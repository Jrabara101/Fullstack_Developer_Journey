/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useCallback } from 'react';
import { GameEngine } from './game/engine';
import { MAPS } from './game/maps';
import { GameCanvas } from './components/GameCanvas';
import { HUD } from './components/HUD';
import { BuyMenu } from './components/BuyMenu';
import { LoadoutCustomizer } from './components/LoadoutCustomizer';
import { MapSelector } from './components/MapSelector';
import { HelpModal } from './components/HelpModal';
import { LoadoutConfig, CameraPerspective, MapData, GameMode } from './types';

export default function App() {
  const [currentMap, setCurrentMap] = useState<MapData>(MAPS[0]);
  const [currentMode, setCurrentMode] = useState<GameMode>('DEFUSAL');

  const [loadout, setLoadout] = useState<LoadoutConfig>({
    primaryWeaponId: 'ak47',
    secondaryWeaponId: 'usp',
    knifeId: 'knife',
    grenades: ['HE', 'SMOKE', 'FLASH'],
    armor: true,
    helmet: true,
    defuseKit: true,
    skin: 'DRAGON_FIRE',
    attachments: {
      ak47: ['RED_DOT', 'LASER_SIGHT'],
      m4a1s: ['SUPPRESSOR', 'RED_DOT'],
      usp: ['SUPPRESSOR']
    }
  });

  // Modal Dialogs
  const [showBuyMenu, setShowBuyMenu] = useState<boolean>(false);
  const [showLoadout, setShowLoadout] = useState<boolean>(false);
  const [showMapSelect, setShowMapSelect] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(false);

  // Initialize Game Engine instance with memo
  const engine = useMemo(() => {
    return new GameEngine(
      currentMap,
      'CT',
      'ct_sas',
      loadout
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentMap]);

  const handleTogglePerspective = useCallback((forcedPerspective?: CameraPerspective) => {
    engine.toggleCameraPerspective(forcedPerspective);
  }, [engine]);

  const handleSelectMapAndMode = useCallback((newMap: MapData, mode: GameMode) => {
    setCurrentMap(newMap);
    setCurrentMode(mode);
  }, []);

  return (
    <div className="relative w-screen h-screen bg-black overflow-hidden flex flex-col font-sans">
      {/* 2nd Person Tactical Viewport */}
      <div className="relative w-full h-full">
        <GameCanvas
          engine={engine}
          currentSkin={loadout.skin}
          onOpenBuyMenu={() => setShowBuyMenu(true)}
          onTogglePerspective={() => handleTogglePerspective()}
        />

        <HUD
          engine={engine}
          onOpenBuyMenu={() => setShowBuyMenu(true)}
          onOpenLoadout={() => setShowLoadout(true)}
          onOpenMapSelect={() => setShowMapSelect(true)}
          onOpenHelp={() => setShowHelp(true)}
          onTogglePerspective={handleTogglePerspective}
        />
      </div>

      {/* Buy Menu Dialog */}
      {showBuyMenu && (
        <BuyMenu
          engine={engine}
          onClose={() => setShowBuyMenu(false)}
        />
      )}

      {/* Gunsmith & Loadout Customizer Dialog */}
      {showLoadout && (
        <LoadoutCustomizer
          engine={engine}
          currentLoadout={loadout}
          onUpdateLoadout={(newLoadout) => setLoadout(newLoadout)}
          onClose={() => setShowLoadout(false)}
        />
      )}

      {/* Map & Mode Deployment Dialog */}
      {showMapSelect && (
        <MapSelector
          currentMapId={currentMap.id}
          onSelectMapAndMode={handleSelectMapAndMode}
          onClose={() => setShowMapSelect(false)}
        />
      )}

      {/* Tactical Help & Controls Manual */}
      {showHelp && (
        <HelpModal
          onClose={() => setShowHelp(false)}
        />
      )}
    </div>
  );
}
