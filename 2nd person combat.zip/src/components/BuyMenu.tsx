import React, { useState } from 'react';
import { GameEngine } from '../game/engine';
import { WEAPONS } from '../game/weapons';
import { WeaponCategory, WeaponDef } from '../types';
import { X, DollarSign, Crosshair, Shield, Zap, Flame, Wind, Sparkles, Target } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface BuyMenuProps {
  engine: GameEngine;
  onClose: () => void;
}

export const BuyMenu: React.FC<BuyMenuProps> = ({ engine, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState<WeaponCategory>('RIFLE');
  const player = engine.state.player;

  const categories: { id: WeaponCategory; label: string; icon: React.ReactNode }[] = [
    { id: 'PISTOL', label: 'Pistols', icon: <Target className="w-4 h-4" /> },
    { id: 'SMG', label: 'Submachine', icon: <Wind className="w-4 h-4" /> },
    { id: 'RIFLE', label: 'Rifles', icon: <Crosshair className="w-4 h-4" /> },
    { id: 'SNIPER', label: 'Snipers', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'SHOTGUN', label: 'Shotgun & Heavy', icon: <Flame className="w-4 h-4" /> },
    { id: 'GEAR', label: 'Armor & Equipment', icon: <Shield className="w-4 h-4" /> }
  ];

  const filteredWeapons = Object.values(WEAPONS).filter(w => w.category === selectedCategory && w.id !== 'knife');

  const handleBuyWeapon = (weapon: WeaponDef) => {
    if (player.money >= weapon.price) {
      player.money -= weapon.price;
      if (weapon.category === 'PISTOL') {
        player.secondaryWeapon = weapon;
        player.ammo[weapon.id] = { mag: weapon.magazineSize, reserve: weapon.reserveAmmo };
      } else {
        player.currentWeapon = weapon;
        player.ammo[weapon.id] = { mag: weapon.magazineSize, reserve: weapon.reserveAmmo };
      }
      sound.playBuy();
    }
  };

  const handleBuyArmor = () => {
    const cost = 1000;
    if (player.money >= cost) {
      player.money -= cost;
      player.armor = 100;
      player.hasHelmet = true;
      sound.playBuy();
    }
  };

  const handleBuyDefuseKit = () => {
    const cost = 400;
    if (player.money >= cost && player.team === 'CT') {
      player.money -= cost;
      player.hasDefuseKit = true;
      sound.playBuy();
    }
  };

  const handleBuyGrenade = (type: 'HE' | 'SMOKE' | 'FLASH', cost: number) => {
    if (player.money >= cost && player.grenades.length < 4) {
      player.money -= cost;
      player.grenades.push(type);
      sound.playBuy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 font-mono select-none">
      <div className="w-full max-w-4xl bg-zinc-950 border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-zinc-900/90 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <span className="text-xl font-black text-amber-400 tracking-wider">TACTICAL CS BUY ARSENAL</span>
            <div className="flex items-center gap-1 bg-emerald-950/80 border border-emerald-500/40 px-3 py-1 rounded-xl text-emerald-400 font-black text-sm">
              <DollarSign className="w-4 h-4" />
              <span>{player.money.toLocaleString()}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-4 p-6 gap-6 min-h-[440px]">
          {/* Left Category Column */}
          <div className="col-span-1 flex flex-col gap-2 border-r border-zinc-800 pr-4">
            <span className="text-[11px] text-zinc-400 uppercase font-bold tracking-wider mb-1">Equipment Category</span>
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl font-bold text-sm transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/20'
                    : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/80'
                }`}
              >
                {cat.icon}
                <span>{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Right Items Grid */}
          <div className="col-span-3 flex flex-col gap-4 overflow-y-auto max-h-[460px] pr-2">
            {selectedCategory === 'GEAR' ? (
              <div className="grid grid-cols-2 gap-4">
                {/* Kevlar Armor + Helmet */}
                <div className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-xl flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-white text-base">Kevlar Vest & Helmet</span>
                      <span className="font-black text-amber-400 text-sm">$ 1,000</span>
                    </div>
                    <p className="text-xs text-zinc-400 mt-2">
                      Full torso and head protection. Absorbs 50% ballistic bullet damage.
                    </p>
                  </div>
                  <button
                    onClick={handleBuyArmor}
                    disabled={player.money < 1000 || (player.armor >= 100 && player.hasHelmet)}
                    className="mt-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white font-bold text-xs rounded-lg transition-all"
                  >
                    {player.armor >= 100 && player.hasHelmet ? 'EQUIPPED' : 'PURCHASE ARMOR'}
                  </button>
                </div>

                {/* Defusal Kit (CT Only) */}
                {player.team === 'CT' && (
                  <div className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-xl flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-white text-base">Tactical Defuse Kit</span>
                        <span className="font-black text-amber-400 text-sm">$ 400</span>
                      </div>
                      <p className="text-xs text-zinc-400 mt-2">
                        Cuts C4 bomb defusal duration in half (from 10 seconds down to 5 seconds).
                      </p>
                    </div>
                    <button
                      onClick={handleBuyDefuseKit}
                      disabled={player.money < 400 || player.hasDefuseKit}
                      className="mt-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white font-bold text-xs rounded-lg transition-all"
                    >
                      {player.hasDefuseKit ? 'EQUIPPED' : 'PURCHASE KIT'}
                    </button>
                  </div>
                )}

                {/* HE Frag Grenade */}
                <div className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-xl flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-white text-base">HE Frag Grenade</span>
                      <span className="font-black text-amber-400 text-sm">$ 300</span>
                    </div>
                    <p className="text-xs text-zinc-400 mt-2">
                      High-explosive fragmentation grenade. Obliterates destructible crates and clears rooms.
                    </p>
                  </div>
                  <button
                    onClick={() => handleBuyGrenade('HE', 300)}
                    disabled={player.money < 300 || player.grenades.length >= 4}
                    className="mt-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white font-bold text-xs rounded-lg transition-all"
                  >
                    BUY HE GRENADE
                  </button>
                </div>

                {/* Smoke Grenade */}
                <div className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-xl flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-white text-base">Tactical Smoke Grenade</span>
                      <span className="font-black text-amber-400 text-sm">$ 300</span>
                    </div>
                    <p className="text-xs text-zinc-400 mt-2">
                      Deploys an impenetrable volumetric cloud that blocks optical sightlines and 2nd-person targeting.
                    </p>
                  </div>
                  <button
                    onClick={() => handleBuyGrenade('SMOKE', 300)}
                    disabled={player.money < 300 || player.grenades.length >= 4}
                    className="mt-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white font-bold text-xs rounded-lg transition-all"
                  >
                    BUY SMOKE GRENADE
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {filteredWeapons.map(wep => {
                  const isCurrent = player.currentWeapon.id === wep.id || player.secondaryWeapon.id === wep.id;
                  const canAfford = player.money >= wep.price;

                  return (
                    <div 
                      key={wep.id}
                      className="p-4 bg-zinc-900/90 border border-zinc-800 rounded-xl flex flex-col justify-between hover:border-zinc-700 transition-all"
                    >
                      <div>
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="font-bold text-white text-base block">{wep.name}</span>
                            <span className="text-[10px] text-zinc-400 uppercase">{wep.category}</span>
                          </div>
                          <span className="font-black text-amber-400 text-sm">$ {wep.price.toLocaleString()}</span>
                        </div>

                        {/* Weapon Stat Gauges */}
                        <div className="grid grid-cols-2 gap-2 mt-3 text-[10px]">
                          <div>
                            <span className="text-zinc-400">Damage: </span>
                            <span className="text-white font-bold">{wep.damage} (x{wep.headshotMultiplier} HS)</span>
                          </div>
                          <div>
                            <span className="text-zinc-400">Fire Rate: </span>
                            <span className="text-white font-bold">{wep.fireRate} rps</span>
                          </div>
                          <div>
                            <span className="text-zinc-400">Magazine: </span>
                            <span className="text-white font-bold">{wep.magazineSize} rnds</span>
                          </div>
                          <div>
                            <span className="text-zinc-400">Penetration: </span>
                            <span className="text-amber-300 font-bold">{wep.penetration >= 2.5 ? 'Heavy Wallbang' : 'Medium'}</span>
                          </div>
                        </div>

                        <p className="text-xs text-zinc-400 mt-2 line-clamp-2">
                          {wep.description}
                        </p>
                      </div>

                      <button
                        onClick={() => handleBuyWeapon(wep)}
                        disabled={!canAfford || isCurrent}
                        className={`mt-4 py-2 font-bold text-xs rounded-lg transition-all ${
                          isCurrent
                            ? 'bg-zinc-800 text-zinc-400 cursor-default'
                            : (canAfford
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                              : 'bg-zinc-800 text-zinc-500 cursor-not-allowed')
                        }`}
                      >
                        {isCurrent ? 'EQUIPPED' : (canAfford ? 'PURCHASE' : 'INSUFFICIENT FUNDS')}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-zinc-900 border-t border-zinc-800 flex justify-between items-center text-xs text-zinc-400">
          <span>Press [B] anytime in Casual mode to open Arsenal</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-lg transition-all"
          >
            DONE (CLOSE)
          </button>
        </div>
      </div>
    </div>
  );
};
