import React, { useRef, useEffect, useCallback } from 'react';
import { GameEngine } from '../game/engine';
import { WEAPON_SKIN_PALETTES } from '../game/weapons';
import { WeaponSkin } from '../types';

interface GameCanvasProps {
  engine: GameEngine;
  currentSkin: WeaponSkin;
  onOpenBuyMenu: () => void;
  onTogglePerspective: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  engine,
  currentSkin,
  onOpenBuyMenu,
  onTogglePerspective,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const keysRef = useRef<Record<string, boolean>>({});
  const mousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isMouseDownRef = useRef<boolean>(false);

  // Key and Mouse event handling
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Prevent scrolling for game controls
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) {
      e.preventDefault();
    }

    keysRef.current[e.code] = true;

    if (e.code === 'KeyB') {
      onOpenBuyMenu();
    } else if (e.code === 'KeyC' || e.code === 'Space') {
      onTogglePerspective();
    } else if (e.code === 'KeyN') {
      engine.toggleVisionMode('NIGHT');
    } else if (e.code === 'KeyT') {
      engine.toggleVisionMode('THERMAL');
    }
  }, [engine, onOpenBuyMenu, onTogglePerspective]);

  const handleKeyUp = useCallback((e: KeyboardEvent) => {
    keysRef.current[e.code] = false;
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    // Convert screen coordinates to world coordinates based on camera position and zoom
    const cam = engine.state.camera;
    const worldX = (clientX - canvasRef.current.width / 2) / cam.zoom + cam.x;
    const worldY = (clientY - canvasRef.current.height / 2) / cam.zoom + cam.y;

    mousePosRef.current = { x: worldX, y: worldY };
  }, [engine]);

  const handleMouseDown = useCallback((e: MouseEvent) => {
    if (e.button === 0) {
      isMouseDownRef.current = true;
    }
  }, []);

  const handleMouseUp = useCallback((e: MouseEvent) => {
    if (e.button === 0) {
      isMouseDownRef.current = false;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleKeyDown, handleKeyUp, handleMouseMove, handleMouseDown, handleMouseUp]);

  // Main Render Loop
  useEffect(() => {
    let animationFrameId: number;

    const render = () => {
      // Pass inputs to engine
      engine.setInput(keysRef.current, mousePosRef.current, isMouseDownRef.current);
      engine.update();

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Handle retina canvas sizing
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }

      const cam = engine.state.camera;
      const state = engine.state;

      ctx.save();
      ctx.clearRect(0, 0, width, height);

      // Camera shake
      const shakeX = (Math.random() * 2 - 1) * cam.shake;
      const shakeY = (Math.random() * 2 - 1) * cam.shake;

      // Transform camera view
      ctx.translate(width / 2 + shakeX, height / 2 + shakeY);
      ctx.scale(cam.zoom, cam.zoom);
      ctx.translate(-cam.x, -cam.y);

      // 1. Draw Map Floor Grid & Background
      ctx.fillStyle = state.map.backgroundColor;
      ctx.fillRect(0, 0, state.map.width, state.map.height);

      // Floor tiles
      ctx.strokeStyle = state.map.floorTileColor;
      ctx.lineWidth = 1;
      const tileSize = 80;
      for (let x = 0; x < state.map.width; x += tileSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, state.map.height);
        ctx.stroke();
      }
      for (let y = 0; y < state.map.height; y += tileSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(state.map.width, y);
        ctx.stroke();
      }

      // 2. Draw Bomb Sites
      for (const site of state.map.bombSites) {
        ctx.beginPath();
        ctx.arc(site.x, site.y, site.radius, 0, Math.PI * 2);
        ctx.fillStyle = site.id === 'A' ? 'rgba(239, 68, 68, 0.15)' : 'rgba(59, 130, 246, 0.15)';
        ctx.fill();
        ctx.strokeStyle = site.id === 'A' ? '#ef4444' : '#3b82f6';
        ctx.lineWidth = 3;
        ctx.setLineDash([8, 6]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Label
        ctx.font = 'bold 24px monospace';
        ctx.fillStyle = site.id === 'A' ? '#ef4444' : '#3b82f6';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`SITE ${site.id}`, site.x, site.y);
      }

      // 3. Draw Bullet Decals & Scorch Marks
      for (const decal of state.bulletDecals) {
        ctx.save();
        ctx.globalAlpha = decal.alpha;
        if (decal.type === 'EXPLOSION_SCORCH') {
          const grad = ctx.createRadialGradient(decal.x, decal.y, 10, decal.x, decal.y, decal.size);
          grad.addColorStop(0, '#18181b');
          grad.addColorStop(0.7, '#27272a');
          grad.addColorStop(1, 'transparent');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(decal.x, decal.y, decal.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (decal.type === 'BULLET_HOLE') {
          ctx.fillStyle = '#09090b';
          ctx.beginPath();
          ctx.arc(decal.x, decal.y, decal.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // 4. Draw Destructible Objects (Crates, Glass, Drywall, Barrels)
      for (const d of state.activeDestructibles) {
        if (d.isDestroyed) continue;

        ctx.save();
        ctx.translate(d.x, d.y);
        ctx.rotate(d.rotation);

        if (d.type === 'WOOD_CRATE') {
          // Wooden crate with planks and health degradation
          ctx.fillStyle = '#854d0e';
          ctx.fillRect(-d.width / 2, -d.height / 2, d.width, d.height);
          ctx.strokeStyle = '#713f12';
          ctx.lineWidth = 3;
          ctx.strokeRect(-d.width / 2, -d.height / 2, d.width, d.height);

          // Diagonal cross braces
          ctx.beginPath();
          ctx.moveTo(-d.width / 2, -d.height / 2);
          ctx.lineTo(d.width / 2, d.height / 2);
          ctx.moveTo(d.width / 2, -d.height / 2);
          ctx.lineTo(-d.width / 2, d.height / 2);
          ctx.stroke();

          // Health damage cracks
          if (d.health < d.maxHealth) {
            ctx.strokeStyle = 'rgba(0,0,0,0.6)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(0, -d.height / 3);
            ctx.lineTo(d.width / 4, 0);
            ctx.lineTo(-d.width / 5, d.height / 3);
            ctx.stroke();
          }
        } else if (d.type === 'GLASS_WALL') {
          // Semi-transparent tempered glass with shine reflection
          ctx.fillStyle = 'rgba(56, 189, 248, 0.35)';
          ctx.fillRect(-d.width / 2, -d.height / 2, d.width, d.height);
          ctx.strokeStyle = '#0284c7';
          ctx.lineWidth = 2;
          ctx.strokeRect(-d.width / 2, -d.height / 2, d.width, d.height);

          // Glass shine
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(-d.width / 3, -d.height / 2);
          ctx.lineTo(-d.width / 4, d.height / 2);
          ctx.stroke();
        } else if (d.type === 'DRYWALL') {
          // Plaster drywall panel
          ctx.fillStyle = '#cbd5e1';
          ctx.fillRect(-d.width / 2, -d.height / 2, d.width, d.height);
          ctx.strokeStyle = '#94a3b8';
          ctx.lineWidth = 2;
          ctx.strokeRect(-d.width / 2, -d.height / 2, d.width, d.height);
        } else if (d.type === 'EXPLOSIVE_BARREL') {
          // Red hazard explosive drum
          ctx.fillStyle = '#dc2626';
          ctx.beginPath();
          ctx.arc(0, 0, d.width / 2, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#991b1b';
          ctx.lineWidth = 3;
          ctx.stroke();

          // Flammable symbol
          ctx.fillStyle = '#fef08a';
          ctx.font = 'bold 16px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('⚠', 0, 0);
        } else if (d.type === 'SANDBAG') {
          ctx.fillStyle = '#78716c';
          ctx.fillRect(-d.width / 2, -d.height / 2, d.width, d.height);
          ctx.strokeStyle = '#57534e';
          ctx.lineWidth = 2;
          ctx.strokeRect(-d.width / 2, -d.height / 2, d.width, d.height);
        }

        // Destructible Health indicator bar if damaged
        if (d.health < d.maxHealth && d.health > 0) {
          const hpPct = d.health / d.maxHealth;
          ctx.fillStyle = 'rgba(0,0,0,0.7)';
          ctx.fillRect(-d.width / 2, -d.height / 2 - 8, d.width, 4);
          ctx.fillStyle = hpPct > 0.5 ? '#22c55e' : (hpPct > 0.25 ? '#eab308' : '#ef4444');
          ctx.fillRect(-d.width / 2, -d.height / 2 - 8, d.width * hpPct, 4);
        }

        ctx.restore();
      }

      // 5. Draw Solid Walls
      for (const w of state.map.walls) {
        ctx.beginPath();
        ctx.moveTo(w.x1, w.y1);
        ctx.lineTo(w.x2, w.y2);
        ctx.strokeStyle = w.color;
        ctx.lineWidth = w.thickness;
        ctx.lineCap = 'square';
        ctx.stroke();
      }

      // 6. Draw Planted C4
      if (state.bomb.isPlanted && !state.bomb.isExploded && !state.bomb.isDefused) {
        ctx.save();
        ctx.translate(state.bomb.x, state.bomb.y);
        ctx.fillStyle = '#27272a';
        ctx.fillRect(-12, -8, 24, 16);
        ctx.strokeStyle = '#e4e4e7';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-12, -8, 24, 16);

        // Blinking Red LED
        const blink = Math.sin(performance.now() * (1 + (40 - state.bomb.timer) * 0.2)) > 0;
        ctx.fillStyle = blink ? '#ef4444' : '#7f1d1d';
        ctx.beginPath();
        ctx.arc(4, 0, 3, 0, Math.PI * 2);
        ctx.fill();

        // Digital countdown digits
        ctx.fillStyle = '#22c55e';
        ctx.font = 'bold 8px monospace';
        ctx.fillText(`${Math.ceil(state.bomb.timer)}s`, -10, 3);
        ctx.restore();
      }

      // 7. Draw Smoke Clouds
      for (const smoke of state.smokeClouds) {
        const grad = ctx.createRadialGradient(smoke.x, smoke.y, 20, smoke.x, smoke.y, smoke.radius);
        grad.addColorStop(0, 'rgba(203, 213, 225, 0.92)');
        grad.addColorStop(0.7, 'rgba(148, 163, 184, 0.8)');
        grad.addColorStop(1, 'rgba(100, 116, 139, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(smoke.x, smoke.y, smoke.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // 8. Draw Grenades
      for (const g of state.grenades) {
        ctx.fillStyle = g.type === 'HE' ? '#15803d' : (g.type === 'SMOKE' ? '#94a3b8' : '#38bdf8');
        ctx.beginPath();
        ctx.arc(g.x, g.y, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      // 9. Draw Combat Entities (Player and Bots)
      const allEntities = [state.player, ...state.bots];
      for (const entity of allEntities) {
        if (entity.isDead) {
          // Dead body / skull marker
          ctx.save();
          ctx.translate(entity.x, entity.y);
          ctx.fillStyle = 'rgba(220, 38, 38, 0.6)';
          ctx.beginPath();
          ctx.arc(0, 0, 14, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 12px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('☠', 0, 0);
          ctx.restore();
          continue;
        }

        ctx.save();
        ctx.translate(entity.x, entity.y);
        ctx.rotate(entity.angle);

        // Body Capsule & Team Colors
        const isCT = entity.team === 'CT';
        const teamBaseColor = isCT ? '#1e3a8a' : '#7f1d1d';
        const teamAccent = isCT ? '#38bdf8' : '#f87171';

        // Laser pointer beam if attached
        if (entity.isPlayer || entity.state === 'ENGAGING') {
          ctx.save();
          ctx.strokeStyle = isCT ? 'rgba(56, 189, 248, 0.45)' : 'rgba(239, 68, 68, 0.45)';
          ctx.lineWidth = 1.5;
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(18, 5);
          ctx.lineTo(entity.currentWeapon.range, 5);
          ctx.stroke();
          ctx.restore();
        }

        // Weapon Barrel & Skin Styling
        const skinPalette = WEAPON_SKIN_PALETTES[currentSkin] || WEAPON_SKIN_PALETTES.DEFAULT;
        ctx.fillStyle = entity.isPlayer ? skinPalette.primary : '#27272a';
        ctx.fillRect(8, 2, 22, 5); // Weapon body
        ctx.fillStyle = entity.isPlayer ? skinPalette.accent : '#71717a';
        ctx.fillRect(18, 3, 10, 3); // Weapon barrel accent

        // Hands & Shoulders
        ctx.fillStyle = teamBaseColor;
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2); // Torso / Helmet
        ctx.fill();
        ctx.strokeStyle = teamAccent;
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Visor / Goggles Reflection
        ctx.fillStyle = teamAccent;
        ctx.fillRect(8, -6, 4, 12);

        // Backpack / Kit (Defuse kit or C4)
        if (entity.hasDefuseKit) {
          ctx.fillStyle = '#22c55e';
          ctx.fillRect(-16, -6, 5, 12);
        } else if (entity.hasC4) {
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(-16, -6, 5, 12);
        }

        ctx.restore();

        // Health & Name Tag Floating above entity
        ctx.save();
        ctx.translate(entity.x, entity.y - 28);
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = entity.isPlayer ? '#fef08a' : (entity.team === 'CT' ? '#93c5fd' : '#fca5a5');
        ctx.fillText(`${entity.name} [${entity.currentWeapon.name.split(' ')[0]}]`, 0, -4);

        // Health Bar
        const barWidth = 36;
        const hpPct = entity.health / entity.maxHealth;
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(-barWidth / 2, 0, barWidth, 4);
        ctx.fillStyle = hpPct > 0.5 ? '#22c55e' : (hpPct > 0.25 ? '#eab308' : '#ef4444');
        ctx.fillRect(-barWidth / 2, 0, barWidth * hpPct, 4);

        // Objective Progress Bar (Planting / Defusing)
        if (entity.isPlanting || entity.isDefusing) {
          const prog = entity.isPlanting ? entity.plantProgress : entity.defuseProgress;
          ctx.fillStyle = entity.isPlanting ? '#ef4444' : '#3b82f6';
          ctx.fillRect(-barWidth / 2, 6, barWidth * prog, 4);
        }
        ctx.restore();
      }

      // 10. Draw Projectile Tracers
      for (const proj of state.projectiles) {
        ctx.save();
        ctx.strokeStyle = proj.color;
        ctx.lineWidth = 2.5;
        ctx.shadowColor = proj.color;
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.moveTo(proj.x - proj.vx * 0.02, proj.y - proj.vy * 0.02);
        ctx.lineTo(proj.x, proj.y);
        ctx.stroke();
        ctx.restore();
      }

      // 11. Draw Particles (Debris, Sparks, Blood)
      for (const p of state.particles) {
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        if (p.shape === 'CIRCLE' || p.shape === 'BLOOD') {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.shape === 'RECT') {
          ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
        } else if (p.shape === 'SPARK') {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // 12. Draw CCTV Camera Mounts
      for (const cctv of state.map.cctvCameras) {
        ctx.save();
        ctx.translate(cctv.x, cctv.y);
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(0, 0, 10, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Camera FOV Cone
        ctx.fillStyle = 'rgba(56, 189, 248, 0.08)';
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, 160, cctv.angle - cctv.fov / 2, cctv.angle + cctv.fov / 2);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }

      // 2nd-Person Focus Target Bracket around Player
      const p = state.player;
      if (!p.isDead) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.strokeStyle = '#22c55e';
        ctx.lineWidth = 2;
        const s = 24;
        // Corner brackets
        ctx.beginPath();
        ctx.moveTo(-s, -s + 8); ctx.lineTo(-s, -s); ctx.lineTo(-s + 8, -s);
        ctx.moveTo(s - 8, -s); ctx.lineTo(s, -s); ctx.lineTo(s, -s + 8);
        ctx.moveTo(-s, s - 8); ctx.lineTo(-s, s); ctx.lineTo(-s + 8, s);
        ctx.moveTo(s - 8, s); ctx.lineTo(s, s); ctx.lineTo(s, s - 8);
        ctx.stroke();

        ctx.font = 'bold 9px monospace';
        ctx.fillStyle = '#22c55e';
        ctx.textAlign = 'center';
        ctx.fillText('YOU [TARGET LOCK]', 0, s + 12);
        ctx.restore();
      }

      ctx.restore(); // Restore world transform

      // ==========================================
      // 13. SCREEN-SPACE 2ND-PERSON HUD OVERLAYS
      // ==========================================

      // Flashbang Fullscreen Whiteout
      if (p.flashDuration > 0) {
        ctx.save();
        ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(1.0, p.flashDuration / 2)})`;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
      }

      // Night Vision / Thermal Vision Shaders
      if (cam.nightVision) {
        ctx.save();
        ctx.fillStyle = 'rgba(16, 185, 129, 0.22)';
        ctx.fillRect(0, 0, width, height);
        // Vignette
        const grad = ctx.createRadialGradient(width / 2, height / 2, width * 0.2, width / 2, height / 2, width * 0.6);
        grad.addColorStop(0, 'transparent');
        grad.addColorStop(1, 'rgba(0, 30, 10, 0.8)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
      } else if (cam.thermalVision) {
        ctx.save();
        ctx.fillStyle = 'rgba(147, 51, 234, 0.18)';
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
      }

      // Authentic 2nd-Person Perspective HUD Framing
      ctx.save();
      // Scanlines
      ctx.fillStyle = `rgba(0, 0, 0, ${cam.scanlineIntensity * 0.25})`;
      for (let y = 0; y < height; y += 4) {
        ctx.fillRect(0, y, width, 1.5);
      }

      // Viewpoint Corner Tag & Reticle
      ctx.font = 'bold 12px monospace';
      ctx.fillStyle = '#22c55e';
      ctx.textAlign = 'left';

      if (cam.perspective === 'ENEMY_POV') {
        ctx.fillStyle = '#ef4444';
        ctx.fillText('🔴 2ND PERSON: [ENEMY EYES POV - TARGETING YOU]', 24, 32);
        ctx.fillText('OPTIC ZOOM: 1.4x | SIGHT-RANGE: CALIBRATED', 24, 48);

        // Center Enemy Crosshairs
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(width / 2, height / 2, 20, 0, Math.PI * 2);
        ctx.moveTo(width / 2 - 30, height / 2); ctx.lineTo(width / 2 - 8, height / 2);
        ctx.moveTo(width / 2 + 8, height / 2); ctx.lineTo(width / 2 + 30, height / 2);
        ctx.moveTo(width / 2, height / 2 - 30); ctx.lineTo(width / 2, height / 2 - 8);
        ctx.moveTo(width / 2, height / 2 + 8); ctx.lineTo(width / 2, height / 2 + 30);
        ctx.stroke();
      } else if (cam.perspective === 'SURVEILLANCE_CCTV') {
        ctx.fillStyle = '#38bdf8';
        ctx.fillText('📹 2ND PERSON: [SURVEILLANCE CCTV FEED]', 24, 32);
        ctx.fillText(`CAM-ID: ${cam.sourceCCTVId || 'CCTV-01'} | REC ● 1080P 60FPS`, 24, 48);
      } else if (cam.perspective === 'SPOTTER_DRONE') {
        ctx.fillStyle = '#f59e0b';
        ctx.fillText('🛸 2ND PERSON: [TACTICAL SPOTTER DRONE]', 24, 32);
        ctx.fillText('ALT: 45M | SIGNAL: 99% | GPS LOCKED', 24, 48);
      } else if (cam.perspective === 'SQUAD_WINGMAN') {
        ctx.fillStyle = '#a855f7';
        ctx.fillText('🛡️ 2ND PERSON: [WINGMAN SHOULDER CAM]', 24, 32);
        ctx.fillText('SQUAD LINK: ACTIVE | OVERWATCH ON YOU', 24, 48);
      } else {
        ctx.fillStyle = '#94a3b8';
        ctx.fillText('🎯 TACTICAL ORBIT VIEW', 24, 32);
      }

      // Camera switch hint
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.textAlign = 'right';
      ctx.fillText('Press [SPACE] or [C] to Switch Camera View | [N] Night | [T] Thermal', width - 24, 32);

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animationFrameId);
  }, [engine, currentSkin]);

  return (
    <div className="relative w-full h-full bg-zinc-950 overflow-hidden select-none cursor-crosshair">
      <canvas
        ref={canvasRef}
        className="w-full h-full block"
      />
    </div>
  );
};
