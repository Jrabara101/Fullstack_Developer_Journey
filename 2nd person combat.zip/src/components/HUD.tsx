import React from 'react';
import { GameEngine } from '../game/engine';
import { CameraPerspective } from '../types';
import { 
  Shield, Crosshair, DollarSign, Clock, Eye, Video, 
  Radio, Bomb, Sparkles, Zap, Flame, ShieldAlert,
  Volume2, VolumeX, Moon, Sun, ShoppingCart, HelpCircle
} from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface HUDProps {
  engine: GameEngine;
  onOpenBuyMenu: () => void;
  onOpenLoadout: () => void;
  onOpenMapSelect: () => void;
  onOpenHelp: () => void;
  onTogglePerspective: (perspective?: CameraPerspective) => void;
}

export const HUD: React.FC<HUDProps> = ({
  engine,
  onOpenBuyMenu,
  onOpenLoadout,
  onOpenMapSelect,
  onOpenHelp,
  onTogglePerspective,
}) => {
  const { player, round, bomb, killFeed, camera, map } = engine.state;
  const isMuted = sound.getIsMuted();

  const currentAmmo = player.ammo[player.currentWeapon.id] || { mag: 0, reserve: 0 };
  const hpPercent = Math.max(0, Math.min(100, (player.health / player.maxHealth) * 100));
  const armorPercent = Math.max(0, Math.min(100, player.armor));

  const formatTime = (secs: number) => {
    const m = Math.floor(Math.max(0, secs) / 60);
    const s = Math.floor(Math.max(0, secs) % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 z-10 font-mono">
      {/* TOP BAR: Scoreboard, Timer, Minimap, Killfeed, Controls */}
      <div className="flex items-start justify-between w-full">
        {/* TOP LEFT: Radar Minimap & Objective */}
        <div className="flex flex-col gap-2 pointer-events-auto">
          <div className="relative w-44 h-44 bg-zinc-950/85 border border-zinc-700/80 rounded-xl overflow-hidden shadow-2xl backdrop-blur-md">
            {/* Radar Canvas Background */}
            <div className="absolute inset-0 flex items-center justify-center">
              {/* Radar sweep line */}
              <div className="absolute w-full h-[1px] bg-emerald-500/20 top-1/2 left-0" />
              <div className="absolute h-full w-[1px] bg-emerald-500/20 top-0 left-1/2" />
              <div className="w-32 h-32 rounded-full border border-emerald-500/30" />
              <div className="w-16 h-16 rounded-full border border-emerald-500/20" />
            </div>

            {/* Bomb Sites on Radar */}
            {map.bombSites.map(s => (
              <div 
                key={s.id}
                className="absolute text-[10px] font-bold text-red-400 bg-red-950/80 px-1 border border-red-500/50 rounded transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${(s.x / map.width) * 100}%`,
                  top: `${(s.y / map.height) * 100}%`,
                }}
              >
                {s.id}
              </div>
            ))}

            {/* Teammates on Radar */}
            {engine.state.bots.filter(b => b.team === player.team && !b.isDead).map(b => (
              <div
                key={b.id}
                className="absolute w-2 h-2 rounded-full bg-sky-400 shadow-[0_0_8px_#38bdf8] transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${(b.x / map.width) * 100}%`,
                  top: `${(b.y / map.height) * 100}%`,
                }}
              />
            ))}

            {/* Enemies on Radar (revealed if close or shooting) */}
            {engine.state.bots.filter(b => b.team !== player.team && !b.isDead).map(b => (
              <div
                key={b.id}
                className="absolute w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444] animate-pulse transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${(b.x / map.width) * 100}%`,
                  top: `${(b.y / map.height) * 100}%`,
                }}
              />
            ))}

            {/* Player Marker on Radar */}
            <div
              className="absolute w-3 h-3 rounded-full bg-emerald-400 border-2 border-white shadow-[0_0_10px_#22c55e] transform -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${(player.x / map.width) * 100}%`,
                top: `${(player.y / map.height) * 100}%`,
              }}
            />

            {/* Radar Header */}
            <div className="absolute top-1.5 left-2 right-2 flex justify-between text-[9px] text-zinc-400 font-bold uppercase tracking-wider">
              <span>{map.codeName}</span>
              <span className="text-emerald-400">RADAR ACTIVE</span>
            </div>
          </div>

          {/* Quick Buttons: Loadout, Map, Buy, Sound */}
          <div className="flex gap-1.5">
            <button
              onClick={onOpenBuyMenu}
              className="px-2.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>BUY [B]</span>
            </button>
            <button
              onClick={onOpenLoadout}
              className="px-2.5 py-1.5 bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-200 border border-zinc-600/50 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>LOADOUT</span>
            </button>
            <button
              onClick={onOpenMapSelect}
              className="px-2.5 py-1.5 bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-200 border border-zinc-600/50 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              <span>MAPS</span>
            </button>
            <button
              onClick={onOpenHelp}
              className="p-1.5 bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300 border border-zinc-600/50 rounded-lg text-xs transition-all shadow-md active:scale-95"
              title="Tactical Guide & Controls"
            >
              <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            </button>
            <button
              onClick={() => sound.toggleMute()}
              className="p-1.5 bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300 border border-zinc-600/50 rounded-lg text-xs transition-all shadow-md active:scale-95"
              title="Toggle Audio"
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
            </button>
          </div>
        </div>

        {/* TOP CENTER: Round Scoreboard & Match Timer */}
        <div className="flex flex-col items-center pointer-events-auto">
          <div className="flex items-center bg-zinc-950/90 border border-zinc-700/80 rounded-2xl px-6 py-2 shadow-2xl backdrop-blur-md gap-6">
            {/* CT Score */}
            <div className="flex items-center gap-3">
              <div className="w-7 h-7 rounded-lg bg-blue-950 border border-blue-500/50 flex items-center justify-center font-black text-blue-400 text-sm">
                CT
              </div>
              <span className="text-2xl font-black text-blue-400">{round.ctScore}</span>
            </div>

            {/* Timer & Round */}
            <div className="flex flex-col items-center px-4 border-x border-zinc-800">
              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">
                ROUND {round.roundNumber} / {round.maxRounds}
              </span>
              <div className="flex items-center gap-1.5 text-xl font-black text-amber-400">
                <Clock className="w-4 h-4" />
                <span>{formatTime(round.phaseTimer)}</span>
              </div>
              {bomb.isPlanted && (
                <div className="flex items-center gap-1 text-[11px] font-bold text-red-500 animate-pulse mt-0.5">
                  <Bomb className="w-3.5 h-3.5" />
                  <span>BOMB PLANTED ({Math.ceil(bomb.timer)}s)</span>
                </div>
              )}
            </div>

            {/* T Score */}
            <div className="flex items-center gap-3">
              <span className="text-2xl font-black text-red-400">{round.tScore}</span>
              <div className="w-7 h-7 rounded-lg bg-red-950 border border-red-500/50 flex items-center justify-center font-black text-red-400 text-sm">
                T
              </div>
            </div>
          </div>

          {/* Perspective Quick Switcher Pill Bar */}
          <div className="flex items-center bg-zinc-950/80 border border-zinc-800 rounded-full px-2 py-1 mt-2 gap-1 backdrop-blur-md">
            <span className="text-[9px] font-bold text-zinc-400 px-2 uppercase">2nd Person Cam:</span>
            <button
              onClick={() => onTogglePerspective('ENEMY_POV')}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all ${
                camera.perspective === 'ENEMY_POV'
                  ? 'bg-red-500 text-white shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>Enemy POV</span>
            </button>
            <button
              onClick={() => onTogglePerspective('SURVEILLANCE_CCTV')}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all ${
                camera.perspective === 'SURVEILLANCE_CCTV'
                  ? 'bg-cyan-500 text-white shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
            >
              <Video className="w-3 h-3" />
              <span>CCTV</span>
            </button>
            <button
              onClick={() => onTogglePerspective('SPOTTER_DRONE')}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all ${
                camera.perspective === 'SPOTTER_DRONE'
                  ? 'bg-amber-500 text-white shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
            >
              <Radio className="w-3 h-3" />
              <span>Drone</span>
            </button>
            <button
              onClick={() => onTogglePerspective('SQUAD_WINGMAN')}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all ${
                camera.perspective === 'SQUAD_WINGMAN'
                  ? 'bg-purple-500 text-white shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
            >
              <ShieldAlert className="w-3 h-3" />
              <span>Wingman</span>
            </button>
          </div>
        </div>

        {/* TOP RIGHT: Killfeed & Money */}
        <div className="flex flex-col items-end gap-2 w-72 pointer-events-auto">
          {/* Economy Cash Counter */}
          <div className="flex items-center gap-1 bg-emerald-950/80 border border-emerald-500/40 rounded-xl px-4 py-1.5 shadow-xl text-emerald-400 font-black text-lg">
            <DollarSign className="w-5 h-5 text-emerald-300" />
            <span>{player.money.toLocaleString()}</span>
          </div>

          {/* CS Killfeed Stream */}
          <div className="flex flex-col gap-1.5 w-full">
            {killFeed.map(item => (
              <div 
                key={item.id}
                className="flex items-center justify-end gap-2 bg-zinc-950/80 border border-zinc-800/80 px-2.5 py-1 rounded-lg text-xs backdrop-blur-sm shadow-md animate-fade-in"
              >
                <span className={`font-bold ${item.killerTeam === 'CT' ? 'text-blue-400' : 'text-red-400'}`}>
                  {item.killerName}
                </span>
                <span className="text-zinc-400 text-[10px] bg-zinc-800/80 px-1.5 py-0.5 rounded border border-zinc-700">
                  {item.weaponName.split(' ')[0]}
                </span>
                {item.isHeadshot && (
                  <span className="text-red-500 text-[10px] font-black" title="Headshot">
                    🎯 HS
                  </span>
                )}
                <span className={`font-bold ${item.victimTeam === 'CT' ? 'text-blue-400' : 'text-red-400'}`}>
                  {item.victimName}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CENTER: Round Over / Celebration Banner */}
      {round.phase === 'ROUND_OVER' && (
        <div className="self-center bg-zinc-950/95 border-2 border-amber-500/80 rounded-2xl p-6 shadow-2xl backdrop-blur-xl flex flex-col items-center gap-2 animate-bounce-short">
          <span className={`text-2xl font-black ${round.winnerTeam === 'CT' ? 'text-blue-400' : 'text-red-400'}`}>
            {round.winReason}
          </span>
          <span className="text-xs text-zinc-400">Next round starting in {Math.ceil(round.phaseTimer)}s...</span>
        </div>
      )}

      {/* BOTTOM BAR: Health, Armor, Weapon Ammo, Grenades, C4 Status */}
      <div className="flex items-end justify-between w-full pointer-events-auto">
        {/* BOTTOM LEFT: Health & Armor */}
        <div className="flex items-center gap-3 bg-zinc-950/90 border border-zinc-700/80 rounded-2xl p-4 shadow-2xl backdrop-blur-md">
          {/* Health */}
          <div className="flex flex-col gap-1 w-32">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-zinc-400 font-bold uppercase flex items-center gap-1">
                <Crosshair className="w-3.5 h-3.5 text-red-500" /> HEALTH
              </span>
              <span className="text-2xl font-black text-white">{Math.ceil(player.health)}</span>
            </div>
            <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-200 ${
                  hpPercent > 50 ? 'bg-emerald-500' : (hpPercent > 25 ? 'bg-amber-500' : 'bg-red-500')
                }`}
                style={{ width: `${hpPercent}%` }}
              />
            </div>
          </div>

          <div className="w-[1px] h-10 bg-zinc-800" />

          {/* Armor */}
          <div className="flex flex-col gap-1 w-28">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-zinc-400 font-bold uppercase flex items-center gap-1">
                <Shield className="w-3.5 h-3.5 text-blue-400" /> ARMOR
              </span>
              <span className="text-2xl font-black text-blue-300">{Math.ceil(player.armor)}</span>
            </div>
            <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-500 transition-all duration-200"
                style={{ width: `${armorPercent}%` }}
              />
            </div>
          </div>

          {/* Defuse kit / C4 Badge */}
          {player.hasDefuseKit && (
            <div className="px-2 py-1 bg-emerald-950/80 border border-emerald-500/50 rounded-lg text-[10px] font-black text-emerald-300 flex items-center gap-1">
              <Zap className="w-3 h-3" /> KIT
            </div>
          )}
          {player.hasC4 && (
            <div className="px-2 py-1 bg-red-950/80 border border-red-500/50 rounded-lg text-[10px] font-black text-red-400 flex items-center gap-1 animate-pulse">
              <Bomb className="w-3 h-3" /> C4 READY
            </div>
          )}
        </div>

        {/* BOTTOM RIGHT: Weapon Magazine Ammo & Grenade Pouch */}
        <div className="flex items-center gap-4 bg-zinc-950/90 border border-zinc-700/80 rounded-2xl p-4 shadow-2xl backdrop-blur-md">
          {/* Tactical Grenade Pouch */}
          <div className="flex gap-1.5 pr-3 border-r border-zinc-800">
            {['HE', 'SMOKE', 'FLASH'].map((g, idx) => {
              const hasG = player.grenades.includes(g);
              return (
                <div
                  key={idx}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black border transition-all ${
                    hasG 
                      ? 'bg-zinc-800 border-zinc-600 text-amber-400' 
                      : 'bg-zinc-900/40 border-zinc-800 text-zinc-700'
                  }`}
                  title={`${g} Grenade (Press G to throw)`}
                >
                  {g === 'HE' ? '💣' : (g === 'SMOKE' ? '💨' : '⚡')}
                </div>
              );
            })}
          </div>

          {/* Active Weapon Name & Magazine */}
          <div className="flex flex-col items-end">
            <span className="text-[11px] text-zinc-400 font-bold uppercase tracking-wider">
              {player.currentWeapon.name}
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-black text-amber-400">
                {currentAmmo.mag}
              </span>
              <span className="text-lg font-bold text-zinc-500">
                / {currentAmmo.reserve}
              </span>
            </div>
            {player.isReloading && (
              <span className="text-[10px] font-bold text-cyan-400 animate-pulse">
                RELOADING ({(player.reloadProgress * 100).toFixed(0)}%)
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
