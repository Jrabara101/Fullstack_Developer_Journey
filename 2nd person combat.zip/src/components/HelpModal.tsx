import React from 'react';
import { X, Eye, Video, Crosshair, Zap, Shield, Bomb, Flame } from 'lucide-react';

interface HelpModalProps {
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 font-mono select-none">
      <div className="w-full max-w-4xl bg-zinc-950 border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-zinc-900/90 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-amber-400" />
            <span className="text-xl font-black text-amber-400 tracking-wider">TACTICAL FIELD MANUAL: 2ND-PERSON CS</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-sm text-zinc-300">
          {/* Section 1: What is 2nd Person Perspective? */}
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
            <h3 className="text-base font-black text-white flex items-center gap-2 mb-2">
              <Eye className="w-5 h-5 text-red-400" />
              1. What is the "2nd Person" Perspective?
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              In classic 1st-person shooters, you see through your own character&apos;s eyes. In 3rd-person, you see over your own shoulder.
              In <b>2nd-Person Counter Strike</b>, you control your operative while viewing the battlefield <b>through the viewpoint of the enemy engaging you</b>,
              mounted <b>Surveillance CCTV security feeds</b>, or aerial <b>Spotter Drones</b>!
            </p>
            <div className="grid grid-cols-3 gap-3 mt-3 text-xs">
              <div className="p-2.5 bg-zinc-950 rounded-lg border border-red-500/30">
                <b className="text-red-400 block mb-1">🔴 Enemy POV Cam</b>
                <span>Camera sits inside the nearest enemy&apos;s optical reticle looking directly at you.</span>
              </div>
              <div className="p-2.5 bg-zinc-950 rounded-lg border border-cyan-500/30">
                <b className="text-cyan-400 block mb-1">📹 CCTV Cam Feed</b>
                <span>Mounted security cameras tracking zone choke points with scanlines and optical zoom.</span>
              </div>
              <div className="p-2.5 bg-zinc-950 rounded-lg border border-amber-500/30">
                <b className="text-amber-400 block mb-1">🛸 Spotter Drone</b>
                <span>Aerial tactical drone providing overhead tactical reconnaissance.</span>
              </div>
            </div>
          </div>

          {/* Section 2: Destructible Environments & Wallbanging */}
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
            <h3 className="text-base font-black text-white flex items-center gap-2 mb-2">
              <Flame className="w-5 h-5 text-amber-400" />
              2. Destructible Environments & Ballistics
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs text-zinc-400">
              <div>
                <b className="text-amber-300 block mb-1">📦 Wooden Crates & Doors</b>
                Bullets punch through with slight damage decay. Continuous fire or explosives will splinter crates into pieces, removing enemy cover!
              </div>
              <div>
                <b className="text-cyan-300 block mb-1">🪟 Tempered Glass Partitions</b>
                Instant 1-shot glass shatter that opens clean sightlines and reveals hidden ambush positions.
              </div>
              <div>
                <b className="text-red-400 block mb-1">🛢️ Explosive Red Barrels</b>
                Shooting red hazard barrels triggers a massive chain-reaction explosion that eliminates nearby hostiles and tears down barricades.
              </div>
              <div>
                <b className="text-emerald-400 block mb-1">🧱 Drywall Cubicles</b>
                High-penetration rifles (AK-47, AWP) can wallbang through drywall partitions to eliminate targets behind cover.
              </div>
            </div>
          </div>

          {/* Section 3: Controls Keymap */}
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
            <h3 className="text-base font-black text-white flex items-center gap-2 mb-3">
              <Crosshair className="w-5 h-5 text-emerald-400" />
              3. Operational Keybindings
            </h3>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">W / A / S / D</span> : Tactical Movement
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">Mouse Aim & Left Click</span> : Aim & Fire
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">R</span> : Reload Magazine
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">SPACE or C</span> : Switch 2nd-Person Cam
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">B</span> : Open Buy Menu Arsenal
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">E (Hold)</span> : Plant C4 / Defuse Bomb
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">G</span> : Throw Frag / Smoke Grenade
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">1 / 2 / 3</span> : Switch Primary / Secondary / Knife
              </div>
              <div className="p-2 bg-zinc-950 rounded border border-zinc-800">
                <span className="text-amber-400 font-bold">N / T</span> : Night Vision / Thermal Mode
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-zinc-900 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black rounded-xl text-xs transition-all shadow-md"
          >
            UNDERSTOOD (CLOSE)
          </button>
        </div>
      </div>
    </div>
  );
};
