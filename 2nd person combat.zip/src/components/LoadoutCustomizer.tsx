import React, { useState } from 'react';
import { GameEngine } from '../game/engine';
import { CHARACTERS } from '../game/characters';
import { WEAPONS, ATTACHMENTS, WEAPON_SKIN_PALETTES } from '../game/weapons';
import { LoadoutConfig, WeaponSkin, AttachmentType, Team } from '../types';
import { X, Shield, Zap, Crosshair, Sparkles, Check, Flame } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface LoadoutCustomizerProps {
  engine: GameEngine;
  currentLoadout: LoadoutConfig;
  onUpdateLoadout: (newLoadout: LoadoutConfig) => void;
  onClose: () => void;
}

export const LoadoutCustomizer: React.FC<LoadoutCustomizerProps> = ({
  engine,
  currentLoadout,
  onUpdateLoadout,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'OPERATIVES' | 'PRIMARY' | 'ATTACHMENTS' | 'SKINS'>('OPERATIVES');
  const [tempLoadout, setTempLoadout] = useState<LoadoutConfig>({ ...currentLoadout });
  const [selectedTeam, setSelectedTeam] = useState<Team>(engine.state.player.team);
  const [selectedCharId, setSelectedCharId] = useState<string>(engine.state.player.character.id);

  const teamCharacters = CHARACTERS.filter(c => c.team === selectedTeam);
  const primaryWeapons = Object.values(WEAPONS).filter(w => ['RIFLE', 'SMG', 'SNIPER', 'SHOTGUN'].includes(w.category));
  const activePrimary = WEAPONS[tempLoadout.primaryWeaponId] || WEAPONS.ak47;

  const handleToggleAttachment = (weaponId: string, attId: AttachmentType) => {
    const currentAtts = tempLoadout.attachments[weaponId] || [];
    let updated: AttachmentType[];
    if (currentAtts.includes(attId)) {
      updated = currentAtts.filter(a => a !== attId);
    } else {
      updated = [...currentAtts, attId];
    }
    const newConfig = {
      ...tempLoadout,
      attachments: {
        ...tempLoadout.attachments,
        [weaponId]: updated
      }
    };
    setTempLoadout(newConfig);
  };

  const handleSelectSkin = (skin: WeaponSkin) => {
    setTempLoadout({
      ...tempLoadout,
      skin
    });
  };

  const handleSaveAndApply = () => {
    onUpdateLoadout(tempLoadout);

    // Apply to engine player
    const player = engine.state.player;
    const newChar = CHARACTERS.find(c => c.id === selectedCharId);
    if (newChar) {
      player.character = newChar;
      player.team = newChar.team;
    }

    const newPrimary = WEAPONS[tempLoadout.primaryWeaponId] || WEAPONS.ak47;
    player.currentWeapon = newPrimary;
    player.ammo[newPrimary.id] = { mag: newPrimary.magazineSize, reserve: newPrimary.reserveAmmo };

    sound.playBuy();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 font-mono select-none">
      <div className="w-full max-w-5xl bg-zinc-950 border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-zinc-900/90 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <span className="text-xl font-black text-amber-400 tracking-wider">TACTICAL GUNSMITH & OPERATIVES</span>
            <div className="flex bg-zinc-800 p-1 rounded-xl gap-1">
              <button
                onClick={() => setSelectedTeam('CT')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  selectedTeam === 'CT' ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                COUNTER-TERRORISTS
              </button>
              <button
                onClick={() => setSelectedTeam('T')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  selectedTeam === 'T' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                TERRORISTS
              </button>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-800 bg-zinc-900/40 px-6 gap-3">
          {[
            { id: 'OPERATIVES', label: 'Operatives & Perks', icon: <Shield className="w-4 h-4" /> },
            { id: 'PRIMARY', label: 'Primary Arsenal', icon: <Crosshair className="w-4 h-4" /> },
            { id: 'ATTACHMENTS', label: 'Gunsmith Attachments', icon: <Zap className="w-4 h-4" /> },
            { id: 'SKINS', label: 'Weapon Skins & Camo', icon: <Sparkles className="w-4 h-4" /> }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 py-3 px-4 text-xs font-bold border-b-2 transition-all ${
                activeTab === tab.id
                  ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                  : 'border-transparent text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto flex-1 min-h-[380px]">
          {/* 1. OPERATIVES TAB */}
          {activeTab === 'OPERATIVES' && (
            <div className="grid grid-cols-2 gap-4">
              {teamCharacters.map(char => {
                const isSelected = selectedCharId === char.id;
                return (
                  <div
                    key={char.id}
                    onClick={() => setSelectedCharId(char.id)}
                    className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-amber-400 shadow-lg shadow-amber-500/15'
                        : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-lg font-black text-white block">{char.name}</span>
                          <span className="text-xs text-amber-400 font-bold">{char.callsign} • {char.role}</span>
                        </div>
                        {isSelected && (
                          <div className="w-6 h-6 rounded-full bg-amber-400 flex items-center justify-center text-zinc-950 font-black">
                            <Check className="w-4 h-4" />
                          </div>
                        )}
                      </div>

                      {/* Perk Highlight */}
                      <div className="mt-4 p-3 bg-zinc-950/80 border border-zinc-800 rounded-xl">
                        <span className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                          <Flame className="w-3.5 h-3.5" /> {char.perkName}
                        </span>
                        <p className="text-xs text-zinc-400 mt-1">
                          {char.perkDesc}
                        </p>
                      </div>

                      {/* Stats */}
                      <div className="grid grid-cols-3 gap-2 mt-4 text-[11px]">
                        <div className="bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/80">
                          <span className="text-zinc-400 block">Armor/HP</span>
                          <span className="text-white font-bold">{char.stats.armor} / {char.stats.health}</span>
                        </div>
                        <div className="bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/80">
                          <span className="text-zinc-400 block">Speed</span>
                          <span className="text-cyan-400 font-bold">{(char.stats.speed * 100).toFixed(0)}%</span>
                        </div>
                        <div className="bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/80">
                          <span className="text-zinc-400 block">Breach Dmg</span>
                          <span className="text-amber-400 font-bold">+{(char.stats.destructBonus * 100 - 100).toFixed(0)}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-zinc-800 flex justify-between items-center text-xs">
                      <span className="text-zinc-400">Team: {char.team}</span>
                      <span className={isSelected ? 'text-amber-400 font-bold' : 'text-zinc-500'}>
                        {isSelected ? 'ACTIVE OPERATIVE' : 'CLICK TO SELECT'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* 2. PRIMARY ARSENAL TAB */}
          {activeTab === 'PRIMARY' && (
            <div className="grid grid-cols-3 gap-4">
              {primaryWeapons.map(wep => {
                const isSelected = tempLoadout.primaryWeaponId === wep.id;
                return (
                  <div
                    key={wep.id}
                    onClick={() => setTempLoadout({ ...tempLoadout, primaryWeaponId: wep.id })}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-amber-400 shadow-md'
                        : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-white text-base">{wep.name}</span>
                        {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                      </div>
                      <span className="text-[10px] text-zinc-400 uppercase">{wep.category} • ${wep.price}</span>

                      <div className="grid grid-cols-2 gap-1.5 mt-3 text-[10px]">
                        <div>Damage: <b className="text-white">{wep.damage}</b></div>
                        <div>Rate: <b className="text-white">{wep.fireRate} rps</b></div>
                        <div>Mag: <b className="text-white">{wep.magazineSize}</b></div>
                        <div>Penetration: <b className="text-amber-400">{wep.penetration >= 2.5 ? 'Heavy' : 'Normal'}</b></div>
                      </div>
                    </div>

                    <span className="mt-3 text-[11px] font-bold text-amber-400">
                      {isSelected ? 'SELECTED PRIMARY' : 'SELECT WEAPON'}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* 3. ATTACHMENTS TAB */}
          {activeTab === 'ATTACHMENTS' && (
            <div>
              <div className="flex items-center justify-between p-4 bg-zinc-900/90 border border-zinc-800 rounded-xl mb-6">
                <div>
                  <span className="text-xs text-zinc-400 uppercase">Modifying Primary Weapon:</span>
                  <span className="text-lg font-black text-white ml-2">{activePrimary.name}</span>
                </div>
                <span className="text-xs text-amber-400 font-bold">
                  {tempLoadout.attachments[activePrimary.id]?.length || 0} Attachments Mounted
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {Object.values(ATTACHMENTS).map(att => {
                  const isEquipped = (tempLoadout.attachments[activePrimary.id] || []).includes(att.id);
                  const isSupported = activePrimary.supportedAttachments.includes(att.id);

                  return (
                    <div
                      key={att.id}
                      onClick={() => isSupported && handleToggleAttachment(activePrimary.id, att.id)}
                      className={`p-4 rounded-xl border-2 transition-all flex flex-col justify-between ${
                        !isSupported
                          ? 'opacity-30 bg-zinc-950 border-zinc-900 cursor-not-allowed'
                          : (isEquipped
                            ? 'bg-zinc-900 border-emerald-400 shadow-md cursor-pointer'
                            : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 cursor-pointer')
                      }`}
                    >
                      <div>
                        <div className="flex justify-between items-start">
                          <span className="font-bold text-white text-base">{att.name}</span>
                          {isEquipped && <Check className="w-4 h-4 text-emerald-400" />}
                        </div>
                        <p className="text-xs text-zinc-400 mt-1">{att.description}</p>

                        <div className="grid grid-cols-2 gap-2 mt-3 text-[10px]">
                          {att.damageMod !== 0 && (
                            <div className={att.damageMod > 0 ? 'text-emerald-400' : 'text-red-400'}>
                              Damage: {att.damageMod > 0 ? '+' : ''}{(att.damageMod * 100).toFixed(0)}%
                            </div>
                          )}
                          {att.accuracyMod !== 0 && (
                            <div className={att.accuracyMod > 0 ? 'text-emerald-400' : 'text-red-400'}>
                              Accuracy: +{(att.accuracyMod * 100).toFixed(0)}%
                            </div>
                          )}
                          {att.recoilMod !== 0 && (
                            <div className={att.recoilMod < 0 ? 'text-emerald-400' : 'text-red-400'}>
                              Recoil: {(att.recoilMod * 100).toFixed(0)}%
                            </div>
                          )}
                          {att.capacityMod !== 0 && (
                            <div className="text-emerald-400">
                              Mag Capacity: +{(att.capacityMod * 100).toFixed(0)}%
                            </div>
                          )}
                        </div>
                      </div>

                      <span className="mt-3 text-[11px] font-bold">
                        {!isSupported ? 'NOT COMPATIBLE' : (isEquipped ? '✓ MOUNTED' : '+ MOUNT ATTACHMENT')}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 4. WEAPON SKINS TAB */}
          {activeTab === 'SKINS' && (
            <div className="grid grid-cols-3 gap-4">
              {(Object.entries(WEAPON_SKIN_PALETTES) as [WeaponSkin, typeof WEAPON_SKIN_PALETTES[WeaponSkin]][]).map(([skinKey, skinData]) => {
                const isSelected = tempLoadout.skin === skinKey;
                return (
                  <div
                    key={skinKey}
                    onClick={() => handleSelectSkin(skinKey)}
                    className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-amber-400 shadow-xl'
                        : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-white text-base">{skinData.name}</span>
                        {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                      </div>
                      <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mt-0.5">
                        Rarity: {skinData.rarity}
                      </span>

                      {/* Skin Color Swatch Preview */}
                      <div className="flex items-center gap-2 mt-4 p-3 bg-zinc-950 rounded-xl border border-zinc-800">
                        <div
                          className="w-8 h-8 rounded-lg border border-white/20 shadow-md"
                          style={{ backgroundColor: skinData.primary }}
                        />
                        <div
                          className="w-8 h-8 rounded-lg border border-white/20 shadow-md"
                          style={{ backgroundColor: skinData.accent }}
                        />
                        <span className="text-[11px] text-zinc-300 ml-2">Camo Coating</span>
                      </div>
                    </div>

                    <span className="mt-4 text-[11px] font-bold text-amber-400">
                      {isSelected ? 'EQUIPPED SKIN' : 'APPLY TO WEAPONS'}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-zinc-900 border-t border-zinc-800 flex justify-between items-center">
          <span className="text-xs text-zinc-400">All perk and weapon modifications apply immediately</span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl text-xs transition-all"
            >
              CANCEL
            </button>
            <button
              onClick={handleSaveAndApply}
              className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black rounded-xl text-xs shadow-lg shadow-amber-500/20 transition-all"
            >
              APPLY LOADOUT & DEPLOY
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
