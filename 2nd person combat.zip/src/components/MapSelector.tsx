import React, { useState } from 'react';
import { MAPS } from '../game/maps';
import { GameMode, MapData } from '../types';
import { X, Shield, Bomb, Sparkles, Target, Crosshair, Check } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface MapSelectorProps {
  currentMapId: string;
  onSelectMapAndMode: (map: MapData, mode: GameMode) => void;
  onClose: () => void;
}

export const MapSelector: React.FC<MapSelectorProps> = ({
  currentMapId,
  onSelectMapAndMode,
  onClose
}) => {
  const [selectedMapId, setSelectedMapId] = useState<string>(currentMapId);
  const [selectedMode, setSelectedMode] = useState<GameMode>('DEFUSAL');

  const modes: { id: GameMode; title: string; desc: string; icon: React.ReactNode }[] = [
    {
      id: 'DEFUSAL',
      title: 'Bomb Defusal (5v5)',
      desc: 'Plant C4 at Bomb Site A or B as Terrorists. CTs must defuse the bomb or neutralize hostiles.',
      icon: <Bomb className="w-4 h-4 text-red-400" />
    },
    {
      id: 'DEATHMATCH',
      title: 'Team Deathmatch',
      desc: 'Fast-paced continuous combat with instant weapon buy and highest frag scoreboard score.',
      icon: <Crosshair className="w-4 h-4 text-amber-400" />
    },
    {
      id: 'SNIPER_DUEL',
      title: '2nd Person Sniper Duel',
      desc: 'AWP only. Read your opponent through their own camera lens to pre-aim and fire first!',
      icon: <Target className="w-4 h-4 text-cyan-400" />
    },
    {
      id: 'TRAINING',
      title: 'CQB Range & Ballistics',
      desc: 'Target dummies, infinite ammo, test all breakable wall penetrations and chain explosions.',
      icon: <Sparkles className="w-4 h-4 text-emerald-400" />
    }
  ];

  const handleConfirm = () => {
    const chosenMap = MAPS.find(m => m.id === selectedMapId) || MAPS[0];
    sound.playBuy();
    onSelectMapAndMode(chosenMap, selectedMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 font-mono select-none">
      <div className="w-full max-w-5xl bg-zinc-950 border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-zinc-900/90 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-amber-400" />
            <span className="text-xl font-black text-amber-400 tracking-wider">DEPLOYMENT DISPATCH: MAP & MODE</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* 1. Game Mode Selector */}
          <div>
            <span className="text-xs text-zinc-400 uppercase font-bold tracking-wider block mb-3">1. Select Operation Mode</span>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {modes.map(mode => {
                const isSelected = selectedMode === mode.id;
                return (
                  <div
                    key={mode.id}
                    onClick={() => setSelectedMode(mode.id)}
                    className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-amber-400 shadow-md'
                        : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        {mode.icon}
                        {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                      </div>
                      <span className="text-sm font-bold text-white block mt-2">{mode.title}</span>
                      <p className="text-[11px] text-zinc-400 mt-1 line-clamp-2">{mode.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. Map Selector */}
          <div>
            <span className="text-xs text-zinc-400 uppercase font-bold tracking-wider block mb-3">2. Select Combat Zone (Destructible Maps)</span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {MAPS.map(m => {
                const isSelected = selectedMapId === m.id;
                return (
                  <div
                    key={m.id}
                    onClick={() => setSelectedMapId(m.id)}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-amber-400 shadow-xl shadow-amber-500/10'
                        : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-start">
                        <span className="font-black text-white text-base">{m.name}</span>
                        {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                      </div>
                      <span className="text-[10px] text-amber-400 font-bold uppercase">{m.codeName}</span>

                      {/* Map Features Pill Tag */}
                      <div className="flex flex-wrap gap-1.5 mt-3">
                        <span className="px-2 py-0.5 bg-zinc-800 text-zinc-300 rounded text-[9px] font-bold">
                          {m.destructibles.length} Destructibles
                        </span>
                        <span className="px-2 py-0.5 bg-zinc-800 text-cyan-300 rounded text-[9px] font-bold">
                          {m.cctvCameras.length} CCTV Feeds
                        </span>
                        <span className="px-2 py-0.5 bg-zinc-800 text-red-300 rounded text-[9px] font-bold">
                          {m.bombSites.length} Sites
                        </span>
                      </div>

                      <p className="text-xs text-zinc-400 mt-2 line-clamp-2">
                        {m.description}
                      </p>
                    </div>

                    <span className="mt-4 text-[11px] font-bold text-amber-400">
                      {isSelected ? 'SELECTED MAP' : 'CLICK TO CHOOSE'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-zinc-900 border-t border-zinc-800 flex justify-between items-center">
          <span className="text-xs text-zinc-400">Tactical environmental objects reset automatically per round</span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl text-xs transition-all"
            >
              CANCEL
            </button>
            <button
              onClick={handleConfirm}
              className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black rounded-xl text-xs shadow-lg shadow-amber-500/20 transition-all"
            >
              DEPLOY MISSION
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
