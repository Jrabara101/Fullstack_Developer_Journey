import { CharacterDef } from '../types';

export const CHARACTERS: CharacterDef[] = [
  // Counter-Terrorists
  {
    id: 'ct_sas',
    name: 'Ghost Operator',
    team: 'CT',
    callsign: 'SAS Bravo-6',
    role: 'Stealth Infiltrator',
    avatarColor: '#1e3a8a',
    accentColor: '#38bdf8',
    perkName: 'Silent Footsteps & Smoke Mastery',
    perkDesc: 'Movement sound radius reduced by 40%. Smoke grenades bloom 25% wider.',
    stats: {
      health: 100,
      armor: 100,
      speed: 1.05,
      recoilControl: 1.1,
      destructBonus: 1.0
    }
  },
  {
    id: 'ct_fbi',
    name: 'Juggernaut SWAT',
    team: 'CT',
    callsign: 'SWAT Heavy',
    role: 'Point Man / Anchor',
    avatarColor: '#1e293b',
    accentColor: '#60a5fa',
    perkName: 'Reinforced Kevlar Plate',
    perkDesc: '+25 Bonus armor capacity and 15% explosive damage reduction.',
    stats: {
      health: 110,
      armor: 125,
      speed: 0.95,
      recoilControl: 1.15,
      destructBonus: 1.1
    }
  },
  {
    id: 'ct_gign',
    name: 'Ravage Breacher',
    team: 'CT',
    callsign: 'GIGN Breacher',
    role: 'Demolition Specialist',
    avatarColor: '#0f172a',
    accentColor: '#818cf8',
    perkName: 'Breach Overpressure',
    perkDesc: '+60% destructive damage against wooden crates, glass walls, and barricades.',
    stats: {
      health: 100,
      armor: 100,
      speed: 1.0,
      recoilControl: 1.0,
      destructBonus: 1.6
    }
  },
  {
    id: 'ct_gsg9',
    name: 'Cipher Recon',
    team: 'CT',
    callsign: 'GSG-9 Specialist',
    role: 'Surveillance / Intel',
    avatarColor: '#172554',
    accentColor: '#22d3ee',
    perkName: 'Surveillance Uplink',
    perkDesc: 'CCTV cameras and Spotter drones reveal enemy footsteps through thin walls.',
    stats: {
      health: 100,
      armor: 100,
      speed: 1.08,
      recoilControl: 1.05,
      destructBonus: 1.0
    }
  },

  // Terrorists
  {
    id: 't_phoenix',
    name: 'Viper Assassin',
    team: 'T',
    callsign: 'Phoenix Vanguard',
    role: 'Entry Fragger',
    avatarColor: '#7f1d1d',
    accentColor: '#f87171',
    perkName: 'Adrenaline Rush',
    perkDesc: '+12% Sprint velocity and 30% faster weapon switch speed.',
    stats: {
      health: 100,
      armor: 100,
      speed: 1.12,
      recoilControl: 1.05,
      destructBonus: 1.05
    }
  },
  {
    id: 't_guerilla',
    name: 'Warlord Saboteur',
    team: 'T',
    callsign: 'Elite Mercenary',
    role: 'Heavy Explosives',
    avatarColor: '#78350f',
    accentColor: '#fbbf24',
    perkName: 'Shrapnel Satchel',
    perkDesc: 'Carries 1 extra HE Frag Grenade. Explosions trigger immediate barrel chain-reactions.',
    stats: {
      health: 105,
      armor: 100,
      speed: 1.0,
      recoilControl: 0.95,
      destructBonus: 1.45
    }
  },
  {
    id: 't_cyber',
    name: 'Glitch Hacker',
    team: 'T',
    callsign: 'Anarchist Grid',
    role: 'Electronic Warfare',
    avatarColor: '#4c0519',
    accentColor: '#f43f5e',
    perkName: 'Camera Jammer',
    perkDesc: 'Temporarily disables CCTV cameras within 300 units; confuses enemy 2nd-person HUD.',
    stats: {
      health: 100,
      armor: 100,
      speed: 1.06,
      recoilControl: 1.08,
      destructBonus: 1.1
    }
  },
  {
    id: 't_separatist',
    name: 'Deadshot Marksman',
    team: 'T',
    callsign: 'Ghost-Eye',
    role: 'Long Range Sniper',
    avatarColor: '#365314',
    accentColor: '#a3e635',
    perkName: 'Tungsten Core Rounds',
    perkDesc: 'Increases bullet penetration power on all rifles and snipers by +35%.',
    stats: {
      health: 100,
      armor: 100,
      speed: 1.02,
      recoilControl: 1.2,
      destructBonus: 1.3
    }
  }
];
