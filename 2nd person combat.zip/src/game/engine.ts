import { 
  CombatEntity, MapData, Projectile, Particle, BulletDecal, SmokeCloud, GrenadeEntity, 
  BombState, RoundState, KillFeedItem, CameraState, LoadoutConfig,
  Vector2D, DestructibleObject, Team
} from '../types';
import { WEAPONS, ATTACHMENTS } from './weapons';
import { CHARACTERS } from './characters';
import { sound } from '../audio/soundEngine';

export interface GameEngineState {
  player: CombatEntity;
  bots: CombatEntity[];
  map: MapData;
  projectiles: Projectile[];
  grenades: GrenadeEntity[];
  smokeClouds: SmokeCloud[];
  particles: Particle[];
  bulletDecals: BulletDecal[];
  bomb: BombState;
  round: RoundState;
  killFeed: KillFeedItem[];
  camera: CameraState;
  activeDestructibles: DestructibleObject[];
}

export class GameEngine {
  public state: GameEngineState;
  private lastTime: number = performance.now();
  private keys: Record<string, boolean> = {};
  private mousePos: Vector2D = { x: 0, y: 0 };
  private isMouseDown: boolean = false;
  private onKillFeedUpdate?: (feed: KillFeedItem[]) => void;
  private onRoundEnd?: (winner: Team, reason: string) => void;

  constructor(
    initialMap: MapData,
    playerTeam: Team,
    playerCharacterId: string,
    playerLoadout: LoadoutConfig,
    onKillFeedUpdate?: (feed: KillFeedItem[]) => void,
    onRoundEnd?: (winner: Team, reason: string) => void
  ) {
    this.onKillFeedUpdate = onKillFeedUpdate;
    this.onRoundEnd = onRoundEnd;

    const charDef = CHARACTERS.find(c => c.id === playerCharacterId) || CHARACTERS[0];
    const primaryWep = WEAPONS[playerLoadout.primaryWeaponId] || WEAPONS.ak47;
    const secWep = WEAPONS[playerLoadout.secondaryWeaponId] || WEAPONS.usp;

    const playerSpawn = playerTeam === 'CT' ? initialMap.ctSpawns[0] : initialMap.tSpawns[0];

    const playerEntity: CombatEntity = {
      id: 'player',
      name: 'You (Operative)',
      team: playerTeam,
      isPlayer: true,
      character: charDef,
      x: playerSpawn.x,
      y: playerSpawn.y,
      angle: playerTeam === 'CT' ? Math.PI * 0.5 : -Math.PI * 0.5,
      targetAngle: playerTeam === 'CT' ? Math.PI * 0.5 : -Math.PI * 0.5,
      vx: 0,
      vy: 0,
      health: charDef.stats.health,
      maxHealth: charDef.stats.health,
      armor: playerLoadout.armor ? (charDef.stats.armor) : 0,
      hasHelmet: playerLoadout.helmet,
      hasDefuseKit: playerTeam === 'CT' && playerLoadout.defuseKit,
      hasC4: playerTeam === 'T',
      isPlanting: false,
      plantProgress: 0,
      isDefusing: false,
      defuseProgress: 0,
      currentWeapon: primaryWep,
      secondaryWeapon: secWep,
      grenades: ['HE', 'SMOKE', 'FLASH'],
      knife: WEAPONS.knife,
      ammo: {
        [primaryWep.id]: { mag: primaryWep.magazineSize, reserve: primaryWep.reserveAmmo },
        [secWep.id]: { mag: secWep.magazineSize, reserve: secWep.reserveAmmo }
      },
      isReloading: false,
      reloadProgress: 0,
      isShooting: false,
      lastShotTime: 0,
      kills: 0,
      deaths: 0,
      score: 0,
      money: 800,
      mvps: 0,
      isDead: false,
      respawnTimer: 0,
      flashDuration: 0,
      recoilOffset: { x: 0, y: 0 },
      state: 'IDLE',
      targetEnemyId: null,
      lookAtTarget: { x: 0, y: 0 }
    };

    const bots = this.generateBots(initialMap, playerTeam);

    this.state = {
      player: playerEntity,
      bots,
      map: initialMap,
      projectiles: [],
      grenades: [],
      smokeClouds: [],
      particles: [],
      bulletDecals: [],
      bomb: {
        isPlanted: false,
        isDefused: false,
        isExploded: false,
        x: 0,
        y: 0,
        site: null,
        timer: 40,
        planterId: null,
        defuserId: null
      },
      round: {
        roundNumber: 1,
        ctScore: 0,
        tScore: 0,
        maxRounds: 15,
        phase: 'LIVE',
        phaseTimer: 115, // 1m 55s
        winnerTeam: null,
        winReason: ''
      },
      killFeed: [],
      camera: {
        perspective: 'ENEMY_POV',
        sourceEntityId: null,
        sourceCCTVId: null,
        x: playerSpawn.x,
        y: playerSpawn.y,
        zoom: 1.0,
        targetZoom: 1.0,
        shake: 0,
        scanlineIntensity: 0.35,
        nightVision: false,
        thermalVision: false,
        lockOnTargetId: null
      },
      activeDestructibles: JSON.parse(JSON.stringify(initialMap.destructibles))
    };
  }

  public setInput(keys: Record<string, boolean>, mousePos: Vector2D, isMouseDown: boolean) {
    this.keys = keys;
    this.mousePos = mousePos;
    this.isMouseDown = isMouseDown;
  }

  public toggleCameraPerspective(forcedPerspective?: CameraState['perspective']) {
    const perspectives: CameraState['perspective'][] = [
      'ENEMY_POV',
      'SURVEILLANCE_CCTV',
      'SPOTTER_DRONE',
      'SQUAD_WINGMAN',
      'TACTICAL_ORBIT'
    ];
    if (forcedPerspective) {
      this.state.camera.perspective = forcedPerspective;
    } else {
      const idx = perspectives.indexOf(this.state.camera.perspective);
      this.state.camera.perspective = perspectives[(idx + 1) % perspectives.length];
    }
    sound.playCameraSwitch();
    this.triggerGlitchEffect();
  }

  public triggerGlitchEffect() {
    this.state.camera.scanlineIntensity = 0.85;
    this.state.camera.shake = 8;
  }

  public toggleVisionMode(mode: 'NIGHT' | 'THERMAL') {
    if (mode === 'NIGHT') {
      this.state.camera.nightVision = !this.state.camera.nightVision;
      if (this.state.camera.nightVision) this.state.camera.thermalVision = false;
    } else {
      this.state.camera.thermalVision = !this.state.camera.thermalVision;
      if (this.state.camera.thermalVision) this.state.camera.nightVision = false;
    }
    sound.playCameraSwitch();
  }

  private generateBots(map: MapData, playerTeam: Team): CombatEntity[] {
    const bots: CombatEntity[] = [];
    const botCountCT = playerTeam === 'CT' ? 3 : 4;
    const botCountT = playerTeam === 'T' ? 3 : 4;

    const botNamesCT = ['Vanguard-Alpha', 'Specter-Echo', 'Aegis-One', 'Delta-Recon'];
    const botNamesT = ['Havoc-Bane', 'Shadow-Kobra', 'Dagger-Nine', 'Anarch-Zero'];

    // Spawn CT Bots
    for (let i = 0; i < botCountCT; i++) {
      const spawn = map.ctSpawns[(i + 1) % map.ctSpawns.length] || map.ctSpawns[0];
      const charDef = CHARACTERS.filter(c => c.team === 'CT')[i % 4] || CHARACTERS[0];
      const weapon = i % 2 === 0 ? WEAPONS.m4a1s : WEAPONS.famas;
      bots.push({
        id: `bot_ct_${i}`,
        name: botNamesCT[i % botNamesCT.length],
        team: 'CT',
        isPlayer: false,
        character: charDef,
        x: spawn.x + (Math.random() * 40 - 20),
        y: spawn.y + (Math.random() * 40 - 20),
        angle: Math.PI * 0.5,
        targetAngle: Math.PI * 0.5,
        vx: 0,
        vy: 0,
        health: 100,
        maxHealth: 100,
        armor: 100,
        hasHelmet: true,
        hasDefuseKit: true,
        hasC4: false,
        isPlanting: false,
        plantProgress: 0,
        isDefusing: false,
        defuseProgress: 0,
        currentWeapon: weapon,
        secondaryWeapon: WEAPONS.usp,
        grenades: ['HE', 'SMOKE'],
        knife: WEAPONS.knife,
        ammo: {
          [weapon.id]: { mag: weapon.magazineSize, reserve: weapon.reserveAmmo },
          [WEAPONS.usp.id]: { mag: WEAPONS.usp.magazineSize, reserve: WEAPONS.usp.reserveAmmo }
        },
        isReloading: false,
        reloadProgress: 0,
        isShooting: false,
        lastShotTime: 0,
        kills: 0,
        deaths: 0,
        score: 0,
        money: 800,
        mvps: 0,
        isDead: false,
        respawnTimer: 0,
        flashDuration: 0,
        recoilOffset: { x: 0, y: 0 },
        state: 'PATROL',
        targetEnemyId: null,
        lookAtTarget: { x: spawn.x, y: spawn.y + 100 }
      });
    }

    // Spawn T Bots
    for (let i = 0; i < botCountT; i++) {
      const spawn = map.tSpawns[(i + 1) % map.tSpawns.length] || map.tSpawns[0];
      const charDef = CHARACTERS.filter(c => c.team === 'T')[i % 4] || CHARACTERS[4];
      const weapon = i === 0 ? WEAPONS.ak47 : (i === 1 ? WEAPONS.p90 : (i === 2 ? WEAPONS.deagle : WEAPONS.ak47));
      bots.push({
        id: `bot_t_${i}`,
        name: botNamesT[i % botNamesT.length],
        team: 'T',
        isPlayer: false,
        character: charDef,
        x: spawn.x + (Math.random() * 40 - 20),
        y: spawn.y + (Math.random() * 40 - 20),
        angle: -Math.PI * 0.5,
        targetAngle: -Math.PI * 0.5,
        vx: 0,
        vy: 0,
        health: 100,
        maxHealth: 100,
        armor: 100,
        hasHelmet: true,
        hasDefuseKit: false,
        hasC4: i === 0 && playerTeam === 'CT', // Give C4 to first bot if player is CT
        isPlanting: false,
        plantProgress: 0,
        isDefusing: false,
        defuseProgress: 0,
        currentWeapon: weapon,
        secondaryWeapon: WEAPONS.glock,
        grenades: ['HE', 'SMOKE'],
        knife: WEAPONS.knife,
        ammo: {
          [weapon.id]: { mag: weapon.magazineSize, reserve: weapon.reserveAmmo },
          [WEAPONS.glock.id]: { mag: WEAPONS.glock.magazineSize, reserve: WEAPONS.glock.reserveAmmo }
        },
        isReloading: false,
        reloadProgress: 0,
        isShooting: false,
        lastShotTime: 0,
        kills: 0,
        deaths: 0,
        score: 0,
        money: 800,
        mvps: 0,
        isDead: false,
        respawnTimer: 0,
        flashDuration: 0,
        recoilOffset: { x: 0, y: 0 },
        state: 'PATROL',
        targetEnemyId: null,
        lookAtTarget: { x: spawn.x, y: spawn.y - 100 }
      });
    }

    return bots;
  }

  public update(): void {
    const now = performance.now();
    const dt = Math.min((now - this.lastTime) / 1000, 0.05); // Cap delta time
    this.lastTime = now;

    this.updateRoundTimer(dt);
    this.updatePlayer(dt);
    this.updateBots(dt);
    this.updateProjectiles(dt);
    this.updateGrenades(dt);
    this.updateSmokeClouds(dt);
    this.updateParticles(dt);
    this.updateBomb(dt);
    this.update2ndPersonCamera(dt);

    // Camera shake decay
    if (this.state.camera.shake > 0) {
      this.state.camera.shake = Math.max(0, this.state.camera.shake - dt * 15);
    }
    // Scanline intensity return
    if (this.state.camera.scanlineIntensity > 0.35) {
      this.state.camera.scanlineIntensity -= dt * 0.5;
    }
  }

  private updateRoundTimer(dt: number) {
    if (this.state.round.phase === 'LIVE') {
      this.state.round.phaseTimer -= dt;

      // Check time out win condition
      if (this.state.round.phaseTimer <= 0) {
        if (this.state.bomb.isPlanted) {
          // If bomb planted, timer doesn't end round until bomb explodes or defused
        } else {
          this.endRound('CT', 'Time Ran Out - Counter-Terrorists Win');
        }
      }

      // Check team elimination
      const ctAlive = [this.state.player, ...this.state.bots].filter(e => e.team === 'CT' && !e.isDead);
      const tAlive = [this.state.player, ...this.state.bots].filter(e => e.team === 'T' && !e.isDead);

      if (ctAlive.length === 0) {
        this.endRound('T', 'Counter-Terrorists Eliminated - Terrorists Win');
      } else if (tAlive.length === 0 && !this.state.bomb.isPlanted) {
        this.endRound('CT', 'Terrorists Eliminated - Counter-Terrorists Win');
      }
    } else if (this.state.round.phase === 'ROUND_OVER') {
      this.state.round.phaseTimer -= dt;
      if (this.state.round.phaseTimer <= 0) {
        this.startNextRound();
      }
    }
  }

  public endRound(winner: Team, reason: string) {
    if (this.state.round.phase === 'ROUND_OVER' || this.state.round.phase === 'MATCH_OVER') return;
    this.state.round.phase = 'ROUND_OVER';
    this.state.round.phaseTimer = 5.0; // 5s celebration freeze
    this.state.round.winnerTeam = winner;
    this.state.round.winReason = reason;

    if (winner === 'CT') {
      this.state.round.ctScore++;
      sound.playRadio('Counter-Terrorists Win');
    } else {
      this.state.round.tScore++;
      sound.playRadio('Terrorists Win');
    }

    if (this.onRoundEnd) {
      this.onRoundEnd(winner, reason);
    }
  }

  public startNextRound() {
    this.state.round.roundNumber++;
    this.state.round.phase = 'LIVE';
    this.state.round.phaseTimer = 115;
    this.state.round.winnerTeam = null;
    this.state.round.winReason = '';

    // Reset Bomb
    this.state.bomb = {
      isPlanted: false,
      isDefused: false,
      isExploded: false,
      x: 0,
      y: 0,
      site: null,
      timer: 40,
      planterId: null,
      defuserId: null
    };

    // Reset Destructibles
    this.state.activeDestructibles = JSON.parse(JSON.stringify(this.state.map.destructibles));
    this.state.projectiles = [];
    this.state.grenades = [];
    this.state.smokeClouds = [];

    // Respawn Player & Bots
    const p = this.state.player;
    const pSpawn = p.team === 'CT' ? this.state.map.ctSpawns[0] : this.state.map.tSpawns[0];
    p.x = pSpawn.x;
    p.y = pSpawn.y;
    p.health = p.character.stats.health;
    p.armor = p.character.stats.armor;
    p.isDead = false;
    p.isPlanting = false;
    p.isDefusing = false;
    p.isReloading = false;
    p.flashDuration = 0;
    p.hasC4 = p.team === 'T';
    
    // Replenish ammo
    p.ammo[p.currentWeapon.id] = { mag: p.currentWeapon.magazineSize, reserve: p.currentWeapon.reserveAmmo };
    p.ammo[p.secondaryWeapon.id] = { mag: p.secondaryWeapon.magazineSize, reserve: p.secondaryWeapon.reserveAmmo };
    p.money += 3250;

    // Reset Bots
    this.state.bots = this.generateBots(this.state.map, p.team);
  }

  private updatePlayer(dt: number) {
    const p = this.state.player;
    if (p.isDead) return;

    // Flashbang decay
    if (p.flashDuration > 0) {
      p.flashDuration = Math.max(0, p.flashDuration - dt);
    }

    // Movement WASD
    let moveX = 0;
    let moveY = 0;
    if (this.keys['KeyW'] || this.keys['ArrowUp']) moveY -= 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) moveY += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) moveX -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) moveX += 1;

    const baseSpeed = 220 * p.character.stats.speed;
    if (moveX !== 0 || moveY !== 0) {
      const len = Math.hypot(moveX, moveY);
      p.vx = (moveX / len) * baseSpeed;
      p.vy = (moveY / len) * baseSpeed;

      // Footstep sound throttle
      if (Math.random() < 0.05) {
        sound.playFootstep();
      }
    } else {
      p.vx = 0;
      p.vy = 0;
    }

    // Apply movement with wall and destructible collisions
    this.applyEntityMovement(p, dt);

    // Aiming towards mouse in world coordinates
    const targetAngle = Math.atan2(this.mousePos.y - p.y, this.mousePos.x - p.x);
    p.angle = targetAngle;

    // Shooting
    if (this.isMouseDown && !p.isReloading && !p.isPlanting && !p.isDefusing) {
      this.fireWeapon(p);
    }

    // Reloading
    if (this.keys['KeyR'] && !p.isReloading) {
      this.reloadWeapon(p);
    }

    // Planting / Defusing with 'KeyE'
    if (this.keys['KeyE']) {
      this.handlePlayerObjective(p, dt);
    } else {
      p.isPlanting = false;
      p.plantProgress = 0;
      p.isDefusing = false;
      p.defuseProgress = 0;
    }

    // Grenade throw (G or 4 key)
    if (this.keys['KeyG'] && p.grenades.length > 0) {
      this.throwGrenade(p);
      this.keys['KeyG'] = false; // Trigger once
    }

    // Weapon swap (1, 2, 3)
    if (this.keys['Digit1']) {
      // Primary
      p.currentWeapon = WEAPONS[this.state.player.currentWeapon.id] || WEAPONS.ak47;
      p.isReloading = false;
    } else if (this.keys['Digit2']) {
      // Secondary
      p.currentWeapon = p.secondaryWeapon;
      p.isReloading = false;
    } else if (this.keys['Digit3']) {
      // Knife
      p.currentWeapon = p.knife;
      p.isReloading = false;
    }

    // Reload progress
    if (p.isReloading) {
      p.reloadProgress += dt / p.currentWeapon.reloadTime;
      if (p.reloadProgress >= 1.0) {
        p.isReloading = false;
        p.reloadProgress = 0;
        const currentAmmo = p.ammo[p.currentWeapon.id];
        if (currentAmmo) {
          const needed = p.currentWeapon.magazineSize - currentAmmo.mag;
          const transfer = Math.min(needed, currentAmmo.reserve);
          currentAmmo.mag += transfer;
          currentAmmo.reserve -= transfer;
        }
      }
    }
  }

  private handlePlayerObjective(p: CombatEntity, dt: number) {
    // Check if on bomb site for planting
    if (p.team === 'T' && p.hasC4 && !this.state.bomb.isPlanted) {
      const nearSite = this.state.map.bombSites.find(site => Math.hypot(p.x - site.x, p.y - site.y) < site.radius);
      if (nearSite) {
        p.isPlanting = true;
        p.plantProgress += dt / 3.0; // 3 seconds plant time
        if (p.plantProgress >= 1.0) {
          p.isPlanting = false;
          p.hasC4 = false;
          this.state.bomb = {
            isPlanted: true,
            isDefused: false,
            isExploded: false,
            x: p.x,
            y: p.y,
            site: nearSite.id,
            timer: 40,
            planterId: p.id,
            defuserId: null
          };
          sound.playRadio('The bomb has been planted');
          sound.playC4Beep(1.0);
        }
        return;
      }
    }

    // Check if near planted bomb for defusing
    if (p.team === 'CT' && this.state.bomb.isPlanted && !this.state.bomb.isDefused) {
      const dist = Math.hypot(p.x - this.state.bomb.x, p.y - this.state.bomb.y);
      if (dist < 80) {
        p.isDefusing = true;
        const defuseTime = p.hasDefuseKit ? 5.0 : 10.0;
        p.defuseProgress += dt / defuseTime;
        if (p.defuseProgress >= 1.0) {
          p.isDefusing = false;
          this.state.bomb.isDefused = true;
          this.endRound('CT', 'Bomb Defused - Counter-Terrorists Win');
          sound.playRadio('Bomb has been defused');
        }
      }
    }
  }

  private updateBots(dt: number) {
    const allEntities = [this.state.player, ...this.state.bots];

    for (const bot of this.state.bots) {
      if (bot.isDead) continue;

      if (bot.flashDuration > 0) {
        bot.flashDuration = Math.max(0, bot.flashDuration - dt);
      }

      // Find nearest living enemy
      const enemies = allEntities.filter(e => e.team !== bot.team && !e.isDead);
      let nearestEnemy: CombatEntity | null = null;
      let minDist = 9999;

      for (const enemy of enemies) {
        const d = Math.hypot(enemy.x - bot.x, enemy.y - bot.y);
        if (d < minDist) {
          minDist = d;
          nearestEnemy = enemy;
        }
      }

      // Bot tactical behavior
      if (nearestEnemy && minDist < 850 && this.hasLineOfSight(bot, nearestEnemy)) {
        bot.state = 'ENGAGING';
        bot.targetEnemyId = nearestEnemy.id;

        // Turn towards enemy with slight inaccuracy
        const aimAngle = Math.atan2(nearestEnemy.y - bot.y, nearestEnemy.x - bot.x);
        bot.angle = aimAngle + (Math.random() * 0.08 - 0.04);

        // Strafe while engaging
        if (minDist > 250) {
          bot.vx = Math.cos(bot.angle) * 160;
          bot.vy = Math.sin(bot.angle) * 160;
        } else {
          // Strafe sideways
          const strafeAngle = bot.angle + Math.PI * 0.5;
          bot.vx = Math.cos(strafeAngle) * 120;
          bot.vy = Math.sin(strafeAngle) * 120;
        }

        // Fire burst
        if (!bot.isReloading && Math.random() < 0.35) {
          this.fireWeapon(bot);
        }
      } else {
        // Objective / Patrol behavior
        if (bot.team === 'T' && bot.hasC4 && !this.state.bomb.isPlanted) {
          // Move to Site A
          const site = this.state.map.bombSites[0];
          const dist = Math.hypot(site.x - bot.x, site.y - bot.y);
          if (dist > 40) {
            const angle = Math.atan2(site.y - bot.y, site.x - bot.x);
            bot.angle = angle;
            bot.vx = Math.cos(angle) * 180;
            bot.vy = Math.sin(angle) * 180;
          } else {
            // Plant C4
            bot.isPlanting = true;
            bot.plantProgress += dt / 3.0;
            if (bot.plantProgress >= 1.0) {
              bot.isPlanting = false;
              bot.hasC4 = false;
              this.state.bomb = {
                isPlanted: true,
                isDefused: false,
                isExploded: false,
                x: bot.x,
                y: bot.y,
                site: 'A',
                timer: 40,
                planterId: bot.id,
                defuserId: null
              };
              sound.playRadio('The bomb has been planted');
            }
          }
        } else if (bot.team === 'CT' && this.state.bomb.isPlanted && !this.state.bomb.isDefused) {
          // Rush to bomb to defuse
          const dist = Math.hypot(this.state.bomb.x - bot.x, this.state.bomb.y - bot.y);
          if (dist > 50) {
            const angle = Math.atan2(this.state.bomb.y - bot.y, this.state.bomb.x - bot.x);
            bot.angle = angle;
            bot.vx = Math.cos(angle) * 200;
            bot.vy = Math.sin(angle) * 200;
          } else {
            bot.isDefusing = true;
            bot.defuseProgress += dt / (bot.hasDefuseKit ? 5.0 : 10.0);
            if (bot.defuseProgress >= 1.0) {
              bot.isDefusing = false;
              this.state.bomb.isDefused = true;
              this.endRound('CT', 'Bomb Defused - Counter-Terrorists Win');
            }
          }
        } else {
          // Patrol cover points
          const targetPoint = this.state.map.coverPoints[(bot.kills + bot.deaths) % this.state.map.coverPoints.length];
          const dist = Math.hypot(targetPoint.x - bot.x, targetPoint.y - bot.y);
          if (dist > 60) {
            const angle = Math.atan2(targetPoint.y - bot.y, targetPoint.x - bot.x);
            bot.angle = angle;
            bot.vx = Math.cos(angle) * 140;
            bot.vy = Math.sin(angle) * 140;
          } else {
            bot.vx = 0;
            bot.vy = 0;
          }
        }
      }

      // Reloading check
      const ammo = bot.ammo[bot.currentWeapon.id];
      if (ammo && ammo.mag <= 3 && !bot.isReloading && ammo.reserve > 0) {
        this.reloadWeapon(bot);
      }

      if (bot.isReloading) {
        bot.reloadProgress += dt / bot.currentWeapon.reloadTime;
        if (bot.reloadProgress >= 1.0) {
          bot.isReloading = false;
          bot.reloadProgress = 0;
          if (ammo) {
            const transfer = Math.min(bot.currentWeapon.magazineSize - ammo.mag, ammo.reserve);
            ammo.mag += transfer;
            ammo.reserve -= transfer;
          }
        }
      }

      this.applyEntityMovement(bot, dt);
    }
  }

  private hasLineOfSight(from: CombatEntity, to: CombatEntity): boolean {
    // Check if solid permanent wall blocks line of sight
    for (const w of this.state.map.walls) {
      if (this.lineIntersectsSegment({ x: from.x, y: from.y }, { x: to.x, y: to.y }, { x: w.x1, y: w.y1 }, { x: w.x2, y: w.y2 })) {
        return false;
      }
    }
    return true;
  }

  private lineIntersectsSegment(p1: Vector2D, p2: Vector2D, p3: Vector2D, p4: Vector2D): boolean {
    const ccw = (a: Vector2D, b: Vector2D, c: Vector2D) => (c.y - a.y) * (b.x - a.x) > (b.y - a.y) * (c.x - a.x);
    return ccw(p1, p3, p4) !== ccw(p2, p3, p4) && ccw(p1, p2, p3) !== ccw(p1, p2, p4);
  }

  private applyEntityMovement(entity: CombatEntity, dt: number) {
    const nextX = entity.x + entity.vx * dt;
    const nextY = entity.y + entity.vy * dt;
    const radius = 22; // collision capsule radius

    let collideX = false;
    let collideY = false;

    // Check Map Border Walls
    for (const w of this.state.map.walls) {
      if (this.circleIntersectsWall(nextX, entity.y, radius, w)) collideX = true;
      if (this.circleIntersectsWall(entity.x, nextY, radius, w)) collideY = true;
    }

    // Check Non-destroyed Destructibles (crates, sandbags)
    for (const d of this.state.activeDestructibles) {
      if (d.isDestroyed) continue;
      if (this.circleIntersectsRect(nextX, entity.y, radius, d)) collideX = true;
      if (this.circleIntersectsRect(entity.x, nextY, radius, d)) collideY = true;
    }

    if (!collideX) entity.x = nextX;
    if (!collideY) entity.y = nextY;
  }

  private circleIntersectsWall(cx: number, cy: number, r: number, w: { x1: number; y1: number; x2: number; y2: number; thickness: number }): boolean {
    const l2 = Math.hypot(w.x2 - w.x1, w.y2 - w.y1) ** 2;
    if (l2 === 0) return Math.hypot(cx - w.x1, cy - w.y1) < r + w.thickness * 0.5;
    let t = ((cx - w.x1) * (w.x2 - w.x1) + (cy - w.y1) * (w.y2 - w.y1)) / l2;
    t = Math.max(0, Math.min(1, t));
    const px = w.x1 + t * (w.x2 - w.x1);
    const py = w.y1 + t * (w.y2 - w.y1);
    return Math.hypot(cx - px, cy - py) < (r + w.thickness * 0.5);
  }

  private circleIntersectsRect(cx: number, cy: number, r: number, rect: { x: number; y: number; width: number; height: number }): boolean {
    const closestX = Math.max(rect.x - rect.width / 2, Math.min(cx, rect.x + rect.width / 2));
    const closestY = Math.max(rect.y - rect.height / 2, Math.min(cy, rect.y + rect.height / 2));
    return Math.hypot(cx - closestX, cy - closestY) < r;
  }

  public fireWeapon(shooter: CombatEntity) {
    const now = performance.now();
    const wep = shooter.currentWeapon;
    const interval = 1000 / wep.fireRate;

    if (now - shooter.lastShotTime < interval) return;

    const ammo = shooter.ammo[wep.id];
    if (!ammo || ammo.mag <= 0) {
      if (!shooter.isReloading && ammo && ammo.reserve > 0) {
        this.reloadWeapon(shooter);
      }
      return;
    }

    // Decrement mag
    ammo.mag--;
    shooter.lastShotTime = now;

    // Recoil and Spread
    const spreadAngle = (Math.random() * 2 - 1) * wep.spread;
    const finalAngle = shooter.angle + spreadAngle;

    sound.playGunshot(wep.id, wep.id === 'usp' || wep.id === 'm4a1s');

    if (shooter.isPlayer) {
      this.state.camera.shake = Math.max(this.state.camera.shake, wep.recoil * 10);
    }

    // Spawn Projectile / Pellets (if shotgun, multiple pellets)
    const pelletCount = wep.category === 'SHOTGUN' ? 6 : 1;
    for (let p = 0; p < pelletCount; p++) {
      const pelletSpread = pelletCount > 1 ? (Math.random() * 2 - 1) * 0.12 : 0;
      const angle = finalAngle + pelletSpread;
      this.state.projectiles.push({
        id: `proj_${now}_${Math.random()}`,
        shooterId: shooter.id,
        team: shooter.team,
        startX: shooter.x,
        startY: shooter.y,
        x: shooter.x + Math.cos(angle) * 25,
        y: shooter.y + Math.sin(angle) * 25,
        vx: Math.cos(angle) * wep.bulletSpeed,
        vy: Math.sin(angle) * wep.bulletSpeed,
        damage: wep.damage / (pelletCount > 1 ? 1.5 : 1),
        penetration: wep.penetration * shooter.character.stats.destructBonus,
        rangeRemaining: wep.range,
        headshotMultiplier: wep.headshotMultiplier,
        isTracer: true,
        color: shooter.team === 'CT' ? '#38bdf8' : '#fb923c'
      });
    }

    // Muzzle flash particle
    this.state.particles.push({
      x: shooter.x + Math.cos(shooter.angle) * 30,
      y: shooter.y + Math.sin(shooter.angle) * 30,
      vx: Math.cos(shooter.angle) * 60,
      vy: Math.sin(shooter.angle) * 60,
      color: '#fef08a',
      size: 8,
      alpha: 1.0,
      decay: 18,
      shape: 'SPARK'
    });
  }

  public reloadWeapon(entity: CombatEntity) {
    const ammo = entity.ammo[entity.currentWeapon.id];
    if (!ammo || ammo.mag >= entity.currentWeapon.magazineSize || ammo.reserve <= 0) return;
    entity.isReloading = true;
    entity.reloadProgress = 0;
    sound.playReload();
  }

  public throwGrenade(entity: CombatEntity) {
    if (entity.grenades.length === 0) return;
    const gType = entity.grenades.shift() as 'HE' | 'SMOKE' | 'FLASH';
    const speed = 450;

    this.state.grenades.push({
      id: `grenade_${performance.now()}`,
      type: gType,
      throwerId: entity.id,
      team: entity.team,
      x: entity.x,
      y: entity.y,
      vx: Math.cos(entity.angle) * speed,
      vy: Math.sin(entity.angle) * speed,
      timer: 1.8,
      detonated: false
    });
  }

  private updateProjectiles(dt: number) {
    const allEntities = [this.state.player, ...this.state.bots];

    for (let i = this.state.projectiles.length - 1; i >= 0; i--) {
      const proj = this.state.projectiles[i];
      const prevX = proj.x;
      const prevY = proj.y;
      proj.x += proj.vx * dt;
      proj.y += proj.vy * dt;
      proj.rangeRemaining -= Math.hypot(proj.vx * dt, proj.vy * dt);

      // Check Destructibles Collision & Ballistic Wall Penetration
      for (const d of this.state.activeDestructibles) {
        if (d.isDestroyed) continue;
        if (this.circleIntersectsRect(proj.x, proj.y, 4, d)) {
          // Damage the destructible object
          d.health -= proj.damage * (proj.penetration >= 2 ? 1.5 : 1.0);

          // Wood / glass particles
          this.spawnDebrisParticles(proj.x, proj.y, d.debrisColor, 5);

          if (d.health <= 0) {
            d.isDestroyed = true;
            this.handleDestructionEvent(d);
          }

          if (d.penetrable && proj.penetration > 1.2) {
            // Bullet penetrates through with reduced damage
            proj.damage *= d.penDecay;
            proj.penetration -= 0.8;
          } else {
            // Bullet stopped by cover
            this.state.projectiles.splice(i, 1);
            break;
          }
        }
      }

      if (!this.state.projectiles[i]) continue;

      // Check Solid Wall Collisions
      let hitWall = false;
      for (const w of this.state.map.walls) {
        if (this.lineIntersectsSegment({ x: prevX, y: prevY }, { x: proj.x, y: proj.y }, { x: w.x1, y: w.y1 }, { x: w.x2, y: w.y2 })) {
          hitWall = true;
          this.state.bulletDecals.push({
            x: proj.x,
            y: proj.y,
            size: 6,
            type: 'BULLET_HOLE',
            alpha: 0.9
          });
          break;
        }
      }

      if (hitWall || proj.rangeRemaining <= 0) {
        this.state.projectiles.splice(i, 1);
        continue;
      }

      // Check Entity Hit Collisions
      for (const entity of allEntities) {
        if (entity.isDead || entity.team === proj.team) continue;

        const dist = Math.hypot(entity.x - proj.x, entity.y - proj.y);
        if (dist < 24) {
          // Headshot detection: top 30% of hit circle relative to direction
          const isHeadshot = dist < 12;
          const finalDamage = isHeadshot ? proj.damage * proj.headshotMultiplier : proj.damage;

          this.applyDamageToEntity(entity, finalDamage, proj.shooterId, isHeadshot);

          // Blood particles
          this.spawnBloodParticles(proj.x, proj.y, 8);

          // Hit sound
          sound.playHitmark(isHeadshot, entity.health <= 0);

          this.state.projectiles.splice(i, 1);
          break;
        }
      }
    }
  }

  private handleDestructionEvent(d: DestructibleObject) {
    if (d.type === 'GLASS_WALL') {
      sound.playDestruction('GLASS');
      this.spawnDebrisParticles(d.x, d.y, '#38bdf8', 25);
    } else if (d.type === 'WOOD_CRATE' || d.type === 'DRYWALL') {
      sound.playDestruction('WOOD');
      this.spawnDebrisParticles(d.x, d.y, d.debrisColor, 20);
    } else if (d.explodesOnDestroy) {
      sound.playDestruction('BARREL');
      this.spawnExplosion(d.x, d.y, d.explosionRadius || 200, d.explosionDamage || 120);
    }
  }

  public spawnExplosion(x: number, y: number, radius: number, damage: number) {
    sound.playExplosion(1.2);
    this.state.camera.shake = 18;

    // Scorch decal
    this.state.bulletDecals.push({
      x,
      y,
      size: radius * 0.7,
      type: 'EXPLOSION_SCORCH',
      alpha: 0.85
    });

    // Fire & Smoke Particles
    for (let i = 0; i < 35; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 250 + 50;
      this.state.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: i % 2 === 0 ? '#ef4444' : '#f59e0b',
        size: Math.random() * 12 + 6,
        alpha: 1.0,
        decay: 3.5,
        shape: 'CIRCLE'
      });
    }

    // Damage nearby entities & chain-explode barrels
    const allEntities = [this.state.player, ...this.state.bots];
    for (const e of allEntities) {
      if (e.isDead) continue;
      const dist = Math.hypot(e.x - x, e.y - y);
      if (dist < radius) {
        const falloff = 1 - (dist / radius);
        this.applyDamageToEntity(e, damage * falloff, 'explosion', false);
      }
    }

    for (const d of this.state.activeDestructibles) {
      if (d.isDestroyed) continue;
      const dist = Math.hypot(d.x - x, d.y - y);
      if (dist < radius) {
        d.health -= damage * 1.5;
        if (d.health <= 0) {
          d.isDestroyed = true;
          this.handleDestructionEvent(d);
        }
      }
    }
  }

  private applyDamageToEntity(entity: CombatEntity, damage: number, attackerId: string, isHeadshot: boolean) {
    if (entity.isDead) return;

    if (entity.armor > 0) {
      const armorAbsorb = damage * 0.5;
      entity.armor = Math.max(0, entity.armor - armorAbsorb);
      entity.health -= damage * 0.5;
    } else {
      entity.health -= damage;
    }

    if (entity.health <= 0) {
      entity.health = 0;
      entity.isDead = true;
      entity.deaths++;

      const allEntities = [this.state.player, ...this.state.bots];
      const killer = allEntities.find(e => e.id === attackerId);
      if (killer) {
        killer.kills++;
        killer.score += isHeadshot ? 150 : 100;
        killer.money += killer.currentWeapon.killReward;
      }

      // Add to killfeed
      const feedItem: KillFeedItem = {
        id: `kill_${performance.now()}`,
        killerName: killer ? killer.name : 'Tactical Blast',
        killerTeam: killer ? killer.team : 'CT',
        victimName: entity.name,
        victimTeam: entity.team,
        weaponName: killer ? killer.currentWeapon.name : 'Explosive',
        isHeadshot,
        isWallbang: false,
        isNoscope: false,
        timestamp: Date.now()
      };

      this.state.killFeed.unshift(feedItem);
      if (this.state.killFeed.length > 6) this.state.killFeed.pop();
      if (this.onKillFeedUpdate) this.onKillFeedUpdate(this.state.killFeed);
    }
  }

  private updateGrenades(dt: number) {
    for (let i = this.state.grenades.length - 1; i >= 0; i--) {
      const g = this.state.grenades[i];
      g.x += g.vx * dt;
      g.y += g.vy * dt;
      g.vx *= 0.95; // Friction
      g.vy *= 0.95;
      g.timer -= dt;

      if (g.timer <= 0) {
        // Detonate
        if (g.type === 'HE') {
          this.spawnExplosion(g.x, g.y, 220, 110);
        } else if (g.type === 'SMOKE') {
          this.state.smokeClouds.push({
            id: `smoke_${performance.now()}`,
            x: g.x,
            y: g.y,
            radius: 120,
            lifetime: 18.0,
            maxLifetime: 18.0
          });
        } else if (g.type === 'FLASH') {
          // Flashbang whiteout
          this.detonateFlashbang(g.x, g.y);
        }
        this.state.grenades.splice(i, 1);
      }
    }
  }

  private detonateFlashbang(x: number, y: number) {
    const allEntities = [this.state.player, ...this.state.bots];
    for (const e of allEntities) {
      if (e.isDead) continue;
      const dist = Math.hypot(e.x - x, e.y - y);
      if (dist < 500) {
        // Check facing angle
        e.flashDuration = Math.min(5.0, 5.0 * (1 - dist / 500));
      }
    }
    this.state.camera.shake = 12;
  }

  private updateSmokeClouds(dt: number) {
    for (let i = this.state.smokeClouds.length - 1; i >= 0; i--) {
      const s = this.state.smokeClouds[i];
      s.lifetime -= dt;
      if (s.lifetime <= 0) {
        this.state.smokeClouds.splice(i, 1);
      }
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.state.particles.length - 1; i >= 0; i--) {
      const p = this.state.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.alpha -= p.decay * dt;
      if (p.alpha <= 0) {
        this.state.particles.splice(i, 1);
      }
    }
  }

  private spawnDebrisParticles(x: number, y: number, color: string, count: number) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 180 + 30;
      this.state.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: Math.random() * 5 + 3,
        alpha: 1.0,
        decay: 2.2,
        shape: 'RECT'
      });
    }
  }

  private spawnBloodParticles(x: number, y: number, count: number) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 120 + 20;
      this.state.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: '#dc2626',
        size: Math.random() * 4 + 2,
        alpha: 0.9,
        decay: 3.0,
        shape: 'BLOOD'
      });
    }
  }

  private updateBomb(dt: number) {
    const bomb = this.state.bomb;
    if (bomb.isPlanted && !bomb.isDefused && !bomb.isExploded) {
      bomb.timer -= dt;

      // Accelerated beeps
      if (Math.random() < (1.0 / Math.max(0.2, bomb.timer * 0.15))) {
        sound.playC4Beep(1 - (bomb.timer / 40));
      }

      if (bomb.timer <= 0) {
        bomb.isExploded = true;
        this.spawnExplosion(bomb.x, bomb.y, 450, 250);
        this.endRound('T', 'Target Destroyed - Terrorists Win');
      }
    }
  }

  // 2nd-Person Camera View Computation
  private update2ndPersonCamera(dt: number) {
    const cam = this.state.camera;
    const player = this.state.player;
    const enemies = this.state.bots.filter(b => b.team !== player.team && !b.isDead);

    if (cam.perspective === 'ENEMY_POV') {
      // Find the enemy closest to or engaging player
      let primaryEnemy: CombatEntity | null = null;
      let minDist = 9999;
      for (const e of enemies) {
        const d = Math.hypot(e.x - player.x, e.y - player.y);
        if (d < minDist) {
          minDist = d;
          primaryEnemy = e;
        }
      }

      if (primaryEnemy) {
        cam.sourceEntityId = primaryEnemy.id;
        // Smooth camera lerp to enemy coordinate
        cam.x += (primaryEnemy.x - cam.x) * dt * 8;
        cam.y += (primaryEnemy.y - cam.y) * dt * 8;
        cam.targetZoom = Math.max(0.75, Math.min(1.2, 800 / Math.max(250, minDist)));
      } else {
        // Fallback to top-down tactical orbit if all enemies eliminated
        cam.x += (player.x - cam.x) * dt * 6;
        cam.y += (player.y - cam.y) * dt * 6;
        cam.targetZoom = 1.0;
      }
    } else if (cam.perspective === 'SURVEILLANCE_CCTV') {
      // Nearest CCTV Camera to player
      let nearestCCTV = this.state.map.cctvCameras[0];
      let minDist = 9999;
      for (const cctv of this.state.map.cctvCameras) {
        const d = Math.hypot(cctv.x - player.x, cctv.y - player.y);
        if (d < minDist) {
          minDist = d;
          nearestCCTV = cctv;
        }
      }
      if (nearestCCTV) {
        cam.sourceCCTVId = nearestCCTV.id;
        cam.x += (nearestCCTV.x - cam.x) * dt * 10;
        cam.y += (nearestCCTV.y - cam.y) * dt * 10;
        cam.targetZoom = 0.95;
      }
    } else if (cam.perspective === 'SPOTTER_DRONE') {
      // Drone hovering above player with lead offset
      cam.x += (player.x + player.vx * 0.3 - cam.x) * dt * 6;
      cam.y += (player.y + player.vy * 0.3 - cam.y) * dt * 6;
      cam.targetZoom = 0.85;
    } else if (cam.perspective === 'SQUAD_WINGMAN') {
      // Friendly squadmate camera
      const friendlyBots = this.state.bots.filter(b => b.team === player.team && !b.isDead);
      const wingman = friendlyBots[0];
      if (wingman) {
        cam.x += (wingman.x - cam.x) * dt * 8;
        cam.y += (wingman.y - cam.y) * dt * 8;
      } else {
        cam.x += (player.x - cam.x) * dt * 8;
        cam.y += (player.y - cam.y) * dt * 8;
      }
      cam.targetZoom = 1.0;
    } else {
      // TACTICAL_ORBIT
      cam.x += (player.x - cam.x) * dt * 8;
      cam.y += (player.y - cam.y) * dt * 8;
      cam.targetZoom = 1.0;
    }

    cam.zoom += (cam.targetZoom - cam.zoom) * dt * 5;
  }
}
