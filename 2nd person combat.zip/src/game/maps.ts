import { MapData } from '../types';

export const MAPS: MapData[] = [
  // MAP 1: DUST II - SANDSTORM DEPOT
  {
    id: 'dust2',
    name: 'Dust II: Sandstorm Depot',
    codeName: 'de_dust2',
    description: 'Iconic desert outpost. Features Mid double doors, Long A choke point, and explosive barrels near B site.',
    width: 2200,
    height: 1600,
    backgroundColor: '#b48a58',
    floorTileColor: '#cfab7a',
    walls: [
      // Outer perimeter
      { id: 'w1', x1: 50, y1: 50, x2: 2150, y2: 50, thickness: 24, color: '#8c6239' },
      { id: 'w2', x1: 2150, y1: 50, x2: 2150, y2: 1550, thickness: 24, color: '#8c6239' },
      { id: 'w3', x1: 2150, y1: 1550, x2: 50, y2: 1550, thickness: 24, color: '#8c6239' },
      { id: 'w4', x1: 50, y1: 1550, x2: 50, y2: 50, thickness: 24, color: '#8c6239' },

      // Long A Walls
      { id: 'w_long_1', x1: 1400, y1: 200, x2: 1400, y2: 700, thickness: 20, color: '#785328' },
      { id: 'w_long_2', x1: 1650, y1: 200, x2: 1650, y2: 600, thickness: 20, color: '#785328' },
      { id: 'w_long_plat', x1: 1650, y1: 200, x2: 2000, y2: 200, thickness: 20, color: '#785328' },

      // Mid Doors Corridor
      { id: 'w_mid_1', x1: 950, y1: 300, x2: 950, y2: 700, thickness: 18, color: '#785328' },
      { id: 'w_mid_2', x1: 1150, y1: 450, x2: 1150, y2: 950, thickness: 18, color: '#785328' },
      { id: 'w_mid_cat', x1: 1150, y1: 450, x2: 1450, y2: 450, thickness: 18, color: '#785328' },

      // B Tunnels & Site
      { id: 'w_btun_1', x1: 200, y1: 850, x2: 600, y2: 850, thickness: 20, color: '#785328' },
      { id: 'w_btun_2', x1: 200, y1: 1150, x2: 500, y2: 1150, thickness: 20, color: '#785328' },
      { id: 'w_bsite_wall', x1: 500, y1: 450, x2: 500, y2: 850, thickness: 20, color: '#785328' },
      { id: 'w_bsite_back', x1: 200, y1: 450, x2: 500, y2: 450, thickness: 20, color: '#785328' },

      // CT Spawn Divider
      { id: 'w_ct_div', x1: 950, y1: 250, x2: 1350, y2: 250, thickness: 18, color: '#785328' },

      // T Spawn Blockers
      { id: 'w_t_block', x1: 900, y1: 1350, x2: 1250, y2: 1350, thickness: 20, color: '#785328' },
    ],
    destructibles: [
      // Mid Doors (Destructible Wood)
      { id: 'mid_door_l', x: 950, y: 780, width: 20, height: 75, rotation: 0, type: 'WOOD_CRATE', health: 140, maxHealth: 140, isDestroyed: false, debrisColor: '#92400e', penetrable: true, penDecay: 0.7 },
      { id: 'mid_door_r', x: 950, y: 860, width: 20, height: 75, rotation: 0, type: 'WOOD_CRATE', health: 140, maxHealth: 140, isDestroyed: false, debrisColor: '#92400e', penetrable: true, penDecay: 0.7 },

      // A Site Crates (Stackable cover)
      { id: 'a_crate_1', x: 1800, y: 350, width: 60, height: 60, rotation: 0, type: 'WOOD_CRATE', health: 180, maxHealth: 180, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.6 },
      { id: 'a_crate_2', x: 1860, y: 350, width: 60, height: 60, rotation: 0, type: 'WOOD_CRATE', health: 180, maxHealth: 180, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.6 },
      { id: 'a_crate_car', x: 1950, y: 650, width: 80, height: 50, rotation: 0.2, type: 'SANDBAG', health: 350, maxHealth: 350, isDestroyed: false, debrisColor: '#78716c', penetrable: false, penDecay: 0.3 },

      // B Site Explosive Barrels & Crates
      { id: 'b_barrel_1', x: 380, y: 550, width: 45, height: 45, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 50, maxHealth: 50, isDestroyed: false, debrisColor: '#dc2626', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 220, explosionDamage: 120 },
      { id: 'b_barrel_2', x: 420, y: 580, width: 45, height: 45, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 50, maxHealth: 50, isDestroyed: false, debrisColor: '#dc2626', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 220, explosionDamage: 120 },
      { id: 'b_box_car', x: 300, y: 680, width: 65, height: 65, rotation: 0, type: 'WOOD_CRATE', health: 200, maxHealth: 200, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.6 },
      { id: 'b_plat_box', x: 230, y: 500, width: 55, height: 55, rotation: 0, type: 'WOOD_CRATE', health: 180, maxHealth: 180, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.6 },

      // Mid / Catwalk wooden barriers
      { id: 'cat_barrier', x: 1300, y: 450, width: 70, height: 18, rotation: 0, type: 'DRYWALL', health: 100, maxHealth: 100, isDestroyed: false, debrisColor: '#d6d3d1', penetrable: true, penDecay: 0.85 },
      { id: 'long_doors_w', x: 1400, y: 730, width: 18, height: 80, rotation: 0, type: 'WOOD_CRATE', health: 150, maxHealth: 150, isDestroyed: false, debrisColor: '#92400e', penetrable: true, penDecay: 0.7 }
    ],
    cctvCameras: [
      { id: 'cam_a_long', x: 1700, y: 120, fov: 1.5, angle: Math.PI * 0.7, rotationRange: 0.6, rotationSpeed: 0.4, label: 'CAM-01 [LONG-A PLAT]' },
      { id: 'cam_mid', x: 1050, y: 350, fov: 1.4, angle: Math.PI * 0.5, rotationRange: 0.8, rotationSpeed: 0.5, label: 'CAM-02 [MID DOORS]' },
      { id: 'cam_b_site', x: 180, y: 380, fov: 1.6, angle: Math.PI * 0.25, rotationRange: 0.7, rotationSpeed: 0.35, label: 'CAM-03 [B SITE ANCHOR]' },
      { id: 'cam_t_spawn', x: 1100, y: 1450, fov: 1.4, angle: -Math.PI * 0.5, rotationRange: 0.5, rotationSpeed: 0.3, label: 'CAM-04 [T SPAWN OVERLOOK]' }
    ],
    bombSites: [
      { id: 'A', x: 1850, y: 400, radius: 95 },
      { id: 'B', x: 350, y: 600, radius: 95 }
    ],
    ctSpawns: [
      { x: 1100, y: 160 },
      { x: 1200, y: 160 },
      { x: 1020, y: 160 },
      { x: 1150, y: 200 }
    ],
    tSpawns: [
      { x: 1050, y: 1440 },
      { x: 1180, y: 1440 },
      { x: 960, y: 1440 },
      { x: 1100, y: 1390 }
    ],
    coverPoints: [
      { x: 1800, y: 550 },
      { x: 1450, y: 600 },
      { x: 1000, y: 850 },
      { x: 450, y: 750 },
      { x: 320, y: 520 },
      { x: 1350, y: 350 }
    ]
  },

  // MAP 2: OFFICE COMPLEX - GLASS SKYRISE
  {
    id: 'office',
    name: 'Office: Glass Skyrise Complex',
    codeName: 'cs_office',
    description: 'Corporate highrise with breakable floor-to-ceiling glass partitions, conference tables, and drywall cubicles.',
    width: 2000,
    height: 1500,
    backgroundColor: '#334155',
    floorTileColor: '#475569',
    walls: [
      // Outer Perimeter
      { id: 'o_w1', x1: 50, y1: 50, x2: 1950, y2: 50, thickness: 24, color: '#1e293b' },
      { id: 'o_w2', x1: 1950, y1: 50, x2: 1950, y2: 1450, thickness: 24, color: '#1e293b' },
      { id: 'o_w3', x1: 1950, y1: 1450, x2: 50, y2: 1450, thickness: 24, color: '#1e293b' },
      { id: 'o_w4', x1: 50, y1: 1450, x2: 50, y2: 50, thickness: 24, color: '#1e293b' },

      // Main Corridor Hallway
      { id: 'o_hall_n', x1: 400, y1: 500, x2: 1600, y2: 500, thickness: 18, color: '#0f172a' },
      { id: 'o_hall_s', x1: 400, y1: 850, x2: 1600, y2: 850, thickness: 18, color: '#0f172a' },

      // Executive Boardroom
      { id: 'o_board_w', x1: 550, y1: 100, x2: 550, y2: 500, thickness: 18, color: '#0f172a' },
      { id: 'o_board_e', x1: 1400, y1: 100, x2: 1400, y2: 500, thickness: 18, color: '#0f172a' },

      // Kitchen / Server room
      { id: 'o_serv_w', x1: 650, y1: 850, x2: 650, y2: 1350, thickness: 18, color: '#0f172a' },
      { id: 'o_serv_e', x1: 1350, y1: 850, x2: 1350, y2: 1350, thickness: 18, color: '#0f172a' },
    ],
    destructibles: [
      // Big Breakable Glass Walls in Hallway & Conference
      { id: 'glass_1', x: 800, y: 500, width: 120, height: 16, rotation: 0, type: 'GLASS_WALL', health: 45, maxHealth: 45, isDestroyed: false, debrisColor: '#38bdf8', penetrable: true, penDecay: 0.95 },
      { id: 'glass_2', x: 1200, y: 500, width: 120, height: 16, rotation: 0, type: 'GLASS_WALL', health: 45, maxHealth: 45, isDestroyed: false, debrisColor: '#38bdf8', penetrable: true, penDecay: 0.95 },
      { id: 'glass_3', x: 950, y: 850, width: 140, height: 16, rotation: 0, type: 'GLASS_WALL', health: 45, maxHealth: 45, isDestroyed: false, debrisColor: '#38bdf8', penetrable: true, penDecay: 0.95 },

      // Drywall Cubicles (Bullet-penetrable wallbangs)
      { id: 'cube_1', x: 750, y: 280, width: 90, height: 14, rotation: 0, type: 'DRYWALL', health: 80, maxHealth: 80, isDestroyed: false, debrisColor: '#cbd5e1', penetrable: true, penDecay: 0.85 },
      { id: 'cube_2', x: 1100, y: 280, width: 90, height: 14, rotation: 0, type: 'DRYWALL', health: 80, maxHealth: 80, isDestroyed: false, debrisColor: '#cbd5e1', penetrable: true, penDecay: 0.85 },
      { id: 'cube_3', x: 950, y: 1100, width: 120, height: 14, rotation: 0, type: 'DRYWALL', health: 80, maxHealth: 80, isDestroyed: false, debrisColor: '#cbd5e1', penetrable: true, penDecay: 0.85 },

      // Wooden Desks / Crates
      { id: 'desk_1', x: 950, y: 260, width: 75, height: 45, rotation: 0, type: 'WOOD_CRATE', health: 160, maxHealth: 160, isDestroyed: false, debrisColor: '#78350f', penetrable: true, penDecay: 0.65 },
      { id: 'desk_2', x: 1000, y: 680, width: 85, height: 40, rotation: 0, type: 'WOOD_CRATE', health: 160, maxHealth: 160, isDestroyed: false, debrisColor: '#78350f', penetrable: true, penDecay: 0.65 },
      { id: 'desk_3', x: 450, y: 680, width: 70, height: 40, rotation: 0, type: 'WOOD_CRATE', health: 160, maxHealth: 160, isDestroyed: false, debrisColor: '#78350f', penetrable: true, penDecay: 0.65 },

      // Explosive Server Battery Units
      { id: 'server_batt', x: 1450, y: 1100, width: 48, height: 48, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 60, maxHealth: 60, isDestroyed: false, debrisColor: '#f97316', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 200, explosionDamage: 110 }
    ],
    cctvCameras: [
      { id: 'cam_off_hall', x: 1000, y: 550, fov: 1.6, angle: 0, rotationRange: 0.9, rotationSpeed: 0.45, label: 'CCTV-01 [MAIN CORRIDOR]' },
      { id: 'cam_off_exec', x: 950, y: 120, fov: 1.5, angle: Math.PI * 0.5, rotationRange: 0.7, rotationSpeed: 0.4, label: 'CCTV-02 [EXECUTIVE SUITE]' },
      { id: 'cam_off_serv', x: 1000, y: 1380, fov: 1.5, angle: -Math.PI * 0.5, rotationRange: 0.7, rotationSpeed: 0.4, label: 'CCTV-03 [SERVER ARCHIVE]' }
    ],
    bombSites: [
      { id: 'A', x: 950, y: 250, radius: 90 },
      { id: 'B', x: 1000, y: 1150, radius: 90 }
    ],
    ctSpawns: [
      { x: 1800, y: 680 },
      { x: 1800, y: 750 },
      { x: 1850, y: 640 },
      { x: 1850, y: 780 }
    ],
    tSpawns: [
      { x: 180, y: 680 },
      { x: 180, y: 750 },
      { x: 120, y: 640 },
      { x: 120, y: 780 }
    ],
    coverPoints: [
      { x: 750, y: 680 },
      { x: 1250, y: 680 },
      { x: 950, y: 350 },
      { x: 950, y: 1000 }
    ]
  },

  // MAP 3: INFERNO - VILLA COURTYARD
  {
    id: 'inferno',
    name: 'Inferno: Villa Courtyard',
    codeName: 'de_inferno',
    description: 'Narrow cobblestone streets, Banana corridor, destructible wine barrels, and church steeple vantage points.',
    width: 2100,
    height: 1600,
    backgroundColor: '#78350f',
    floorTileColor: '#92400e',
    walls: [
      { id: 'inf_w1', x1: 50, y1: 50, x2: 2050, y2: 50, thickness: 24, color: '#451a03' },
      { id: 'inf_w2', x1: 2050, y1: 50, x2: 2050, y2: 1550, thickness: 24, color: '#451a03' },
      { id: 'inf_w3', x1: 2050, y1: 1550, x2: 50, y2: 1550, thickness: 24, color: '#451a03' },
      { id: 'inf_w4', x1: 50, y1: 1550, x2: 50, y2: 50, thickness: 24, color: '#451a03' },

      // Banana Alley Curve
      { id: 'inf_b1', x1: 450, y1: 400, x2: 450, y2: 1100, thickness: 22, color: '#451a03' },
      { id: 'inf_b2', x1: 700, y1: 550, x2: 700, y2: 1250, thickness: 22, color: '#451a03' },

      // Mid Courtyard & Apartments
      { id: 'inf_mid1', x1: 1000, y1: 250, x2: 1000, y2: 750, thickness: 20, color: '#451a03' },
      { id: 'inf_mid2', x1: 1250, y1: 500, x2: 1250, y2: 1150, thickness: 20, color: '#451a03' },
      { id: 'inf_apt', x1: 1250, y1: 500, x2: 1650, y2: 500, thickness: 20, color: '#451a03' },

      // A Site & Library
      { id: 'inf_lib', x1: 1650, y1: 200, x2: 1650, y2: 800, thickness: 20, color: '#451a03' }
    ],
    destructibles: [
      // Banana Wine Barrels (Explosive / Breakable)
      { id: 'barrel_b1', x: 550, y: 650, width: 45, height: 45, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 50, maxHealth: 50, isDestroyed: false, debrisColor: '#ef4444', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 230, explosionDamage: 125 },
      { id: 'barrel_b2', x: 590, y: 690, width: 45, height: 45, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 50, maxHealth: 50, isDestroyed: false, debrisColor: '#ef4444', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 230, explosionDamage: 125 },

      // Wooden Carts & Crates on B Site
      { id: 'cart_b', x: 300, y: 350, width: 80, height: 50, rotation: 0.3, type: 'WOOD_CRATE', health: 220, maxHealth: 220, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.65 },
      { id: 'crate_b_stack', x: 220, y: 280, width: 60, height: 60, rotation: 0, type: 'WOOD_CRATE', health: 180, maxHealth: 180, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.65 },

      // A Site Patios & Balconies
      { id: 'a_pit_sandbags', x: 1800, y: 400, width: 90, height: 35, rotation: 0, type: 'SANDBAG', health: 320, maxHealth: 320, isDestroyed: false, debrisColor: '#a8a29e', penetrable: false, penDecay: 0.3 },
      { id: 'a_grave_crate', x: 1550, y: 320, width: 55, height: 55, rotation: 0, type: 'WOOD_CRATE', health: 160, maxHealth: 160, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.65 }
    ],
    cctvCameras: [
      { id: 'cam_inf_banana', x: 570, y: 950, fov: 1.5, angle: -Math.PI * 0.5, rotationRange: 0.7, rotationSpeed: 0.4, label: 'CCTV-01 [BANANA STREET]' },
      { id: 'cam_inf_court', x: 1100, y: 550, fov: 1.6, angle: 0, rotationRange: 0.8, rotationSpeed: 0.45, label: 'CCTV-02 [VILLA COURTYARD]' },
      { id: 'cam_inf_asite', x: 1750, y: 220, fov: 1.5, angle: Math.PI * 0.6, rotationRange: 0.6, rotationSpeed: 0.35, label: 'CCTV-03 [A SITE FOUNTAIN]' }
    ],
    bombSites: [
      { id: 'A', x: 1750, y: 350, radius: 90 },
      { id: 'B', x: 280, y: 300, radius: 90 }
    ],
    ctSpawns: [
      { x: 1100, y: 180 },
      { x: 1200, y: 180 },
      { x: 1020, y: 180 },
      { x: 1150, y: 230 }
    ],
    tSpawns: [
      { x: 600, y: 1420 },
      { x: 720, y: 1420 },
      { x: 500, y: 1420 },
      { x: 620, y: 1370 }
    ],
    coverPoints: [
      { x: 550, y: 800 },
      { x: 1100, y: 700 },
      { x: 1500, y: 400 },
      { x: 350, y: 450 }
    ]
  },

  // MAP 4: NUKE - INDUSTRIAL CORE
  {
    id: 'nuke',
    name: 'Nuke: Industrial Reactor Core',
    codeName: 'de_nuke',
    description: 'High-tech nuclear plant with blast doors, radioactive containment barrels, and catwalk sniper lanes.',
    width: 2100,
    height: 1600,
    backgroundColor: '#1e293b',
    floorTileColor: '#334155',
    walls: [
      { id: 'nuk_w1', x1: 50, y1: 50, x2: 2050, y2: 50, thickness: 24, color: '#0f172a' },
      { id: 'nuk_w2', x1: 2050, y1: 50, x2: 2050, y2: 1550, thickness: 24, color: '#0f172a' },
      { id: 'nuk_w3', x1: 2050, y1: 1550, x2: 50, y2: 1550, thickness: 24, color: '#0f172a' },
      { id: 'nuk_w4', x1: 50, y1: 1550, x2: 50, y2: 50, thickness: 24, color: '#0f172a' },

      // Main Reactor Silo Walls
      { id: 'nuk_silo_w', x1: 850, y1: 450, x2: 850, y2: 1050, thickness: 22, color: '#0f172a' },
      { id: 'nuk_silo_e', x1: 1350, y1: 450, x2: 1350, y2: 1050, thickness: 22, color: '#0f172a' },
      { id: 'nuk_silo_n', x1: 850, y1: 450, x2: 1350, y2: 450, thickness: 22, color: '#0f172a' },

      // Ramp Corridor
      { id: 'nuk_ramp', x1: 1450, y1: 800, x2: 1850, y2: 800, thickness: 20, color: '#0f172a' }
    ],
    destructibles: [
      // Toxic Barrels (Large chain blast)
      { id: 'nuk_tox1', x: 1100, y: 700, width: 50, height: 50, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 50, maxHealth: 50, isDestroyed: false, debrisColor: '#84cc16', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 250, explosionDamage: 135 },
      { id: 'nuk_tox2', x: 1150, y: 730, width: 50, height: 50, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 50, maxHealth: 50, isDestroyed: false, debrisColor: '#84cc16', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 250, explosionDamage: 135 },

      // Catwalk Drywall / Glass
      { id: 'nuk_glass_hut', x: 950, y: 450, width: 80, height: 16, rotation: 0, type: 'GLASS_WALL', health: 40, maxHealth: 40, isDestroyed: false, debrisColor: '#06b6d4', penetrable: true, penDecay: 0.95 },
      { id: 'nuk_crate_yard', x: 450, y: 800, width: 65, height: 65, rotation: 0, type: 'WOOD_CRATE', health: 200, maxHealth: 200, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.65 }
    ],
    cctvCameras: [
      { id: 'cam_nuk_silo', x: 1100, y: 480, fov: 1.7, angle: Math.PI * 0.5, rotationRange: 0.9, rotationSpeed: 0.5, label: 'CCTV-01 [REACTOR CORE]' },
      { id: 'cam_nuk_yard', x: 450, y: 350, fov: 1.5, angle: Math.PI * 0.3, rotationRange: 0.7, rotationSpeed: 0.4, label: 'CCTV-02 [OUTSIDE YARD]' }
    ],
    bombSites: [
      { id: 'A', x: 1100, y: 650, radius: 95 },
      { id: 'B', x: 1650, y: 1000, radius: 90 }
    ],
    ctSpawns: [
      { x: 1750, y: 300 },
      { x: 1850, y: 300 },
      { x: 1700, y: 350 },
      { x: 1800, y: 350 }
    ],
    tSpawns: [
      { x: 300, y: 1350 },
      { x: 400, y: 1350 },
      { x: 250, y: 1400 },
      { x: 350, y: 1400 }
    ],
    coverPoints: [
      { x: 950, y: 800 },
      { x: 1250, y: 800 },
      { x: 1550, y: 900 }
    ]
  },

  // MAP 5: TRAINING KILLHOUSE / SHOOTING RANGE
  {
    id: 'killhouse',
    name: 'Killhouse: Ballistics & Breach Range',
    codeName: 'cqb_range',
    description: 'Tactical target arena loaded with all destructible materials, plywood doors, explosive chain barrels, and fast target reset.',
    width: 1800,
    height: 1300,
    backgroundColor: '#27272a',
    floorTileColor: '#3f3f46',
    walls: [
      { id: 'k_w1', x1: 50, y1: 50, x2: 1750, y2: 50, thickness: 24, color: '#18181b' },
      { id: 'k_w2', x1: 1750, y1: 50, x2: 1750, y2: 1250, thickness: 24, color: '#18181b' },
      { id: 'k_w3', x1: 1750, y1: 1250, x2: 50, y2: 1250, thickness: 24, color: '#18181b' },
      { id: 'k_w4', x1: 50, y1: 1250, x2: 50, y2: 50, thickness: 24, color: '#18181b' },

      // Training room dividers
      { id: 'k_div_1', x1: 600, y1: 100, x2: 600, y2: 700, thickness: 18, color: '#18181b' },
      { id: 'k_div_2', x1: 1200, y1: 600, x2: 1200, y2: 1200, thickness: 18, color: '#18181b' }
    ],
    destructibles: [
      // Test Glass
      { id: 'k_glass_test', x: 600, y: 400, width: 14, height: 100, rotation: 0, type: 'GLASS_WALL', health: 40, maxHealth: 40, isDestroyed: false, debrisColor: '#38bdf8', penetrable: true, penDecay: 0.95 },
      // Test Drywall
      { id: 'k_dry_test', x: 1200, y: 800, width: 14, height: 100, rotation: 0, type: 'DRYWALL', health: 75, maxHealth: 75, isDestroyed: false, debrisColor: '#e2e8f0', penetrable: true, penDecay: 0.85 },
      // Wood Crates array
      { id: 'k_crate_1', x: 850, y: 350, width: 60, height: 60, rotation: 0, type: 'WOOD_CRATE', health: 150, maxHealth: 150, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.65 },
      { id: 'k_crate_2', x: 920, y: 350, width: 60, height: 60, rotation: 0, type: 'WOOD_CRATE', health: 150, maxHealth: 150, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.65 },
      { id: 'k_crate_3', x: 885, y: 420, width: 60, height: 60, rotation: 0, type: 'WOOD_CRATE', health: 150, maxHealth: 150, isDestroyed: false, debrisColor: '#a16207', penetrable: true, penDecay: 0.65 },
      // Explosive Barrel Cluster
      { id: 'k_barrel_1', x: 1400, y: 350, width: 45, height: 45, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 45, maxHealth: 45, isDestroyed: false, debrisColor: '#dc2626', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 240, explosionDamage: 130 },
      { id: 'k_barrel_2', x: 1460, y: 350, width: 45, height: 45, rotation: 0, type: 'EXPLOSIVE_BARREL', health: 45, maxHealth: 45, isDestroyed: false, debrisColor: '#dc2626', penetrable: true, penDecay: 0.8, explodesOnDestroy: true, explosionRadius: 240, explosionDamage: 130 }
    ],
    cctvCameras: [
      { id: 'cam_k_main', x: 900, y: 100, fov: 1.8, angle: Math.PI * 0.5, rotationRange: 0.9, rotationSpeed: 0.6, label: 'RANGE-01 [BALLISTIC OVERVIEW]' }
    ],
    bombSites: [
      { id: 'A', x: 900, y: 650, radius: 85 }
    ],
    ctSpawns: [
      { x: 300, y: 650 },
      { x: 300, y: 750 }
    ],
    tSpawns: [
      { x: 1500, y: 650 },
      { x: 1500, y: 750 }
    ],
    coverPoints: [
      { x: 750, y: 650 },
      { x: 1050, y: 650 }
    ]
  }
];
