export type Team = 'CT' | 'T';

export type CameraPerspective = 
  | 'ENEMY_POV'          // Looking from the eyes/camera of the nearest or engaging enemy
  | 'SURVEILLANCE_CCTV'   // Wall-mounted tactical security camera closest to the action
  | 'SPOTTER_DRONE'      // Aerial tactical drone following from overhead/isometric angle
  | 'SQUAD_WINGMAN'      // Looking from your squadmate's shoulder camera
  | 'TACTICAL_ORBIT';    // Cinematic tactical third/dynamic follow

export type GameMode = 'DEFUSAL' | 'DEATHMATCH' | 'BREACH_RESCUE' | 'SNIPER_DUEL' | 'TRAINING';

export type WeaponCategory = 'PISTOL' | 'SMG' | 'RIFLE' | 'SNIPER' | 'SHOTGUN' | 'GRENADE' | 'GEAR';

export type WeaponSkin = 'DEFAULT' | 'DRAGON_FIRE' | 'NEON_CYBER' | 'ASIIMOV_WHITE' | 'GOLDEN_EMPEROR' | 'CARBON_STEALTH';

export type AttachmentType = 'SUPPRESSOR' | 'RED_DOT' | 'LASER_SIGHT' | 'EXTENDED_MAG' | 'HEAVY_BARREL';

export interface WeaponAttachment {
  id: AttachmentType;
  name: string;
  description: string;
  damageMod: number;
  accuracyMod: number;
  recoilMod: number;
  capacityMod: number;
  silenced?: boolean;
}

export interface WeaponDef {
  id: string;
  name: string;
  category: WeaponCategory;
  price: number;
  damage: number;
  headshotMultiplier: number;
  fireRate: number; // rounds per second
  magazineSize: number;
  reserveAmmo: number;
  reloadTime: number; // seconds
  recoil: number;
  penetration: number; // 1 = wood, 2 = drywall/glass, 3 = thick crates, 4 = concrete
  range: number;
  bulletSpeed: number;
  spread: number;
  icon: string;
  killReward: number;
  supportedAttachments: AttachmentType[];
  description: string;
}

export interface CharacterDef {
  id: string;
  name: string;
  team: Team;
  callsign: string;
  role: string;
  avatarColor: string;
  accentColor: string;
  perkName: string;
  perkDesc: string;
  stats: {
    health: number;
    armor: number;
    speed: number;
    recoilControl: number;
    destructBonus: number;
  };
}

export interface LoadoutConfig {
  primaryWeaponId: string;
  secondaryWeaponId: string;
  knifeId: string;
  grenades: string[];
  armor: boolean;
  helmet: boolean;
  defuseKit: boolean;
  skin: WeaponSkin;
  attachments: { [weaponId: string]: AttachmentType[] };
}

export interface Vector2D {
  x: number;
  y: number;
}

export type DestructibleType = 'WOOD_CRATE' | 'GLASS_WALL' | 'DRYWALL' | 'EXPLOSIVE_BARREL' | 'SANDBAG' | 'SECURITY_DOOR';

export interface DestructibleObject {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  type: DestructibleType;
  health: number;
  maxHealth: number;
  isDestroyed: boolean;
  debrisColor: string;
  penetrable: boolean;
  penDecay: number; // damage reduction when bullets pass through
  explodesOnDestroy?: boolean;
  explosionRadius?: number;
  explosionDamage?: number;
}

export interface WallSegment {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  thickness: number;
  color: string;
}

export interface CCTVCamera {
  id: string;
  x: number;
  y: number;
  fov: number;
  angle: number;
  rotationRange: number; // arc in radians
  rotationSpeed: number;
  label: string;
}

export interface BombSite {
  id: 'A' | 'B';
  x: number;
  y: number;
  radius: number;
}

export interface MapData {
  id: string;
  name: string;
  codeName: string;
  description: string;
  width: number;
  height: number;
  backgroundColor: string;
  floorTileColor: string;
  walls: WallSegment[];
  destructibles: DestructibleObject[];
  cctvCameras: CCTVCamera[];
  bombSites: BombSite[];
  ctSpawns: Vector2D[];
  tSpawns: Vector2D[];
  coverPoints: Vector2D[];
}

export interface Projectile {
  id: string;
  shooterId: string;
  team: Team;
  startX: number;
  startY: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  penetration: number;
  rangeRemaining: number;
  headshotMultiplier: number;
  isTracer: boolean;
  color: string;
}

export interface GrenadeEntity {
  id: string;
  type: 'HE' | 'SMOKE' | 'FLASH' | 'DECOY';
  throwerId: string;
  team: Team;
  x: number;
  y: number;
  vx: number;
  vy: number;
  timer: number; // seconds until detonation
  detonated: boolean;
}

export interface SmokeCloud {
  id: string;
  x: number;
  y: number;
  radius: number;
  lifetime: number;
  maxLifetime: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  decay: number;
  shape: 'RECT' | 'CIRCLE' | 'SPARK' | 'BLOOD';
}

export interface BulletDecal {
  x: number;
  y: number;
  size: number;
  type: 'BULLET_HOLE' | 'BLOOD_SPLAT' | 'EXPLOSION_SCORCH' | 'GLASS_CRACK';
  alpha: number;
}

export interface CombatEntity {
  id: string;
  name: string;
  team: Team;
  isPlayer: boolean;
  character: CharacterDef;
  x: number;
  y: number;
  angle: number; // view direction in radians
  targetAngle: number;
  vx: number;
  vy: number;
  health: number;
  maxHealth: number;
  armor: number;
  hasHelmet: boolean;
  hasDefuseKit: boolean;
  hasC4: boolean;
  isPlanting: boolean;
  plantProgress: number;
  isDefusing: boolean;
  defuseProgress: number;
  currentWeapon: WeaponDef;
  secondaryWeapon: WeaponDef;
  grenades: string[];
  knife: WeaponDef;
  ammo: { [weaponId: string]: { mag: number; reserve: number } };
  isReloading: boolean;
  reloadProgress: number;
  isShooting: boolean;
  lastShotTime: number;
  kills: number;
  deaths: number;
  score: number;
  money: number;
  mvps: number;
  isDead: boolean;
  respawnTimer: number;
  flashDuration: number; // seconds blinded
  recoilOffset: Vector2D;
  state: 'IDLE' | 'PATROL' | 'ENGAGING' | 'SEEKING_COVER' | 'PLANTING' | 'DEFUSING' | 'RETREATING';
  targetEnemyId: string | null;
  lookAtTarget: Vector2D;
}

export interface BombState {
  isPlanted: boolean;
  isDefused: boolean;
  isExploded: boolean;
  x: number;
  y: number;
  site: 'A' | 'B' | null;
  timer: number; // standard 40s
  planterId: string | null;
  defuserId: string | null;
}

export interface KillFeedItem {
  id: string;
  killerName: string;
  killerTeam: Team;
  victimName: string;
  victimTeam: Team;
  weaponName: string;
  isHeadshot: boolean;
  isWallbang: boolean;
  isNoscope: boolean;
  timestamp: number;
}

export interface RoundState {
  roundNumber: number;
  ctScore: number;
  tScore: number;
  maxRounds: number;
  phase: 'FREEZE_TIME' | 'LIVE' | 'ROUND_OVER' | 'MATCH_OVER';
  phaseTimer: number;
  winnerTeam: Team | null;
  winReason: string;
}

export interface CameraState {
  perspective: CameraPerspective;
  sourceEntityId: string | null; // which entity's eyes we are currently seeing through
  sourceCCTVId: string | null;   // or which security camera
  x: number;
  y: number;
  zoom: number;
  targetZoom: number;
  shake: number;
  scanlineIntensity: number;
  nightVision: boolean;
  thermalVision: boolean;
  lockOnTargetId: string | null;
}
