package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.components.CartDrawer
import com.example.ui.components.CyberHeader
import com.example.ui.components.CyberToast
import com.example.ui.components.OrderSuccessDialog
import com.example.ui.components.SpecsDialog
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.StorefrontScreen
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.NexusStoreViewModel
import com.example.viewmodel.Screen

class MainActivity : ComponentActivity() {
    private val viewModel: NexusStoreViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NexusCoreApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun NexusCoreApp(viewModel: NexusStoreViewModel) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground),
        topBar = {
            CyberHeader(
                currentScreen = state.currentScreen,
                cartCount = state.totalCartCount,
                searchQuery = state.searchQuery,
                onSearchChange = { viewModel.setSearchQuery(it) },
                onNavigateStorefront = { viewModel.navigateTo(Screen.STOREFRONT) },
                onOpenCart = { viewModel.toggleCartDrawer(true) },
                onOpenSpecs = { viewModel.toggleSpecsModal(true) },
                onOpenSupport = { viewModel.showToast("Support Uplink: 24/7 Priority Discord & SLA Active", "SUPPORT DISPATCH") }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CyberBackground)
        ) {
            when (state.currentScreen) {
                Screen.STOREFRONT -> {
                    StorefrontScreen(
                        state = state,
                        onCategorySelected = { viewModel.setCategory(it) },
                        onAddToCart = { viewModel.addToCart(it) },
                        onOpenCart = { viewModel.toggleCartDrawer(true) }
                    )
                }

                Screen.CHECKOUT -> {
                    CheckoutScreen(
                        state = state,
                        onBackToStore = { viewModel.navigateTo(Screen.STOREFRONT) },
                        onToggleShippingEdit = { viewModel.toggleShippingEdit() },
                        onSaveShipping = { viewModel.updateShippingDetails(it) },
                        onSelectPaymentMethod = { viewModel.setPaymentMethod(it) },
                        onUpdateCardDetails = { number, name, expiry, cvc ->
                            viewModel.updateCardInfo(number, name, expiry, cvc)
                        },
                        onToggleVault = { viewModel.setStoreEncryptedToken(it) },
                        onApplyPromo = { viewModel.applyPromoCode(it) },
                        onAuthorizeOrder = { viewModel.authorizeAndPlaceOrder() }
                    )
                }
            }

            // Interactive Cart Drawer
            CartDrawer(
                state = state,
                onClose = { viewModel.toggleCartDrawer(false) },
                onUpdateQuantity = { id, delta -> viewModel.updateQuantity(id, delta) },
                onRemoveItem = { id -> viewModel.removeCartItem(id) },
                onProceedToCheckout = { viewModel.navigateTo(Screen.CHECKOUT) }
            )

            // Animated Cyber Toast
            CyberToast(
                isVisible = state.isToastVisible,
                title = state.toastSubtitle ?: "STATUS",
                message = state.toastMessage ?: "",
                onDismiss = { viewModel.dismissToast() }
            )

            // Order Success Protocol Dialog
            if (state.isOrderSuccessDialogOpen) {
                OrderSuccessDialog(
                    state = state,
                    onDismiss = { viewModel.dismissOrderSuccess() }
                )
            }

            // Hardware Specs Modal
            if (state.isSpecsModalOpen) {
                SpecsDialog(
                    onDismiss = { viewModel.toggleSpecsModal(false) }
                )
            }
        }
    }
}
