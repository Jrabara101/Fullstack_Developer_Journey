package com.example.model

data class Product(
    val id: String,
    val title: String,
    val shortName: String,
    val categoryCode: String,
    val category: String, // "keyboards", "mice", "headsets", "mats"
    val rating: Double,
    val reviewCount: Int,
    val specs: String,
    val specTag: String,
    val accentBadge: String,
    val price: Double,
    val variant: String,
    val imageUrl: String,
    val warehouse: String = "Alpha"
)

data class CartItem(
    val product: Product,
    val variant: String,
    val quantity: Int
) {
    val totalPrice: Double get() = product.price * quantity
}

data class ShippingDetails(
    val name: String = "Alex Chen",
    val email: String = "alex.chen@esports.gg",
    val phone: String = "+1 (555) 382-9011",
    val street: String = "742 Evergreen Terrace",
    val suite: String = "Suite 4B",
    val city: String = "Neo Tokyo",
    val state: String = "CA",
    val postalCode: String = "94107",
    val country: String = "United States"
) {
    fun summaryAddress(): String = "$street, $suite, $city, $state $postalCode, $country"
    fun summaryContact(): String = "$name • $email • $phone"
}
