package com.example.model

object ProductRepository {
    const val AVATAR_URL =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuD32-maZlUR7v8Cq_W8hOgjMVJpdlpjajTCvPWjD7garjFelTO8rXnaii-nxuAItRpRu71S5aCzjyOucBBzwasM3dWGP7-rOxIQoq6eq6TemtWvBXBgd9KbVRysdqXkcls_2V1I2g0KPvHh1ydIPs1vW9YEURW5wDrS435uPSxHqZU0pT6j0APYjafhb9lZjrFGkDqkx0o_rKEynD9uo3Wtm8MKPeYKIWfx16B1Hbxb0SaGrrjD6bLnsQ"

    const val LOGO_URL =
        "https://lh3.googleusercontent.com/aida/AEtjO1VZOxKj7_DWmS7VjEkM1UesPBYnYX-vM2_on723wpMjcm6zXhSHPL5ro9bHjQnzrygUVVx5gV-4TfdtM_W1W4raTQTdnb6gEsmxzCN8LjTmBrFMxDKr8Ve_lEUemgV4sV47E5cbmZFyvHpa49SnQmNwBVPIegB-t2d8srxf--rPHEVcfRIIvZU_19Ppa4UB-F2h9VG22vJxTXjpY-ERfFBzETv2LlehNibzKYifnPbVuCMtaSm_iP7Jlbcx"

    val products = listOf(
        Product(
            id = "prod-1",
            title = "NEXUS Apex-75 Magnetic Hall Keyboard",
            shortName = "Apex-75 Wireless Keyboard",
            categoryCode = "HEX // 01 · KEYBOARD",
            category = "keyboards",
            rating = 4.9,
            reviewCount = 184,
            specs = "0.1mm Actuation • 8000Hz Polling • PBT Dye-Sub",
            specTag = "8000 Hz USB-C",
            accentBadge = "RAPID TRIGGER",
            price = 219.00,
            variant = "Carbon Slate / 8K",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCNFHuY_Mw7P9eTM7HJo4FfZtkBgAMnPx8L8XFFJ5JBA2uloMc0l8X2krCw_4uXvpzNFblXzJTIzNC3oB56SWgZaGQp28cRLNNCvV9Rf2f0ouoKImxyFfU4eJ7LRFcU2XM6mFxfVJkgjYtbRv1-Hp6DSUtAtpwTQ-sZwqg_L49B3y8c0T0ohFfj1BAMqCSDD_RzoU42rZldjPi0-XYURgrItkaiE9jlLuUpMPzuizp4IccI4PT4E3w9DA",
            warehouse = "Alpha"
        ),
        Product(
            id = "prod-2",
            title = "AETHER Carbon-38 Wireless Gaming Mouse",
            shortName = "Carbon-38 Ultralight Mouse",
            categoryCode = "HEX // 02 · MOUSE",
            category = "mice",
            rating = 5.0,
            reviewCount = 96,
            specs = "38g Featherweight • PAW3950 Optical • 4K Dongle",
            specTag = "PAW3950 GEN2",
            accentBadge = "LIMITED RUN",
            price = 159.00,
            variant = "Forged Matte",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCGRNYcK9cOxJ-G7n7w46yU9x_PhsCUMxSXOBQU3UyWF-91Ex9r2Qe90sVrqMKlpWGrDunkcb-nS8Q9ghyADE_frrqvfxW3fJQ0dvUXWhYXwRm5v0aEv_zqz8u5TFnY-Yzz2I2siBspzwue7Ro-DzQkPGwXXdYlYR9S7xPYNr4YK1pb4P8Q1OKvFtLtjk9T5EA6aQyebWilAN46UmirExYXk82YpQPqNtOPusyE7yMIX40ux9T3ltPFgQ",
            warehouse = "Delta"
        ),
        Product(
            id = "prod-3",
            title = "AEGIS Pro Planar Magnetic Wireless Headset",
            shortName = "AEGIS Pro Planar Magnetic Headset",
            categoryCode = "HEX // 03 · AUDIO",
            category = "headsets",
            rating = 4.8,
            reviewCount = 112,
            specs = "90mm Drivers • Ultra-Low Latency 2.4G • Detachable Mic",
            specTag = "90MM ISODYNAMIC",
            accentBadge = "STUDIO GRADE",
            price = 289.00,
            variant = "Studio Obsidian",
            imageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuC5tSd4lGUV73mSfTvDc0MNZsaA4x7W9j5zT0rOswz5FE4xn-WeXKIP1JtM5kzGuPARUkoF_0Nftwj57L1f74jGQ9_J5PN49hSWWkoZVcs-Y4KKot6Uo2bu6z3VihLoSMJ7FukGfwdPlaMzoe3_3IoEmgUyodWeb0s6uqSY0luSBKZpSOtWKC4BiKFzbUe1MnDzu5XIMLobX_KmfPGj2VPzeSTada0OBlwiZ8tNkm5tO05PNPd7if0BWQ",
            warehouse = "Alpha"
        )
    )

    fun getInitialCart(): List<CartItem> {
        return listOf(
            CartItem(product = products[0], variant = products[0].variant, quantity = 1),
            CartItem(product = products[1], variant = products[1].variant, quantity = 1)
        )
    }
}
