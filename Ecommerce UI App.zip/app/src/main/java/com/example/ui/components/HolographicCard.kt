package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberTertiary

@Composable
fun HolographicCard(
    cardNumber: String,
    cardHolder: String,
    expiry: String,
    modifier: Modifier = Modifier
) {
    val cardGradient = Brush.linearGradient(
        colors = listOf(
            Color(0xFF2E2F5B),
            Color(0xFF1E1E38),
            Color(0xFF121226)
        )
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(cardGradient)
            .border(
                1.5.dp,
                Brush.linearGradient(
                    listOf(
                        CyberPrimary.copy(alpha = 0.8f),
                        CyberSecondary.copy(alpha = 0.5f),
                        CyberTertiary.copy(alpha = 0.3f)
                    )
                ),
                RoundedCornerShape(18.dp)
            )
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Row: Chip + Contactless + Brand
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // EMV Chip
                    Box(
                        modifier = Modifier
                            .size(36.dp, 26.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE2B755))
                            .border(1.dp, Color(0xFFC79836), RoundedCornerShape(4.dp))
                            .padding(3.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .border(0.5.dp, Color(0xFF8A6822), RoundedCornerShape(2.dp))
                        )
                    }

                    // Contactless Icon
                    Icon(
                        imageVector = Icons.Default.Nfc,
                        contentDescription = "Contactless",
                        tint = CyberPrimary.copy(alpha = 0.85f),
                        modifier = Modifier.size(20.dp)
                    )

                    Text(
                        text = "TITAN // ACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = CyberSecondary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.08.sp
                        )
                    )
                }

                Text(
                    text = "CYBERPAY",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                )
            }

            // Card Number
            Text(
                text = cardNumber.ifBlank { "•••• •••• •••• 8842" },
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 21.sp,
                    letterSpacing = 2.sp,
                    color = Color.White
                )
            )

            // Bottom Row: Holder & Expiry
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "CARDHOLDER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = CyberPrimary.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                    )
                    Text(
                        text = cardHolder.uppercase().ifBlank { "ALEX CHEN" },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "EXPIRES",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = CyberPrimary.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                    )
                    Text(
                        text = expiry.ifBlank { "09 / 28" },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    )
                }
            }
        }
    }
}
