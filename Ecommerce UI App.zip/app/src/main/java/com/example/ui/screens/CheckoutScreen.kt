package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ShippingDetails
import com.example.ui.components.HolographicCard
import com.example.ui.components.OrderTelemetryCard
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberOnPrimary
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberOutlineVariant
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurfaceContainer
import com.example.ui.theme.CyberSurfaceContainerHigh
import com.example.ui.theme.CyberSurfaceContainerLow
import com.example.ui.theme.CyberSurfaceContainerLowest
import com.example.viewmodel.NexusUiState

@Composable
fun CheckoutScreen(
    state: NexusUiState,
    onBackToStore: () -> Unit,
    onToggleShippingEdit: () -> Unit,
    onSaveShipping: (ShippingDetails) -> Unit,
    onSelectPaymentMethod: (String) -> Unit,
    onUpdateCardDetails: (String, String, String, String) -> Unit,
    onToggleVault: (Boolean) -> Unit,
    onApplyPromo: (String) -> Unit,
    onAuthorizeOrder: () -> Unit,
    modifier: Modifier = Modifier
) {
    var editStreet by remember(state.shippingDetails) { mutableStateOf(state.shippingDetails.street) }
    var editSuite by remember(state.shippingDetails) { mutableStateOf(state.shippingDetails.suite) }
    var editCity by remember(state.shippingDetails) { mutableStateOf(state.shippingDetails.city) }
    var editState by remember(state.shippingDetails) { mutableStateOf(state.shippingDetails.state) }
    var editPostal by remember(state.shippingDetails) { mutableStateOf(state.shippingDetails.postalCode) }

    var selectedShippingSpeed by remember { mutableStateOf("express") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Breadcrumb & Security Status
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clickable { onBackToStore() }
                            .testTag("back_to_store_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Store",
                            tint = CyberPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "STOREFRONT > CART > DISPATCH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CyberPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = CyberSecondary,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "TLS 1.3 // 256-BIT ENCRYPTED TUNNEL",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CyberSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }

            // Stepper Indicator (01 VERIFIED, 02 ACTIVE INGESTION, 03 QUEUED)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberSurfaceContainerLow)
                        .border(1.dp, CyberOutlineVariant.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                        .padding(vertical = 10.dp, horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StepPill("01", "VERIFIED", isDone = true, isActive = false)
                    Box(modifier = Modifier.width(16.dp).height(1.dp).background(CyberOutlineVariant))
                    StepPill("02", "ACTIVE INGESTION", isDone = false, isActive = true)
                    Box(modifier = Modifier.width(16.dp).height(1.dp).background(CyberOutlineVariant))
                    StepPill("03", "QUEUED", isDone = false, isActive = false)
                }
            }

            // Step 1: Verified Shipping Destination Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(CyberSurfaceContainerLow)
                        .border(1.dp, CyberOutlineVariant.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = CyberSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "1. VERIFIED SHIPPING DESTINATION",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            IconButton(
                                onClick = onToggleShippingEdit,
                                modifier = Modifier.size(30.dp).testTag("edit_shipping_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit shipping",
                                    tint = CyberPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        if (!state.isEditingShipping) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = state.shippingDetails.summaryContact(),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 13.sp
                                    )
                                )
                                Text(
                                    text = state.shippingDetails.summaryAddress(),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        } else {
                            // Inline Address Editor Form
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                CyberInputField("Street Address", editStreet) { editStreet = it }
                                CyberInputField("Suite / Unit", editSuite) { editSuite = it }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        CyberInputField("City", editCity) { editCity = it }
                                    }
                                    Box(modifier = Modifier.weight(0.5f)) {
                                        CyberInputField("State", editState) { editState = it }
                                    }
                                    Box(modifier = Modifier.weight(0.7f)) {
                                        CyberInputField("Zip", editPostal) { editPostal = it }
                                    }
                                }

                                Button(
                                    onClick = {
                                        onSaveShipping(
                                            state.shippingDetails.copy(
                                                street = editStreet,
                                                suite = editSuite,
                                                city = editCity,
                                                state = editState,
                                                postalCode = editPostal
                                            )
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CyberPrimary,
                                        contentColor = CyberOnPrimary
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth().height(40.dp)
                                ) {
                                    Text("SAVE DESTINATION TELEMETRY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Step 2: Active Ingestion: Payment Method Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(CyberSurfaceContainerLow)
                        .border(1.dp, CyberPrimary.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(CyberPrimary)
                            )
                            Text(
                                text = "2. ACTIVE INGESTION: PAYMENT METHOD",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Method Selectors: Credit Card, Apple Pay, Crypto Pay
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PaymentMethodPill(
                                label = "Credit Card",
                                icon = Icons.Default.CreditCard,
                                isSelected = state.paymentMethod == "Credit Card",
                                onClick = { onSelectPaymentMethod("Credit Card") },
                                modifier = Modifier.weight(1f)
                            )
                            PaymentMethodPill(
                                label = "Apple Pay",
                                icon = Icons.Default.PhoneIphone,
                                isSelected = state.paymentMethod == "Apple Pay",
                                onClick = { onSelectPaymentMethod("Apple Pay") },
                                modifier = Modifier.weight(1f)
                            )
                            PaymentMethodPill(
                                label = "Crypto Pay",
                                icon = Icons.Default.CurrencyBitcoin,
                                isSelected = state.paymentMethod == "Crypto Pay",
                                onClick = { onSelectPaymentMethod("Crypto Pay") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Holographic Card Visual Preview
                        HolographicCard(
                            cardNumber = state.cardNumber,
                            cardHolder = state.cardName,
                            expiry = state.cardExpiry
                        )

                        // Form Fields
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            CyberInputField(
                                label = "CARD NUMBER (AUTO-FORMAT ACTIVE)",
                                value = state.cardNumber,
                                onValueChange = {
                                    onUpdateCardDetails(it, state.cardName, state.cardExpiry, state.cardCvc)
                                }
                            )

                            CyberInputField(
                                label = "NAME ON CARD",
                                value = state.cardName,
                                onValueChange = {
                                    onUpdateCardDetails(state.cardNumber, it, state.cardExpiry, state.cardCvc)
                                }
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(modifier = Modifier.weight(1f)) {
                                    CyberInputField(
                                        label = "EXPIRATION",
                                        value = state.cardExpiry,
                                        onValueChange = {
                                            onUpdateCardDetails(state.cardNumber, state.cardName, it, state.cardCvc)
                                        }
                                    )
                                }
                                Box(modifier = Modifier.weight(1f)) {
                                    CyberInputField(
                                        label = "SECURITY CVC",
                                        value = state.cardCvc,
                                        onValueChange = {
                                            onUpdateCardDetails(state.cardNumber, state.cardName, state.cardExpiry, it)
                                        }
                                    )
                                }
                            }
                        }

                        // 1-Click Vault Checkbox
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleVault(!state.storeEncryptedToken) }
                        ) {
                            Checkbox(
                                checked = state.storeEncryptedToken,
                                onCheckedChange = { onToggleVault(it) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = CyberPrimary,
                                    uncheckedColor = CyberOutline
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Store encrypted token in Nexus 1-Click Vault for instant priority access",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }
            }

            // Step 3: Dispatch Review & Final Authorization Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(CyberSurfaceContainerLow)
                        .border(1.dp, CyberOutlineVariant.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(
                            text = "3. VERIFY PROTOCOL & DISPATCH SPEED",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Radio Options for Dispatch Speed
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberSurfaceContainer)
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedShippingSpeed = "express" },
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = selectedShippingSpeed == "express",
                                        onClick = { selectedShippingSpeed = "express" },
                                        colors = RadioButtonDefaults.colors(selectedColor = CyberSecondary)
                                    )
                                    Column {
                                        Text(
                                            text = "Priority Cyber Freight (1-2 Days)",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            ),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Direct airport hub injection with live GPS telemetry",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = CyberOutline,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }
                                Text(
                                    text = "FREE",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CyberSecondary,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }

                        // Big Primary Action Button: AUTHORIZE & PLACE ORDER
                        Button(
                            onClick = onAuthorizeOrder,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberPrimary,
                                contentColor = CyberOnPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("authorize_order_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "AUTHORIZE & PLACE ORDER ($${String.format("%.2f", state.totalAmount)})",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                )
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Text(
                            text = "By authorizing, you agree to the Nexus Hardware Protocol and esports SLA. Charge will appear as NEXUS*TITAN CORE.",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CyberOutline,
                                fontSize = 10.sp
                            ),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Order Telemetry Card
            item {
                OrderTelemetryCard(
                    state = state,
                    onApplyPromo = onApplyPromo
                )
            }
        }
    }
}

@Composable
private fun StepPill(number: String, title: String, isDone: Boolean, isActive: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(
                    if (isDone) CyberSecondary
                    else if (isActive) CyberPrimary
                    else CyberSurfaceContainerHigh
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isDone) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = CyberSurfaceContainerLowest,
                    modifier = Modifier.size(12.dp)
                )
            } else {
                Text(
                    text = number,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) CyberOnPrimary else CyberOutline
                    )
                )
            }
        }

        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isActive || isDone) FontWeight.Bold else FontWeight.Medium,
                color = if (isActive) CyberPrimary else if (isDone) CyberSecondary else CyberOutline,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
private fun PaymentMethodPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CyberSurfaceContainerHigh else CyberSurfaceContainer)
            .border(
                1.dp,
                if (isSelected) CyberPrimary else CyberOutlineVariant.copy(alpha = 0.35f),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) CyberPrimary else CyberOutline,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else CyberOutline,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
private fun CyberInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                color = CyberOutline
            )
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            textStyle = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            ),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberPrimary,
                unfocusedBorderColor = CyberOutlineVariant,
                focusedContainerColor = CyberSurfaceContainer,
                unfocusedContainerColor = CyberSurfaceContainer
            )
        )
    }
}
