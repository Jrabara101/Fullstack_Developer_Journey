package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF131316)
val CyberSurface = Color(0xFF131316)
val CyberSurfaceDim = Color(0xFF131316)
val CyberSurfaceBright = Color(0xFF39393C)
val CyberSurfaceContainerLowest = Color(0xFF0E0E11)
val CyberSurfaceContainerLow = Color(0xFF1B1B1E)
val CyberSurfaceContainer = Color(0xFF1F1F22)
val CyberSurfaceContainerHigh = Color(0xFF2A2A2D)
val CyberSurfaceContainerHighest = Color(0xFF353438)

val CyberOnSurface = Color(0xFFE4E1E6)
val CyberOnSurfaceVariant = Color(0xFFC7C4D7)
val CyberOutline = Color(0xFF908FA0)
val CyberOutlineVariant = Color(0xFF464554)

val CyberPrimary = Color(0xFFC0C1FF)
val CyberOnPrimary = Color(0xFF1000A9)
val CyberPrimaryContainer = Color(0xFF8083FF)
val CyberOnPrimaryContainer = Color(0xFF0D0096)
val CyberInversePrimary = Color(0xFF494BD6)

val CyberSecondary = Color(0xFF4EDEA3) // Emerald neon
val CyberOnSecondary = Color(0xFF003824)
val CyberSecondaryContainer = Color(0xFF00A572)
val CyberOnSecondaryContainer = Color(0xFF00311F)

val CyberTertiary = Color(0xFFFFB783)
val CyberOnTertiary = Color(0xFF4F2500)
val CyberTertiaryContainer = Color(0xFFD97721)

val CyberError = Color(0xFFFFB4AB)
val CyberOnError = Color(0xFF690005)
val CyberErrorContainer = Color(0xFF93000A)
val CyberOnErrorContainer = Color(0xFFFFDAD6)

