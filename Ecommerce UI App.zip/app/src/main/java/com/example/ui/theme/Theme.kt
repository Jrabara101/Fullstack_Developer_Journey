package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CyberDarkColorScheme = darkColorScheme(
    primary = CyberPrimary,
    onPrimary = CyberOnPrimary,
    primaryContainer = CyberPrimaryContainer,
    onPrimaryContainer = CyberOnPrimaryContainer,
    inversePrimary = CyberInversePrimary,
    secondary = CyberSecondary,
    onSecondary = CyberOnSecondary,
    secondaryContainer = CyberSecondaryContainer,
    onSecondaryContainer = CyberOnSecondaryContainer,
    tertiary = CyberTertiary,
    onTertiary = CyberOnTertiary,
    tertiaryContainer = CyberTertiaryContainer,
    background = CyberBackground,
    onBackground = CyberOnSurface,
    surface = CyberSurface,
    onSurface = CyberOnSurface,
    surfaceVariant = CyberSurfaceContainerHighest,
    onSurfaceVariant = CyberOnSurfaceVariant,
    surfaceContainerLowest = CyberSurfaceContainerLowest,
    surfaceContainerLow = CyberSurfaceContainerLow,
    surfaceContainer = CyberSurfaceContainer,
    surfaceContainerHigh = CyberSurfaceContainerHigh,
    surfaceContainerHighest = CyberSurfaceContainerHighest,
    outline = CyberOutline,
    outlineVariant = CyberOutlineVariant,
    error = CyberError,
    onError = CyberOnError,
    errorContainer = CyberErrorContainer,
    onErrorContainer = CyberOnErrorContainer
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = CyberDarkColorScheme,
        typography = Typography,
        content = content
    )
}

