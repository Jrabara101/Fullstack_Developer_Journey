package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.CartItem
import com.example.model.Product
import com.example.model.ProductRepository
import com.example.model.ShippingDetails
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen {
    STOREFRONT,
    CHECKOUT
}

data class NexusUiState(
    val currentScreen: Screen = Screen.STOREFRONT,
    val selectedCategory: String = "all",
    val searchQuery: String = "",
    val cartItems: List<CartItem> = ProductRepository.getInitialCart(),
    val isCartDrawerOpen: Boolean = false,
    val toastMessage: String? = null,
    val toastSubtitle: String? = null,
    val isToastVisible: Boolean = false,
    // Checkout state
    val checkoutStep: Int = 2, // 1: Shipping, 2: Payment, 3: Review
    val isEditingShipping: Boolean = false,
    val shippingDetails: ShippingDetails = ShippingDetails(),
    val paymentMethod: String = "Credit Card", // "Credit Card", "Apple Pay", "Crypto Pay"
    val cardNumber: String = "4532 8812 9043 8842",
    val cardName: String = "Alex Chen",
    val cardExpiry: String = "09 / 28",
    val cardCvc: String = "842",
    val storeEncryptedToken: Boolean = true,
    val promoCode: String = "ESPORTS_PRO",
    val isPromoApplied: Boolean = true,
    val isOrderSuccessDialogOpen: Boolean = false,
    val lastOrderCode: String = "NX-9043-ALPHA",
    val isSpecsModalOpen: Boolean = false,
    val isSupportModalOpen: Boolean = false
) {
    val totalCartCount: Int get() = cartItems.sumOf { it.quantity }
    val subtotal: Double get() = cartItems.sumOf { it.totalPrice }
    val taxRate: Double get() = 0.07
    val estimatedTax: Double get() = subtotal * taxRate
    // Free shipping threshold target $400.00
    val freeShippingTarget: Double get() = 400.00
    val amountToFreeShipping: Double get() = (freeShippingTarget - subtotal).coerceAtLeast(0.0)
    val freeShippingProgress: Float get() = if (freeShippingTarget > 0) {
        (subtotal / freeShippingTarget).coerceIn(0.0, 1.0).toFloat()
    } else 1f

    val shippingFee: Double get() = if (subtotal >= freeShippingTarget || isPromoApplied) 0.0 else 25.0
    val totalAmount: Double get() = subtotal + estimatedTax + shippingFee

    val filteredProducts: List<Product> get() {
        val list = if (selectedCategory == "all") {
            ProductRepository.products
        } else {
            ProductRepository.products.filter { it.category == selectedCategory }
        }
        return if (searchQuery.isBlank()) {
            list
        } else {
            list.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.specs.contains(searchQuery, ignoreCase = true)
            }
        }
    }
}

class NexusStoreViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(NexusUiState())
    val uiState: StateFlow<NexusUiState> = _uiState.asStateFlow()

    private var toastJob: Job? = null

    fun navigateTo(screen: Screen) {
        _uiState.update { it.copy(currentScreen = screen, isCartDrawerOpen = false) }
    }

    fun setCategory(category: String) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun toggleCartDrawer(open: Boolean? = null) {
        _uiState.update {
            val next = open ?: !it.isCartDrawerOpen
            it.copy(isCartDrawerOpen = next)
        }
    }

    fun addToCart(product: Product) {
        _uiState.update { state ->
            val existingIndex = state.cartItems.indexOfFirst { it.product.id == product.id }
            val updatedItems = if (existingIndex != -1) {
                state.cartItems.toMutableList().also { list ->
                    val item = list[existingIndex]
                    list[existingIndex] = item.copy(quantity = item.quantity + 1)
                }
            } else {
                state.cartItems + CartItem(product = product, variant = product.variant, quantity = 1)
            }
            state.copy(cartItems = updatedItems)
        }
        showToast("Item added: ${product.title}", "CART SYNCHRONIZED")
    }

    fun updateQuantity(productId: String, delta: Int) {
        _uiState.update { state ->
            val updated = state.cartItems.mapNotNull { item ->
                if (item.product.id == productId) {
                    val newQty = item.quantity + delta
                    if (newQty > 0) item.copy(quantity = newQty) else null
                } else {
                    item
                }
            }
            state.copy(cartItems = updated)
        }
    }

    fun removeCartItem(productId: String) {
        _uiState.update { state ->
            state.copy(cartItems = state.cartItems.filterNot { it.product.id == productId })
        }
    }

    fun showToast(message: String, title: String = "CART SYNCHRONIZED") {
        toastJob?.cancel()
        _uiState.update {
            it.copy(
                toastMessage = message,
                toastSubtitle = title,
                isToastVisible = true
            )
        }
        toastJob = viewModelScope.launch {
            delay(3200)
            _uiState.update { it.copy(isToastVisible = false) }
        }
    }

    fun dismissToast() {
        toastJob?.cancel()
        _uiState.update { it.copy(isToastVisible = false) }
    }

    fun toggleShippingEdit(editing: Boolean? = null) {
        _uiState.update { it.copy(isEditingShipping = editing ?: !it.isEditingShipping) }
    }

    fun updateShippingDetails(details: ShippingDetails) {
        _uiState.update {
            it.copy(shippingDetails = details, isEditingShipping = false)
        }
        showToast("Shipping address confirmed", "TELEMETRY UPDATED")
    }

    fun setPaymentMethod(method: String) {
        _uiState.update { it.copy(paymentMethod = method) }
    }

    fun updateCardInfo(number: String, name: String, expiry: String, cvc: String) {
        _uiState.update {
            it.copy(
                cardNumber = number,
                cardName = name,
                cardExpiry = expiry,
                cardCvc = cvc
            )
        }
    }

    fun setStoreEncryptedToken(store: Boolean) {
        _uiState.update { it.copy(storeEncryptedToken = store) }
    }

    fun applyPromoCode(code: String) {
        if (code.trim().equals("ESPORTS_PRO", ignoreCase = true)) {
            _uiState.update {
                it.copy(promoCode = "ESPORTS_PRO", isPromoApplied = true)
            }
            showToast("ESPORTS_PRO applied (VIP Tier Active • Free Global Shipping)", "ACCESS PROTOCOL")
        } else {
            showToast("Invalid authorization code", "ERROR")
        }
    }

    fun authorizeAndPlaceOrder() {
        val randomDigits = (1000..9999).random()
        _uiState.update {
            it.copy(
                isOrderSuccessDialogOpen = true,
                lastOrderCode = "NX-$randomDigits-ALPHA"
            )
        }
    }

    fun dismissOrderSuccess() {
        _uiState.update {
            it.copy(
                isOrderSuccessDialogOpen = false,
                cartItems = emptyList(),
                currentScreen = Screen.STOREFRONT
            )
        }
    }

    fun toggleSpecsModal(open: Boolean) {
        _uiState.update { it.copy(isSpecsModalOpen = open) }
    }

    fun toggleSupportModal(open: Boolean) {
        _uiState.update { it.copy(isSupportModalOpen = open) }
    }
}
