package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.viewmodel.NexusStoreViewModel
import com.example.viewmodel.Screen
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Nexus Core", appName)
    }

    @Test
    fun `initial cart contains expected items and calculates totals`() {
        val viewModel = NexusStoreViewModel()
        val state = viewModel.uiState.value

        assertEquals(2, state.cartItems.size)
        assertEquals(2, state.totalCartCount)
        assertEquals(378.00, state.subtotal, 0.01)
        assertEquals(26.46, state.estimatedTax, 0.01)
        assertEquals(404.46, state.totalAmount, 0.01)
    }

    @Test
    fun `updating cart quantity updates totals`() {
        val viewModel = NexusStoreViewModel()
        val firstItemId = viewModel.uiState.value.cartItems[0].product.id

        viewModel.updateQuantity(firstItemId, 1)
        val state = viewModel.uiState.value
        assertEquals(3, state.totalCartCount)
    }

    @Test
    fun `navigation between storefront and checkout works`() {
        val viewModel = NexusStoreViewModel()
        assertEquals(Screen.STOREFRONT, viewModel.uiState.value.currentScreen)

        viewModel.navigateTo(Screen.CHECKOUT)
        assertEquals(Screen.CHECKOUT, viewModel.uiState.value.currentScreen)
    }
}
