---
name: Calm Airflow
colors:
  surface: '#f9f9ff'
  surface-dim: '#d9d9df'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f9'
  surface-container: '#ededf3'
  surface-container-high: '#e8e8ed'
  surface-container-highest: '#e2e2e8'
  on-surface: '#1a1c20'
  on-surface-variant: '#454655'
  inverse-surface: '#2f3035'
  inverse-on-surface: '#f0f0f6'
  outline: '#757686'
  outline-variant: '#c5c5d7'
  surface-tint: '#3c4cdc'
  primary: '#1c2dc4'
  on-primary: '#ffffff'
  primary-container: '#3b4bdb'
  on-primary-container: '#d2d4ff'
  inverse-primary: '#bdc2ff'
  secondary: '#006d44'
  on-secondary: '#ffffff'
  secondary-container: '#93f7be'
  on-secondary-container: '#007349'
  tertiary: '#43464f'
  on-tertiary: '#ffffff'
  tertiary-container: '#5b5e67'
  on-tertiary-container: '#d5d7e2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe0ff'
  primary-fixed-dim: '#bdc2ff'
  on-primary-fixed: '#000865'
  on-primary-fixed-variant: '#1d2ec4'
  secondary-fixed: '#93f7be'
  secondary-fixed-dim: '#77daa4'
  on-secondary-fixed: '#002111'
  on-secondary-fixed-variant: '#005232'
  tertiary-fixed: '#e0e2ed'
  tertiary-fixed-dim: '#c4c6d1'
  on-tertiary-fixed: '#181c23'
  on-tertiary-fixed-variant: '#43474f'
  background: '#f9f9ff'
  on-background: '#1a1c20'
  surface-variant: '#e2e2e8'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  title-md:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  caption-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers an unpretentious, transparent, and quiet travel booking utility. Built around uncompromising honesty, the interface strips out promotional banners, artificial urgency cues, and hidden fare tiers. The emotional posture is grounded, clear, and reassuring—a deliberate antidote to chaotic consumer airline flows.

The aesthetic fuses modern Scandinavian minimalism with hyper-functional Swiss editorial utility:
- **Honest Layouts:** Pricing totals are locked and breakdown-visible from step one. Red text is strictly avoided for exclusions to prevent cognitive panic; muted dashes replace aggressive rejection indicators.
- **Generous Canvas:** Negative space replaces artificial card nesting. White surfaces rest atop warm limestone tinted backdrops.
- **Single Vector Focus:** Exactly one prominent action per viewport. Every secondary choice lives in muted, understated affordances.

## Colors

The palette relies on subtle warmth and functional restraint. Surfaces are rendered with absolute discipline:

- **Canvas Background (`#F6F5F2`):** A warm, tactile limestone off-white that eliminates screen glare while providing subtle contrast beneath pure white cards.
- **Card & Bar Surface (`#FFFFFF`):** Pure optical white used strictly for interactable card containers, bottom sheets, and the bottom anchor bar.
- **Primary Ink (`#14161A`):** Deep carbon black for primary typographic weight, flight codes, and core totals. Never pitch `#000000`.
- **Muted (`#6B7078`):** Balanced slate grey reserved for intermediate stops, baggage labels, secondary metadata, and excluded amenity dashes.
- **Structural Line (`#E3E1DC`):** Low-contrast warm grey hairline stroke for bounding cards, dividers, step connectors, and inactive indicators.
- **Soft Indigo Tint (`#EEF0FB`):** A gentle pale wash applied exclusively to denote selected fare cards and highlighted cabin features.
- **Primary Accent (`#3B4BDB`):** Pure cobalt indigo driving primary CTA buttons, active timeline rings, selected radio points, and progressive forward flow.
- **Included Green (`#1F8A5B`):** Forest jade utilized only for affirmative baggage/meal check marks. Excluded items never use red; they render with a `#6B7078` dash.

## Typography

Typographic discipline provides the structural backbone of this design system. Inter handles all screen roles with strict numeric alignment rules.

- **Tabular Figures (`tnum`):** All numerals—including departure/arrival timestamps, flight durations, layover countdowns, seat assignments, and currency amounts—must enforce OpenType tabular figures (`font-variant-numeric: tabular-nums`). This guarantees decimal and column alignment across flight comparison cards.
- **Hierarchy:**
  - **Display (`28px/34px`):** Final checkout totals and hero airport codes (e.g., `SFO → CPH`).
  - **Title (`20px/26px`):** Step headers and card titles.
  - **Body (`15px/22px`):** Flight specifications, policy disclosures, and confirmation summaries.
  - **Caption (`13px/18px`):** Cabin class subheads, terminal designations, and aircraft types.

## Layout & Spacing

Designed fundamentally around handheld iOS form factors, the grid prioritizes thumb-zone ergonomics and uninterrupted vertical scanning:

- **Canvas Gutters & Margins:** Standard mobile canvas maintains an outer margin of `20px` (`1.25rem`), keeping content away from curved display edges. Internal card gutters standardize on `16px` (`1rem`).
- **Vertical Rhythm:**
  - `space-xs` (4px): Spacing between badge icons and label text.
  - `space-sm` (8px): Distance between flight times and airport codes.
  - `space-md` (16px): Internal padding inside cards and input fields.
  - `space-lg` (20px): Gap between distinct card sections and route segments.
  - `space-xl` (32px): Major step groupings and screen title bottom margins.
- **Fixed Persistent Anchor:** Checkout totals and forward progress actions lock permanently to a docked 80px high bottom bar above the iOS home indicator bar, clearing content with a `100px` scroll clearance buffer.

## Elevation & Depth

This design system rejects skeuomorphic drop shadows, heavy layered blurs, and floating elevations in favor of clean planar contrast:

- **Hairline Framing:** Depth is communicated exclusively via contrast between the `#F6F5F2` canvas and `#FFFFFF` surfaces bounded by a single `1px solid #E3E1DC` border.
- **Zero Cast Shadows:** Cards, buttons, and floating bottom panels feature `box-shadow: none`. Hierarchy is conveyed through boundary lines and surface fills.
- **Selected Surface State:** When a card or option is toggled, its background shifts from `#FFFFFF` to `#EEF0FB` and its border transitions from `#E3E1DC` to `#3B4BDB` (`1.5px`).
- **Modal Sheets:** Slide-up detailed fare breakdowns overlay the canvas with a flat `#14161A` backdrop tint at `24%` opacity, retaining crisp lines and zero ambient glow.

## Shapes

The geometry balances ergonomic tactile touchpoints with crisp card architecture:

- **Cards & Sheets (`16px`):** Main interactive flight cards, price breakdowns, and modal bottom containers strictly use a 16px corner radius.
- **Primary CTA Buttons (`14px`):** Designed to match modern iOS standard tactile controls, the 52px primary action carries a 14px continuous curvature corner radius.
- **Pills & Chips (`9999px`):** All filter chips, flight status badges (e.g., "Nonstop"), and inclusion markers use full circular pill encapsulation.

## Components

### Buttons
- **Primary CTA:** Exactly 52px tall, spanning full container width. Filled with `#3B4BDB`, text rendered in pure white Inter Semibold (`16px`). Radius: `14px`. No shadows.
- **Secondary / Ghost Button:** 44px tall, transparent background with a 1px solid `#E3E1DC` line. Text color is `#14161A`.

### Flight Cards
- 16px border radius, `#FFFFFF` background, wrapped in a 1px solid `#E3E1DC` border.
- Internal layout uses a 3-column row: departure time + code (left), timeline duration line + stop chip (center), arrival time + code (right). Price sits prominently on a unified bottom line in tabular display numerals.
- Selected state adopts an `#EEF0FB` tint and a `#3B4BDB` border.

### Filter & Status Chips
- Full pill shape (`border-radius: 9999px`), 32px height, 12px horizontal padding.
- Unselected: `#FFFFFF` fill with 1px solid `#E3E1DC` line, `#14161A` text.
- Active: `#3B4BDB` fill with white text.

### Inclusions List
- Amenities and allowances (carry-on, checked bag, seat selection, cancellation) display in vertical rows separated by faint dividers.
- **Included:** Vector checkmark rendered in `#1F8A5B` followed by `#14161A` text.
- **Excluded:** A simple em-dash (`—`) rendered in `#6B7078` followed by `#6B7078` text. Red badges or icons are strictly disallowed.

### Form Inputs & Selectors
- 48px height, 12px radius, pure white surface with `#E3E1DC` border.
- Floating metadata label in `#6B7078` (12px), user value in `#14161A` (15px tabular). Focus ring triggers a crisp 1.5px `#3B4BDB` stroke without outer glow.

### Sticky Bottom Anchor
- Anchored to bottom screen, filled with `#FFFFFF` and divided from scrollable content by a `1px solid #E3E1DC` top line.
- Left block displays the immutable all-in final price (Display 28px). Right block holds the 52px Primary CTA button.