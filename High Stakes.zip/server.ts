import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { RoomManager, InternalRoom } from './server/roomManager.ts';
import { createServer as createViteServer } from 'vite';

process.env.DISABLE_HMR = 'true';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const url = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
  if (url.pathname === '/ws' || url.pathname.startsWith('/ws')) {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

const roomManager = new RoomManager();

// Track active sockets
interface ClientConnection {
  ws: WebSocket;
  roomCode?: string;
  playerId?: string;
}

const clients = new Map<WebSocket, ClientConnection>();

function broadcastRoomState(room: InternalRoom) {
  for (const [ws, conn] of clients.entries()) {
    if (conn.roomCode === room.roomCode && ws.readyState === WebSocket.OPEN) {
      const state = roomManager.getClientGameState(room, conn.playerId || '');
      ws.send(JSON.stringify({ type: 'STATE_SYNC', state }));
    }
  }
}

// Global 500ms ticker for turn countdown and bot timers
setInterval(() => {
  for (const roomCode of ['DEMO', ...Array.from(new Set(Array.from(clients.values()).map(c => c.roomCode).filter(Boolean) as string[]))]) {
    const room = roomManager.getRoomByCode(roomCode);
    if (room && (room.phase === 'PLAYER_TURN' || room.phase === 'BLUFF_CHALLENGE')) {
      roomManager.tickTurn(roomCode);
      if (room.phase === 'BLUFF_CHALLENGE') {
        roomManager.runBotBluffCallDecisions(roomCode);
      }
      broadcastRoomState(room);
    }
  }
}, 500);

wss.on('connection', (ws: WebSocket) => {
  const conn: ClientConnection = { ws };
  clients.set(ws, conn);

  ws.on('message', (messageRaw: string) => {
    try {
      const data = JSON.parse(messageRaw.toString());
      const { type, payload } = data;

      switch (type) {
        case 'CREATE_ROOM': {
          const { hostName, avatarUrl } = payload || {};
          const { room, hostPlayerId } = roomManager.createRoom(hostName, avatarUrl);
          conn.roomCode = room.roomCode;
          conn.playerId = hostPlayerId;

          ws.send(JSON.stringify({
            type: 'ROOM_CREATED',
            roomCode: room.roomCode,
            playerId: hostPlayerId
          }));

          broadcastRoomState(room);
          break;
        }

        case 'JOIN_ROOM': {
          const { roomCode, username, avatarUrl, playerId } = payload || {};
          const existingRoom = roomManager.getRoomByCode(roomCode);
          if (!existingRoom) {
            ws.send(JSON.stringify({ type: 'ERROR', message: `Table #${roomCode} not found` }));
            return;
          }

          // Check if reconnecting existing player by playerId OR username
          let player = existingRoom.players.find(p => (playerId && p.id === playerId) || (username && p.username === username && !p.isBot));
          if (!player) {
            const joinRes = roomManager.joinRoom(roomCode, username, avatarUrl);
            if (!joinRes) {
              ws.send(JSON.stringify({ type: 'ERROR', message: 'Table is full (maximum 6 seats)' }));
              return;
            }
            player = joinRes.player;
          }

          conn.roomCode = roomCode;
          conn.playerId = player.id;

          ws.send(JSON.stringify({
            type: 'ROOM_JOINED',
            roomCode: existingRoom.roomCode,
            playerId: player.id
          }));

          broadcastRoomState(existingRoom);
          break;
        }

        case 'START_GAME': {
          if (!conn.roomCode) return;
          const started = roomManager.startGame(conn.roomCode);
          if (started) {
            const room = roomManager.getRoomByCode(conn.roomCode);
            if (room) broadcastRoomState(room);
          }
          break;
        }

        case 'ADD_BOT': {
          if (!conn.roomCode) return;
          const bot = roomManager.addBot(conn.roomCode);
          if (bot) {
            const room = roomManager.getRoomByCode(conn.roomCode);
            if (room) broadcastRoomState(room);
          }
          break;
        }

        case 'PLAY_CARD': {
          if (!conn.roomCode || !conn.playerId) return;
          const { cardId, declaredColor, isBluffPlay } = payload;
          const res = roomManager.playCard(conn.roomCode, conn.playerId, cardId, declaredColor, isBluffPlay);
          if (!res.success) {
            ws.send(JSON.stringify({ type: 'ERROR', message: res.error || 'Invalid move' }));
          } else {
            const room = roomManager.getRoomByCode(conn.roomCode);
            if (room) broadcastRoomState(room);
          }
          break;
        }

        case 'CALL_BLUFF': {
          if (!conn.roomCode || !conn.playerId) return;
          const success = roomManager.callBluff(conn.roomCode, conn.playerId);
          if (success) {
            const room = roomManager.getRoomByCode(conn.roomCode);
            if (room) broadcastRoomState(room);
          }
          break;
        }

        case 'DRAW_CARD': {
          if (!conn.roomCode || !conn.playerId) return;
          const success = roomManager.drawCardAction(conn.roomCode, conn.playerId);
          if (success) {
            const room = roomManager.getRoomByCode(conn.roomCode);
            if (room) broadcastRoomState(room);
          }
          break;
        }

        case 'RAISE_ANTE': {
          if (!conn.roomCode || !conn.playerId) return;
          const { amount } = payload;
          const success = roomManager.raiseAnte(conn.roomCode, conn.playerId, amount);
          if (success) {
            const room = roomManager.getRoomByCode(conn.roomCode);
            if (room) broadcastRoomState(room);
          }
          break;
        }

        case 'PLAY_MELD': {
          if (!conn.roomCode || !conn.playerId) return;
          const { cardIds } = payload;
          const success = roomManager.playMeld(conn.roomCode, conn.playerId, cardIds);
          if (success) {
            const room = roomManager.getRoomByCode(conn.roomCode);
            if (room) broadcastRoomState(room);
          }
          break;
        }

        case 'SEND_EMOTE': {
          if (!conn.roomCode || !conn.playerId) return;
          const { emote } = payload;
          roomManager.sendEmote(conn.roomCode, conn.playerId, emote);
          const room = roomManager.getRoomByCode(conn.roomCode);
          if (room) broadcastRoomState(room);
          break;
        }
      }
    } catch (err) {
      console.error('Error parsing WS message:', err);
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
  });
});

// Create initial demo room for instant access
roomManager.createRoom('Ace Vega', undefined, 'DEMO');
roomManager.addBot('DEMO');
roomManager.addBot('DEMO');
roomManager.startGame('DEMO');

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';
  const PORT = process.env.PORT || 3000;

  if (!isProduction) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Card Arena server running on http://localhost:${PORT}`);
  });
}

startServer();
