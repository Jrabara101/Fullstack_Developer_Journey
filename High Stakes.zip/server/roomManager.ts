import { Card, CardColor, CardGameState, CombatLogEntry, TablePlayer } from '../src/game/types.ts';
import {
  generateDeck,
  shuffleDeck,
  isLegalPlay,
  verifyBluff,
  evaluateMeld,
  getNextPlayerIndex,
  COLORS
} from '../src/game/rules.ts';

export interface InternalPlayer extends TablePlayer {
  hand: Card[];
  wsSessionIds: Set<string>;
}

export interface InternalRoom {
  roomId: string;
  roomCode: string;
  phase: CardGameState['phase'];
  activeColor: CardColor;
  topDiscard: Card | null;
  drawDeck: Card[];
  discardPile: Card[];
  potChips: number;
  currentAnte: number;
  currentTurnPlayerId: string;
  turnTimeRemainingMs: number;
  direction: 1 | -1;
  turnIndex: number;
  players: InternalPlayer[];
  combatLog: CombatLogEntry[];
  bluffChallenge?: {
    initiatorPlayerId: string;
    initiatorName: string;
    card: Card;
    claimedColor: CardColor;
    claimedType: Card['type'];
    timeLeftMs: number;
    challengerPlayerId?: string;
    challengerName?: string;
    isBluff?: boolean;
    resultMessage?: string;
  };
  showdownPayout?: CardGameState['showdownPayout'];
  turnTimerInterval?: NodeJS.Timeout;
}

const AVATARS = [
  'https://api.dicebear.com/7.x/bottts/svg?seed=Ace&backgroundColor=b6e3f4',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Roxy&backgroundColor=ffd5dc',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Viper&backgroundColor=d1d4f9',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Maverick&backgroundColor=c0aede',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Neon&backgroundColor=ffdfbf',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Shadow&backgroundColor=d1f4d9'
];

const BOT_NAMES = ['Ace Vega', 'Roxy Velvet', 'Viper Strike', 'Duke Maverick', 'Slick Neon'];

export class RoomManager {
  private rooms = new Map<string, InternalRoom>();

  public createRoom(hostName: string, avatarUrl?: string, forcedRoomCode?: string): { room: InternalRoom; hostPlayerId: string } {
    const roomCode = (forcedRoomCode || Math.random().toString(36).substring(2, 6)).toUpperCase();
    const roomId = `room_${Date.now()}_${roomCode}`;
    const hostPlayerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const hostPlayer: InternalPlayer = {
      id: hostPlayerId,
      username: hostName || 'Host VIP',
      avatarUrl: avatarUrl || AVATARS[0],
      chips: 2500,
      currentBet: 50,
      cardCount: 0,
      isTurn: false,
      hasPassed: false,
      isHost: true,
      isBot: false,
      hand: [],
      wsSessionIds: new Set(),
    };

    const room: InternalRoom = {
      roomId,
      roomCode,
      phase: 'LOBBY',
      activeColor: 'red',
      topDiscard: null,
      drawDeck: [],
      discardPile: [],
      potChips: 0,
      currentAnte: 50,
      currentTurnPlayerId: hostPlayerId,
      turnTimeRemainingMs: 15000,
      direction: 1,
      turnIndex: 0,
      players: [hostPlayer],
      combatLog: [
        {
          id: `log_${Date.now()}`,
          text: `Table initialized with code #${roomCode}.`,
          timestamp: Date.now(),
          type: 'info',
        },
      ],
    };

    this.rooms.set(roomCode, room);
    return { room, hostPlayerId };
  }

  public getRoomByCode(code: string): InternalRoom | undefined {
    return this.rooms.get(code.toUpperCase());
  }

  public joinRoom(roomCode: string, username: string, avatarUrl?: string): { room: InternalRoom; player: InternalPlayer } | null {
    const room = this.getRoomByCode(roomCode);
    if (!room) return null;

    if (room.players.length >= 6) {
      return null;
    }

    const playerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const avatar = avatarUrl || AVATARS[room.players.length % AVATARS.length];

    const player: InternalPlayer = {
      id: playerId,
      username: username || `HighRoller #${room.players.length + 1}`,
      avatarUrl: avatar,
      chips: 2500,
      currentBet: room.currentAnte,
      cardCount: 0,
      isTurn: false,
      hasPassed: false,
      isHost: false,
      isBot: false,
      hand: [],
      wsSessionIds: new Set(),
    };

    // If game is already in progress, deal 7 cards to the new player and collect ante
    if (room.phase !== 'LOBBY' && room.drawDeck.length >= 7) {
      player.hand = room.drawDeck.splice(0, 7);
      player.cardCount = player.hand.length;
      room.potChips += room.currentAnte;
      player.chips = Math.max(0, player.chips - room.currentAnte);
    }

    room.players.push(player);
    this.addLog(room, `${player.username} pulled up a seat at the table.`, 'info');
    return { room, player };
  }

  public addBot(roomCode: string): InternalPlayer | null {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.players.length >= 6) return null;

    const botIndex = room.players.filter(p => p.isBot).length;
    const botName = BOT_NAMES[botIndex % BOT_NAMES.length];
    const botId = `bot_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    const botPlayer: InternalPlayer = {
      id: botId,
      username: `${botName} [AI]`,
      avatarUrl: AVATARS[(room.players.length + 1) % AVATARS.length],
      chips: 2500,
      currentBet: room.currentAnte,
      cardCount: 0,
      isTurn: false,
      hasPassed: false,
      isHost: false,
      isBot: true,
      hand: [],
      wsSessionIds: new Set(),
    };

    // If game is already running, deal cards to bot
    if (room.phase !== 'LOBBY' && room.drawDeck.length > 7) {
      botPlayer.hand = room.drawDeck.splice(0, 7);
      botPlayer.cardCount = botPlayer.hand.length;
      room.potChips += room.currentAnte;
      botPlayer.chips -= room.currentAnte;
    }

    room.players.push(botPlayer);
    this.addLog(room, `${botPlayer.username} joined the arena.`, 'info');
    return botPlayer;
  }

  public startGame(roomCode: string): boolean {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.players.length < 1) return false;

    // If solo player starts, auto-seed 2 bot players so game is an electrifying showdown!
    while (room.players.length < 3) {
      this.addBot(roomCode);
    }

    const deck = shuffleDeck(generateDeck());
    const ante = room.currentAnte;
    let initialPot = 0;

    // Deal 7 cards to each player and collect ante
    for (const player of room.players) {
      player.hand = deck.splice(0, 7);
      player.cardCount = player.hand.length;
      player.chips = Math.max(0, player.chips - ante);
      player.currentBet = ante;
      player.hasPassed = false;
      initialPot += ante;
    }

    // Flip top card for discard pile
    let firstCard = deck.pop()!;
    while (firstCard.color === 'wild') {
      // Don't start with wild as initial discard
      deck.unshift(firstCard);
      firstCard = deck.pop()!;
    }

    room.drawDeck = deck;
    room.discardPile = [firstCard];
    room.topDiscard = firstCard;
    room.activeColor = firstCard.color;
    room.potChips = initialPot;
    room.phase = 'PLAYER_TURN';
    room.turnIndex = 0;
    room.currentTurnPlayerId = room.players[0].id;
    room.turnTimeRemainingMs = 15000;
    room.direction = 1;
    room.bluffChallenge = undefined;
    room.showdownPayout = undefined;

    this.updatePlayerTurnFlags(room);
    this.addLog(room, `Cards dealt! Top card is [${firstCard.color.toUpperCase()} ${firstCard.type === 'number' ? firstCard.value : firstCard.type}]. Pot: ${initialPot} chips.`, 'play');

    return true;
  }

  public playCard(
    roomCode: string,
    playerId: string,
    cardId: string,
    declaredColor?: CardColor,
    isBluffPlay: boolean = false
  ): { success: boolean; error?: string } {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.phase !== 'PLAYER_TURN') return { success: false, error: 'Not in player turn phase' };
    if (room.currentTurnPlayerId !== playerId) return { success: false, error: 'Not your turn' };

    const player = room.players.find(p => p.id === playerId);
    if (!player) return { success: false, error: 'Player not found' };

    const cardIndex = player.hand.findIndex(c => c.id === cardId);
    if (cardIndex === -1) return { success: false, error: 'Card not in hand' };

    const card = player.hand[cardIndex];

    // BLUFF PLAY: Played face down
    if (isBluffPlay) {
      player.hand.splice(cardIndex, 1);
      player.cardCount = player.hand.length;

      const claimedColor = declaredColor || (card.color === 'wild' ? 'red' : card.color);
      const claimedType = card.type;

      room.phase = 'BLUFF_CHALLENGE';
      room.bluffChallenge = {
        initiatorPlayerId: player.id,
        initiatorName: player.username,
        card,
        claimedColor,
        claimedType,
        timeLeftMs: 5000,
      };

      this.addLog(
        room,
        `${player.username} played a card FACE DOWN claiming [${claimedColor.toUpperCase()} ${claimedType}]. Calling bluff window open (5s)!`,
        'bluff'
      );

      return { success: true };
    }

    // FACE UP PLAY: Validate legality
    const legal = isLegalPlay(card, room.topDiscard, room.activeColor);
    if (!legal) {
      return { success: false, error: 'Illegal card play for current color/value' };
    }

    // Remove from hand and add to discard
    player.hand.splice(cardIndex, 1);
    player.cardCount = player.hand.length;
    room.discardPile.push(card);
    room.topDiscard = card;

    // Handle special effects
    if (card.color === 'wild' || card.type === 'wild' || card.type === 'wild_ante') {
      room.activeColor = declaredColor || 'red';
      if (card.type === 'wild_ante') {
        const anteBump = 100;
        room.currentAnte += anteBump;
        room.potChips += anteBump;
        this.addLog(room, `WILD ANTE played! Pot raised by ${anteBump} to ${room.potChips} chips. New color: ${room.activeColor.toUpperCase()}.`, 'ante');
      } else {
        this.addLog(room, `${player.username} shifted active color to ${room.activeColor.toUpperCase()}.`, 'play');
      }
    } else {
      room.activeColor = card.color;
      this.addLog(room, `${player.username} played [${card.color.toUpperCase()} ${card.type === 'number' ? card.value : card.type}].`, 'play');
    }

    // Action cards
    let skipSteps = 1;
    if (card.type === 'skip') {
      skipSteps = 2;
      this.addLog(room, `SKIP! Next player skipped.`, 'play');
    } else if (card.type === 'reverse') {
      room.direction = (room.direction * -1) as 1 | -1;
      this.addLog(room, `REVERSE! Table rotation inverted.`, 'play');
      if (room.players.length === 2) {
        skipSteps = 2;
      }
    } else if (card.type === 'draw_two') {
      const victimIdx = getNextPlayerIndex(room.turnIndex, room.players.length, room.direction, 1);
      const victim = room.players[victimIdx];
      this.drawCardsForPlayer(room, victim, 2);
      skipSteps = 2;
      this.addLog(room, `DRAW TWO! ${victim.username} drew 2 penalty cards and lost their turn.`, 'play');
    }

    // Check round victory
    if (player.hand.length === 0) {
      this.handleRoundVictory(room, player, 'Hand Cleared (UNO Showdown!)', [card]);
      return { success: true };
    }

    // Advance turn
    this.advanceTurn(room, skipSteps);
    return { success: true };
  }

  public callBluff(roomCode: string, challengerPlayerId: string): boolean {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.phase !== 'BLUFF_CHALLENGE' || !room.bluffChallenge) return false;

    const challenger = room.players.find(p => p.id === challengerPlayerId);
    const initiator = room.players.find(p => p.id === room.bluffChallenge.initiatorPlayerId);
    if (!challenger || !initiator || challenger.id === initiator.id) return false;

    const challenge = room.bluffChallenge;
    const card = challenge.card;

    // Check if the card was actually a bluff
    const isBluff = verifyBluff(card, room.activeColor, room.topDiscard);

    challenge.challengerPlayerId = challenger.id;
    challenge.challengerName = challenger.username;
    challenge.isBluff = isBluff;

    if (isBluff) {
      // INITIATOR CAUGHT BLUFFING!
      challenge.resultMessage = `BLUFF CALLED! ${initiator.username} was bluffing with [${card.color.toUpperCase()} ${card.type === 'number' ? card.value : card.type}]. Penalty: Draws 4 cards!`;
      this.drawCardsForPlayer(room, initiator, 4);
      // Card is burned
      this.addLog(room, challenge.resultMessage, 'bluff');
    } else {
      // INITIATOR WAS GENUINE! CHALLENGER PAYS PENALTY!
      const penaltyChips = room.currentAnte * 2;
      challenger.chips = Math.max(0, challenger.chips - penaltyChips);
      room.potChips += penaltyChips;
      this.drawCardsForPlayer(room, challenger, 2);

      // Card legally lands on discard pile
      room.discardPile.push(card);
      room.topDiscard = card;
      room.activeColor = challenge.claimedColor;

      challenge.resultMessage = `GENUINE PLAY! ${initiator.username} was telling the truth with [${card.color.toUpperCase()} ${card.type === 'number' ? card.value : card.type}]. ${challenger.username} drew 2 cards and paid ${penaltyChips} chips!`;
      this.addLog(room, challenge.resultMessage, 'bluff');
    }

    room.phase = 'ROUND_RESOLVE';

    setTimeout(() => {
      if (room.phase === 'ROUND_RESOLVE') {
        room.bluffChallenge = undefined;
        room.phase = 'PLAYER_TURN';
        this.advanceTurn(room, 1);
      }
    }, 2500);

    return true;
  }

  public resolveBluffTimeout(roomCode: string) {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.phase !== 'BLUFF_CHALLENGE' || !room.bluffChallenge) return;

    const challenge = room.bluffChallenge;
    const initiator = room.players.find(p => p.id === challenge.initiatorPlayerId);
    const card = challenge.card;

    this.addLog(
      room,
      `No one challenged! ${challenge.initiatorName}'s hidden card took effect cleanly.`,
      'bluff'
    );

    // Card takes effect
    room.discardPile.push(card);
    room.topDiscard = card;
    room.activeColor = challenge.claimedColor;

    if (initiator && initiator.hand.length === 0) {
      this.handleRoundVictory(room, initiator, 'Sneak Bluff Finish!', [card]);
      return;
    }

    room.bluffChallenge = undefined;
    room.phase = 'PLAYER_TURN';
    this.advanceTurn(room, 1);
  }

  public drawCardAction(roomCode: string, playerId: string): boolean {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.phase !== 'PLAYER_TURN' || room.currentTurnPlayerId !== playerId) return false;

    const player = room.players.find(p => p.id === playerId);
    if (!player) return false;

    const [drawn] = this.drawCardsForPlayer(room, player, 1);
    if (drawn) {
      this.addLog(room, `${player.username} drew a card from the deck.`, 'play');
    }
    this.advanceTurn(room, 1);
    return true;
  }

  public raiseAnte(roomCode: string, playerId: string, amount: number): boolean {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.phase !== 'PLAYER_TURN') return false;

    const player = room.players.find(p => p.id === playerId);
    if (!player || player.chips < amount) return false;

    player.chips -= amount;
    player.currentBet += amount;
    room.potChips += amount;
    room.currentAnte += Math.floor(amount / 2);

    this.addLog(room, `${player.username} raised the ante by ${amount} chips! Total Pot: ${room.potChips} 🪙`, 'ante');
    return true;
  }

  public playMeld(roomCode: string, playerId: string, cardIds: string[]): boolean {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.phase !== 'PLAYER_TURN' || room.currentTurnPlayerId !== playerId) return false;

    const player = room.players.find(p => p.id === playerId);
    if (!player) return false;

    const meldCards = player.hand.filter(c => cardIds.includes(c.id));
    if (meldCards.length < 3) return false;

    const evaluation = evaluateMeld(meldCards);
    if (!evaluation.isMeld) return false;

    // Remove meld cards from hand
    player.hand = player.hand.filter(c => !cardIds.includes(c.id));
    player.cardCount = player.hand.length;

    // Discard top card of the meld
    const topMeld = meldCards[meldCards.length - 1];
    room.discardPile.push(...meldCards);
    room.topDiscard = topMeld;
    if (topMeld.color !== 'wild') {
      room.activeColor = topMeld.color;
    }

    const wonPot = Math.min(room.potChips, Math.floor(room.potChips * (evaluation.multiplier > 2 ? 0.75 : 0.5)));
    player.chips += wonPot;
    room.potChips -= wonPot;

    this.addLog(
      room,
      `COMBO SWEEP! ${player.username} melded a ${evaluation.name} and swept ${wonPot} chips from the pot!`,
      'win'
    );

    if (player.hand.length === 0) {
      this.handleRoundVictory(room, player, evaluation.name, meldCards);
      return true;
    }

    this.advanceTurn(room, 1);
    return true;
  }

  public sendEmote(roomCode: string, playerId: string, emote: string): void {
    const room = this.getRoomByCode(roomCode);
    if (!room) return;
    const player = room.players.find(p => p.id === playerId);
    if (!player) return;

    this.addLog(room, `${player.username} ${emote}`, 'info');
  }

  public tickTurn(roomCode: string): void {
    const room = this.getRoomByCode(roomCode);
    if (!room) return;

    if (room.phase === 'BLUFF_CHALLENGE' && room.bluffChallenge) {
      room.bluffChallenge.timeLeftMs = Math.max(0, room.bluffChallenge.timeLeftMs - 500);
      if (room.bluffChallenge.timeLeftMs <= 0) {
        this.resolveBluffTimeout(roomCode);
      }
      return;
    }

    if (room.phase === 'PLAYER_TURN') {
      room.turnTimeRemainingMs = Math.max(0, room.turnTimeRemainingMs - 500);

      // Bot Turn AI Logic
      const currentTurnPlayer = room.players.find(p => p.id === room.currentTurnPlayerId);
      if (currentTurnPlayer && currentTurnPlayer.isBot && room.turnTimeRemainingMs <= 13500) {
        this.runBotTurn(room, currentTurnPlayer);
        return;
      }

      // Turn timeout: Auto-draw or auto-fold
      if (room.turnTimeRemainingMs <= 0) {
        if (currentTurnPlayer) {
          this.addLog(room, `${currentTurnPlayer.username} timed out and auto-drew a card.`, 'info');
          this.drawCardAction(roomCode, currentTurnPlayer.id);
        }
      }
    }
  }

  private runBotTurn(room: InternalRoom, bot: InternalPlayer) {
    // 1. Check for melds (Flush or Straight)
    if (bot.hand.length >= 3) {
      for (const color of COLORS) {
        const sameColorCards = bot.hand.filter(c => c.color === color);
        if (sameColorCards.length >= 3) {
          this.playMeld(room.roomCode, bot.id, sameColorCards.slice(0, 3).map(c => c.id));
          return;
        }
      }
    }

    // 2. Check for legal playable cards
    const legalCards = bot.hand.filter(c => isLegalPlay(c, room.topDiscard, room.activeColor));

    // 20% bluff chance if bot has no legal play or has 4+ cards
    const wantsToBluff = Math.random() < 0.25 && bot.hand.length > 2;

    if (wantsToBluff && bot.hand.length > 0) {
      // Pick a card to bluff
      const bluffCard = bot.hand[Math.floor(Math.random() * bot.hand.length)];
      this.playCard(room.roomCode, bot.id, bluffCard.id, room.activeColor, true);
      return;
    }

    if (legalCards.length > 0) {
      // Prefer action cards or wild cards
      const chosen = legalCards[Math.floor(Math.random() * legalCards.length)];
      const colorChoices: CardColor[] = ['red', 'blue', 'green', 'yellow'];
      const chosenColor = colorChoices[Math.floor(Math.random() * colorChoices.length)];
      this.playCard(room.roomCode, bot.id, chosen.id, chosenColor, false);
      return;
    }

    // Otherwise, draw card
    this.drawCardAction(room.roomCode, bot.id);
  }

  public runBotBluffCallDecisions(roomCode: string) {
    const room = this.getRoomByCode(roomCode);
    if (!room || room.phase !== 'BLUFF_CHALLENGE' || !room.bluffChallenge) return;

    // Bots have 35% chance to call a bluff
    for (const player of room.players) {
      if (player.isBot && player.id !== room.bluffChallenge.initiatorPlayerId) {
        if (Math.random() < 0.35) {
          this.callBluff(roomCode, player.id);
          break;
        }
      }
    }
  }

  private advanceTurn(room: InternalRoom, steps: number = 1): void {
    room.turnIndex = getNextPlayerIndex(room.turnIndex, room.players.length, room.direction, steps);
    room.currentTurnPlayerId = room.players[room.turnIndex].id;
    room.turnTimeRemainingMs = 15000;
    this.updatePlayerTurnFlags(room);
  }

  private updatePlayerTurnFlags(room: InternalRoom): void {
    for (const p of room.players) {
      p.isTurn = p.id === room.currentTurnPlayerId;
    }
  }

  private drawCardsForPlayer(room: InternalRoom, player: InternalPlayer, count: number): Card[] {
    const drawn: Card[] = [];
    for (let i = 0; i < count; i++) {
      if (room.drawDeck.length === 0) {
        if (room.discardPile.length > 1) {
          const top = room.discardPile.pop()!;
          room.drawDeck = shuffleDeck(room.discardPile);
          room.discardPile = [top];
        } else {
          break;
        }
      }
      const card = room.drawDeck.pop();
      if (card) {
        player.hand.push(card);
        drawn.push(card);
      }
    }
    player.cardCount = player.hand.length;
    return drawn;
  }

  private handleRoundVictory(room: InternalRoom, winner: InternalPlayer, comboName: string, winningCards: Card[]): void {
    const pot = room.potChips;
    winner.chips += pot;
    room.potChips = 0;
    room.phase = 'SHOWDOWN_PAYOUT';

    room.showdownPayout = {
      winnerPlayerId: winner.id,
      winnerName: winner.username,
      amount: pot,
      comboName,
      winningCards,
    };

    this.addLog(
      room,
      `🏆 VICTORY SHOWDOWN! ${winner.username} wins ${pot} chips with "${comboName}"!`,
      'win'
    );
  }

  private addLog(room: InternalRoom, text: string, type: CombatLogEntry['type'] = 'info'): void {
    room.combatLog.unshift({
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      text,
      timestamp: Date.now(),
      type,
    });
    if (room.combatLog.length > 40) {
      room.combatLog.pop();
    }
  }

  /**
   * Cryptographic Fog of War state masking.
   * Client NEVER receives other players' cards!
   */
  public getClientGameState(room: InternalRoom, requestingPlayerId: string): CardGameState {
    const maskedPlayers: TablePlayer[] = room.players.map(p => {
      const isSelf = p.id === requestingPlayerId;
      return {
        id: p.id,
        username: p.username,
        avatarUrl: p.avatarUrl,
        chips: p.chips,
        currentBet: p.currentBet,
        cardCount: p.hand.length,
        isTurn: p.isTurn,
        hasPassed: p.hasPassed,
        isHost: p.isHost,
        isBot: p.isBot,
        // Fog of war: Only self sees private hand!
        hand: isSelf ? [...p.hand] : undefined,
      };
    });

    return {
      roomId: room.roomId,
      roomCode: room.roomCode,
      phase: room.phase,
      activeColor: room.activeColor,
      topDiscard: room.topDiscard,
      drawDeckCount: room.drawDeck.length,
      potChips: room.potChips,
      currentAnte: room.currentAnte,
      currentTurnPlayerId: room.currentTurnPlayerId,
      turnTimeRemainingMs: room.turnTimeRemainingMs,
      direction: room.direction,
      bluffChallenge: room.bluffChallenge
        ? {
            initiatorPlayerId: room.bluffChallenge.initiatorPlayerId,
            initiatorName: room.bluffChallenge.initiatorName,
            playedCardMasked: true,
            // Reveal card only once resolved
            card: room.phase === 'ROUND_RESOLVE' ? room.bluffChallenge.card : undefined as any,
            claimedColor: room.bluffChallenge.claimedColor,
            claimedType: room.bluffChallenge.claimedType,
            timeLeftMs: room.bluffChallenge.timeLeftMs,
            challengerPlayerId: room.bluffChallenge.challengerPlayerId,
            challengerName: room.bluffChallenge.challengerName,
            isBluff: room.bluffChallenge.isBluff,
            resultMessage: room.bluffChallenge.resultMessage,
          }
        : undefined,
      showdownPayout: room.showdownPayout,
      players: maskedPlayers,
      myPlayerId: requestingPlayerId,
      combatLog: room.combatLog.slice(0, 25),
    };
  }
}
