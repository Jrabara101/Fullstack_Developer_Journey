import React, { useState, useEffect, useCallback } from 'react';
import { useCardGameSocket } from './hooks/useCardGameSocket';
import { TableBroadcastView } from './components/TableBroadcastView';
import { ControllerView } from './components/ControllerView';
import { BluffModal } from './components/BluffModal';
import { VictoryModal } from './components/VictoryModal';
import { soundEngine } from './utils/audio';
import { Sparkles, Play, Shield, Smartphone, Coins, Users, ArrowRight, Dices } from 'lucide-react';

export default function App() {
  const {
    gameState,
    isConnected,
    lastError,
    createRoom,
    joinRoom,
    startGame,
    addBot,
    playCard,
    callBluff,
    drawCard,
    raiseAnte,
    playMeld,
    sendEmote,
    leaveTable,
  } = useCardGameSocket();

  const [inGame, setInGame] = useState(false);
  const [viewportMode, setViewportMode] = useState<'broadcast' | 'controller'>('broadcast');
  const [username, setUsername] = useState('HighRoller');
  const [joinPin, setJoinPin] = useState('');
  const [joinError, setJoinError] = useState<string | null>(null);

  // Check URL params for ?autostart=1 or ?table=CODE
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const autostart = params.get('autostart');
    const tableParam = params.get('table');
    const modeParam = params.get('mode');

    if (modeParam === 'controller') {
      setViewportMode('controller');
    }

    if (tableParam) {
      setJoinPin(tableParam.toUpperCase());
      joinRoom(tableParam.toUpperCase(), 'Player Guest');
      setInGame(true);
      document.body.dataset.state = 'playing';
    } else if (autostart === '1') {
      handleQuickStart();
    }
  }, [joinRoom]);

  // Keyboard shortcut for Enter/Space to start from Title screen
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!inGame && (e.key === 'Enter' || e.code === 'Space')) {
        // Prevent default spacebar scroll
        if (e.target instanceof HTMLInputElement) return;
        e.preventDefault();
        handleQuickStart();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [inGame]);

  const handleQuickStart = () => {
    document.body.dataset.state = 'playing';
    soundEngine.playCardSnap();
    // Join demo table or create instant table
    joinRoom('DEMO', username || 'VIP Gambler');
    setInGame(true);
  };

  const handleCreatePrivateTable = () => {
    document.body.dataset.state = 'playing';
    soundEngine.playCardSnap();
    createRoom(username || 'Host VIP');
    setInGame(true);
  };

  const handleJoinTable = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinPin.trim()) {
      setJoinError('Please enter a 4-character table code');
      return;
    }
    document.body.dataset.state = 'playing';
    soundEngine.playCardSnap();
    joinRoom(joinPin.trim().toUpperCase(), username || 'Challenger');
    setInGame(true);
  };

  const handleNextHand = () => {
    startGame();
  };

  const myPlayer = gameState?.players.find(p => p.id === gameState.myPlayerId);

  // If in game and game state loaded
  if (inGame && gameState) {
    return (
      <div className="relative w-full min-h-screen bg-[#07130f]">
        {/* Error notification if any */}
        {lastError && (
          <div className="fixed top-4 inset-x-0 mx-auto w-fit z-50 px-4 py-2 rounded-xl bg-red-950/90 border border-red-500 text-red-300 text-xs font-mono shadow-2xl animate-in slide-in-from-top">
            {lastError}
          </div>
        )}

        {/* Viewport Render: Desktop Felt Table vs Mobile Controller */}
        {viewportMode === 'broadcast' ? (
          <TableBroadcastView
            gameState={gameState}
            onPlayCard={playCard}
            onDrawCard={drawCard}
            onRaiseAnte={raiseAnte}
            onPlayMeld={playMeld}
            onCallBluff={callBluff}
            onAddBot={addBot}
            onSwitchToController={() => setViewportMode('controller')}
            onLeaveTable={leaveTable}
            onSendEmote={sendEmote}
          />
        ) : (
          <ControllerView
            gameState={gameState}
            onPlayCard={playCard}
            onDrawCard={drawCard}
            onRaiseAnte={raiseAnte}
            onCallBluff={callBluff}
            onSwitchToTable={() => setViewportMode('broadcast')}
          />
        )}

        {/* Bluff Suspense Alert Modal */}
        {gameState.bluffChallenge && (
          <BluffModal
            challenge={gameState.bluffChallenge}
            myPlayerId={gameState.myPlayerId}
            phase={gameState.phase}
            onCallBluff={callBluff}
          />
        )}

        {/* Round Showdown Payout Modal */}
        {gameState.phase === 'SHOWDOWN_PAYOUT' && gameState.showdownPayout && (
          <VictoryModal
            payout={gameState.showdownPayout}
            isHost={!!myPlayer?.isHost}
            onNextHand={handleNextHand}
          />
        )}
      </div>
    );
  }

  // TITLE SCREEN / LOBBY SHELL
  return (
    <div className="relative min-h-screen w-full bg-casino-felt flex flex-col justify-between items-center px-4 py-8 select-none overflow-hidden">
      {/* Ambient table spotlight lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[400px] h-[300px] bg-amber-500/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Status & Connection indicator */}
      <div className="relative z-10 w-full max-w-5xl flex items-center justify-between text-xs font-mono text-slate-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>Table Engine Online · WebSocket Ready</span>
        </div>
        <div className="flex items-center gap-2">
          <span>Instant Room Play · Zero Install</span>
        </div>
      </div>

      {/* Hero Showcase Centerpiece */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-2xl my-auto">
        {/* Bespoke Emblem / Title Lockup */}
        <div className="mb-4 relative">
          <div className="w-16 h-16 rounded-2xl bg-slate-900/90 border border-amber-500/40 text-amber-400 flex items-center justify-center shadow-[0_0_30px_rgba(234,179,8,0.3)]">
            <Dices className="w-9 h-9 stroke-[2]" />
          </div>
        </div>

        <h1 className="font-display font-black text-4xl sm:text-6xl text-slate-100 tracking-tight leading-none">
          VELVET <span className="text-amber-400">ANTE</span>
        </h1>
        <p className="mt-3 text-sm sm:text-base text-slate-300 max-w-md font-medium leading-relaxed">
          The high-stakes hybrid arena where <span className="text-red-400 font-semibold">Uno color matching</span> collides with <span className="text-amber-300 font-semibold">Poker pot wagering</span> and audacious bluff calls.
        </p>

        {/* Feature Highlights Minimalist Strip */}
        <div className="flex items-center gap-4 sm:gap-6 mt-6 text-xs text-slate-400 font-mono">
          <span className="flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-amber-400" /> Escalating Pot
          </span>
          <span>·</span>
          <span className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-purple-400" /> 5s Bluff Challenge
          </span>
          <span>·</span>
          <span className="flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" /> Dual-Device Play
          </span>
        </div>

        {/* Interactive Seating Action Deck */}
        <div className="mt-8 w-full max-w-md p-5 rounded-3xl bg-slate-950/85 border border-emerald-500/30 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
          {/* Player Username Input */}
          <div className="flex flex-col items-start gap-1">
            <label htmlFor="username-input" className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
              Player Handle
            </label>
            <input
              id="username-input"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. Ace Maverick"
              maxLength={16}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-semibold text-slate-100 focus:outline-none focus:border-amber-400 transition-colors"
            />
          </div>

          {/* Primary Quick Start CTA */}
          <button
            data-start="true"
            onClick={handleQuickStart}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-display font-extrabold text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(16,185,129,0.5)] transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Enter Table Showdown</span>
          </button>

          <div className="relative flex items-center justify-center my-1">
            <div className="border-t border-slate-800 w-full" />
            <span className="bg-slate-950 px-3 text-[10px] font-mono text-slate-500 uppercase">Or</span>
          </div>

          {/* Host Private Table & Join Room PIN */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleCreatePrivateTable}
              className="flex-1 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-xs font-semibold text-slate-200 transition-colors"
            >
              Host Private Room
            </button>

            {/* Join Table PIN form */}
            <form onSubmit={handleJoinTable} className="flex-1 flex items-center gap-1">
              <input
                type="text"
                value={joinPin}
                onChange={(e) => setJoinPin(e.target.value.toUpperCase())}
                placeholder="PIN (4 letters)"
                maxLength={4}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono font-bold text-center uppercase tracking-widest text-amber-300 focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="px-3 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors shrink-0"
              >
                Join
              </button>
            </form>
          </div>

          {joinError && (
            <span className="text-[11px] font-mono text-red-400">{joinError}</span>
          )}
        </div>
      </div>

      {/* Flat borderless control hint line */}
      <footer className="relative z-10 text-center text-xs text-slate-500 font-mono tracking-wide">
        Press Space or Enter to Start · Drag card edge to corner-peek · Flick up to play
      </footer>
    </div>
  );
}
