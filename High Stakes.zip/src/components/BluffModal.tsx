import React from 'react';
import { CardGameState } from '../game/types';
import { Card3D } from './Card3D';
import { ShieldAlert, AlertTriangle, Clock } from 'lucide-react';

interface BluffModalProps {
  challenge: NonNullable<CardGameState['bluffChallenge']>;
  myPlayerId: string;
  phase: CardGameState['phase'];
  onCallBluff: () => void;
}

export const BluffModal: React.FC<BluffModalProps> = ({
  challenge,
  myPlayerId,
  phase,
  onCallBluff,
}) => {
  const isInitiator = challenge.initiatorPlayerId === myPlayerId;
  const isResolved = phase === 'ROUND_RESOLVE' || !!challenge.resultMessage;
  const progressPercent = Math.max(0, Math.min(100, (challenge.timeLeftMs / 5000) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      {/* Warning Vignette Overlay */}
      <div className="absolute inset-0 border-8 border-red-600/40 pointer-events-none animate-pulse" />

      <div className="relative w-full max-w-lg rounded-3xl bg-slate-950 border-2 border-red-500/60 p-6 sm:p-8 flex flex-col items-center text-center shadow-[0_0_60px_rgba(239,68,68,0.5)]">
        {/* Escalating 5-Second Timer Bar */}
        {!isResolved && (
          <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden mb-6 border border-red-500/30">
            <div
              className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-red-500 transition-all duration-300 ease-linear shadow-[0_0_12px_rgba(239,68,68,0.8)]"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        )}

        {/* Header Badge */}
        <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-950/80 border border-red-500/40 text-red-400 text-xs font-mono font-bold tracking-widest uppercase mb-3 shadow">
          <ShieldAlert className="w-4 h-4 text-red-500 animate-bounce" />
          <span>Bluff Challenge Active</span>
        </div>

        {/* Main Claim Text */}
        <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-slate-100 tracking-tight">
          {challenge.initiatorName} played a <span className="text-purple-400">HIDDEN CARD</span>
        </h2>
        <p className="mt-1 text-sm text-slate-400 max-w-md">
          Claimed to be <span className="font-bold text-amber-300 uppercase">{challenge.claimedColor} {challenge.claimedType}</span>. Is it genuine or an audacious bluff?
        </p>

        {/* Face-Down Card Spotlight */}
        <div className="my-6 relative py-2">
          {/* Chromatic spotlight aura */}
          <div className="absolute -inset-4 rounded-2xl bg-purple-600/20 blur-xl pointer-events-none" />

          {isResolved && challenge.card ? (
            <Card3D card={challenge.card} isFaceDown={false} canPeek={false} className="scale-110" />
          ) : (
            <Card3D
              card={{ id: 'hidden', color: challenge.claimedColor, value: 0, type: challenge.claimedType }}
              isFaceDown={true}
              canPeek={false}
              className="scale-110 ring-4 ring-purple-500/50 shadow-[0_0_30px_rgba(168,85,247,0.5)]"
            />
          )}
        </div>

        {/* Result Message or Challenge Action */}
        {isResolved ? (
          <div className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-700 animate-in zoom-in-95 duration-200">
            <span className="text-sm font-semibold text-amber-300">
              {challenge.resultMessage}
            </span>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 w-full">
            <div className="flex items-center gap-1.5 text-xs font-mono text-red-400">
              <Clock className="w-4 h-4 animate-spin" />
              <span>{(challenge.timeLeftMs / 1000).toFixed(1)}s window remaining</span>
            </div>

            {isInitiator ? (
              <div className="px-6 py-2.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-300 text-xs font-medium">
                You laid down this bluff. Sweat it out!
              </div>
            ) : (
              <button
                onClick={onCallBluff}
                className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-display font-extrabold text-base tracking-wide uppercase shadow-[0_0_35px_rgba(239,68,68,0.7)] hover:scale-105 active:scale-95 transition-all"
              >
                Call Bluff!
              </button>
            )}
            <span className="text-[11px] text-slate-500">
              {isInitiator
                ? 'If caught, you draw 4 cards. If unchallenged, you take the trick!'
                : 'Wrong call: Pay 2x ante & draw 2 cards. Right call: Caught player draws 4!'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
