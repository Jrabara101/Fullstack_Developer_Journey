import React, { useState, useRef, useId } from 'react';
import { Card, CardColor } from '../game/types';
import { ArrowLeftRight, Ban, Plus, Sparkles, Flame } from 'lucide-react';

interface Card3DProps {
  card: Card;
  isPlayable?: boolean;
  isSelected?: boolean;
  isFaceDown?: boolean;
  canPeek?: boolean;
  onPlay?: (card: Card) => void;
  onClick?: () => void;
  className?: string;
  style?: React.CSSProperties;
}

const COLOR_MAP: Record<CardColor, { bg: string; text: string; border: string; glow: string }> = {
  red: {
    bg: 'from-rose-950 via-red-900 to-red-950',
    text: 'text-red-400',
    border: 'border-red-500/40',
    glow: 'rgba(239, 68, 68, 0.4)',
  },
  blue: {
    bg: 'from-slate-950 via-blue-900 to-indigo-950',
    text: 'text-blue-400',
    border: 'border-blue-500/40',
    glow: 'rgba(59, 130, 246, 0.4)',
  },
  green: {
    bg: 'from-emerald-950 via-emerald-900 to-teal-950',
    text: 'text-emerald-400',
    border: 'border-emerald-500/40',
    glow: 'rgba(16, 185, 129, 0.4)',
  },
  yellow: {
    bg: 'from-amber-950 via-amber-900 to-yellow-950',
    text: 'text-amber-400',
    border: 'border-amber-500/40',
    glow: 'rgba(245, 158, 11, 0.4)',
  },
  wild: {
    bg: 'from-purple-950 via-fuchsia-900 to-violet-950',
    text: 'text-fuchsia-400',
    border: 'border-fuchsia-500/40',
    glow: 'rgba(168, 85, 247, 0.5)',
  },
};

export const Card3D: React.FC<Card3DProps> = ({
  card,
  isPlayable = false,
  isSelected = false,
  isFaceDown = false,
  canPeek = true,
  onPlay,
  onClick,
  className = '',
  style = {},
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const startPointerRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const patternId = useId();

  // 3D Peeking & Flick states
  const [peekRotation, setPeekRotation] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isFlicking, setIsFlicking] = useState(false);
  const [flickTransform, setFlickTransform] = useState<string>('');

  const colorConfig = COLOR_MAP[card.color] || COLOR_MAP.wild;

  // Pointer down: record starting position for flick or corner-peek
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    startPointerRef.current = {
      x: e.clientX,
      y: e.clientY,
      time: Date.now(),
    };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!startPointerRef.current || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const deltaX = e.clientX - startPointerRef.current.x;
    const deltaY = e.clientY - startPointerRef.current.y;

    // Corner-peeking calculation (localized tilt)
    if (canPeek && isFaceDown) {
      const rotY = Math.max(-45, Math.min(45, (deltaX / rect.width) * 50));
      const rotX = Math.max(-45, Math.min(45, (-deltaY / rect.height) * 50));
      setPeekRotation({ x: rotX, y: rotY });
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!startPointerRef.current) return;
    const deltaX = e.clientX - startPointerRef.current.x;
    const deltaY = e.clientY - startPointerRef.current.y;
    const deltaTime = Math.max(1, Date.now() - startPointerRef.current.time);

    // Calculate flick velocity
    const velocityY = deltaY / deltaTime; // px per ms, negative is upwards
    const isFlickUp = deltaY < -40 || velocityY < -0.4;

    if (isFlickUp && isPlayable && onPlay) {
      // Trigger flick-to-play animation
      setIsFlicking(true);
      const randomRot = Math.round((Math.random() - 0.5) * 24);
      setFlickTransform(`translate3d(${deltaX * 0.8}px, -320px, 120px) rotate(${randomRot}deg) scale(0.9)`);
      setTimeout(() => {
        onPlay(card);
        setIsFlicking(false);
        setFlickTransform('');
      }, 180);
    } else {
      // Reset peek
      setPeekRotation({ x: 0, y: 0 });
      if (Math.abs(deltaX) < 8 && Math.abs(deltaY) < 8 && onClick) {
        onClick();
      }
    }

    startPointerRef.current = null;
  };

  const renderCardContent = () => {
    if (card.type === 'number') {
      return (
        <span className="font-display font-extrabold text-3xl tracking-tighter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
          {card.value}
        </span>
      );
    }
    if (card.type === 'skip') {
      return <Ban className="w-8 h-8 stroke-[2.5] drop-shadow-md" />;
    }
    if (card.type === 'reverse') {
      return <ArrowLeftRight className="w-8 h-8 stroke-[2.5] drop-shadow-md" />;
    }
    if (card.type === 'draw_two') {
      return (
        <div className="flex items-center gap-0.5 font-display font-black text-2xl drop-shadow-md">
          <Plus className="w-5 h-5 stroke-[3]" />
          <span>2</span>
        </div>
      );
    }
    if (card.type === 'wild') {
      return (
        <div className="flex flex-col items-center gap-1">
          <Sparkles className="w-8 h-8 stroke-[2.2] animate-pulse text-amber-300 drop-shadow-md" />
          <span className="text-[10px] font-bold tracking-widest uppercase text-amber-300">WILD</span>
        </div>
      );
    }
    if (card.type === 'wild_ante') {
      return (
        <div className="flex flex-col items-center gap-0.5">
          <Flame className="w-8 h-8 stroke-[2.5] text-amber-400 drop-shadow-md animate-bounce" />
          <span className="text-[9px] font-black tracking-widest text-amber-300 uppercase">ANTE +100</span>
        </div>
      );
    }
    return null;
  };

  const cardTransform = isFlicking
    ? flickTransform
    : `perspective(1000px) rotateX(${peekRotation.x}deg) rotateY(${peekRotation.y}deg) ${
        isSelected ? 'translateY(-24px) scale(1.04)' : ''
      }`;

  return (
    <div
      ref={cardRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={() => {
        setPeekRotation({ x: 0, y: 0 });
        startPointerRef.current = null;
      }}
      style={{
        ...style,
        transform: cardTransform,
        transition: isFlicking
          ? 'transform 0.18s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.18s ease'
          : 'transform 0.12s ease-out, box-shadow 0.15s ease',
      }}
      className={`relative w-20 h-32 sm:w-24 sm:h-36 rounded-xl cursor-pointer select-none touch-none preserve-3d transition-all ${
        isPlayable ? 'ring-2 ring-emerald-400/80 hover:ring-amber-400 card-shadow-hover' : 'card-shadow opacity-95'
      } ${className}`}
    >
      {/* FACE DOWN (Card Back) */}
      {isFaceDown ? (
        <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-slate-950 via-[#0e171e] to-slate-900 border border-amber-500/30 p-2 flex flex-col items-center justify-between overflow-hidden shadow-2xl">
          {/* Ornate Gold Border Filigree */}
          <div className="absolute inset-1 rounded-lg border border-amber-500/20 pointer-events-none" />
          <div className="absolute inset-2 rounded border border-emerald-500/10 pointer-events-none" />
          
          <svg className="absolute inset-0 w-full h-full opacity-15 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id={`card-pattern-${patternId}`} width="16" height="16" patternUnits="userSpaceOnUse">
                <path d="M8 0L16 8L8 16L0 8Z" fill="none" stroke="#eab308" strokeWidth="0.8" />
                <circle cx="8" cy="8" r="2" fill="#10b981" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill={`url(#card-pattern-${patternId})`} />
          </svg>

          <div className="w-full flex justify-between text-[10px] font-mono text-amber-500/70">
            <span>♠</span>
            <span>♦</span>
          </div>

          {/* Center Vault Medallion */}
          <div className="relative z-10 w-10 h-10 rounded-full border border-amber-500/40 bg-slate-900/90 flex items-center justify-center shadow-inner">
            <Sparkles className="w-5 h-5 text-amber-400" />
          </div>

          <div className="w-full flex justify-between text-[10px] font-mono text-amber-500/70">
            <span>♣</span>
            <span>♥</span>
          </div>
        </div>
      ) : (
        /* FACE UP (Card Face) */
        <div
          className={`absolute inset-0 rounded-xl bg-gradient-to-b ${colorConfig.bg} border-2 ${
            colorConfig.border
          } p-2.5 flex flex-col justify-between overflow-hidden ${colorConfig.text} shadow-xl`}
        >
          {/* Subtle inner gold rim */}
          <div className="absolute inset-1 rounded-lg border border-white/10 pointer-events-none" />

          {/* Top Left Corner Index */}
          <div className="flex flex-col items-start leading-none z-10">
            <span className="font-display font-extrabold text-base tracking-tight">
              {card.type === 'number'
                ? card.value
                : card.type === 'draw_two'
                ? '+2'
                : card.type === 'skip'
                ? '⊘'
                : card.type === 'reverse'
                ? '⇄'
                : '★'}
            </span>
            <span className="text-[9px] font-mono uppercase tracking-wider opacity-75">
              {card.color.substring(0, 3)}
            </span>
          </div>

          {/* Center Graphic */}
          <div className="relative z-10 flex flex-col items-center justify-center my-auto">
            {renderCardContent()}
          </div>

          {/* Bottom Right Corner Index (Inverted) */}
          <div className="flex flex-col items-end leading-none z-10 rotate-180">
            <span className="font-display font-extrabold text-base tracking-tight">
              {card.type === 'number'
                ? card.value
                : card.type === 'draw_two'
                ? '+2'
                : card.type === 'skip'
                ? '⊘'
                : card.type === 'reverse'
                ? '⇄'
                : '★'}
            </span>
            <span className="text-[9px] font-mono uppercase tracking-wider opacity-75">
              {card.color.substring(0, 3)}
            </span>
          </div>

          {/* Subtle bottom shine */}
          <div className="absolute bottom-0 inset-x-0 h-10 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
        </div>
      )}
    </div>
  );
};
