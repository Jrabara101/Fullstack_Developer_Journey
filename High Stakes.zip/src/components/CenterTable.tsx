import React from 'react';
import { Card, CardColor } from '../game/types';
import { Card3D } from './Card3D';
import { Coins, RotateCw, RotateCcw, Flame } from 'lucide-react';

interface CenterTableProps {
  topDiscard: Card | null;
  activeColor: CardColor;
  drawDeckCount: number;
  potChips: number;
  currentAnte: number;
  direction: 1 | -1;
  onDrawDeckClick?: () => void;
  canDraw?: boolean;
}

const COLOR_GLOW_MAP: Record<CardColor, string> = {
  red: 'border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.35)]',
  blue: 'border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.35)]',
  green: 'border-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.35)]',
  yellow: 'border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.35)]',
  wild: 'border-purple-500 shadow-[0_0_30px_rgba(168,85,247,0.45)]',
};

export const CenterTable: React.FC<CenterTableProps> = ({
  topDiscard,
  activeColor,
  drawDeckCount,
  potChips,
  currentAnte,
  direction,
  onDrawDeckClick,
  canDraw = false,
}) => {
  return (
    <div className="relative flex flex-col items-center justify-center p-6 select-none">
      {/* Central Pot Counter */}
      <div className="relative mb-5 flex items-center gap-2.5 px-5 py-2 rounded-full bg-slate-900/90 border border-amber-500/40 shadow-[0_0_25px_rgba(234,179,8,0.25)]">
        <div className="w-6 h-6 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow">
          <Coins className="w-4 h-4" />
        </div>
        <div className="flex flex-col">
          <span className="text-[10px] font-mono uppercase tracking-wider text-amber-300/80 leading-none">
            Main Pot
          </span>
          <span className="font-display font-extrabold text-lg text-amber-300 tabular-nums leading-tight">
            {potChips.toLocaleString()} <span className="text-xs font-normal">CHIPS</span>
          </span>
        </div>

        {/* Ante Badge */}
        <div className="ml-2 pl-3 border-l border-slate-700 flex items-center gap-1 text-[11px] font-mono text-emerald-400">
          <Flame className="w-3.5 h-3.5 text-amber-400" />
          <span>Ante: {currentAnte}</span>
        </div>
      </div>

      {/* Discard & Draw Decks Arena */}
      <div className="relative flex items-center justify-center gap-6 sm:gap-10">
        {/* Draw Deck Stack */}
        <div
          onClick={canDraw ? onDrawDeckClick : undefined}
          className={`relative group cursor-pointer transition-transform ${
            canDraw ? 'hover:scale-105 active:scale-95' : 'opacity-80 cursor-not-allowed'
          }`}
        >
          {/* Faux Card Layers for 3D depth */}
          <div className="absolute top-2 left-2 w-20 h-32 sm:w-24 sm:h-36 rounded-xl bg-slate-950/80 border border-amber-500/10 pointer-events-none" />
          <div className="absolute top-1 left-1 w-20 h-32 sm:w-24 sm:h-36 rounded-xl bg-slate-950/90 border border-amber-500/20 pointer-events-none" />

          {/* Top Face-Down Draw Card */}
          <Card3D
            card={{ id: 'deck_top', color: 'wild', value: 0, type: 'wild' }}
            isFaceDown={true}
            canPeek={false}
          />

          {/* Deck Count Label */}
          <div className="absolute -bottom-3 inset-x-0 mx-auto w-fit px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-[10px] font-mono text-slate-300 shadow">
            {drawDeckCount} cards
          </div>
        </div>

        {/* Active Discard Pile with Active Color Rim */}
        <div className="relative">
          {/* Active Color Aura Ring */}
          <div
            className={`absolute -inset-3 rounded-2xl border-2 transition-all duration-500 ${
              COLOR_GLOW_MAP[activeColor]
            }`}
          />

          {/* Discard Card */}
          {topDiscard ? (
            <Card3D card={topDiscard} isFaceDown={false} canPeek={false} />
          ) : (
            <div className="w-20 h-32 sm:w-24 sm:h-36 rounded-xl border-2 border-dashed border-emerald-500/30 flex items-center justify-center text-emerald-500/40 text-xs font-mono">
              Felt Stack
            </div>
          )}

          {/* Active Suit / Color Indicator Tag */}
          <div className="absolute -top-3 inset-x-0 mx-auto w-fit px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-[10px] font-mono uppercase font-bold text-slate-200 flex items-center gap-1 shadow">
            <span
              className={`w-2 h-2 rounded-full ${
                activeColor === 'red'
                  ? 'bg-red-500'
                  : activeColor === 'blue'
                  ? 'bg-blue-500'
                  : activeColor === 'green'
                  ? 'bg-emerald-500'
                  : activeColor === 'yellow'
                  ? 'bg-amber-400'
                  : 'bg-purple-500'
              }`}
            />
            {activeColor}
          </div>
        </div>
      </div>

      {/* Rotation Direction Cue */}
      <div className="mt-4 flex items-center gap-1.5 text-[11px] font-mono text-slate-400">
        {direction === 1 ? (
          <>
            <RotateCw className="w-3.5 h-3.5 text-emerald-400 animate-spin" style={{ animationDuration: '8s' }} />
            <span>Clockwise Turn</span>
          </>
        ) : (
          <>
            <RotateCcw className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '8s' }} />
            <span>Reversed Turn</span>
          </>
        )}
      </div>
    </div>
  );
};
