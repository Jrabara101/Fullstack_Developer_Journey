import React, { useState } from 'react';
import { Card, CardGameState, CardColor } from '../game/types';
import { Card3D } from './Card3D';
import { isLegalPlay } from '../game/rules';
import { Coins, EyeOff, Play, Plus, Monitor, ShieldAlert, Sparkles } from 'lucide-react';

interface ControllerViewProps {
  gameState: CardGameState;
  onPlayCard: (card: Card, declaredColor?: CardColor, isBluff?: boolean) => void;
  onDrawCard: () => void;
  onRaiseAnte: (amount: number) => void;
  onCallBluff: () => void;
  onSwitchToTable: () => void;
}

const COLORS: { color: CardColor; label: string; bg: string }[] = [
  { color: 'red', label: 'Red', bg: 'bg-red-600' },
  { color: 'blue', label: 'Blue', bg: 'bg-blue-600' },
  { color: 'green', label: 'Green', bg: 'bg-emerald-600' },
  { color: 'yellow', label: 'Yellow', bg: 'bg-amber-500 text-slate-950' },
];

export const ControllerView: React.FC<ControllerViewProps> = ({
  gameState,
  onPlayCard,
  onDrawCard,
  onRaiseAnte,
  onCallBluff,
  onSwitchToTable,
}) => {
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [isPendingBluff, setIsPendingBluff] = useState(false);

  const myPlayer = gameState.players.find(p => p.id === gameState.myPlayerId);
  const isMyTurn = gameState.currentTurnPlayerId === gameState.myPlayerId;
  const isBluffPhase = gameState.phase === 'BLUFF_CHALLENGE';
  const myHand = myPlayer?.hand || [];
  const selectedCard = myHand.find(c => c.id === selectedCardId) || null;

  const handleAction = (isBluff: boolean) => {
    if (!selectedCard) return;
    if (selectedCard.color === 'wild' || isBluff) {
      setIsPendingBluff(isBluff);
      setShowColorPicker(true);
    } else {
      onPlayCard(selectedCard, undefined, false);
    }
  };

  const handleColorPick = (color: CardColor) => {
    if (!selectedCard) return;
    setShowColorPicker(false);
    onPlayCard(selectedCard, color, isPendingBluff);
    setIsPendingBluff(false);
  };

  return (
    <div className="min-h-screen w-full bg-[#07130f] text-slate-100 flex flex-col justify-between select-none touch-manipulation overflow-hidden">
      {/* Top 30%: Compact Mini-Table Broadcast */}
      <section className="h-[28vh] bg-gradient-to-b from-[#0e171e] to-[#07130f] border-b border-emerald-500/20 px-4 py-3 flex flex-col justify-between">
        {/* Top Header Row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-mono text-amber-300">
            <span>TABLE</span>
            <span className="font-extrabold text-white">#{gameState.roomCode}</span>
          </div>

          <button
            onClick={onSwitchToTable}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-xs text-slate-300 hover:text-white"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Table View</span>
          </button>
        </div>

        {/* Mini Table Center Stack & Pot Readout */}
        <div className="flex items-center justify-between gap-4 my-auto">
          {/* Top Discard Preview */}
          <div className="flex items-center gap-3">
            <div className="relative scale-90 origin-left">
              {gameState.topDiscard && (
                <Card3D card={gameState.topDiscard} canPeek={false} isFaceDown={false} />
              )}
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-mono uppercase text-slate-400">Current Discard</span>
              <span className="text-xs font-bold text-amber-300 uppercase">
                {gameState.activeColor} Suit
              </span>
            </div>
          </div>

          {/* Pot Readout */}
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-mono uppercase text-slate-400">Total Pot</span>
            <div className="flex items-center gap-1 text-base font-extrabold text-amber-400 font-display tabular-nums">
              <Coins className="w-4 h-4" />
              <span>{gameState.potChips.toLocaleString()}</span>
            </div>
            <span className="text-[10px] font-mono text-emerald-400">
              Ante: {gameState.currentAnte}
            </span>
          </div>
        </div>

        {/* Turn Status Alert Banner */}
        <div
          className={`py-1.5 px-3 rounded-xl text-center text-xs font-mono font-bold uppercase tracking-wider ${
            isMyTurn
              ? 'bg-emerald-500 text-slate-950 animate-pulse'
              : 'bg-slate-900 text-slate-400 border border-slate-800'
          }`}
        >
          {isMyTurn
            ? `Your Turn! (${(gameState.turnTimeRemainingMs / 1000).toFixed(1)}s)`
            : 'Opponent Thinking...'}
        </div>
      </section>

      {/* Color Picker Drawer if triggered */}
      {showColorPicker && (
        <div className="p-3 bg-slate-950 border-t border-b border-amber-500/40 flex flex-col items-center gap-2">
          <span className="text-xs font-bold text-amber-300">
            {isPendingBluff ? 'Declare Claimed Suit:' : 'Select New Color:'}
          </span>
          <div className="grid grid-cols-4 gap-2 w-full max-w-xs">
            {COLORS.map(({ color, label, bg }) => (
              <button
                key={color}
                onClick={() => handleColorPick(color)}
                className={`py-2 rounded-lg text-xs font-extrabold text-white shadow ${bg}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Bottom 70%: Touch Card Carousel with High Thumb Clearance */}
      <section className="flex-1 flex flex-col justify-end px-3 pb-4">
        {/* Helper instruction */}
        <div className="text-center text-[11px] font-mono text-slate-400 mb-2">
          {selectedCard
            ? `Selected: [${selectedCard.color.toUpperCase()} ${selectedCard.type === 'number' ? selectedCard.value : selectedCard.type}] - Swipe up or tap button to play`
            : 'Tap card to select · Drag edge to corner-peek'}
        </div>

        {/* Horizontal Swipeable Card Carousel */}
        <div className="flex items-center gap-3 overflow-x-auto pb-4 pt-2 px-2 snap-x snap-mandatory no-scrollbar">
          {myHand.map((card) => {
            const isPlayable = isMyTurn && !isBluffPhase && isLegalPlay(card, gameState.topDiscard, gameState.activeColor);
            const isSelected = selectedCardId === card.id;

            return (
              <div key={card.id} className="shrink-0 snap-center">
                <Card3D
                  card={card}
                  isPlayable={isPlayable}
                  isSelected={isSelected}
                  isFaceDown={false}
                  canPeek={true}
                  className="w-24 h-36"
                  onClick={() => setSelectedCardId(isSelected ? null : card.id)}
                  onPlay={() => onPlayCard(card, undefined, false)}
                />
              </div>
            );
          })}
        </div>

        {/* Tactile Thumb Action Buttons */}
        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-800">
          {/* Play Button */}
          <button
            disabled={!isMyTurn || !selectedCard || isBluffPhase}
            onClick={() => handleAction(false)}
            className={`py-3.5 rounded-2xl flex flex-col items-center justify-center gap-1 font-display font-extrabold text-xs uppercase shadow-lg ${
              isMyTurn && selectedCard && !isBluffPhase
                ? 'bg-emerald-500 text-slate-950 active:scale-95'
                : 'bg-slate-900 text-slate-600'
            }`}
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Play</span>
          </button>

          {/* Bluff Button */}
          <button
            disabled={!isMyTurn || !selectedCard || isBluffPhase}
            onClick={() => handleAction(true)}
            className={`py-3.5 rounded-2xl flex flex-col items-center justify-center gap-1 font-display font-extrabold text-xs uppercase shadow-lg ${
              isMyTurn && selectedCard && !isBluffPhase
                ? 'bg-purple-600 text-white active:scale-95'
                : 'bg-slate-900 text-slate-600'
            }`}
          >
            <EyeOff className="w-4 h-4" />
            <span>Bluff</span>
          </button>

          {/* Pass / Draw Button */}
          <button
            disabled={!isMyTurn || isBluffPhase}
            onClick={onDrawCard}
            className={`py-3.5 rounded-2xl flex flex-col items-center justify-center gap-1 font-display font-extrabold text-xs uppercase shadow-lg ${
              isMyTurn && !isBluffPhase
                ? 'bg-slate-800 text-slate-200 active:scale-95'
                : 'bg-slate-900 text-slate-600'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Draw</span>
          </button>

          {/* Raise Ante Button */}
          <button
            disabled={!isMyTurn || (myPlayer?.chips || 0) < 50 || isBluffPhase}
            onClick={() => onRaiseAnte(50)}
            className={`py-3.5 rounded-2xl flex flex-col items-center justify-center gap-1 font-display font-extrabold text-xs uppercase shadow-lg ${
              isMyTurn && (myPlayer?.chips || 0) >= 50 && !isBluffPhase
                ? 'bg-amber-500 text-slate-950 active:scale-95'
                : 'bg-slate-900 text-slate-600'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>+50 Ante</span>
          </button>
        </div>

        {/* Slam Call Bluff Alert Button if Bluff Challenge Active */}
        {isBluffPhase && (
          <div className="mt-2 animate-bounce">
            <button
              onClick={onCallBluff}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-display font-black text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(239,68,68,0.7)] active:scale-95 flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-5 h-5" />
              <span>Slam "Call Bluff" (5s)!</span>
            </button>
          </div>
        )}
      </section>
    </div>
  );
};
