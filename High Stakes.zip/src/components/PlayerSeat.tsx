import React from 'react';
import { TablePlayer } from '../game/types';
import { Coins, Crown, Bot } from 'lucide-react';

interface PlayerSeatProps {
  player: TablePlayer;
  turnTimeRemainingMs?: number;
  totalTurnTimeMs?: number;
  isCurrentTurn: boolean;
  positionClass?: string;
}

export const PlayerSeat: React.FC<PlayerSeatProps> = ({
  player,
  turnTimeRemainingMs = 15000,
  totalTurnTimeMs = 15000,
  isCurrentTurn,
  positionClass = '',
}) => {
  const isUrgent = isCurrentTurn && turnTimeRemainingMs < 5000;
  const progressRatio = Math.max(0, Math.min(1, turnTimeRemainingMs / totalTurnTimeMs));
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progressRatio);

  return (
    <div className={`relative flex flex-col items-center gap-1.5 select-none ${positionClass}`}>
      {/* Turn Timer SVG Ring around Avatar */}
      <div className="relative w-20 h-20 sm:w-24 sm:h-24 flex items-center justify-center">
        {/* SVG Progress Ring */}
        <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 96 96">
          {/* Track */}
          <circle
            cx="48"
            cy="48"
            r={radius}
            fill="none"
            stroke="rgba(30, 46, 40, 0.6)"
            strokeWidth="3.5"
          />
          {/* Animated Progress Beam */}
          {isCurrentTurn && (
            <circle
              cx="48"
              cy="48"
              r={radius}
              fill="none"
              stroke={isUrgent ? '#ef4444' : '#10b981'}
              strokeWidth="4"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-[stroke-dashoffset] duration-300 ease-linear"
            />
          )}
        </svg>

        {/* Avatar Container */}
        <div
          className={`relative w-16 h-16 sm:w-18 sm:h-18 rounded-full overflow-hidden bg-slate-900 border-2 transition-all ${
            isCurrentTurn
              ? isUrgent
                ? 'border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.7)] animate-pulse'
                : 'border-emerald-400 shadow-[0_0_16px_rgba(16,185,129,0.5)]'
              : 'border-slate-800'
          }`}
        >
          <img
            src={player.avatarUrl}
            alt={player.username}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />

          {/* Turn Active Pill */}
          {isCurrentTurn && (
            <div
              className={`absolute bottom-0 inset-x-0 py-0.5 text-[9px] font-mono font-bold uppercase text-center ${
                isUrgent ? 'bg-red-600 text-white' : 'bg-emerald-600 text-slate-950'
              }`}
            >
              {(turnTimeRemainingMs / 1000).toFixed(1)}s
            </div>
          )}
        </div>

        {/* Host Crown */}
        {player.isHost && (
          <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-md">
            <Crown className="w-3.5 h-3.5" />
          </div>
        )}

        {/* AI Bot Badge */}
        {player.isBot && (
          <div className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-cyan-700 text-white flex items-center justify-center shadow-md">
            <Bot className="w-3 h-3" />
          </div>
        )}

        {/* Card Count Fan Badge */}
        <div className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-md bg-slate-900/90 border border-slate-700 text-[10px] font-mono font-bold text-amber-300 shadow">
          🂠 {player.cardCount}
        </div>
      </div>

      {/* Player Metadata Pill */}
      <div className="flex flex-col items-center max-w-[120px] text-center">
        <span className="text-xs font-semibold text-slate-200 truncate w-full">
          {player.username}
        </span>

        {/* Chips Balance */}
        <div className="flex items-center gap-1 text-[11px] font-mono font-medium text-amber-400 tabular-nums">
          <Coins className="w-3 h-3 text-amber-400" />
          <span>{player.chips.toLocaleString()}</span>
        </div>

        {/* Current Bet if > 0 */}
        {player.currentBet > 0 && (
          <span className="text-[10px] font-mono text-emerald-400/90 tabular-nums">
            Bet: {player.currentBet} 🪙
          </span>
        )}
      </div>
    </div>
  );
};
