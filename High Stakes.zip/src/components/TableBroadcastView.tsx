import React, { useState } from 'react';
import { Card, CardGameState, CardColor } from '../game/types';
import { PlayerSeat } from './PlayerSeat';
import { CenterTable } from './CenterTable';
import { Card3D } from './Card3D';
import { WagerDrawer } from './WagerDrawer';
import { soundEngine } from '../utils/audio';
import { isLegalPlay } from '../game/rules';
import { Copy, Check, Volume2, VolumeX, Smartphone, UserPlus, QrCode, MessageSquare } from 'lucide-react';
import QRCode from 'qrcode';

interface TableBroadcastViewProps {
  gameState: CardGameState;
  onPlayCard: (card: Card, declaredColor?: CardColor, isBluff?: boolean) => void;
  onDrawCard: () => void;
  onRaiseAnte: (amount: number) => void;
  onPlayMeld: (cardIds: string[]) => void;
  onCallBluff: () => void;
  onAddBot: () => void;
  onSwitchToController: () => void;
  onLeaveTable: () => void;
  onSendEmote: (emote: string) => void;
}

export const TableBroadcastView: React.FC<TableBroadcastViewProps> = ({
  gameState,
  onPlayCard,
  onDrawCard,
  onRaiseAnte,
  onPlayMeld,
  onCallBluff,
  onAddBot,
  onSwitchToController,
  onLeaveTable,
  onSendEmote,
}) => {
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [selectedMeldCardIds, setSelectedMeldCardIds] = useState<string[]>([]);
  const [copiedCode, setCopiedCode] = useState(false);
  const [isMuted, setIsMuted] = useState(soundEngine.isMuted);
  const [showQrModal, setShowQrModal] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const myPlayer = gameState.players.find(p => p.id === gameState.myPlayerId);
  const isMyTurn = gameState.currentTurnPlayerId === gameState.myPlayerId;
  const isBluffPhase = gameState.phase === 'BLUFF_CHALLENGE';
  const otherPlayers = gameState.players.filter(p => p.id !== gameState.myPlayerId);

  const myHand = myPlayer?.hand || [];
  const selectedCard = myHand.find(c => c.id === selectedCardId) || null;
  const selectedMeldCards = myHand.filter(c => selectedMeldCardIds.includes(c.id));

  const toggleMute = () => {
    soundEngine.isMuted = !soundEngine.isMuted;
    setIsMuted(soundEngine.isMuted);
  };

  const copyRoomCode = () => {
    navigator.clipboard?.writeText(gameState.roomCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const openQrModal = async () => {
    try {
      const joinUrl = `${window.location.origin}?table=${gameState.roomCode}&mode=controller`;
      const url = await QRCode.toDataURL(joinUrl, { margin: 2, width: 260, color: { dark: '#07130f', light: '#ffffff' } });
      setQrDataUrl(url);
      setShowQrModal(true);
    } catch (err) {
      console.error('Error generating QR:', err);
    }
  };

  const handleCardClick = (card: Card) => {
    if (selectedCardId === card.id) {
      setSelectedCardId(null);
    } else {
      setSelectedCardId(card.id);
    }

    // Toggle multi-select for meld combos
    if (selectedMeldCardIds.includes(card.id)) {
      setSelectedMeldCardIds(prev => prev.filter(id => id !== card.id));
    } else {
      setSelectedMeldCardIds(prev => [...prev, card.id]);
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-casino-felt flex flex-col justify-between overflow-hidden">
      {/* Top Bar Navigation */}
      <header className="relative z-20 flex items-center justify-between px-4 sm:px-8 py-3 bg-slate-950/80 border-b border-emerald-500/20 backdrop-blur-md">
        {/* Left: Table PIN & Invite */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-emerald-500/30 text-xs font-mono">
            <span className="text-slate-400">TABLE:</span>
            <span className="font-extrabold text-amber-300 tracking-wider">#{gameState.roomCode}</span>
            <button
              onClick={copyRoomCode}
              title="Copy Room Code"
              className="ml-1 p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <button
            onClick={openQrModal}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 hover:text-amber-300 transition-colors"
            title="Scan QR to play on smartphone controller"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Phone Sync</span>
          </button>

          {/* Add Bot button for host */}
          {myPlayer?.isHost && gameState.players.length < 6 && (
            <button
              onClick={onAddBot}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 hover:text-emerald-400 transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Add AI Seat</span>
            </button>
          )}
        </div>

        {/* Center: Brand Wordmark */}
        <div className="flex items-center gap-2">
          <span className="font-display font-extrabold text-lg sm:text-xl tracking-tight text-slate-100">
            VELVET <span className="text-amber-400">ANTE</span>
          </span>
          <span className="hidden md:inline-block text-[11px] font-mono text-emerald-400/80 uppercase px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/20">
            {gameState.phase.replace('_', ' ')}
          </span>
        </div>

        {/* Right: Audio & Mode Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Emote Actions */}
          <div className="hidden lg:flex items-center gap-1">
            {[
              { label: '🍅', text: 'threw a tomato!' },
              { label: '🪙', text: 'clinked chips aggressively!' },
              { label: '💥', text: 'slammed the table!' },
              { label: '🔥', text: 'raised the heat!' },
            ].map(({ label, text }) => (
              <button
                key={label}
                onClick={() => onSendEmote(text)}
                title={text}
                className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-center text-sm transition-transform active:scale-90"
              >
                {label}
              </button>
            ))}
          </div>

          <button
            onClick={onSwitchToController}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/80 hover:bg-purple-900 border border-purple-500/30 text-purple-300 text-xs font-semibold transition-colors"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Pocket View</span>
          </button>

          <button
            onClick={toggleMute}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          <button
            onClick={onLeaveTable}
            className="px-3 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/20 text-red-300 text-xs transition-colors"
          >
            Leave
          </button>
        </div>
      </header>

      {/* Main Oval Table Arena */}
      <main className="relative flex-1 flex flex-col items-center justify-center p-2 sm:p-6 max-w-7xl mx-auto w-full">
        {/* Felt Oval Perimeter Ring */}
        <div
          className={`relative w-full max-w-5xl rounded-[3rem] sm:rounded-[4.5rem] bg-[#0c1f17] border-4 border-[#1e3a2f] table-rim-glow ${
            isMyTurn && gameState.turnTimeRemainingMs < 5000 ? 'table-rim-urgent' : ''
          } py-8 px-4 sm:px-12 flex flex-col items-center justify-center min-h-[440px]`}
        >
          {/* Subtle Inset Felt Oval Trim */}
          <div className="absolute inset-4 rounded-[2.5rem] sm:rounded-[4rem] border border-emerald-500/10 pointer-events-none" />

          {/* Opponent Seats along Upper Perimeter */}
          <div className="w-full flex items-center justify-around gap-2 mb-4 z-10 flex-wrap">
            {otherPlayers.map((player) => (
              <PlayerSeat
                key={player.id}
                player={player}
                isCurrentTurn={player.id === gameState.currentTurnPlayerId}
                turnTimeRemainingMs={gameState.turnTimeRemainingMs}
              />
            ))}
          </div>

          {/* Center Table Area (Pot, Discard, Draw) */}
          <div className="my-auto z-10">
            <CenterTable
              topDiscard={gameState.topDiscard}
              activeColor={gameState.activeColor}
              drawDeckCount={gameState.drawDeckCount}
              potChips={gameState.potChips}
              currentAnte={gameState.currentAnte}
              direction={gameState.direction}
              canDraw={isMyTurn && !isBluffPhase}
              onDrawDeckClick={onDrawCard}
            />
          </div>

          {/* Combat Log Pill */}
          {gameState.combatLog.length > 0 && (
            <div className="absolute bottom-3 left-6 hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/80 border border-slate-800 text-[11px] font-mono text-slate-400 max-w-md truncate shadow">
              <MessageSquare className="w-3 h-3 text-emerald-400 shrink-0" />
              <span className="truncate">{gameState.combatLog[0].text}</span>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Action Dock (My Hand & Wager Controls) */}
      <footer className="relative z-20 w-full flex flex-col items-center pb-4 pt-2 bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent">
        {/* Fan Hand Rack */}
        <div className="relative w-full max-w-4xl px-4 flex items-center justify-center -space-x-8 sm:-space-x-10 mb-3 overflow-x-auto py-6">
          {myHand.map((card, idx) => {
            const total = myHand.length;
            const mid = (total - 1) / 2;
            const offset = idx - mid;
            const rotationDeg = offset * (total > 8 ? 2.5 : 4);
            const translateY = Math.abs(offset) * 2;
            const isPlayable = isMyTurn && !isBluffPhase && isLegalPlay(card, gameState.topDiscard, gameState.activeColor);
            const isSelected = selectedCardId === card.id || selectedMeldCardIds.includes(card.id);

            return (
              <div
                key={card.id}
                style={{
                  transform: `rotate(${rotationDeg}deg) translateY(${translateY}px)`,
                  zIndex: isSelected ? 40 : 10 + idx,
                }}
                className="transition-transform duration-150 origin-bottom hover:!z-50"
              >
                <Card3D
                  card={card}
                  isPlayable={isPlayable}
                  isSelected={isSelected}
                  isFaceDown={false}
                  onPlay={() => onPlayCard(card, undefined, false)}
                  onClick={() => handleCardClick(card)}
                />
              </div>
            );
          })}
        </div>

        {/* Tactical Controls Drawer */}
        <WagerDrawer
          isTurn={isMyTurn}
          selectedCard={selectedCard}
          selectedMeldCards={selectedMeldCards}
          currentAnte={gameState.currentAnte}
          playerChips={myPlayer?.chips || 0}
          isBluffPhase={isBluffPhase}
          canCallBluff={isBluffPhase && gameState.bluffChallenge?.initiatorPlayerId !== gameState.myPlayerId}
          onPlayCard={onPlayCard}
          onDrawCard={onDrawCard}
          onRaiseAnte={onRaiseAnte}
          onPlayMeld={onPlayMeld}
          onCallBluff={onCallBluff}
        />
      </footer>

      {/* Dual Device QR Code Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-950 border border-emerald-500/40 p-6 flex flex-col items-center text-center shadow-2xl">
            <h3 className="font-display font-extrabold text-xl text-slate-100 mb-1">
              Dual-Device Controller
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Scan with your smartphone camera to use your phone as a private tactile card controller!
            </p>

            {qrDataUrl && (
              <div className="p-3 rounded-2xl bg-white shadow-xl mb-4">
                <img src={qrDataUrl} alt="Room QR Code" className="w-52 h-52 object-contain" />
              </div>
            )}

            <div className="text-xs font-mono text-amber-300 font-bold mb-4">
              Room Code: #{gameState.roomCode}
            </div>

            <button
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
