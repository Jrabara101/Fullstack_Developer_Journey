import React, { useEffect } from 'react';
import { CardGameState } from '../game/types';
import { Card3D } from './Card3D';
import confetti from 'canvas-confetti';
import { Trophy, Coins, RotateCcw } from 'lucide-react';

interface VictoryModalProps {
  payout: NonNullable<CardGameState['showdownPayout']>;
  isHost: boolean;
  onNextHand: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  payout,
  isHost,
  onNextHand,
}) => {
  useEffect(() => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#eab308', '#10b981', '#3b82f6', '#ef4444', '#a855f7'],
    });
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-950 border-2 border-amber-500/50 p-6 sm:p-8 flex flex-col items-center text-center shadow-[0_0_60px_rgba(234,179,8,0.3)]">
        {/* Trophy Badge */}
        <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mb-4 shadow-inner">
          <Trophy className="w-9 h-9 stroke-[2.2]" />
        </div>

        <span className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold mb-1">
          Showdown Payout
        </span>
        <h2 className="font-display font-black text-2xl sm:text-3xl text-slate-100">
          {payout.winnerName} Sweeps the Table!
        </h2>
        <p className="mt-1 text-sm font-semibold text-emerald-400">
          Winning Combo: {payout.comboName}
        </p>

        {/* Claimed Chips Pill */}
        <div className="my-5 flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-slate-900 border border-amber-500/40 shadow">
          <Coins className="w-5 h-5 text-amber-400" />
          <span className="font-display font-extrabold text-2xl text-amber-300 tabular-nums">
            +{payout.amount.toLocaleString()}{' '}
            <span className="text-sm font-normal text-amber-400/80">CHIPS CLAIMED</span>
          </span>
        </div>

        {/* Winning Cards Showcase */}
        {payout.winningCards && payout.winningCards.length > 0 && (
          <div className="flex items-center justify-center gap-2 mb-6 overflow-x-auto py-2 max-w-full">
            {payout.winningCards.map((card) => (
              <Card3D key={card.id} card={card} canPeek={false} className="scale-90" />
            ))}
          </div>
        )}

        {/* Action Button */}
        {isHost ? (
          <button
            onClick={onNextHand}
            className="flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-display font-extrabold text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(234,179,8,0.5)] transition-all hover:scale-105 active:scale-95"
          >
            <RotateCcw className="w-4 h-4 stroke-[2.5]" />
            <span>Deal Next Hand</span>
          </button>
        ) : (
          <div className="text-xs font-mono text-slate-400 animate-pulse">
            Waiting for Table Host to deal next hand...
          </div>
        )}
      </div>
    </div>
  );
};
