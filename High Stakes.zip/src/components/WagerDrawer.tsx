import React, { useState } from 'react';
import { Card, CardColor } from '../game/types';
import { Coins, EyeOff, Play, Plus, Sparkles, Flame, ShieldAlert } from 'lucide-react';

interface WagerDrawerProps {
  isTurn: boolean;
  selectedCard: Card | null;
  selectedMeldCards: Card[];
  currentAnte: number;
  playerChips: number;
  isBluffPhase: boolean;
  onPlayCard: (card: Card, declaredColor?: CardColor, isBluff?: boolean) => void;
  onDrawCard: () => void;
  onRaiseAnte: (amount: number) => void;
  onPlayMeld: (cardIds: string[]) => void;
  onCallBluff: () => void;
  canCallBluff: boolean;
}

const COLORS: { color: CardColor; label: string; bg: string }[] = [
  { color: 'red', label: 'Red', bg: 'bg-red-600 hover:bg-red-500 text-white' },
  { color: 'blue', label: 'Blue', bg: 'bg-blue-600 hover:bg-blue-500 text-white' },
  { color: 'green', label: 'Green', bg: 'bg-emerald-600 hover:bg-emerald-500 text-white' },
  { color: 'yellow', label: 'Yellow', bg: 'bg-amber-500 hover:bg-amber-400 text-slate-950' },
];

export const WagerDrawer: React.FC<WagerDrawerProps> = ({
  isTurn,
  selectedCard,
  selectedMeldCards,
  currentAnte,
  playerChips,
  isBluffPhase,
  onPlayCard,
  onDrawCard,
  onRaiseAnte,
  onPlayMeld,
  onCallBluff,
  canCallBluff,
}) => {
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [pendingBluff, setPendingBluff] = useState(false);
  const [raiseAmount, setRaiseAmount] = useState(50);

  const handlePlayClick = (isBluff: boolean) => {
    if (!selectedCard) return;

    if (selectedCard.color === 'wild' || isBluff) {
      setPendingBluff(isBluff);
      setShowColorPicker(true);
    } else {
      onPlayCard(selectedCard, undefined, false);
    }
  };

  const handleColorSelected = (color: CardColor) => {
    if (!selectedCard) return;
    setShowColorPicker(false);
    onPlayCard(selectedCard, color, pendingBluff);
    setPendingBluff(false);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-3 rounded-2xl bg-slate-900/90 border border-emerald-500/20 shadow-2xl backdrop-blur-md select-none">
      {/* Color Picker Overlay */}
      {showColorPicker && (
        <div className="mb-3 p-3 rounded-xl bg-slate-950 border border-amber-500/30 flex flex-col items-center gap-2 animate-in fade-in zoom-in-95 duration-150">
          <span className="text-xs font-semibold text-amber-300">
            {pendingBluff ? 'Declare Claimed Suit for Bluff:' : 'Choose New Active Color:'}
          </span>
          <div className="flex items-center gap-2">
            {COLORS.map(({ color, label, bg }) => (
              <button
                key={color}
                onClick={() => handleColorSelected(color)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all shadow ${bg}`}
              >
                {label}
              </button>
            ))}
            <button
              onClick={() => setShowColorPicker(false)}
              className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-slate-200"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Left: Tactical Plays */}
        <div className="flex items-center gap-2">
          {/* Play Face Up */}
          <button
            disabled={!isTurn || !selectedCard || isBluffPhase}
            onClick={() => handlePlayClick(false)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
              isTurn && selectedCard && !isBluffPhase
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 hover:shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Play Card</span>
          </button>

          {/* Bluff Play (Face Down) */}
          <button
            disabled={!isTurn || !selectedCard || isBluffPhase}
            onClick={() => handlePlayClick(true)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
              isTurn && selectedCard && !isBluffPhase
                ? 'bg-purple-600 hover:bg-purple-500 text-white hover:shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>Bluff (Face Down)</span>
          </button>

          {/* Draw Card */}
          <button
            disabled={!isTurn || isBluffPhase}
            onClick={onDrawCard}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
              isTurn && !isBluffPhase
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                : 'bg-slate-850 text-slate-600 border border-slate-800 cursor-not-allowed'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Pass & Draw</span>
          </button>

          {/* Meld Pot Sweep Button */}
          {selectedMeldCards.length >= 3 && (
            <button
              disabled={!isTurn || isBluffPhase}
              onClick={() => onPlayMeld(selectedMeldCards.map(c => c.id))}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-[0_0_20px_rgba(234,179,8,0.5)] animate-pulse"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>Meld Sweep ({selectedMeldCards.length} Cards)</span>
            </button>
          )}
        </div>

        {/* Center: CALL BLUFF trigger if challenge active */}
        {isBluffPhase && (
          <div className="flex items-center gap-2 animate-bounce">
            <button
              disabled={!canCallBluff}
              onClick={onCallBluff}
              className={`flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-xl ${
                canCallBluff
                  ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_25px_rgba(239,68,68,0.7)]'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Slam "Call Bluff"!</span>
            </button>
          </div>
        )}

        {/* Right: Ante & Chips Raising */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950/80 px-2 py-1 rounded-xl border border-slate-800">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] font-mono text-amber-400 tabular-nums">
              {playerChips} 🪙
            </span>
          </div>

          {/* Quick Raise Chips */}
          <div className="flex items-center gap-1">
            {[50, 100, 250].map((amt) => (
              <button
                key={amt}
                disabled={playerChips < amt || isBluffPhase}
                onClick={() => onRaiseAnte(amt)}
                className={`px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold transition-all ${
                  playerChips >= amt && !isBluffPhase
                    ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                }`}
              >
                +{amt}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
