import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generateDeck,
  shuffleDeck,
  isLegalPlay,
  evaluateMeld,
  verifyBluff,
  getNextPlayerIndex
} from './rules.ts';
import type { Card } from './types.ts';

test('generateDeck creates correct hybrid Uno/Poker card composition', () => {
  const deck = generateDeck();
  // 4 colors * (1 zero + 9*2 numbers + 3*2 specials) + 4 wilds + 4 wild_antes
  // Per color: 1 + 18 + 6 = 25 cards.
  // 4 * 25 = 100 cards + 8 wilds = 108 cards total
  assert.equal(deck.length, 108);

  const wilds = deck.filter(c => c.type === 'wild' || c.type === 'wild_ante');
  assert.equal(wilds.length, 8);
});

test('shuffleDeck preserves all cards and order changes', () => {
  const deck = generateDeck();
  const shuffled = shuffleDeck(deck);
  assert.equal(shuffled.length, deck.length);
  // It should be extremely rare that shuffled is identical to unshuffled
  assert.notDeepEqual(shuffled, deck);
});

test('isLegalPlay accurately validates color, number, action and wild plays', () => {
  const topDiscard: Card = { id: 'top', color: 'red', value: 7, type: 'number' };

  // Matching color
  assert.equal(isLegalPlay({ id: '1', color: 'red', value: 2, type: 'number' }, topDiscard, 'red'), true);
  // Matching value
  assert.equal(isLegalPlay({ id: '2', color: 'blue', value: 7, type: 'number' }, topDiscard, 'red'), true);
  // Wild card
  assert.equal(isLegalPlay({ id: '3', color: 'wild', value: -1, type: 'wild' }, topDiscard, 'red'), true);
  // Action card matching action
  const topSkip: Card = { id: 's1', color: 'green', value: -1, type: 'skip' };
  assert.equal(isLegalPlay({ id: 's2', color: 'blue', value: -1, type: 'skip' }, topSkip, 'green'), true);

  // Illegal play
  assert.equal(isLegalPlay({ id: '4', color: 'green', value: 3, type: 'number' }, topDiscard, 'red'), false);
});

test('evaluateMeld correctly identifies Flushes, Straights and Straight Flushes', () => {
  // 3-card flush
  const flushCards: Card[] = [
    { id: '1', color: 'blue', value: 2, type: 'number' },
    { id: '2', color: 'blue', value: 5, type: 'number' },
    { id: '3', color: 'blue', value: 8, type: 'number' },
  ];
  const flushRes = evaluateMeld(flushCards);
  assert.equal(flushRes.isMeld, true);
  assert.match(flushRes.name, /Flush/);
  assert.equal(flushRes.multiplier, 2);

  // 3-card straight
  const straightCards: Card[] = [
    { id: '1', color: 'red', value: 4, type: 'number' },
    { id: '2', color: 'blue', value: 5, type: 'number' },
    { id: '3', color: 'green', value: 6, type: 'number' },
  ];
  const straightRes = evaluateMeld(straightCards);
  assert.equal(straightRes.isMeld, true);
  assert.match(straightRes.name, /Straight/);
  assert.equal(straightRes.multiplier, 1.5);

  // Straight flush
  const royalCards: Card[] = [
    { id: '1', color: 'yellow', value: 3, type: 'number' },
    { id: '2', color: 'yellow', value: 4, type: 'number' },
    { id: '3', color: 'yellow', value: 5, type: 'number' },
  ];
  const royalRes = evaluateMeld(royalCards);
  assert.equal(royalRes.isMeld, true);
  assert.match(royalRes.name, /Straight Flush/);
  assert.equal(royalRes.multiplier, 3);
});

test('verifyBluff detects genuine plays vs illegal bluffs', () => {
  const topDiscard: Card = { id: 'top', color: 'red', value: 5, type: 'number' };

  // Played genuine card (red 2 on red 5)
  const genuineCard: Card = { id: 'g1', color: 'red', value: 2, type: 'number' };
  assert.equal(verifyBluff(genuineCard, 'red', topDiscard), false); // not a bluff

  // Played bluff card (green 8 on red 5)
  const bluffCard: Card = { id: 'b1', color: 'green', value: 8, type: 'number' };
  assert.equal(verifyBluff(bluffCard, 'red', topDiscard), true); // IS a bluff!
});

test('getNextPlayerIndex handles circular turns and skips', () => {
  assert.equal(getNextPlayerIndex(0, 4, 1, 1), 1);
  assert.equal(getNextPlayerIndex(3, 4, 1, 1), 0);
  assert.equal(getNextPlayerIndex(0, 4, -1, 1), 3);
  // Skip
  assert.equal(getNextPlayerIndex(1, 4, 1, 2), 3);
});
