import type { Card, CardColor, CardType, TablePlayer } from './types.ts';

export const COLORS: CardColor[] = ['red', 'blue', 'green', 'yellow'];
export const SPECIAL_TYPES: CardType[] = ['skip', 'reverse', 'draw_two'];

/**
 * Generates a full hybrid deck of cards.
 * Uno 0-9 for each of the 4 colors, plus actions, wild cards, and wild_ante cards.
 */
export function generateDeck(): Card[] {
  const deck: Card[] = [];
  let idCounter = 1;

  for (const color of COLORS) {
    // 0 appears once
    deck.push({
      id: `c_${idCounter++}`,
      color,
      value: 0,
      type: 'number',
    });

    // 1-9 appear twice
    for (let val = 1; val <= 9; val++) {
      deck.push({
        id: `c_${idCounter++}`,
        color,
        value: val,
        type: 'number',
      });
      deck.push({
        id: `c_${idCounter++}`,
        color,
        value: val,
        type: 'number',
      });
    }

    // Special action cards (2 of each per color)
    for (const type of SPECIAL_TYPES) {
      deck.push({
        id: `c_${idCounter++}`,
        color,
        value: -1,
        type,
      });
      deck.push({
        id: `c_${idCounter++}`,
        color,
        value: -1,
        type,
      });
    }
  }

  // 4 Wild cards
  for (let i = 0; i < 4; i++) {
    deck.push({
      id: `c_${idCounter++}`,
      color: 'wild',
      value: -1,
      type: 'wild',
    });
  }

  // 4 Wild Ante cards (escalates pot + forces wild color switch)
  for (let i = 0; i < 4; i++) {
    deck.push({
      id: `c_${idCounter++}`,
      color: 'wild',
      value: -1,
      type: 'wild_ante',
    });
  }

  return deck;
}

/**
 * In-place Fisher-Yates shuffle
 */
export function shuffleDeck(deck: Card[]): Card[] {
  const result = [...deck];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

/**
 * Checks if a card can be legally played face-up onto the top discard pile.
 */
export function isLegalPlay(card: Card, topDiscard: Card | null, activeColor: CardColor): boolean {
  if (!topDiscard) return true;

  // Wild cards can always be played
  if (card.color === 'wild' || card.type === 'wild' || card.type === 'wild_ante') {
    return true;
  }

  // Matching current active color
  if (card.color === activeColor) {
    return true;
  }

  // Matching value for number cards
  if (card.type === 'number' && topDiscard.type === 'number' && card.value === topDiscard.value) {
    return true;
  }

  // Matching action type (e.g., Skip on Skip, Reverse on Reverse)
  if (card.type !== 'number' && card.type === topDiscard.type) {
    return true;
  }

  return false;
}

/**
 * Evaluates a multi-card meld (e.g. Flush, Straight) for early pot sweeps.
 * Flush: 3 or more cards of the exact same color.
 * Straight: 3 or more numbered cards with sequential values (e.g. 3, 4, 5).
 */
export interface MeldResult {
  isMeld: boolean;
  name: string;
  multiplier: number;
}

export function evaluateMeld(cards: Card[]): MeldResult {
  if (cards.length < 3) {
    return { isMeld: false, name: '', multiplier: 1 };
  }

  // Check Color Flush (all non-wild cards same color)
  const colors = cards.map(c => c.color).filter(c => c !== 'wild');
  const allSameColor = colors.length === cards.length && new Set(colors).size === 1;

  // Check Straight (all number cards in consecutive sequence)
  const isAllNumbers = cards.every(c => c.type === 'number' && c.value >= 0);
  let isStraight = false;
  if (isAllNumbers) {
    const sortedVals = [...cards.map(c => c.value)].sort((a, b) => a - b);
    // check uniqueness and consecutiveness
    let consecutive = true;
    for (let i = 0; i < sortedVals.length - 1; i++) {
      if (sortedVals[i + 1] !== sortedVals[i] + 1) {
        consecutive = false;
        break;
      }
    }
    isStraight = consecutive;
  }

  if (allSameColor && isStraight) {
    return {
      isMeld: true,
      name: `Royal Straight Flush (${cards[0].color.toUpperCase()})`,
      multiplier: 3,
    };
  }

  if (allSameColor) {
    return {
      isMeld: true,
      name: `${cards.length}-Card Flush (${cards[0].color.toUpperCase()})`,
      multiplier: 2,
    };
  }

  if (isStraight) {
    return {
      isMeld: true,
      name: `${cards.length}-Card Straight`,
      multiplier: 1.5,
    };
  }

  return { isMeld: false, name: '', multiplier: 1 };
}

/**
 * Determines whether a face-down played card was a BLUFF.
 * If the card could legally have been played on the table given the claimed color/type,
 * it is genuine. If not, it is a bluff!
 */
export function verifyBluff(
  actualCard: Card,
  activeColor: CardColor,
  topDiscard: Card | null
): boolean {
  // If the card is actually a wild card, it's never a bluff (it's always legal)
  if (actualCard.color === 'wild' || actualCard.type === 'wild' || actualCard.type === 'wild_ante') {
    return false;
  }

  // If actual card matched the active color or top discard, it is legal (genuine)
  const legal = isLegalPlay(actualCard, topDiscard, activeColor);
  return !legal; // If not legal, it was indeed a bluff!
}

/**
 * Calculates next player turn index in the ring based on direction (1 or -1)
 * and optional skip.
 */
export function getNextPlayerIndex(
  currentIndex: number,
  playerCount: number,
  direction: 1 | -1 = 1,
  steps: number = 1
): number {
  if (playerCount <= 0) return 0;
  const raw = (currentIndex + direction * steps) % playerCount;
  return raw >= 0 ? raw : raw + playerCount;
}
