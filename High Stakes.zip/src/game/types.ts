export type CardColor = 'red' | 'blue' | 'green' | 'yellow' | 'wild';
export type CardType = 'number' | 'skip' | 'reverse' | 'draw_two' | 'wild' | 'wild_ante';

export interface Card {
  id: string;
  color: CardColor;
  value: number; // 0-9 for numbers; special codes for action cards (-1 for action/wild)
  type: CardType;
  isFaceDown?: boolean;
}

export interface TablePlayer {
  id: string;
  username: string;
  avatarUrl: string;
  chips: number;
  currentBet: number;
  cardCount: number;
  isTurn: boolean;
  hasPassed: boolean;
  isHost: boolean;
  isBot?: boolean;
  hand?: Card[]; // Populated ONLY for local client's session
}

export type GamePhase = 'LOBBY' | 'DEALING' | 'PLAYER_TURN' | 'BLUFF_CHALLENGE' | 'ROUND_RESOLVE' | 'SHOWDOWN_PAYOUT';

export interface BluffChallengeState {
  initiatorPlayerId: string;
  initiatorName: string;
  playedCardMasked: boolean;
  card: Card; // Stored server-side, masked to opponent until resolved
  claimedColor: CardColor;
  claimedType: CardType;
  timeLeftMs: number;
  challengerPlayerId?: string;
  challengerName?: string;
  isBluff?: boolean;
  resultMessage?: string;
}

export interface ShowdownPayoutState {
  winnerPlayerId: string;
  winnerName: string;
  amount: number;
  comboName: string;
  winningCards: Card[];
}

export interface CombatLogEntry {
  id: string;
  text: string;
  timestamp: number;
  type?: 'play' | 'bluff' | 'ante' | 'win' | 'info';
}

export interface CardGameState {
  roomId: string;
  roomCode: string;
  phase: GamePhase;
  activeColor: CardColor;
  topDiscard: Card | null;
  drawDeckCount: number;
  potChips: number;
  currentAnte: number;
  currentTurnPlayerId: string;
  turnTimeRemainingMs: number;
  bluffChallenge?: BluffChallengeState;
  showdownPayout?: ShowdownPayoutState;
  players: TablePlayer[];
  myPlayerId: string;
  direction: 1 | -1; // 1 = clockwise, -1 = counter-clockwise
  combatLog: CombatLogEntry[];
}
