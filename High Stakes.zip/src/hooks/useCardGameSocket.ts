import { useEffect, useRef, useState, useCallback } from 'react';
import { Card, CardColor, CardGameState } from '../game/types';
import { soundEngine } from '../utils/audio';

const STORAGE_KEY_PLAYER_ID = 'velvet_ante_player_id';
const STORAGE_KEY_ROOM_CODE = 'velvet_ante_room_code';
const STORAGE_KEY_USERNAME = 'velvet_ante_username';

export function useCardGameSocket() {
  const [gameState, setGameState] = useState<CardGameState | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const sendQueueRef = useRef<string[]>([]);
  const prevPotRef = useRef<number>(0);
  const prevPhaseRef = useRef<string>('');
  const prevDiscardIdRef = useRef<string>('');

  const connect = useCallback(() => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      setLastError(null);

      // Flush any queued messages
      while (sendQueueRef.current.length > 0) {
        const item = sendQueueRef.current.shift();
        if (item) ws.send(item);
      }

      // Auto-reconnect if stored session exists and queue was empty
      const savedRoom = localStorage.getItem(STORAGE_KEY_ROOM_CODE);
      const savedPlayerId = localStorage.getItem(STORAGE_KEY_PLAYER_ID);
      const savedUsername = localStorage.getItem(STORAGE_KEY_USERNAME) || 'HighRoller';

      if (savedRoom && sendQueueRef.current.length === 0) {
        ws.send(JSON.stringify({
          type: 'JOIN_ROOM',
          payload: {
            roomCode: savedRoom,
            username: savedUsername,
            playerId: savedPlayerId,
          }
        }));
      }
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'STATE_SYNC') {
          const newState: CardGameState = msg.state;
          setGameState(newState);

          // Audio triggers
          if (newState.potChips > prevPotRef.current) {
            soundEngine.playChipClink();
          }
          prevPotRef.current = newState.potChips;

          if (newState.phase === 'BLUFF_CHALLENGE' && prevPhaseRef.current !== 'BLUFF_CHALLENGE') {
            soundEngine.playBluffAlarm();
          }
          if (newState.phase === 'SHOWDOWN_PAYOUT' && prevPhaseRef.current !== 'SHOWDOWN_PAYOUT') {
            soundEngine.playVictoryFanfare();
          }
          prevPhaseRef.current = newState.phase;

          if (newState.topDiscard?.id && newState.topDiscard.id !== prevDiscardIdRef.current) {
            soundEngine.playCardSnap();
            prevDiscardIdRef.current = newState.topDiscard.id;
          }
        } else if (msg.type === 'ROOM_CREATED' || msg.type === 'ROOM_JOINED') {
          localStorage.setItem(STORAGE_KEY_ROOM_CODE, msg.roomCode);
          localStorage.setItem(STORAGE_KEY_PLAYER_ID, msg.playerId);
        } else if (msg.type === 'ERROR') {
          setLastError(msg.message);
          setTimeout(() => setLastError(null), 4000);
        }
      } catch (err) {
        console.error('Failed to parse socket message:', err);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      // Attempt reconnect after 2s
      setTimeout(connect, 2000);
    };

    ws.onerror = () => {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          ws.close();
        } catch {}
      }
    };
  }, []);

  useEffect(() => {
    connect();
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  const send = useCallback((type: string, payload: unknown = {}) => {
    const raw = JSON.stringify({ type, payload });
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(raw);
    } else {
      sendQueueRef.current.push(raw);
    }
  }, []);

  const createRoom = useCallback((hostName: string, avatarUrl?: string) => {
    localStorage.setItem(STORAGE_KEY_USERNAME, hostName);
    send('CREATE_ROOM', { hostName, avatarUrl });
  }, [send]);

  const joinRoom = useCallback((roomCode: string, username: string, avatarUrl?: string) => {
    localStorage.setItem(STORAGE_KEY_USERNAME, username);
    localStorage.setItem(STORAGE_KEY_ROOM_CODE, roomCode);
    const existingPlayerId = localStorage.getItem(STORAGE_KEY_PLAYER_ID);
    send('JOIN_ROOM', { roomCode, username, avatarUrl, playerId: existingPlayerId });
  }, [send]);

  const startGame = useCallback(() => {
    send('START_GAME');
  }, [send]);

  const addBot = useCallback(() => {
    send('ADD_BOT');
  }, [send]);

  const playCard = useCallback((cardId: string, declaredColor?: CardColor, isBluffPlay: boolean = false) => {
    // Optimistic haptic vibration
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(isBluffPlay ? [40, 60, 40] : 30);
    }
    soundEngine.playCardSnap();
    send('PLAY_CARD', { cardId, declaredColor, isBluffPlay });
  }, [send]);

  const callBluff = useCallback(() => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate([80, 50, 80]);
    }
    soundEngine.playBluffAlarm();
    send('CALL_BLUFF');
  }, [send]);

  const drawCard = useCallback(() => {
    soundEngine.playCardSnap();
    send('DRAW_CARD');
  }, [send]);

  const raiseAnte = useCallback((amount: number) => {
    soundEngine.playChipClink();
    send('RAISE_ANTE', { amount });
  }, [send]);

  const playMeld = useCallback((cardIds: string[]) => {
    soundEngine.playChipClink();
    send('PLAY_MELD', { cardIds });
  }, [send]);

  const sendEmote = useCallback((emote: string) => {
    send('SEND_EMOTE', { emote });
  }, [send]);

  const leaveTable = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY_ROOM_CODE);
    setGameState(null);
    window.location.reload();
  }, []);

  return {
    gameState,
    isConnected,
    lastError,
    createRoom,
    joinRoom,
    startGame,
    addBot,
    playCard,
    callBluff,
    drawCard,
    raiseAnte,
    playMeld,
    sendEmote,
    leaveTable,
  };
}
