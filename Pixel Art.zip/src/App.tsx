/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ToolType, 
  Layer, 
  OnionSkinConfig, 
  PeerInfo 
} from './types';
import { RETRO_PALETTES } from './constants/palettes';
import { 
  DEFAULT_LAYERS, 
  getStarterKnightFrames, 
  createEmptyGrid, 
  createEmptyFrame,
  saveProjectToStorage, 
  loadProjectFromStorage 
} from './utils/storage';
import { HistoryManager, HistoryCommand } from './utils/history';
import { snapColorToPalette } from './utils/color';
import { sounds } from './utils/audio';
import { peerService } from './services/peerService';

// Studio UI Components
import { TopMenuBar } from './components/TopMenuBar';
import { Toolbar } from './components/Toolbar';
import { CanvasViewport } from './components/CanvasViewport';
import { TimelineDock } from './components/TimelineDock';
import { RightSidebar } from './components/RightSidebar';
import { ExportModal } from './components/ExportModal';
import { SpriteGameModal } from './components/SpriteGameModal';
import { PeerJamModal } from './components/PeerJamModal';
import { AiGeneratorModal } from './components/AiGeneratorModal';
import { ResizeCanvasModal } from './components/ResizeCanvasModal';

export default function App() {
  // 1. Dimensions & Canvas Transform
  const [dimensions, setDimensions] = useState<{ width: number; height: number }>({ width: 16, height: 16 });
  const [zoom, setZoom] = useState<number>(24);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // 2. Active Tools & Color
  const [activeTool, setActiveTool] = useState<ToolType>('pencil');
  const [brushSize, setBrushSize] = useState<number>(1);
  const [primaryColor, setPrimaryColor] = useState<string>('#ffffff');
  const [secondaryColor, setSecondaryColor] = useState<string>('#000000');
  const [palette, setPalette] = useState<string[]>(RETRO_PALETTES[2].colors); // PICO-8 default
  const [activePaletteId, setActivePaletteId] = useState<string>('pico-8');

  // 3. Layers & Multi-frame Matrix [frameIndex][layerIndex][y][x]
  const [layers, setLayers] = useState<Layer[]>(DEFAULT_LAYERS);
  const [activeLayerId, setActiveLayerId] = useState<string>('layer-flats');
  const [frames, setFrames] = useState<(string | null)[][][][]>(() => getStarterKnightFrames());
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(0);

  // 4. Animation & Playback
  const [fps, setFps] = useState<number>(8);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [onionSkin, setOnionSkin] = useState<OnionSkinConfig>({
    enabled: true,
    framesBefore: 1,
    framesAfter: 1,
    opacity: 0.35,
    tintPast: '#ef4444',
    tintFuture: '#3b82f6',
  });

  // 5. Grid, HUD & Symmetry
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showCoordinates, setShowCoordinates] = useState<boolean>(true);
  const [symmetryHorizontal, setSymmetryHorizontal] = useState<boolean>(false);
  const [symmetryVertical, setSymmetryVertical] = useState<boolean>(false);

  // 6. History Stack (Command Pattern capped at 50 ops)
  const historyRef = useRef<HistoryManager>(new HistoryManager(50));
  const [canUndo, setCanUndo] = useState<boolean>(false);
  const [canRedo, setCanRedo] = useState<boolean>(false);

  // 7. Modals
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isGameOpen, setIsGameOpen] = useState(false);
  const [isPeerJamOpen, setIsPeerJamOpen] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isResizeOpen, setIsResizeOpen] = useState(false);

  // 8. Live Peer Jam State
  const [roomCode, setRoomCode] = useState<string>('');
  const [peers, setPeers] = useState<PeerInfo[]>([]);
  const [localPeer, setLocalPeer] = useState<PeerInfo>(peerService.localPeer);

  // Sync undo/redo button states
  const updateHistoryState = useCallback(() => {
    setCanUndo(historyRef.current.canUndo());
    setCanRedo(historyRef.current.canRedo());
  }, []);

  // Peer Jam listener setup
  useEffect(() => {
    // Check URL hash for peer room invitation (e.g. #jam=ROOM)
    const hash = window.location.hash;
    if (hash.includes('jam=')) {
      const code = hash.split('jam=')[1]?.split('&')[0];
      if (code) {
        peerService.joinRoom(code);
        setRoomCode(code);
      }
    }

    const unsubPeers = peerService.onPeersChange((pList) => {
      setPeers(pList);
    });

    const unsubDraw = peerService.onRemoteDraw(({ frameIndex, layerIndex, x, y, color }) => {
      setFrames((prev) => {
        if (!prev[frameIndex] || !prev[frameIndex][layerIndex] || !prev[frameIndex][layerIndex][y]) {
          return prev;
        }
        const next = structuredClone(prev);
        next[frameIndex][layerIndex][y][x] = color;
        return next;
      });
    });

    return () => {
      unsubPeers();
      unsubDraw();
    };
  }, []);

  // Peer Jam handlers
  const handleJoinRoom = (code: string) => {
    peerService.joinRoom(code);
    setRoomCode(code);
    window.location.hash = `jam=${code}`;
  };

  const handleLeaveRoom = () => {
    peerService.leaveRoom();
    setRoomCode('');
    window.location.hash = '';
  };

  const handleUpdatePeerName = (name: string) => {
    peerService.updateLocalName(name);
    setLocalPeer({ ...peerService.localPeer });
  };

  const handleSendCursor = (x: number, y: number, active: boolean) => {
    peerService.sendCursor(x, y, active);
  };

  // Commit batch of pixel changes to active state and history stack
  const handleCommitPixelBatch = useCallback((
    diffs: { frameIndex: number; layerIndex: number; x: number; y: number; oldColor: string | null; newColor: string | null }[]
  ) => {
    if (diffs.length === 0) return;

    // Push to history
    historyRef.current.pushCommand({
      type: 'pixel_batch',
      description: `Painted ${diffs.length} pixels`,
      diffs,
    });
    updateHistoryState();

    // Broadcast to live jam peers
    for (const d of diffs) {
      peerService.sendDraw(d.frameIndex, d.layerIndex, d.x, d.y, d.newColor);
    }

    // Sync state
    setFrames((prev) => {
      const next = structuredClone(prev);
      for (const d of diffs) {
        if (next[d.frameIndex]?.[d.layerIndex]?.[d.y]) {
          next[d.frameIndex][d.layerIndex][d.y][d.x] = d.newColor;
        }
      }
      return next;
    });
  }, [updateHistoryState]);

  // Push snapshot to history (e.g. for canvas resize, snap palette, or AI apply)
  const commitSnapshot = useCallback((newFrames: (string | null)[][][][], description: string) => {
    historyRef.current.pushCommand({
      type: 'snapshot',
      description,
      beforeFrames: structuredClone(frames),
      afterFrames: structuredClone(newFrames),
    });
    setFrames(newFrames);
    updateHistoryState();
  }, [frames, updateHistoryState]);

  // Undo / Redo
  const handleUndo = useCallback(() => {
    const nextFrames = historyRef.current.undo(frames);
    if (nextFrames) {
      setFrames(nextFrames);
      sounds.playUndo();
      updateHistoryState();
    }
  }, [frames, updateHistoryState]);

  const handleRedo = useCallback(() => {
    const nextFrames = historyRef.current.redo(frames);
    if (nextFrames) {
      setFrames(nextFrames);
      sounds.playUndo();
      updateHistoryState();
    }
  }, [frames, updateHistoryState]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is currently typing in an input
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      // Undo / Redo
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }

      // Tools
      switch (e.key.toLowerCase()) {
        case 'b':
        case 'p':
          setActiveTool('pencil');
          sounds.playToolSwitch();
          break;
        case 'e':
          setActiveTool('eraser');
          sounds.playToolSwitch();
          break;
        case 'g':
          setActiveTool('bucket');
          sounds.playToolSwitch();
          break;
        case 'i':
          setActiveTool('picker');
          sounds.playToolSwitch();
          break;
        case 'l':
          setActiveTool('line');
          sounds.playToolSwitch();
          break;
        case 'u':
        case 'r':
          setActiveTool('rect');
          sounds.playToolSwitch();
          break;
        case 'c':
          setActiveTool('circle');
          sounds.playToolSwitch();
          break;
        case 'd':
          setActiveTool('dither');
          sounds.playToolSwitch();
          break;
        case 'm':
          setActiveTool('select');
          sounds.playToolSwitch();
          break;
        case 'x':
          // Swap primary and secondary color
          setPrimaryColor(secondaryColor);
          setSecondaryColor(primaryColor);
          sounds.playToolSwitch();
          break;
        case ' ':
          // Play / Pause animation
          e.preventDefault();
          setIsPlaying((prev) => !prev);
          sounds.playToolSwitch();
          break;
        case ',':
          // Previous frame
          setActiveFrameIndex((prev) => (prev - 1 + frames.length) % frames.length);
          sounds.playToolSwitch();
          break;
        case '.':
          // Next frame
          setActiveFrameIndex((prev) => (prev + 1) % frames.length);
          sounds.playToolSwitch();
          break;
        case '1':
          setBrushSize(1);
          sounds.playToolSwitch();
          break;
        case '2':
          setBrushSize(2);
          sounds.playToolSwitch();
          break;
        case '3':
          setBrushSize(3);
          sounds.playToolSwitch();
          break;
        case '4':
          setBrushSize(4);
          sounds.playToolSwitch();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo, primaryColor, secondaryColor, frames.length]);

  // Frame Operations
  const handleAddFrame = () => {
    const newFrame = createEmptyFrame(dimensions.width, dimensions.height, layers.length);
    const newFrames = [...frames, newFrame];
    commitSnapshot(newFrames, 'Add Blank Frame');
    setActiveFrameIndex(newFrames.length - 1);
    sounds.playToolSwitch();
  };

  const handleDuplicateFrame = () => {
    const currentFrameClone = structuredClone(frames[activeFrameIndex]);
    const newFrames = [
      ...frames.slice(0, activeFrameIndex + 1),
      currentFrameClone,
      ...frames.slice(activeFrameIndex + 1),
    ];
    commitSnapshot(newFrames, 'Duplicate Frame');
    setActiveFrameIndex(activeFrameIndex + 1);
    sounds.playToolSwitch();
  };

  const handleDeleteFrame = () => {
    if (frames.length <= 1) return;
    const newFrames = frames.filter((_, idx) => idx !== activeFrameIndex);
    commitSnapshot(newFrames, 'Delete Frame');
    setActiveFrameIndex(Math.max(0, activeFrameIndex - 1));
    sounds.playToolSwitch();
  };

  const handleMoveFrame = (direction: 'left' | 'right') => {
    const targetIdx = direction === 'left' ? activeFrameIndex - 1 : activeFrameIndex + 1;
    if (targetIdx < 0 || targetIdx >= frames.length) return;

    const newFrames = [...frames];
    const temp = newFrames[activeFrameIndex];
    newFrames[activeFrameIndex] = newFrames[targetIdx];
    newFrames[targetIdx] = temp;

    commitSnapshot(newFrames, `Move Frame ${direction}`);
    setActiveFrameIndex(targetIdx);
    sounds.playToolSwitch();
  };

  // Layer Operations
  const handleAddLayer = () => {
    const newLayerId = `layer-${Date.now()}`;
    const newLayer: Layer = {
      id: newLayerId,
      name: `Layer ${layers.length + 1}`,
      visible: true,
      opacity: 1,
      locked: false,
    };

    const nextLayers = [...layers, newLayer];
    const nextFrames = frames.map((f) => [
      ...f,
      createEmptyGrid(dimensions.width, dimensions.height),
    ]);

    setLayers(nextLayers);
    commitSnapshot(nextFrames, 'Add Layer');
    setActiveLayerId(newLayerId);
    sounds.playToolSwitch();
  };

  const handleDuplicateLayer = (layerId: string) => {
    const lIdx = layers.findIndex((l) => l.id === layerId);
    if (lIdx === -1) return;

    const original = layers[lIdx];
    const newLayerId = `layer-${Date.now()}`;
    const newLayer: Layer = {
      ...original,
      id: newLayerId,
      name: `${original.name} Copy`,
    };

    const nextLayers = [...layers];
    nextLayers.splice(lIdx + 1, 0, newLayer);

    const nextFrames = frames.map((f) => {
      const copy = structuredClone(f[lIdx]);
      const nextF = [...f];
      nextF.splice(lIdx + 1, 0, copy);
      return nextF;
    });

    setLayers(nextLayers);
    commitSnapshot(nextFrames, 'Duplicate Layer');
    setActiveLayerId(newLayerId);
    sounds.playToolSwitch();
  };

  const handleDeleteLayer = (layerId: string) => {
    if (layers.length <= 1) return;
    const lIdx = layers.findIndex((l) => l.id === layerId);
    if (lIdx === -1) return;

    const nextLayers = layers.filter((l) => l.id !== layerId);
    const nextFrames = frames.map((f) => f.filter((_, idx) => idx !== lIdx));

    setLayers(nextLayers);
    commitSnapshot(nextFrames, 'Delete Layer');
    setActiveLayerId(nextLayers[Math.max(0, lIdx - 1)].id);
    sounds.playToolSwitch();
  };

  const handleToggleLayerVisibility = (layerId: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === layerId ? { ...l, visible: !l.visible } : l))
    );
    sounds.playToolSwitch();
  };

  const handleToggleLayerLock = (layerId: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === layerId ? { ...l, locked: !l.locked } : l))
    );
    sounds.playToolSwitch();
  };

  const handleChangeLayerOpacity = (layerId: string, opacity: number) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === layerId ? { ...l, opacity } : l))
    );
  };

  const handleRenameLayer = (layerId: string, newName: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === layerId ? { ...l, name: newName } : l))
    );
  };

  const handleReorderLayer = (layerId: string, direction: 'up' | 'down') => {
    const lIdx = layers.findIndex((l) => l.id === layerId);
    const targetIdx = direction === 'up' ? lIdx + 1 : lIdx - 1;
    if (targetIdx < 0 || targetIdx >= layers.length) return;

    const nextLayers = [...layers];
    const tempL = nextLayers[lIdx];
    nextLayers[lIdx] = nextLayers[targetIdx];
    nextLayers[targetIdx] = tempL;

    const nextFrames = frames.map((f) => {
      const nextF = [...f];
      const tempG = nextF[lIdx];
      nextF[lIdx] = nextF[targetIdx];
      nextF[targetIdx] = tempG;
      return nextF;
    });

    setLayers(nextLayers);
    commitSnapshot(nextFrames, 'Reorder Layer');
    sounds.playToolSwitch();
  };

  // Flip Horizontal
  const handleFlipHorizontal = () => {
    const activeLayerIdx = Math.max(0, layers.findIndex((l) => l.id === activeLayerId));
    const nextFrames = structuredClone(frames);
    const grid = nextFrames[activeFrameIndex][activeLayerIdx];

    for (let y = 0; y < dimensions.height; y++) {
      grid[y].reverse();
    }

    commitSnapshot(nextFrames, 'Flip Horizontal');
    sounds.playToolSwitch();
  };

  // Flip Vertical
  const handleFlipVertical = () => {
    const activeLayerIdx = Math.max(0, layers.findIndex((l) => l.id === activeLayerId));
    const nextFrames = structuredClone(frames);
    nextFrames[activeFrameIndex][activeLayerIdx].reverse();

    commitSnapshot(nextFrames, 'Flip Vertical');
    sounds.playToolSwitch();
  };

  // Rotate 90deg Clockwise
  const handleRotate90 = () => {
    const activeLayerIdx = Math.max(0, layers.findIndex((l) => l.id === activeLayerId));
    const nextFrames = structuredClone(frames);
    const oldGrid = nextFrames[activeFrameIndex][activeLayerIdx];
    const newGrid = createEmptyGrid(dimensions.height, dimensions.width);

    for (let y = 0; y < dimensions.height; y++) {
      for (let x = 0; x < dimensions.width; x++) {
        newGrid[x][dimensions.height - 1 - y] = oldGrid[y][x];
      }
    }

    nextFrames[activeFrameIndex][activeLayerIdx] = newGrid;
    commitSnapshot(nextFrames, 'Rotate 90° Clockwise');
    sounds.playToolSwitch();
  };

  // Clear Active Frame
  const handleClearCanvas = () => {
    const activeLayerIdx = Math.max(0, layers.findIndex((l) => l.id === activeLayerId));
    const nextFrames = structuredClone(frames);
    nextFrames[activeFrameIndex][activeLayerIdx] = createEmptyGrid(dimensions.width, dimensions.height);
    commitSnapshot(nextFrames, 'Clear Active Layer');
    sounds.playToolSwitch();
  };

  // New Blank Project
  const handleNewCanvas = () => {
    const freshFrames = [createEmptyFrame(dimensions.width, dimensions.height, layers.length)];
    commitSnapshot(freshFrames, 'New Canvas');
    setActiveFrameIndex(0);
    sounds.playToolSwitch();
  };

  // Resize or Crop Canvas Dimensions
  const handleApplyResize = (newWidth: number, newHeight: number) => {
    const nextFrames = frames.map((frame) =>
      frame.map((layerGrid) => {
        const newGrid = createEmptyGrid(newWidth, newHeight);
        const copyW = Math.min(dimensions.width, newWidth);
        const copyH = Math.min(dimensions.height, newHeight);
        for (let y = 0; y < copyH; y++) {
          for (let x = 0; x < copyW; x++) {
            newGrid[y][x] = layerGrid[y]?.[x] ?? null;
          }
        }
        return newGrid;
      })
    );

    setDimensions({ width: newWidth, height: newHeight });
    commitSnapshot(nextFrames, `Resize Canvas to ${newWidth}x${newHeight}`);
  };

  // Snap entire sprite colors to chosen retro hardware palette!
  const handleSnapCanvasToPalette = (paletteColors: string[]) => {
    const nextFrames = frames.map((frame) =>
      frame.map((layerGrid) =>
        layerGrid.map((row) =>
          row.map((cell) => (cell ? snapColorToPalette(cell, paletteColors) : null))
        )
      )
    );

    commitSnapshot(nextFrames, 'Snap to Hardware Palette');
    sounds.playSuccess();
  };

  // Load Sample Sprites
  const handleLoadStarterSprite = (type: 'knight' | 'heart' | 'coin') => {
    if (type === 'knight') {
      setDimensions({ width: 16, height: 16 });
      const kFrames = getStarterKnightFrames();
      commitSnapshot(kFrames, 'Load Hero Knight');
      setActiveFrameIndex(0);
    } else if (type === 'heart') {
      setDimensions({ width: 16, height: 16 });
      const hFrames: (string | null)[][][][] = [];
      const red = '#ff004d';
      const pink = '#ff77a8';
      const white = '#ffffff';

      // 3 beating heart frames
      [1, 1.15, 0.95].forEach((scale) => {
        const f = createEmptyFrame(16, 16, layers.length);
        const g = f[1]; // flats
        for (let y = 3; y <= 12; y++) {
          for (let x = 2; x <= 13; x++) {
            const nx = (x - 7.5) / (5 * scale);
            const ny = (y - 7.5) / (5 * scale);
            // Heart implicit formula
            if (Math.pow(nx * nx + ny * ny - 1, 3) - nx * nx * ny * ny * ny <= 0) {
              g[y][x] = (x < 6 && y < 6) ? white : (y > 9 ? pink : red);
            }
          }
        }
        hFrames.push(f);
      });
      commitSnapshot(hFrames, 'Load Beating Heart');
      setActiveFrameIndex(0);
    } else if (type === 'coin') {
      setDimensions({ width: 16, height: 16 });
      const cFrames: (string | null)[][][][] = [];
      const gold = '#ffa300';
      const yellow = '#ffec27';
      const darkGold = '#ab5236';

      // 4 spinning coin frames with varying width
      [6, 4, 2, 4].forEach((coinWidth) => {
        const f = createEmptyFrame(16, 16, layers.length);
        const g = f[1];
        const half = Math.floor(coinWidth / 2);
        for (let y = 3; y <= 12; y++) {
          for (let dx = -half; dx <= half; dx++) {
            const x = 8 + dx;
            if (x >= 0 && x < 16) {
              g[y][x] = dx === -half ? darkGold : dx === 0 ? yellow : gold;
            }
          }
        }
        cFrames.push(f);
      });
      commitSnapshot(cFrames, 'Load Spinning Coin');
      setActiveFrameIndex(0);
    }
    sounds.playSuccess();
  };

  // Apply AI Generated / Quantized Pixels to active frame/layer
  const handleApplyGeneratedPixels = (pixels: (string | null)[][]) => {
    const activeLayerIdx = Math.max(0, layers.findIndex((l) => l.id === activeLayerId));
    const nextFrames = structuredClone(frames);
    nextFrames[activeFrameIndex][activeLayerIdx] = pixels;
    commitSnapshot(nextFrames, 'Apply AI Generated Pixels');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#090a0f] text-[#f4f4f5] overflow-hidden select-none">
      {/* 1. Top Menubar */}
      <TopMenuBar
        canUndo={canUndo}
        canRedo={canRedo}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onNewCanvas={handleNewCanvas}
        onResizeCanvas={() => setIsResizeOpen(true)}
        onClearCanvas={handleClearCanvas}
        onFlipHorizontal={handleFlipHorizontal}
        onFlipVertical={handleFlipVertical}
        onRotate90={handleRotate90}
        onExportModalOpen={() => setIsExportOpen(true)}
        onPeerJamOpen={() => setIsPeerJamOpen(true)}
        onGameModalOpen={() => setIsGameOpen(true)}
        onAiModalOpen={() => setIsAiOpen(true)}
        onLoadStarterSprite={handleLoadStarterSprite}
        showGrid={showGrid}
        setShowGrid={setShowGrid}
        onionSkinEnabled={onionSkin.enabled}
        setOnionSkinEnabled={(val) => setOnionSkin((prev) => ({ ...prev, enabled: typeof val === 'function' ? val(prev.enabled) : val }))}
        showCoordinates={showCoordinates}
        setShowCoordinates={setShowCoordinates}
        peerCount={peers.length}
        isPeerConnected={!!roomCode}
      />

      {/* 2. Middle Body: Toolbar + Canvas Viewport + Right Sidebar */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Toolbar */}
        <Toolbar
          activeTool={activeTool}
          setActiveTool={setActiveTool}
          brushSize={brushSize}
          setBrushSize={setBrushSize}
          primaryColor={primaryColor}
          secondaryColor={secondaryColor}
          setPrimaryColor={setPrimaryColor}
          setSecondaryColor={setSecondaryColor}
          symmetryHorizontal={symmetryHorizontal}
          setSymmetryHorizontal={setSymmetryHorizontal}
          symmetryVertical={symmetryVertical}
          setSymmetryVertical={setSymmetryVertical}
        />

        {/* Center Canvas Viewport */}
        <CanvasViewport
          dimensions={dimensions}
          zoom={zoom}
          setZoom={setZoom}
          pan={pan}
          setPan={setPan}
          activeTool={activeTool}
          brushSize={brushSize}
          primaryColor={primaryColor}
          secondaryColor={secondaryColor}
          setPrimaryColor={setPrimaryColor}
          layers={layers}
          activeLayerId={activeLayerId}
          frames={frames}
          activeFrameIndex={activeFrameIndex}
          onionSkin={onionSkin}
          showGrid={showGrid}
          setShowGrid={setShowGrid}
          showCoordinates={showCoordinates}
          symmetryHorizontal={symmetryHorizontal}
          symmetryVertical={symmetryVertical}
          peers={peers}
          onCommitPixelBatch={handleCommitPixelBatch}
          onSendCursor={handleSendCursor}
        />

        {/* Right Dock / Sidebar */}
        <RightSidebar
          primaryColor={primaryColor}
          setPrimaryColor={setPrimaryColor}
          secondaryColor={secondaryColor}
          setSecondaryColor={setSecondaryColor}
          palette={palette}
          setPalette={setPalette}
          activePaletteId={activePaletteId}
          setActivePaletteId={setActivePaletteId}
          layers={layers}
          activeLayerId={activeLayerId}
          setActiveLayerId={setActiveLayerId}
          onAddLayer={handleAddLayer}
          onDuplicateLayer={handleDuplicateLayer}
          onDeleteLayer={handleDeleteLayer}
          onToggleLayerVisibility={handleToggleLayerVisibility}
          onToggleLayerLock={handleToggleLayerLock}
          onChangeLayerOpacity={handleChangeLayerOpacity}
          onReorderLayer={handleReorderLayer}
          onMergeLayerDown={() => {}}
          onRenameLayer={handleRenameLayer}
          onSnapCanvasToPalette={handleSnapCanvasToPalette}
          frames={frames}
          activeFrameIndex={activeFrameIndex}
          fps={fps}
          dimensions={dimensions}
        />
      </div>

      {/* 3. Bottom Frame-by-Frame Timeline Dock */}
      <TimelineDock
        frames={frames}
        activeFrameIndex={activeFrameIndex}
        setActiveFrameIndex={setActiveFrameIndex}
        fps={fps}
        setFps={setFps}
        isPlaying={isPlaying}
        setIsPlaying={setIsPlaying}
        onionSkin={onionSkin}
        setOnionSkin={setOnionSkin}
        layers={layers}
        dimensions={dimensions}
        onAddFrame={handleAddFrame}
        onDuplicateFrame={handleDuplicateFrame}
        onDeleteFrame={handleDeleteFrame}
        onMoveFrame={handleMoveFrame}
      />

      {/* 4. Modals */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        frames={frames}
        activeFrameIndex={activeFrameIndex}
        layers={layers}
        dimensions={dimensions}
        fps={fps}
      />

      <SpriteGameModal
        isOpen={isGameOpen}
        onClose={() => setIsGameOpen(false)}
        frames={frames}
        layers={layers}
        dimensions={dimensions}
      />

      <PeerJamModal
        isOpen={isPeerJamOpen}
        onClose={() => setIsPeerJamOpen(false)}
        peers={peers}
        roomCode={roomCode}
        onJoinRoom={handleJoinRoom}
        onLeaveRoom={handleLeaveRoom}
        localPeer={localPeer}
        onUpdateName={handleUpdatePeerName}
      />

      <AiGeneratorModal
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
        dimensions={dimensions}
        palette={palette}
        onApplyGeneratedPixels={handleApplyGeneratedPixels}
      />

      <ResizeCanvasModal
        isOpen={isResizeOpen}
        onClose={() => setIsResizeOpen(false)}
        currentDimensions={dimensions}
        onApplyResize={handleApplyResize}
      />
    </div>
  );
}
