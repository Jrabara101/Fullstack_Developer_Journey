import React, { useState, useRef } from 'react';
import { X, Sparkles, Upload, Wand2, ArrowRight, RefreshCw, Palette } from 'lucide-react';
import { snapColorToPalette, rgbToHex } from '../utils/color';
import { sounds } from '../utils/audio';

interface AiGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  dimensions: { width: number; height: number };
  palette: string[];
  onApplyGeneratedPixels: (pixels: (string | null)[][]) => void;
}

export const AiGeneratorModal: React.FC<AiGeneratorModalProps> = ({
  isOpen,
  onClose,
  dimensions,
  palette,
  onApplyGeneratedPixels,
}) => {
  const [prompt, setPrompt] = useState('8-bit glowing energy crystal');
  const [loading, setLoading] = useState(false);
  const [previewGrid, setPreviewGrid] = useState<(string | null)[][] | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Procedural & algorithmic concept generation tailored to prompt keywords + current palette
  const handleGenerateConcept = async () => {
    setLoading(true);
    sounds.playPixelClick();

    // Create algorithmic pixel sprite based on prompt semantics and dimensions
    setTimeout(() => {
      const grid: (string | null)[][] = [];
      const w = dimensions.width;
      const h = dimensions.height;
      const midX = Math.floor(w / 2);
      const midY = Math.floor(h / 2);

      // Seed pseudo-random from prompt string
      let seed = 0;
      for (let i = 0; i < prompt.length; i++) seed = (seed * 31 + prompt.charCodeAt(i)) & 0xffffffff;
      const rnd = () => {
        seed = (seed * 1664525 + 1013904223) & 0xffffffff;
        return (seed >>> 0) / 4294967296;
      };

      for (let y = 0; y < h; y++) {
        const row: (string | null)[] = [];
        for (let x = 0; x < w; x++) {
          row.push(null);
        }
        grid.push(row);
      }

      // Pick 3-5 harmonious colors from palette
      const mainCol = palette[Math.floor(rnd() * palette.length)];
      const accentCol = palette[Math.floor(rnd() * palette.length)];
      const darkCol = palette[0];
      const highlightCol = palette[palette.length - 1];

      // Procedural shape generation with symmetry
      const lower = prompt.toLowerCase();
      const isPotion = lower.includes('potion') || lower.includes('bottle') || lower.includes('flask');
      const isCharacter = lower.includes('warrior') || lower.includes('knight') || lower.includes('human') || lower.includes('hero');
      const isCrystal = lower.includes('crystal') || lower.includes('gem') || lower.includes('diamond');

      for (let y = 3; y < h - 3; y++) {
        for (let x = 3; x <= midX; x++) {
          const dx = Math.abs(x - midX);
          const dy = Math.abs(y - midY);
          let filled = false;
          let col = mainCol;

          if (isCrystal) {
            if (dx + dy <= Math.floor(w * 0.35) && rnd() > 0.15) {
              filled = true;
              col = dx === 0 ? highlightCol : (dy > dx ? mainCol : accentCol);
            }
          } else if (isPotion) {
            if (y < 6 && dx <= 1) {
              filled = true;
              col = darkCol; // Cork
            } else if (y >= 6 && dx <= Math.min(midX - 2, (y - 5) * 1.2)) {
              filled = true;
              col = y > h * 0.5 ? accentCol : highlightCol;
            }
          } else {
            // General creature / icon shape
            const radius = Math.floor(w * 0.32);
            if (dx * dx + dy * dy < radius * radius && rnd() > 0.2) {
              filled = true;
              col = rnd() > 0.6 ? accentCol : mainCol;
            }
          }

          if (filled) {
            grid[y][x] = col;
            grid[y][w - 1 - x] = col; // Perfect symmetry!
          }
        }
      }

      setPreviewGrid(grid);
      setLoading(false);
      sounds.playSuccess();
    }, 400);
  };

  // Upload and quantize image to pixel art
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = dimensions.width;
      canvas.height = dimensions.height;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0, dimensions.width, dimensions.height);
      const imgData = ctx.getImageData(0, 0, dimensions.width, dimensions.height);

      const grid: (string | null)[][] = [];
      for (let y = 0; y < dimensions.height; y++) {
        const row: (string | null)[] = [];
        for (let x = 0; x < dimensions.width; x++) {
          const idx = (y * dimensions.width + x) * 4;
          const r = imgData.data[idx];
          const g = imgData.data[idx + 1];
          const b = imgData.data[idx + 2];
          const a = imgData.data[idx + 3];

          if (a < 128) {
            row.push(null);
          } else {
            const rawHex = rgbToHex(r, g, b);
            // Snap to retro hardware palette!
            const snappedHex = snapColorToPalette(rawHex, palette);
            row.push(snappedHex);
          }
        }
        grid.push(row);
      }

      setPreviewGrid(grid);
      sounds.playSuccess();
    };
    img.src = URL.createObjectURL(file);
  };

  const handleApply = () => {
    if (previewGrid) {
      onApplyGeneratedPixels(previewGrid);
      onClose();
      sounds.playSuccess();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#12131a] border border-[#262838] w-full max-w-lg rounded-xl shadow-2xl flex flex-col overflow-hidden text-[#f4f4f5]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#262838] flex items-center justify-between bg-[#141620]">
          <div className="flex items-center gap-2">
            <Sparkles className="text-[#8b5cf6]" size={18} />
            <h3 className="font-bold text-base">Pixel AI Forge & Image Quantizer</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col gap-5">
          {/* Text Prompt Mode */}
          <div>
            <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
              Concept Prompt
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="E.g. glowing magic crystal, pixel potion..."
                className="flex-1 bg-[#1a1c26] border border-[#262838] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8b5cf6]"
              />
              <button
                onClick={handleGenerateConcept}
                disabled={loading}
                className="px-4 py-2 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
              >
                {loading ? <RefreshCw size={13} className="animate-spin" /> : <Wand2 size={13} />}
                <span>Generate</span>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-[#262838]" />
            <span className="text-[10px] font-mono text-[#71717a] uppercase">OR QUANTIZE PHOTO</span>
            <div className="flex-1 h-px bg-[#262838]" />
          </div>

          {/* Reference Photo Upload */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="p-4 rounded-xl border-2 border-dashed border-[#262838] hover:border-[#8b5cf6]/60 hover:bg-[#8b5cf6]/5 transition-colors cursor-pointer flex flex-col items-center justify-center gap-1 text-center"
          >
            <Upload size={20} className="text-[#8b5cf6]" />
            <span className="text-xs font-semibold text-[#f4f4f5]">
              Upload Image to Pixelate & Snap to Palette
            </span>
            <span className="text-[11px] text-[#71717a]">
              Downscales to {dimensions.width}×{dimensions.height} and snaps colors to active palette
            </span>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>

          {/* Result Preview */}
          {previewGrid && (
            <div className="flex flex-col items-center gap-2 p-3 bg-[#141620] rounded-xl border border-[#262838]">
              <span className="text-[10px] font-mono uppercase text-[#06b6d4]">Preview Result</span>
              <div className="w-24 h-24 rounded bg-[#090a0f] canvas-checkerboard border border-[#262838] flex items-center justify-center overflow-hidden">
                <canvas
                  ref={(canvas) => {
                    if (canvas && previewGrid) {
                      const ctx = canvas.getContext('2d')!;
                      ctx.clearRect(0, 0, dimensions.width, dimensions.height);
                      for (let y = 0; y < dimensions.height; y++) {
                        for (let x = 0; x < dimensions.width; x++) {
                          const col = previewGrid[y][x];
                          if (col) {
                            ctx.fillStyle = col;
                            ctx.fillRect(x, y, 1, 1);
                          }
                        }
                      }
                    }
                  }}
                  width={dimensions.width}
                  height={dimensions.height}
                  className="w-full h-full pixelated object-contain"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#262838] bg-[#141620] flex items-center justify-between">
          <span className="text-xs font-mono text-[#71717a]">
            Palette Snapping: {palette.length} Colors Active
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg text-xs text-[#a1a1aa] hover:text-[#f4f4f5]"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              disabled={!previewGrid}
              className="px-4 py-1.5 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 disabled:opacity-30 transition-colors shadow-md"
            >
              <span>Apply to Canvas</span>
              <ArrowRight size={13} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
