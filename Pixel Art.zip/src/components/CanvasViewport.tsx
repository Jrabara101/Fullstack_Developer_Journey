import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  ToolType, 
  Layer, 
  SelectionArea, 
  OnionSkinConfig, 
  PeerInfo 
} from '../types';
import { 
  getBresenhamLine, 
  getRectanglePoints, 
  getCirclePoints, 
  getBrushFootprint, 
  applySymmetry, 
  Point 
} from '../utils/bresenham';
import { floodFill } from '../utils/floodFill';
import { hexToRgb } from '../utils/color';
import { sounds } from '../utils/audio';
import { ZoomIn, ZoomOut, Maximize2, Grid } from 'lucide-react';

interface CanvasViewportProps {
  dimensions: { width: number; height: number };
  zoom: number;
  setZoom: React.Dispatch<React.SetStateAction<number>>;
  pan: { x: number; y: number };
  setPan: React.Dispatch<React.SetStateAction<{ x: number; y: number }>>;
  activeTool: ToolType;
  brushSize: number;
  primaryColor: string;
  secondaryColor: string;
  setPrimaryColor: (color: string) => void;
  layers: Layer[];
  activeLayerId: string;
  frames: (string | null)[][][][];
  activeFrameIndex: number;
  onionSkin: OnionSkinConfig;
  showGrid: boolean;
  setShowGrid: React.Dispatch<React.SetStateAction<boolean>>;
  showCoordinates: boolean;
  symmetryHorizontal: boolean;
  symmetryVertical: boolean;
  peers: PeerInfo[];
  onCommitPixelBatch: (diffs: { frameIndex: number; layerIndex: number; x: number; y: number; oldColor: string | null; newColor: string | null }[]) => void;
  onSendCursor: (x: number, y: number, active: boolean) => void;
}

export const CanvasViewport: React.FC<CanvasViewportProps> = ({
  dimensions,
  zoom,
  setZoom,
  pan,
  setPan,
  activeTool,
  brushSize,
  primaryColor,
  secondaryColor,
  setPrimaryColor,
  layers,
  activeLayerId,
  frames,
  activeFrameIndex,
  onionSkin,
  showGrid,
  setShowGrid,
  showCoordinates,
  symmetryHorizontal,
  symmetryVertical,
  peers,
  onCommitPixelBatch,
  onSendCursor,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Layered HTML5 Canvases
  const gridCanvasRef = useRef<HTMLCanvasElement>(null);
  const onionCanvasRef = useRef<HTMLCanvasElement>(null);
  const drawingCanvasRef = useRef<HTMLCanvasElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);

  // Interaction State
  const [isMouseDown, setIsMouseDown] = useState(false);
  const [mouseButton, setMouseButton] = useState<number>(0); // 0 = left, 2 = right
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [hoverCoord, setHoverCoord] = useState<{ x: number; y: number } | null>(null);
  const [dragStartCoord, setDragStartCoord] = useState<Point | null>(null);
  const [lastDrawnPoint, setLastDrawnPoint] = useState<Point | null>(null);
  
  // Selection
  const [selection, setSelection] = useState<SelectionArea>({
    startX: 0,
    startY: 0,
    endX: 0,
    endY: 0,
    active: false,
  });

  // Track modified pixels during current stroke for atomic commit & undo
  const currentStrokeDiffs = useRef<Map<string, { frameIndex: number; layerIndex: number; x: number; y: number; oldColor: string | null; newColor: string | null }>>(new Map());

  const activeLayerIndex = Math.max(0, layers.findIndex(l => l.id === activeLayerId));
  const activeLayer = layers[activeLayerIndex];

  // Convert client viewport coordinates to Canvas Pixel (X, Y)
  const clientToPixel = useCallback((clientX: number, clientY: number): Point | null => {
    if (!containerRef.current) return null;
    const rect = containerRef.current.getBoundingClientRect();
    
    // Canvas center with pan
    const cx = rect.width / 2 + pan.x;
    const cy = rect.height / 2 + pan.y;

    const scaledW = dimensions.width * zoom;
    const scaledH = dimensions.height * zoom;

    const canvasLeft = cx - scaledW / 2;
    const canvasTop = cy - scaledH / 2;

    const localX = clientX - rect.left - canvasLeft;
    const localY = clientY - rect.top - canvasTop;

    const pixelX = Math.floor(localX / zoom);
    const pixelY = Math.floor(localY / zoom);

    if (pixelX < 0 || pixelX >= dimensions.width || pixelY < 0 || pixelY >= dimensions.height) {
      return null;
    }

    return { x: pixelX, y: pixelY };
  }, [dimensions, zoom, pan]);

  // Center canvas view
  const handleCenterView = () => {
    setPan({ x: 0, y: 0 });
    // Fit comfortably
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const idealZoom = Math.min(
        Math.floor((rect.width * 0.7) / dimensions.width),
        Math.floor((rect.height * 0.7) / dimensions.height)
      );
      setZoom(Math.max(4, Math.min(64, idealZoom)));
    }
  };

  // 1. Render Background Grid & Symmetry guidelines
  useEffect(() => {
    const canvas = gridCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (showGrid) {
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';

      for (let x = 0; x <= dimensions.width; x++) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, dimensions.height);
        ctx.stroke();
      }

      for (let y = 0; y <= dimensions.height; y++) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(dimensions.width, y);
        ctx.stroke();
      }
    }

    // Symmetry guidelines
    if (symmetryHorizontal) {
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.6)'; // Cyan guide
      ctx.lineWidth = 1;
      ctx.beginPath();
      const midX = dimensions.width / 2;
      ctx.moveTo(midX, 0);
      ctx.lineTo(midX, dimensions.height);
      ctx.stroke();
    }

    if (symmetryVertical) {
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.6)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      const midY = dimensions.height / 2;
      ctx.moveTo(0, midY);
      ctx.lineTo(dimensions.width, midY);
      ctx.stroke();
    }
  }, [dimensions, showGrid, symmetryHorizontal, symmetryVertical]);

  // 2. Render Onion-Skinning Ghost Layer
  useEffect(() => {
    const canvas = onionCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!onionSkin.enabled || frames.length <= 1) return;

    // Past Frames (tintPast)
    for (let offset = 1; offset <= onionSkin.framesBefore; offset++) {
      const pastIndex = activeFrameIndex - offset;
      if (pastIndex >= 0) {
        const frameData = frames[pastIndex];
        const alpha = (onionSkin.opacity / offset) * 0.75;
        renderFrameGhost(ctx, frameData, layers, dimensions, onionSkin.tintPast, alpha);
      }
    }

    // Future Frames (tintFuture)
    for (let offset = 1; offset <= onionSkin.framesAfter; offset++) {
      const futureIndex = activeFrameIndex + offset;
      if (futureIndex < frames.length) {
        const frameData = frames[futureIndex];
        const alpha = (onionSkin.opacity / offset) * 0.75;
        renderFrameGhost(ctx, frameData, layers, dimensions, onionSkin.tintFuture, alpha);
      }
    }
  }, [onionSkin, activeFrameIndex, frames, layers, dimensions]);

  // Helper to render onion skin tinted ghost
  const renderFrameGhost = (
    ctx: CanvasRenderingContext2D,
    frame: (string | null)[][][],
    layerList: Layer[],
    dims: { width: number; height: number },
    tintColor: string,
    alpha: number
  ) => {
    const tintRgb = hexToRgb(tintColor);
    ctx.save();
    ctx.globalAlpha = alpha;

    for (let l = 0; l < layerList.length; l++) {
      if (!layerList[l].visible) continue;
      const layerGrid = frame[l];
      if (!layerGrid) continue;

      for (let y = 0; y < dims.height; y++) {
        for (let x = 0; x < dims.width; x++) {
          const color = layerGrid[y]?.[x];
          if (color) {
            ctx.fillStyle = `rgb(${tintRgb.r}, ${tintRgb.g}, ${tintRgb.b})`;
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }
    }
    ctx.restore();
  };

  // 3. Render Active Drawing Canvas (Composites visible layers with opacity)
  useEffect(() => {
    const canvas = drawingCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const currentFrame = frames[activeFrameIndex];
    if (!currentFrame) return;

    // Render layers from bottom to top
    for (let l = 0; l < layers.length; l++) {
      const layer = layers[l];
      if (!layer.visible || layer.opacity <= 0) continue;

      const layerGrid = currentFrame[l];
      if (!layerGrid) continue;

      ctx.save();
      ctx.globalAlpha = layer.opacity;

      for (let y = 0; y < dimensions.height; y++) {
        for (let x = 0; x < dimensions.width; x++) {
          const hex = layerGrid[y]?.[x];
          if (hex) {
            ctx.fillStyle = hex;
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }
      ctx.restore();
    }
  }, [frames, activeFrameIndex, layers, dimensions]);

  // 4. Render Hover Overlay (Brush footprint, shape preview, selection, peer cursors)
  useEffect(() => {
    const canvas = overlayCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Hover or drag preview
    if (hoverCoord && !isPanning) {
      let previewPoints: Point[] = [];

      if (isMouseDown && dragStartCoord && (activeTool === 'line' || activeTool === 'rect' || activeTool === 'circle')) {
        // Dragging shape
        if (activeTool === 'line') {
          previewPoints = getBresenhamLine(dragStartCoord.x, dragStartCoord.y, hoverCoord.x, hoverCoord.y);
        } else if (activeTool === 'rect') {
          previewPoints = getRectanglePoints(dragStartCoord.x, dragStartCoord.y, hoverCoord.x, hoverCoord.y, false);
        } else if (activeTool === 'circle') {
          const radius = Math.round(Math.hypot(hoverCoord.x - dragStartCoord.x, hoverCoord.y - dragStartCoord.y));
          previewPoints = getCirclePoints(dragStartCoord.x, dragStartCoord.y, radius, false);
        }
      } else if (activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither') {
        const footprint = getBrushFootprint(hoverCoord.x, hoverCoord.y, brushSize);
        previewPoints = applySymmetry(footprint, dimensions.width, dimensions.height, symmetryHorizontal, symmetryVertical);
      } else {
        previewPoints = [hoverCoord];
      }

      // Draw preview pixels
      const drawColor = mouseButton === 2 ? secondaryColor : primaryColor;
      ctx.save();
      ctx.fillStyle = activeTool === 'eraser' ? 'rgba(255, 255, 255, 0.4)' : drawColor;
      ctx.globalAlpha = 0.55;

      for (const p of previewPoints) {
        if (p.x >= 0 && p.x < dimensions.width && p.y >= 0 && p.y < dimensions.height) {
          ctx.fillRect(p.x, p.y, 1, 1);
        }
      }
      ctx.restore();

      // Sharp 1px pixel border highlight for precise targeting
      ctx.strokeStyle = '#8b5cf6';
      ctx.lineWidth = 0.15;
      for (const p of previewPoints) {
        ctx.strokeRect(p.x, p.y, 1, 1);
      }
    }

    // Marquee Selection Bounding Box
    if (selection.active) {
      const minX = Math.min(selection.startX, selection.endX);
      const maxX = Math.max(selection.startX, selection.endX);
      const minY = Math.min(selection.startY, selection.endY);
      const maxY = Math.max(selection.startY, selection.endY);

      ctx.save();
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 0.2;
      ctx.setLineDash([0.5, 0.5]);
      ctx.strokeRect(minX, minY, maxX - minX + 1, maxY - minY + 1);
      ctx.fillStyle = 'rgba(6, 182, 212, 0.15)';
      ctx.fillRect(minX, minY, maxX - minX + 1, maxY - minY + 1);
      ctx.restore();
    }

    // Peer Cursors
    for (const peer of peers) {
      if (peer.cursor && peer.cursor.active && peer.cursor.x >= 0) {
        ctx.save();
        ctx.strokeStyle = peer.color;
        ctx.fillStyle = peer.color;
        ctx.lineWidth = 0.2;
        ctx.strokeRect(peer.cursor.x - 0.5, peer.cursor.y - 0.5, 2, 2);
        ctx.globalAlpha = 0.3;
        ctx.fillRect(peer.cursor.x, peer.cursor.y, 1, 1);
        ctx.restore();
      }
    }
  }, [
    hoverCoord, 
    isMouseDown, 
    dragStartCoord, 
    activeTool, 
    brushSize, 
    primaryColor, 
    secondaryColor, 
    mouseButton, 
    dimensions, 
    symmetryHorizontal, 
    symmetryVertical, 
    selection, 
    peers,
    isPanning
  ]);

  // Handle drawing operation on points
  const paintPoints = useCallback((points: Point[], color: string | null) => {
    if (activeLayer?.locked || !activeLayer?.visible) return;

    const currentFrame = frames[activeFrameIndex];
    if (!currentFrame || !currentFrame[activeLayerIndex]) return;

    const layerGrid = currentFrame[activeLayerIndex];

    for (const p of points) {
      if (p.x < 0 || p.x >= dimensions.width || p.y < 0 || p.y >= dimensions.height) continue;

      // If dither tool: 50% checkerboard filter
      if (activeTool === 'dither' && (p.x + p.y) % 2 !== 0) {
        continue;
      }

      const key = `${p.x},${p.y}`;
      const oldColor = layerGrid[p.y][p.x];

      if (oldColor !== color && !currentStrokeDiffs.current.has(key)) {
        currentStrokeDiffs.current.set(key, {
          frameIndex: activeFrameIndex,
          layerIndex: activeLayerIndex,
          x: p.x,
          y: p.y,
          oldColor,
          newColor: color
        });
      }

      // Draw immediately on active canvas for instant 60fps responsiveness!
      layerGrid[p.y][p.x] = color;
      
      const drawCtx = drawingCanvasRef.current?.getContext('2d');
      if (drawCtx) {
        if (color) {
          drawCtx.fillStyle = color;
          drawCtx.fillRect(p.x, p.y, 1, 1);
        } else {
          drawCtx.clearRect(p.x, p.y, 1, 1);
        }
      }
    }
  }, [activeLayer, activeFrameIndex, activeLayerIndex, dimensions, frames, activeTool]);

  const [isSpaceHeld, setIsSpaceHeld] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        setIsSpaceHeld(true);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        setIsSpaceHeld(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Pointer Down
  const handlePointerDown = (e: React.PointerEvent) => {
    // Middle button or Space held = Pan
    if (e.button === 1 || isSpaceHeld) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      return;
    }

    const pixel = clientToPixel(e.clientX, e.clientY);
    if (!pixel) return;

    setIsMouseDown(true);
    setMouseButton(e.button);
    setDragStartCoord(pixel);
    setLastDrawnPoint(pixel);
    currentStrokeDiffs.current.clear();

    const targetColor = e.button === 2 || activeTool === 'eraser' 
      ? (activeTool === 'eraser' ? null : secondaryColor) 
      : primaryColor;

    if (activeTool === 'picker') {
      // Pick color from composite view
      const curFrame = frames[activeFrameIndex];
      let picked: string | null = null;
      for (let l = layers.length - 1; l >= 0; l--) {
        if (layers[l].visible && curFrame?.[l]?.[pixel.y]?.[pixel.x]) {
          picked = curFrame[l][pixel.y][pixel.x];
          break;
        }
      }
      if (picked) {
        setPrimaryColor(picked);
        sounds.playPixelClick();
      }
      return;
    }

    if (activeTool === 'bucket') {
      const curFrame = frames[activeFrameIndex];
      if (curFrame && curFrame[activeLayerIndex]) {
        const { modifiedPixels } = floodFill(
          curFrame[activeLayerIndex],
          pixel.x,
          pixel.y,
          targetColor
        );
        if (modifiedPixels.length > 0) {
          const diffs = modifiedPixels.map(p => ({
            frameIndex: activeFrameIndex,
            layerIndex: activeLayerIndex,
            x: p.x,
            y: p.y,
            oldColor: curFrame[activeLayerIndex][p.y][p.x],
            newColor: p.color
          }));
          onCommitPixelBatch(diffs);
          sounds.playPixelClick();
        }
      }
      return;
    }

    if (activeTool === 'select') {
      setSelection({
        startX: pixel.x,
        startY: pixel.y,
        endX: pixel.x,
        endY: pixel.y,
        active: true,
      });
      return;
    }

    if (activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither') {
      const footprint = getBrushFootprint(pixel.x, pixel.y, brushSize);
      const points = applySymmetry(footprint, dimensions.width, dimensions.height, symmetryHorizontal, symmetryVertical);
      paintPoints(points, targetColor);
      sounds.playPixelClick();
    }
  };

  // Pointer Move
  const handlePointerMove = (e: React.PointerEvent) => {
    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
      return;
    }

    const pixel = clientToPixel(e.clientX, e.clientY);
    setHoverCoord(pixel);

    if (pixel) {
      onSendCursor(pixel.x, pixel.y, isMouseDown);
    }

    if (!isMouseDown || !pixel) return;

    if (activeTool === 'select' && dragStartCoord) {
      setSelection(prev => ({
        ...prev,
        endX: pixel.x,
        endY: pixel.y,
        active: true,
      }));
      return;
    }

    const targetColor = mouseButton === 2 || activeTool === 'eraser' 
      ? (activeTool === 'eraser' ? null : secondaryColor) 
      : primaryColor;

    if ((activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither') && lastDrawnPoint) {
      // Gapless stroke using Bresenham line between last point and current point
      const line = getBresenhamLine(lastDrawnPoint.x, lastDrawnPoint.y, pixel.x, pixel.y);
      const allPoints: Point[] = [];

      for (const pt of line) {
        const footprint = getBrushFootprint(pt.x, pt.y, brushSize);
        allPoints.push(...footprint);
      }

      const symPoints = applySymmetry(allPoints, dimensions.width, dimensions.height, symmetryHorizontal, symmetryVertical);
      paintPoints(symPoints, targetColor);
      setLastDrawnPoint(pixel);
    }
  };

  // Pointer Up
  const handlePointerUp = () => {
    if (isPanning) {
      setIsPanning(false);
      return;
    }

    if (!isMouseDown) return;
    setIsMouseDown(false);
    setLastDrawnPoint(null);

    const targetColor = mouseButton === 2 || activeTool === 'eraser' 
      ? (activeTool === 'eraser' ? null : secondaryColor) 
      : primaryColor;

    // Finish shape tools (Line, Rect, Circle)
    if (dragStartCoord && hoverCoord) {
      let finalPoints: Point[] = [];
      if (activeTool === 'line') {
        finalPoints = getBresenhamLine(dragStartCoord.x, dragStartCoord.y, hoverCoord.x, hoverCoord.y);
      } else if (activeTool === 'rect') {
        finalPoints = getRectanglePoints(dragStartCoord.x, dragStartCoord.y, hoverCoord.x, hoverCoord.y, false);
      } else if (activeTool === 'circle') {
        const radius = Math.round(Math.hypot(hoverCoord.x - dragStartCoord.x, hoverCoord.y - dragStartCoord.y));
        finalPoints = getCirclePoints(dragStartCoord.x, dragStartCoord.y, radius, false);
      }

      if (finalPoints.length > 0) {
        const symPoints = applySymmetry(finalPoints, dimensions.width, dimensions.height, symmetryHorizontal, symmetryVertical);
        paintPoints(symPoints, targetColor);
      }
    }

    // Commit all accumulated stroke diffs to history stack!
    if (currentStrokeDiffs.current.size > 0) {
      const diffArray = Array.from(currentStrokeDiffs.current.values());
      onCommitPixelBatch(diffArray);
      currentStrokeDiffs.current.clear();
    }

    setDragStartCoord(null);
  };

  // Wheel zoom centered on cursor
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.25 : 0.8;
    setZoom(prev => {
      const next = Math.round(prev * zoomFactor);
      return Math.max(2, Math.min(64, next));
    });
  };

  // Zoom controls
  const handleZoomIn = () => setZoom(z => Math.min(64, Math.round(z * 1.5)));
  const handleZoomOut = () => setZoom(z => Math.max(2, Math.round(z / 1.5)));

  return (
    <div 
      ref={containerRef}
      className="relative flex-1 h-full overflow-hidden bg-[#090a0f] select-none cursor-crosshair touch-none"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
      onContextMenu={(e) => e.preventDefault()}
      onWheel={handleWheel}
    >
      {/* Floating Canvas HUD (Top Left & Top Right) */}
      <div className="absolute top-3 left-4 z-30 flex items-center gap-2 bg-[#12131a]/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#262838] shadow-lg text-xs font-mono">
        <span className="text-[#a1a1aa]">CANVAS</span>
        <span className="text-[#f4f4f5] font-semibold">{dimensions.width}×{dimensions.height}</span>
        <span className="text-[#3b3d54]">|</span>
        <span className="text-[#a1a1aa]">ZOOM</span>
        <span className="text-[#06b6d4] font-semibold">{Math.round((zoom / 1) * 100)}%</span>
        {showCoordinates && hoverCoord && (
          <>
            <span className="text-[#3b3d54]">|</span>
            <span className="text-[#8b5cf6] font-semibold">
              X: {hoverCoord.x.toString().padStart(2, '0')} Y: {hoverCoord.y.toString().padStart(2, '0')}
            </span>
          </>
        )}
      </div>

      {/* Floating View Controls (Bottom Right) */}
      <div className="absolute bottom-4 right-4 z-30 flex items-center gap-1.5 bg-[#12131a]/90 backdrop-blur-md p-1.5 rounded-lg border border-[#262838] shadow-xl">
        <button
          onClick={handleZoomOut}
          className="p-1.5 rounded text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          title="Zoom Out (-)"
        >
          <ZoomOut size={16} />
        </button>
        <button
          onClick={handleCenterView}
          className="p-1.5 rounded text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          title="Reset View & Center"
        >
          <Maximize2 size={16} />
        </button>
        <button
          onClick={handleZoomIn}
          className="p-1.5 rounded text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          title="Zoom In (+)"
        >
          <ZoomIn size={16} />
        </button>
        <div className="w-px h-4 bg-[#262838] mx-0.5" />
        <button
          onClick={() => setShowGrid(prev => !prev)}
          className={`p-1.5 rounded transition-colors ${
            showGrid 
              ? 'bg-[#8b5cf6]/20 text-[#8b5cf6]' 
              : 'text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26]'
          }`}
          title="Toggle Pixel Grid (G)"
        >
          <Grid size={16} />
        </button>
      </div>

      {/* Peer indicators floating tags */}
      {peers.map(peer => {
        if (!peer.cursor?.active || peer.cursor.x < 0) return null;
        const rect = containerRef.current?.getBoundingClientRect();
        if (!rect) return null;
        const cx = rect.width / 2 + pan.x;
        const cy = rect.height / 2 + pan.y;
        const left = cx - (dimensions.width * zoom) / 2 + peer.cursor.x * zoom;
        const top = cy - (dimensions.height * zoom) / 2 + peer.cursor.y * zoom;

        return (
          <div
            key={peer.id}
            className="absolute z-40 pointer-events-none transform -translate-y-6 flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono text-white shadow"
            style={{ left, top, backgroundColor: peer.color }}
          >
            <span>{peer.name}</span>
          </div>
        );
      })}

      {/* Centered Canvas Container with CSS Transform Matrix for 60fps pan & zoom */}
      <div
        className="absolute top-1/2 left-1/2 will-change-transform shadow-[0_0_50px_rgba(0,0,0,0.8)]"
        style={{
          width: dimensions.width,
          height: dimensions.height,
          transform: `translate(-50%, -50%) translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
        }}
      >
        {/* Layer 0: Checkerboard background for alpha pixel transparency */}
        <div className="absolute inset-0 canvas-checkerboard pointer-events-none" />

        {/* Layer 1: Onion-Skin Ghost Layer */}
        <canvas
          ref={onionCanvasRef}
          width={dimensions.width}
          height={dimensions.height}
          className="absolute inset-0 pixelated pointer-events-none"
        />

        {/* Layer 2: Active Drawing Canvas */}
        <canvas
          ref={drawingCanvasRef}
          width={dimensions.width}
          height={dimensions.height}
          className="absolute inset-0 pixelated pointer-events-none"
        />

        {/* Layer 3: Background Pixel Grid */}
        <canvas
          ref={gridCanvasRef}
          width={dimensions.width}
          height={dimensions.height}
          className="absolute inset-0 pixelated pointer-events-none"
        />

        {/* Layer 4: Cursor Hover, Marquee Selection & Drag Preview Overlay */}
        <canvas
          ref={overlayCanvasRef}
          width={dimensions.width}
          height={dimensions.height}
          className="absolute inset-0 pixelated pointer-events-none"
        />
      </div>
    </div>
  );
};
