import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Download, 
  Image, 
  Film, 
  Grid3X3, 
  Code2, 
  Copy, 
  Check, 
  Sliders, 
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Layer, SpriteSheetEngine } from '../types';
import { encodeGif } from '../utils/gifEncoder';
import { sounds } from '../utils/audio';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  frames: (string | null)[][][][];
  activeFrameIndex: number;
  layers: Layer[];
  dimensions: { width: number; height: number };
  fps: number;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  frames,
  activeFrameIndex,
  layers,
  dimensions,
  fps,
}) => {
  const [activeTab, setActiveTab] = useState<'png' | 'gif' | 'spritesheet'>('spritesheet');
  
  // PNG settings
  const [pngScale, setPngScale] = useState<number>(8);
  const [pngScope, setPngScope] = useState<'current' | 'all'>('current');
  const [includeBackground, setIncludeBackground] = useState<boolean>(false);

  // GIF settings
  const [gifScale, setGifScale] = useState<number>(8);
  const [gifFps, setGifFps] = useState<number>(fps);
  const [isGeneratingGif, setIsGeneratingGif] = useState<boolean>(false);
  const [generatedGifUrl, setGeneratedGifUrl] = useState<string | null>(null);

  // Sprite Sheet settings
  const [sheetLayout, setSheetLayout] = useState<'horizontal' | 'vertical' | 'grid'>('horizontal');
  const [sheetColumns, setSheetColumns] = useState<number>(Math.min(frames.length, 4));
  const [sheetPadding, setSheetPadding] = useState<number>(0);
  const [sheetScale, setSheetScale] = useState<number>(1);
  const [targetEngine, setTargetEngine] = useState<SpriteSheetEngine>('godot');
  const [copiedCode, setCopiedCode] = useState(false);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  // Render composite frame to offscreen canvas
  const renderFrameToCanvas = (frameData: (string | null)[][][]): HTMLCanvasElement => {
    const canvas = document.createElement('canvas');
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;
    const ctx = canvas.getContext('2d')!;

    if (includeBackground) {
      ctx.fillStyle = '#141418';
      ctx.fillRect(0, 0, dimensions.width, dimensions.height);
    }

    for (let l = 0; l < layers.length; l++) {
      if (!layers[l].visible) continue;
      const layerGrid = frameData[l];
      if (!layerGrid) continue;

      ctx.save();
      ctx.globalAlpha = layers[l].opacity;

      for (let y = 0; y < dimensions.height; y++) {
        for (let x = 0; x < dimensions.width; x++) {
          const color = layerGrid[y]?.[x];
          if (color) {
            ctx.fillStyle = color;
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }
      ctx.restore();
    }
    return canvas;
  };

  // Generate Sprite Sheet layout canvas
  const generateSpriteSheetCanvas = (): { canvas: HTMLCanvasElement; metadata: any } => {
    const frameCount = frames.length;
    let cols = frameCount;
    let rows = 1;

    if (sheetLayout === 'vertical') {
      cols = 1;
      rows = frameCount;
    } else if (sheetLayout === 'grid') {
      cols = Math.max(1, sheetColumns);
      rows = Math.ceil(frameCount / cols);
    }

    const frameW = dimensions.width * sheetScale;
    const frameH = dimensions.height * sheetScale;

    const sheetWidth = cols * frameW + (cols - 1) * sheetPadding;
    const sheetHeight = rows * frameH + (rows - 1) * sheetPadding;

    const canvas = document.createElement('canvas');
    canvas.width = sheetWidth;
    canvas.height = sheetHeight;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    const frameRects: { frame: number; x: number; y: number; w: number; h: number }[] = [];

    for (let i = 0; i < frameCount; i++) {
      const col = sheetLayout === 'vertical' ? 0 : sheetLayout === 'horizontal' ? i : i % cols;
      const row = sheetLayout === 'vertical' ? i : sheetLayout === 'horizontal' ? 0 : Math.floor(i / cols);

      const destX = col * (frameW + sheetPadding);
      const destY = row * (frameH + sheetPadding);

      const sourceCanvas = renderFrameToCanvas(frames[i]);
      ctx.drawImage(sourceCanvas, 0, 0, dimensions.width, dimensions.height, destX, destY, frameW, frameH);

      frameRects.push({
        frame: i,
        x: destX,
        y: destY,
        w: frameW,
        h: frameH
      });
    }

    return { canvas, metadata: frameRects };
  };

  // Update Sprite Sheet Preview Canvas
  useEffect(() => {
    if (!isOpen || activeTab !== 'spritesheet') return;
    const { canvas: sheetCanvas } = generateSpriteSheetCanvas();
    const target = previewCanvasRef.current;
    if (!target) return;

    target.width = sheetCanvas.width;
    target.height = sheetCanvas.height;
    const ctx = target.getContext('2d');
    if (ctx) {
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, target.width, target.height);
      ctx.drawImage(sheetCanvas, 0, 0);
    }
  }, [isOpen, activeTab, sheetLayout, sheetColumns, sheetPadding, sheetScale, frames, layers, dimensions, includeBackground]);

  // Generate Game Engine Metadata JSON
  const getEngineMetadataJson = (): string => {
    const { metadata } = generateSpriteSheetCanvas();
    
    if (targetEngine === 'godot') {
      return JSON.stringify({
        engine: 'Godot 4.x',
        format: 'SpriteFrames',
        animation: 'default',
        speed: fps,
        loop: true,
        frames: metadata.map((f: any) => ({
          region: { x: f.x, y: f.y, width: f.w, height: f.h },
          duration: 1.0 / fps
        }))
      }, null, 2);
    }

    if (targetEngine === 'phaser') {
      return JSON.stringify({
        textures: [{
          image: 'spritesheet.png',
          format: 'RGBA8888',
          size: {
            w: metadata[metadata.length - 1]?.x + dimensions.width,
            h: metadata[metadata.length - 1]?.y + dimensions.height
          },
          scale: sheetScale,
          frames: metadata.map((f: any, idx: number) => ({
            filename: `frame_${idx.toString().padStart(3, '0')}.png`,
            frame: { x: f.x, y: f.y, w: f.w, h: f.h },
            rotated: false,
            trimmed: false,
            sourceSize: { w: f.w, h: f.h }
          }))
        }]
      }, null, 2);
    }

    if (targetEngine === 'unity') {
      return JSON.stringify({
        unitySpriteData: {
          textureName: 'spritesheet',
          pixelsPerUnit: 16,
          spriteAlignment: 'Center',
          sprites: metadata.map((f: any, idx: number) => ({
            name: `sprite_${idx}`,
            rect: { x: f.x, y: f.y, width: f.w, height: f.h },
            pivot: { x: 0.5, y: 0.5 }
          }))
        }
      }, null, 2);
    }

    // Generic / CSS Sprite Sheet code
    const totalW = metadata.length * dimensions.width * sheetScale;
    return `/* CSS Keyframe Animation for Pixel Art Sprite */
.pixel-sprite {
  width: ${dimensions.width * sheetScale}px;
  height: ${dimensions.height * sheetScale}px;
  background-image: url('spritesheet.png');
  background-repeat: no-repeat;
  image-rendering: pixelated;
  animation: play-sprite ${frames.length / fps}s steps(${frames.length}) infinite;
}

@keyframes play-sprite {
  from { background-position: 0px 0px; }
  to { background-position: -${totalW}px 0px; }
}`;
  };

  // Download Single or All PNGs
  const handleDownloadPng = () => {
    const scale = pngScale;
    const targetW = dimensions.width * scale;
    const targetH = dimensions.height * scale;

    const exportSingle = (frameIdx: number, filename: string) => {
      const srcCanvas = renderFrameToCanvas(frames[frameIdx]);
      const upCanvas = document.createElement('canvas');
      upCanvas.width = targetW;
      upCanvas.height = targetH;
      const ctx = upCanvas.getContext('2d')!;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(srcCanvas, 0, 0, dimensions.width, dimensions.height, 0, 0, targetW, targetH);

      const link = document.createElement('a');
      link.download = filename;
      link.href = upCanvas.toDataURL('image/png');
      link.click();
    };

    if (pngScope === 'current') {
      exportSingle(activeFrameIndex, `pixelart_frame_${activeFrameIndex + 1}_${scale}x.png`);
    } else {
      frames.forEach((_, idx) => {
        exportSingle(idx, `pixelart_frame_${idx + 1}_${scale}x.png`);
      });
    }

    confetti({ particleCount: 50, spread: 60, origin: { y: 0.8 } });
    sounds.playSuccess();
  };

  // Generate & Download Animated GIF
  const handleGenerateAndDownloadGif = async () => {
    setIsGeneratingGif(true);
    try {
      const gifFrames = frames.map((f) => {
        const src = renderFrameToCanvas(f);
        const up = document.createElement('canvas');
        up.width = dimensions.width * gifScale;
        up.height = dimensions.height * gifScale;
        const ctx = up.getContext('2d')!;
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(src, 0, 0, dimensions.width, dimensions.height, 0, 0, up.width, up.height);

        const imgData = ctx.getImageData(0, 0, up.width, up.height);
        return {
          data: imgData.data,
          width: up.width,
          height: up.height,
          delayMs: Math.round(1000 / gifFps)
        };
      });

      const blob = encodeGif(gifFrames);
      const url = URL.createObjectURL(blob);
      setGeneratedGifUrl(url);

      const link = document.createElement('a');
      link.download = `pixelart_anim_${dimensions.width}x${dimensions.height}_${gifScale}x.gif`;
      link.href = url;
      link.click();

      confetti({ particleCount: 60, spread: 70, origin: { y: 0.8 } });
      sounds.playSuccess();
    } catch (err) {
      console.error('GIF export failed:', err);
    } finally {
      setIsGeneratingGif(false);
    }
  };

  // Download Sprite Sheet & JSON
  const handleDownloadSpriteSheet = () => {
    const { canvas } = generateSpriteSheetCanvas();
    const link = document.createElement('a');
    link.download = `spritesheet_${dimensions.width}x${dimensions.height}_${frames.length}f.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();

    // Also download engine JSON metadata
    const jsonBlob = new Blob([getEngineMetadataJson()], { type: 'application/json' });
    const jsonLink = document.createElement('a');
    jsonLink.download = `spritesheet_${targetEngine}_metadata.json`;
    jsonLink.href = URL.createObjectURL(jsonBlob);
    jsonLink.click();

    confetti({ particleCount: 75, spread: 80, origin: { y: 0.8 } });
    sounds.playSuccess();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#12131a] border border-[#262838] w-full max-w-3xl rounded-xl shadow-2xl flex flex-col overflow-hidden text-[#f4f4f5] max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#262838] flex items-center justify-between bg-[#141620]">
          <div className="flex items-center gap-2">
            <Download className="text-[#8b5cf6]" size={18} />
            <h2 className="font-bold text-base">Engine-Ready Exporter</h2>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#1a1c26] text-[#06b6d4] border border-[#262838]">
              {dimensions.width}×{dimensions.height} · {frames.length} FRAMES
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#262838] bg-[#12131a] px-5">
          <button
            onClick={() => setActiveTab('spritesheet')}
            className={`py-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'spritesheet'
                ? 'border-[#8b5cf6] text-[#8b5cf6] bg-[#1a1c26]/50'
                : 'border-transparent text-[#71717a] hover:text-[#a1a1aa]'
            }`}
          >
            <Grid3X3 size={15} />
            <span>Sprite Sheet + Engine JSON</span>
          </button>

          <button
            onClick={() => setActiveTab('gif')}
            className={`py-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'gif'
                ? 'border-[#8b5cf6] text-[#8b5cf6] bg-[#1a1c26]/50'
                : 'border-transparent text-[#71717a] hover:text-[#a1a1aa]'
            }`}
          >
            <Film size={15} />
            <span>Animated GIF</span>
          </button>

          <button
            onClick={() => setActiveTab('png')}
            className={`py-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'png'
                ? 'border-[#8b5cf6] text-[#8b5cf6] bg-[#1a1c26]/50'
                : 'border-transparent text-[#71717a] hover:text-[#a1a1aa]'
            }`}
          >
            <Image size={15} />
            <span>Lossless PNG (Upscaled)</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-6">
          {activeTab === 'spritesheet' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left: Settings */}
              <div className="flex flex-col gap-4">
                <div>
                  <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                    Layout Alignment
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['horizontal', 'vertical', 'grid'] as const).map((l) => (
                      <button
                        key={l}
                        onClick={() => setSheetLayout(l)}
                        className={`py-2 text-xs rounded border capitalize transition-colors ${
                          sheetLayout === l
                            ? 'bg-[#8b5cf6]/20 border-[#8b5cf6] text-[#8b5cf6] font-semibold'
                            : 'bg-[#1a1c26] border-[#262838] text-[#a1a1aa] hover:text-[#f4f4f5]'
                        }`}
                      >
                        {l}
                      </button>
                    ))}
                  </div>
                </div>

                {sheetLayout === 'grid' && (
                  <div>
                    <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                      Columns ({sheetColumns})
                    </label>
                    <input
                      type="range"
                      min="1"
                      max={frames.length}
                      value={sheetColumns}
                      onChange={(e) => setSheetColumns(Number(e.target.value))}
                      className="w-full accent-[#8b5cf6]"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                      Padding (px)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="16"
                      value={sheetPadding}
                      onChange={(e) => setSheetPadding(Number(e.target.value))}
                      className="w-full bg-[#1a1c26] border border-[#262838] rounded px-3 py-1.5 text-xs text-[#f4f4f5]"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                      Scale Multiplier
                    </label>
                    <select
                      value={sheetScale}
                      onChange={(e) => setSheetScale(Number(e.target.value))}
                      className="w-full bg-[#1a1c26] border border-[#262838] rounded px-3 py-1.5 text-xs text-[#f4f4f5]"
                    >
                      {[1, 2, 4, 8].map(s => (
                        <option key={s} value={s}>{s}x ({dimensions.width * s}px)</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                    Target Game Engine
                  </label>
                  <select
                    value={targetEngine}
                    onChange={(e) => setTargetEngine(e.target.value as SpriteSheetEngine)}
                    className="w-full bg-[#1a1c26] border border-[#262838] rounded px-3 py-1.5 text-xs text-[#f4f4f5]"
                  >
                    <option value="godot">Godot 4.x (SpriteFrames JSON)</option>
                    <option value="phaser">Phaser 3 / TexturePacker JSON</option>
                    <option value="unity">Unity Coordinates JSON</option>
                    <option value="generic">CSS Sprite Sheet Animation</option>
                  </select>
                </div>

                {/* Metadata JSON preview */}
                <div className="relative mt-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-mono text-[#71717a]">ENGINE METADATA PREVIEW</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(getEngineMetadataJson());
                        setCopiedCode(true);
                        setTimeout(() => setCopiedCode(false), 2000);
                      }}
                      className="text-[10px] text-[#06b6d4] hover:text-[#22d3ee] flex items-center gap-1 font-mono"
                    >
                      {copiedCode ? <Check size={11} /> : <Copy size={11} />}
                      <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
                    </button>
                  </div>
                  <pre className="p-3 bg-[#090a0f] rounded-lg border border-[#262838] text-[10px] font-mono text-zinc-300 max-h-32 overflow-y-auto scrollbar-thin">
                    {getEngineMetadataJson()}
                  </pre>
                </div>
              </div>

              {/* Right: Sprite Sheet Preview */}
              <div className="flex flex-col items-center justify-center p-4 bg-[#090a0f] canvas-checkerboard rounded-xl border border-[#262838] overflow-hidden min-h-[240px]">
                <canvas
                  ref={previewCanvasRef}
                  className="pixelated shadow-2xl border border-white/10 rounded"
                  style={{
                    imageRendering: 'pixelated',
                    transform: 'scale(2.5)',
                    transformOrigin: 'center center',
                    margin: '20px'
                  }}
                />
              </div>
            </div>
          )}

          {activeTab === 'gif' && (
            <div className="flex flex-col gap-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                    Upscale Resolution ({dimensions.width * gifScale} × {dimensions.height * gifScale} px)
                  </label>
                  <select
                    value={gifScale}
                    onChange={(e) => setGifScale(Number(e.target.value))}
                    className="w-full bg-[#1a1c26] border border-[#262838] rounded px-3 py-2 text-xs text-[#f4f4f5]"
                  >
                    {[1, 2, 4, 8, 16].map((s) => (
                      <option key={s} value={s}>
                        {s}x ({dimensions.width * s} × {dimensions.height * s} px)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                    Animation Speed ({gifFps} FPS)
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="24"
                    value={gifFps}
                    onChange={(e) => setGifFps(Number(e.target.value))}
                    className="w-full accent-[#8b5cf6]"
                  />
                </div>
              </div>

              <div className="p-4 bg-[#1a1c26] rounded-lg border border-[#262838] flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold text-[#f4f4f5]">Multi-Frame LZW GIF89a</h4>
                  <p className="text-xs text-[#a1a1aa]">
                    Lossless nearest-neighbor frames compiled in browser memory with full transparency.
                  </p>
                </div>
                <button
                  onClick={handleGenerateAndDownloadGif}
                  disabled={isGeneratingGif}
                  className="px-4 py-2 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white rounded-lg text-xs font-semibold flex items-center gap-2 disabled:opacity-50 transition-colors shadow-lg"
                >
                  <Download size={14} />
                  <span>{isGeneratingGif ? 'Compiling GIF...' : 'Generate & Download GIF'}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'png' && (
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                    Export Resolution ({dimensions.width * pngScale} × {dimensions.height * pngScale} px)
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[1, 2, 4, 8, 12, 16, 24, 32].map((s) => (
                      <button
                        key={s}
                        onClick={() => setPngScale(s)}
                        className={`py-2 rounded text-xs font-mono border transition-colors ${
                          pngScale === s
                            ? 'bg-[#8b5cf6]/20 border-[#8b5cf6] text-[#8b5cf6] font-bold'
                            : 'bg-[#1a1c26] border-[#262838] text-[#a1a1aa] hover:text-[#f4f4f5]'
                        }`}
                      >
                        {s}x
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                    Export Scope
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setPngScope('current')}
                      className={`py-2 rounded text-xs border transition-colors ${
                        pngScope === 'current'
                          ? 'bg-[#8b5cf6]/20 border-[#8b5cf6] text-[#8b5cf6] font-bold'
                          : 'bg-[#1a1c26] border-[#262838] text-[#a1a1aa]'
                      }`}
                    >
                      Active Frame (#{(activeFrameIndex + 1)})
                    </button>
                    <button
                      onClick={() => setPngScope('all')}
                      className={`py-2 rounded text-xs border transition-colors ${
                        pngScope === 'all'
                          ? 'bg-[#8b5cf6]/20 border-[#8b5cf6] text-[#8b5cf6] font-bold'
                          : 'bg-[#1a1c26] border-[#262838] text-[#a1a1aa]'
                      }`}
                    >
                      All Frames ({frames.length})
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 mt-2">
                <input
                  type="checkbox"
                  id="includeBg"
                  checked={includeBackground}
                  onChange={(e) => setIncludeBackground(e.target.checked)}
                  className="rounded bg-[#1a1c26] border-[#262838] text-[#8b5cf6] focus:ring-0"
                />
                <label htmlFor="includeBg" className="text-xs text-[#a1a1aa] cursor-pointer">
                  Fill transparent areas with dark background color (uncheck for transparent PNG)
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-4 border-t border-[#262838] bg-[#141620] flex items-center justify-between">
          <span className="text-xs font-mono text-[#71717a]">
            Nearest-Neighbor Lossless Pipeline · Zero Blur
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
            >
              Cancel
            </button>
            {activeTab === 'spritesheet' && (
              <button
                onClick={handleDownloadSpriteSheet}
                className="px-5 py-2 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white rounded-lg text-xs font-semibold flex items-center gap-2 shadow-lg transition-colors"
              >
                <Download size={14} />
                <span>Download Sprite Sheet + JSON</span>
              </button>
            )}
            {activeTab === 'png' && (
              <button
                onClick={handleDownloadPng}
                className="px-5 py-2 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white rounded-lg text-xs font-semibold flex items-center gap-2 shadow-lg transition-colors"
              >
                <Download size={14} />
                <span>Download Upscaled PNG ({pngScale}x)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
