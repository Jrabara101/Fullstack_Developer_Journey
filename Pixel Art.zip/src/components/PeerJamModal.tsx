import React, { useState } from 'react';
import { X, Users, Copy, Check, Radio, Link as LinkIcon, LogOut } from 'lucide-react';
import { peerService } from '../services/peerService';
import { PeerInfo } from '../types';
import { sounds } from '../utils/audio';

interface PeerJamModalProps {
  isOpen: boolean;
  onClose: () => void;
  peers: PeerInfo[];
  roomCode: string;
  onJoinRoom: (code: string) => void;
  onLeaveRoom: () => void;
  localPeer: PeerInfo;
  onUpdateName: (name: string) => void;
}

export const PeerJamModal: React.FC<PeerJamModalProps> = ({
  isOpen,
  onClose,
  peers,
  roomCode,
  onJoinRoom,
  onLeaveRoom,
  localPeer,
  onUpdateName,
}) => {
  const [inputCode, setInputCode] = useState(roomCode || 'PIXEL-JAM');
  const [nameInput, setNameInput] = useState(localPeer.name);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const isConnected = !!roomCode;

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputCode.trim()) {
      onJoinRoom(inputCode.trim());
      sounds.playSuccess();
    }
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}${window.location.pathname}#jam=${roomCode}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
    sounds.playToolSwitch();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#12131a] border border-[#262838] w-full max-w-md rounded-xl shadow-2xl flex flex-col overflow-hidden text-[#f4f4f5]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#262838] flex items-center justify-between bg-[#141620]">
          <div className="flex items-center gap-2">
            <Users className="text-[#06b6d4]" size={18} />
            <h3 className="font-bold text-base">Live Peer Jam Mode</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col gap-5">
          {/* User profile row */}
          <div className="p-3.5 bg-[#1a1c26] rounded-lg border border-[#262838] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-8 h-8 rounded-full border-2 border-white/80 shadow"
                style={{ backgroundColor: localPeer.color }}
              />
              <div>
                <label className="text-[10px] font-mono text-[#71717a] uppercase block">
                  Your Artist Handle
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => {
                    setNameInput(e.target.value);
                    onUpdateName(e.target.value);
                  }}
                  className="bg-transparent text-sm font-semibold text-[#f4f4f5] focus:outline-none"
                />
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#12131a] text-[#06b6d4] border border-[#262838]">
              YOU
            </span>
          </div>

          {/* Connection status */}
          {!isConnected ? (
            <form onSubmit={handleJoin} className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-1.5">
                  Room Code
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={inputCode}
                    onChange={(e) => setInputCode(e.target.value.toUpperCase())}
                    placeholder="E.G. RETRO-JAM"
                    className="flex-1 bg-[#1a1c26] border border-[#262838] rounded-lg px-3 py-2 text-xs font-mono uppercase text-white focus:outline-none focus:border-[#06b6d4]"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#06b6d4] hover:bg-[#0891b2] text-[#090a0f] font-bold text-xs rounded-lg transition-colors"
                  >
                    Connect
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-[#71717a]">
                Join or create a collaborative room to draw sprites synchronously with colored peer cursors.
              </p>
            </form>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <div>
                    <div className="text-xs font-mono font-bold text-emerald-400">
                      CONNECTED: ROOM #{roomCode}
                    </div>
                    <div className="text-[10px] text-[#a1a1aa]">
                      Real-time peer broadcast active
                    </div>
                  </div>
                </div>
                <button
                  onClick={onLeaveRoom}
                  className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded border border-rose-500/30 text-xs flex items-center gap-1 font-mono transition-colors"
                  title="Leave Room"
                >
                  <LogOut size={13} />
                  <span>Leave</span>
                </button>
              </div>

              {/* Shareable Link */}
              <div className="flex items-center justify-between p-2.5 bg-[#1a1c26] rounded-lg border border-[#262838]">
                <span className="text-xs font-mono text-[#a1a1aa] truncate mr-2">
                  {window.location.origin}#jam={roomCode}
                </span>
                <button
                  onClick={handleCopyLink}
                  className="px-2.5 py-1 bg-[#12131a] hover:bg-[#262838] text-[#06b6d4] rounded text-xs flex items-center gap-1 border border-[#262838] transition-colors shrink-0"
                >
                  {copiedLink ? <Check size={12} /> : <Copy size={12} />}
                  <span>{copiedLink ? 'Copied' : 'Copy Link'}</span>
                </button>
              </div>

              {/* Connected Peers List */}
              <div>
                <span className="text-xs font-mono uppercase text-[#a1a1aa] block mb-2">
                  Artists in Room ({peers.length + 1})
                </span>
                <div className="flex flex-col gap-1.5 max-h-36 overflow-y-auto scrollbar-thin">
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-[#141620] rounded border border-[#262838]">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: localPeer.color }} />
                    <span className="text-xs font-medium text-white">{localPeer.name} (You)</span>
                  </div>
                  {peers.map((peer) => (
                    <div
                      key={peer.id}
                      className="flex items-center gap-2 px-3 py-1.5 bg-[#141620] rounded border border-[#262838]"
                    >
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: peer.color }} />
                      <span className="text-xs text-[#a1a1aa]">{peer.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#262838] bg-[#141620] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1a1c26] hover:bg-[#262838] text-xs font-medium rounded-lg text-[#f4f4f5] border border-[#262838] transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
