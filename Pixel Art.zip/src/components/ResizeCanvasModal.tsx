import React, { useState } from 'react';
import { X, Maximize, Check } from 'lucide-react';
import { sounds } from '../utils/audio';

interface ResizeCanvasModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentDimensions: { width: number; height: number };
  onApplyResize: (newWidth: number, newHeight: number) => void;
}

export const ResizeCanvasModal: React.FC<ResizeCanvasModalProps> = ({
  isOpen,
  onClose,
  currentDimensions,
  onApplyResize,
}) => {
  const [w, setW] = useState(currentDimensions.width);
  const [h, setH] = useState(currentDimensions.height);

  if (!isOpen) return null;

  const presets = [
    { label: '16×16', w: 16, h: 16, desc: 'Classic Retro Icons & Tiny Sprites' },
    { label: '24×24', w: 24, h: 24, desc: 'Game Boy Color & GBA Characters' },
    { label: '32×32', w: 32, h: 32, desc: 'Detailed 16-Bit Characters & Tiles' },
    { label: '48×48', w: 48, h: 48, desc: 'RPG Bosses & High-Res Pixel Art' },
    { label: '64×64', w: 64, h: 64, desc: 'Portraits, Scene Assets & Weapons' },
  ];

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    const clampedW = Math.max(4, Math.min(128, w));
    const clampedH = Math.max(4, Math.min(128, h));
    onApplyResize(clampedW, clampedH);
    sounds.playSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#12131a] border border-[#262838] w-full max-w-md rounded-xl shadow-2xl flex flex-col overflow-hidden text-[#f4f4f5]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#262838] flex items-center justify-between bg-[#141620]">
          <div className="flex items-center gap-2">
            <Maximize className="text-[#8b5cf6]" size={18} />
            <h3 className="font-bold text-base">Resize Canvas</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleApply} className="p-6 flex flex-col gap-5">
          {/* Presets */}
          <div>
            <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-2">
              Hardware Dimension Presets
            </label>
            <div className="grid grid-cols-1 gap-2">
              {presets.map((p) => {
                const isSelected = w === p.w && h === p.h;
                return (
                  <button
                    type="button"
                    key={p.label}
                    onClick={() => {
                      setW(p.w);
                      setH(p.h);
                      sounds.playToolSwitch();
                    }}
                    className={`px-3 py-2 rounded-lg border text-left flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-[#8b5cf6]/20 border-[#8b5cf6] text-white'
                        : 'bg-[#1a1c26] border-[#262838] text-[#a1a1aa] hover:text-white'
                    }`}
                  >
                    <div>
                      <span className="font-mono font-bold text-xs">{p.label}</span>
                      <span className="text-[11px] text-[#71717a] ml-2">{p.desc}</span>
                    </div>
                    {isSelected && <Check size={14} className="text-[#8b5cf6]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Width & Height */}
          <div>
            <label className="text-xs font-mono uppercase text-[#a1a1aa] block mb-2">
              Custom Size (4px - 128px)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] font-mono text-[#71717a] uppercase block mb-1">Width (px)</span>
                <input
                  type="number"
                  min="4"
                  max="128"
                  value={w}
                  onChange={(e) => setW(Number(e.target.value))}
                  className="w-full bg-[#1a1c26] border border-[#262838] rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#8b5cf6]"
                />
              </div>
              <div>
                <span className="text-[10px] font-mono text-[#71717a] uppercase block mb-1">Height (px)</span>
                <input
                  type="number"
                  min="4"
                  max="128"
                  value={h}
                  onChange={(e) => setH(Number(e.target.value))}
                  className="w-full bg-[#1a1c26] border border-[#262838] rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#8b5cf6]"
                />
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs text-[#a1a1aa] hover:text-white hover:bg-[#1a1c26]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white font-semibold text-xs rounded-lg transition-colors shadow-lg"
            >
              Apply Resize
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
