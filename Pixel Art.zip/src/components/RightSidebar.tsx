import React, { useState, useRef, useEffect } from 'react';
import { 
  Palette, 
  Layers as LayersIcon, 
  Play, 
  Pause, 
  Plus, 
  Eye, 
  EyeOff, 
  Lock, 
  Unlock, 
  Trash2, 
  Copy, 
  ArrowDown, 
  Wand2, 
  Sparkles,
  ChevronUp,
  ChevronDown,
  Droplet
} from 'lucide-react';
import { Layer, PalettePreset } from '../types';
import { RETRO_PALETTES } from '../constants/palettes';
import { generateColorRamp, snapColorToPalette } from '../utils/color';
import { sounds } from '../utils/audio';

interface RightSidebarProps {
  primaryColor: string;
  setPrimaryColor: (color: string) => void;
  secondaryColor: string;
  setSecondaryColor: (color: string) => void;
  palette: string[];
  setPalette: React.Dispatch<React.SetStateAction<string[]>>;
  activePaletteId: string;
  setActivePaletteId: (id: string) => void;
  layers: Layer[];
  activeLayerId: string;
  setActiveLayerId: (id: string) => void;
  onAddLayer: () => void;
  onDuplicateLayer: (layerId: string) => void;
  onDeleteLayer: (layerId: string) => void;
  onToggleLayerVisibility: (layerId: string) => void;
  onToggleLayerLock: (layerId: string) => void;
  onChangeLayerOpacity: (layerId: string, opacity: number) => void;
  onReorderLayer: (layerId: string, direction: 'up' | 'down') => void;
  onMergeLayerDown: (layerId: string) => void;
  onRenameLayer: (layerId: string, newName: string) => void;
  onSnapCanvasToPalette: (paletteColors: string[]) => void;
  frames: (string | null)[][][][];
  activeFrameIndex: number;
  fps: number;
  dimensions: { width: number; height: number };
}

export const RightSidebar: React.FC<RightSidebarProps> = ({
  primaryColor,
  setPrimaryColor,
  secondaryColor,
  setSecondaryColor,
  palette,
  setPalette,
  activePaletteId,
  setActivePaletteId,
  layers,
  activeLayerId,
  setActiveLayerId,
  onAddLayer,
  onDuplicateLayer,
  onDeleteLayer,
  onToggleLayerVisibility,
  onToggleLayerLock,
  onChangeLayerOpacity,
  onReorderLayer,
  onMergeLayerDown,
  onRenameLayer,
  onSnapCanvasToPalette,
  frames,
  activeFrameIndex,
  fps,
  dimensions,
}) => {
  const [activeTab, setActiveTab] = useState<'palette' | 'layers'>('palette');
  const [previewPlaying, setPreviewPlaying] = useState(true);
  const [previewFrame, setPreviewFrame] = useState(0);
  const [editingLayerId, setEditingLayerId] = useState<string | null>(null);
  const [layerNameInput, setLayerNameInput] = useState('');
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  // Dynamic Tint/Shade Ramp based on primary color
  const colorRamp = generateColorRamp(primaryColor, 7);

  // Mini-Previewer animation loop
  useEffect(() => {
    if (!previewPlaying || frames.length <= 1) {
      setPreviewFrame(activeFrameIndex);
      return;
    }

    const interval = 1000 / fps;
    const timer = setInterval(() => {
      setPreviewFrame(prev => (prev + 1) % frames.length);
    }, interval);

    return () => clearInterval(timer);
  }, [previewPlaying, fps, frames.length, activeFrameIndex]);

  // Render mini previewer canvas
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, dimensions.width, dimensions.height);

    const targetFrameData = frames[previewPlaying ? previewFrame : activeFrameIndex];
    if (!targetFrameData) return;

    for (let l = 0; l < layers.length; l++) {
      if (!layers[l].visible) continue;
      const layerGrid = targetFrameData[l];
      if (!layerGrid) continue;

      ctx.save();
      ctx.globalAlpha = layers[l].opacity;

      for (let y = 0; y < dimensions.height; y++) {
        for (let x = 0; x < dimensions.width; x++) {
          const color = layerGrid[y]?.[x];
          if (color) {
            ctx.fillStyle = color;
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }
      ctx.restore();
    }
  }, [frames, previewFrame, previewPlaying, activeFrameIndex, layers, dimensions]);

  // Handle preset change
  const handleSelectPreset = (preset: PalettePreset) => {
    setActivePaletteId(preset.id);
    setPalette(preset.colors);
    setPrimaryColor(preset.colors[0]);
    if (preset.colors.length > 1) {
      setSecondaryColor(preset.colors[1]);
    }
    sounds.playToolSwitch();
  };

  return (
    <aside className="w-80 bg-[#12131a] border-l border-[#262838] flex flex-col h-full select-none z-20 shrink-0">
      {/* 1. Mini-Previewer Window */}
      <div className="p-3.5 border-b border-[#262838] bg-[#141620]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-mono uppercase tracking-wider text-[#a1a1aa]">Preview</span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#1a1c26] text-[#8b5cf6] border border-[#262838]">
              {dimensions.width}×{dimensions.height}
            </span>
          </div>
          <button
            onClick={() => setPreviewPlaying(!previewPlaying)}
            className="text-[11px] font-mono text-[#a1a1aa] hover:text-[#f4f4f5] flex items-center gap-1 transition-colors"
          >
            {previewPlaying ? <Pause size={12} /> : <Play size={12} />}
            <span>{previewPlaying ? 'Live' : 'Paused'}</span>
          </button>
        </div>

        {/* Viewport Box */}
        <div className="relative w-full h-32 rounded-lg bg-[#090a0f] canvas-checkerboard border border-[#262838] flex items-center justify-center overflow-hidden shadow-inner">
          <canvas
            ref={previewCanvasRef}
            width={dimensions.width}
            height={dimensions.height}
            className="w-24 h-24 pixelated object-contain"
          />
        </div>
      </div>

      {/* Tabs Header */}
      <div className="flex border-b border-[#262838] bg-[#12131a]">
        <button
          onClick={() => setActiveTab('palette')}
          className={`flex-1 py-2.5 text-xs font-medium flex items-center justify-center gap-2 border-b-2 transition-colors ${
            activeTab === 'palette'
              ? 'border-[#8b5cf6] text-[#8b5cf6] bg-[#1a1c26]/50'
              : 'border-transparent text-[#71717a] hover:text-[#a1a1aa]'
          }`}
        >
          <Palette size={14} />
          <span>Palettes & Ramps</span>
        </button>
        <button
          onClick={() => setActiveTab('layers')}
          className={`flex-1 py-2.5 text-xs font-medium flex items-center justify-center gap-2 border-b-2 transition-colors ${
            activeTab === 'layers'
              ? 'border-[#8b5cf6] text-[#8b5cf6] bg-[#1a1c26]/50'
              : 'border-transparent text-[#71717a] hover:text-[#a1a1aa]'
          }`}
        >
          <LayersIcon size={14} />
          <span>Layers ({layers.length})</span>
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
        {activeTab === 'palette' ? (
          <div className="flex flex-col gap-4">
            {/* Retro Hardware Presets Dropdown */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-mono uppercase text-[#a1a1aa]">Retro Hardware</label>
                <button
                  onClick={() => onSnapCanvasToPalette(palette)}
                  className="text-[10px] text-[#06b6d4] hover:text-[#22d3ee] flex items-center gap-1 font-mono transition-colors"
                  title="Recolor entire sprite to closest colors in active palette"
                >
                  <Wand2 size={11} />
                  <span>Snap Sprite</span>
                </button>
              </div>

              <select
                value={activePaletteId}
                onChange={(e) => {
                  const p = RETRO_PALETTES.find(item => item.id === e.target.value);
                  if (p) handleSelectPreset(p);
                }}
                className="w-full bg-[#1a1c26] text-[#f4f4f5] border border-[#262838] rounded-md px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#8b5cf6]"
              >
                {RETRO_PALETTES.map((preset) => (
                  <option key={preset.id} value={preset.id}>
                    {preset.name} ({preset.colors.length}c)
                  </option>
                ))}
              </select>

              {/* Preset Description */}
              {RETRO_PALETTES.find(p => p.id === activePaletteId)?.description && (
                <p className="text-[10px] text-[#71717a] mt-1 italic">
                  {RETRO_PALETTES.find(p => p.id === activePaletteId)?.description}
                </p>
              )}
            </div>

            {/* Active Palette Swatches */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono uppercase text-[#a1a1aa]">
                  Swatches ({palette.length})
                </span>
                <span className="text-[10px] font-mono text-[#71717a]">
                  Click = Primary | Right = Sec
                </span>
              </div>

              <div className="grid grid-cols-8 gap-1.5 p-2 bg-[#1a1c26] rounded-lg border border-[#262838]">
                {palette.map((colorHex, idx) => {
                  const isPrimary = colorHex.toLowerCase() === primaryColor.toLowerCase();
                  const isSecondary = colorHex.toLowerCase() === secondaryColor.toLowerCase();

                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        setPrimaryColor(colorHex);
                        sounds.playPixelClick();
                      }}
                      onContextMenu={(e) => {
                        e.preventDefault();
                        setSecondaryColor(colorHex);
                        sounds.playPixelClick();
                      }}
                      className={`relative aspect-square rounded transition-transform hover:scale-110 shadow-sm ${
                        isPrimary
                          ? 'ring-2 ring-white scale-105 z-10'
                          : isSecondary
                          ? 'ring-2 ring-[#06b6d4] scale-105 z-10'
                          : 'border border-black/20'
                      }`}
                      style={{ backgroundColor: colorHex }}
                      title={`${colorHex} (Click for Primary, Right-click for Secondary)`}
                    >
                      {isPrimary && (
                        <span className="absolute inset-0 flex items-center justify-center text-[10px] text-white drop-shadow font-bold">
                          •
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Dynamic Tint & Shade Ramp Generator */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Sparkles size={12} className="text-[#8b5cf6]" />
                  <span className="text-[11px] font-mono uppercase text-[#a1a1aa]">
                    Tint / Shade Ramp
                  </span>
                </div>
                <button
                  onClick={() => {
                    // Append ramp to current palette
                    const unique = Array.from(new Set([...palette, ...colorRamp]));
                    setPalette(unique);
                    sounds.playSuccess();
                  }}
                  className="text-[10px] text-[#8b5cf6] hover:text-[#a78bfa] font-mono transition-colors"
                >
                  + Add to Swatches
                </button>
              </div>

              <div className="flex items-center gap-1 p-2 bg-[#1a1c26] rounded-lg border border-[#262838]">
                {colorRamp.map((rampColor, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setPrimaryColor(rampColor);
                      sounds.playPixelClick();
                    }}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      setSecondaryColor(rampColor);
                      sounds.playPixelClick();
                    }}
                    className={`flex-1 h-7 rounded transition-transform hover:scale-110 ${
                      rampColor.toLowerCase() === primaryColor.toLowerCase()
                        ? 'ring-2 ring-white scale-105 z-10'
                        : 'border border-black/20'
                    }`}
                    style={{ backgroundColor: rampColor }}
                    title={`${rampColor} (Step ${idx + 1}/7)`}
                  />
                ))}
              </div>
            </div>

            {/* Custom Color Inputs */}
            <div className="p-3 bg-[#1a1c26] rounded-lg border border-[#262838]">
              <span className="text-[11px] font-mono uppercase text-[#a1a1aa] block mb-2">
                Custom Color Input
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-8 h-8 rounded border-0 cursor-pointer bg-transparent p-0"
                />
                <input
                  type="text"
                  value={primaryColor.toUpperCase()}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="flex-1 bg-[#12131a] border border-[#262838] rounded px-2.5 py-1 text-xs font-mono uppercase text-[#f4f4f5] focus:outline-none focus:border-[#8b5cf6]"
                  placeholder="#FFFFFF"
                />
                <button
                  onClick={() => {
                    if (!palette.includes(primaryColor)) {
                      setPalette([...palette, primaryColor]);
                      sounds.playSuccess();
                    }
                  }}
                  className="p-1.5 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white rounded text-xs transition-colors"
                  title="Add to palette"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Layers Tab */
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-mono uppercase text-[#a1a1aa]">Layer Stack</span>
              <button
                onClick={onAddLayer}
                className="px-2 py-1 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white rounded text-xs flex items-center gap-1 transition-colors shadow-sm"
              >
                <Plus size={13} />
                <span>New Layer</span>
              </button>
            </div>

            {/* List layers in reverse (top to bottom visual stacking) */}
            <div className="flex flex-col gap-2">
              {[...layers].reverse().map((layer) => {
                const isSelected = layer.id === activeLayerId;
                const isEditing = editingLayerId === layer.id;

                return (
                  <div
                    key={layer.id}
                    onClick={() => {
                      setActiveLayerId(layer.id);
                      sounds.playToolSwitch();
                    }}
                    className={`p-2.5 rounded-lg border transition-all flex flex-col gap-2 cursor-pointer ${
                      isSelected
                        ? 'bg-[#1a1c26] border-[#8b5cf6] shadow-[0_0_12px_rgba(139,92,246,0.2)]'
                        : 'bg-[#141620] border-[#262838] hover:border-[#3b3d54]'
                    }`}
                  >
                    {/* Top Row: Name and Actions */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 flex-1 min-w-0 mr-2">
                        {isEditing ? (
                          <input
                            type="text"
                            value={layerNameInput}
                            onChange={(e) => setLayerNameInput(e.target.value)}
                            onBlur={() => {
                              if (layerNameInput.trim()) {
                                onRenameLayer(layer.id, layerNameInput.trim());
                              }
                              setEditingLayerId(null);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                if (layerNameInput.trim()) {
                                  onRenameLayer(layer.id, layerNameInput.trim());
                                }
                                setEditingLayerId(null);
                              }
                            }}
                            autoFocus
                            className="bg-[#12131a] text-xs px-1.5 py-0.5 rounded border border-[#8b5cf6] text-[#f4f4f5] outline-none w-full"
                          />
                        ) : (
                          <span
                            onDoubleClick={() => {
                              setEditingLayerId(layer.id);
                              setLayerNameInput(layer.name);
                            }}
                            className={`text-xs font-medium truncate ${
                              isSelected ? 'text-[#f4f4f5]' : 'text-[#a1a1aa]'
                            }`}
                            title="Double-click to rename"
                          >
                            {layer.name}
                          </span>
                        )}
                      </div>

                      {/* Controls */}
                      <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                        {/* Visibility */}
                        <button
                          onClick={() => onToggleLayerVisibility(layer.id)}
                          className={`p-1 rounded transition-colors ${
                            layer.visible ? 'text-[#a1a1aa] hover:text-[#f4f4f5]' : 'text-[#52525b] hover:text-[#a1a1aa]'
                          }`}
                          title={layer.visible ? 'Hide layer' : 'Show layer'}
                        >
                          {layer.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                        </button>

                        {/* Lock */}
                        <button
                          onClick={() => onToggleLayerLock(layer.id)}
                          className={`p-1 rounded transition-colors ${
                            layer.locked ? 'text-amber-400' : 'text-[#52525b] hover:text-[#a1a1aa]'
                          }`}
                          title={layer.locked ? 'Unlock layer' : 'Lock layer'}
                        >
                          {layer.locked ? <Lock size={14} /> : <Unlock size={14} />}
                        </button>

                        {/* Duplicate */}
                        <button
                          onClick={() => onDuplicateLayer(layer.id)}
                          className="p-1 text-[#71717a] hover:text-[#f4f4f5] rounded"
                          title="Duplicate layer"
                        >
                          <Copy size={13} />
                        </button>

                        {/* Move Up */}
                        <button
                          onClick={() => onReorderLayer(layer.id, 'up')}
                          className="p-1 text-[#71717a] hover:text-[#f4f4f5] rounded"
                          title="Move layer up"
                        >
                          <ChevronUp size={14} />
                        </button>

                        {/* Move Down */}
                        <button
                          onClick={() => onReorderLayer(layer.id, 'down')}
                          className="p-1 text-[#71717a] hover:text-[#f4f4f5] rounded"
                          title="Move layer down"
                        >
                          <ChevronDown size={14} />
                        </button>

                        {/* Delete */}
                        <button
                          onClick={() => onDeleteLayer(layer.id)}
                          disabled={layers.length <= 1}
                          className="p-1 text-[#71717a] hover:text-rose-400 disabled:opacity-20 rounded"
                          title="Delete layer"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>

                    {/* Bottom Row: Opacity Slider */}
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <span className="text-[10px] font-mono text-[#71717a]">Opacity:</span>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={layer.opacity}
                        onChange={(e) => onChangeLayerOpacity(layer.id, Number(e.target.value))}
                        className="flex-1 accent-[#8b5cf6] h-1 bg-[#262838] rounded cursor-pointer"
                      />
                      <span className="text-[10px] font-mono text-[#a1a1aa] w-8 text-right">
                        {Math.round(layer.opacity * 100)}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
