import React, { useRef, useEffect, useState, useCallback } from 'react';
import { X, Play, RotateCcw, Trophy, Volume2, Sparkles, Gamepad2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Layer } from '../types';
import { sounds } from '../utils/audio';

interface SpriteGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  frames: (string | null)[][][][];
  layers: Layer[];
  dimensions: { width: number; height: number };
}

interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface Coin {
  x: number;
  y: number;
  collected: boolean;
}

export const SpriteGameModal: React.FC<SpriteGameModalProps> = ({
  isOpen,
  onClose,
  frames,
  layers,
  dimensions,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'title' | 'playing' | 'victory'>('title');
  const [score, setScore] = useState(0);

  // Render sprite frames into pre-cached ImageBitmaps or offscreen canvases
  const spriteCanvasesRef = useRef<HTMLCanvasElement[]>([]);

  useEffect(() => {
    if (!isOpen) return;

    // Cache rendered frames
    spriteCanvasesRef.current = frames.map((f) => {
      const c = document.createElement('canvas');
      c.width = dimensions.width;
      c.height = dimensions.height;
      const ctx = c.getContext('2d')!;

      for (let l = 0; l < layers.length; l++) {
        if (!layers[l].visible) continue;
        const grid = f[l];
        if (!grid) continue;

        ctx.save();
        ctx.globalAlpha = layers[l].opacity;
        for (let y = 0; y < dimensions.height; y++) {
          for (let x = 0; x < dimensions.width; x++) {
            const color = grid[y]?.[x];
            if (color) {
              ctx.fillStyle = color;
              ctx.fillRect(x, y, 1, 1);
            }
          }
        }
        ctx.restore();
      }
      return c;
    });
  }, [isOpen, frames, layers, dimensions]);

  // Game physics state
  const playerRef = useRef({
    x: 50,
    y: 280,
    vx: 0,
    vy: 0,
    w: 24,
    h: 24,
    grounded: false,
    facingRight: true,
    animFrame: 0,
    animTimer: 0,
  });

  const platformsRef = useRef<Platform[]>([
    { x: 0, y: 340, w: 640, h: 40 }, // Ground
    { x: 140, y: 270, w: 90, h: 14 },
    { x: 280, y: 210, w: 90, h: 14 },
    { x: 420, y: 150, w: 100, h: 14 },
    { x: 260, y: 100, w: 80, h: 14 },
    { x: 80, y: 80, w: 90, h: 14 }, // Victory altar
  ]);

  const coinsRef = useRef<Coin[]>([
    { x: 180, y: 240, collected: false },
    { x: 320, y: 180, collected: false },
    { x: 460, y: 120, collected: false },
    { x: 300, y: 70, collected: false },
  ]);

  const keysRef = useRef<{ [key: string]: boolean }>({});

  const resetGame = useCallback(() => {
    playerRef.current = {
      x: 50,
      y: 280,
      vx: 0,
      vy: 0,
      w: 24,
      h: 24,
      grounded: false,
      facingRight: true,
      animFrame: 0,
      animTimer: 0,
    };
    coinsRef.current = coinsRef.current.map(c => ({ ...c, collected: false }));
    setScore(0);
    setGameState('playing');
  }, []);

  // Main 60fps Loop
  useEffect(() => {
    if (!isOpen || gameState !== 'playing') return;

    let animId: number;
    let lastTime = performance.now();

    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (e.code === 'KeyW' || e.code === 'ArrowUp' || e.code === 'Space') {
        if (playerRef.current.grounded) {
          playerRef.current.vy = -10.5;
          playerRef.current.grounded = false;
          sounds.playJump();
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;

    const loop = (time: number) => {
      const dt = Math.min((time - lastTime) / 1000, 0.05);
      lastTime = time;

      const p = playerRef.current;
      const keys = keysRef.current;

      // Horizontal movement
      const speed = 200;
      if (keys['KeyA'] || keys['ArrowLeft']) {
        p.vx = -speed;
        p.facingRight = false;
      } else if (keys['KeyD'] || keys['ArrowRight']) {
        p.vx = speed;
        p.facingRight = true;
      } else {
        p.vx *= 0.75;
      }

      // Gravity
      p.vy += 22 * dt * 60;
      if (p.vy > 14) p.vy = 14;

      // Update position
      p.x += p.vx * dt;
      p.y += p.vy * dt * 45;

      // Platform collisions
      p.grounded = false;
      for (const plat of platformsRef.current) {
        if (
          p.x + p.w > plat.x &&
          p.x < plat.x + plat.w &&
          p.y + p.h >= plat.y &&
          p.y + p.h <= plat.y + plat.h + 10 &&
          p.vy >= 0
        ) {
          p.y = plat.y - p.h;
          p.vy = 0;
          p.grounded = true;
        }
      }

      // Coin pickups
      for (const coin of coinsRef.current) {
        if (!coin.collected) {
          const dist = Math.hypot(p.x + p.w / 2 - coin.x, p.y + p.h / 2 - coin.y);
          if (dist < 18) {
            coin.collected = true;
            setScore(s => s + 100);
            sounds.playCoin();
          }
        }
      }

      // Victory Condition: Reached Altar at top left platform
      if (p.x < 140 && p.y < 70 && p.grounded) {
        setGameState('victory');
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
        sounds.playSuccess();
        return;
      }

      // Animation frame advancement
      if (Math.abs(p.vx) > 10 && spriteCanvasesRef.current.length > 1) {
        p.animTimer += dt;
        if (p.animTimer > 0.12) {
          p.animTimer = 0;
          p.animFrame = (p.animFrame + 1) % spriteCanvasesRef.current.length;
        }
      } else {
        p.animFrame = 0;
      }

      // Render Scene
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Retro Gradient Sky
      const skyGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      skyGrad.addColorStop(0, '#0d0f1a');
      skyGrad.addColorStop(0.7, '#1b1b2f');
      skyGrad.addColorStop(1, '#2c1e40');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Retro Pixel Stars
      ctx.fillStyle = '#f4f4f5';
      const starPositions = [[40, 30], [120, 50], [220, 25], [350, 45], [520, 35], [600, 60]];
      for (const [sx, sy] of starPositions) {
        ctx.fillRect(sx, sy, 2, 2);
      }

      // 2. Platforms
      for (const plat of platformsRef.current) {
        // Platform top grass / tech line
        ctx.fillStyle = '#8b5cf6';
        ctx.fillRect(plat.x, plat.y, plat.w, 4);
        // Platform body
        ctx.fillStyle = '#1e1c2e';
        ctx.fillRect(plat.x, plat.y + 4, plat.w, plat.h - 4);
        // Border outline
        ctx.strokeStyle = '#3b3459';
        ctx.lineWidth = 1;
        ctx.strokeRect(plat.x, plat.y, plat.w, plat.h);
      }

      // 3. Victory Shrine / Flag
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(110, 45, 2, 35);
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.moveTo(112, 45);
      ctx.lineTo(130, 55);
      ctx.lineTo(112, 65);
      ctx.fill();

      // 4. Pixel Coins
      for (const coin of coinsRef.current) {
        if (!coin.collected) {
          const coinBounce = Math.sin(time / 200) * 3;
          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.arc(coin.x, coin.y + coinBounce, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#fef08a';
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      // 5. Draw Player (The user's animated pixel art sprite!)
      const currentSprite = spriteCanvasesRef.current[p.animFrame] || spriteCanvasesRef.current[0];
      if (currentSprite) {
        ctx.save();
        ctx.imageSmoothingEnabled = false;

        if (!p.facingRight) {
          ctx.translate(p.x + p.w, p.y);
          ctx.scale(-1, 1);
          ctx.drawImage(currentSprite, 0, 0, p.w, p.h);
        } else {
          ctx.drawImage(currentSprite, p.x, p.y, p.w, p.h);
        }
        ctx.restore();
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isOpen, gameState]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#12131a] border border-[#262838] w-full max-w-3xl rounded-xl shadow-2xl flex flex-col overflow-hidden text-[#f4f4f5]">
        {/* Modal Header */}
        <div className="px-5 py-3 border-b border-[#262838] flex items-center justify-between bg-[#141620]">
          <div className="flex items-center gap-2">
            <Gamepad2 className="text-emerald-400" size={18} />
            <h3 className="font-bold text-sm">Sprite Play Sandbox (2D Platformer)</h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#1a1c26] text-emerald-400 border border-[#262838]">
              60 FPS PHYSICS
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Game Canvas Container */}
        <div className="relative bg-[#090a0f] flex items-center justify-center h-[380px] overflow-hidden select-none">
          <canvas
            ref={canvasRef}
            width={640}
            height={380}
            className="pixelated w-full h-full object-contain"
          />

          {/* Title Screen Overlay */}
          {gameState === 'title' && (
            <div className="absolute inset-0 bg-[#090a0f]/80 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-[#06b6d4] flex items-center justify-center mb-3 shadow-[0_0_20px_rgba(16,185,129,0.4)]">
                <Gamepad2 size={26} className="text-white" />
              </div>
              <h2 className="text-xl font-black tracking-tight text-white mb-1">
                Pixel Hero Stage
              </h2>
              <p className="text-xs text-[#a1a1aa] max-w-sm mb-5">
                Play directly with the sprite you just forged! Run across platforms, grab gems, and leap to the celestial beacon!
              </p>
              <button
                onClick={resetGame}
                className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-[#090a0f] font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg flex items-center gap-2 transition-transform hover:scale-105"
              >
                <Play size={14} />
                <span>Start Simulation</span>
              </button>
              <div className="mt-4 text-[11px] font-mono text-[#71717a]">
                A / D or Arrow Keys: Run · Space or W: Jump
              </div>
            </div>
          )}

          {/* Victory Overlay */}
          {gameState === 'victory' && (
            <div className="absolute inset-0 bg-[#090a0f]/85 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6 animate-in fade-in duration-300">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-[#8b5cf6] flex items-center justify-center mb-3 shadow-[0_0_20px_rgba(245,158,11,0.5)]">
                <Trophy size={26} className="text-white" />
              </div>
              <h2 className="text-xl font-black tracking-tight text-white mb-1">
                Stage Cleared!
              </h2>
              <p className="text-xs text-emerald-400 font-mono mb-4">
                Score: {score} PTS · Sprite Animation Verified!
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={resetGame}
                  className="px-5 py-2 bg-[#8b5cf6] hover:bg-[#7c3aed] text-white font-semibold text-xs rounded-lg flex items-center gap-2 transition-colors"
                >
                  <RotateCcw size={14} />
                  <span>Play Again</span>
                </button>
                <button
                  onClick={onClose}
                  className="px-5 py-2 bg-[#1a1c26] hover:bg-[#262838] text-[#f4f4f5] text-xs rounded-lg transition-colors border border-[#262838]"
                >
                  Back to Studio
                </button>
              </div>
            </div>
          )}

          {/* Low-occlusion perimeter HUD */}
          {gameState === 'playing' && (
            <div className="absolute top-3 left-4 right-4 pointer-events-none flex items-center justify-between text-xs font-mono">
              <div className="bg-[#12131a]/85 backdrop-blur px-3 py-1 rounded-md border border-[#262838] flex items-center gap-2 text-emerald-400">
                <span>SCORE:</span>
                <span className="font-bold text-white tabular-nums">{score}</span>
              </div>
              <div className="bg-[#12131a]/85 backdrop-blur px-3 py-1 rounded-md border border-[#262838] text-[#a1a1aa] flex items-center gap-2">
                <span>CONTROLS:</span>
                <span className="text-white">WASD / ARROWS</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#262838] bg-[#141620] flex items-center justify-between text-xs">
          <span className="text-[#71717a] font-mono">
            Sprite test chamber mounts pixel animations into active game loop
          </span>
          <button
            onClick={resetGame}
            className="px-3 py-1.5 bg-[#1a1c26] hover:bg-[#262838] text-[#a1a1aa] hover:text-[#f4f4f5] rounded border border-[#262838] transition-colors flex items-center gap-1.5 text-xs font-mono"
          >
            <RotateCcw size={13} />
            <span>Restart Stage</span>
          </button>
        </div>
      </div>
    </div>
  );
};
