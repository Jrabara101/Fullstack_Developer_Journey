import React, { useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Plus, 
  Copy, 
  Trash2, 
  ChevronLeft, 
  ChevronRight, 
  Layers, 
  Eye, 
  SlidersHorizontal,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { OnionSkinConfig, Layer } from '../types';
import { sounds } from '../utils/audio';

interface TimelineDockProps {
  frames: (string | null)[][][][];
  activeFrameIndex: number;
  setActiveFrameIndex: React.Dispatch<React.SetStateAction<number>>;
  fps: number;
  setFps: (fps: number) => void;
  isPlaying: boolean;
  setIsPlaying: React.Dispatch<React.SetStateAction<boolean>>;
  onionSkin: OnionSkinConfig;
  setOnionSkin: React.Dispatch<React.SetStateAction<OnionSkinConfig>>;
  layers: Layer[];
  dimensions: { width: number; height: number };
  onAddFrame: () => void;
  onDuplicateFrame: () => void;
  onDeleteFrame: () => void;
  onMoveFrame: (direction: 'left' | 'right') => void;
}

export const TimelineDock: React.FC<TimelineDockProps> = ({
  frames,
  activeFrameIndex,
  setActiveFrameIndex,
  fps,
  setFps,
  isPlaying,
  setIsPlaying,
  onionSkin,
  setOnionSkin,
  layers,
  dimensions,
  onAddFrame,
  onDuplicateFrame,
  onDeleteFrame,
  onMoveFrame,
}) => {
  const [collapsed, setCollapsed] = React.useState(false);
  const [showOnionSettings, setShowOnionSettings] = React.useState(false);

  // Playback timer loop
  useEffect(() => {
    if (!isPlaying || frames.length <= 1) return;

    const interval = 1000 / fps;
    const timer = setInterval(() => {
      setActiveFrameIndex((prev: number) => (prev + 1) % frames.length);
    }, interval);

    return () => clearInterval(timer);
  }, [isPlaying, fps, frames.length, setActiveFrameIndex]);

  return (
    <footer className="bg-[#12131a] border-t border-[#262838] flex flex-col select-none transition-all duration-200 z-20">
      {/* Dock Header & Playback Controls Bar */}
      <div className="h-11 px-4 flex items-center justify-between border-b border-[#262838]/60 bg-[#141620]">
        {/* Left: Playback controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsPlaying(!isPlaying);
              sounds.playToolSwitch();
            }}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium text-xs transition-colors shadow-sm ${
              isPlaying
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-[#8b5cf6] text-white hover:bg-[#7c3aed]'
            }`}
          >
            {isPlaying ? <Pause size={14} /> : <Play size={14} />}
            <span>{isPlaying ? 'Pause' : 'Play'}</span>
          </button>

          {/* Step Back / Forward */}
          <div className="flex items-center gap-1 bg-[#1a1c26] p-0.5 rounded border border-[#262838]">
            <button
              onClick={() => {
                setActiveFrameIndex((activeFrameIndex - 1 + frames.length) % frames.length);
                sounds.playToolSwitch();
              }}
              className="p-1 text-[#a1a1aa] hover:text-[#f4f4f5] rounded hover:bg-[#262838] transition-colors"
              title="Previous Frame (,)"
            >
              <ChevronLeft size={15} />
            </button>
            <span className="font-mono text-xs px-1.5 text-[#f4f4f5]">
              {(activeFrameIndex + 1).toString().padStart(2, '0')}/
              {frames.length.toString().padStart(2, '0')}
            </span>
            <button
              onClick={() => {
                setActiveFrameIndex((activeFrameIndex + 1) % frames.length);
                sounds.playToolSwitch();
              }}
              className="p-1 text-[#a1a1aa] hover:text-[#f4f4f5] rounded hover:bg-[#262838] transition-colors"
              title="Next Frame (.)"
            >
              <ChevronRight size={15} />
            </button>
          </div>

          {/* Speed / FPS Slider */}
          <div className="flex items-center gap-2 ml-2 pl-3 border-l border-[#262838]">
            <span className="text-[11px] font-mono text-[#a1a1aa]">FPS:</span>
            <input
              type="range"
              min="1"
              max="24"
              value={fps}
              onChange={(e) => setFps(Number(e.target.value))}
              className="w-20 accent-[#8b5cf6] h-1.5 bg-[#262838] rounded-lg cursor-pointer"
            />
            <span className="text-xs font-mono text-[#8b5cf6] font-semibold w-6">{fps}</span>
          </div>
        </div>

        {/* Right: Onion Skin & Frame Operations */}
        <div className="flex items-center gap-2">
          {/* Onion Skin Quick Toggle */}
          <button
            onClick={() => {
              setOnionSkin(prev => ({ ...prev, enabled: !prev.enabled }));
              sounds.playToolSwitch();
            }}
            className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 border transition-colors ${
              onionSkin.enabled
                ? 'bg-[#06b6d4]/15 border-[#06b6d4]/40 text-[#06b6d4]'
                : 'bg-[#1a1c26] border-[#262838] text-[#71717a] hover:text-[#f4f4f5]'
            }`}
            title="Toggle Onion Skinning"
          >
            <Layers size={13} />
            <span>Onion Skin</span>
          </button>

          {/* Onion Skin detailed adjustments */}
          <button
            onClick={() => setShowOnionSettings(!showOnionSettings)}
            className={`p-1.5 rounded text-xs border border-[#262838] transition-colors ${
              showOnionSettings ? 'bg-[#1a1c26] text-[#f4f4f5]' : 'text-[#71717a] hover:text-[#f4f4f5]'
            }`}
            title="Onion skin settings"
          >
            <SlidersHorizontal size={13} />
          </button>

          <div className="w-px h-4 bg-[#262838]" />

          {/* Add Frame */}
          <button
            onClick={onAddFrame}
            className="p-1.5 bg-[#1a1c26] hover:bg-[#262838] text-[#a1a1aa] hover:text-[#f4f4f5] rounded border border-[#262838] transition-colors flex items-center gap-1 text-xs"
            title="Add Blank Frame"
          >
            <Plus size={14} />
            <span className="hidden sm:inline">Add</span>
          </button>

          {/* Duplicate Frame */}
          <button
            onClick={onDuplicateFrame}
            className="p-1.5 bg-[#1a1c26] hover:bg-[#262838] text-[#a1a1aa] hover:text-[#f4f4f5] rounded border border-[#262838] transition-colors"
            title="Duplicate Frame"
          >
            <Copy size={14} />
          </button>

          {/* Delete Frame */}
          <button
            onClick={onDeleteFrame}
            disabled={frames.length <= 1}
            className={`p-1.5 rounded border border-[#262838] transition-colors ${
              frames.length <= 1
                ? 'opacity-30 cursor-not-allowed text-[#52525b]'
                : 'bg-[#1a1c26] hover:bg-rose-500/20 text-[#a1a1aa] hover:text-rose-400 hover:border-rose-500/40'
            }`}
            title="Delete Frame"
          >
            <Trash2 size={14} />
          </button>

          <div className="w-px h-4 bg-[#262838]" />

          {/* Collapse dock */}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1 rounded text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26]"
          >
            {collapsed ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
        </div>
      </div>

      {/* Onion Skin settings pop-down bar */}
      {showOnionSettings && (
        <div className="px-4 py-2 bg-[#1a1c26] border-b border-[#262838] flex flex-wrap items-center gap-6 text-xs text-[#a1a1aa]">
          <div className="flex items-center gap-2">
            <span>Frames Before:</span>
            <input
              type="range"
              min="1"
              max="4"
              value={onionSkin.framesBefore}
              onChange={(e) => setOnionSkin(prev => ({ ...prev, framesBefore: Number(e.target.value) }))}
              className="w-16 accent-[#ef4444]"
            />
            <span className="font-mono text-[#ef4444]">{onionSkin.framesBefore}</span>
          </div>

          <div className="flex items-center gap-2">
            <span>Frames After:</span>
            <input
              type="range"
              min="1"
              max="4"
              value={onionSkin.framesAfter}
              onChange={(e) => setOnionSkin(prev => ({ ...prev, framesAfter: Number(e.target.value) }))}
              className="w-16 accent-[#3b82f6]"
            />
            <span className="font-mono text-[#3b82f6]">{onionSkin.framesAfter}</span>
          </div>

          <div className="flex items-center gap-2">
            <span>Ghost Opacity:</span>
            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.05"
              value={onionSkin.opacity}
              onChange={(e) => setOnionSkin(prev => ({ ...prev, opacity: Number(e.target.value) }))}
              className="w-20 accent-[#06b6d4]"
            />
            <span className="font-mono text-[#06b6d4]">{Math.round(onionSkin.opacity * 100)}%</span>
          </div>
        </div>
      )}

      {/* Frame Strip */}
      {!collapsed && (
        <div className="h-24 px-4 py-2 flex items-center gap-3 overflow-x-auto scrollbar-thin">
          {frames.map((frameData, idx) => {
            const isSelected = idx === activeFrameIndex;
            return (
              <div
                key={idx}
                onClick={() => {
                  setActiveFrameIndex(idx);
                  sounds.playToolSwitch();
                }}
                className={`relative flex-shrink-0 cursor-pointer rounded-lg p-1.5 transition-all flex flex-col items-center gap-1 group ${
                  isSelected
                    ? 'bg-[#1a1c26] ring-2 ring-[#8b5cf6] shadow-[0_0_12px_rgba(139,92,246,0.25)]'
                    : 'bg-[#141620] hover:bg-[#1a1c26] border border-[#262838]'
                }`}
              >
                {/* Frame index badge */}
                <div className="w-full flex items-center justify-between text-[10px] font-mono px-1">
                  <span className={isSelected ? 'text-[#8b5cf6] font-bold' : 'text-[#71717a]'}>
                    #{(idx + 1).toString().padStart(2, '0')}
                  </span>
                  {isSelected && (
                    <span className="w-1.5 h-1.5 rounded-full bg-[#8b5cf6] animate-pulse" />
                  )}
                </div>

                {/* Canvas Thumbnail */}
                <div className="w-14 h-14 rounded bg-[#090a0f] canvas-checkerboard border border-[#262838] overflow-hidden flex items-center justify-center">
                  <FrameThumbnail
                    frame={frameData}
                    layers={layers}
                    dimensions={dimensions}
                  />
                </div>

                {/* Reorder arrows on hover */}
                <div className="absolute inset-x-0 bottom-0 py-0.5 opacity-0 group-hover:opacity-100 flex justify-between px-1 bg-[#12131a]/90 backdrop-blur-sm rounded-b transition-opacity">
                  <button
                    disabled={idx === 0}
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveFrame('left');
                    }}
                    className="text-[#71717a] hover:text-[#f4f4f5] disabled:opacity-20"
                    title="Move left"
                  >
                    ◀
                  </button>
                  <button
                    disabled={idx === frames.length - 1}
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveFrame('right');
                    }}
                    className="text-[#71717a] hover:text-[#f4f4f5] disabled:opacity-20"
                    title="Move right"
                  >
                    ▶
                  </button>
                </div>
              </div>
            );
          })}

          {/* Quick Add Frame Button at end of strip */}
          <button
            onClick={onAddFrame}
            className="flex-shrink-0 w-14 h-14 rounded-lg border-2 border-dashed border-[#262838] hover:border-[#8b5cf6]/50 hover:bg-[#8b5cf6]/5 flex flex-col items-center justify-center text-[#71717a] hover:text-[#8b5cf6] transition-colors"
            title="Append New Frame"
          >
            <Plus size={18} />
          </button>
        </div>
      )}
    </footer>
  );
};

// Mini Canvas Thumbnail Renderer
const FrameThumbnail: React.FC<{
  frame: (string | null)[][][];
  layers: Layer[];
  dimensions: { width: number; height: number };
}> = ({ frame, layers, dimensions }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, dimensions.width, dimensions.height);

    for (let l = 0; l < layers.length; l++) {
      if (!layers[l].visible) continue;
      const layerGrid = frame[l];
      if (!layerGrid) continue;

      ctx.save();
      ctx.globalAlpha = layers[l].opacity;

      for (let y = 0; y < dimensions.height; y++) {
        for (let x = 0; x < dimensions.width; x++) {
          const color = layerGrid[y]?.[x];
          if (color) {
            ctx.fillStyle = color;
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }
      ctx.restore();
    }
  }, [frame, layers, dimensions]);

  return (
    <canvas
      ref={canvasRef}
      width={dimensions.width}
      height={dimensions.height}
      className="w-full h-full pixelated object-contain"
    />
  );
};
