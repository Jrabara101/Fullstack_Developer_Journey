import React from 'react';
import { 
  Pencil, 
  Eraser, 
  PaintBucket, 
  Pipette, 
  SquareDashed, 
  Slash, 
  Square, 
  Circle, 
  Grid2X2,
  SplitSquareVertical,
  SplitSquareHorizontal,
  ArrowRightLeft
} from 'lucide-react';
import { ToolType } from '../types';
import { sounds } from '../utils/audio';

interface ToolbarProps {
  activeTool: ToolType;
  setActiveTool: (tool: ToolType) => void;
  brushSize: number;
  setBrushSize: (size: number) => void;
  primaryColor: string;
  secondaryColor: string;
  setPrimaryColor: (color: string) => void;
  setSecondaryColor: (color: string) => void;
  symmetryHorizontal: boolean;
  setSymmetryHorizontal: React.Dispatch<React.SetStateAction<boolean>>;
  symmetryVertical: boolean;
  setSymmetryVertical: React.Dispatch<React.SetStateAction<boolean>>;
}

interface ToolDef {
  id: ToolType;
  label: string;
  icon: React.ReactNode;
  shortcut: string;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  activeTool,
  setActiveTool,
  brushSize,
  setBrushSize,
  primaryColor,
  secondaryColor,
  setPrimaryColor,
  setSecondaryColor,
  symmetryHorizontal,
  setSymmetryHorizontal,
  symmetryVertical,
  setSymmetryVertical,
}) => {
  const tools: ToolDef[] = [
    { id: 'pencil', label: 'Pencil Tool', icon: <Pencil size={18} />, shortcut: 'B' },
    { id: 'eraser', label: 'Eraser', icon: <Eraser size={18} />, shortcut: 'E' },
    { id: 'bucket', label: 'Flood Fill Bucket', icon: <PaintBucket size={18} />, shortcut: 'G' },
    { id: 'picker', label: 'Color Eyedropper', icon: <Pipette size={18} />, shortcut: 'I' },
    { id: 'line', label: 'Line Tool', icon: <Slash size={18} />, shortcut: 'L' },
    { id: 'rect', label: 'Rectangle', icon: <Square size={18} />, shortcut: 'U' },
    { id: 'circle', label: 'Circle Tool', icon: <Circle size={18} />, shortcut: 'C' },
    { id: 'dither', label: 'Dither Shading Brush', icon: <Grid2X2 size={18} />, shortcut: 'D' },
    { id: 'select', label: 'Marquee Select', icon: <SquareDashed size={18} />, shortcut: 'M' },
  ];

  const handleToolSelect = (tool: ToolType) => {
    setActiveTool(tool);
    sounds.playToolSwitch();
  };

  const swapColors = () => {
    const temp = primaryColor;
    setPrimaryColor(secondaryColor);
    setSecondaryColor(temp);
    sounds.playToolSwitch();
  };

  return (
    <aside className="w-16 bg-[#12131a] border-r border-[#262838] flex flex-col items-center py-3 select-none z-20 shrink-0">
      {/* Primary & Secondary Color Swatches */}
      <div className="relative w-11 h-11 mb-4 flex items-center justify-center">
        {/* Secondary color (behind) */}
        <div 
          className="absolute right-0 bottom-0 w-7 h-7 rounded border border-[#3a3d54] shadow cursor-pointer transition-transform hover:scale-105"
          style={{ backgroundColor: secondaryColor }}
          title={`Secondary color (Right click / swap): ${secondaryColor}`}
          onClick={swapColors}
        />
        {/* Primary color (in front) */}
        <div 
          className="absolute left-0 top-0 w-7 h-7 rounded border-2 border-white/80 shadow-md cursor-pointer transition-transform hover:scale-105 z-10"
          style={{ backgroundColor: primaryColor }}
          title={`Primary color: ${primaryColor}`}
        />
        <button
          onClick={swapColors}
          className="absolute -bottom-1 -right-1 p-0.5 rounded bg-[#1a1c26] border border-[#262838] text-[#71717a] hover:text-[#f4f4f5] z-20 transition-colors"
          title="Swap colors (X)"
        >
          <ArrowRightLeft size={10} />
        </button>
      </div>

      <div className="w-10 h-px bg-[#262838] mb-3" />

      {/* Main Drawing Tools */}
      <div className="flex flex-col gap-1.5 items-center">
        {tools.map((t) => {
          const isActive = activeTool === t.id;
          return (
            <div key={t.id} className="relative group">
              <button
                onClick={() => handleToolSelect(t.id)}
                className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                  isActive
                    ? 'bg-[#8b5cf6]/20 text-[#8b5cf6] ring-2 ring-[#8b5cf6] shadow-[0_0_12px_rgba(139,92,246,0.3)] font-semibold'
                    : 'text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26]'
                }`}
                aria-label={t.label}
              >
                {t.icon}
              </button>

              {/* Tooltip */}
              <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-[#1a1c26] text-[#f4f4f5] border border-[#262838] rounded shadow-xl text-xs whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50 flex items-center gap-1.5">
                <span>{t.label}</span>
                <kbd className="px-1 py-0.5 bg-[#12131a] rounded text-[10px] text-[#71717a] border border-[#262838] uppercase">
                  {t.shortcut}
                </kbd>
              </div>
            </div>
          );
        })}
      </div>

      <div className="w-10 h-px bg-[#262838] my-3" />

      {/* Brush Size Selector */}
      <div className="flex flex-col items-center gap-1">
        <span className="text-[10px] font-mono text-[#71717a] uppercase tracking-wider mb-0.5">Size</span>
        <div className="flex flex-col gap-1">
          {[1, 2, 3, 4].map((size) => (
            <button
              key={size}
              onClick={() => {
                setBrushSize(size);
                sounds.playToolSwitch();
              }}
              className={`w-7 h-7 rounded text-xs font-mono transition-all flex items-center justify-center ${
                brushSize === size
                  ? 'bg-[#8b5cf6] text-white font-bold shadow-sm'
                  : 'bg-[#1a1c26] text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#262838]'
              }`}
              title={`Brush size ${size}px`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>

      <div className="w-10 h-px bg-[#262838] my-3" />

      {/* Symmetry Toggles */}
      <div className="flex flex-col gap-1.5 items-center">
        <div className="relative group">
          <button
            onClick={() => setSymmetryHorizontal(prev => !prev)}
            className={`w-9 h-9 rounded flex items-center justify-center transition-colors ${
              symmetryHorizontal 
                ? 'bg-[#06b6d4]/20 text-[#06b6d4] ring-1 ring-[#06b6d4]' 
                : 'text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26]'
            }`}
            title="Mirror Horizontally (X-axis symmetry)"
          >
            <SplitSquareHorizontal size={16} />
          </button>
          <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2 py-1 bg-[#1a1c26] text-[#f4f4f5] border border-[#262838] rounded shadow-xl text-xs whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50">
            Horizontal Symmetry
          </div>
        </div>

        <div className="relative group">
          <button
            onClick={() => setSymmetryVertical(prev => !prev)}
            className={`w-9 h-9 rounded flex items-center justify-center transition-colors ${
              symmetryVertical 
                ? 'bg-[#06b6d4]/20 text-[#06b6d4] ring-1 ring-[#06b6d4]' 
                : 'text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26]'
            }`}
            title="Mirror Vertically (Y-axis symmetry)"
          >
            <SplitSquareVertical size={16} />
          </button>
          <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2 py-1 bg-[#1a1c26] text-[#f4f4f5] border border-[#262838] rounded shadow-xl text-xs whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50">
            Vertical Symmetry
          </div>
        </div>
      </div>
    </aside>
  );
};
