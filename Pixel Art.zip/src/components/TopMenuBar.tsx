import React, { useState, useRef, useEffect } from 'react';
import { 
  FolderOpen, 
  Save, 
  RotateCcw, 
  RotateCw, 
  Download, 
  Users, 
  Gamepad2, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Grid, 
  FilePlus, 
  ChevronDown,
  Layers,
  FlipHorizontal,
  FlipVertical,
  Scissors,
  Copy,
  ClipboardPaste,
  HelpCircle
} from 'lucide-react';
import { sounds } from '../utils/audio';

interface TopMenuBarProps {
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onNewCanvas: () => void;
  onResizeCanvas: () => void;
  onClearCanvas: () => void;
  onFlipHorizontal: () => void;
  onFlipVertical: () => void;
  onRotate90: () => void;
  onExportModalOpen: () => void;
  onPeerJamOpen: () => void;
  onGameModalOpen: () => void;
  onAiModalOpen: () => void;
  onLoadStarterSprite: (type: 'knight' | 'heart' | 'coin') => void;
  showGrid: boolean;
  setShowGrid: React.Dispatch<React.SetStateAction<boolean>>;
  onionSkinEnabled: boolean;
  setOnionSkinEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  showCoordinates: boolean;
  setShowCoordinates: React.Dispatch<React.SetStateAction<boolean>>;
  peerCount: number;
  isPeerConnected: boolean;
}

export const TopMenuBar: React.FC<TopMenuBarProps> = ({
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onNewCanvas,
  onResizeCanvas,
  onClearCanvas,
  onFlipHorizontal,
  onFlipVertical,
  onRotate90,
  onExportModalOpen,
  onPeerJamOpen,
  onGameModalOpen,
  onAiModalOpen,
  onLoadStarterSprite,
  showGrid,
  setShowGrid,
  onionSkinEnabled,
  setOnionSkinEnabled,
  showCoordinates,
  setShowCoordinates,
  peerCount,
  isPeerConnected,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [audioMuted, setAudioMuted] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleSound = () => {
    sounds.enabled = !sounds.enabled;
    setAudioMuted(!sounds.enabled);
  };

  const handleMenuClick = (name: string) => {
    setActiveMenu(activeMenu === name ? null : name);
    sounds.playToolSwitch();
  };

  return (
    <header 
      ref={menuRef} 
      className="h-12 bg-[#12131a] border-b border-[#262838] flex items-center justify-between px-3 select-none z-30 shrink-0"
    >
      {/* Brand & Dropdown Menus */}
      <div className="flex items-center gap-4">
        {/* Logo / Lockup */}
        <div className="flex items-center gap-2 pr-3 border-r border-[#262838]">
          <div className="w-7 h-7 rounded-md bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center shadow-[0_0_12px_rgba(139,92,246,0.4)]">
            <span className="text-white font-mono font-black text-sm">PF</span>
          </div>
          <span className="font-bold tracking-tight text-sm text-[#f4f4f5]">
            Pixel<span className="text-[#8b5cf6]">Forge</span>
          </span>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#1a1c26] text-[#06b6d4] border border-[#262838] font-semibold">
            STUDIO
          </span>
        </div>

        {/* Top Dropdowns */}
        <div className="flex items-center gap-1 text-xs">
          {/* File Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('file')}
              className={`px-2.5 py-1.5 rounded transition-colors flex items-center gap-1 ${
                activeMenu === 'file' ? 'bg-[#1a1c26] text-white' : 'text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26]'
              }`}
            >
              <span>File</span>
              <ChevronDown size={12} />
            </button>
            {activeMenu === 'file' && (
              <div className="absolute top-full left-0 mt-1 w-52 bg-[#141620] border border-[#262838] rounded-lg shadow-2xl py-1 z-50">
                <button
                  onClick={() => { onNewCanvas(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2"><FilePlus size={14} /> New Canvas</span>
                  <kbd className="text-[10px] text-[#71717a]">Alt+N</kbd>
                </button>
                <button
                  onClick={() => { onResizeCanvas(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center gap-2"
                >
                  <Maximize size={14} /> Resize Canvas...
                </button>
                <div className="my-1 border-t border-[#262838]" />
                <div className="px-3 py-1 text-[10px] font-mono uppercase text-[#71717a]">Sample Sprites</div>
                <button
                  onClick={() => { onLoadStarterSprite('knight'); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center gap-2"
                >
                  ⚔️ Hero Knight (4 Frames)
                </button>
                <button
                  onClick={() => { onLoadStarterSprite('coin'); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center gap-2"
                >
                  🪙 Spinning Coin (4 Frames)
                </button>
                <button
                  onClick={() => { onLoadStarterSprite('heart'); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center gap-2"
                >
                  ❤️ Beating Heart (3 Frames)
                </button>
                <div className="my-1 border-t border-[#262838]" />
                <button
                  onClick={() => { onClearCanvas(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-rose-400 hover:bg-rose-500/10"
                >
                  Clear Active Frame
                </button>
              </div>
            )}
          </div>

          {/* Edit Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('edit')}
              className={`px-2.5 py-1.5 rounded transition-colors flex items-center gap-1 ${
                activeMenu === 'edit' ? 'bg-[#1a1c26] text-white' : 'text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26]'
              }`}
            >
              <span>Edit</span>
              <ChevronDown size={12} />
            </button>
            {activeMenu === 'edit' && (
              <div className="absolute top-full left-0 mt-1 w-52 bg-[#141620] border border-[#262838] rounded-lg shadow-2xl py-1 z-50">
                <button
                  disabled={!canUndo}
                  onClick={() => { onUndo(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center justify-between disabled:opacity-30"
                >
                  <span className="flex items-center gap-2"><RotateCcw size={14} /> Undo</span>
                  <kbd className="text-[10px] text-[#71717a]">Ctrl+Z</kbd>
                </button>
                <button
                  disabled={!canRedo}
                  onClick={() => { onRedo(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center justify-between disabled:opacity-30"
                >
                  <span className="flex items-center gap-2"><RotateCw size={14} /> Redo</span>
                  <kbd className="text-[10px] text-[#71717a]">Ctrl+Y</kbd>
                </button>
                <div className="my-1 border-t border-[#262838]" />
                <button
                  onClick={() => { onFlipHorizontal(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center gap-2"
                >
                  <FlipHorizontal size={14} /> Flip Horizontal
                </button>
                <button
                  onClick={() => { onFlipVertical(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center gap-2"
                >
                  <FlipVertical size={14} /> Flip Vertical
                </button>
                <button
                  onClick={() => { onRotate90(); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center gap-2"
                >
                  <RotateCw size={14} /> Rotate 90° Clockwise
                </button>
              </div>
            )}
          </div>

          {/* View Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('view')}
              className={`px-2.5 py-1.5 rounded transition-colors flex items-center gap-1 ${
                activeMenu === 'view' ? 'bg-[#1a1c26] text-white' : 'text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26]'
              }`}
            >
              <span>View</span>
              <ChevronDown size={12} />
            </button>
            {activeMenu === 'view' && (
              <div className="absolute top-full left-0 mt-1 w-52 bg-[#141620] border border-[#262838] rounded-lg shadow-2xl py-1 z-50">
                <button
                  onClick={() => { setShowGrid(!showGrid); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2"><Grid size={14} /> Pixel Grid</span>
                  <span className="text-[10px] text-[#8b5cf6]">{showGrid ? 'ON' : 'OFF'}</span>
                </button>
                <button
                  onClick={() => { setOnionSkinEnabled(!onionSkinEnabled); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2"><Layers size={14} /> Onion Skinning</span>
                  <span className="text-[10px] text-[#06b6d4]">{onionSkinEnabled ? 'ON' : 'OFF'}</span>
                </button>
                <button
                  onClick={() => { setShowCoordinates(!showCoordinates); setActiveMenu(null); }}
                  className="w-full px-3 py-1.5 text-left text-xs text-[#f4f4f5] hover:bg-[#1a1c26] flex items-center justify-between"
                >
                  <span>Coordinate HUD</span>
                  <span className="text-[10px] text-[#71717a]">{showCoordinates ? 'ON' : 'OFF'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Primary Actions & Mode Launchers */}
      <div className="flex items-center gap-2">
        {/* Undo / Redo Quick Buttons */}
        <div className="flex items-center gap-1 mr-2">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className="p-1.5 rounded text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26] disabled:opacity-30 transition-colors"
            title="Undo (Ctrl+Z)"
          >
            <RotateCcw size={15} />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            className="p-1.5 rounded text-[#a1a1aa] hover:text-[#f4f4f5] hover:bg-[#1a1c26] disabled:opacity-30 transition-colors"
            title="Redo (Ctrl+Y)"
          >
            <RotateCw size={15} />
          </button>
        </div>

        {/* Live Peer Jam Mode Button */}
        <button
          onClick={onPeerJamOpen}
          className={`px-2.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 border transition-all ${
            isPeerConnected
              ? 'bg-[#06b6d4]/15 border-[#06b6d4]/40 text-[#06b6d4]'
              : 'bg-[#1a1c26] border-[#262838] text-[#a1a1aa] hover:text-[#f4f4f5]'
          }`}
          title="Collaborative Live Peer Jam"
        >
          <Users size={14} />
          <span>Peer Jam</span>
          {peerCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-[#06b6d4] text-[#090a0f] font-mono text-[10px] font-bold">
              {peerCount + 1}
            </span>
          )}
        </button>

        {/* AI Concept Forge */}
        <button
          onClick={onAiModalOpen}
          className="px-2.5 py-1.5 rounded-md text-xs font-medium bg-[#8b5cf6]/15 border border-[#8b5cf6]/40 text-[#a78bfa] hover:bg-[#8b5cf6]/25 transition-colors flex items-center gap-1.5"
          title="AI Pixel Concept Generator & Quantizer"
        >
          <Sparkles size={14} />
          <span>Pixel AI</span>
        </button>

        {/* Playable Mini Game Sandbox ("Test in Game") */}
        <button
          onClick={onGameModalOpen}
          className="px-2.5 py-1.5 rounded-md text-xs font-medium bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25 transition-colors flex items-center gap-1.5 shadow-sm"
          title="Test Sprite in Playable 2D Platformer"
        >
          <Gamepad2 size={14} />
          <span>Play Test</span>
        </button>

        {/* Engine Ready Exporter */}
        <button
          onClick={onExportModalOpen}
          className="px-3 py-1.5 rounded-md text-xs font-medium bg-[#8b5cf6] hover:bg-[#7c3aed] text-white shadow-[0_0_12px_rgba(139,92,246,0.3)] transition-all flex items-center gap-1.5"
        >
          <Download size={14} />
          <span>Export</span>
        </button>

        <div className="w-px h-4 bg-[#262838] mx-1" />

        {/* Audio Mute Toggle */}
        <button
          onClick={toggleSound}
          className="p-1.5 rounded text-[#71717a] hover:text-[#f4f4f5] hover:bg-[#1a1c26] transition-colors"
          title={audioMuted ? 'Unmute retro audio' : 'Mute retro audio'}
        >
          {audioMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
        </button>
      </div>
    </header>
  );
};
