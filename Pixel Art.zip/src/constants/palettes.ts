import { PalettePreset } from '../types';

export const RETRO_PALETTES: PalettePreset[] = [
  {
    id: 'gameboy-dmg',
    name: 'Game Boy (DMG-01)',
    category: 'retro-hardware',
    description: 'Original 1989 Nintendo monochrome 4-tone olive pea-soup palette',
    colors: ['#0f380f', '#306230', '#8bac0f', '#9bbc0f'],
  },
  {
    id: 'gameboy-pocket',
    name: 'Game Boy Pocket',
    category: 'retro-hardware',
    description: '1996 high-contrast monochrome silver/grey 4-tone display',
    colors: ['#000000', '#545454', '#a8a8a8', '#ffffff'],
  },
  {
    id: 'pico-8',
    name: 'PICO-8 Fantasy Console',
    category: 'fantasy-console',
    description: 'Lexaloffle 16-color balanced palette beloved by indie game developers',
    colors: [
      '#000000', '#1d2b53', '#7e2553', '#008751',
      '#ab5236', '#5f574f', '#c2c3c7', '#fff1e8',
      '#ff004d', '#ffa300', '#ffec27', '#00e436',
      '#29adff', '#83769c', '#ff77a8', '#ffccaa'
    ],
  },
  {
    id: 'nes-classic',
    name: 'NES / Famicom (Selected)',
    category: 'retro-hardware',
    description: 'Vibrant 16-color subset of Nintendo 8-bit master CRT palette',
    colors: [
      '#000000', '#fcfcfc', '#f83800', '#e40058',
      '#d80092', '#8c0074', '#0000fc', '#0078f8',
      '#00b800', '#00a800', '#58d854', '#f8b800',
      '#f87858', '#ac7c00', '#bcbcbc', '#7c7c7c'
    ],
  },
  {
    id: 'c64',
    name: 'Commodore 64 (VIC-II)',
    category: 'classic-pc',
    description: 'Muted, nostalgic 16-color palette of the legendary 1982 home computer',
    colors: [
      '#000000', '#ffffff', '#880000', '#aaffee',
      '#cc44cc', '#00cc55', '#0000aa', '#eeee77',
      '#dd8855', '#664400', '#ff7777', '#333333',
      '#777777', '#aaff66', '#0088ff', '#bbbbbb'
    ],
  },
  {
    id: 'cga-mode1',
    name: 'IBM CGA Mode 1 (High)',
    category: 'classic-pc',
    description: 'Iconic 1981 IBM PC 4-color high intensity mode (Black, Cyan, Magenta, White)',
    colors: ['#000000', '#55ffff', '#ff55ff', '#ffffff'],
  },
  {
    id: 'endesga-32',
    name: 'EDG 32 (Endesga)',
    category: 'modern',
    description: 'Modern gold standard 32-color pixel art palette with smooth ramps',
    colors: [
      '#be4a2f', '#d77643', '#ead4aa', '#e4a672',
      '#b86f56', '#733e39', '#3e2731', '#a22633',
      '#e43b44', '#f77622', '#feae34', '#fee761',
      '#63c74d', '#3e8948', '#265c42', '#193c3e',
      '#124e89', '#0099db', '#2ce8f5', '#ffffff',
      '#c0cbdc', '#8b9bb4', '#5a6988', '#3a4466',
      '#262b44', '#181425', '#ff0044', '#68386c',
      '#b55088', '#f6757a', '#e8b796', '#c28569'
    ],
  },
  {
    id: 'cyberpunk-neon',
    name: 'Cyberpunk Neon',
    category: 'modern',
    description: 'Synthwave electric neon shades against deep obsidian shadow tones',
    colors: [
      '#080914', '#181b34', '#312d5a', '#543b7e',
      '#873e84', '#c93b6e', '#f85854', '#fe9844',
      '#ffe052', '#3affb2', '#00d2fe', '#0084ff',
      '#7b42ff', '#df3fff', '#ff54b0', '#ffffff'
    ],
  },
  {
    id: 'solarized-retro',
    name: 'Solarized Dark Pixel',
    category: 'modern',
    description: 'Low-contrast, eye-strain-free precision tones for technical illustrations',
    colors: [
      '#002b36', '#073642', '#586e75', '#657b83',
      '#839496', '#93a1a1', '#eee8d5', '#fdf6e3',
      '#b58900', '#cb4b16', '#dc322f', '#d33682',
      '#6c71c4', '#268bd2', '#2aa198', '#859900'
    ],
  }
];
