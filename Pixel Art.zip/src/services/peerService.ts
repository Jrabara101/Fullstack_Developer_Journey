import { PeerInfo } from '../types';

export interface PeerMessage {
  type: 'peer_join' | 'peer_leave' | 'cursor' | 'draw' | 'sync_state' | 'heartbeat';
  sender: PeerInfo;
  payload?: any;
}

const PEER_COLORS = [
  '#06b6d4', // Cyan
  '#f43f5e', // Rose
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#3b82f6', // Blue
];

export class PeerJamService {
  private channel: BroadcastChannel | null = null;
  private roomCode: string = '';
  public localPeer: PeerInfo;
  private peers: Map<string, PeerInfo> = new Map();
  private onPeersChangeCallbacks: ((peers: PeerInfo[]) => void)[] = [];
  private onRemoteDrawCallbacks: ((data: { frameIndex: number; layerIndex: number; x: number; y: number; color: string | null }) => void)[] = [];
  private heartbeatInterval: number | null = null;

  constructor() {
    const randomId = Math.random().toString(36).substring(2, 9);
    const colorIndex = Math.floor(Math.random() * PEER_COLORS.length);
    this.localPeer = {
      id: randomId,
      name: `Artist_${randomId.slice(0, 4)}`,
      color: PEER_COLORS[colorIndex],
      cursor: { x: -1, y: -1, active: false }
    };
  }

  public joinRoom(roomCode: string) {
    this.leaveRoom();
    this.roomCode = roomCode.toUpperCase().trim();
    if (!this.roomCode) return;

    try {
      this.channel = new BroadcastChannel(`pixelforge_room_${this.roomCode}`);
      this.channel.onmessage = (event) => this.handleMessage(event.data);

      // Announce presence
      this.broadcast({
        type: 'peer_join',
        sender: this.localPeer
      });

      // Periodic heartbeat
      this.heartbeatInterval = window.setInterval(() => {
        this.broadcast({
          type: 'heartbeat',
          sender: this.localPeer
        });
      }, 3000);
    } catch (err) {
      console.warn('BroadcastChannel not supported in this context', err);
    }
  }

  public leaveRoom() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    if (this.channel) {
      try {
        this.broadcast({
          type: 'peer_leave',
          sender: this.localPeer
        });
        this.channel.close();
      } catch {}
      this.channel = null;
    }
    this.peers.clear();
    this.notifyPeersChange();
  }

  public updateLocalName(newName: string) {
    this.localPeer.name = newName;
    this.broadcast({
      type: 'heartbeat',
      sender: this.localPeer
    });
    this.notifyPeersChange();
  }

  public updateLocalColor(newColor: string) {
    this.localPeer.color = newColor;
    this.broadcast({
      type: 'heartbeat',
      sender: this.localPeer
    });
    this.notifyPeersChange();
  }

  public sendCursor(x: number, y: number, active: boolean) {
    if (!this.channel) return;
    this.localPeer.cursor = { x, y, active };
    this.broadcast({
      type: 'cursor',
      sender: this.localPeer,
      payload: { x, y, active }
    });
  }

  public sendDraw(frameIndex: number, layerIndex: number, x: number, y: number, color: string | null) {
    if (!this.channel) return;
    this.broadcast({
      type: 'draw',
      sender: this.localPeer,
      payload: { frameIndex, layerIndex, x, y, color }
    });
  }

  private broadcast(msg: PeerMessage) {
    if (this.channel) {
      try {
        this.channel.postMessage(msg);
      } catch {}
    }
  }

  private handleMessage(msg: PeerMessage) {
    if (!msg || !msg.sender || msg.sender.id === this.localPeer.id) return;

    const senderId = msg.sender.id;

    switch (msg.type) {
      case 'peer_join':
      case 'heartbeat':
        this.peers.set(senderId, msg.sender);
        this.notifyPeersChange();
        // Acknowledge back so newcomer knows we exist
        if (msg.type === 'peer_join') {
          this.broadcast({
            type: 'heartbeat',
            sender: this.localPeer
          });
        }
        break;

      case 'peer_leave':
        this.peers.delete(senderId);
        this.notifyPeersChange();
        break;

      case 'cursor':
        if (this.peers.has(senderId)) {
          const peer = this.peers.get(senderId)!;
          peer.cursor = msg.payload;
          this.notifyPeersChange();
        }
        break;

      case 'draw':
        for (const cb of this.onRemoteDrawCallbacks) {
          cb(msg.payload);
        }
        break;
    }
  }

  public onPeersChange(cb: (peers: PeerInfo[]) => void) {
    this.onPeersChangeCallbacks.push(cb);
    return () => {
      this.onPeersChangeCallbacks = this.onPeersChangeCallbacks.filter(c => c !== cb);
    };
  }

  public onRemoteDraw(cb: (data: { frameIndex: number; layerIndex: number; x: number; y: number; color: string | null }) => void) {
    this.onRemoteDrawCallbacks.push(cb);
    return () => {
      this.onRemoteDrawCallbacks = this.onRemoteDrawCallbacks.filter(c => c !== cb);
    };
  }

  private notifyPeersChange() {
    const list = Array.from(this.peers.values());
    for (const cb of this.onPeersChangeCallbacks) {
      cb(list);
    }
  }

  public getRoomCode(): string {
    return this.roomCode;
  }

  public isConnected(): boolean {
    return !!this.channel && !!this.roomCode;
  }
}

export const peerService = new PeerJamService();
