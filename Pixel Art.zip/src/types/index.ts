export type ToolType = 
  | 'pencil' 
  | 'eraser' 
  | 'bucket' 
  | 'picker' 
  | 'select' 
  | 'line' 
  | 'rect' 
  | 'circle' 
  | 'dither';

export interface Layer {
  id: string;
  name: string;
  visible: boolean;
  opacity: number; // 0 to 1
  locked: boolean;
}

export interface SelectionArea {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  active: boolean;
  floatingPixels?: (string | null)[][]; // selected pixel block for moving/pasting
  floatingPos?: { x: number; y: number };
}

export interface OnionSkinConfig {
  enabled: boolean;
  framesBefore: number;
  framesAfter: number;
  opacity: number; // 0 to 1
  tintPast: string; // color tint for past frames, e.g. #ef4444
  tintFuture: string; // color tint for future frames, e.g. #3b82f6
}

export interface PalettePreset {
  id: string;
  name: string;
  category: 'retro-hardware' | 'fantasy-console' | 'classic-pc' | 'modern';
  colors: string[];
  description: string;
}

export interface PixelStudioState {
  dimensions: { width: number; height: number };
  zoom: number;
  pan: { x: number; y: number };
  activeTool: ToolType;
  primaryColor: string;
  secondaryColor: string;
  brushSize: number;
  palette: string[];
  activePaletteId: string;
  layers: Layer[];
  activeLayerId: string;
  // [frameIndex][layerIndex][y][x] hex string or null
  frames: (string | null)[][][][];
  activeFrameIndex: number;
  fps: number;
  isPlaying: boolean;
  onionSkin: OnionSkinConfig;
  showGrid: boolean;
  showPixelCoordinates: boolean;
  symmetryHorizontal: boolean;
  symmetryVertical: boolean;
}

export interface PeerInfo {
  id: string;
  name: string;
  color: string;
  cursor?: { x: number; y: number; active: boolean };
}

export type ExportFormat = 'png' | 'gif' | 'spritesheet';
export type SpriteSheetEngine = 'godot' | 'unity' | 'phaser' | 'generic';
