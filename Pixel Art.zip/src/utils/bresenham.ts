export interface Point {
  x: number;
  y: number;
}

// Bresenham's line algorithm generates all points between (x0, y0) and (x1, y1)
export function getBresenhamLine(x0: number, y0: number, x1: number, y1: number): Point[] {
  const points: Point[] = [];
  const dx = Math.abs(x1 - x0);
  const dy = Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx - dy;

  let currX = x0;
  let currY = y0;

  while (true) {
    points.push({ x: currX, y: currY });

    if (currX === x1 && currY === y1) break;

    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      currX += sx;
    }
    if (e2 < dx) {
      err += dx;
      currY += sy;
    }
  }

  return points;
}

// Rectangle rasterization
export function getRectanglePoints(
  x0: number, 
  y0: number, 
  x1: number, 
  y1: number, 
  filled: boolean = false
): Point[] {
  const minX = Math.min(x0, x1);
  const maxX = Math.max(x0, x1);
  const minY = Math.min(y0, y1);
  const maxY = Math.max(y0, y1);
  const points: Point[] = [];

  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      if (filled || x === minX || x === maxX || y === minY || y === maxY) {
        points.push({ x, y });
      }
    }
  }

  return points;
}

// Midpoint circle algorithm
export function getCirclePoints(
  cx: number, 
  cy: number, 
  radius: number, 
  filled: boolean = false
): Point[] {
  const points: Point[] = [];
  const pointSet = new Set<string>();

  const addPoint = (x: number, y: number) => {
    const key = `${x},${y}`;
    if (!pointSet.has(key)) {
      pointSet.add(key);
      points.push({ x, y });
    }
  };

  if (filled) {
    for (let y = -radius; y <= radius; y++) {
      for (let x = -radius; x <= radius; x++) {
        if (x * x + y * y <= radius * radius) {
          addPoint(cx + x, cy + y);
        }
      }
    }
    return points;
  }

  let x = radius;
  let y = 0;
  let err = 0;

  while (x >= y) {
    addPoint(cx + x, cy + y);
    addPoint(cx + y, cy + x);
    addPoint(cx - y, cy + x);
    addPoint(cx - x, cy + y);
    addPoint(cx - x, cy - y);
    addPoint(cx - y, cy - x);
    addPoint(cx + y, cy - x);
    addPoint(cx + x, cy - y);

    if (err <= 0) {
      y += 1;
      err += 2 * y + 1;
    }
    if (err > 0) {
      x -= 1;
      err -= 2 * x + 1;
    }
  }

  return points;
}

// Expand brush footprint according to size (1, 2, 3, 4)
export function getBrushFootprint(x: number, y: number, size: number): Point[] {
  if (size <= 1) return [{ x, y }];
  const points: Point[] = [];
  const offset = Math.floor(size / 2);

  for (let dy = 0; dy < size; dy++) {
    for (let dx = 0; dx < size; dx++) {
      points.push({
        x: x - offset + dx,
        y: y - offset + dy
      });
    }
  }
  return points;
}

// Apply symmetry if enabled
export function applySymmetry(
  points: Point[],
  width: number,
  height: number,
  horizontal: boolean,
  vertical: boolean
): Point[] {
  if (!horizontal && !vertical) return points;

  const result: Point[] = [...points];
  const seen = new Set<string>(points.map(p => `${p.x},${p.y}`));

  const add = (x: number, y: number) => {
    if (x >= 0 && x < width && y >= 0 && y < height) {
      const key = `${x},${y}`;
      if (!seen.has(key)) {
        seen.add(key);
        result.push({ x, y });
      }
    }
  };

  for (const p of points) {
    const symX = width - 1 - p.x;
    const symY = height - 1 - p.y;

    if (horizontal) {
      add(symX, p.y);
    }
    if (vertical) {
      add(p.x, symY);
    }
    if (horizontal && vertical) {
      add(symX, symY);
    }
  }

  return result;
}
