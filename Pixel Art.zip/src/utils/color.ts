export interface RGB {
  r: number;
  g: number;
  b: number;
  a?: number;
}

export interface HSL {
  h: number;
  s: number;
  l: number;
}

export function hexToRgb(hex: string): RGB {
  let cleanHex = hex.replace('#', '').trim();
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map(c => c + c).join('');
  }
  const num = parseInt(cleanHex, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

export function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  const rHex = clamp(r).toString(16).padStart(2, '0');
  const gHex = clamp(g).toString(16).padStart(2, '0');
  const bHex = clamp(b).toString(16).padStart(2, '0');
  return `#${rHex}${gHex}${bHex}`.toLowerCase();
}

export function rgbToHsl(r: number, g: number, b: number): HSL {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }

  return { h: h * 360, s: s * 100, l: l * 100 };
}

export function hslToRgb(h: number, s: number, l: number): RGB {
  h = (h % 360 + 360) % 360 / 360;
  s = Math.max(0, Math.min(100, s)) / 100;
  l = Math.max(0, Math.min(100, l)) / 100;

  if (s === 0) {
    const val = Math.round(l * 255);
    return { r: val, g: val, b: val };
  }

  const hue2rgb = (p: number, q: number, t: number) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };

  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;

  const r = Math.round(hue2rgb(p, q, h + 1 / 3) * 255);
  const g = Math.round(hue2rgb(p, q, h) * 255);
  const b = Math.round(hue2rgb(p, q, h - 1 / 3) * 255);

  return { r, g, b };
}

// Perceptually-weighted Euclidean color distance (redmean formula)
export function colorDistance(c1: RGB, c2: RGB): number {
  const rmean = (c1.r + c2.r) / 2;
  const r = c1.r - c2.r;
  const g = c1.g - c2.g;
  const b = c1.b - c2.b;
  return Math.sqrt(
    (((512 + rmean) * r * r) >> 8) +
    4 * g * g +
    (((767 - rmean) * b * b) >> 8)
  );
}

// Find closest matching color in a given palette
export function snapColorToPalette(hex: string, palette: string[]): string {
  if (!palette || palette.length === 0) return hex;
  const targetRgb = hexToRgb(hex);
  let closestColor = palette[0];
  let minDistance = Infinity;

  for (const palHex of palette) {
    const palRgb = hexToRgb(palHex);
    const dist = colorDistance(targetRgb, palRgb);
    if (dist < minDistance) {
      minDistance = dist;
      closestColor = palHex;
    }
  }

  return closestColor.toLowerCase();
}

// Generate dynamic tint/shade ramp for pixel art
// With hue shifting (shadows shift slightly cooler/blue, highlights slightly warmer/yellow)
export function generateColorRamp(baseHex: string, steps: number = 7): string[] {
  const rgb = hexToRgb(baseHex);
  const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);

  const ramp: string[] = [];
  const midIndex = Math.floor(steps / 2);

  for (let i = 0; i < steps; i++) {
    if (i === midIndex) {
      ramp.push(baseHex.toLowerCase());
      continue;
    }

    const diff = i - midIndex; // negative for shadows, positive for highlights
    const factor = diff / midIndex; // -1 to +1

    // Lightness adjustment
    let newL = hsl.l;
    if (factor > 0) {
      newL = hsl.l + (100 - hsl.l) * (factor * 0.75);
    } else {
      newL = hsl.l * (1 + factor * 0.85);
    }

    // Hue shift: warm highlights (+yellow/50°), cool shadows (-blue/240°)
    let newH = hsl.h;
    if (factor > 0) {
      // Warm towards 50° (golden yellow)
      const targetWarm = 50;
      newH = hsl.h + (targetWarm - hsl.h) * (factor * 0.2);
    } else {
      // Cool towards 240° (deep blue)
      const targetCool = 240;
      newH = hsl.h + (targetCool - hsl.h) * (Math.abs(factor) * 0.25);
    }

    // Saturation adjustment
    let newS = hsl.s;
    if (factor > 0) {
      newS = Math.min(100, hsl.s * (1 - factor * 0.15));
    } else {
      newS = Math.min(100, hsl.s * (1 + Math.abs(factor) * 0.2));
    }

    const newRgb = hslToRgb(newH, newS, newL);
    ramp.push(rgbToHex(newRgb.r, newRgb.g, newRgb.b));
  }

  return ramp;
}
