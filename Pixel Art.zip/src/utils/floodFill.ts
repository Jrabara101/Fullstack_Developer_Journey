import { Point } from './bresenham';

export function floodFill(
  pixels: (string | null)[][],
  startX: number,
  startY: number,
  fillColor: string | null
): { modifiedPixels: { x: number; y: number; color: string | null }[] } {
  const height = pixels.length;
  if (height === 0) return { modifiedPixels: [] };
  const width = pixels[0].length;

  if (startX < 0 || startX >= width || startY < 0 || startY >= height) {
    return { modifiedPixels: [] };
  }

  const targetColor = pixels[startY][startX];
  // If clicking on same color, nothing to do
  if (targetColor === fillColor) {
    return { modifiedPixels: [] };
  }

  const modifiedPixels: { x: number; y: number; color: string | null }[] = [];
  const visited = new Uint8Array(width * height);
  const queue: Point[] = [{ x: startX, y: startY }];
  visited[startY * width + startX] = 1;

  while (queue.length > 0) {
    const { x, y } = queue.pop()!;
    modifiedPixels.push({ x, y, color: fillColor });

    const neighbors: [number, number][] = [
      [x + 1, y],
      [x - 1, y],
      [x, y + 1],
      [x, y - 1]
    ];

    for (const [nx, ny] of neighbors) {
      if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
        const index = ny * width + nx;
        if (!visited[index]) {
          if (pixels[ny][nx] === targetColor) {
            visited[index] = 1;
            queue.push({ x: nx, y: ny });
          }
        }
      }
    }
  }

  return { modifiedPixels };
}
