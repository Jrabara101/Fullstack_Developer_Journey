/**
 * Lightweight, robust GIF89a encoder in TypeScript
 * Handles multi-frame animated GIFs with transparency, variable delays, and LZW compression.
 */

export interface GifFrameInput {
  data: Uint8ClampedArray; // RGBA pixel array
  width: number;
  height: number;
  delayMs: number; // in milliseconds (e.g. 100 for 10fps)
}

export function encodeGif(frames: GifFrameInput[]): Blob {
  if (frames.length === 0) {
    throw new Error('At least one frame is required for GIF generation');
  }

  const width = frames[0].width;
  const height = frames[0].height;
  const buffer: number[] = [];

  const writeByte = (b: number) => buffer.push(b & 0xff);
  const writeWord = (w: number) => {
    buffer.push(w & 0xff);
    buffer.push((w >> 8) & 0xff);
  };
  const writeString = (s: string) => {
    for (let i = 0; i < s.length; i++) buffer.push(s.charCodeAt(i));
  };

  // Header: GIF89a
  writeString('GIF89a');

  // Logical Screen Descriptor
  writeWord(width);
  writeWord(height);
  // Packed field: no global color table by default (we use local color tables for precision), 8 bits/pixel
  writeByte(0x70);
  writeByte(0); // background color index
  writeByte(0); // pixel aspect ratio

  // Netscape Application Extension (for looping)
  writeByte(0x21); // extension introducer
  writeByte(0xff); // application extension label
  writeByte(11);   // block size
  writeString('NETSCAPE2.0');
  writeByte(3);    // sub-block data size
  writeByte(1);    // sub-block ID (loop count)
  writeWord(0);    // loop count 0 = forever
  writeByte(0);    // block terminator

  for (const frame of frames) {
    // 1. Quantize RGBA frame to max 256 colors palette with transparency
    const { palette, indexedPixels, transparentIndex } = quantizeFrame(frame.data, frame.width, frame.height);

    // Compute color table size (power of 2, 2 to 256 entries)
    let colorCount = Math.max(2, palette.length);
    let pow2 = 1;
    let bitDepth = 1;
    while (pow2 < colorCount && bitDepth < 8) {
      pow2 <<= 1;
      bitDepth++;
    }
    while (palette.length < pow2) {
      palette.push([0, 0, 0]);
    }

    // Graphic Control Extension
    writeByte(0x21); // extension
    writeByte(0xf9); // graphic control label
    writeByte(4);    // block size

    // Packed fields: disposal method 2 (restore to background), transparency flag
    const hasTransparency = transparentIndex !== -1;
    const disposalMethod = 2; // Restore to background
    const packedGCE = (disposalMethod << 2) | (hasTransparency ? 1 : 0);
    writeByte(packedGCE);

    // Delay time in 1/100ths of a second
    const delayHundredths = Math.max(1, Math.round(frame.delayMs / 10));
    writeWord(delayHundredths);

    writeByte(hasTransparency ? transparentIndex : 0); // transparent color index
    writeByte(0); // block terminator

    // Image Descriptor
    writeByte(0x2c); // image separator
    writeWord(0);    // left
    writeWord(0);    // top
    writeWord(width);
    writeWord(height);

    // Local Color Table Flag (1), Interlace (0), Sort (0), Size (bitDepth - 1)
    const packedID = 0x80 | (bitDepth - 1);
    writeByte(packedID);

    // Local Color Table
    for (const [r, g, b] of palette) {
      writeByte(r);
      writeByte(g);
      writeByte(b);
    }

    // LZW Compression
    const minCodeSize = Math.max(2, bitDepth);
    writeByte(minCodeSize);

    const lzwData = lzwEncode(indexedPixels, minCodeSize);
    let offset = 0;
    while (offset < lzwData.length) {
      const chunkSize = Math.min(255, lzwData.length - offset);
      writeByte(chunkSize);
      for (let i = 0; i < chunkSize; i++) {
        writeByte(lzwData[offset + i]);
      }
      offset += chunkSize;
    }
    writeByte(0); // block terminator
  }

  // Trailer
  writeByte(0x3b);

  return new Blob([new Uint8Array(buffer)], { type: 'image/gif' });
}

function quantizeFrame(rgba: Uint8ClampedArray, width: number, height: number) {
  const palette: [number, number, number][] = [];
  const colorMap = new Map<string, number>();
  const totalPixels = width * height;
  const indexedPixels = new Uint8Array(totalPixels);
  let transparentIndex = -1;

  for (let i = 0; i < totalPixels; i++) {
    const r = rgba[i * 4];
    const g = rgba[i * 4 + 1];
    const b = rgba[i * 4 + 2];
    const a = rgba[i * 4 + 3];

    // Transparent pixel
    if (a < 128) {
      if (transparentIndex === -1) {
        transparentIndex = palette.length;
        palette.push([0, 0, 0]); // dummy color
      }
      indexedPixels[i] = transparentIndex;
      continue;
    }

    const key = `${r},${g},${b}`;
    let idx = colorMap.get(key);
    if (idx === undefined) {
      if (palette.length < 256) {
        idx = palette.length;
        palette.push([r, g, b]);
        colorMap.set(key, idx);
      } else {
        // Fallback to nearest color if palette exceeds 256
        let minDist = Infinity;
        idx = 0;
        for (let p = 0; p < palette.length; p++) {
          if (p === transparentIndex) continue;
          const [pr, pg, pb] = palette[p];
          const dist = (r - pr) ** 2 + (g - pg) ** 2 + (b - pb) ** 2;
          if (dist < minDist) {
            minDist = dist;
            idx = p;
          }
        }
      }
    }
    indexedPixels[i] = idx;
  }

  return { palette, indexedPixels, transparentIndex };
}

function lzwEncode(indexedPixels: Uint8Array, minCodeSize: number): number[] {
  const clearCode = 1 << minCodeSize;
  const eoiCode = clearCode + 1;
  let codeSize = minCodeSize + 1;
  let nextCode = eoiCode + 1;

  const dictionary = new Map<string, number>();
  const resetDict = () => {
    dictionary.clear();
    for (let i = 0; i < clearCode; i++) {
      dictionary.set(String(i), i);
    }
    codeSize = minCodeSize + 1;
    nextCode = eoiCode + 1;
  };

  resetDict();

  const outputBits: number[] = [];
  let bitCount = 0;
  let currentByte = 0;

  const emitCode = (code: number) => {
    for (let i = 0; i < codeSize; i++) {
      const bit = (code >> i) & 1;
      currentByte |= bit << bitCount;
      bitCount++;
      if (bitCount === 8) {
        outputBits.push(currentByte);
        currentByte = 0;
        bitCount = 0;
      }
    }
  };

  emitCode(clearCode);

  if (indexedPixels.length > 0) {
    let currentPrefix = String(indexedPixels[0]);

    for (let i = 1; i < indexedPixels.length; i++) {
      const k = indexedPixels[i];
      const combined = `${currentPrefix},${k}`;

      if (dictionary.has(combined)) {
        currentPrefix = combined;
      } else {
        emitCode(dictionary.get(currentPrefix)!);

        if (nextCode < 4096) {
          dictionary.set(combined, nextCode++);
          if (nextCode === (1 << codeSize) + 1 && codeSize < 12) {
            codeSize++;
          }
        } else {
          emitCode(clearCode);
          resetDict();
        }

        currentPrefix = String(k);
      }
    }

    emitCode(dictionary.get(currentPrefix)!);
  }

  emitCode(eoiCode);

  // Flush remaining bits
  if (bitCount > 0) {
    outputBits.push(currentByte);
  }

  return outputBits;
}
