export interface PixelDiff {
  frameIndex: number;
  layerIndex: number;
  x: number;
  y: number;
  oldColor: string | null;
  newColor: string | null;
}

export type HistoryCommand =
  | {
      type: 'pixel_batch';
      description: string;
      diffs: PixelDiff[];
    }
  | {
      type: 'snapshot';
      description: string;
      beforeFrames: (string | null)[][][][];
      afterFrames: (string | null)[][][][];
    };

export class HistoryManager {
  private undoStack: HistoryCommand[] = [];
  private redoStack: HistoryCommand[] = [];
  private maxDepth: number = 50;

  constructor(maxDepth: number = 50) {
    this.maxDepth = maxDepth;
  }

  public pushCommand(command: HistoryCommand) {
    // If empty batch, discard
    if (command.type === 'pixel_batch' && command.diffs.length === 0) return;

    this.undoStack.push(command);
    if (this.undoStack.length > this.maxDepth) {
      this.undoStack.shift();
    }
    this.redoStack = []; // Clear redo stack upon new action
  }

  public canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  public canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  public undo(currentFrames: (string | null)[][][][]): (string | null)[][][][] | null {
    if (!this.canUndo()) return null;
    const command = this.undoStack.pop()!;
    this.redoStack.push(command);

    if (command.type === 'snapshot') {
      return structuredClone(command.beforeFrames);
    }

    if (command.type === 'pixel_batch') {
      const nextFrames = structuredClone(currentFrames);
      for (const diff of command.diffs) {
        if (
          nextFrames[diff.frameIndex] &&
          nextFrames[diff.frameIndex][diff.layerIndex] &&
          nextFrames[diff.frameIndex][diff.layerIndex][diff.y]
        ) {
          nextFrames[diff.frameIndex][diff.layerIndex][diff.y][diff.x] = diff.oldColor;
        }
      }
      return nextFrames;
    }

    return null;
  }

  public redo(currentFrames: (string | null)[][][][]): (string | null)[][][][] | null {
    if (!this.canRedo()) return null;
    const command = this.redoStack.pop()!;
    this.undoStack.push(command);

    if (command.type === 'snapshot') {
      return structuredClone(command.afterFrames);
    }

    if (command.type === 'pixel_batch') {
      const nextFrames = structuredClone(currentFrames);
      for (const diff of command.diffs) {
        if (
          nextFrames[diff.frameIndex] &&
          nextFrames[diff.frameIndex][diff.layerIndex] &&
          nextFrames[diff.frameIndex][diff.layerIndex][diff.y]
        ) {
          nextFrames[diff.frameIndex][diff.layerIndex][diff.y][diff.x] = diff.newColor;
        }
      }
      return nextFrames;
    }

    return null;
  }

  public clear() {
    this.undoStack = [];
    this.redoStack = [];
  }
}
