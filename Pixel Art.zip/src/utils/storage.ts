import { Layer } from '../types';

export function createEmptyGrid(width: number, height: number): (string | null)[][] {
  const grid: (string | null)[][] = [];
  for (let y = 0; y < height; y++) {
    const row: (string | null)[] = [];
    for (let x = 0; x < width; x++) {
      row.push(null);
    }
    grid.push(row);
  }
  return grid;
}

export function createEmptyFrame(width: number, height: number, layerCount: number): (string | null)[][][] {
  const frame: (string | null)[][][] = [];
  for (let l = 0; l < layerCount; l++) {
    frame.push(createEmptyGrid(width, height));
  }
  return frame;
}

// Default initial layers
export const DEFAULT_LAYERS: Layer[] = [
  { id: 'layer-bg', name: 'Background', visible: true, opacity: 1, locked: false },
  { id: 'layer-flats', name: 'Flats', visible: true, opacity: 1, locked: false },
  { id: 'layer-lineart', name: 'Line Art', visible: true, opacity: 1, locked: false },
];

/**
 * Built-in Preset: Animated 16x16 Pixel Hero Knight walking animation!
 * 4 frames with retro fantasy palette
 */
export function getStarterKnightFrames(): (string | null)[][][][] {
  const w = 16;
  const h = 16;
  const frames: (string | null)[][][][] = [];

  // Colors
  const helm = '#83769c';
  const helmDark = '#5f574f';
  const visor = '#29adff';
  const skin = '#ffccaa';
  const armor = '#c2c3c7';
  const armorDark = '#5f574f';
  const swordBlade = '#ffffff';
  const swordHilt = '#ffa300';
  const boots = '#ab5236';

  // Frame 0: Idle
  const f0 = createEmptyFrame(w, h, 3);
  // LineArt & Details on layer 2, Flats on layer 1
  const l1_0 = f0[1]; // Flats
  // Helmet
  for (let x = 6; x <= 10; x++) { l1_0[3][x] = helm; l1_0[4][x] = helm; }
  l1_0[2][7] = helm; l1_0[2][8] = helm; l1_0[2][9] = helm;
  // Visor
  l1_0[4][9] = visor; l1_0[4][10] = visor;
  // Face
  l1_0[5][7] = skin; l1_0[5][8] = skin; l1_0[5][9] = skin;
  // Torso / armor
  for (let y = 6; y <= 9; y++) {
    for (let x = 6; x <= 9; x++) l1_0[y][x] = armor;
  }
  l1_0[7][6] = armorDark; l1_0[8][6] = armorDark;
  // Sword
  l1_0[7][11] = swordHilt;
  l1_0[6][11] = swordBlade; l1_0[5][11] = swordBlade; l1_0[4][11] = swordBlade;
  // Legs
  l1_0[10][7] = boots; l1_0[11][7] = boots;
  l1_0[10][9] = boots; l1_0[11][9] = boots;
  frames.push(f0);

  // Frame 1: Walk Step Left
  const f1 = createEmptyFrame(w, h, 3);
  const l1_1 = f1[1];
  for (let x = 6; x <= 10; x++) { l1_1[2][x] = helm; l1_1[3][x] = helm; }
  l1_1[1][7] = helm; l1_1[1][8] = helm; l1_1[1][9] = helm;
  l1_1[3][9] = visor; l1_1[3][10] = visor;
  l1_1[4][7] = skin; l1_1[4][8] = skin; l1_1[4][9] = skin;
  for (let y = 5; y <= 8; y++) {
    for (let x = 6; x <= 9; x++) l1_1[y][x] = armor;
  }
  l1_1[6][12] = swordHilt;
  l1_1[5][12] = swordBlade; l1_1[4][12] = swordBlade; l1_1[3][12] = swordBlade;
  l1_1[9][6] = boots; l1_1[10][5] = boots; // front leg stride
  l1_1[9][9] = boots; l1_1[10][10] = boots; // back leg stride
  frames.push(f1);

  // Frame 2: Contact
  const f2 = createEmptyFrame(w, h, 3);
  const l1_2 = f2[1];
  for (let x = 6; x <= 10; x++) { l1_2[3][x] = helm; l1_2[4][x] = helm; }
  l1_2[2][7] = helm; l1_2[2][8] = helm; l1_2[2][9] = helm;
  l1_2[4][9] = visor; l1_2[4][10] = visor;
  l1_2[5][7] = skin; l1_2[5][8] = skin; l1_2[5][9] = skin;
  for (let y = 6; y <= 9; y++) {
    for (let x = 6; x <= 9; x++) l1_2[y][x] = armor;
  }
  l1_2[7][11] = swordHilt;
  l1_2[6][11] = swordBlade; l1_2[5][11] = swordBlade; l1_2[4][11] = swordBlade;
  l1_2[10][7] = boots; l1_2[11][7] = boots;
  l1_2[10][9] = boots; l1_2[11][9] = boots;
  frames.push(f2);

  // Frame 3: Walk Step Right
  const f3 = createEmptyFrame(w, h, 3);
  const l1_3 = f3[1];
  for (let x = 6; x <= 10; x++) { l1_3[2][x] = helm; l1_3[3][x] = helm; }
  l1_3[1][7] = helm; l1_3[1][8] = helm; l1_3[1][9] = helm;
  l1_3[3][9] = visor; l1_3[3][10] = visor;
  l1_3[4][7] = skin; l1_3[4][8] = skin; l1_3[4][9] = skin;
  for (let y = 5; y <= 8; y++) {
    for (let x = 6; x <= 9; x++) l1_3[y][x] = armor;
  }
  l1_3[6][10] = swordHilt;
  l1_3[5][10] = swordBlade; l1_3[4][10] = swordBlade; l1_3[3][10] = swordBlade;
  l1_3[9][8] = boots; l1_3[10][9] = boots;
  l1_3[9][7] = boots; l1_3[10][6] = boots;
  frames.push(f3);

  return frames;
}

const STORAGE_KEY = 'pixelforge_studio_project_v1';

export function saveProjectToStorage(data: unknown) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.warn('Unable to save to localStorage:', err);
  }
}

export function loadProjectFromStorage(): unknown | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
