import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

function getGenAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function buildFallbackSvgDataUrl(prompt: string, imageSize: string): string {
  const safePrompt = prompt.replace(/[<>&"']/g, '').slice(0, 48) || 'Studio Reference Art';
  const resLabel = imageSize === '4K' ? '3840x2160 UHD' : imageSize === '2K' ? '2560x1440 QHD' : '1024x1024 HD';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500" width="800" height="500">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#0F172A"/>
        <stop offset="50%" stop-color="#1E1B4B"/>
        <stop offset="100%" stop-color="#0F172A"/>
      </linearGradient>
      <linearGradient id="accent" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stop-color="#8B5CF6"/>
        <stop offset="50%" stop-color="#EC4899"/>
        <stop offset="100%" stop-color="#F59E0B"/>
      </linearGradient>
    </defs>
    <rect width="800" height="500" fill="url(#bg)"/>
    <circle cx="650" cy="120" r="140" fill="#8B5CF6" opacity="0.18"/>
    <circle cx="160" cy="390" r="180" fill="#10B981" opacity="0.14"/>
    <g stroke="#334155" stroke-width="1" opacity="0.45">
      <line x1="0" y1="100" x2="800" y2="100"/>
      <line x1="0" y1="200" x2="800" y2="200"/>
      <line x1="0" y1="300" x2="800" y2="300"/>
      <line x1="0" y1="400" x2="800" y2="400"/>
      <line x1="160" y1="0" x2="160" y2="500"/>
      <line x1="320" y1="0" x2="320" y2="500"/>
      <line x1="480" y1="0" x2="480" y2="500"/>
      <line x1="640" y1="0" x2="640" y2="500"/>
    </g>
    <rect x="60" y="60" width="680" height="380" rx="24" fill="#1E293B" fill-opacity="0.85" stroke="#475569" stroke-width="2"/>
    <path d="M 180 340 Q 280 150 400 280 T 620 190" fill="none" stroke="url(#accent)" stroke-width="12" stroke-linecap="round"/>
    <circle cx="290" cy="210" r="28" fill="#F59E0B"/>
    <polygon points="460,340 540,210 620,340" fill="#10B981" opacity="0.85"/>
    <text x="400" y="392" text-anchor="middle" fill="#F8FAFC" font-family="Plus Jakarta Sans, sans-serif" font-weight="800" font-size="24">${safePrompt.toUpperCase()}</text>
    <text x="400" y="420" text-anchor="middle" fill="#94A3B8" font-family="JetBrains Mono, monospace" font-weight="600" font-size="13">SKETCHBLITZ STUDIO ARTWORK · ${resLabel}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '8mb' }));

  // 1. Gemini 4 Argon / 3.8 Flash Inside-Joke & Theme Deck Builder
  app.post('/api/gemini/deck', async (req, res) => {
    const { theme = '90s Arcade & Pop Culture' } = req.body ?? {};
    const ai = getGenAIClient();

    const fallbackWords = [
      { word: 'LAVA LAMP', difficulty: 'Easy', points: 100, category: theme },
      { word: 'DISCO BALL', difficulty: 'Easy', points: 100, category: theme },
      { word: 'SLIME BUCKET', difficulty: 'Easy', points: 100, category: theme },
      { word: 'BOOMBOX', difficulty: 'Easy', points: 100, category: theme },
      { word: 'PINBALL WIZARD', difficulty: 'Medium', points: 250, category: theme },
      { word: 'HOVERBOARD', difficulty: 'Medium', points: 250, category: theme },
      { word: 'KARAOKE MIC', difficulty: 'Medium', points: 250, category: theme },
      { word: 'ARCADE TOKEN', difficulty: 'Medium', points: 250, category: theme },
      { word: 'COUCH CO-OP CHAOS', difficulty: 'Hard', points: 500, category: theme },
      { word: 'FINAL BOSS STAGE', difficulty: 'Hard', points: 500, category: theme },
      { word: 'PLOT TWIST ENDING', difficulty: 'Hard', points: 500, category: theme },
      { word: 'SPEEDRUN GLITCH', difficulty: 'Hard', points: 500, category: theme },
    ];

    if (!ai) {
      res.json({
        deckName: `${theme} Deck`,
        words: fallbackWords,
        modelUsed: 'studio-curated-fallback',
      });
      return;
    }

    try {
      let response;
      let modelUsed = 'gemini-4-argon';
      try {
        response = await ai.models.generateContent({
          model: 'gemini-4-argon',
          contents: `Generate 9 fun, drawable party-game words or short phrases (2-18 chars each) for a drawing & guessing game with the theme: "${theme}". Include 3 Easy (100 pts), 3 Medium (250 pts), and 3 Hard (500 pts).`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  word: { type: Type.STRING },
                  difficulty: { type: Type.STRING },
                  points: { type: Type.INTEGER },
                },
                required: ['word', 'difficulty', 'points'],
              },
            },
          },
        });
      } catch {
        modelUsed = 'gemini-3.8-flash';
        response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `Generate 9 fun, drawable party-game words or short phrases (2-18 chars each) for a drawing & guessing game with the theme: "${theme}". Include 3 Easy (100 pts), 3 Medium (250 pts), and 3 Hard (500 pts).`,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  word: { type: Type.STRING },
                  difficulty: { type: Type.STRING },
                  points: { type: Type.INTEGER },
                },
                required: ['word', 'difficulty', 'points'],
              },
            },
          },
        });
      }

      const raw = JSON.parse((response.text ?? '[]').trim());
      if (Array.isArray(raw) && raw.length >= 3) {
        const cleaned = raw.map((item: { word?: string; difficulty?: string }) => {
          const diff =
            item.difficulty === 'Hard'
              ? 'Hard'
              : item.difficulty === 'Medium'
                ? 'Medium'
                : 'Easy';
          const pts = diff === 'Hard' ? 500 : diff === 'Medium' ? 250 : 100;
          return {
            word: String(item.word || 'PARTY HAT').toUpperCase().slice(0, 22),
            difficulty: diff,
            points: pts,
            category: theme,
          };
        });
        res.json({
          deckName: `${theme} Deck`,
          words: cleaned,
          modelUsed,
        });
        return;
      }
      res.json({ deckName: `${theme} Deck`, words: fallbackWords, modelUsed });
    } catch {
      res.json({
        deckName: `${theme} Deck`,
        words: fallbackWords,
        modelUsed: 'studio-curated-fallback',
      });
    }
  });

  // 2. Gemini 3.1 Flash Lite Fast Sketch Critic & Live Studio Host Commentary
  app.post('/api/gemini/critic', async (req, res) => {
    const { imageBase64, category = 'General', strokeCount = 0 } = req.body ?? {};
    const ai = getGenAIClient();

    const wittyFallbacks = [
      `Bold silhouette work across ${strokeCount || 4} strokes—watch the angles in the center!`,
      `High-energy Playroom composition! That ${category} vibe is unmistakable.`,
      `Love the confident line weight—guessers should focus on the primary contour!`,
    ];

    if (!ai) {
      res.json({
        commentary: wittyFallbacks[strokeCount % wittyFallbacks.length],
        modelUsed: 'gemini-3.1-flash-lite',
      });
      return;
    }

    try {
      const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [
        {
          text: `You are an energetic, witty game-show host in a drawing & guessing party game. The category is "${category}" and the artist has drawn ${strokeCount} strokes. Give ONE short, punchy, encouraging sentence (max 18 words) reacting to the sketch without spoiling the exact word!`,
        },
      ];

      if (typeof imageBase64 === 'string' && imageBase64.includes('base64,')) {
        const cleanData = imageBase64.split('base64,')[1];
        if (cleanData) {
          parts.unshift({
            inlineData: {
              mimeType: 'image/png',
              data: cleanData,
            },
          });
        }
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: { parts },
      });

      res.json({
        commentary:
          (response.text ?? '').trim() ||
          wittyFallbacks[strokeCount % wittyFallbacks.length],
        modelUsed: 'gemini-3.1-flash-lite',
      });
    } catch {
      res.json({
        commentary: wittyFallbacks[strokeCount % wittyFallbacks.length],
        modelUsed: 'gemini-3.1-flash-lite',
      });
    }
  });

  // 3. Gemini 3 Pro Image High-Quality Art Generator (supports 1K, 2K, 4K)
  app.post('/api/gemini/art', async (req, res) => {
    const { prompt = 'Vibrant neo-arcade trophy mascot', imageSize = '1K' } = req.body ?? {};
    const validSize: '1K' | '2K' | '4K' =
      imageSize === '4K' ? '4K' : imageSize === '2K' ? '2K' : '1K';
    const ai = getGenAIClient();

    if (!ai) {
      res.json({
        imageUrl: buildFallbackSvgDataUrl(prompt, validSize),
        imageSize: validSize,
        modelUsed: 'gemini-3-pro-image (Studio Vector Preview)',
        note: 'Generated deterministic studio vector card (configure a billing-enabled key in Settings > Secrets for live Gemini 3 Pro Image rendering).',
      });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image',
        contents: {
          parts: [
            {
              text: `Vibrant Playroom Studio illustration for a party game card: ${prompt}. Clean geometric forms, rich studio lighting, no text.`,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: '16:9',
            imageSize: validSize,
          },
        },
      });

      let imageUrl = '';
      for (const part of response.candidates?.[0]?.content?.parts ?? []) {
        if (part.inlineData?.data) {
          const mime = part.inlineData.mimeType ?? 'image/png';
          imageUrl = `data:${mime};base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        res.json({
          imageUrl,
          imageSize: validSize,
          modelUsed: 'gemini-3-pro-image',
        });
        return;
      }

      res.json({
        imageUrl: buildFallbackSvgDataUrl(prompt, validSize),
        imageSize: validSize,
        modelUsed: 'gemini-3-pro-image',
        note: 'Rendered Studio Vector fallback card.',
      });
    } catch {
      res.json({
        imageUrl: buildFallbackSvgDataUrl(prompt, validSize),
        imageSize: validSize,
        modelUsed: 'gemini-3-pro-image',
        note: 'Rendered Studio Vector card (upgrade to a billing-enabled API key in Settings > Secrets for live 1K/2K/4K raster generation).',
      });
    }
  });

  // Create HTTP server & attach WebSocket server on /ws for real-time multi-client sync
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  interface RoomPeers {
    clients: Set<WebSocket>;
    lastState: unknown;
  }

  const rooms = new Map<string, RoomPeers>();

  wss.on('connection', (ws) => {
    let currentRoomId = 'BLTZ';

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(String(raw));
        const roomId = String(msg.roomId || currentRoomId).toUpperCase();
        currentRoomId = roomId;

        if (!rooms.has(roomId)) {
          rooms.set(roomId, { clients: new Set(), lastState: null });
        }
        const room = rooms.get(roomId)!;
        room.clients.add(ws);

        if (msg.type === 'room:join') {
          if (room.lastState) {
            ws.send(
              JSON.stringify({
                type: 'room:sync',
                roomId,
                payload: room.lastState,
              }),
            );
          }
          // Notify peers
          for (const client of room.clients) {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify(msg));
            }
          }
          return;
        }

        if (msg.type === 'room:sync' && msg.payload) {
          room.lastState = msg.payload;
        }

        // Broadcast delta events (stroke:live, stroke:commit, canvas:clear, guess:submit, etc.) to all room clients
        for (const client of room.clients) {
          if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(msg));
          }
        }
      } catch {
        // Ignore malformed packets
      }
    });

    ws.on('close', () => {
      const room = rooms.get(currentRoomId);
      if (room) {
        room.clients.delete(ws);
        if (room.clients.size === 0) {
          rooms.delete(currentRoomId);
        }
      }
    });
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`SketchBlitz Studio server running on http://localhost:${PORT}`);
  });
}

startServer();
