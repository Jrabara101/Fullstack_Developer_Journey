/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { useGameStore } from './store/useGameStore';
import { ThreeStudioStage } from './components/ThreeStudioStage';
import { TitleScreen } from './components/TitleScreen';
import { DrawingViewport } from './components/DrawingViewport';
import { ArtistToolbar } from './components/ArtistToolbar';
import { ChatGuessStream } from './components/ChatGuessStream';
import { PlayerScoreboard } from './components/PlayerScoreboard';
import {
  WordSelectionModal,
  PairingAndDualScreenModal,
  GeminiStudioHubModal,
  PauseAndGameOverModals,
} from './components/ModalsAndDrawers';
import {
  Volume2,
  VolumeX,
  Pause,
  RotateCcw,
  QrCode,
  Sparkles,
  MessageSquare,
} from 'lucide-react';

export default function App() {
  const shellState = useGameStore((s) => s.shellState);
  const phase = useGameStore((s) => s.phase);
  const round = useGameStore((s) => s.round);
  const timeLeft = useGameStore((s) => s.timeLeft);
  const maxTime = useGameStore((s) => s.maxTime);
  const hiddenWord = useGameStore((s) => s.hiddenWord);
  const actualWord = useGameStore((s) => s.actualWord);
  const wordDifficulty = useGameStore((s) => s.wordDifficulty);
  const wordPoints = useGameStore((s) => s.wordPoints);
  const currentArtistId = useGameStore((s) => s.currentArtistId);
  const localPlayerId = useGameStore((s) => s.localPlayerId);
  const players = useGameStore((s) => s.players);
  const dualScreenMode = useGameStore((s) => s.dualScreenMode);
  const muted = useGameStore((s) => s.muted);

  const startGameFromTitle = useGameStore((s) => s.startGameFromTitle);
  const togglePause = useGameStore((s) => s.togglePause);
  const restartMatch = useGameStore((s) => s.restartMatch);
  const toggleMute = useGameStore((s) => s.toggleMute);
  const setTool = useGameStore((s) => s.setTool);
  const tickSecond = useGameStore((s) => s.tickSecond);
  const connectRealtimeRoom = useGameStore((s) => s.connectRealtimeRoom);
  const setRoomId = useGameStore((s) => s.setRoomId);
  const requestGeminiCritic = useGameStore((s) => s.requestGeminiCritic);

  const [pairingModalOpen, setPairingModalOpen] = useState(false);
  const [geminiModalOpen, setGeminiModalOpen] = useState(false);
  const [mobileChatExpanded, setMobileChatExpanded] = useState(false);

  const exportCanvasFnRef = useRef<(() => string) | null>(null);

  const localPlayer =
    players.find((p) => p.id === localPlayerId) || players[0];
  const isLocalArtist = currentArtistId === localPlayerId;

  // Initialize room connection, body data-state, and check ?autostart=1
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get('room');
    if (roomParam) {
      setRoomId(roomParam);
    } else {
      connectRealtimeRoom('BLTZ');
    }

    if (params.get('autostart') === '1') {
      document.body.dataset.state = 'playing';
      startGameFromTitle(true);
    } else {
      document.body.dataset.state = 'title';
    }
  }, [connectRealtimeRoom, setRoomId, startGameFromTitle]);

  // 1-second authoritative round countdown timer
  useEffect(() => {
    const timer = window.setInterval(() => {
      tickSecond();
    }, 1000);
    return () => clearInterval(timer);
  }, [tickSecond]);

  // Global keyboard shortcuts (Enter/Space on Title, P/Escape for Pause, M for Mute, B/E/F for tools)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isInputFocused =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable);

      if (shellState === 'title' && !isInputFocused) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          startGameFromTitle(false);
        }
        return;
      }

      if (isInputFocused) return;

      if (e.key === 'Escape' || e.key.toLowerCase() === 'p') {
        if (!pairingModalOpen && !geminiModalOpen) {
          e.preventDefault();
          togglePause();
        }
      } else if (e.key.toLowerCase() === 'm') {
        e.preventDefault();
        toggleMute();
      } else if (e.key.toLowerCase() === 'r' && shellState === 'playing') {
        e.preventDefault();
        restartMatch();
      } else if (e.key.toLowerCase() === 'b' && shellState === 'playing') {
        setTool('brush');
      } else if (e.key.toLowerCase() === 'e' && shellState === 'playing') {
        setTool('eraser');
      } else if (e.key.toLowerCase() === 'f' && shellState === 'playing') {
        setTool('fill');
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    shellState,
    pairingModalOpen,
    geminiModalOpen,
    startGameFromTitle,
    togglePause,
    toggleMute,
    restartMatch,
    setTool,
  ]);

  // Dynamic timer progress bar color shift (Green -> Amber -> Red)
  const progressPct =
    maxTime > 0 ? Math.max(0, Math.min(100, (timeLeft / maxTime) * 100)) : 100;
  const timerBarColor =
    timeLeft <= 10
      ? 'bg-[#EF4444]'
      : timeLeft <= 25
        ? 'bg-[#F59E0B]'
        : 'bg-[#10B981]';

  const showUnmaskedWord =
    isLocalArtist || localPlayer.hasGuessedCorrectly || phase === 'ROUND_RECAP';

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0F172A] text-[#F8FAFC] select-none">
      {/* Isolated Full-Bleed Three.js 3D Playroom Studio Stage */}
      <ThreeStudioStage shellState={shellState} />

      {/* Title Screen Overlay */}
      {shellState === 'title' && (
        <TitleScreen
          onOpenPairingModal={() => setPairingModalOpen(true)}
          onOpenGeminiModal={() => setGeminiModalOpen(true)}
        />
      )}

      {/* Active Playing Game Shell */}
      {shellState !== 'title' && (
        <main className="relative z-10 w-full h-full flex flex-col p-2.5 md:p-4 gap-2.5 md:gap-3 pointer-events-auto">
          {/* Top Phase & Timer HUD Strip */}
          <div className="w-full rounded-2xl bg-[#1E293B] border border-slate-700 px-3.5 py-2 shadow-xl flex flex-col gap-1.5 shrink-0">
            <div className="flex items-center justify-between gap-3">
              {/* Left Cluster: Round Badge & Mode */}
              <div className="flex items-center gap-3 min-w-0">
                <div className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase block">
                    ROUND
                  </span>
                  <span
                    data-testid="hud-round-counter"
                    className="text-sm font-extrabold text-white font-mono-code tabular-nums"
                  >
                    {round.current}/{round.total}
                  </span>
                </div>

                <div className="hidden sm:block min-w-0">
                  <span className="text-[11px] font-semibold text-violet-400 uppercase tracking-wider block">
                    {isLocalArtist ? 'YOUR PROMPT TO DRAW' : 'GUESS THE WORD'} ·{' '}
                    {wordDifficulty} (+{wordPoints} PTS)
                  </span>
                  <span className="text-xs text-slate-400 truncate block">
                    {isLocalArtist
                      ? 'Sketch clearly—players earn bonus points for fast deductions!'
                      : 'Near-misses within 1–2 letters trigger private Warm Guess hints'}
                  </span>
                </div>
              </div>

              {/* Center Focal Anchor: Masked or Active Secret Word Display */}
              <div className="px-4 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                  {showUnmaskedWord
                    ? 'SECRET WORD (VISIBLE TO YOU)'
                    : `HIDDEN WORD (${(actualWord || 'CAMPFIRE').length} LETTERS)`}
                </span>
                <span
                  data-testid="hud-word-display"
                  className={`text-base md:text-xl font-extrabold font-mono-code tracking-widest ${
                    showUnmaskedWord ? 'text-emerald-400' : 'text-amber-300'
                  }`}
                >
                  {showUnmaskedWord ? actualWord : hiddenWord}
                </span>
              </div>

              {/* Right Cluster: Countdown Timer & Utility Icon Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <div
                  className={`px-3 py-1 rounded-xl border text-right ${
                    timeLeft <= 15
                      ? 'bg-red-950/80 border-red-500 text-red-200'
                      : 'bg-slate-900 border-slate-700 text-white'
                  }`}
                >
                  <span className="text-[10px] font-semibold text-slate-400 block">
                    TIME
                  </span>
                  <span
                    data-testid="hud-timer-readout"
                    className="text-base md:text-lg font-extrabold font-mono-code tabular-nums"
                  >
                    {Math.round(timeLeft)}s
                  </span>
                </div>

                <button
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    setPairingModalOpen(true);
                  }}
                  aria-label="Open Room Pairing and Dual-Screen Mode"
                  title="Room Pairing & QR [Cast]"
                  className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-200 cursor-pointer"
                >
                  <QrCode className="w-4 h-4 text-violet-400" />
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    setGeminiModalOpen(true);
                  }}
                  aria-label="Open AI Deck Builder and 4K Studio Art Hub"
                  title="Gemini Deck Builder & HD Art"
                  className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-200 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-amber-400" />
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    toggleMute();
                  }}
                  aria-label={muted ? 'Unmute Audio [M]' : 'Mute Audio [M]'}
                  title="Mute / Unmute [M]"
                  className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-200 cursor-pointer"
                >
                  {muted ? (
                    <VolumeX className="w-4 h-4 text-rose-400" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-emerald-400" />
                  )}
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    togglePause();
                  }}
                  aria-label="Pause Game [P]"
                  title="Pause [P / Esc]"
                  className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-200 cursor-pointer"
                >
                  <Pause className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    restartMatch();
                  }}
                  aria-label="Restart Match [R]"
                  title="Restart Match [R]"
                  className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hidden sm:flex items-center justify-center text-slate-200 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Animated Progress Bar with Dynamic Color Shifts (Green -> Amber -> Red) */}
            <div className="w-full h-1.5 rounded-full bg-slate-900 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${timerBarColor}`}
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>

          {/* 3-Column Desktop Workspace / Responsive Dual-Screen Layout */}
          <div className="flex-1 min-h-0 flex flex-col lg:flex-row gap-3 overflow-hidden">
            {/* Left Dock (240px on Desktop): Ranked Player Scoreboard & Modifiers */}
            {dualScreenMode !== 'stylus-pad' && (
              <div className="hidden lg:block w-[240px] shrink-0 h-full">
                <PlayerScoreboard
                  onOpenPairingModal={() => setPairingModalOpen(true)}
                />
              </div>
            )}

            {/* Center Canvas Viewport & Docked Artist Toolbar */}
            <div className="flex-1 min-w-0 h-full flex flex-col justify-between gap-2.5 overflow-hidden">
              <div className="flex-1 min-h-0 flex items-center justify-center overflow-hidden">
                <DrawingViewport
                  onExportCanvasDataUrl={(fn) => {
                    exportCanvasFnRef.current = fn;
                  }}
                />
              </div>

              {dualScreenMode !== 'tv-cast' && (
                <ArtistToolbar
                  onOpenGeminiModal={() => setGeminiModalOpen(true)}
                  onTriggerCritic={() => {
                    const dataUrl = exportCanvasFnRef.current
                      ? exportCanvasFnRef.current()
                      : undefined;
                    requestGeminiCritic(dataUrl);
                  }}
                />
              )}
            </div>

            {/* Right Dock (340px on Desktop): Real-Time Chat & Warm-Guess Stream */}
            {dualScreenMode !== 'tv-cast' && (
              <div className="hidden lg:block w-[340px] shrink-0 h-full">
                <ChatGuessStream />
              </div>
            )}

            {/* Mobile Compact Guess Ticker / Expandable Drawer */}
            <div className="lg:hidden shrink-0">
              {mobileChatExpanded ? (
                <div className="fixed inset-x-2 bottom-2 top-20 z-30 flex flex-col">
                  <div className="flex justify-end mb-1">
                    <button
                      type="button"
                      onClick={() => setMobileChatExpanded(false)}
                      className="px-3 py-1 rounded-lg bg-slate-800 text-xs font-bold text-white border border-slate-600"
                    >
                      Minimize Chat Drawer
                    </button>
                  </div>
                  <div className="flex-1 min-h-0">
                    <ChatGuessStream />
                  </div>
                </div>
              ) : (
                <div className="rounded-xl bg-[#1E293B] border border-slate-700 p-2 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setMobileChatExpanded(true)}
                    className="flex-1 text-left px-2.5 py-1.5 rounded-lg bg-slate-900 text-xs text-slate-300 flex items-center gap-2"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-violet-400 shrink-0" />
                    <span className="truncate">
                      Tap to open Guess Stream & test Warm Guess...
                    </span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </main>
      )}

      {/* Modals & Overlays */}
      <WordSelectionModal />
      <PairingAndDualScreenModal
        open={pairingModalOpen}
        onClose={() => setPairingModalOpen(false)}
      />
      <GeminiStudioHubModal
        open={geminiModalOpen}
        onClose={() => setGeminiModalOpen(false)}
      />
      <PauseAndGameOverModals />
    </div>
  );
}
