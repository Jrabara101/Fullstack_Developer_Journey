import React, { useState } from 'react';
import { STUDIO_PALETTE_16 } from '../game/rules';
import { useGameStore } from '../store/useGameStore';
import {
  Pencil,
  Eraser,
  PaintBucket,
  Trash2,
  Palette,
  Sparkles,
  FastForward,
  UserCheck,
} from 'lucide-react';

interface ArtistToolbarProps {
  onOpenGeminiModal: () => void;
  onTriggerCritic: () => void;
}

export const ArtistToolbar: React.FC<ArtistToolbarProps> = ({
  onOpenGeminiModal,
  onTriggerCritic,
}) => {
  const phase = useGameStore((s) => s.phase);
  const currentArtistId = useGameStore((s) => s.currentArtistId);
  const localPlayerId = useGameStore((s) => s.localPlayerId);
  const activeTool = useGameStore((s) => s.activeTool);
  const activeColor = useGameStore((s) => s.activeColor);
  const brushWidth = useGameStore((s) => s.brushWidth);
  const isAskingCritic = useGameStore((s) => s.isAskingCritic);

  const setTool = useGameStore((s) => s.setTool);
  const setColor = useGameStore((s) => s.setColor);
  const setBrushWidth = useGameStore((s) => s.setBrushWidth);
  const clearCanvas = useGameStore((s) => s.clearCanvas);
  const triggerRoundRecapNow = useGameStore((s) => s.triggerRoundRecapNow);
  const switchRoleToGuesserDemo = useGameStore((s) => s.switchRoleToGuesserDemo);
  const switchRoleToArtistDemo = useGameStore((s) => s.switchRoleToArtistDemo);

  const [paletteOpen, setPaletteOpen] = useState(false);
  const isLocalArtist = currentArtistId === localPlayerId;

  return (
    <div className="w-full rounded-xl bg-[#1E293B] border border-slate-700 px-3 py-2.5 shadow-xl flex flex-wrap items-center justify-between gap-2.5">
      {isLocalArtist ? (
        <>
          {/* Tool Toggle Group */}
          <div
            role="group"
            aria-label="Drawing Tools"
            className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800"
          >
            <button
              type="button"
              onClick={() => setTool('brush')}
              aria-label="Brush Tool"
              aria-pressed={activeTool === 'brush'}
              className={`px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTool === 'brush'
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Brush</span>
            </button>

            <button
              type="button"
              onClick={() => setTool('eraser')}
              aria-label="Eraser Tool"
              aria-pressed={activeTool === 'eraser'}
              className={`px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTool === 'eraser'
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Eraser className="w-3.5 h-3.5" />
              <span>Eraser</span>
            </button>

            <button
              type="button"
              onClick={() => setTool('fill')}
              aria-label="Bucket Fill Tool"
              aria-pressed={activeTool === 'fill'}
              className={`px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTool === 'fill'
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <PaintBucket className="w-3.5 h-3.5" />
              <span>Fill</span>
            </button>

            <button
              type="button"
              onClick={clearCanvas}
              aria-label="Clear Canvas"
              className="px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 text-rose-300 hover:text-white hover:bg-rose-600/80 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          </div>

          {/* 16-Color Swatch Strip & Popover */}
          <div className="relative flex items-center gap-1.5">
            <div className="hidden xl:flex items-center gap-1">
              {STUDIO_PALETTE_16.slice(0, 10).map((hex) => (
                <button
                  key={hex}
                  type="button"
                  onClick={() => setColor(hex)}
                  aria-label={`Select color ${hex}`}
                  className={`w-6 h-6 rounded-md border transition-transform cursor-pointer ${
                    activeColor === hex
                      ? 'scale-110 border-white ring-2 ring-violet-500'
                      : 'border-slate-600 hover:scale-105'
                  }`}
                  style={{ backgroundColor: hex }}
                />
              ))}
            </div>

            <button
              type="button"
              onClick={() => setPaletteOpen((v) => !v)}
              aria-label="Toggle 16-Color Swatch Picker"
              aria-expanded={paletteOpen}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
            >
              <span
                className="w-3.5 h-3.5 rounded-full border border-white/50"
                style={{ backgroundColor: activeColor }}
              />
              <Palette className="w-3.5 h-3.5 text-violet-400" />
              <span>16 Colors</span>
            </button>

            {paletteOpen && (
              <div className="absolute bottom-11 left-0 z-30 p-3 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl w-56">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-300">
                    Studio 16-Swatch Palette
                  </span>
                  <button
                    type="button"
                    onClick={() => setPaletteOpen(false)}
                    className="text-xs text-slate-400 hover:text-white cursor-pointer"
                  >
                    Close
                  </button>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {STUDIO_PALETTE_16.map((hex) => (
                    <button
                      key={hex}
                      type="button"
                      onClick={() => {
                        setColor(hex);
                        setPaletteOpen(false);
                      }}
                      aria-label={`Color swatch ${hex}`}
                      className={`h-8 rounded-lg border transition-transform cursor-pointer ${
                        activeColor === hex
                          ? 'border-white ring-2 ring-violet-500 scale-105'
                          : 'border-slate-700 hover:scale-105'
                      }`}
                      style={{ backgroundColor: hex }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Brush Size Slider */}
          <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
            <label
              htmlFor="brush-width-slider"
              className="text-xs font-medium text-slate-400 whitespace-nowrap"
            >
              Size: <span className="text-slate-100 font-mono-code">{brushWidth}px</span>
            </label>
            <input
              id="brush-width-slider"
              type="range"
              min={2}
              max={32}
              value={brushWidth}
              onChange={(e) => setBrushWidth(Number(e.target.value))}
              aria-label="Brush Width"
              className="w-20 accent-violet-500 cursor-pointer"
            />
          </div>
        </>
      ) : (
        <div className="flex items-center gap-2 text-xs text-slate-300">
          <span className="font-semibold text-emerald-400">
            Guesser Mode Active:
          </span>
          <span>
            Watch MiloSketch draw and type guesses in the chat dock on the right!
          </span>
        </div>
      )}

      {/* Right Action Utilities: Role Toggle, Gemini Studio Critic, Recap Trigger */}
      <div className="flex items-center gap-1.5 ml-auto">
        <button
          type="button"
          onClick={isLocalArtist ? switchRoleToGuesserDemo : switchRoleToArtistDemo}
          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>{isLocalArtist ? 'Switch to Guesser' : 'Switch to Artist'}</span>
        </button>

        <button
          type="button"
          onClick={onTriggerCritic}
          disabled={isAskingCritic}
          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-violet-300 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
          <span>{isAskingCritic ? 'Analyzing...' : 'AI Host Critique'}</span>
        </button>

        <button
          type="button"
          onClick={onOpenGeminiModal}
          className="px-2.5 py-1.5 rounded-lg bg-violet-600/20 hover:bg-violet-600/30 text-violet-200 border border-violet-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>AI Deck & HD Art</span>
        </button>

        {phase === 'DRAWING' && (
          <button
            type="button"
            onClick={triggerRoundRecapNow}
            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>3s Replay</span>
          </button>
        )}
      </div>
    </div>
  );
};
