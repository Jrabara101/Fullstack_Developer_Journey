import React, { useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import { useGameStore } from '../store/useGameStore';
import { Send, Flame, Lock, Sparkles, CheckCircle2 } from 'lucide-react';

export const ChatGuessStream: React.FC = () => {
  const messages = useGameStore((s) => s.messages);
  const players = useGameStore((s) => s.players);
  const localPlayerId = useGameStore((s) => s.localPlayerId);
  const actualWord = useGameStore((s) => s.actualWord);
  const aiHostComment = useGameStore((s) => s.aiHostComment);
  const submitGuessOrChat = useGameStore((s) => s.submitGuessOrChat);

  const [inputText, setInputText] = useState('');
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const localPlayer =
    players.find((p) => p.id === localPlayerId) || players[0];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length]);

  const triggerConfettiBurst = () => {
    try {
      confetti({
        particleCount: 55,
        spread: 65,
        origin: { y: 0.7 },
      });
    } catch {}
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed) return;

    const target = (actualWord || 'CAMPFIRE').toUpperCase();
    if (trimmed.toUpperCase() === target && !localPlayer.hasGuessedCorrectly) {
      triggerConfettiBurst();
    }

    submitGuessOrChat(trimmed);
    setInputText('');
  };

  // Compute a guaranteed 1-letter off near-miss for instant Warm Guess testing
  const targetWord = (actualWord || 'CAMPFIRE').toUpperCase();
  const warmSample =
    targetWord.length >= 3
      ? targetWord.slice(0, targetWord.length - 1)
      : `${targetWord}X`;

  return (
    <aside
      aria-label="Live Chat and Guess Stream"
      className="w-full h-full flex flex-col bg-[#1E293B] border border-slate-700 rounded-2xl overflow-hidden shadow-xl"
    >
      {/* Top Stream Header */}
      <div className="px-4 py-3 border-b border-slate-700 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-slate-100">
            Guess & Chat Stream
          </h2>
          <p className="text-xs text-slate-400">
            {localPlayer.hasGuessedCorrectly
              ? 'Spectator Channel Active · Answers hidden from late guessers'
              : 'Levenshtein Warm-Guess Engine Active'}
          </p>
        </div>
        {localPlayer.hasGuessedCorrectly && (
          <span className="flex items-center gap-1 text-xs font-semibold text-emerald-400">
            <Lock className="w-3.5 h-3.5" /> Secret Mode
          </span>
        )}
      </div>

      {/* Live AI Studio Host Ticker */}
      <div className="px-3.5 py-2 bg-slate-900/90 border-b border-slate-800 flex items-start gap-2">
        <Sparkles className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
        <p className="text-xs text-slate-300 leading-snug">
          <span className="font-semibold text-violet-300">Studio Host: </span>
          {aiHostComment}
        </p>
      </div>

      {/* Scrollable Messages Area */}
      <div
        ref={scrollRef}
        data-testid="chat-messages-list"
        className="flex-1 overflow-y-auto p-3.5 space-y-2"
      >
        {messages.map((m) => {
          if (m.channel === 'system') {
            return (
              <div
                key={m.id}
                className="px-3 py-2 rounded-lg bg-slate-900/80 border border-slate-800 text-xs text-slate-300"
              >
                <span className="font-bold text-violet-400">{m.senderName}</span>
                <span aria-hidden="true"> · </span>
                <span>{m.text}</span>
              </div>
            );
          }

          if (m.proximity === 'exact') {
            return (
              <div
                key={m.id}
                data-testid="message-exact-guess"
                className="px-3 py-2.5 rounded-lg bg-emerald-950/80 border border-emerald-500/50 text-xs text-emerald-200 flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="font-bold text-emerald-300">
                    CORRECT GUESS!
                  </span>{' '}
                  <span>{m.text}</span>
                </div>
              </div>
            );
          }

          if (m.channel === 'private-warm') {
            return (
              <div
                key={m.id}
                data-testid="message-warm-guess"
                className="px-3 py-2 rounded-lg bg-amber-950/80 border border-amber-500/50 text-xs text-amber-200 flex items-center gap-2"
              >
                <Flame className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="font-bold text-amber-300">WARM GUESS</span>
                  <span aria-hidden="true"> · </span>
                  <span>{m.text}</span>
                </div>
              </div>
            );
          }

          if (m.channel === 'spectator') {
            return (
              <div
                key={m.id}
                className="px-3 py-2 rounded-lg bg-emerald-950/40 border border-emerald-800/50 text-xs text-emerald-200"
              >
                <span className="font-semibold text-emerald-400">
                  [Spectator] {m.senderName}:
                </span>{' '}
                <span>{m.text}</span>
              </div>
            );
          }

          return (
            <div
              key={m.id}
              className="px-3 py-1.5 rounded-lg bg-slate-900/50 text-xs text-slate-200 flex items-baseline gap-1.5"
            >
              <span
                className="font-bold shrink-0"
                style={{ color: m.senderColor }}
              >
                {m.senderName}:
              </span>
              <span className="break-words">{m.text}</span>
            </div>
          );
        })}
      </div>

      {/* Instant Quick-Test Bar for Warm Guess & Asymmetric Guess Secrecy */}
      <div className="px-3 py-2 bg-slate-900/90 border-t border-slate-800 space-y-1">
        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block">
          Instant Proximity & Secrecy Test
        </span>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={() => submitGuessOrChat(warmSample)}
            className="px-2 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-[11px] font-semibold cursor-pointer truncate"
          >
            Warm Guess (&quot;{warmSample}&quot;)
          </button>
          <button
            type="button"
            onClick={() => {
              if (!localPlayer.hasGuessedCorrectly) {
                triggerConfettiBurst();
              }
              submitGuessOrChat(targetWord);
            }}
            className="px-2 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 text-[11px] font-semibold cursor-pointer truncate"
          >
            Exact (&quot;{targetWord}&quot;)
          </button>
        </div>
      </div>

      {/* Guess Input Form */}
      <form
        onSubmit={handleFormSubmit}
        className="p-3 bg-slate-900 border-t border-slate-700 flex items-center gap-2"
      >
        <label htmlFor="guess-chat-input" className="sr-only">
          Type your guess or chat message
        </label>
        <input
          id="guess-chat-input"
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={
            localPlayer.hasGuessedCorrectly
              ? 'Chat in secret Spectator channel...'
              : 'Type your guess here...'
          }
          className="flex-1 bg-slate-800 text-slate-100 placeholder-slate-400 text-xs font-medium px-3 py-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-violet-500"
        />
        <button
          type="submit"
          aria-label="Submit Guess"
          className="px-3.5 py-2.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <span>Guess</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </aside>
  );
};
