import React, { useEffect, useRef, useState } from 'react';
import { DrawStroke, StrokePoint } from '../game/types';
import { useGameStore } from '../store/useGameStore';
import { Play, RotateCcw, Sparkles, EyeOff, Activity } from 'lucide-react';

const LOGICAL_WIDTH = 1000;
const LOGICAL_HEIGHT = 625; // 16:10 responsive aspect ratio

function renderStrokeOnContext(
  ctx: CanvasRenderingContext2D,
  stroke: DrawStroke,
  alpha = 1,
  maxPointsCount?: number,
) {
  const pts =
    typeof maxPointsCount === 'number'
      ? stroke.points.slice(0, maxPointsCount)
      : stroke.points;
  if (pts.length === 0) return;

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.strokeStyle = stroke.color;
  ctx.fillStyle = stroke.color;
  ctx.lineWidth = stroke.width;

  if (pts.length === 1) {
    ctx.beginPath();
    ctx.arc(pts[0].x, pts[0].y, stroke.width / 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    return;
  }

  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length - 1; i++) {
    const midX = (pts[i].x + pts[i + 1].x) / 2;
    const midY = (pts[i].y + pts[i + 1].y) / 2;
    ctx.quadraticCurveTo(pts[i].x, pts[i].y, midX, midY);
  }
  const last = pts[pts.length - 1];
  ctx.lineTo(last.x, last.y);
  ctx.stroke();
  ctx.restore();
}

export const DrawingViewport: React.FC<{
  onExportCanvasDataUrl?: (fn: () => string) => void;
}> = ({ onExportCanvasDataUrl }) => {
  const committedCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const replayCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const phase = useGameStore((s) => s.phase);
  const timeLeft = useGameStore((s) => s.timeLeft);
  const currentArtistId = useGameStore((s) => s.currentArtistId);
  const localPlayerId = useGameStore((s) => s.localPlayerId);
  const strokes = useGameStore((s) => s.canvasState.strokes);
  const backgroundColor = useGameStore((s) => s.canvasState.backgroundColor);
  const activeLiveStroke = useGameStore((s) => s.activeLiveStroke);
  const activeTool = useGameStore((s) => s.activeTool);
  const activeColor = useGameStore((s) => s.activeColor);
  const brushWidth = useGameStore((s) => s.brushWidth);
  const modifiers = useGameStore((s) => s.modifiers);
  const paperShakeTrigger = useGameStore((s) => s.paperShakeTrigger);
  const actualWord = useGameStore((s) => s.actualWord);
  const round = useGameStore((s) => s.round);

  const startLiveStroke = useGameStore((s) => s.startLiveStroke);
  const appendLiveStroke = useGameStore((s) => s.appendLiveStroke);
  const commitLiveStroke = useGameStore((s) => s.commitLiveStroke);
  const floodFillCanvas = useGameStore((s) => s.floodFillCanvas);
  const advanceFromRecap = useGameStore((s) => s.advanceFromRecap);

  const isLocalArtist = currentArtistId === localPlayerId;
  const isDrawingRef = useRef(false);
  const cursorPosRef = useRef<{ x: number; y: number; visible: boolean }>({
    x: 500,
    y: 312,
    visible: false,
  });

  const [shakeClass, setShakeClass] = useState(false);
  const [replayProgress, setReplayProgress] = useState(100);
  const [replayNonce, setReplayNonce] = useState(0);

  // Trigger paper-shake CSS animation when canvas is cleared
  useEffect(() => {
    if (!paperShakeTrigger) return;
    setShakeClass(true);
    const timer = window.setTimeout(() => setShakeClass(false), 380);
    return () => clearTimeout(timer);
  }, [paperShakeTrigger]);

  // Expose canvas snapshot helper for Gemini Art Critic
  useEffect(() => {
    if (!onExportCanvasDataUrl) return;
    onExportCanvasDataUrl(() => {
      const c = committedCanvasRef.current;
      return c ? c.toDataURL('image/png') : '';
    });
  }, [onExportCanvasDataUrl]);

  // Clear active stroke on window blur so pointer state never sticks
  useEffect(() => {
    const handleBlur = () => {
      if (isDrawingRef.current) {
        isDrawingRef.current = false;
        commitLiveStroke();
      }
    };
    window.addEventListener('blur', handleBlur);
    return () => window.removeEventListener('blur', handleBlur);
  }, [commitLiveStroke]);

  // LAYER 1: Render static background & committed strokes (with Blindfold fade support)
  useEffect(() => {
    const canvas = committedCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;

    const drawCommittedLayer = () => {
      ctx.clearRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
      ctx.fillStyle = backgroundColor;
      ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);

      const now = Date.now();
      let needsNextFrame = false;

      for (const stroke of strokes) {
        let alpha = 1;
        if (modifiers.blindfold && isLocalArtist && phase === 'DRAWING') {
          const ageMs = now - stroke.timestamp;
          if (ageMs > 1200) {
            alpha = 0.05; // Nearly invisible to the blindfolded artist
          } else {
            alpha = Math.max(0.05, 1 - ageMs / 1200);
            needsNextFrame = true;
          }
        }
        renderStrokeOnContext(ctx, stroke, alpha);
      }

      if (needsNextFrame) {
        animId = requestAnimationFrame(drawCommittedLayer);
      }
    };

    drawCommittedLayer();
    return () => cancelAnimationFrame(animId);
  }, [strokes, backgroundColor, modifiers.blindfold, isLocalArtist, phase]);

  // LAYER 2: Render active stroke & glowing brush cursor
  const redrawOverlay = () => {
    const canvas = overlayCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);

    if (activeLiveStroke) {
      renderStrokeOnContext(ctx, activeLiveStroke, 1);
    }

    if (cursorPosRef.current.visible && isLocalArtist && phase === 'DRAWING') {
      const { x, y } = cursorPosRef.current;
      ctx.save();
      ctx.beginPath();
      ctx.arc(x, y, Math.max(4, brushWidth / 2), 0, Math.PI * 2);
      ctx.strokeStyle = activeTool === 'eraser' ? '#0F172A' : activeColor;
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(x, y, Math.max(6, brushWidth / 2 + 3), 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(139, 92, 246, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();
    }
  };

  useEffect(() => {
    redrawOverlay();
  });

  // 3-SECOND HIGH-SPEED VECTOR STROKE REPLAY TIMELAPSE (during ROUND_RECAP)
  useEffect(() => {
    if (phase !== 'ROUND_RECAP') return;
    const canvas = replayCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const totalPoints = strokes.reduce((acc, s) => acc + s.points.length, 0);
    const durationMs = 3000; // Exact 3-second high-speed vector replay
    const startTime = performance.now();
    let frameId = 0;

    const animateReplay = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / durationMs);
      setReplayProgress(Math.round(t * 100));

      ctx.clearRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
      ctx.fillStyle = backgroundColor;
      ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);

      let pointsBudget = Math.ceil(totalPoints * t);
      for (const stroke of strokes) {
        if (pointsBudget <= 0) break;
        const count = Math.min(stroke.points.length, pointsBudget);
        renderStrokeOnContext(ctx, stroke, 1, count);
        pointsBudget -= count;
      }

      if (t < 1) {
        frameId = requestAnimationFrame(animateReplay);
      }
    };

    frameId = requestAnimationFrame(animateReplay);
    return () => cancelAnimationFrame(frameId);
  }, [phase, strokes, backgroundColor, replayNonce]);

  const toLogicalCoords = (e: React.PointerEvent<HTMLCanvasElement>): StrokePoint => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / Math.max(1, rect.width)) * LOGICAL_WIDTH;
    const y = ((e.clientY - rect.top) / Math.max(1, rect.height)) * LOGICAL_HEIGHT;
    return {
      x: Math.max(0, Math.min(LOGICAL_WIDTH, Math.round(x * 10) / 10)),
      y: Math.max(0, Math.min(LOGICAL_HEIGHT, Math.round(y * 10) / 10)),
      pressure: e.pressure || 0.5,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isLocalArtist || phase !== 'DRAWING') return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const pt = toLogicalCoords(e);

    if (activeTool === 'fill') {
      floodFillCanvas(activeColor);
      return;
    }

    isDrawingRef.current = true;
    startLiveStroke(pt);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const pt = toLogicalCoords(e);
    cursorPosRef.current = { x: pt.x, y: pt.y, visible: true };
    if (isDrawingRef.current && isLocalArtist && phase === 'DRAWING') {
      appendLiveStroke(pt);
    } else {
      redrawOverlay();
    }
  };

  const handlePointerUpOrCancel = () => {
    if (isDrawingRef.current) {
      isDrawingRef.current = false;
      commitLiveStroke();
    }
  };

  const isTimeCrunch = phase === 'DRAWING' && timeLeft <= 15;

  return (
    <div
      className={`relative w-full aspect-[16/10] max-h-[calc(100vh-210px)] rounded-2xl overflow-hidden bg-white shadow-2xl transition-transform duration-150 select-none ${
        shakeClass ? 'animate-paper-shake' : ''
      } ${
        isTimeCrunch
          ? 'ring-4 ring-[#EF4444] shadow-[0_0_40px_rgba(239,68,68,0.45)]'
          : 'border-2 border-slate-700'
      }`}
    >
      {/* Layer 1: Static background and committed vector strokes */}
      <canvas
        ref={committedCanvasRef}
        width={LOGICAL_WIDTH}
        height={LOGICAL_HEIGHT}
        data-testid="drawing-canvas-committed"
        className="absolute inset-0 w-full h-full block pointer-events-none"
      />

      {/* Layer 2: Active live stroke overlay and glowing brush cursor */}
      <canvas
        ref={overlayCanvasRef}
        width={LOGICAL_WIDTH}
        height={LOGICAL_HEIGHT}
        data-testid="drawing-canvas-overlay"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUpOrCancel}
        onPointerCancel={handlePointerUpOrCancel}
        onPointerLeave={() => {
          cursorPosRef.current.visible = false;
          handlePointerUpOrCancel();
          redrawOverlay();
        }}
        className={`absolute inset-0 w-full h-full block touch-none ${
          isLocalArtist && phase === 'DRAWING' ? 'cursor-crosshair' : 'cursor-default'
        }`}
      />

      {/* Dynamic Time-Crunch Vignette (< 15 seconds) */}
      {isTimeCrunch && (
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none border-[10px] border-red-500/35 rounded-2xl"
        />
      )}

      {/* Active Party Modifier Subtle Top-Left Notice on Canvas */}
      {(modifiers.blindfold || modifiers.oneLineOnly || modifiers.speedBlitz) &&
        phase === 'DRAWING' && (
          <div className="absolute top-3 left-3 pointer-events-none flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900/90 text-xs font-medium text-slate-200 border border-slate-700">
            {modifiers.blindfold && (
              <span className="flex items-center gap-1 text-amber-400">
                <EyeOff className="w-3.5 h-3.5" /> Blindfold Ink (1.2s Fade)
              </span>
            )}
            {modifiers.oneLineOnly && (
              <span className="flex items-center gap-1 text-violet-400">
                <Activity className="w-3.5 h-3.5" /> One-Line Only
              </span>
            )}
            {modifiers.speedBlitz && (
              <span className="flex items-center gap-1 text-emerald-400">
                <Sparkles className="w-3.5 h-3.5" /> 1.5x Speed Blitz
              </span>
            )}
          </div>
        )}

      {/* 3-Second High-Speed Vector Replay & Round Timelapse Overlay (ROUND_RECAP) */}
      {phase === 'ROUND_RECAP' && (
        <div className="absolute inset-0 z-20 bg-slate-950/95 flex flex-col justify-between p-4 md:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-violet-400">
                Round {round.current} Timelapse Recap · 3-Second Vector Replay
              </p>
              <h2 className="text-xl md:text-2xl font-extrabold text-white mt-0.5">
                The Word Was:{' '}
                <span className="text-emerald-400 font-mono-code tracking-wider">
                  {actualWord}
                </span>
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setReplayNonce((n) => n + 1)}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Replay 3s Sketch ({replayProgress}%)
              </button>
              <button
                type="button"
                onClick={advanceFromRecap}
                className="px-4 py-2 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Play className="w-3.5 h-3.5" />
                {round.current >= round.total ? 'View Match Podium' : 'Start Next Round'}
              </button>
            </div>
          </div>

          <div className="relative flex-1 my-3 rounded-xl overflow-hidden border border-slate-700 bg-white">
            <canvas
              ref={replayCanvasRef}
              width={LOGICAL_WIDTH}
              height={LOGICAL_HEIGHT}
              data-testid="replay-timelapse-canvas"
              className="w-full h-full object-contain block"
            />
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>
              Replaying {strokes.length} Catmull-Rom vector strokes at 10x speed
            </span>
            <span className="font-mono-code text-emerald-400">
              TIMELAPSE PROGRESS: {replayProgress}%
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
