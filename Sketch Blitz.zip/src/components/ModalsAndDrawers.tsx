import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useGameStore } from '../store/useGameStore';
import { DualScreenMode, ImageSizeOption } from '../game/types';
import {
  Sparkles,
  X,
  Tv,
  Smartphone,
  Monitor,
  Play,
  RotateCcw,
  Home,
  Trophy,
  Wand2,
  Image as ImageIcon,
  Check,
} from 'lucide-react';

export const WordSelectionModal: React.FC = () => {
  const phase = useGameStore((s) => s.phase);
  const shellState = useGameStore((s) => s.shellState);
  const timeLeft = useGameStore((s) => s.timeLeft);
  const round = useGameStore((s) => s.round);
  const wordChoices = useGameStore((s) => s.wordChoices);
  const customDeckName = useGameStore((s) => s.customDeckName);
  const selectWord = useGameStore((s) => s.selectWord);
  const switchRoleToGuesserDemo = useGameStore((s) => s.switchRoleToGuesserDemo);

  if (shellState !== 'playing' || phase !== 'WORD_SELECTION' || !wordChoices) {
    return null;
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="word-select-heading"
      className="fixed inset-0 z-30 bg-slate-950/85 flex items-center justify-center p-4"
    >
      <div className="w-full max-w-xl rounded-2xl bg-[#1E293B] border border-slate-700 p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-xs font-semibold text-violet-400 uppercase tracking-wider">
              Round {round.current} of {round.total} · {customDeckName}
            </p>
            <h2
              id="word-select-heading"
              className="text-xl font-extrabold text-white mt-0.5"
            >
              Choose Your Secret Word to Sketch
            </h2>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-right">
            <span className="text-[10px] text-slate-400 block">AUTO-PICK</span>
            <span className="text-base font-extrabold text-amber-400 font-mono-code tabular-nums">
              {timeLeft}s
            </span>
          </div>
        </div>

        <p className="text-xs text-slate-300 mb-5">
          Higher difficulty tiers grant larger score multipliers when players
          deduce your sketch!
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
          {wordChoices.map((option) => {
            const tierColor =
              option.difficulty === 'Hard'
                ? 'border-rose-500/50 hover:border-rose-400 bg-rose-950/30'
                : option.difficulty === 'Medium'
                  ? 'border-amber-500/50 hover:border-amber-400 bg-amber-950/30'
                  : 'border-emerald-500/50 hover:border-emerald-400 bg-emerald-950/30';

            const ptsColor =
              option.difficulty === 'Hard'
                ? 'text-rose-300'
                : option.difficulty === 'Medium'
                  ? 'text-amber-300'
                  : 'text-emerald-300';

            return (
              <button
                key={option.word}
                type="button"
                onClick={() => selectWord(option)}
                className={`p-4 rounded-xl border-2 text-left transition-all hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between ${tierColor}`}
              >
                <div>
                  <span
                    className={`text-xs font-bold uppercase tracking-wider ${ptsColor}`}
                  >
                    {option.difficulty} · +{option.points} PTS
                  </span>
                  <span className="text-lg font-extrabold text-white font-mono-code block mt-2 break-words">
                    {option.word}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 mt-3 block">
                  {option.word.length} letters · Click to Draw
                </span>
              </button>
            );
          })}
        </div>

        <div className="pt-3 border-t border-slate-700 flex items-center justify-between text-xs text-slate-400">
          <span>Want to guess instead of drawing this turn?</span>
          <button
            type="button"
            onClick={switchRoleToGuesserDemo}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 font-semibold border border-slate-600 cursor-pointer whitespace-nowrap"
          >
            Let MiloSketch Draw (Play as Guesser)
          </button>
        </div>
      </div>
    </div>
  );
};

export const PairingAndDualScreenModal: React.FC<{
  open: boolean;
  onClose: () => void;
}> = ({ open, onClose }) => {
  const roomId = useGameStore((s) => s.roomId);
  const dualScreenMode = useGameStore((s) => s.dualScreenMode);
  const setDualScreenMode = useGameStore((s) => s.setDualScreenMode);
  const setRoomId = useGameStore((s) => s.setRoomId);
  const [copied, setCopied] = useState(false);

  if (!open) return null;

  const joinUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/?room=${roomId}&autostart=1`
      : `https://sketchblitz.studio/?room=${roomId}`;

  const handleCopy = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(joinUrl).catch(() => {});
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const modes: Array<{
    id: DualScreenMode;
    title: string;
    desc: string;
    icon: React.ReactNode;
  }> = [
    {
      id: 'standard',
      title: 'Standard 3-Column Studio',
      desc: 'Full scoreboard, drawing canvas, and live guess stream.',
      icon: <Monitor className="w-4 h-4 text-violet-400" />,
    },
    {
      id: 'tv-cast',
      title: 'Living Room TV Cast View',
      desc: 'Maximized cinema canvas & scoreboard for big-screen party display.',
      icon: <Tv className="w-4 h-4 text-emerald-400" />,
    },
    {
      id: 'stylus-pad',
      title: 'Mobile Touch Stylus Pad',
      desc: 'Focused touch drawing pad & quick-guess bar for handheld devices.',
      icon: <Smartphone className="w-4 h-4 text-amber-400" />,
    },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="pairing-modal-title"
      className="fixed inset-0 z-40 bg-slate-950/85 flex items-center justify-center p-4"
    >
      <div className="w-full max-w-lg rounded-2xl bg-[#1E293B] border border-slate-700 p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-700">
          <div>
            <h2
              id="pairing-modal-title"
              className="text-lg font-extrabold text-white"
            >
              Frictionless Room Pairing & Dual-Screen Mode
            </h2>
            <p className="text-xs text-slate-400">
              Scan QR with your phone or enter the 4-character Room Code
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Pairing Modal"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center mb-5">
          <div className="p-4 rounded-xl bg-white flex flex-col items-center justify-center">
            <QRCodeSVG value={joinUrl} size={136} level="M" />
            <span className="text-[11px] font-mono-code font-bold text-slate-800 mt-2">
              SCAN TO PAIR STYLUS
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <label
                htmlFor="modal-room-code-input"
                className="text-xs font-semibold text-slate-400 block mb-1"
              >
                Active 4-Character Room Code
              </label>
              <input
                id="modal-room-code-input"
                type="text"
                value={roomId}
                maxLength={4}
                onChange={(e) => setRoomId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xl font-mono-code font-extrabold text-amber-400 tracking-widest uppercase"
              />
            </div>

            <button
              type="button"
              onClick={handleCopy}
              className="w-full py-2 px-3 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Copied Invite Link!</span>
                </>
              ) : (
                <span>Copy Instant Join URL</span>
              )}
            </button>
          </div>
        </div>

        <div>
          <span className="text-xs font-bold text-slate-300 block mb-2">
            Select Viewport Ergonomics (Dual-Screen Support)
          </span>
          <div className="space-y-2">
            {modes.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setDualScreenMode(m.id);
                  onClose();
                }}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-colors cursor-pointer ${
                  dualScreenMode === m.id
                    ? 'bg-violet-600/20 border-violet-500 text-white'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  {m.icon}
                  <div>
                    <div className="text-xs font-bold">{m.title}</div>
                    <div className="text-[11px] text-slate-400">{m.desc}</div>
                  </div>
                </div>
                <span className="text-xs font-mono-code text-violet-300">
                  {dualScreenMode === m.id ? 'ACTIVE' : 'SELECT'}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export const GeminiStudioHubModal: React.FC<{
  open: boolean;
  onClose: () => void;
}> = ({ open, onClose }) => {
  const customDeckName = useGameStore((s) => s.customDeckName);
  const customWordsCount = useGameStore((s) => s.customWordsCount);
  const isGeneratingDeck = useGameStore((s) => s.isGeneratingDeck);
  const isGeneratingArt = useGameStore((s) => s.isGeneratingArt);
  const studioArtGallery = useGameStore((s) => s.studioArtGallery);

  const importCustomDeck = useGameStore((s) => s.importCustomDeck);
  const generateGeminiDeck = useGameStore((s) => s.generateGeminiDeck);
  const generateGeminiStudioArt = useGameStore((s) => s.generateGeminiStudioArt);

  const [pasteWords, setPasteWords] = useState(
    'COFFEE SPILL, MONDAY MEETING, KARAOKE KING, WI-FI DROPPED, PIZZA HEIST',
  );
  const [deckTheme, setDeckTheme] = useState('90s Saturday Morning Cartoons');
  const [artPrompt, setArtPrompt] = useState(
    'Golden neon sketch trophy surrounded by colorful paint splashes in a cozy playroom studio',
  );
  const [imageSize, setImageSize] = useState<ImageSizeOption>('1K');

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="gemini-hub-title"
      className="fixed inset-0 z-40 bg-slate-950/85 flex items-center justify-center p-4 overflow-y-auto"
    >
      <div className="w-full max-w-2xl rounded-2xl bg-[#1E293B] border border-slate-700 p-6 shadow-2xl my-auto max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <div>
              <h2
                id="gemini-hub-title"
                className="text-lg font-extrabold text-white"
              >
                Inside-Joke Deck Builder & Gemini Studio Hub
              </h2>
              <p className="text-xs text-slate-400">
                Active Deck: {customDeckName} ({customWordsCount} words)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Studio Hub Modal"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Column 1: Inside-Joke Paste & Gemini 4 Argon Deck Architect */}
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-violet-300">
                <Wand2 className="w-4 h-4" />
                <span>Gemini 4 Argon Theme Deck Generator</span>
              </div>
              <label
                htmlFor="gemini-theme-input"
                className="block text-[11px] text-slate-400"
              >
                Enter any party theme or fandom to generate tiered words:
              </label>
              <input
                id="gemini-theme-input"
                type="text"
                value={deckTheme}
                onChange={(e) => setDeckTheme(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
              />
              <button
                type="button"
                disabled={isGeneratingDeck}
                onClick={() => generateGeminiDeck(deckTheme)}
                className="w-full py-2 px-3 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer"
              >
                {isGeneratingDeck
                  ? 'Generating Tiered Word Pack...'
                  : 'Generate AI Word Deck'}
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
              <div className="text-xs font-bold text-emerald-300">
                One-Click Paste Inside-Joke Deck
              </div>
              <label
                htmlFor="custom-paste-textarea"
                className="block text-[11px] text-slate-400"
              >
                Paste comma or newline separated inside jokes:
              </label>
              <textarea
                id="custom-paste-textarea"
                rows={3}
                value={pasteWords}
                onChange={(e) => setPasteWords(e.target.value)}
                className="w-full p-2.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white font-mono-code"
              />
              <button
                type="button"
                onClick={() =>
                  importCustomDeck(pasteWords, 'Inside-Joke Party Pack')
                }
                className="w-full py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
              >
                Import Custom Inside-Joke Deck
              </button>
            </div>
          </div>

          {/* Column 2: Gemini 3 Pro Image Generator (1K, 2K, 4K) */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-3">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
                  <ImageIcon className="w-4 h-4" />
                  <span>Gemini 3 Pro Image Studio Card</span>
                </span>
                <span className="text-[11px] font-mono-code text-slate-400">
                  {imageSize} RES
                </span>
              </div>

              <label
                htmlFor="studio-art-prompt"
                className="block text-[11px] text-slate-400"
              >
                Generate a reference card, trophy poster, or custom avatar:
              </label>
              <textarea
                id="studio-art-prompt"
                rows={2}
                value={artPrompt}
                onChange={(e) => setArtPrompt(e.target.value)}
                className="w-full p-2.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
              />

              {/* Resolution Size Selector (1K, 2K, 4K) */}
              <div>
                <span className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Select Target Resolution Size:
                </span>
                <div
                  role="group"
                  aria-label="Image Resolution Size"
                  className="grid grid-cols-3 gap-2"
                >
                  {(['1K', '2K', '4K'] as ImageSizeOption[]).map((sz) => (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setImageSize(sz)}
                      aria-pressed={imageSize === sz}
                      className={`py-1.5 rounded-lg border text-xs font-mono-code font-bold cursor-pointer ${
                        imageSize === sz
                          ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                disabled={isGeneratingArt}
                onClick={() => generateGeminiStudioArt(artPrompt, imageSize)}
                className="w-full py-2.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold cursor-pointer"
              >
                {isGeneratingArt
                  ? `Rendering ${imageSize} Studio Card...`
                  : `Generate ${imageSize} Studio Art`}
              </button>
            </div>

            {/* Generated Art Preview Slot (with Zero-Broken-Image guarantee) */}
            <div className="pt-2 border-t border-slate-800">
              {studioArtGallery.length > 0 ? (
                <div className="space-y-1.5">
                  <div className="relative rounded-lg overflow-hidden border border-slate-700 bg-slate-950 aspect-video">
                    <img
                      src={studioArtGallery[0].imageUrl}
                      alt={studioArtGallery[0].prompt}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-slate-900/90 text-[10px] font-mono-code text-amber-300 border border-slate-700">
                      {studioArtGallery[0].imageSize} ·{' '}
                      {studioArtGallery[0].modelUsed}
                    </span>
                  </div>
                  {studioArtGallery[0].note && (
                    <p className="text-[11px] text-slate-400 leading-tight">
                      {studioArtGallery[0].note}
                    </p>
                  )}
                </div>
              ) : (
                <div className="rounded-lg border border-dashed border-slate-700 p-4 text-center text-xs text-slate-400">
                  Choose 1K, 2K, or 4K above and click Generate to create a
                  custom Studio Reference Card.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const PauseAndGameOverModals: React.FC = () => {
  const shellState = useGameStore((s) => s.shellState);
  const round = useGameStore((s) => s.round);
  const players = useGameStore((s) => s.players);
  const roundHistory = useGameStore((s) => s.roundHistory);
  const togglePause = useGameStore((s) => s.togglePause);
  const restartMatch = useGameStore((s) => s.restartMatch);
  const setShellState = useGameStore((s) => s.setShellState);

  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
  const winner = sortedPlayers[0] || players[0];

  if (shellState === 'paused') {
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="pause-modal-title"
        className="fixed inset-0 z-50 bg-slate-950/85 flex items-center justify-center p-4"
      >
        <div className="w-full max-w-md rounded-2xl bg-[#1E293B] border border-slate-700 p-6 shadow-2xl text-center space-y-5">
          <div>
            <p className="text-xs font-mono-code text-violet-400 uppercase tracking-widest">
              STUDIO PAUSED
            </p>
            <h2
              id="pause-modal-title"
              className="text-2xl font-extrabold text-white mt-1"
            >
              Match Paused
            </h2>
          </div>

          <div className="grid grid-cols-3 gap-2.5 text-center">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">ROUND</span>
              <span className="text-lg font-extrabold text-white font-mono-code tabular-nums">
                {round.current}/{round.total}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">LEADER</span>
              <span className="text-sm font-bold text-emerald-400 truncate block mt-0.5">
                {winner.username}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">TOP SCORE</span>
              <span className="text-lg font-extrabold text-amber-400 font-mono-code tabular-nums">
                {Math.round(winner.score)}
              </span>
            </div>
          </div>

          <div className="space-y-2.5">
            <button
              type="button"
              onClick={togglePause}
              className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Resume Match (Esc / P)</span>
            </button>
            <button
              type="button"
              onClick={restartMatch}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 border border-slate-700 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Restart Match</span>
            </button>
            <button
              type="button"
              onClick={() => setShellState('title')}
              className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Return to Title Screen</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (shellState === 'gameover') {
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="podium-modal-title"
        className="fixed inset-0 z-50 bg-slate-950/75 flex items-center justify-center p-4"
      >
        <div className="w-full max-w-lg rounded-2xl bg-[#1E293B] border border-slate-700 p-6 shadow-2xl space-y-5">
          <div className="text-center">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center mx-auto mb-2 text-amber-300">
              <Trophy className="w-6 h-6" />
            </div>
            <p className="text-xs font-mono-code text-amber-400 uppercase tracking-widest">
              MATCH PODIUM · 3 ROUNDS COMPLETE
            </p>
            <h2
              id="podium-modal-title"
              className="text-2xl font-extrabold text-white mt-1"
            >
              Champion: {winner.username}
            </h2>
          </div>

          {/* Mastery Metrics */}
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">
                WINNING SCORE
              </span>
              <span className="text-xl font-extrabold text-emerald-400 font-mono-code tabular-nums">
                {Math.round(winner.score)}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">
                ROUNDS PLAYED
              </span>
              <span className="text-xl font-extrabold text-white font-mono-code tabular-nums">
                {round.total}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">
                SKETCHES SAVED
              </span>
              <span className="text-xl font-extrabold text-violet-400 font-mono-code tabular-nums">
                {Math.max(1, roundHistory.length)}
              </span>
            </div>
          </div>

          {/* Final Standings Table */}
          <div className="space-y-2">
            {sortedPlayers.map((p, idx) => (
              <div
                key={p.id}
                className="px-3.5 py-2.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xs font-mono-code font-bold text-slate-400">
                    #{idx + 1}
                  </span>
                  <span className="text-sm font-bold text-white">
                    {p.username}
                  </span>
                </div>
                <span className="text-sm font-mono-code font-extrabold text-amber-400 tabular-nums">
                  {Math.round(p.score)} PTS
                </span>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              data-start="true"
              onClick={restartMatch}
              className="flex-1 py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Play Again</span>
            </button>
            <button
              type="button"
              onClick={() => setShellState('title')}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs cursor-pointer"
            >
              Title Screen
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
