import React from 'react';
import { useGameStore } from '../store/useGameStore';
import {
  Pencil,
  Check,
  Crown,
  EyeOff,
  Activity,
  Zap,
  QrCode,
} from 'lucide-react';

interface PlayerScoreboardProps {
  onOpenPairingModal: () => void;
}

export const PlayerScoreboard: React.FC<PlayerScoreboardProps> = ({
  onOpenPairingModal,
}) => {
  const roomId = useGameStore((s) => s.roomId);
  const players = useGameStore((s) => s.players);
  const currentArtistId = useGameStore((s) => s.currentArtistId);
  const modifiers = useGameStore((s) => s.modifiers);
  const customDeckName = useGameStore((s) => s.customDeckName);
  const lastFloatingScore = useGameStore((s) => s.lastFloatingScore);
  const toggleModifier = useGameStore((s) => s.toggleModifier);

  // Sort players by score descending
  const rankedPlayers = [...players].sort((a, b) => b.score - a.score);

  return (
    <aside
      aria-label="Scoreboard and Party Modifiers"
      className="w-full h-full flex flex-col justify-between bg-[#1E293B] border border-slate-700 rounded-2xl p-3.5 shadow-xl overflow-y-auto"
    >
      <div>
        {/* Room Code & Dual-Screen Pairing Trigger */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-700">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Room Code
            </span>
            <span className="text-lg font-extrabold text-white font-mono-code tracking-widest">
              {roomId}
            </span>
          </div>
          <button
            type="button"
            onClick={onOpenPairingModal}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <QrCode className="w-3.5 h-3.5 text-violet-400" />
            <span>Pair / Cast</span>
          </button>
        </div>

        {/* Ranked Players List */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold text-slate-300">Lobby Standings</span>
            <span className="tabular-nums">{players.length} Players</span>
          </div>

          <div className="space-y-2">
            {rankedPlayers.map((player, index) => {
              const isArtist = player.id === currentArtistId;
              const showFloat =
                lastFloatingScore && lastFloatingScore.playerId === player.id;

              return (
                <div
                  key={player.id}
                  className={`relative p-2.5 rounded-xl border transition-colors flex items-center justify-between gap-2 ${
                    player.hasGuessedCorrectly
                      ? 'bg-emerald-950/40 border-emerald-500/50'
                      : isArtist
                        ? 'bg-violet-950/40 border-violet-500/60'
                        : 'bg-slate-900/70 border-slate-800'
                  }`}
                >
                  {/* Floating Score Delta Animation (+250) */}
                  {showFloat && (
                    <span
                      key={lastFloatingScore.key}
                      className="animate-float-score absolute -top-2 right-3 z-20 px-2 py-0.5 rounded bg-emerald-500 text-slate-950 font-mono-code font-extrabold text-xs shadow-lg pointer-events-none"
                    >
                      +{lastFloatingScore.delta}
                    </span>
                  )}

                  <div className="flex items-center gap-2.5 min-w-0">
                    {/* Custom SVG Avatar */}
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 font-bold text-white text-xs relative shadow-inner"
                      style={{ backgroundColor: player.avatarColor }}
                    >
                      <span>{player.username.slice(0, 2).toUpperCase()}</span>
                      {index === 0 && player.score > 0 && (
                        <Crown className="w-3.5 h-3.5 text-amber-300 absolute -top-1.5 -right-1.5 drop-shadow" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-slate-100 truncate">
                          {player.username}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1">
                        <span>#{index + 1}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {isArtist
                            ? 'Drawing'
                            : player.hasGuessedCorrectly
                              ? 'Guessed!'
                              : `${player.pingMs}ms`}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Status Icon & Tabular Score */}
                  <div className="flex items-center gap-2 shrink-0">
                    {player.hasGuessedCorrectly ? (
                      <span
                        title="Guessed Correctly"
                        className="w-6 h-6 rounded-lg bg-emerald-500/30 border border-emerald-400/50 flex items-center justify-center text-emerald-300"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    ) : isArtist ? (
                      <span
                        title="Current Artist"
                        className="w-6 h-6 rounded-lg bg-violet-600/30 border border-violet-500/50 flex items-center justify-center text-violet-300"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </span>
                    ) : null}
                    <div className="text-right">
                      <span
                        data-testid={`player-score-${player.id}`}
                        className="text-sm font-extrabold text-white font-mono-code tabular-nums block"
                      >
                        {Math.round(player.score)}
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        PTS
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Host-Toggled Party Modifiers & Active Deck Info */}
      <div className="pt-3 border-t border-slate-700 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-200">
            Party Modifiers
          </span>
          <span className="text-[11px] text-slate-400 truncate max-w-[110px]">
            {customDeckName}
          </span>
        </div>

        <div className="space-y-1.5">
          <button
            type="button"
            onClick={() => toggleModifier('blindfold')}
            aria-pressed={modifiers.blindfold}
            className={`w-full px-2.5 py-2 rounded-lg border text-left text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
              modifiers.blindfold
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-200'
                : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <EyeOff className="w-3.5 h-3.5 text-amber-400" />
              <span>Blindfold Ink (1s Fade)</span>
            </span>
            <span className="font-mono-code text-[11px]">
              {modifiers.blindfold ? 'ON' : 'OFF'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => toggleModifier('oneLineOnly')}
            aria-pressed={modifiers.oneLineOnly}
            className={`w-full px-2.5 py-2 rounded-lg border text-left text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
              modifiers.oneLineOnly
                ? 'bg-violet-500/20 border-violet-500/50 text-violet-200'
                : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-violet-400" />
              <span>One-Line Only</span>
            </span>
            <span className="font-mono-code text-[11px]">
              {modifiers.oneLineOnly ? 'ON' : 'OFF'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => toggleModifier('speedBlitz')}
            aria-pressed={modifiers.speedBlitz}
            className={`w-full px-2.5 py-2 rounded-lg border text-left text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
              modifiers.speedBlitz
                ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-200'
                : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              <span>Speed Blitz (1.5x)</span>
            </span>
            <span className="font-mono-code text-[11px]">
              {modifiers.speedBlitz ? 'ON' : 'OFF'}
            </span>
          </button>
        </div>
      </div>
    </aside>
  );
};
