import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { ShellState } from '../game/types';

interface ThreeStudioStageProps {
  shellState: ShellState;
}

// Pre-allocated math helpers at module scope (Zero GC inside render loop)
const _targetCamPos = new THREE.Vector3();
const _targetLookAt = new THREE.Vector3();
const _currentLookAt = new THREE.Vector3(0, 1.4, 0);
const _dummyObj = new THREE.Object3D();
const _colorHelper = new THREE.Color();

function createProceduralWoodBumpTexture(renderer: THREE.WebGLRenderer): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 40; i++) {
    ctx.fillStyle = i % 2 === 0 ? '#969696' : '#6a6a6a';
    ctx.fillRect(0, (i * 3.2) % 128, 128, 1.5);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return tex;
}

function createStudioCanvasArtTexture(renderer: THREE.WebGLRenderer): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, 512, 320);

  // Subtle grid lines
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  for (let x = 32; x < 512; x += 32) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 320);
    ctx.stroke();
  }
  for (let y = 32; y < 320; y += 32) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  // Playful vector sketch on the 3D studio easel
  ctx.strokeStyle = '#8B5CF6';
  ctx.lineWidth = 10;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(90, 240);
  ctx.lineTo(190, 110);
  ctx.lineTo(275, 210);
  ctx.lineTo(355, 120);
  ctx.lineTo(430, 240);
  ctx.stroke();

  // Warm sun circle
  ctx.fillStyle = '#F59E0B';
  ctx.beginPath();
  ctx.arc(265, 95, 34, 0, Math.PI * 2);
  ctx.fill();

  // Emerald wave
  ctx.strokeStyle = '#10B981';
  ctx.lineWidth = 9;
  ctx.beginPath();
  ctx.moveTo(75, 268);
  ctx.quadraticCurveTo(256, 238, 435, 268);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return tex;
}

export const ThreeStudioStage: React.FC<ThreeStudioStageProps> = ({ shellState }) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const shellStateRef = useRef<ShellState>(shellState);

  useEffect(() => {
    shellStateRef.current = shellState;
  }, [shellState]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Software WebGL detection per threejs skill
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const bgHex = 0x0f172a;
    scene.background = new THREE.Color(bgHex);
    scene.fog = new THREE.FogExp2(bgHex, 0.032);

    // Studio Environment Reflection (RoomEnvironment + PMREMGenerator)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      45,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.1,
      100,
    );
    camera.position.set(-2.4, 2.5, 7.2);
    camera.lookAt(0.8, 1.4, 0);

    // Warm/Cool Studio Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.85);
    hemiLight.position.set(0, 15, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1d6, 2.2);
    keyLight.position.set(6, 10, 7);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    const d = 8;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 25;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x8b5cf6, 1.4);
    rimLight.position.set(-6, 5, -5);
    scene.add(rimLight);

    const woodBump = createProceduralWoodBumpTexture(renderer);
    const canvasArtTex = createStudioCanvasArtTexture(renderer);

    // Studio Floor with subtle circular stage platform (offset on Y to prevent Z-fighting)
    const floorGeo = new THREE.PlaneGeometry(60, 60);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.85,
      metalness: 0.1,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    const stageDiscGeo = new THREE.CylinderGeometry(4.6, 4.8, 0.12, 48);
    const stageDiscMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.5,
      metalness: 0.25,
    });
    const stageDisc = new THREE.Mesh(stageDiscGeo, stageDiscMat);
    stageDisc.position.set(1.2, 0.06, 0);
    stageDisc.receiveShadow = true;
    scene.add(stageDisc);

    // Contact shadow helper
    const shadowDiscGeo = new THREE.CircleGeometry(1.5, 32);
    const shadowDiscMat = new THREE.MeshBasicMaterial({
      color: 0x020617,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });

    // COMPOSITE MODEL 1: 8-Part Studio Easel & Framed Canvas Hero Subject (pivoted at bottom-center)
    const easelGroup = new THREE.Group();
    easelGroup.position.set(1.35, 0.12, 0.2);

    const easelContactShadow = new THREE.Mesh(shadowDiscGeo, shadowDiscMat);
    easelContactShadow.rotation.x = -Math.PI / 2;
    easelContactShadow.position.y = 0.015;
    easelGroup.add(easelContactShadow);

    const oakMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.65,
      metalness: 0.1,
      bumpMap: woodBump,
      bumpScale: 0.015,
    });
    const trimGoldMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.25,
      metalness: 0.85,
    });
    const boardMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: canvasArtTex,
      roughness: 0.35,
      metalness: 0.05,
    });

    // Left, Right, Back Tripod Legs
    const legGeo = new THREE.CylinderGeometry(0.055, 0.045, 2.9, 16);
    const leftLeg = new THREE.Mesh(legGeo, oakMat);
    leftLeg.position.set(-0.75, 1.4, 0.2);
    leftLeg.rotation.z = -0.14;
    leftLeg.rotation.x = -0.08;
    leftLeg.castShadow = true;
    easelGroup.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, oakMat);
    rightLeg.position.set(0.75, 1.4, 0.2);
    rightLeg.rotation.z = 0.14;
    rightLeg.rotation.x = -0.08;
    rightLeg.castShadow = true;
    easelGroup.add(rightLeg);

    const backLeg = new THREE.Mesh(legGeo, oakMat);
    backLeg.position.set(0, 1.35, -0.65);
    backLeg.rotation.x = 0.32;
    backLeg.castShadow = true;
    easelGroup.add(backLeg);

    // Horizontal Shelf Ledge
    const shelfGeo = new THREE.BoxGeometry(2.3, 0.11, 0.26);
    const shelfMesh = new THREE.Mesh(shelfGeo, oakMat);
    shelfMesh.position.set(0, 1.05, 0.32);
    shelfMesh.castShadow = true;
    easelGroup.add(shelfMesh);

    // Canvas Backing Frame
    const frameGeo = new THREE.BoxGeometry(2.28, 1.52, 0.09);
    const frameMesh = new THREE.Mesh(frameGeo, trimGoldMat);
    frameMesh.position.set(0, 1.85, 0.24);
    frameMesh.rotation.x = -0.08;
    frameMesh.castShadow = true;
    easelGroup.add(frameMesh);

    // Canvas Art Surface
    const artBoardGeo = new THREE.BoxGeometry(2.14, 1.38, 0.04);
    const artBoardMesh = new THREE.Mesh(artBoardGeo, boardMat);
    artBoardMesh.position.set(0, 1.85, 0.29);
    artBoardMesh.rotation.x = -0.08;
    easelGroup.add(artBoardMesh);

    // Top Clamp Finial
    const clampGeo = new THREE.BoxGeometry(0.28, 0.18, 0.18);
    const clampMesh = new THREE.Mesh(clampGeo, trimGoldMat);
    clampMesh.position.set(0, 2.66, 0.18);
    easelGroup.add(clampMesh);

    scene.add(easelGroup);

    // COMPOSITE MODEL 2: 6-Part Giant Sculpted Stylus Pencil floating beside the easel
    const pencilGroup = new THREE.Group();
    pencilGroup.position.set(2.85, 1.9, 0.85);
    pencilGroup.rotation.set(0.25, -0.35, 0.55);

    const pencilBodyMat = new THREE.MeshStandardMaterial({
      color: 0x8b5cf6,
      roughness: 0.35,
      metalness: 0.2,
    });
    const ferruleMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.18,
      metalness: 0.92,
    });
    const eraserMat = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      roughness: 0.75,
      metalness: 0.05,
    });
    const coneWoodMat = new THREE.MeshStandardMaterial({
      color: 0xfde68a,
      roughness: 0.65,
      metalness: 0.05,
    });
    const leadTipMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.3,
      metalness: 0.4,
    });

    const hexBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 1.35, 6), pencilBodyMat);
    hexBarrel.castShadow = true;
    pencilGroup.add(hexBarrel);

    const ferrule = new THREE.Mesh(new THREE.CylinderGeometry(0.145, 0.145, 0.22, 24), ferruleMat);
    ferrule.position.y = 0.78;
    pencilGroup.add(ferrule);

    const eraserCap = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.14, 8, 16), eraserMat);
    eraserCap.position.y = 0.96;
    pencilGroup.add(eraserCap);

    const woodCone = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.38, 16), coneWoodMat);
    woodCone.position.y = -0.86;
    woodCone.rotation.x = Math.PI;
    pencilGroup.add(woodCone);

    const graphiteTip = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.15, 16), leadTipMat);
    graphiteTip.position.y = -1.02;
    graphiteTip.rotation.x = Math.PI;
    pencilGroup.add(graphiteTip);

    const accentRing = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.02, 12, 32), trimGoldMat);
    accentRing.rotation.x = Math.PI / 2;
    pencilGroup.add(accentRing);

    scene.add(pencilGroup);

    // COMPOSITE MODEL 3: 6-Part Championship Podium (for Match Podium / Background Depth)
    const podiumGroup = new THREE.Group();
    podiumGroup.position.set(1.2, 0.12, -2.4);

    const pod1Mat = new THREE.MeshStandardMaterial({ color: 0x8b5cf6, roughness: 0.4, metalness: 0.3 });
    const pod2Mat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.5, metalness: 0.2 });
    const pod3Mat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5, metalness: 0.2 });

    const step1 = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.1, 1.1), pod1Mat);
    step1.position.set(0, 0.55, 0);
    step1.castShadow = true;
    step1.receiveShadow = true;
    podiumGroup.add(step1);

    const step1Crown = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.05, 12, 24), trimGoldMat);
    step1Crown.position.set(0, 1.38, 0);
    podiumGroup.add(step1Crown);

    const step2 = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.78, 1.0), pod2Mat);
    step2.position.set(-1.12, 0.39, 0.1);
    step2.castShadow = true;
    step2.receiveShadow = true;
    podiumGroup.add(step2);

    const step3 = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.56, 1.0), pod3Mat);
    step3.position.set(1.12, 0.28, 0.15);
    step3.castShadow = true;
    step3.receiveShadow = true;
    podiumGroup.add(step3);

    scene.add(podiumGroup);

    // INSTANCED MESH (> 20 repeated floating geometric studio color blocks)
    const blockCount = 28;
    const blockGeo = new THREE.BoxGeometry(0.28, 0.28, 0.28);
    const blockMat = new THREE.MeshStandardMaterial({
      roughness: 0.35,
      metalness: 0.25,
    });
    const instancedBlocks = new THREE.InstancedMesh(blockGeo, blockMat, blockCount);
    instancedBlocks.frustumCulled = false;

    const paletteColors = [0x8b5cf6, 0x10b981, 0xf59e0b, 0xef4444, 0x06b6d4, 0xec4899];
    const blockSeeds: Array<{ x: number; y: number; z: number; scale: number; speed: number }> = [];

    for (let i = 0; i < blockCount; i++) {
      const angle = -Math.PI * 0.45 + (i / blockCount) * Math.PI * 1.15;
      const radius = 3.2 + (i % 4) * 0.85;
      const x = Math.max(0.35, 1.6 + Math.cos(angle) * radius);
      const z = Math.sin(angle) * radius - 1.2;
      const y = 0.45 + (i % 5) * 0.62;
      const scale = 0.72 + (i % 4) * 0.14;
      blockSeeds.push({ x, y, z, scale, speed: 0.6 + (i % 5) * 0.2 });

      _dummyObj.position.set(x, y, z);
      _dummyObj.rotation.set(i * 0.4, i * 0.7, 0);
      _dummyObj.scale.setScalar(scale);
      _dummyObj.updateMatrix();
      instancedBlocks.setMatrixAt(i, _dummyObj.matrix);

      _colorHelper.setHex(paletteColors[i % paletteColors.length]);
      instancedBlocks.setColorAt(i, _colorHelper);
    }
    instancedBlocks.instanceMatrix.needsUpdate = true;
    if (instancedBlocks.instanceColor) instancedBlocks.instanceColor.needsUpdate = true;
    instancedBlocks.computeBoundingSphere();
    scene.add(instancedBlocks);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Subtle pointer parallax
    let pointerX = 0;
    let pointerY = 0;
    const onPointerMove = (e: PointerEvent) => {
      pointerX = (e.clientX / Math.max(1, window.innerWidth) - 0.5) * 2;
      pointerY = (e.clientY / Math.max(1, window.innerHeight) - 0.5) * 2;
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    let lastTimeMs = performance.now();
    const startTimeMs = lastTimeMs;
    let frameId = 0;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const nowMs = performance.now();
      const rawDt = (nowMs - lastTimeMs) / 1000;
      lastTimeMs = nowMs;
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
      const elapsed = (nowMs - startTimeMs) / 1000;

      // Animate sculpted stylus pencil & podium crown
      pencilGroup.position.y = 1.9 + Math.sin(elapsed * 2.1) * 0.14;
      pencilGroup.rotation.y = -0.35 + Math.sin(elapsed * 1.2) * 0.25;
      step1Crown.rotation.y = elapsed * 1.4;
      step1Crown.position.y = 1.38 + Math.sin(elapsed * 2.6) * 0.06;

      // Update floating studio blocks
      for (let i = 0; i < blockCount; i++) {
        const b = blockSeeds[i];
        _dummyObj.position.set(
          b.x,
          b.y + Math.sin(elapsed * b.speed + i) * 0.15,
          b.z,
        );
        _dummyObj.rotation.set(elapsed * 0.3 + i, elapsed * 0.45 + i, 0);
        _dummyObj.scale.setScalar(b.scale);
        _dummyObj.updateMatrix();
        instancedBlocks.setMatrixAt(i, _dummyObj.matrix);
      }
      instancedBlocks.instanceMatrix.needsUpdate = true;

      // Damped camera choreography based on shellState
      const mode = shellStateRef.current;
      if (mode === 'title') {
        _targetCamPos.set(-1.35 + pointerX * 0.45, 2.15 - pointerY * 0.25, 6.2);
        _targetLookAt.set(0.95, 1.55, 0);
      } else if (mode === 'gameover') {
        _targetCamPos.set(1.2 + Math.sin(elapsed * 0.5) * 0.6, 2.3, 1.2);
        _targetLookAt.set(1.2, 1.0, -2.4);
      } else {
        // Subtle ambient studio background framing during active play
        _targetCamPos.set(0, 3.6, 8.8);
        _targetLookAt.set(1.0, 1.2, 0);
      }

      const dampFactor = 1 - Math.exp(-4.5 * dt);
      camera.position.lerp(_targetCamPos, dampFactor);
      _currentLookAt.lerp(_targetLookAt, dampFactor);
      camera.lookAt(_currentLookAt);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      data-testid="three-studio-stage"
      className="fixed inset-0 w-full h-full pointer-events-none z-0"
    />
  );
};
