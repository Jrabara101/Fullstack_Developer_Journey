import React, { useState } from 'react';
import { useGameStore } from '../store/useGameStore';
import { Play, QrCode, Sparkles, EyeOff, Activity, Zap } from 'lucide-react';

interface TitleScreenProps {
  onOpenPairingModal: () => void;
  onOpenGeminiModal: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onOpenPairingModal,
  onOpenGeminiModal,
}) => {
  const roomId = useGameStore((s) => s.roomId);
  const players = useGameStore((s) => s.players);
  const localPlayerId = useGameStore((s) => s.localPlayerId);
  const modifiers = useGameStore((s) => s.modifiers);
  const setLocalUsername = useGameStore((s) => s.setLocalUsername);
  const setRoomId = useGameStore((s) => s.setRoomId);
  const toggleModifier = useGameStore((s) => s.toggleModifier);
  const startGameFromTitle = useGameStore((s) => s.startGameFromTitle);

  const localPlayer =
    players.find((p) => p.id === localPlayerId) || players[0];

  const [nameInput, setNameInput] = useState(localPlayer.username);
  const [roomInput, setRoomInput] = useState(roomId);

  const handleStart = () => {
    setLocalUsername(nameInput);
    setRoomId(roomInput);
    startGameFromTitle(false);
  };

  return (
    <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-between p-6 md:p-12">
      {/* Top Status Strip (Unboxed clean metadata, no website navbar) */}
      <div className="flex items-center justify-between">
        <div className="text-xs font-mono-code text-slate-300 flex items-center gap-2">
          <span>ROOM: {roomId}</span>
          <span aria-hidden="true">·</span>
          <span>4 PLAYERS READY</span>
          <span aria-hidden="true">·</span>
          <span>3 ROUNDS</span>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenPairingModal}
            className="px-3.5 py-2 rounded-xl bg-slate-900/95 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <QrCode className="w-3.5 h-3.5 text-violet-400" />
            <span>Room Code & QR Cast</span>
          </button>

          <button
            type="button"
            onClick={onOpenGeminiModal}
            className="px-3.5 py-2 rounded-xl bg-slate-900/95 hover:bg-slate-800 text-violet-200 border border-violet-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>AI Deck & 4K Studio Art</span>
          </button>
        </div>
      </div>

      {/* Left-Third Asymmetric Title Lockup over 35%+ Calm Negative Space */}
      <div className="max-w-lg pointer-events-auto my-auto">
        {/* Custom Inline SVG Title Lockup matched to Playroom Studio World */}
        <div className="mb-5">
          <svg
            viewBox="0 0 520 128"
            className="w-full max-w-[460px] h-auto drop-shadow-2xl"
            role="img"
            aria-label="SketchBlitz Studio"
          >
            <defs>
              <linearGradient id="titleStrokeGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#8B5CF6" />
                <stop offset="55%" stopColor="#EC4899" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
            </defs>
            {/* Diegetic Studio Plaque Backing */}
            <rect
              x="4"
              y="8"
              width="512"
              height="112"
              rx="22"
              fill="#0F172A"
              stroke="url(#titleStrokeGrad)"
              strokeWidth="3.5"
            />
            {/* StylusNib Emblem Icon */}
            <g transform="translate(26, 26)">
              <rect
                x="0"
                y="0"
                width="74"
                height="74"
                rx="16"
                fill="#1E293B"
                stroke="#475569"
                strokeWidth="2"
              />
              <path
                d="M18 56 L32 20 L45 44 L56 18"
                fill="none"
                stroke="#10B981"
                strokeWidth="6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="56" cy="18" r="6" fill="#F59E0B" />
            </g>
            {/* Main Display Typography */}
            <text
              x="118"
              y="62"
              fill="#F8FAFC"
              fontFamily="Plus Jakarta Sans, sans-serif"
              fontWeight="800"
              fontSize="40"
              letterSpacing="-1"
            >
              SKETCHBLITZ
            </text>
            <text
              x="120"
              y="95"
              fill="#A78BFA"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="700"
              fontSize="16"
              letterSpacing="4"
            >
              PLAYROOM STUDIO · LIVE
            </text>
          </svg>
        </div>

        <p className="text-sm md:text-base text-slate-300 leading-relaxed mb-6">
          High-energy multiplayer drawing and deduction. Sketch on the dual-layer
          Catmull-Rom canvas, trigger private warm-guess proximity alerts, and
          watch 3-second vector replays on the 3D studio stage.
        </p>

        {/* Frictionless Room Pairing & Handle Controls */}
        <div className="p-4 rounded-2xl bg-[#1E293B] border border-slate-700 shadow-2xl space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label
                htmlFor="title-player-name"
                className="block text-xs font-semibold text-slate-300 mb-1"
              >
                Player Handle
              </label>
              <input
                id="title-player-name"
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                maxLength={18}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm font-semibold text-white focus:outline-none focus:border-violet-500"
              />
            </div>

            <div>
              <label
                htmlFor="title-room-code"
                className="block text-xs font-semibold text-slate-300 mb-1"
              >
                4-Char Room Code
              </label>
              <input
                id="title-room-code"
                type="text"
                value={roomInput}
                onChange={(e) => setRoomId(e.target.value)}
                onInput={(e) =>
                  setRoomInput(
                    (e.target as HTMLInputElement).value
                      .toUpperCase()
                      .slice(0, 4),
                  )
                }
                maxLength={4}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm font-mono-code font-bold text-amber-400 uppercase tracking-widest focus:outline-none focus:border-violet-500"
              />
            </div>
          </div>

          {/* Party Modifiers Quick Bar */}
          <div>
            <span className="block text-xs font-semibold text-slate-400 mb-1.5">
              Party Modifiers (Optional Chaos Rules)
            </span>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => toggleModifier('blindfold')}
                aria-pressed={modifiers.blindfold}
                className={`px-2.5 py-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  modifiers.blindfold
                    ? 'bg-amber-500/20 border-amber-500 text-amber-200'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <EyeOff className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Blindfold</span>
              </button>

              <button
                type="button"
                onClick={() => toggleModifier('oneLineOnly')}
                aria-pressed={modifiers.oneLineOnly}
                className={`px-2.5 py-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  modifiers.oneLineOnly
                    ? 'bg-violet-500/20 border-violet-500 text-violet-200'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Activity className="w-3.5 h-3.5 text-violet-400 shrink-0" />
                <span>One-Line</span>
              </button>

              <button
                type="button"
                onClick={() => toggleModifier('speedBlitz')}
                aria-pressed={modifiers.speedBlitz}
                className={`px-2.5 py-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  modifiers.speedBlitz
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-200'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Zap className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Speed Blitz</span>
              </button>
            </div>
          </div>

          {/* Primary Start CTA with data-start="true" */}
          <button
            type="button"
            data-start="true"
            onClick={handleStart}
            className="w-full py-3.5 px-6 rounded-xl bg-violet-600 hover:bg-violet-500 active:scale-[0.99] text-white font-extrabold text-base flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer whitespace-nowrap"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>Enter Playroom Studio (Press Enter)</span>
          </button>
        </div>
      </div>

      {/* Single flat control-hint line in the bottom safe margin */}
      <div className="text-xs text-slate-400 font-mono-code">
        Mouse / Touch Draw · Enter Submit Guess · B / E / F Switch Tools · P / Esc Pause · M Mute Audio
      </div>
    </div>
  );
};
