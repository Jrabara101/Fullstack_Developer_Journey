import test from 'node:test';
import assert from 'node:assert/strict';
import {
  levenshteinDistance,
  evaluateGuessProximity,
  maskTargetWord,
  calculateGuessScore,
  smoothStrokeCatmullRom,
  parseCustomWordDeck,
  pickThreeTieredWords,
  DEFAULT_WORD_DECK,
} from './rules';

test('levenshteinDistance calculates exact, 1-edit, and 2-edit distances accurately', () => {
  assert.equal(levenshteinDistance('CAMPFIRE', 'campfire'), 0);
  assert.equal(levenshteinDistance('CAMPFIRE', 'CAMPFIR'), 1);
  assert.equal(levenshteinDistance('CAMPFIRE', 'KAMPFIRE'), 1);
  assert.equal(levenshteinDistance('LIGHTHOUSE', 'LIGHTOUS'), 2);
});

test('evaluateGuessProximity identifies exact, warm (1 letter off), close (2 letters off), and cold guesses', () => {
  const exact = evaluateGuessProximity('robot', 'ROBOT');
  assert.equal(exact.proximity, 'exact');
  assert.equal(exact.editDistance, 0);

  const warm = evaluateGuessProximity('ROBO', 'ROBOT');
  assert.equal(warm.proximity, 'warm');
  assert.equal(warm.editDistance, 1);

  const close = evaluateGuessProximity('SKATEBORD', 'SKATEBOARD');
  assert.equal(close.proximity, 'warm');

  const closeTwo = evaluateGuessProximity('SKATBORD', 'SKATEBOARD');
  assert.equal(closeTwo.proximity, 'close');
  assert.equal(closeTwo.editDistance, 2);

  const cold = evaluateGuessProximity('BANANA', 'SKATEBOARD');
  assert.equal(cold.proximity, 'cold');
});

test('maskTargetWord masks letters with underscores and reveals progressive hints past 50% and 75% time', () => {
  const initialMask = maskTargetWord('CAMPFIRE', 60, 60);
  assert.equal(initialMask, '_ _ _ _ _ _ _ _');

  const midMask = maskTargetWord('CAMPFIRE', 25, 60);
  assert.equal(midMask.startsWith('C '), true);

  const lateMask = maskTargetWord('CAMPFIRE', 10, 60);
  assert.equal(lateMask.includes('C'), true);
  assert.equal(lateMask.includes('F'), true);
});

test('calculateGuessScore scales points by difficulty, remaining time, guess rank, and party modifiers', () => {
  const baseFirst = calculateGuessScore({
    basePoints: 250,
    timeLeft: 50,
    maxTime: 60,
    guessOrderIndex: 0,
    modifiers: { blindfold: false, oneLineOnly: false, speedBlitz: false },
  });

  const baseLater = calculateGuessScore({
    basePoints: 250,
    timeLeft: 15,
    maxTime: 60,
    guessOrderIndex: 2,
    modifiers: { blindfold: false, oneLineOnly: false, speedBlitz: false },
  });

  assert.equal(baseFirst.guesserPoints > baseLater.guesserPoints, true);

  const modifiedScore = calculateGuessScore({
    basePoints: 250,
    timeLeft: 50,
    maxTime: 60,
    guessOrderIndex: 0,
    modifiers: { blindfold: true, oneLineOnly: true, speedBlitz: false },
  });

  assert.equal(modifiedScore.guesserPoints > baseFirst.guesserPoints, true);
});

test('smoothStrokeCatmullRom interpolates intermediate points along a multi-point stroke', () => {
  const raw = [
    { x: 100, y: 100 },
    { x: 200, y: 150 },
    { x: 300, y: 100 },
    { x: 400, y: 200 },
  ];
  const smoothed = smoothStrokeCatmullRom(raw, 4);
  assert.equal(smoothed.length > raw.length, true);
  assert.deepEqual(smoothed[0], raw[0]);
});

test('parseCustomWordDeck and pickThreeTieredWords categorize custom words into Easy, Medium, and Hard tiers', () => {
  const parsed = parseCustomWordDeck('cat, skateboard, quantum entanglement', 'Inside Jokes');
  assert.equal(parsed.length, 3);
  assert.equal(parsed[0].difficulty, 'Easy');
  assert.equal(parsed[1].difficulty, 'Hard');
  assert.equal(parsed[2].difficulty, 'Hard');

  const three = pickThreeTieredWords(DEFAULT_WORD_DECK, 2);
  assert.equal(three.length, 3);
  assert.equal(three[0].difficulty, 'Easy');
  assert.equal(three[1].difficulty, 'Medium');
  assert.equal(three[2].difficulty, 'Hard');
});
