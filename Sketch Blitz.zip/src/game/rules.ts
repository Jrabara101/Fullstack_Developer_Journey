import { DrawStroke, GuessProximity, PartyModifiers, StrokePoint, WordOption } from './types';

export const STUDIO_PALETTE_16 = [
  '#0F172A', // Obsidian Ink
  '#475569', // Slate Gray
  '#94A3B8', // Cool Silver
  '#FFFFFF', // Pure White
  '#EF4444', // Arcade Coral Red
  '#F97316', // Tangy Orange
  '#F59E0B', // Amber Gold
  '#EAB308', // Electric Lemon
  '#10B981', // Emerald Mint
  '#059669', // Deep Forest
  '#06B6D4', // Cyan Bolt
  '#3B82F6', // RoyalCobalt
  '#8B5CF6', // Electric Violet
  '#EC4899', // Hot Magenta
  '#92400E', // Warm Umber
  '#FCA5A5', // Soft Peach
] as const;

export const DEFAULT_WORD_DECK: WordOption[] = [
  { word: 'CAMPFIRE', difficulty: 'Easy', points: 100, category: 'Outdoors' },
  { word: 'ROBOT', difficulty: 'Easy', points: 100, category: 'Sci-Fi' },
  { word: 'PIZZA', difficulty: 'Easy', points: 100, category: 'Food' },
  { word: 'SNOWMAN', difficulty: 'Easy', points: 100, category: 'Winter' },
  { word: 'GUITAR', difficulty: 'Easy', points: 100, category: 'Music' },
  { word: 'ROCKET', difficulty: 'Easy', points: 100, category: 'Space' },
  { word: 'CACTUS', difficulty: 'Easy', points: 100, category: 'Nature' },
  { word: 'CROWN', difficulty: 'Easy', points: 100, category: 'Royalty' },

  { word: 'LIGHTHOUSE', difficulty: 'Medium', points: 250, category: 'Architecture' },
  { word: 'ASTRONAUT', difficulty: 'Medium', points: 250, category: 'Space' },
  { word: 'SKATEBOARD', difficulty: 'Medium', points: 250, category: 'Action' },
  { word: 'VOLCANO', difficulty: 'Medium', points: 250, category: 'Nature' },
  { word: 'CHANDELIER', difficulty: 'Medium', points: 250, category: 'Interior' },
  { word: 'SUBMARINE', difficulty: 'Medium', points: 250, category: 'Vehicles' },
  { word: 'TREEHOUSE', difficulty: 'Medium', points: 250, category: 'Outdoors' },
  { word: 'PARACHUTE', difficulty: 'Medium', points: 250, category: 'Action' },

  { word: 'TIME MACHINE', difficulty: 'Hard', points: 500, category: 'Sci-Fi' },
  { word: 'SLEEPWALKING', difficulty: 'Hard', points: 500, category: 'Action' },
  { word: 'ROLLERCOASTER', difficulty: 'Hard', points: 500, category: 'Amusement' },
  { word: 'ZERO GRAVITY', difficulty: 'Hard', points: 500, category: 'Space' },
  { word: 'BRAIN FREEZE', difficulty: 'Hard', points: 500, category: 'Chaos' },
  { word: 'SHADOW PUPPET', difficulty: 'Hard', points: 500, category: 'Art' },
  { word: 'LOCH NESS', difficulty: 'Hard', points: 500, category: 'Myth' },
  { word: 'ESCAPE ROOM', difficulty: 'Hard', points: 500, category: 'Party' },
];

/**
 * Computes the standard Levenshtein edit distance between two strings (case-insensitive, trimmed).
 */
export function levenshteinDistance(a: string, b: string): number {
  const s1 = a.trim().toUpperCase();
  const s2 = b.trim().toUpperCase();

  if (s1 === s2) return 0;
  if (s1.length === 0) return s2.length;
  if (s2.length === 0) return s1.length;

  const prev = new Array<number>(s2.length + 1);
  const curr = new Array<number>(s2.length + 1);

  for (let j = 0; j <= s2.length; j++) {
    prev[j] = j;
  }

  for (let i = 1; i <= s1.length; i++) {
    curr[0] = i;
    for (let j = 1; j <= s2.length; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
      curr[j] = Math.min(
        curr[j - 1] + 1,      // insertion
        prev[j] + 1,          // deletion
        prev[j - 1] + cost,   // substitution
      );
    }
    for (let j = 0; j <= s2.length; j++) {
      prev[j] = curr[j];
    }
  }

  return prev[s2.length];
}

/**
 * Evaluates a player's guess against the hidden target word.
 * - distance === 0 -> 'exact'
 * - distance === 1 -> 'warm' ("You're super close! 1 letter off")
 * - distance === 2 (when word length >= 5) -> 'close' ("Getting warm! 2 letters away")
 * - otherwise -> 'cold'
 */
export function evaluateGuessProximity(
  guess: string,
  targetWord: string,
): { proximity: GuessProximity; editDistance: number } {
  const cleanGuess = guess.trim().toUpperCase();
  const cleanTarget = targetWord.trim().toUpperCase();

  if (!cleanGuess || !cleanTarget) {
    return { proximity: 'cold', editDistance: 99 };
  }

  const distance = levenshteinDistance(cleanGuess, cleanTarget);
  if (distance === 0) {
    return { proximity: 'exact', editDistance: 0 };
  }
  if (distance === 1 && cleanTarget.length >= 3) {
    return { proximity: 'warm', editDistance: 1 };
  }
  if (distance === 2 && cleanTarget.length >= 5) {
    return { proximity: 'close', editDistance: 2 };
  }

  return { proximity: 'cold', editDistance: distance };
}

/**
 * Generates a masked representation of a target word (e.g. "CAMPFIRE" -> "_ _ _ _ _ _ _ _")
 * Optionally reveals specific hint indices as the timer winds down.
 */
export function maskTargetWord(
  word: string,
  timeLeft: number,
  maxTime: number,
): string {
  const clean = word.toUpperCase();
  const chars = clean.split('');
  const progress = maxTime > 0 ? 1 - timeLeft / maxTime : 0;

  // Reveal up to 1 letter at 50% time elapsed, 2 letters at 75% time elapsed for words >= 5 chars
  const revealCount =
    clean.replace(/\s+/g, '').length < 4
      ? 0
      : progress >= 0.75
        ? 2
        : progress >= 0.5
          ? 1
          : 0;

  // Deterministic indices to reveal based on character codes
  const letterIndices: number[] = [];
  chars.forEach((ch, idx) => {
    if (ch !== ' ' && ch !== '-') letterIndices.push(idx);
  });

  const revealedSet = new Set<number>();
  if (revealCount >= 1 && letterIndices.length > 0) {
    revealedSet.add(letterIndices[0]);
  }
  if (revealCount >= 2 && letterIndices.length > 2) {
    revealedSet.add(letterIndices[Math.floor(letterIndices.length / 2)]);
  }

  return chars
    .map((ch, idx) => {
      if (ch === ' ') return '  ';
      if (ch === '-') return '-';
      if (revealedSet.has(idx)) return ch;
      return '_';
    })
    .join(' ');
}

/**
 * Calculates score awarded for a correct guess based on word difficulty points,
 * remaining round time, guess order rank, and active party modifiers.
 */
export function calculateGuessScore(params: {
  basePoints: number;
  timeLeft: number;
  maxTime: number;
  guessOrderIndex: number; // 0 for first guesser, 1 for second, etc.
  modifiers: PartyModifiers;
}): { guesserPoints: number; artistBonus: number } {
  const { basePoints, timeLeft, maxTime, guessOrderIndex, modifiers } = params;
  const clampedRatio = maxTime > 0 ? Math.max(0.15, Math.min(1, timeLeft / maxTime)) : 0.5;
  const firstBonus = guessOrderIndex === 0 ? 60 : guessOrderIndex === 1 ? 30 : 0;

  let modifierMult = 1;
  if (modifiers.blindfold) modifierMult += 0.25;
  if (modifiers.oneLineOnly) modifierMult += 0.25;
  if (modifiers.speedBlitz) modifierMult += 0.35;

  const rawGuesser = (basePoints * (0.45 + 0.55 * clampedRatio) + firstBonus) * modifierMult;
  const guesserPoints = Math.round(rawGuesser / 5) * 5;
  const artistBonus = Math.round((basePoints * 0.35 * modifierMult) / 5) * 5;

  return { guesserPoints, artistBonus };
}

/**
 * Smooths a sequence of raw pointer points using Catmull-Rom spline interpolation
 * so mouse and touch strokes look fluid regardless of device sample rate.
 */
export function smoothStrokeCatmullRom(
  points: StrokePoint[],
  segmentsPerCurve = 4,
): StrokePoint[] {
  if (points.length <= 2) {
    return points.slice();
  }

  const result: StrokePoint[] = [points[0]];

  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(points.length - 1, i + 2)];

    const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
    const steps = dist < 4 ? 1 : Math.min(8, Math.max(2, segmentsPerCurve));

    for (let step = 1; step <= steps; step++) {
      const t = step / steps;
      const t2 = t * t;
      const t3 = t2 * t;

      const x =
        0.5 *
        (2 * p1.x +
          (-p0.x + p2.x) * t +
          (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 +
          (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3);

      const y =
        0.5 *
        (2 * p1.y +
          (-p0.y + p2.y) * t +
          (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 +
          (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3);

      result.push({
        x: Math.round(x * 10) / 10,
        y: Math.round(y * 10) / 10,
        pressure: p1.pressure ?? 0.5,
      });
    }
  }

  return result;
}

/**
 * Parses a custom Inside-Joke Deck string (comma or newline separated) into tiered WordOptions.
 */
export function parseCustomWordDeck(
  rawText: string,
  deckCategory = 'Custom Deck',
): WordOption[] {
  const tokens = rawText
    .split(/[\n,;]+/)
    .map((item) => item.trim().toUpperCase())
    .filter((item) => item.length >= 2 && item.length <= 28);

  const unique = Array.from(new Set(tokens));

  return unique.map((word) => {
    const cleanLen = word.replace(/\s+/g, '').length;
    const hasSpace = word.includes(' ');
    if (hasSpace || cleanLen >= 10) {
      return { word, difficulty: 'Hard', points: 500, category: deckCategory };
    }
    if (cleanLen >= 6) {
      return { word, difficulty: 'Medium', points: 250, category: deckCategory };
    }
    return { word, difficulty: 'Easy', points: 100, category: deckCategory };
  });
}

/**
 * Picks 3 tiered word choices (1 Easy, 1 Medium, 1 Hard) from a word deck.
 */
export function pickThreeTieredWords(
  deck: WordOption[],
  seedOffset = 0,
): WordOption[] {
  const source = deck.length >= 3 ? deck : DEFAULT_WORD_DECK;
  const easy = source.filter((w) => w.difficulty === 'Easy');
  const medium = source.filter((w) => w.difficulty === 'Medium');
  const hard = source.filter((w) => w.difficulty === 'Hard');

  const pickFrom = (arr: WordOption[], fallbackDifficulty: 'Easy' | 'Medium' | 'Hard', idx: number): WordOption => {
    if (arr.length > 0) {
      return arr[(idx + seedOffset) % arr.length];
    }
    const def = DEFAULT_WORD_DECK.filter((w) => w.difficulty === fallbackDifficulty);
    return def[(idx + seedOffset) % def.length];
  };

  return [
    pickFrom(easy, 'Easy', 0),
    pickFrom(medium, 'Medium', 1),
    pickFrom(hard, 'Hard', 2),
  ];
}

/**
 * Generates deterministic vector strokes for a given word so AI/Studio bots or demo replays
 * render recognizable, charming multi-stroke vector sketches on the canvas.
 */
export function buildProceduralSketchForWord(word: string): DrawStroke[] {
  const upper = word.toUpperCase();
  const now = Date.now();

  const createCircle = (cx: number, cy: number, r: number, steps = 24): StrokePoint[] => {
    const pts: StrokePoint[] = [];
    for (let i = 0; i <= steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      pts.push({ x: Math.round(cx + Math.cos(a) * r), y: Math.round(cy + Math.sin(a) * r) });
    }
    return pts;
  };

  if (upper.includes('CAMPFIRE') || upper.includes('VOLCANO')) {
    return [
      {
        id: 'bot-s1',
        tool: 'brush',
        color: '#92400E',
        width: 14,
        timestamp: now,
        points: [
          { x: 360, y: 470 },
          { x: 500, y: 430 },
          { x: 640, y: 470 },
        ],
      },
      {
        id: 'bot-s2',
        tool: 'brush',
        color: '#92400E',
        width: 14,
        timestamp: now + 150,
        points: [
          { x: 370, y: 430 },
          { x: 500, y: 470 },
          { x: 630, y: 430 },
        ],
      },
      {
        id: 'bot-s3',
        tool: 'brush',
        color: '#EF4444',
        width: 16,
        timestamp: now + 300,
        points: [
          { x: 420, y: 420 },
          { x: 450, y: 260 },
          { x: 500, y: 340 },
          { x: 530, y: 210 },
          { x: 580, y: 420 },
          { x: 420, y: 420 },
        ],
      },
      {
        id: 'bot-s4',
        tool: 'brush',
        color: '#F59E0B',
        width: 12,
        timestamp: now + 450,
        points: [
          { x: 455, y: 410 },
          { x: 500, y: 270 },
          { x: 545, y: 410 },
        ],
      },
    ];
  }

  if (upper.includes('ROBOT')) {
    return [
      {
        id: 'bot-r1',
        tool: 'brush',
        color: '#475569',
        width: 10,
        timestamp: now,
        points: [
          { x: 400, y: 180 },
          { x: 600, y: 180 },
          { x: 600, y: 340 },
          { x: 400, y: 340 },
          { x: 400, y: 180 },
        ],
      },
      {
        id: 'bot-r2',
        tool: 'brush',
        color: '#EF4444',
        width: 8,
        timestamp: now + 120,
        points: [
          { x: 500, y: 180 },
          { x: 500, y: 120 },
        ],
      },
      {
        id: 'bot-r3',
        tool: 'brush',
        color: '#06B6D4',
        width: 12,
        timestamp: now + 240,
        points: createCircle(455, 240, 18, 12),
      },
      {
        id: 'bot-r4',
        tool: 'brush',
        color: '#06B6D4',
        width: 12,
        timestamp: now + 360,
        points: createCircle(545, 240, 18, 12),
      },
      {
        id: 'bot-r5',
        tool: 'brush',
        color: '#F59E0B',
        width: 8,
        timestamp: now + 480,
        points: [
          { x: 440, y: 300 },
          { x: 470, y: 310 },
          { x: 500, y: 295 },
          { x: 530, y: 310 },
          { x: 560, y: 300 },
        ],
      },
    ];
  }

  // Default cheerful sun + mountain + wave scene for any word
  return [
    {
      id: 'bot-d1',
      tool: 'brush',
      color: '#F59E0B',
      width: 14,
      timestamp: now,
      points: createCircle(500, 260, 85, 24),
    },
    {
      id: 'bot-d2',
      tool: 'brush',
      color: '#8B5CF6',
      width: 10,
      timestamp: now + 200,
      points: [
        { x: 320, y: 450 },
        { x: 440, y: 270 },
        { x: 540, y: 410 },
        { x: 620, y: 290 },
        { x: 710, y: 450 },
      ],
    },
    {
      id: 'bot-d3',
      tool: 'brush',
      color: '#10B981',
      width: 12,
      timestamp: now + 400,
      points: [
        { x: 280, y: 460 },
        { x: 500, y: 445 },
        { x: 730, y: 460 },
      ],
    },
  ];
}
