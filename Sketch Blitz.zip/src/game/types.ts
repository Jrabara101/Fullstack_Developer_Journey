export type GamePhase =
  | 'LOBBY'
  | 'WORD_SELECTION'
  | 'DRAWING'
  | 'ROUND_RECAP'
  | 'GAME_OVER';

export type ShellState = 'title' | 'playing' | 'paused' | 'gameover';

export type DrawTool = 'brush' | 'eraser' | 'fill';

export interface StrokePoint {
  x: number; // Normalized 0..1000 canvas coordinate
  y: number; // Normalized 0..625 canvas coordinate (16:10 aspect)
  pressure?: number;
}

export interface DrawStroke {
  id: string;
  points: StrokePoint[];
  color: string;
  width: number;
  tool: DrawTool;
  timestamp: number;
}

export interface WordOption {
  word: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  points: 100 | 250 | 500;
  category: string;
}

export interface Player {
  id: string;
  username: string;
  avatarUrl: string;
  avatarColor: string;
  score: number;
  roundScoreDelta: number;
  streak: number;
  hasGuessedCorrectly: boolean;
  isHost: boolean;
  isBot?: boolean;
  pingMs: number;
}

export interface PartyModifiers {
  blindfold: boolean; // Drawer's ink fades visually after 1.2 seconds while drawing
  oneLineOnly: boolean; // Pen cannot be lifted once stroke begins
  speedBlitz: boolean; // 35s high-octane rounds with 1.5x score multiplier
}

export type GuessProximity = 'exact' | 'warm' | 'close' | 'cold' | 'chat';

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderColor: string;
  text: string;
  timestamp: number;
  channel: 'public' | 'spectator' | 'private-warm' | 'system';
  proximity: GuessProximity;
  editDistance?: number;
  pointsAwarded?: number;
}

export interface RoundRecapRecord {
  roundNumber: number;
  artistName: string;
  word: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  strokes: DrawStroke[];
  backgroundColor: string;
  fastestGuesser?: string;
  totalCorrectGuesses: number;
}

export interface GameLobbyState {
  roomId: string;
  round: { current: number; total: number };
  phase: GamePhase;
  timeLeft: number;
  maxTime: number;
  currentArtistId: string;
  hiddenWord: string; // Masked as underscores ("_ _ _ _") for guessers, unmasked for drawer/spectators
  actualWord?: string; // Populated for active drawer, correct guessers, or during recap
  wordDifficulty: 'Easy' | 'Medium' | 'Hard';
  wordPoints: number;
  wordChoices?: WordOption[]; // Populated for active drawer during WORD_SELECTION
  players: Player[];
  canvasState: {
    strokes: DrawStroke[];
    backgroundColor: string;
  };
  modifiers: PartyModifiers;
  messages: ChatMessage[];
  roundHistory: RoundRecapRecord[];
  customDeckName: string;
  customWordsCount: number;
}

export type DualScreenMode = 'standard' | 'tv-cast' | 'stylus-pad';

export type ImageSizeOption = '1K' | '2K' | '4K';

export interface GeneratedStudioArt {
  id: string;
  prompt: string;
  imageSize: ImageSizeOption;
  imageUrl: string;
  createdAt: number;
  modelUsed: string;
  note?: string;
}
