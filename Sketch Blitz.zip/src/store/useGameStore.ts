import { create } from 'zustand';
import {
  ChatMessage,
  DrawStroke,
  DrawTool,
  DualScreenMode,
  GameLobbyState,
  GeneratedStudioArt,
  PartyModifiers,
  Player,
  ShellState,
  StrokePoint,
  WordOption,
} from '../game/types';
import {
  DEFAULT_WORD_DECK,
  STUDIO_PALETTE_16,
  buildProceduralSketchForWord,
  calculateGuessScore,
  evaluateGuessProximity,
  maskTargetWord,
  parseCustomWordDeck,
  pickThreeTieredWords,
  smoothStrokeCatmullRom,
} from '../game/rules';
import { soundEngine } from '../utils/sound';

const INITIAL_PLAYERS: Player[] = [
  {
    id: 'player-local',
    username: 'You (Host)',
    avatarUrl: 'artist-violet',
    avatarColor: '#8B5CF6',
    score: 0,
    roundScoreDelta: 0,
    streak: 0,
    hasGuessedCorrectly: false,
    isHost: true,
    isBot: false,
    pingMs: 14,
  },
  {
    id: 'bot-milo',
    username: 'MiloSketch',
    avatarUrl: 'bot-emerald',
    avatarColor: '#10B981',
    score: 0,
    roundScoreDelta: 0,
    streak: 0,
    hasGuessedCorrectly: false,
    isHost: false,
    isBot: true,
    pingMs: 22,
  },
  {
    id: 'bot-nova',
    username: 'NovaPixel',
    avatarUrl: 'bot-amber',
    avatarColor: '#F59E0B',
    score: 0,
    roundScoreDelta: 0,
    streak: 0,
    hasGuessedCorrectly: false,
    isHost: false,
    isBot: true,
    pingMs: 19,
  },
  {
    id: 'bot-riley',
    username: 'RileyInk',
    avatarUrl: 'bot-cyan',
    avatarColor: '#06B6D4',
    score: 0,
    roundScoreDelta: 0,
    streak: 0,
    hasGuessedCorrectly: false,
    isHost: false,
    isBot: true,
    pingMs: 27,
  },
];

interface ExtendedGameStore extends GameLobbyState {
  shellState: ShellState;
  localPlayerId: string;
  activeTool: DrawTool;
  activeColor: string;
  brushWidth: number;
  dualScreenMode: DualScreenMode;
  muted: boolean;
  paperShakeTrigger: number;
  activeDeck: WordOption[];
  studioArtGallery: GeneratedStudioArt[];
  aiHostComment: string;
  isGeneratingDeck: boolean;
  isGeneratingArt: boolean;
  isAskingCritic: boolean;
  activeLiveStroke: DrawStroke | null;
  lastFloatingScore: { playerId: string; delta: number; key: number } | null;

  // Actions
  setShellState: (state: ShellState) => void;
  setLocalUsername: (name: string) => void;
  setRoomId: (code: string) => void;
  startGameFromTitle: (quickStartDrawing?: boolean) => void;
  togglePause: () => void;
  restartMatch: () => void;
  selectWord: (option: WordOption) => void;
  switchRoleToGuesserDemo: () => void;
  switchRoleToArtistDemo: () => void;
  setTool: (tool: DrawTool) => void;
  setColor: (color: string) => void;
  setBrushWidth: (width: number) => void;
  startLiveStroke: (pt: StrokePoint) => void;
  appendLiveStroke: (pt: StrokePoint) => void;
  commitLiveStroke: () => void;
  clearCanvas: () => void;
  floodFillCanvas: (color: string) => void;
  submitGuessOrChat: (rawText: string, senderId?: string) => void;
  toggleModifier: (key: keyof PartyModifiers) => void;
  importCustomDeck: (rawText: string, deckName?: string) => void;
  generateGeminiDeck: (theme: string) => Promise<void>;
  generateGeminiStudioArt: (prompt: string, size: '1K' | '2K' | '4K') => Promise<void>;
  requestGeminiCritic: (canvasDataUrl?: string) => Promise<void>;
  setDualScreenMode: (mode: DualScreenMode) => void;
  toggleMute: () => void;
  tickSecond: () => void;
  triggerRoundRecapNow: () => void;
  advanceFromRecap: () => void;
  connectRealtimeRoom: (roomId: string) => void;
}

let wsClient: WebSocket | null = null;
let broadcastChan: BroadcastChannel | null = null;

function broadcastNetworkPacket(type: string, roomId: string, payload: unknown) {
  const msg = JSON.stringify({ type, roomId, payload });
  if (wsClient && wsClient.readyState === WebSocket.OPEN) {
    wsClient.send(msg);
  }
  if (broadcastChan) {
    try {
      broadcastChan.postMessage({ type, roomId, payload });
    } catch {}
  }
}

export const useGameStore = create<ExtendedGameStore>((set, get) => ({
  roomId: 'BLTZ',
  round: { current: 1, total: 3 },
  phase: 'LOBBY',
  timeLeft: 60,
  maxTime: 60,
  currentArtistId: 'player-local',
  hiddenWord: '_ _ _ _ _ _ _ _',
  actualWord: 'CAMPFIRE',
  wordDifficulty: 'Easy',
  wordPoints: 100,
  wordChoices: pickThreeTieredWords(DEFAULT_WORD_DECK, 0),
  players: INITIAL_PLAYERS,
  canvasState: {
    strokes: [],
    backgroundColor: '#FFFFFF',
  },
  modifiers: {
    blindfold: false,
    oneLineOnly: false,
    speedBlitz: false,
  },
  messages: [
    {
      id: 'sys-welcome',
      senderId: 'system',
      senderName: 'Studio Host',
      senderColor: '#8B5CF6',
      text: 'Welcome to SketchBlitz Studio! Pick a word or type guesses in the stream.',
      timestamp: Date.now(),
      channel: 'system',
      proximity: 'chat',
    },
  ],
  roundHistory: [],
  customDeckName: 'Standard Arcade Pack',
  customWordsCount: DEFAULT_WORD_DECK.length,

  shellState: 'title',
  localPlayerId: 'player-local',
  activeTool: 'brush',
  activeColor: STUDIO_PALETTE_16[0],
  brushWidth: 8,
  dualScreenMode: 'standard',
  muted: false,
  paperShakeTrigger: 0,
  activeDeck: DEFAULT_WORD_DECK,
  studioArtGallery: [],
  aiHostComment: 'Studio cameras rolling! Ready for high-speed sketches and warm guesses.',
  isGeneratingDeck: false,
  isGeneratingArt: false,
  isAskingCritic: false,
  activeLiveStroke: null,
  lastFloatingScore: null,

  setShellState: (shellState) => {
    if (typeof document !== 'undefined') {
      document.body.dataset.state = shellState;
    }
    set({ shellState });
  },

  setLocalUsername: (name) => {
    const clean = name.trim().slice(0, 18) || 'You (Host)';
    set((state) => ({
      players: state.players.map((p) =>
        p.id === state.localPlayerId ? { ...p, username: clean } : p,
      ),
    }));
  },

  setRoomId: (code) => {
    const clean = code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'BLTZ';
    set({ roomId: clean });
    get().connectRealtimeRoom(clean);
  },

  startGameFromTitle: (quickStartDrawing = false) => {
    const state = get();
    const choices = pickThreeTieredWords(state.activeDeck, state.round.current);
    const roundDuration = state.modifiers.speedBlitz ? 35 : 60;

    if (typeof document !== 'undefined') {
      document.body.dataset.state = 'playing';
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
    }

    soundEngine.playPopClick(1.2);

    if (quickStartDrawing) {
      const picked = choices[0];
      set({
        shellState: 'playing',
        phase: 'DRAWING',
        timeLeft: roundDuration,
        maxTime: roundDuration,
        actualWord: picked.word,
        wordDifficulty: picked.difficulty,
        wordPoints: picked.points,
        hiddenWord: maskTargetWord(picked.word, roundDuration, roundDuration),
        wordChoices: choices,
        canvasState: { strokes: [], backgroundColor: '#FFFFFF' },
      });
      return;
    }

    set({
      shellState: 'playing',
      phase: 'WORD_SELECTION',
      timeLeft: 10,
      maxTime: 10,
      wordChoices: choices,
      canvasState: { strokes: [], backgroundColor: '#FFFFFF' },
      players: state.players.map((p) => ({
        ...p,
        hasGuessedCorrectly: false,
        roundScoreDelta: 0,
      })),
    });
  },

  togglePause: () => {
    const { shellState } = get();
    if (shellState === 'playing') {
      if (typeof document !== 'undefined') {
        document.body.dataset.state = 'paused';
      }
      set({ shellState: 'paused' });
    } else if (shellState === 'paused') {
      if (typeof document !== 'undefined') {
        document.body.dataset.state = 'playing';
      }
      set({ shellState: 'playing' });
    }
  },

  restartMatch: () => {
    const state = get();
    const choices = pickThreeTieredWords(state.activeDeck, 1);
    if (typeof document !== 'undefined') {
      document.body.dataset.state = 'playing';
    }
    soundEngine.playPopClick(1.1);
    set({
      shellState: 'playing',
      round: { current: 1, total: 3 },
      phase: 'WORD_SELECTION',
      currentArtistId: 'player-local',
      timeLeft: 10,
      maxTime: 10,
      wordChoices: choices,
      canvasState: { strokes: [], backgroundColor: '#FFFFFF' },
      roundHistory: [],
      players: state.players.map((p) => ({
        ...p,
        score: 0,
        roundScoreDelta: 0,
        streak: 0,
        hasGuessedCorrectly: false,
      })),
      messages: [
        {
          id: `sys-restart-${Date.now()}`,
          senderId: 'system',
          senderName: 'Studio Host',
          senderColor: '#8B5CF6',
          text: 'New match started! Round 1 of 3—Artist is selecting a word.',
          timestamp: Date.now(),
          channel: 'system',
          proximity: 'chat',
        },
      ],
    });
  },

  selectWord: (option) => {
    const state = get();
    const roundDuration = state.modifiers.speedBlitz ? 35 : 60;
    const masked = maskTargetWord(option.word, roundDuration, roundDuration);
    soundEngine.playPopClick(1.3);

    const isBotArtist = state.currentArtistId !== state.localPlayerId;
    const initialStrokes = isBotArtist ? buildProceduralSketchForWord(option.word) : [];

    set({
      phase: 'DRAWING',
      actualWord: option.word,
      wordDifficulty: option.difficulty,
      wordPoints: option.points,
      hiddenWord: masked,
      timeLeft: roundDuration,
      maxTime: roundDuration,
      canvasState: {
        strokes: initialStrokes,
        backgroundColor: '#FFFFFF',
      },
      messages: [
        ...state.messages,
        {
          id: `sys-draw-${Date.now()}`,
          senderId: 'system',
          senderName: 'Studio Host',
          senderColor: '#8B5CF6',
          text: `Round ${state.round.current} started! Word is ${option.word.length} letters (${option.difficulty} · ${option.points} pts).`,
          timestamp: Date.now(),
          channel: 'system',
          proximity: 'chat',
        },
      ],
    });

    broadcastNetworkPacket('word:select', state.roomId, {
      word: option.word,
      difficulty: option.difficulty,
      points: option.points,
      roundDuration,
    });
  },

  switchRoleToGuesserDemo: () => {
    const state = get();
    const targetOption =
      state.activeDeck.find((w) => w.word === (state.actualWord || 'CAMPFIRE')) ||
      DEFAULT_WORD_DECK[0];
    const roundDuration = state.modifiers.speedBlitz ? 35 : 60;
    const botStrokes = buildProceduralSketchForWord(targetOption.word);

    soundEngine.playPopClick(1.15);
    set({
      phase: 'DRAWING',
      currentArtistId: 'bot-milo',
      actualWord: targetOption.word,
      wordDifficulty: targetOption.difficulty,
      wordPoints: targetOption.points,
      hiddenWord: maskTargetWord(targetOption.word, roundDuration, roundDuration),
      timeLeft: roundDuration,
      maxTime: roundDuration,
      canvasState: {
        strokes: botStrokes,
        backgroundColor: '#FFFFFF',
      },
      players: state.players.map((p) => ({
        ...p,
        hasGuessedCorrectly: false,
      })),
      messages: [
        ...state.messages,
        {
          id: `sys-role-guesser-${Date.now()}`,
          senderId: 'system',
          senderName: 'Studio Host',
          senderColor: '#10B981',
          text: `MiloSketch is now drawing! Type a near-miss or exact guess in the chat box to test Warm Guess & Asymmetric Secrecy.`,
          timestamp: Date.now(),
          channel: 'system',
          proximity: 'chat',
        },
      ],
    });
  },

  switchRoleToArtistDemo: () => {
    const state = get();
    const roundDuration = state.modifiers.speedBlitz ? 35 : 60;
    const actual = state.actualWord || 'CAMPFIRE';
    soundEngine.playPopClick(1.15);
    set({
      phase: 'DRAWING',
      currentArtistId: state.localPlayerId,
      timeLeft: roundDuration,
      maxTime: roundDuration,
      hiddenWord: maskTargetWord(actual, roundDuration, roundDuration),
      players: state.players.map((p) => ({
        ...p,
        hasGuessedCorrectly: false,
      })),
      messages: [
        ...state.messages,
        {
          id: `sys-role-artist-${Date.now()}`,
          senderId: 'system',
          senderName: 'Studio Host',
          senderColor: '#8B5CF6',
          text: `You are the Active Artist! Sketch "${actual}" on the canvas.`,
          timestamp: Date.now(),
          channel: 'system',
          proximity: 'chat',
        },
      ],
    });
  },

  setTool: (activeTool) => {
    soundEngine.playPopClick(1.0);
    set({ activeTool });
  },

  setColor: (activeColor) => {
    soundEngine.playPopClick(1.08);
    set({ activeColor, activeTool: get().activeTool === 'eraser' ? 'brush' : get().activeTool });
  },

  setBrushWidth: (brushWidth) => set({ brushWidth }),

  startLiveStroke: (pt) => {
    const state = get();
    if (state.phase !== 'DRAWING') return;
    // In One-Line Only modifier, if the artist already committed 1 stroke this round, block starting a second stroke
    if (state.modifiers.oneLineOnly && state.canvasState.strokes.length >= 1) {
      set({
        messages: [
          ...state.messages,
          {
            id: `sys-oneline-${Date.now()}`,
            senderId: 'system',
            senderName: 'One-Line Rule',
            senderColor: '#F59E0B',
            text: 'One-Line Only modifier is active! Clear the canvas to start a fresh continuous line.',
            timestamp: Date.now(),
            channel: 'private-warm',
            proximity: 'warm',
          },
        ],
      });
      return;
    }

    const stroke: DrawStroke = {
      id: `stroke-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      points: [pt],
      color: state.activeTool === 'eraser' ? state.canvasState.backgroundColor : state.activeColor,
      width: state.brushWidth,
      tool: state.activeTool,
      timestamp: Date.now(),
    };
    set({ activeLiveStroke: stroke });
  },

  appendLiveStroke: (pt) => {
    const live = get().activeLiveStroke;
    if (!live) return;
    const lastPt = live.points[live.points.length - 1];
    if (lastPt && Math.hypot(pt.x - lastPt.x, pt.y - lastPt.y) < 1.8) {
      return;
    }
    const updated: DrawStroke = {
      ...live,
      points: [...live.points, pt],
    };
    set({ activeLiveStroke: updated });
    broadcastNetworkPacket('stroke:live', get().roomId, updated);
  },

  commitLiveStroke: () => {
    const state = get();
    const live = state.activeLiveStroke;
    if (!live) return;

    const smoothedPoints = smoothStrokeCatmullRom(live.points, 4);
    const finalStroke: DrawStroke = {
      ...live,
      points: smoothedPoints,
      timestamp: Date.now(),
    };

    set({
      activeLiveStroke: null,
      canvasState: {
        ...state.canvasState,
        strokes: [...state.canvasState.strokes, finalStroke],
      },
    });

    broadcastNetworkPacket('stroke:commit', state.roomId, finalStroke);
  },

  clearCanvas: () => {
    const state = get();
    soundEngine.playPaperShakeClear();
    set({
      paperShakeTrigger: Date.now(),
      activeLiveStroke: null,
      canvasState: {
        strokes: [],
        backgroundColor: '#FFFFFF',
      },
    });
    broadcastNetworkPacket('canvas:clear', state.roomId, {});
  },

  floodFillCanvas: (color) => {
    const state = get();
    soundEngine.playPopClick(0.85);
    set({
      canvasState: {
        ...state.canvasState,
        backgroundColor: color,
      },
    });
    broadcastNetworkPacket('canvas:fill', state.roomId, { color });
  },

  submitGuessOrChat: (rawText, senderId) => {
    const text = rawText.trim();
    if (!text) return;

    const state = get();
    const activeSenderId = senderId || state.localPlayerId;
    const sender =
      state.players.find((p) => p.id === activeSenderId) || state.players[0];

    const targetWord = state.actualWord || 'CAMPFIRE';

    // If sender already guessed correctly, route to private Spectator channel (Asymmetric Guess Secrecy)
    if (sender.hasGuessedCorrectly) {
      const specMsg: ChatMessage = {
        id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        senderId: sender.id,
        senderName: sender.username,
        senderColor: sender.avatarColor,
        text,
        timestamp: Date.now(),
        channel: 'spectator',
        proximity: 'chat',
      };
      set({ messages: [...state.messages, specMsg] });
      return;
    }

    const { proximity, editDistance } = evaluateGuessProximity(text, targetWord);

    if (proximity === 'exact' && state.phase === 'DRAWING') {
      const alreadyCorrectCount = state.players.filter((p) => p.hasGuessedCorrectly).length;
      const { guesserPoints, artistBonus } = calculateGuessScore({
        basePoints: state.wordPoints,
        timeLeft: state.timeLeft,
        maxTime: state.maxTime,
        guessOrderIndex: alreadyCorrectCount,
        modifiers: state.modifiers,
      });

      soundEngine.playCorrectGuessFanfare();

      const updatedPlayers = state.players.map((p) => {
        if (p.id === sender.id) {
          return {
            ...p,
            score: p.score + guesserPoints,
            roundScoreDelta: p.roundScoreDelta + guesserPoints,
            streak: p.streak + 1,
            hasGuessedCorrectly: true,
          };
        }
        if (p.id === state.currentArtistId && sender.id !== state.currentArtistId) {
          return {
            ...p,
            score: p.score + artistBonus,
            roundScoreDelta: p.roundScoreDelta + artistBonus,
          };
        }
        return p;
      });

      const exactMsg: ChatMessage = {
        id: `msg-exact-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        senderId: sender.id,
        senderName: sender.username,
        senderColor: '#10B981',
        text: `${sender.username} locked in the exact word! (+${guesserPoints} pts) — shifted to Spectator Chat`,
        timestamp: Date.now(),
        channel: 'spectator',
        proximity: 'exact',
        pointsAwarded: guesserPoints,
      };

      set({
        players: updatedPlayers,
        messages: [...state.messages, exactMsg],
        lastFloatingScore: {
          playerId: sender.id,
          delta: guesserPoints,
          key: Date.now(),
        },
      });

      broadcastNetworkPacket('guess:exact', state.roomId, {
        senderId: sender.id,
        guesserPoints,
        artistBonus,
      });
      return;
    }

    if ((proximity === 'warm' || proximity === 'close') && state.phase === 'DRAWING') {
      soundEngine.playWarmGuessChime();
      const warmMsg: ChatMessage = {
        id: `msg-warm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        senderId: sender.id,
        senderName: sender.username,
        senderColor: '#F59E0B',
        text:
          proximity === 'warm'
            ? `"${text.toUpperCase()}" — You're super close! (1 letter away — private hint)`
            : `"${text.toUpperCase()}" — Getting warm! (2 letters off — private hint)`,
        timestamp: Date.now(),
        channel: 'private-warm',
        proximity,
        editDistance,
      };
      set({ messages: [...state.messages, warmMsg] });
      return;
    }

    const publicMsg: ChatMessage = {
      id: `msg-pub-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      senderId: sender.id,
      senderName: sender.username,
      senderColor: sender.avatarColor,
      text,
      timestamp: Date.now(),
      channel: 'public',
      proximity: 'cold',
    };
    set({ messages: [...state.messages, publicMsg] });
    broadcastNetworkPacket('chat:public', state.roomId, publicMsg);
  },

  toggleModifier: (key) => {
    soundEngine.playPopClick(1.1);
    set((state) => ({
      modifiers: {
        ...state.modifiers,
        [key]: !state.modifiers[key],
      },
    }));
  },

  importCustomDeck: (rawText, deckName = 'Inside-Joke Custom Pack') => {
    const parsed = parseCustomWordDeck(rawText, deckName);
    if (parsed.length === 0) return;
    soundEngine.playCorrectGuessFanfare();
    const merged = [...parsed, ...DEFAULT_WORD_DECK];
    set({
      activeDeck: merged,
      customDeckName: deckName,
      customWordsCount: parsed.length,
      wordChoices: pickThreeTieredWords(merged, 0),
      messages: [
        ...get().messages,
        {
          id: `sys-deck-${Date.now()}`,
          senderId: 'system',
          senderName: 'Deck Builder',
          senderColor: '#10B981',
          text: `Loaded "${deckName}" with ${parsed.length} custom words!`,
          timestamp: Date.now(),
          channel: 'system',
          proximity: 'chat',
        },
      ],
    });
  },

  generateGeminiDeck: async (theme) => {
    const cleanTheme = theme.trim() || 'Late Night Party Chaos';
    set({ isGeneratingDeck: true });
    try {
      const resp = await fetch('/api/gemini/deck', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ theme: cleanTheme }),
      });
      const data = await resp.json();
      if (Array.isArray(data.words) && data.words.length > 0) {
        const merged = [...data.words, ...DEFAULT_WORD_DECK];
        soundEngine.playCorrectGuessFanfare();
        set({
          activeDeck: merged,
          customDeckName: data.deckName || `${cleanTheme} Deck`,
          customWordsCount: data.words.length,
          wordChoices: pickThreeTieredWords(merged, 0),
          isGeneratingDeck: false,
          messages: [
            ...get().messages,
            {
              id: `sys-gem-deck-${Date.now()}`,
              senderId: 'system',
              senderName: 'Gemini Deck Architect',
              senderColor: '#8B5CF6',
              text: `Generated ${data.words.length} themed words for "${cleanTheme}" (${data.modelUsed})!`,
              timestamp: Date.now(),
              channel: 'system',
              proximity: 'chat',
            },
          ],
        });
        return;
      }
      set({ isGeneratingDeck: false });
    } catch {
      set({ isGeneratingDeck: false });
    }
  },

  generateGeminiStudioArt: async (prompt, size) => {
    const cleanPrompt = prompt.trim() || get().actualWord || 'CAMPFIRE';
    set({ isGeneratingArt: true });
    try {
      const resp = await fetch('/api/gemini/art', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: cleanPrompt, imageSize: size }),
      });
      const data = await resp.json();
      if (data.imageUrl) {
        const item: GeneratedStudioArt = {
          id: `art-${Date.now()}`,
          prompt: cleanPrompt,
          imageSize: size,
          imageUrl: data.imageUrl,
          createdAt: Date.now(),
          modelUsed: data.modelUsed || 'gemini-3-pro-image',
          note: data.note,
        };
        soundEngine.playCorrectGuessFanfare();
        set((state) => ({
          isGeneratingArt: false,
          studioArtGallery: [item, ...state.studioArtGallery],
        }));
        return;
      }
      set({ isGeneratingArt: false });
    } catch {
      set({ isGeneratingArt: false });
    }
  },

  requestGeminiCritic: async (canvasDataUrl) => {
    const state = get();
    set({ isAskingCritic: true });
    try {
      const resp = await fetch('/api/gemini/critic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: canvasDataUrl,
          category: state.wordDifficulty,
          strokeCount: state.canvasState.strokes.length,
        }),
      });
      const data = await resp.json();
      if (data.commentary) {
        soundEngine.playPopClick(1.25);
        set({
          aiHostComment: data.commentary,
          isAskingCritic: false,
          messages: [
            ...get().messages,
            {
              id: `sys-critic-${Date.now()}`,
              senderId: 'system',
              senderName: 'Gemini Studio Host',
              senderColor: '#8B5CF6',
              text: data.commentary,
              timestamp: Date.now(),
              channel: 'system',
              proximity: 'chat',
            },
          ],
        });
        return;
      }
      set({ isAskingCritic: false });
    } catch {
      set({ isAskingCritic: false });
    }
  },

  setDualScreenMode: (dualScreenMode) => {
    soundEngine.playPopClick(1.05);
    set({ dualScreenMode });
  },

  toggleMute: () => {
    const muted = soundEngine.toggleMute();
    set({ muted });
  },

  triggerRoundRecapNow: () => {
    const state = get();
    const artist =
      state.players.find((p) => p.id === state.currentArtistId) || state.players[0];
    const strokesToReplay =
      state.canvasState.strokes.length > 0
        ? state.canvasState.strokes
        : buildProceduralSketchForWord(state.actualWord || 'CAMPFIRE');

    const record = {
      roundNumber: state.round.current,
      artistName: artist.username,
      word: state.actualWord || 'CAMPFIRE',
      difficulty: state.wordDifficulty,
      strokes: strokesToReplay,
      backgroundColor: state.canvasState.backgroundColor,
      fastestGuesser:
        state.players.find((p) => p.hasGuessedCorrectly)?.username || 'MiloSketch',
      totalCorrectGuesses: Math.max(
        1,
        state.players.filter((p) => p.hasGuessedCorrectly).length,
      ),
    };

    soundEngine.playCorrectGuessFanfare();

    set({
      phase: 'ROUND_RECAP',
      timeLeft: 6,
      maxTime: 6,
      canvasState: {
        ...state.canvasState,
        strokes: strokesToReplay,
      },
      roundHistory: [...state.roundHistory, record],
    });
  },

  advanceFromRecap: () => {
    const state = get();
    if (state.round.current >= state.round.total) {
      if (typeof document !== 'undefined') {
        document.body.dataset.state = 'gameover';
      }
      soundEngine.playCorrectGuessFanfare();
      set({
        phase: 'GAME_OVER',
        shellState: 'gameover',
      });
      return;
    }

    const nextRoundNum = state.round.current + 1;
    const nextChoices = pickThreeTieredWords(state.activeDeck, nextRoundNum);
    // Rotate artist among players
    const currIdx = state.players.findIndex((p) => p.id === state.currentArtistId);
    const nextArtist = state.players[(currIdx + 1) % state.players.length] || state.players[0];

    set({
      round: { ...state.round, current: nextRoundNum },
      phase: 'WORD_SELECTION',
      currentArtistId: nextArtist.id,
      timeLeft: 10,
      maxTime: 10,
      wordChoices: nextChoices,
      canvasState: { strokes: [], backgroundColor: '#FFFFFF' },
      players: state.players.map((p) => ({
        ...p,
        hasGuessedCorrectly: false,
        roundScoreDelta: 0,
      })),
    });
  },

  tickSecond: () => {
    const state = get();
    if (state.shellState !== 'playing') return;

    if (state.phase === 'WORD_SELECTION') {
      if (state.timeLeft <= 1) {
        const autoChoice =
          (state.wordChoices && state.wordChoices[0]) || DEFAULT_WORD_DECK[0];
        state.selectWord(autoChoice);
      } else {
        set({ timeLeft: state.timeLeft - 1 });
      }
      return;
    }

    if (state.phase === 'DRAWING') {
      const nextTime = state.timeLeft - 1;

      // Dynamic Time-Crunch Juice (< 15 seconds heartbeat audio tick)
      if (nextTime <= 15 && nextTime > 0) {
        soundEngine.playHeartbeatTick(nextTime <= 7);
      }

      // Friendly Studio Bot guesses as the drawing progresses so the chat & scoreboard feel alive
      const word = state.actualWord || 'CAMPFIRE';
      if (nextTime === state.maxTime - 12 && state.canvasState.strokes.length > 0) {
        const nearMiss =
          word.length > 4
            ? word.slice(0, word.length - 1)
            : `${word}S`;
        set((s) => ({
          messages: [
            ...s.messages,
            {
              id: `bot-chat-${Date.now()}`,
              senderId: 'bot-nova',
              senderName: 'NovaPixel',
              senderColor: '#F59E0B',
              text: `Wait is that ${nearMiss.toLowerCase()}??`,
              timestamp: Date.now(),
              channel: 'public',
              proximity: 'cold',
            },
          ],
        }));
      }

      if (nextTime === state.maxTime - 22 && state.canvasState.strokes.length > 0) {
        const milo = state.players.find((p) => p.id === 'bot-milo');
        if (milo && !milo.hasGuessedCorrectly && state.currentArtistId !== 'bot-milo') {
          state.submitGuessOrChat(word, 'bot-milo');
        }
      }

      if (nextTime <= 0) {
        state.triggerRoundRecapNow();
        return;
      }

      set({
        timeLeft: nextTime,
        hiddenWord: maskTargetWord(word, nextTime, state.maxTime),
      });
      return;
    }
  },

  connectRealtimeRoom: (roomId) => {
    if (typeof window === 'undefined') return;

    try {
      if (broadcastChan) broadcastChan.close();
      broadcastChan = new BroadcastChannel(`sketchblitz-${roomId}`);
      broadcastChan.onmessage = (ev) => {
        const { type, payload } = ev.data ?? {};
        if (type === 'stroke:live' && payload) {
          set({ activeLiveStroke: payload as DrawStroke });
        } else if (type === 'stroke:commit' && payload) {
          const stroke = payload as DrawStroke;
          set((s) => {
            if (s.canvasState.strokes.some((st) => st.id === stroke.id)) return s;
            return {
              activeLiveStroke: null,
              canvasState: {
                ...s.canvasState,
                strokes: [...s.canvasState.strokes, stroke],
              },
            };
          });
        } else if (type === 'canvas:clear') {
          set({
            activeLiveStroke: null,
            canvasState: { strokes: [], backgroundColor: '#FFFFFF' },
          });
        } else if (type === 'canvas:fill' && payload?.color) {
          set((s) => ({
            canvasState: { ...s.canvasState, backgroundColor: payload.color },
          }));
        } else if (type === 'chat:public' && payload) {
          const msg = payload as ChatMessage;
          set((s) => {
            if (s.messages.some((m) => m.id === msg.id)) return s;
            return { messages: [...s.messages, msg] };
          });
        }
      };
    } catch {}

    try {
      if (wsClient) wsClient.close();
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      wsClient = new WebSocket(`${proto}//${window.location.host}/ws`);
      wsClient.onopen = () => {
        wsClient?.send(JSON.stringify({ type: 'room:join', roomId }));
      };
      wsClient.onmessage = (ev) => {
        try {
          const { type, payload } = JSON.parse(String(ev.data));
          if (type === 'stroke:live' && payload) {
            set({ activeLiveStroke: payload as DrawStroke });
          } else if (type === 'stroke:commit' && payload) {
            const stroke = payload as DrawStroke;
            set((s) => {
              if (s.canvasState.strokes.some((st) => st.id === stroke.id)) return s;
              return {
                activeLiveStroke: null,
                canvasState: {
                  ...s.canvasState,
                  strokes: [...s.canvasState.strokes, stroke],
                },
              };
            });
          } else if (type === 'canvas:clear') {
            set({
              activeLiveStroke: null,
              canvasState: { strokes: [], backgroundColor: '#FFFFFF' },
            });
          } else if (type === 'canvas:fill' && payload?.color) {
            set((s) => ({
              canvasState: { ...s.canvasState, backgroundColor: payload.color },
            }));
          } else if (type === 'chat:public' && payload) {
            const msg = payload as ChatMessage;
            set((s) => {
              if (s.messages.some((m) => m.id === msg.id)) return s;
              return { messages: [...s.messages, msg] };
            });
          }
        } catch {}
      };
    } catch {}
  },
}));
