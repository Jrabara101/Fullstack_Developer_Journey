package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NavigationTab
import com.example.ui.LoomViewModel
import com.example.ui.components.LoomBottomNavBar
import com.example.ui.components.LoomMainHeader
import com.example.ui.screens.CanvasStudioScreen
import com.example.ui.screens.Drape3DViewportScreen
import com.example.ui.screens.ExportStudioScreen
import com.example.ui.screens.MotifStudioScreen
import com.example.ui.screens.PaletteStudioScreen
import com.example.ui.screens.PenStudioScreen
import com.example.ui.theme.LoomBackground
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnSecondary
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow
import com.example.ui.theme.LoomSurfaceContainerLowest
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LoomViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                LoomAppRoot(viewModel)
            }
        }
    }
}

@Composable
fun LoomAppRoot(viewModel: LoomViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()
    val notification by viewModel.statusNotification.collectAsState()
    val apiKey by viewModel.geminiApiKey.collectAsState()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var keyInputValue by remember { mutableStateOf(apiKey) }

    // BackHandler: if on any sub-screen, return to SELECT
    BackHandler(enabled = currentTab != NavigationTab.SELECT) {
        viewModel.selectTab(NavigationTab.SELECT)
    }

    // Auto-clear transient status notification
    LaunchedEffect(notification) {
        if (notification != null) {
            kotlinx.coroutines.delay(3500)
            viewModel.clearNotification()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(LoomBackground),
        topBar = {
            if (currentTab != NavigationTab.VIEW_3D) {
                LoomMainHeader(
                    repeatMode = repeatMode,
                    onRepeatClick = {
                        viewModel.showNotification("Repeat system: Toroidal Half-Drop Active")
                    },
                    onSettingsClick = {
                        keyInputValue = apiKey
                        showSettingsDialog = true
                    },
                    onProfileClick = {
                        showProfileDialog = true
                    },
                    modifier = Modifier.statusBarsPadding()
                )
            }
        },
        bottomBar = {
            LoomBottomNavBar(
                selectedTab = currentTab,
                onTabSelected = { tab ->
                    viewModel.selectTab(tab)
                }
            )
        },
        containerColor = LoomBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Screen Routing
            when (currentTab) {
                NavigationTab.SELECT -> {
                    CanvasStudioScreen(viewModel = viewModel)
                }
                NavigationTab.VIEW_3D -> {
                    Drape3DViewportScreen(viewModel = viewModel)
                }
                NavigationTab.MOTIF -> {
                    MotifStudioScreen(viewModel = viewModel)
                }
                NavigationTab.PEN -> {
                    PenStudioScreen(viewModel = viewModel)
                }
                NavigationTab.PALETTE -> {
                    PaletteStudioScreen(viewModel = viewModel)
                }
                NavigationTab.EXPORT -> {
                    ExportStudioScreen(viewModel = viewModel)
                }
            }

            // In-App Toast Notification Banner
            AnimatedVisibility(
                visible = notification != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                notification?.let { msg ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(LoomSurfaceContainerHighest.copy(alpha = 0.98f))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(LoomSecondary)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = msg,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = LoomOnSurface
                        )
                    }
                }
            }
        }
    }

    // Settings / API Key Dialog
    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = LoomSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = "Studio Settings & AI Key",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LoomOnSurface
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Gemini 3.1 Flash Image model generates and edits photorealistic Bauhaus textiles.",
                        fontSize = 12.sp,
                        color = LoomOnSurfaceVariant
                    )
                    OutlinedTextField(
                        value = keyInputValue,
                        onValueChange = { keyInputValue = it },
                        label = { Text("Gemini API Key", fontSize = 11.sp) },
                        placeholder = { Text("AIzaSy...", fontSize = 11.sp, color = LoomOutline) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LoomSecondary,
                            unfocusedBorderColor = LoomSurfaceContainerHighest,
                            focusedTextColor = LoomOnSurface,
                            unfocusedTextColor = LoomOnSurface
                        ),
                        singleLine = true
                    )
                    Text(
                        text = "Keys can also be configured via AI Studio Secrets Panel.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setCustomApiKey(keyInputValue)
                        showSettingsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LoomSecondary)
                ) {
                    Text("Save", color = LoomOnSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) {
                    Text("Close", color = LoomOnSurfaceVariant, fontSize = 12.sp)
                }
            },
            containerColor = LoomSurfaceContainer
        )
    }

    // Profile / Atelier Info Dialog
    if (showProfileDialog) {
        AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            title = {
                Text(
                    text = "Bauhaus Loom Atelier",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoomOnSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Designer: Bauhaus Textile Workshop",
                        fontSize = 12.sp,
                        color = LoomOnSurface
                    )
                    Text(
                        text = "Engine: Realtime PBR Jacquard Physics · 240 WPI",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = LoomSecondary
                    )
                    Text(
                        text = "Generative Model: gemini-3.1-flash-image-preview",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = LoomPrimary
                    )
                    Text(
                        text = "Platform: Android Jetpack Compose Studio",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showProfileDialog = false }) {
                    Text("Done", color = LoomPrimary, fontSize = 12.sp)
                }
            },
            containerColor = LoomSurfaceContainer
        )
    }
}
