package com.example.data.gemini

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiImageService {
    private const val MODEL_NAME = "gemini-3.1-flash-image-preview"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getResolvedApiKey(userCustomKey: String?): String {
        val custom = userCustomKey?.trim().orEmpty()
        if (custom.isNotEmpty() && custom != "MY_GEMINI_API_KEY") return custom

        return try {
            val buildConfigKey = BuildConfig.GEMINI_API_KEY
            if (buildConfigKey.isNotEmpty() && buildConfigKey != "MY_GEMINI_API_KEY") {
                buildConfigKey
            } else {
                ""
            }
        } catch (e: Throwable) {
            ""
        }
    }

    suspend fun generateOrEditImage(
        prompt: String,
        base64InputImage: String? = null,
        userCustomKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getResolvedApiKey(userCustomKey)
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is required. Please provide a key in the AI studio panel or settings.")
            )
        }

        try {
            val endpoint = "$BASE_URL/$MODEL_NAME:generateContent?key=$apiKey"

            // Construct contents
            val partsArray = JSONArray()

            // Text prompt instruction
            val textPart = JSONObject().apply {
                put("text", prompt)
            }
            partsArray.put(textPart)

            // If editing an existing image, include inlineData
            if (!base64InputImage.isNullOrBlank()) {
                val inlineData = JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64InputImage)
                }
                val imagePart = JSONObject().apply {
                    put("inlineData", inlineData)
                }
                partsArray.put(imagePart)
            }

            val contentObj = JSONObject().apply {
                put("parts", partsArray)
            }

            val contentsArray = JSONArray().apply {
                put(contentObj)
            }

            // Generation config with IMAGE modality
            val imageConfig = JSONObject().apply {
                put("aspectRatio", "1:1")
                put("imageSize", "1K")
            }

            val responseModalities = JSONArray().apply {
                put("TEXT")
                put("IMAGE")
            }

            val generationConfig = JSONObject().apply {
                put("imageConfig", imageConfig)
                put("responseModalities", responseModalities)
            }

            val requestJson = JSONObject().apply {
                put("contents", contentsArray)
                put("generationConfig", generationConfig)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMessage = try {
                    val errorJson = JSONObject(responseString)
                    errorJson.optJSONObject("error")?.optString("message")
                        ?: "HTTP ${response.code}: $responseString"
                } catch (e: Exception) {
                    "HTTP ${response.code}: $responseString"
                }
                return@withContext Result.failure(Exception(errorMessage))
            }

            val responseJson = JSONObject(responseString)
            val candidates = responseJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(Exception("No image candidates returned from model."))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val parts = firstCandidate.optJSONObject("content")?.optJSONArray("parts")
            if (parts == null || parts.length() == 0) {
                return@withContext Result.failure(Exception("No content parts in candidate response."))
            }

            var generatedBase64: String? = null
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val inlineData = part.optJSONObject("inlineData")
                if (inlineData != null) {
                    val data = inlineData.optString("data")
                    if (data.isNotEmpty()) {
                        generatedBase64 = data
                        break
                    }
                }
            }

            if (generatedBase64 != null) {
                Result.success(generatedBase64)
            } else {
                Result.failure(Exception("Model responded without inline image data."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    fun base64ToBitmap(base64: String): Bitmap? {
        return try {
            val decodedBytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
        } catch (e: Exception) {
            null
        }
    }
}
