package com.example.data.model

enum class VectorMotifType {
    ARCH,
    CONCENTRIC_CORE,
    CHEVRON,
    WRAP_PIP,
    GENERATED_AI
}

data class LoomMotif(
    val id: String,
    val name: String,
    val blendMode: String = "Pass-Through",
    val opacity: Float = 0.85f,
    val x: Float = 128f,
    val y: Float = 256f,
    val width: Float = 172.5f,
    val height: Float = 172.5f,
    val rotation: Float = 0f,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val isSelected: Boolean = false,
    val type: VectorMotifType = VectorMotifType.ARCH,
    val primaryColorHex: String = "#4CD7F6",
    val secondaryColorHex: String = "#D0BCFF",
    val prompt: String? = null,
    val imageBase64: String? = null
)

data class Colorway(
    val id: String,
    val name: String,
    val colors: List<String>,
    val isHarmonyLocked: Boolean = true,
    val isLiveSync: Boolean = true
)

enum class CameraAngle(val label: String, val rotationX: Float, val rotationY: Float, val scale: Float) {
    FRONT("Front", 0f, 0f, 1.0f),
    DRAPE_45("Drape 45°", 18f, -15f, 1.08f),
    MICRO_10X("Micro 10x", 8f, -4f, 2.1f),
    TOP_DOWN("Top-down", 45f, 0f, 0.92f)
}

data class Substrate(
    val id: String,
    val name: String,
    val bending: String,
    val weight: String,
    val symbol: String
)

data class PhysicsState(
    val sheenPercent: Int = 78,
    val stiffnessPercent: Int = 32,
    val elasticityPercent: Int = 64,
    val isWindActive: Boolean = true,
    val lightingRig: String = "Softbox 5200K",
    val selectedSubstrate: Substrate = Substrate(
        id = "mulberry",
        name = "Mulberry Silk",
        bending = "Low",
        weight = "120gsm",
        symbol = "✦"
    ),
    val activeCameraAngle: CameraAngle = CameraAngle.DRAPE_45,
    val warpCount: Int = 420,
    val tpi: Int = 28,
    val twistType: String = "S-Twist",
    val stressKPa: Float = 14.8f,
    val fps: Float = 60.2f
)

enum class NavigationTab(val label: String, val route: String) {
    SELECT("Select", "canvas-studio"),
    PEN("Pen", "vector-pen"),
    MOTIF("Motif", "geometric-motifs"),
    PALETTE("Palette", "colorway-studio"),
    VIEW_3D("3D View", "draped-render"),
    EXPORT("Export", "technical-spec")
}

sealed class GenerationState {
    object Idle : GenerationState()
    data class Generating(val prompt: String) : GenerationState()
    data class Success(val prompt: String, val imageBase64: String) : GenerationState()
    data class Error(val message: String) : GenerationState()
}
