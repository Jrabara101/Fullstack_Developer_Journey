package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.gemini.GeminiImageService
import com.example.data.model.CameraAngle
import com.example.data.model.Colorway
import com.example.data.model.GenerationState
import com.example.data.model.LoomMotif
import com.example.data.model.NavigationTab
import com.example.data.model.PhysicsState
import com.example.data.model.Substrate
import com.example.data.model.VectorMotifType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class LoomViewModel : ViewModel() {

    private val _currentTab = MutableStateFlow(NavigationTab.SELECT)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _repeatMode = MutableStateFlow("Half-Drop")
    val repeatMode: StateFlow<String> = _repeatMode.asStateFlow()

    private val _zoomPercent = MutableStateFlow(125)
    val zoomPercent: StateFlow<Int> = _zoomPercent.asStateFlow()

    private val _snapGridPx = MutableStateFlow(8)
    val snapGridPx: StateFlow<Int> = _snapGridPx.asStateFlow()

    private val _guidesActive = MutableStateFlow(true)
    val guidesActive: StateFlow<Boolean> = _guidesActive.asStateFlow()

    private val _toroidalSeamsActive = MutableStateFlow(true)
    val toroidalSeamsActive: StateFlow<Boolean> = _toroidalSeamsActive.asStateFlow()

    // Default Bauhaus Flora v2 motifs
    private val initialMotifs = listOf(
        LoomMotif(
            id = "motif_arch",
            name = "Motif_04_Arch",
            blendMode = "Pass-Through",
            opacity = 0.85f,
            x = 128.0f,
            y = 256.0f,
            width = 172.5f,
            height = 172.5f,
            rotation = 0f,
            isVisible = true,
            isLocked = false,
            isSelected = true,
            type = VectorMotifType.ARCH,
            primaryColorHex = "#4CD7F6",
            secondaryColorHex = "#D0BCFF"
        ),
        LoomMotif(
            id = "motif_sun",
            name = "Motif_02_ConcentricSun",
            blendMode = "Pass-Through",
            opacity = 0.95f,
            x = 128.0f,
            y = 190.0f,
            width = 128.0f,
            height = 128.0f,
            rotation = 0f,
            isVisible = true,
            isLocked = false,
            isSelected = false,
            type = VectorMotifType.CONCENTRIC_CORE,
            primaryColorHex = "#D0BCFF",
            secondaryColorHex = "#4CD7F6"
        ),
        LoomMotif(
            id = "motif_chevron",
            name = "Motif_01_ChevronStep",
            blendMode = "Screen",
            opacity = 0.80f,
            x = 128.0f,
            y = 390.0f,
            width = 160.0f,
            height = 80.0f,
            rotation = 0f,
            isVisible = true,
            isLocked = false,
            isSelected = false,
            type = VectorMotifType.CHEVRON,
            primaryColorHex = "#D3E4FE",
            secondaryColorHex = "#4CD7F6"
        ),
        LoomMotif(
            id = "motif_wrap",
            name = "Motif_03_ToroidalSeam",
            blendMode = "Multiply",
            opacity = 0.90f,
            x = 128.0f,
            y = 0.0f,
            width = 80.0f,
            height = 40.0f,
            rotation = 0f,
            isVisible = true,
            isLocked = false,
            isSelected = false,
            type = VectorMotifType.WRAP_PIP,
            primaryColorHex = "#C0C1FF",
            secondaryColorHex = "#8083FF"
        )
    )

    private val _motifs = MutableStateFlow<List<LoomMotif>>(initialMotifs)
    val motifs: StateFlow<List<LoomMotif>> = _motifs.asStateFlow()

    private val _selectedMotifId = MutableStateFlow("motif_arch")
    val selectedMotifId: StateFlow<String> = _selectedMotifId.asStateFlow()

    private val _activeDrawerTab = MutableStateFlow(0) // 0: Layers, 1: Weimar Nocturne, 2: Cloth Sim
    val activeDrawerTab: StateFlow<Int> = _activeDrawerTab.asStateFlow()

    private val _colorway = MutableStateFlow(
        Colorway(
            id = "weimar_nocturne",
            name = "Weimar Nocturne",
            colors = listOf("#D0BCFF", "#4CD7F6", "#C0C1FF", "#2A3A4F", "#D3E4FE"),
            isHarmonyLocked = true,
            isLiveSync = true
        )
    )
    val colorway: StateFlow<Colorway> = _colorway.asStateFlow()

    private val _physicsState = MutableStateFlow(PhysicsState())
    val physicsState: StateFlow<PhysicsState> = _physicsState.asStateFlow()

    private val _geminiApiKey = MutableStateFlow("")
    val geminiApiKey: StateFlow<String> = _geminiApiKey.asStateFlow()

    private val _generationState = MutableStateFlow<GenerationState>(GenerationState.Idle)
    val generationState: StateFlow<GenerationState> = _generationState.asStateFlow()

    private val _aiMotifsHistory = MutableStateFlow<List<LoomMotif>>(emptyList())
    val aiMotifsHistory: StateFlow<List<LoomMotif>> = _aiMotifsHistory.asStateFlow()

    private val _statusNotification = MutableStateFlow<String?>(null)
    val statusNotification: StateFlow<String?> = _statusNotification.asStateFlow()

    val availableSubstrates = listOf(
        Substrate("mulberry", "Mulberry Silk", "Low", "120gsm", "✦"),
        Substrate("linen", "Heavy Linen (380gsm)", "High", "380gsm", "▨"),
        Substrate("cotton", "Mercerized Cotton", "Medium", "180gsm", "::"),
        Substrate("wool", "Wool Twill", "Medium-High", "320gsm", "≈")
    )

    val lightingRigs = listOf(
        "Softbox 5200K",
        "Atelier Skylight 6500K",
        "Tungsten Rim 3200K",
        "High-Contrast Studio"
    )

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun selectMotif(id: String) {
        _selectedMotifId.value = id
        _motifs.update { list ->
            list.map { it.copy(isSelected = (it.id == id)) }
        }
    }

    fun updateMotifPosition(id: String, deltaX: Float, deltaY: Float) {
        _motifs.update { list ->
            list.map {
                if (it.id == id && !it.isLocked) {
                    val snap = _snapGridPx.value
                    val newX = (it.x + deltaX).coerceIn(0f, 512f)
                    val newY = (it.y + deltaY).coerceIn(0f, 512f)
                    val snappedX = if (snap > 1) (Math.round(newX / snap) * snap).toFloat() else newX
                    val snappedY = if (snap > 1) (Math.round(newY / snap) * snap).toFloat() else newY
                    it.copy(x = snappedX, y = snappedY)
                } else it
            }
        }
    }

    fun updateMotifScale(id: String, scaleFactor: Float) {
        _motifs.update { list ->
            list.map {
                if (it.id == id && !it.isLocked) {
                    val newW = (it.width * scaleFactor).coerceIn(40f, 400f)
                    val newH = (it.height * scaleFactor).coerceIn(40f, 400f)
                    it.copy(width = newW, height = newH)
                } else it
            }
        }
    }

    fun updateMotifRotation(id: String, deltaDeg: Float) {
        _motifs.update { list ->
            list.map {
                if (it.id == id && !it.isLocked) {
                    it.copy(rotation = (it.rotation + deltaDeg) % 360f)
                } else it
            }
        }
    }

    fun toggleMotifVisibility(id: String) {
        _motifs.update { list ->
            list.map {
                if (it.id == id) it.copy(isVisible = !it.isVisible) else it
            }
        }
    }

    fun toggleMotifLock(id: String) {
        _motifs.update { list ->
            list.map {
                if (it.id == id) it.copy(isLocked = !it.isLocked) else it
            }
        }
    }

    fun setDrawerTab(tabIndex: Int) {
        _activeDrawerTab.value = tabIndex
    }

    fun toggleHarmonyLock() {
        _colorway.update { it.copy(isHarmonyLocked = !it.isHarmonyLocked) }
    }

    fun toggleLiveSync() {
        _colorway.update { it.copy(isLiveSync = !it.isLiveSync) }
    }

    fun updateColorSwatch(index: Int, newHex: String) {
        _colorway.update { current ->
            val list = current.colors.toMutableList()
            if (index in list.indices) {
                list[index] = newHex
            }
            current.copy(colors = list)
        }
    }

    fun setPhysicsSheen(percent: Int) {
        _physicsState.update { it.copy(sheenPercent = percent.coerceIn(0, 100)) }
    }

    fun setPhysicsStiffness(percent: Int) {
        _physicsState.update { it.copy(stiffnessPercent = percent.coerceIn(0, 100)) }
    }

    fun setPhysicsElasticity(percent: Int) {
        _physicsState.update { it.copy(elasticityPercent = percent.coerceIn(0, 100)) }
    }

    fun toggleWindActive() {
        _physicsState.update { it.copy(isWindActive = !it.isWindActive) }
    }

    fun setLightingRig(rig: String) {
        _physicsState.update { it.copy(lightingRig = rig) }
    }

    fun setSubstrate(substrate: Substrate) {
        _physicsState.update { it.copy(selectedSubstrate = substrate) }
    }

    fun setCameraAngle(angle: CameraAngle) {
        _physicsState.update { it.copy(activeCameraAngle = angle) }
    }

    fun resetPhysicsDefaults() {
        _physicsState.value = PhysicsState()
        showNotification("Physics parameters reset to default atelier values")
    }

    fun toggleToroidalSeams() {
        _toroidalSeamsActive.value = !_toroidalSeamsActive.value
    }

    fun toggleGuides() {
        _guidesActive.value = !_guidesActive.value
    }

    fun centerActiveMotif() {
        _motifs.update { list ->
            list.map {
                if (it.id == _selectedMotifId.value) {
                    it.copy(x = 128f, y = 256f, rotation = 0f)
                } else it
            }
        }
        showNotification("Re-centered motif to canvas center coordinate (128, 256)")
    }

    fun setCustomApiKey(key: String) {
        _geminiApiKey.value = key
        showNotification("API Key updated")
    }

    fun generateAiMotif(prompt: String) {
        viewModelScope.launch {
            _generationState.value = GenerationState.Generating(prompt)
            val result = GeminiImageService.generateOrEditImage(
                prompt = "High-fashion Bauhaus jacquard textile pattern repeat, $prompt, architectural geometry, electric cyan, periwinkle, lavender, luxury loom weave texture, 4k detail, seamless studio cloth",
                base64InputImage = null,
                userCustomKey = _geminiApiKey.value
            )

            result.onSuccess { base64 ->
                _generationState.value = GenerationState.Success(prompt, base64)
                val newMotif = LoomMotif(
                    id = "ai_${UUID.randomUUID()}",
                    name = "AI_${prompt.take(12).replace(" ", "_")}",
                    blendMode = "Pass-Through",
                    opacity = 1.0f,
                    x = 128f,
                    y = 256f,
                    width = 200f,
                    height = 200f,
                    rotation = 0f,
                    type = VectorMotifType.GENERATED_AI,
                    prompt = prompt,
                    imageBase64 = base64
                )
                _aiMotifsHistory.update { listOf(newMotif) + it }
                showNotification("Generated new Bauhaus textile motif!")
            }.onFailure { err ->
                _generationState.value = GenerationState.Error(err.message ?: "Failed to generate motif image")
            }
        }
    }

    fun editAiMotif(motif: LoomMotif, editInstruction: String) {
        viewModelScope.launch {
            _generationState.value = GenerationState.Generating(editInstruction)
            val inputBase64 = motif.imageBase64
            val result = GeminiImageService.generateOrEditImage(
                prompt = "Modify this Bauhaus jacquard textile: $editInstruction. Keep high weave density and atelier luxury quality.",
                base64InputImage = inputBase64,
                userCustomKey = _geminiApiKey.value
            )

            result.onSuccess { newBase64 ->
                _generationState.value = GenerationState.Success(editInstruction, newBase64)
                val updated = motif.copy(
                    id = "ai_${UUID.randomUUID()}",
                    name = "${motif.name}_v2",
                    prompt = editInstruction,
                    imageBase64 = newBase64
                )
                _aiMotifsHistory.update { listOf(updated) + it }
                // Also update the motif in active motifs list if matching
                _motifs.update { list ->
                    list.map { if (it.id == motif.id) updated else it }
                }
                showNotification("Textile edited with Gemini 3.1 Flash Image!")
            }.onFailure { err ->
                _generationState.value = GenerationState.Error(err.message ?: "Failed to edit image")
            }
        }
    }

    fun applyMotifToCanvas(motif: LoomMotif) {
        _motifs.update { current ->
            // deselect all and add/update this motif
            val without = current.filterNot { it.id == motif.id }
            listOf(motif.copy(isSelected = true)) + without.map { it.copy(isSelected = false) }
        }
        _selectedMotifId.value = motif.id
        _currentTab.value = NavigationTab.SELECT
        showNotification("Applied motif '${motif.name}' to active canvas!")
    }

    fun showNotification(msg: String) {
        _statusNotification.value = msg
    }

    fun clearNotification() {
        _statusNotification.value = null
    }
}
