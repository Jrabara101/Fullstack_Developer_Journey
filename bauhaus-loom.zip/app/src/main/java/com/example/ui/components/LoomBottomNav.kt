package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NavigationTab
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceContainerHighest

@Composable
fun LoomBottomNavBar(
    selectedTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        Triple(NavigationTab.SELECT, "Select", Icons.Default.NearMe),
        Triple(NavigationTab.PEN, "Pen", Icons.Default.Edit),
        Triple(NavigationTab.MOTIF, "Motif", Icons.Default.Category),
        Triple(NavigationTab.PALETTE, "Palette", Icons.Default.Palette),
        Triple(NavigationTab.VIEW_3D, "3D View", Icons.Default.ViewInAr),
        Triple(NavigationTab.EXPORT, "Export", Icons.Default.IosShare)
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(LoomSurface.copy(alpha = 0.95f))
            .navigationBarsPadding()
            .height(64.dp)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (tab, label, icon) ->
            val isActive = tab == selectedTab
            val background = if (isActive) LoomSurfaceContainerHighest else LoomSurface.copy(alpha = 0f)
            val contentColor = if (isActive) LoomSecondary else LoomOnSurfaceVariant

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(background)
                    .clickable { onTabSelected(tab) }
                    .testTag("nav_tab_${label.lowercase()}"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = contentColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = label,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = contentColor,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }
    }
}
