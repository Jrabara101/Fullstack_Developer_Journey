package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomPrimaryContainer
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceBright
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow

@Composable
fun LoomMainHeader(
    repeatMode: String,
    onRepeatClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(LoomSurface.copy(alpha = 0.95f))
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title branding
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerLow)
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "LOOM",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = LoomSecondary,
                    letterSpacing = 1.sp
                )
            }
            Text(
                text = " / ",
                color = LoomOutline,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            Column(modifier = Modifier.padding(start = 2.dp)) {
                Text(
                    text = "Bauhaus Flora v2",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoomOnSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Canvas Studio",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline
                )
            }
        }

        // Action controls
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Repeat mode button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(LoomSurfaceContainerHigh)
                    .clickable { onRepeatClick() }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
                    .testTag("repeat_mode_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.GridView,
                    contentDescription = "Pattern repeat configuration",
                    tint = LoomSecondary,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = repeatMode,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = LoomOnSurface
                )
                Icon(
                    imageVector = Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = LoomOutline,
                    modifier = Modifier.size(13.dp)
                )
            }

            // Quick Studio / Settings action
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainer)
                    .clickable { onSettingsClick() }
                    .testTag("settings_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Quick studio action",
                    tint = LoomOnSurface,
                    modifier = Modifier.size(18.dp)
                )
            }

            // User profile avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(LoomPrimary)
                    .clickable { onProfileClick() }
                    .testTag("profile_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Account profile",
                    tint = LoomOnPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun DrapeViewportHeader(
    onDismiss: () -> Unit,
    onResetCamera: () -> Unit,
    onArLook: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(LoomSurfaceContainerLow)
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainer)
                    .testTag("dismiss_3d_viewport")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Dismiss 3D drape inspector",
                    tint = LoomOnSurface,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "3D Drape Viewport",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LoomOnSurface
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(LoomPrimaryContainer.copy(alpha = 0.25f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "PBR LIVE",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = LoomPrimary
                        )
                    }
                }
                Text(
                    text = "Realtime Jacquard Physics · 240 WPI",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerHigh)
                    .clickable { onResetCamera() }
                    .testTag("reset_camera_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset simulation camera",
                    tint = LoomOnSurface,
                    modifier = Modifier.size(18.dp)
                )
            }

            Row(
                modifier = Modifier
                    .height(36.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerHighest)
                    .clickable { onArLook() }
                    .padding(horizontal = 8.dp)
                    .testTag("ar_look_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ViewInAr,
                    contentDescription = "AR Quick Look Preview",
                    tint = LoomSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "AR Look",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = LoomSecondary
                )
            }
        }
    }
}
