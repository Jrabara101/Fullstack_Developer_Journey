package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BorderStyle
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Grid4x4
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.ViewQuilt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.gemini.GeminiImageService
import com.example.data.model.LoomMotif
import com.example.data.model.NavigationTab
import com.example.data.model.VectorMotifType
import com.example.ui.LoomViewModel
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnSecondary
import com.example.ui.theme.LoomOnSecondaryContainer
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomPrimaryContainer
import com.example.ui.theme.LoomPrimaryFixedDim
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSecondaryContainer
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceBright
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow
import com.example.ui.theme.LoomSurfaceContainerLowest
import com.example.ui.theme.LoomTertiary

@Composable
fun CanvasStudioScreen(
    viewModel: LoomViewModel,
    modifier: Modifier = Modifier
) {
    val repeatMode by viewModel.repeatMode.collectAsState()
    val zoomPercent by viewModel.zoomPercent.collectAsState()
    val motifs by viewModel.motifs.collectAsState()
    val selectedMotifId by viewModel.selectedMotifId.collectAsState()
    val drawerTab by viewModel.activeDrawerTab.collectAsState()
    val colorway by viewModel.colorway.collectAsState()
    val snapPx by viewModel.snapGridPx.collectAsState()
    val guidesActive by viewModel.guidesActive.collectAsState()
    val toroidalSeamsActive by viewModel.toroidalSeamsActive.collectAsState()

    val selectedMotif = motifs.find { it.id == selectedMotifId } ?: motifs.firstOrNull()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LoomSurface)
            .verticalScroll(scrollState)
            .padding(bottom = 16.dp)
    ) {
        // Meta Readout HUD Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Resolution & DPI pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerHigh)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(LoomSecondary.copy(alpha = pulseAlpha))
                    )
                    Text(
                        text = "512×512px",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = LoomOnSurfaceVariant
                    )
                    Text(
                        text = "·",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline
                    )
                    Text(
                        text = "300 DPI",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LoomSecondary
                    )
                }

                // Repeat Mode Selector pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerHigh)
                        .clickable { viewModel.showNotification("Repeat: Half-Drop Pattern") }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ViewQuilt,
                        contentDescription = null,
                        tint = LoomPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = repeatMode,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = LoomOnSurface
                    )
                    Icon(
                        imageVector = Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = LoomOutline,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }

            // Symmetry & Zoom Readout
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSecondaryContainer)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AllInclusive,
                        contentDescription = null,
                        tint = LoomOnSecondaryContainer,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "4× SYM",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = LoomOnSecondaryContainer
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerHigh)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "$zoomPercent%",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LoomOnSurface
                    )
                }
            }
        }

        // Toroidal Interactive Canvas Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
                .aspectRatio(1.05f)
                .clip(RoundedCornerShape(8.dp))
                .background(LoomSurfaceContainerLowest)
                .testTag("canvas_viewport"),
            contentAlignment = Alignment.Center
        ) {
            // Background Micro Dot Grid Texture
            Canvas(modifier = Modifier.fillMaxSize()) {
                val step = 16.dp.toPx()
                val radius = 1.dp.toPx()
                val dotColor = Color(0xFF958EA0).copy(alpha = 0.25f)
                var x = 0f
                while (x < size.width) {
                    var y = 0f
                    while (y < size.height) {
                        drawCircle(color = dotColor, radius = radius, center = Offset(x, y))
                        y += step
                    }
                    x += step
                }
            }

            // Ghost toroidal wrap replicas in corners
            GhostToroidalCorner(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (-32).dp, y = (-32).dp)
            )
            GhostToroidalCorner(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (32).dp, y = (-32).dp)
            )
            GhostToroidalCorner(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .offset(x = (-32).dp, y = (32).dp)
            )
            GhostToroidalCorner(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = (32).dp, y = (32).dp)
            )

            // Master Repeat Tile Center (240x240dp canvas frame)
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerLow)
                    .border(1.dp, LoomPrimary.copy(alpha = 0.35f), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Seam guidelines if active
                if (guidesActive) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                        val seamColor = LoomSecondary.copy(alpha = 0.35f)
                        // Horizontal center guide
                        drawLine(
                            color = seamColor,
                            start = Offset(0f, size.height / 2),
                            end = Offset(size.width, size.height / 2),
                            strokeWidth = 1f,
                            pathEffect = pathEffect
                        )
                        // Vertical center guide
                        drawLine(
                            color = seamColor,
                            start = Offset(size.width / 2, 0f),
                            end = Offset(size.width / 2, size.height),
                            strokeWidth = 1f,
                            pathEffect = pathEffect
                        )
                    }
                }

                // Render vector motifs or AI motif
                motifs.forEach { motif ->
                    if (motif.isVisible) {
                        MotifVectorView(
                            motif = motif,
                            modifier = Modifier
                                .fillMaxSize()
                                .rotate(motif.rotation)
                        )
                    }
                }

                // Interactive Transform Bounding Box for the selected motif
                selectedMotif?.let { current ->
                    TransformBoundingBox(
                        motif = current,
                        onDrag = { dx, dy ->
                            viewModel.updateMotifPosition(current.id, dx, dy)
                        },
                        onScale = { factor ->
                            viewModel.updateMotifScale(current.id, factor)
                        },
                        onRotate = { deltaDeg ->
                            viewModel.updateMotifRotation(current.id, deltaDeg)
                        }
                    )
                }

                // Corner Master Canvas Boundary Indicators
                Text(
                    text = "⌜",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = LoomPrimary,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(2.dp)
                )
                Text(
                    text = "⌝",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = LoomPrimary,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                )
                Text(
                    text = "⌞",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = LoomPrimary,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(2.dp)
                )
                Text(
                    text = "⌟",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = LoomPrimary,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                )
            }

            // Floating Mini Texture / Toroidal Indicator
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(LoomSurfaceContainerHigh.copy(alpha = 0.9f))
                    .clickable { viewModel.toggleToroidalSeams() }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DonutLarge,
                    contentDescription = null,
                    tint = if (toroidalSeamsActive) LoomSecondary else LoomOutline,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = if (toroidalSeamsActive) "Toroidal Seams Active" else "Toroidal Seams Off",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOnSurface,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Tactical Floating Controls HUD Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(LoomSurfaceContainerHigh.copy(alpha = 0.95f))
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Snap Tool
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(LoomSurfaceContainer)
                    .clickable {
                        val nextSnap = when (snapPx) {
                            8 -> 16
                            16 -> 4
                            else -> 8
                        }
                        viewModel.showNotification("Snap Grid: ${nextSnap}px")
                    }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("snap_grid_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Grid4x4,
                    contentDescription = null,
                    tint = LoomSecondary,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "Snap ${snapPx}px",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoomSecondary
                )
            }

            // Seam Guides
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { viewModel.toggleGuides() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("toggle_guides_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BorderStyle,
                    contentDescription = null,
                    tint = if (guidesActive) LoomPrimary else LoomOutline,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "Guides",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (guidesActive) LoomOnSurface else LoomOutline
                )
            }

            // Symmetrical Center Reset
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { viewModel.centerActiveMotif() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("center_motif_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.RestartAlt,
                    contentDescription = null,
                    tint = LoomOnSurface,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "Center",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = LoomOnSurface
                )
            }
        }

        // Collapsible Studio Workspace Drawer / Inspector
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(LoomSurfaceContainer)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Drawer Navigation Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerLow)
                    .padding(2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val tabs = listOf("Layers (4)", "Weimar Nocturne", "Cloth Sim")
                tabs.forEachIndexed { index, title ->
                    val isActive = drawerTab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isActive) LoomSurfaceContainerHigh else Color.Transparent)
                            .clickable { viewModel.setDrawerTab(index) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Medium,
                            color = if (isActive) LoomSecondary else LoomOnSurfaceVariant
                        )
                    }
                }
            }

            // Quick Colorway Swatches Strip
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerLow)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "COLORWAY PALETTE",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline,
                        letterSpacing = 0.5.sp
                    )
                    Row(
                        modifier = Modifier.clickable { viewModel.toggleHarmonyLock() },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoFixHigh,
                            contentDescription = null,
                            tint = if (colorway.isHarmonyLocked) LoomPrimary else LoomOutline,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Harmony Lock",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = if (colorway.isHarmonyLocked) LoomPrimary else LoomOutline
                        )
                    }
                }

                // 5 Color Swatches with Hex Identifiers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    colorway.colors.forEachIndexed { idx, hex ->
                        val color = try {
                            Color(android.graphics.Color.parseColor(hex))
                        } catch (e: Exception) {
                            LoomSecondary
                        }
                        val shortHex = hex.take(5).uppercase()

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.clickable {
                                viewModel.showNotification("Selected swatch: $hex")
                            }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (idx < 3) 2.dp else 1.dp,
                                        color = if (idx < 3) color.copy(alpha = 0.6f) else LoomOutline.copy(alpha = 0.3f),
                                        shape = CircleShape
                                    )
                            )
                            Text(
                                text = shortHex,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = LoomOnSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Active Layer Quick Inspector Card
            selectedMotif?.let { activeMotif ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerHigh)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(LoomSurfaceContainerLowest),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Architecture,
                                contentDescription = null,
                                tint = LoomPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = activeMotif.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = LoomOnSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "Verified Layer",
                                    tint = LoomSecondary,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                            Text(
                                text = "Blend: ${activeMotif.blendMode} · O: ${(activeMotif.opacity * 100).toInt()}%",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = LoomOutline
                            )
                        }
                    }

                    // Visibility & Lock States
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.toggleMotifVisibility(activeMotif.id) },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(LoomSurfaceContainer)
                        ) {
                            Icon(
                                imageVector = if (activeMotif.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Toggle Visibility",
                                tint = if (activeMotif.isVisible) LoomOnSurface else LoomOutline,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.toggleMotifLock(activeMotif.id) },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(LoomSurfaceContainer)
                        ) {
                            Icon(
                                imageVector = if (activeMotif.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = "Toggle Lock",
                                tint = if (activeMotif.isLocked) LoomSecondary else LoomOnSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Quick Draped Silk Render Preview Badge (Banner with hotlinked atelier silk image)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(LoomSurfaceContainerLowest)
                    .clickable { viewModel.selectTab(NavigationTab.VIEW_3D) }
                    .testTag("quick_drape_preview_card")
            ) {
                // Hotlinked Silk Drape Thumbnail Background
                AsyncImage(
                    model = "https://lh3.googleusercontent.com/aida-public/AB6AXuAZOM_49v7uc0kEpJ-_Y1VIw07vUA80J8qme-AmLkaIX_j_7yRUWGObw85H2sOkDE3fzN1VumJh4tGpwV0OrJOpeFwFjFFRMkdsPCVeYYkj-86T7cw43VgebY7cA0lOCBz6cA1P4I_TkumNg5QvS_bCgks9GK09NcmQI0aQ6FchUG9JqWtPgKtni6ryHtWq5zEvG87mibxZ33Z_GxaWPMHFpdaSgOlnf2pMKmXcUUE2v3UKMmzM-WqW",
                    contentDescription = "Close-up macro of flowing silk textile pattern",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    alpha = 0.45f
                )

                // Gradient wash
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    LoomSurfaceContainerLowest,
                                    LoomSurfaceContainerLowest.copy(alpha = 0.75f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Card details
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(LoomSecondary)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "3D REALTIME JACQUARD",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = LoomSecondary
                            )
                        }
                        Text(
                            text = "Mulberry Silk Drape",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LoomOnSurface,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        Text(
                            text = "Weave Density: 240 WPI",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LoomOnSurfaceVariant
                        )
                    }

                    // 360 Turntable Icon Button
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(LoomPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "Open 3D Turntable",
                            tint = LoomOnPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Numeric Geometry Transform Scrubber Strip
            selectedMotif?.let { current ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TransformMetricCell("X", String.format("%.1f", current.x), Modifier.weight(1f)) {
                        viewModel.updateMotifPosition(current.id, 4f, 0f)
                    }
                    TransformMetricCell("Y", String.format("%.1f", current.y), Modifier.weight(1f)) {
                        viewModel.updateMotifPosition(current.id, 0f, 4f)
                    }
                    TransformMetricCell("W", String.format("%.1f", current.width), Modifier.weight(1f), isSecondary = true) {
                        viewModel.updateMotifScale(current.id, 1.05f)
                    }
                    TransformMetricCell("H", String.format("%.1f", current.height), Modifier.weight(1f), isSecondary = true) {
                        viewModel.updateMotifScale(current.id, 0.95f)
                    }
                }
            }
        }
    }
}

@Composable
fun TransformMetricCell(
    axis: String,
    value: String,
    modifier: Modifier = Modifier,
    isSecondary: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(LoomSurfaceContainerLow)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = axis,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = LoomOutline
        )
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isSecondary) LoomSecondary else LoomOnSurface
        )
    }
}

@Composable
fun MotifVectorView(
    motif: LoomMotif,
    modifier: Modifier = Modifier
) {
    if (motif.type == VectorMotifType.GENERATED_AI && motif.imageBase64 != null) {
        val bitmap = remember(motif.imageBase64) {
            GeminiImageService.base64ToBitmap(motif.imageBase64)
        }
        if (bitmap != null) {
            Box(
                modifier = modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = motif.prompt ?: "Generated Bauhaus Motif",
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop,
                    alpha = motif.opacity
                )
            }
            return
        }
    }

    // Default vector rendering of Bauhaus Flora components
    Canvas(modifier = modifier) {
        val primaryColor = try {
            Color(android.graphics.Color.parseColor(motif.primaryColorHex))
        } catch (e: Exception) {
            LoomSecondary
        }
        val secondaryColor = try {
            Color(android.graphics.Color.parseColor(motif.secondaryColorHex))
        } catch (e: Exception) {
            LoomPrimary
        }

        when (motif.type) {
            VectorMotifType.ARCH -> {
                // Background balance circle
                drawCircle(
                    color = primaryColor.copy(alpha = 0.18f * motif.opacity),
                    radius = size.width * 0.38f,
                    center = Offset(size.width / 2, size.height / 2)
                )

                // Bauhaus arch path
                val archPath = Path().apply {
                    val w = size.width
                    val h = size.height
                    moveTo(w * 0.25f, h * 0.75f)
                    cubicTo(
                        w * 0.25f, h * 0.45f,
                        w * 0.43f, h * 0.28f,
                        w * 0.50f, h * 0.28f
                    )
                    cubicTo(
                        w * 0.57f, h * 0.28f,
                        w * 0.75f, h * 0.45f,
                        w * 0.75f, h * 0.75f
                    )
                    close()
                }
                drawPath(
                    path = archPath,
                    color = primaryColor.copy(alpha = 0.82f * motif.opacity)
                )
            }

            VectorMotifType.CONCENTRIC_CORE -> {
                val cx = size.width / 2
                val cy = size.height * 0.38f
                drawCircle(
                    color = LoomSurface,
                    radius = size.width * 0.13f,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = secondaryColor.copy(alpha = motif.opacity),
                    radius = size.width * 0.085f,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = primaryColor.copy(alpha = motif.opacity),
                    radius = size.width * 0.038f,
                    center = Offset(cx, cy)
                )
            }

            VectorMotifType.CHEVRON -> {
                val w = size.width
                val h = size.height
                val chevronPath1 = Path().apply {
                    moveTo(w * 0.33f, h * 0.70f)
                    lineTo(w * 0.50f, h * 0.84f)
                    lineTo(w * 0.67f, h * 0.70f)
                }
                drawPath(
                    path = chevronPath1,
                    color = primaryColor.copy(alpha = 0.9f * motif.opacity),
                    style = Stroke(width = 4.dp.toPx())
                )

                val chevronPath2 = Path().apply {
                    moveTo(w * 0.37f, h * 0.76f)
                    lineTo(w * 0.50f, h * 0.87f)
                    lineTo(w * 0.63f, h * 0.76f)
                }
                drawPath(
                    path = chevronPath2,
                    color = secondaryColor.copy(alpha = 0.75f * motif.opacity),
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }

            VectorMotifType.WRAP_PIP -> {
                // Top wrap pip
                drawCircle(
                    color = secondaryColor.copy(alpha = motif.opacity),
                    radius = size.width * 0.04f,
                    center = Offset(size.width / 2, size.height * 0.06f)
                )
                // Left & Right boundary wraps
                drawCircle(
                    color = primaryColor.copy(alpha = motif.opacity),
                    radius = size.width * 0.035f,
                    center = Offset(0f, size.height * 0.5f)
                )
                drawCircle(
                    color = primaryColor.copy(alpha = motif.opacity),
                    radius = size.width * 0.035f,
                    center = Offset(size.width, size.height * 0.5f)
                )
            }

            else -> {}
        }
    }
}

@Composable
fun TransformBoundingBox(
    motif: LoomMotif,
    onDrag: (Float, Float) -> Unit,
    onScale: (Float) -> Unit,
    onRotate: (Float) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
            .pointerInput(motif.id) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x * 0.8f, dragAmount.y * 0.8f)
                }
            }
    ) {
        // Cyan Bounding Box Outline
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(1.5.dp, LoomSecondary, RoundedCornerShape(2.dp))
        ) {
            // Corner Node Handles (Square 10x10dp)
            NodeHandle(Alignment.TopStart) { onScale(1.04f) }
            NodeHandle(Alignment.TopEnd) { onScale(1.04f) }
            NodeHandle(Alignment.BottomStart) { onScale(0.96f) }
            NodeHandle(Alignment.BottomEnd) { onScale(0.96f) }

            // Top Rotation Pip
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-18).dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(LoomPrimaryFixedDim)
                        .clickable { onRotate(15f) }
                )
                Box(
                    modifier = Modifier
                        .width(1.5.dp)
                        .height(8.dp)
                        .background(LoomSecondary)
                )
            }
        }
    }
}

@Composable
fun NodeHandle(alignment: Alignment, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(9.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(LoomSecondary)
            .clickable { onClick() }
    )
}

@Composable
fun GhostToroidalCorner(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .size(80.dp)
            .scale(0.85f)
    ) {
        drawCircle(
            color = LoomPrimary.copy(alpha = 0.12f),
            radius = size.width * 0.4f,
            center = Offset(size.width / 2, size.height / 2)
        )
        val path = Path().apply {
            moveTo(size.width * 0.2f, size.height * 0.8f)
            cubicTo(
                size.width * 0.3f, size.height * 0.4f,
                size.width * 0.7f, size.height * 0.4f,
                size.width * 0.8f, size.height * 0.8f
            )
            close()
        }
        drawPath(path = path, color = LoomSecondary.copy(alpha = 0.14f))
    }
}
