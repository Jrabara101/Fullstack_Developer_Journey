package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DownloadForOffline
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.WbIridescent
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.gemini.GeminiImageService
import com.example.data.model.CameraAngle
import com.example.data.model.NavigationTab
import com.example.ui.LoomViewModel
import com.example.ui.components.DrapeViewportHeader
import com.example.ui.theme.LoomOnBackground
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnPrimaryContainer
import com.example.ui.theme.LoomOnSecondary
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomOutlineVariant
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomPrimaryContainer
import com.example.ui.theme.LoomPrimaryFixedDim
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSecondaryContainer
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceBright
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow
import com.example.ui.theme.LoomSurfaceContainerLowest
import com.example.ui.theme.LoomTertiary

@Composable
fun Drape3DViewportScreen(
    viewModel: LoomViewModel,
    modifier: Modifier = Modifier
) {
    val physicsState by viewModel.physicsState.collectAsState()
    val colorway by viewModel.colorway.collectAsState()
    val motifs by viewModel.motifs.collectAsState()
    val substrates = viewModel.availableSubstrates
    val lightingRigs = viewModel.lightingRigs

    var showLightingMenu by remember { mutableStateOf(false) }

    // Dynamic camera drag interactive states
    var manualRotX by remember { mutableFloatStateOf(0f) }
    var manualRotY by remember { mutableFloatStateOf(0f) }

    val animRotX by animateFloatAsState(
        targetValue = physicsState.activeCameraAngle.rotationX + manualRotX,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "rotX"
    )
    val animRotY by animateFloatAsState(
        targetValue = physicsState.activeCameraAngle.rotationY + manualRotY,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "rotY"
    )
    val animScale by animateFloatAsState(
        targetValue = physicsState.activeCameraAngle.scale,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "scale"
    )

    // Animated wind wave phase
    val infiniteTransition = rememberInfiniteTransition(label = "windPhase")
    val windOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "windAnim"
    )

    val pingScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 2.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pingScale"
    )

    val scrollState = rememberScrollState()

    // Find any AI-generated texture to apply if available
    val activeAiMotif = motifs.find { it.imageBase64 != null }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LoomSurface)
            .verticalScroll(scrollState)
            .padding(bottom = 20.dp)
    ) {
        // Modal Context Header
        DrapeViewportHeader(
            onDismiss = { viewModel.selectTab(NavigationTab.SELECT) },
            onResetCamera = {
                manualRotX = 0f
                manualRotY = 0f
                viewModel.setCameraAngle(CameraAngle.DRAPE_45)
                viewModel.showNotification("Simulation camera reset to Drape 45°")
            },
            onArLook = {
                viewModel.showNotification("Launching AR Quick Look session...")
            }
        )

        // Hero 3D Drape Viewport (4:5 aspect ratio)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.85f)
                .background(LoomSurfaceContainerLowest)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        manualRotY = (manualRotY + dragAmount.x * 0.3f).coerceIn(-45f, 45f)
                        manualRotX = (manualRotX - dragAmount.y * 0.3f).coerceIn(-30f, 30f)
                    }
                }
                .testTag("hero_3d_viewport"),
            contentAlignment = Alignment.Center
        ) {
            // Viewport Environment Spotlight Backdrop
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            LoomSecondary.copy(alpha = 0.16f),
                            LoomPrimary.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.38f),
                        radius = size.width * 0.75f
                    )
                )
            }

            // Tactile Jacquard 3D Cloth Drape Staging
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
                    .graphicsLayer {
                        rotationX = animRotX
                        rotationY = animRotY
                        scaleX = animScale
                        scaleY = animScale
                    },
                contentAlignment = Alignment.Center
            ) {
                // Draped silk cloth card
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .height(340.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(LoomSurfaceContainerLow)
                        .border(1.dp, LoomSurfaceContainerHighest, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    // Hotlinked Photorealistic Mannequin Silk Drape
                    AsyncImage(
                        model = "https://lh3.googleusercontent.com/aida-public/AB6AXuCyXjkNG-p3riEXZlhX3XB9JN7dGviXmo1ZekaMyr2YqVU47G2u2D2Q-8JlESlpU5R8jjikQQmZLEkQlFHruB5p0k4bA48d5Uwv7eLTkttdt3eOc4vtdJlLv-75th8id4drgGyyTjAGStiPY4Mu4ETWmdvT8dplPbf7EXDkufyt4R-2bXLc43hrXmmOoee28mkTLvDPfSWcwvIv3jZ1fk2Tj8FllmZrwAEfO37ugNfUWZGCbucV1GUr",
                        contentDescription = "Photorealistic 3D rendered textile silk jacquard cloth on mannequin bust",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // If user generated a custom AI motif, layer it as a tactile weave blend
                    if (activeAiMotif?.imageBase64 != null) {
                        val aiBitmap = remember(activeAiMotif.imageBase64) {
                            GeminiImageService.base64ToBitmap(activeAiMotif.imageBase64)
                        }
                        if (aiBitmap != null) {
                            androidx.compose.foundation.Image(
                                bitmap = aiBitmap.asImageBitmap(),
                                contentDescription = "Active Generative Motif",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .scale(1.05f),
                                contentScale = ContentScale.Crop,
                                alpha = 0.38f
                            )
                        }
                    }

                    // Specular Weave Shimmer Overlay reacting to Sheen slider
                    val sheenAlpha = (physicsState.sheenPercent / 100f) * 0.35f
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        LoomSurfaceContainerLowest.copy(alpha = 0.6f),
                                        Color.Transparent,
                                        LoomSecondary.copy(alpha = sheenAlpha),
                                        LoomPrimary.copy(alpha = sheenAlpha * 0.6f),
                                        Color.Transparent
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(1000f, 1000f)
                                )
                            )
                    )

                    // Wind Particle Stream curves
                    if (physicsState.isWindActive) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val path1 = Path().apply {
                                val w = size.width
                                val h = size.height
                                moveTo(0f, h * 0.50f + (windOffset * 0.3f))
                                cubicTo(
                                    w * 0.25f, h * 0.47f,
                                    w * 0.45f, h * 0.58f + (windOffset * 0.5f),
                                    w * 0.75f, h * 0.54f
                                )
                                cubicTo(
                                    w * 0.85f, h * 0.52f,
                                    w * 0.95f, h * 0.53f,
                                    w, h * 0.50f
                                )
                            }
                            drawPath(
                                path = path1,
                                color = LoomSecondary.copy(alpha = 0.5f),
                                style = Stroke(
                                    width = 1.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 16f), windOffset)
                                )
                            )

                            val path2 = Path().apply {
                                val w = size.width
                                val h = size.height
                                moveTo(0f, h * 0.62f)
                                cubicTo(
                                    w * 0.20f, h * 0.59f,
                                    w * 0.50f, h * 0.70f - (windOffset * 0.4f),
                                    w * 0.80f, h * 0.64f
                                )
                                cubicTo(
                                    w * 0.90f, h * 0.62f,
                                    w * 0.95f, h * 0.63f,
                                    w, h * 0.60f
                                )
                            }
                            drawPath(
                                path = path2,
                                color = LoomPrimary.copy(alpha = 0.4f),
                                style = Stroke(
                                    width = 1.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 14f), windOffset * 1.2f)
                                )
                            )
                        }
                    }

                    // Active Yarn Crosshair Anchor Node
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .offset(x = 20.dp, y = (-8).dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Pulsing radar pip
                            Box(
                                modifier = Modifier.size(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .scale(pingScale)
                                        .clip(CircleShape)
                                        .background(LoomSecondary.copy(alpha = (1f - (pingScale - 1f) / 1.2f).coerceIn(0f, 0.7f)))
                                )
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(LoomSecondary)
                                )
                            }

                            // Detail Card
                            Column(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(LoomSurfaceContainerHighest.copy(alpha = 0.92f))
                                    .border(1.dp, LoomSurfaceBright, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Warp #${physicsState.warpCount}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = LoomSecondary
                                )
                                Text(
                                    text = "Twist: ${physicsState.tpi} TPI · ${physicsState.twistType}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = LoomOutline
                                )
                            }
                        }
                    }
                }
            }

            // Top Left Telemetry HUD Pill
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerHighest.copy(alpha = 0.9f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(LoomSecondaryContainer)
                    )
                    Text(
                        text = "${physicsState.fps} FPS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LoomOnSurface
                    )
                    Text(
                        text = "·",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline
                    )
                    Text(
                        text = "PBR WebGL2",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerLowest.copy(alpha = 0.75f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Stress: ${physicsState.stressKPa} kPa",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline
                    )
                }
            }

            // Top Right Studio Lighting Quick Dropdown
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerHighest.copy(alpha = 0.9f))
                        .clickable { showLightingMenu = true }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("lighting_dropdown"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WbIridescent,
                        contentDescription = null,
                        tint = LoomTertiary,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = physicsState.lightingRig,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LoomOnSurface
                    )
                    Icon(
                        imageVector = Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = LoomOutline,
                        modifier = Modifier.size(13.dp)
                    )
                }

                DropdownMenu(
                    expanded = showLightingMenu,
                    onDismissRequest = { showLightingMenu = false },
                    modifier = Modifier.background(LoomSurfaceContainerHighest)
                ) {
                    lightingRigs.forEach { rig ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = rig,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = if (rig == physicsState.lightingRig) LoomSecondary else LoomOnSurface
                                )
                            },
                            onClick = {
                                viewModel.setLightingRig(rig)
                                showLightingMenu = false
                            }
                        )
                    }
                }
            }

            // Floating Micro-Gesture HUD (Center bottom)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = (-52).dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(LoomSurfaceContainerLowest.copy(alpha = 0.85f))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = null,
                    tint = LoomOutlineVariant,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = "Drag to Orbit · Pinch to Zoom · 2-Finger Pan",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutlineVariant
                )
            }

            // Camera Angle Presets Bar (Anchored Bottom HUD)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(LoomSurfaceContainerHigh.copy(alpha = 0.95f))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                CameraAngle.values().forEach { angle ->
                    val isActive = physicsState.activeCameraAngle == angle
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isActive) LoomSurfaceContainerHighest else Color.Transparent)
                            .clickable {
                                manualRotX = 0f
                                manualRotY = 0f
                                viewModel.setCameraAngle(angle)
                            }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                            .testTag("camera_btn_${angle.name.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = angle.label,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (isActive) LoomSecondary else LoomOnSurfaceVariant
                        )
                    }
                }
            }
        }

        // Simulation & Physics Control Drawer Deck
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(LoomSurfaceContainerLow)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Substrate Material Presets Horizontal Strip
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SUBSTRATE MATERIAL LIBRARY",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Bending: ${physicsState.selectedSubstrate.bending} · Weight: ${physicsState.selectedSubstrate.weight}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    substrates.forEach { substrate ->
                        val isSelected = physicsState.selectedSubstrate.id == substrate.id
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) LoomPrimaryContainer else LoomSurfaceContainerHigh)
                                .clickable { viewModel.setSubstrate(substrate) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("substrate_${substrate.id}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = substrate.symbol,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = if (isSelected) LoomOnPrimaryContainer else LoomOnSurfaceVariant
                            )
                            Text(
                                text = substrate.name,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (isSelected) LoomOnPrimaryContainer else LoomOnSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Physics Parameters Grids Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(LoomSurfaceContainer)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REALTIME PHYSICS MODIFIERS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline,
                        letterSpacing = 0.5.sp
                    )
                    Row(
                        modifier = Modifier.clickable { viewModel.resetPhysicsDefaults() },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = null,
                            tint = LoomPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Reset Defaults",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = LoomPrimary
                        )
                    }
                }

                // Slider 1: Sheen & Specular
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Sheen & Specular",
                            fontSize = 12.sp,
                            color = LoomOnSurface
                        )
                        Text(
                            text = "${physicsState.sheenPercent}% · OKLCH Glint",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LoomSecondary
                        )
                    }
                    Slider(
                        value = physicsState.sheenPercent.toFloat(),
                        onValueChange = { viewModel.setPhysicsSheen(it.toInt()) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = LoomSecondary,
                            activeTrackColor = LoomSecondary,
                            inactiveTrackColor = LoomSurfaceContainerHighest
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .testTag("sheen_slider")
                    )
                }

                // Slider 2: Drape Stiffness
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    val flowLabel = when {
                        physicsState.stiffnessPercent > 60 -> "Rigid Twill"
                        physicsState.stiffnessPercent > 25 -> "Fluid Flow"
                        else -> "Ultra Gossamer"
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Drape Stiffness (Bending Rigidity)",
                            fontSize = 12.sp,
                            color = LoomOnSurface
                        )
                        Text(
                            text = "${physicsState.stiffnessPercent}% · $flowLabel",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LoomPrimary
                        )
                    }
                    Slider(
                        value = physicsState.stiffnessPercent.toFloat(),
                        onValueChange = { viewModel.setPhysicsStiffness(it.toInt()) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = LoomPrimary,
                            activeTrackColor = LoomPrimary,
                            inactiveTrackColor = LoomSurfaceContainerHighest
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .testTag("stiffness_slider")
                    )
                }

                // Slider 3: Tension / Elasticity
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    val force = String.format("%.2f", physicsState.elasticityPercent * 0.0175f)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Warp / Weft Elasticity",
                            fontSize = 12.sp,
                            color = LoomOnSurface
                        )
                        Text(
                            text = "${physicsState.elasticityPercent}% · $force N/mm",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LoomOnSurface
                        )
                    }
                    Slider(
                        value = physicsState.elasticityPercent.toFloat(),
                        onValueChange = { viewModel.setPhysicsElasticity(it.toInt()) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = LoomTertiary,
                            activeTrackColor = LoomTertiary,
                            inactiveTrackColor = LoomSurfaceContainerHighest
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .testTag("tension_slider")
                    )
                }

                // Wind Field Quick Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Air,
                            contentDescription = null,
                            tint = LoomSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "Atelier Ambient Breeze",
                                fontSize = 12.sp,
                                color = LoomOnSurface
                            )
                            Text(
                                text = "0.4 m/s oscillating turbulence",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = LoomOutline
                            )
                        }
                    }

                    // Wind Switch Toggle Pill
                    Box(
                        modifier = Modifier
                            .size(width = 46.dp, height = 24.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (physicsState.isWindActive) LoomSecondary else LoomSurfaceContainerHighest)
                            .clickable { viewModel.toggleWindActive() }
                            .padding(3.dp)
                            .testTag("wind_toggle_btn"),
                        contentAlignment = if (physicsState.isWindActive) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(if (physicsState.isWindActive) LoomOnSecondary else LoomOutline)
                        )
                    }
                }
            }

            // Active Colorway & Sync Palette Bar Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(LoomSurfaceContainer)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE CANVAS COLORWAY",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline,
                        letterSpacing = 0.5.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { viewModel.toggleLiveSync() }
                    ) {
                        Checkbox(
                            checked = colorway.isLiveSync,
                            onCheckedChange = { viewModel.toggleLiveSync() },
                            colors = CheckboxDefaults.colors(
                                checkedColor = LoomPrimary,
                                uncheckedColor = LoomOutline
                            ),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Live Sync Canvas",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = LoomPrimary
                        )
                    }
                }

                // 5 Swatch buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    colorway.colors.forEach { hex ->
                        val color = try {
                            Color(android.graphics.Color.parseColor(hex))
                        } catch (e: Exception) {
                            LoomSecondary
                        }
                        val shortHex = hex.take(5).uppercase()

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(color)
                                .clickable {
                                    viewModel.showNotification("Colorway token: $hex")
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = shortHex,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (hex.contains("D3E4", ignoreCase = true)) LoomSurface else LoomSurfaceContainerLowest
                            )
                        }
                    }
                }
            }

            // Bottom Action Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Export .glTF Button
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSurfaceContainerHigh)
                        .clickable {
                            viewModel.showNotification("Exporting 3D Drape asset as .glTF mesh with PBR maps...")
                        }
                        .padding(horizontal = 8.dp)
                        .testTag("export_gltf_button"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.DownloadForOffline,
                        contentDescription = null,
                        tint = LoomOnSurface,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Export .glTF",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = LoomOnSurface
                    )
                }

                // Apply & Return Button
                Row(
                    modifier = Modifier
                        .weight(1.5f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomPrimary)
                        .clickable {
                            viewModel.selectTab(NavigationTab.SELECT)
                            viewModel.showNotification("Applied simulation parameters to active workspace")
                        }
                        .padding(horizontal = 12.dp)
                        .testTag("apply_and_return_button"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = LoomOnPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Apply & Return",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LoomOnPrimary
                    )
                }
            }
        }
    }
}
