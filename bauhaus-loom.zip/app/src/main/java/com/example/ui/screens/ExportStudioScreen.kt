package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.LoomViewModel
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnSecondary
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomPrimaryContainer
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow
import com.example.ui.theme.LoomSurfaceContainerLowest

@Composable
fun ExportStudioScreen(
    viewModel: LoomViewModel,
    modifier: Modifier = Modifier
) {
    val physicsState by viewModel.physicsState.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LoomSurface)
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Column {
            Text(
                text = "Technical Loom Specification",
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = LoomOnSurface
            )
            Text(
                text = "Industrial Jacquard Punch & CAD Export",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = LoomOutline
            )
        }

        // Specification Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(LoomSurfaceContainer)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "WEAVE & SUBSTRATE MATRIX",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = LoomOutline
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SpecBox("WARP DENSITY", "${physicsState.warpCount} WPI", Modifier.weight(1f))
                SpecBox("YARN TWIST", "${physicsState.tpi} TPI (${physicsState.twistType})", Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SpecBox("SUBSTRATE", physicsState.selectedSubstrate.name, Modifier.weight(1f))
                SpecBox("WEIGHT", physicsState.selectedSubstrate.weight, Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SpecBox("REPEAT SYSTEM", "Half-Drop 512px", Modifier.weight(1f))
                SpecBox("RESOLUTION", "300 DPI", Modifier.weight(1f))
            }
        }

        // Jacquard Punch Card Matrix Simulation Visualizer
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(LoomSurfaceContainer)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = null,
                        tint = LoomSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "JACQUARD PUNCH CARD TAPE",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = LoomSecondary
                    )
                }
                Text(
                    text = "Loom Channel #01-64",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline
                )
            }

            // Binary hole punch visualization
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerLowest)
                    .border(1.dp, LoomSurfaceContainerHighest, RoundedCornerShape(4.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cols = 32
                    val rows = 6
                    val colStep = size.width / cols
                    val rowStep = size.height / rows
                    val punchColor = LoomSecondary.copy(alpha = 0.75f)
                    val unpunchedColor = LoomSurfaceContainerHigh

                    for (r in 0 until rows) {
                        for (c in 0 until cols) {
                            val isPunched = (r * 7 + c * 13) % 3 != 0
                            val cx = c * colStep + colStep / 2
                            val cy = r * rowStep + rowStep / 2
                            drawCircle(
                                color = if (isPunched) punchColor else unpunchedColor,
                                radius = 2.dp.toPx(),
                                center = Offset(cx, cy)
                            )
                        }
                    }
                }
            }
        }

        // Export Actions
        Text(
            text = "PACKAGED ASSET EXPORTS",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = LoomOutline,
            letterSpacing = 0.5.sp
        )

        ExportRowItem(
            title = "3D PBR Drape (.glTF)",
            desc = "Full mannequin mesh, Jacquard displacement maps, OKLCH specularity",
            icon = Icons.Default.ViewInAr,
            actionLabel = "Export",
            onExport = {
                viewModel.showNotification("Generating .glTF archive with PBR texture sets...")
            }
        )

        ExportRowItem(
            title = "Master Vector Repeat (.SVG)",
            desc = "Precision toroidal boundary nodes, half-drop offsets, layer hierarchy",
            icon = Icons.Default.Description,
            actionLabel = "Export",
            onExport = {
                viewModel.showNotification("Exporting Bauhaus Flora v2 as scalable vector .SVG")
            }
        )

        ExportRowItem(
            title = "Seamless Repeat Tile (.PNG)",
            desc = "512×512px @ 300 DPI, RGBA 32-bit lossless textile print card",
            icon = Icons.Default.Download,
            actionLabel = "Export",
            onExport = {
                viewModel.showNotification("Exported master seamless repeat tile (.PNG)")
            }
        )

        ExportRowItem(
            title = "Loom Punch Code (.JAC)",
            desc = "Industrial electronic jacquard format for automated weaving looms",
            icon = Icons.Default.GridOn,
            actionLabel = "Export",
            onExport = {
                viewModel.showNotification("Synthesized industrial Jacquard punch card (.JAC)")
            }
        )
    }
}

@Composable
fun SpecBox(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(LoomSurfaceContainerLow)
            .padding(8.dp)
    ) {
        Text(
            text = title,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = LoomOutline
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = LoomOnSurface,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun ExportRowItem(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    actionLabel: String,
    onExport: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(LoomSurfaceContainer)
            .clickable { onExport() }
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f, fill = false)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(LoomSurfaceContainerLowest),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = LoomSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoomOnSurface
                )
                Text(
                    text = desc,
                    fontSize = 11.sp,
                    color = LoomOnSurfaceVariant,
                    maxLines = 1
                )
            }
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(LoomSurfaceContainerHigh)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = actionLabel,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LoomSecondary
            )
        }
    }
}
