package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.gemini.GeminiImageService
import com.example.data.model.GenerationState
import com.example.data.model.LoomMotif
import com.example.data.model.NavigationTab
import com.example.ui.LoomViewModel
import com.example.ui.theme.LoomError
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnPrimaryContainer
import com.example.ui.theme.LoomOnSecondary
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomPrimaryContainer
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSecondaryContainer
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceBright
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow
import com.example.ui.theme.LoomSurfaceContainerLowest
import com.example.ui.theme.LoomTertiary

@Composable
fun MotifStudioScreen(
    viewModel: LoomViewModel,
    modifier: Modifier = Modifier
) {
    val generationState by viewModel.generationState.collectAsState()
    val motifsHistory by viewModel.aiMotifsHistory.collectAsState()
    val activeMotifs by viewModel.motifs.collectAsState()
    val selectedMotifId by viewModel.selectedMotifId.collectAsState()
    val apiKey by viewModel.geminiApiKey.collectAsState()

    var isEditMode by remember { mutableStateOf(false) }
    var promptInput by remember {
        mutableStateOf("Bauhaus arch and concentric circular flora in neon cyan and silk lavender")
    }
    var editInstructionInput by remember {
        mutableStateOf("Add shimmering metallic gold threads and increase jacquard weave contrast")
    }
    var showApiKeyInput by remember { mutableStateOf(false) }
    var apiKeyText by remember { mutableStateOf(apiKey) }

    val selectedMotif = activeMotifs.find { it.id == selectedMotifId } ?: activeMotifs.firstOrNull()
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LoomSurface)
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header with Model Identity
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Generative AI Motif Studio",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoomOnSurface
                )
                Text(
                    text = "Text-to-textile synthesis & weave editing",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = LoomOutline
                )
            }

            // Model badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomPrimaryContainer.copy(alpha = 0.25f))
                    .border(1.dp, LoomPrimary.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "gemini-3.1-flash-image-preview",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = LoomPrimary
                )
            }
        }

        // Mode Switcher: Create New vs Edit Existing
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(LoomSurfaceContainerLow)
                .padding(3.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (!isEditMode) LoomSurfaceContainerHigh else Color.Transparent)
                    .clickable { isEditMode = false }
                    .padding(vertical = 8.dp)
                    .testTag("mode_create_motif"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (!isEditMode) LoomSecondary else LoomOnSurfaceVariant,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "Create New Pattern",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = if (!isEditMode) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (!isEditMode) LoomSecondary else LoomOnSurfaceVariant
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isEditMode) LoomSurfaceContainerHigh else Color.Transparent)
                    .clickable { isEditMode = true }
                    .padding(vertical = 8.dp)
                    .testTag("mode_edit_motif"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = if (isEditMode) LoomPrimary else LoomOnSurfaceVariant,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "Edit Active Textile",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = if (isEditMode) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (isEditMode) LoomPrimary else LoomOnSurfaceVariant
                    )
                }
            }
        }

        // Input Card for Prompt
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(LoomSurfaceContainer)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val isGenerating = generationState is GenerationState.Generating

            if (!isEditMode) {
                Text(
                    text = "PROMPT TEXTILE GENERATOR",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline,
                    letterSpacing = 0.5.sp
                )

                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("prompt_text_field"),
                    placeholder = {
                        Text(
                            text = "Describe your Bauhaus jacquard pattern...",
                            fontSize = 12.sp,
                            color = LoomOutline
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LoomSecondary,
                        unfocusedBorderColor = LoomSurfaceContainerHighest,
                        focusedContainerColor = LoomSurfaceContainerLowest,
                        unfocusedContainerColor = LoomSurfaceContainerLowest,
                        focusedTextColor = LoomOnSurface,
                        unfocusedTextColor = LoomOnSurface
                    ),
                    shape = RoundedCornerShape(6.dp),
                    maxLines = 3
                )

                // Quick Prompt Presets
                Text(
                    text = "Curated Bauhaus Prompts:",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline
                )
                val suggestions = listOf(
                    "Bauhaus Arch & Concentric Flora in cyan & lavender twill",
                    "Constructivist diagonal twill with metallic warp",
                    "De Stijl geometric circles with dark obsidian twill",
                    "Organic botanical jacquard with fine 240 WPI silk weave"
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    suggestions.forEach { sugg ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(LoomSurfaceContainerLow)
                                .clickable { promptInput = sugg }
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "✦ ",
                                color = LoomSecondary,
                                fontSize = 10.sp
                            )
                            Text(
                                text = sugg,
                                fontSize = 11.sp,
                                color = LoomOnSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }

                // Generate Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isGenerating) LoomSurfaceContainerHigh else LoomSecondary)
                        .clickable(enabled = !isGenerating && promptInput.isNotBlank()) {
                            viewModel.generateAiMotif(promptInput)
                        }
                        .padding(horizontal = 12.dp)
                        .testTag("generate_motif_button"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = LoomSecondary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Synthesizing with gemini-3.1-flash-image-preview...",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LoomOnSurface
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = LoomOnSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Generate Bauhaus Motif",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LoomOnSecondary
                        )
                    }
                }
            } else {
                // EDIT MODE
                Text(
                    text = "EDIT EXISTING TEXTILE WITH TEXT INSTRUCTION",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline,
                    letterSpacing = 0.5.sp
                )

                selectedMotif?.let { motif ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(LoomSurfaceContainerLow)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(LoomSurfaceContainerLowest),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = LoomPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Active Motif: ${motif.name}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = LoomOnSurface
                            )
                            Text(
                                text = "Coordinates: (${motif.x.toInt()}, ${motif.y.toInt()}) · Scale: ${motif.width.toInt()}px",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = LoomOutline
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = editInstructionInput,
                    onValueChange = { editInstructionInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_instruction_text_field"),
                    placeholder = {
                        Text(
                            text = "e.g. Invert colorway, add gold twill lines, or add floral embroidery",
                            fontSize = 12.sp,
                            color = LoomOutline
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LoomPrimary,
                        unfocusedBorderColor = LoomSurfaceContainerHighest,
                        focusedContainerColor = LoomSurfaceContainerLowest,
                        unfocusedContainerColor = LoomSurfaceContainerLowest,
                        focusedTextColor = LoomOnSurface,
                        unfocusedTextColor = LoomOnSurface
                    ),
                    shape = RoundedCornerShape(6.dp),
                    maxLines = 3
                )

                // Edit Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isGenerating) LoomSurfaceContainerHigh else LoomPrimary)
                        .clickable(enabled = !isGenerating && editInstructionInput.isNotBlank() && selectedMotif != null) {
                            selectedMotif?.let {
                                viewModel.editAiMotif(it, editInstructionInput)
                            }
                        }
                        .padding(horizontal = 12.dp)
                        .testTag("apply_edit_instruction_button"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = LoomPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Transforming with Gemini 3.1...",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LoomOnSurface
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = LoomOnPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Apply AI Transformation",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LoomOnPrimary
                        )
                    }
                }
            }
        }

        // Generation Result / Feedback
        when (val state = generationState) {
            is GenerationState.Error -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(LoomSurfaceContainer)
                        .border(1.dp, LoomError.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = LoomError,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Generation Notice",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LoomError
                        )
                    }
                    Text(
                        text = state.message,
                        fontSize = 12.sp,
                        color = LoomOnSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(LoomSurfaceContainerHigh)
                            .clickable { showApiKeyInput = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = LoomSecondary,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Set Custom Gemini API Key",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = LoomSecondary
                        )
                    }
                }
            }

            is GenerationState.Success -> {
                val bitmap = remember(state.imageBase64) {
                    GeminiImageService.base64ToBitmap(state.imageBase64)
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(LoomSurfaceContainer)
                        .border(1.dp, LoomSecondary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = LoomSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Synthesized Successfully",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = LoomSecondary
                            )
                        }
                        Text(
                            text = "1024×1024px",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = LoomOutline
                        )
                    }

                    if (bitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(LoomSurfaceContainerLowest),
                            contentAlignment = Alignment.Center
                        ) {
                            androidx.compose.foundation.Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = state.prompt,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(LoomSecondary)
                                .clickable {
                                    motifsHistory.firstOrNull()?.let {
                                        viewModel.applyMotifToCanvas(it)
                                    }
                                }
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Apply to Canvas",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = LoomOnSecondary
                            )
                        }

                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(LoomPrimaryContainer)
                                .clickable {
                                    viewModel.selectTab(NavigationTab.VIEW_3D)
                                }
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewInAr,
                                contentDescription = null,
                                tint = LoomOnPrimaryContainer,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Drape in 3D",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = LoomOnPrimaryContainer
                            )
                        }
                    }
                }
            }

            else -> {}
        }

        // Custom API Key Card (Collapsible)
        AnimatedVisibility(visible = showApiKeyInput) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(LoomSurfaceContainerLow)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "CONFIGURE GEMINI API KEY",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline
                )
                OutlinedTextField(
                    value = apiKeyText,
                    onValueChange = { apiKeyText = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Paste your Gemini API key here...", fontSize = 11.sp, color = LoomOutline) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LoomSecondary,
                        unfocusedBorderColor = LoomSurfaceContainerHighest,
                        focusedContainerColor = LoomSurfaceContainerLowest,
                        unfocusedContainerColor = LoomSurfaceContainerLowest,
                        focusedTextColor = LoomOnSurface,
                        unfocusedTextColor = LoomOnSurface
                    ),
                    shape = RoundedCornerShape(4.dp),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(LoomSecondary)
                            .clickable {
                                viewModel.setCustomApiKey(apiKeyText)
                                showApiKeyInput = false
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Save Key",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LoomOnSecondary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(LoomSurfaceContainerHigh)
                            .clickable { showApiKeyInput = false }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Cancel",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = LoomOnSurfaceVariant
                        )
                    }
                }
            }
        }

        // History of Generated Motifs
        if (motifsHistory.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "GENERATED TEXTILES HISTORY (${motifsHistory.size})",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = LoomOutline,
                    letterSpacing = 0.5.sp
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(motifsHistory) { motif ->
                        val bitmap = remember(motif.imageBase64) {
                            motif.imageBase64?.let { GeminiImageService.base64ToBitmap(it) }
                        }
                        Column(
                            modifier = Modifier
                                .width(120.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(LoomSurfaceContainer)
                                .clickable { viewModel.applyMotifToCanvas(motif) }
                                .padding(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(90.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(LoomSurfaceContainerLowest),
                                contentAlignment = Alignment.Center
                            ) {
                                if (bitmap != null) {
                                    androidx.compose.foundation.Image(
                                        bitmap = bitmap.asImageBitmap(),
                                        contentDescription = motif.prompt,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                            Text(
                                text = motif.name,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = LoomOnSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
