package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Colorway
import com.example.ui.LoomViewModel
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnSecondary
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceBright
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow
import com.example.ui.theme.LoomSurfaceContainerLowest

@Composable
fun PaletteStudioScreen(
    viewModel: LoomViewModel,
    modifier: Modifier = Modifier
) {
    val colorway by viewModel.colorway.collectAsState()
    val scrollState = rememberScrollState()

    var selectedSwatchIndex by remember { mutableIntStateOf(0) }
    var customHexInput by remember { mutableStateOf(colorway.colors.getOrNull(0) ?: "#D0BCFF") }

    val presetPalettes = listOf(
        Colorway("weimar", "Weimar Nocturne", listOf("#D0BCFF", "#4CD7F6", "#C0C1FF", "#2A3A4F", "#D3E4FE")),
        Colorway("destijl", "Bauhaus De Stijl", listOf("#F59E0B", "#EF4444", "#3B82F6", "#0B0C10", "#F8FAFC")),
        Colorway("gossamer", "Gossamer Pastel", listOf("#FDE68A", "#A7F3D0", "#BAE6FD", "#C7D2FE", "#FBCFE8")),
        Colorway("obsidian", "Atelier Cyber Weave", listOf("#10B981", "#06B6D4", "#6366F1", "#1E1B4B", "#E0E7FF"))
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LoomSurface)
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Column {
            Text(
                text = "Colorway & Yarn Palette Studio",
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = LoomOnSurface
            )
            Text(
                text = "OKLCH glint balance & chromatic live synchronization",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = LoomOutline
            )
        }

        // Active Colorway Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(LoomSurfaceContainer)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE COLORWAY: ${colorway.name.uppercase()}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LoomSecondary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { viewModel.toggleLiveSync() }
                ) {
                    Checkbox(
                        checked = colorway.isLiveSync,
                        onCheckedChange = { viewModel.toggleLiveSync() },
                        colors = CheckboxDefaults.colors(checkedColor = LoomPrimary),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Live Sync",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomPrimary
                    )
                }
            }

            // 5 Swatches Strip with Selection Rings
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                colorway.colors.forEachIndexed { index, hex ->
                    val color = try {
                        Color(android.graphics.Color.parseColor(hex))
                    } catch (e: Exception) {
                        LoomSecondary
                    }
                    val isSelected = selectedSwatchIndex == index

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            selectedSwatchIndex = index
                            customHexInput = hex
                        }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(color)
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) LoomSecondary else LoomOutline.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(6.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = if (hex.contains("D3E4") || hex.contains("F8FA")) LoomSurface else Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Text(
                            text = hex.take(5).uppercase(),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = if (isSelected) LoomSecondary else LoomOnSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Swatch Editor Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(LoomSurfaceContainer)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "EDIT SWATCH #${selectedSwatchIndex + 1}",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = LoomOutline
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customHexInput,
                    onValueChange = { customHexInput = it },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LoomSecondary,
                        unfocusedBorderColor = LoomSurfaceContainerHighest,
                        focusedContainerColor = LoomSurfaceContainerLowest,
                        unfocusedContainerColor = LoomSurfaceContainerLowest,
                        focusedTextColor = LoomOnSurface,
                        unfocusedTextColor = LoomOnSurface
                    ),
                    shape = RoundedCornerShape(4.dp),
                    singleLine = true
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(LoomSecondary)
                        .clickable {
                            if (customHexInput.startsWith("#") && customHexInput.length in 4..9) {
                                viewModel.updateColorSwatch(selectedSwatchIndex, customHexInput)
                                viewModel.showNotification("Updated swatch #${selectedSwatchIndex + 1} to $customHexInput")
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = "Apply",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = LoomOnSecondary
                    )
                }
            }
        }

        // Preset Colorway Libraries
        Text(
            text = "CURATED ARCHITECTURAL PALETTES",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = LoomOutline,
            letterSpacing = 0.5.sp
        )

        presetPalettes.forEach { palette ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(LoomSurfaceContainer)
                    .clickable {
                        palette.colors.forEachIndexed { i, c ->
                            viewModel.updateColorSwatch(i, c)
                        }
                        viewModel.showNotification("Applied '${palette.name}' palette")
                    }
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = palette.name,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LoomOnSurface
                    )
                    Text(
                        text = "5 Harmonics · OKLCH",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomOutline
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    palette.colors.forEach { hex ->
                        val col = try {
                            Color(android.graphics.Color.parseColor(hex))
                        } catch (e: Exception) {
                            LoomSecondary
                        }
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(col)
                        )
                    }
                }
            }
        }
    }
}
