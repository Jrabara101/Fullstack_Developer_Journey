package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.LinearScale
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.LoomViewModel
import com.example.ui.theme.LoomOnPrimary
import com.example.ui.theme.LoomOnPrimaryContainer
import com.example.ui.theme.LoomOnSecondary
import com.example.ui.theme.LoomOnSecondaryContainer
import com.example.ui.theme.LoomOnSurface
import com.example.ui.theme.LoomOnSurfaceVariant
import com.example.ui.theme.LoomOutline
import com.example.ui.theme.LoomPrimary
import com.example.ui.theme.LoomPrimaryContainer
import com.example.ui.theme.LoomSecondary
import com.example.ui.theme.LoomSecondaryContainer
import com.example.ui.theme.LoomSurface
import com.example.ui.theme.LoomSurfaceBright
import com.example.ui.theme.LoomSurfaceContainer
import com.example.ui.theme.LoomSurfaceContainerHigh
import com.example.ui.theme.LoomSurfaceContainerHighest
import com.example.ui.theme.LoomSurfaceContainerLow
import com.example.ui.theme.LoomSurfaceContainerLowest
import com.example.ui.theme.LoomTertiary

@Composable
fun PenStudioScreen(
    viewModel: LoomViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var penStrokeWidth by remember { mutableFloatStateOf(4f) }
    var symmetry4x by remember { mutableStateOf(true) }
    var isBezierMode by remember { mutableStateOf(true) }

    // Interactive points on the drafting pad
    val points = remember {
        mutableStateListOf(
            Offset(100f, 150f),
            Offset(200f, 80f),
            Offset(300f, 150f),
            Offset(200f, 240f)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(LoomSurface)
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Vector Pen & Warp Drafter",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = LoomOnSurface
                )
                Text(
                    text = "Toroidal bezier curves & jacquard nodes",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = LoomOutline
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSurfaceContainerHigh)
                    .clickable {
                        points.clear()
                        points.addAll(
                            listOf(
                                Offset(100f, 150f),
                                Offset(200f, 80f),
                                Offset(300f, 150f),
                                Offset(200f, 240f)
                            )
                        )
                        viewModel.showNotification("Drafting pad reset to default Bauhaus diamond")
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = null,
                        tint = LoomPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "Reset",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = LoomPrimary
                    )
                }
            }
        }

        // Interactive Drafting Pad
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.1f)
                .clip(RoundedCornerShape(8.dp))
                .background(LoomSurfaceContainerLowest)
                .border(1.dp, LoomSurfaceContainerHighest, RoundedCornerShape(8.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val pos = change.position
                        // Check if dragging an existing point or adding
                        val hitIndex = points.indexOfFirst {
                            (it - pos).getDistance() < 32f
                        }
                        if (hitIndex != -1) {
                            points[hitIndex] = pos
                        } else {
                            if (points.size < 12) {
                                points.add(pos)
                            }
                        }
                    }
                }
                .testTag("pen_drafting_pad"),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Background grid lines
                val step = 20.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(
                        color = Color(0xFF182E48).copy(alpha = 0.4f),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 0.5f
                    )
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(
                        color = Color(0xFF182E48).copy(alpha = 0.4f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 0.5f
                    )
                    y += step
                }

                // Draw path through points
                if (points.isNotEmpty()) {
                    val path = Path().apply {
                        moveTo(points[0].x, points[0].y)
                        for (i in 1 until points.size) {
                            if (isBezierMode && i < points.size - 1) {
                                val midX = (points[i].x + points[i + 1].x) / 2f
                                val midY = (points[i].y + points[i + 1].y) / 2f
                                quadraticTo(points[i].x, points[i].y, midX, midY)
                            } else {
                                lineTo(points[i].x, points[i].y)
                            }
                        }
                        if (points.size > 2) close()
                    }

                    // Master curve
                    drawPath(
                        path = path,
                        color = LoomSecondary,
                        style = Stroke(
                            width = penStrokeWidth.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )

                    // 4x symmetry mirrored curves
                    if (symmetry4x) {
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val mirrorPath = Path().apply {
                            moveTo(cx - (points[0].x - cx), points[0].y)
                            for (i in 1 until points.size) {
                                lineTo(cx - (points[i].x - cx), points[i].y)
                            }
                            if (points.size > 2) close()
                        }
                        drawPath(
                            path = mirrorPath,
                            color = LoomPrimary.copy(alpha = 0.6f),
                            style = Stroke(
                                width = penStrokeWidth.dp.toPx(),
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }

                    // Node pips
                    points.forEachIndexed { idx, pt ->
                        drawCircle(
                            color = LoomSecondary,
                            radius = 5.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = LoomSurface,
                            radius = 2.5.dp.toPx(),
                            center = pt
                        )
                    }
                }
            }

            // Gesture hint
            Text(
                text = "Touch and drag to sculpt vector knots",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = LoomOutline,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(8.dp)
            )
        }

        // Pen Tools Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(LoomSurfaceContainer)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isBezierMode) LoomPrimaryContainer else LoomSurfaceContainerHigh)
                        .clickable { isBezierMode = !isBezierMode }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (isBezierMode) "Bezier Smooth" else "Linear Sharp",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isBezierMode) LoomOnPrimaryContainer else LoomOnSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (symmetry4x) LoomSecondaryContainer else LoomSurfaceContainerHigh)
                        .clickable { symmetry4x = !symmetry4x }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "4× Symmetry",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (symmetry4x) LoomOnSecondaryContainer else LoomOnSurfaceVariant
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(LoomSecondary)
                    .clickable {
                        viewModel.showNotification("Vector curve applied to active canvas layer!")
                        viewModel.selectTab(com.example.data.model.NavigationTab.SELECT)
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Commit Curve",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LoomOnSecondary
                )
            }
        }

        // Stroke Width Slider
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(LoomSurfaceContainer)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Yarn Thread Gauge (Stroke Weight)",
                    fontSize = 12.sp,
                    color = LoomOnSurface
                )
                Text(
                    text = "${penStrokeWidth.toInt()} px",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = LoomSecondary
                )
            }
            Slider(
                value = penStrokeWidth,
                onValueChange = { penStrokeWidth = it },
                valueRange = 1f..12f,
                colors = SliderDefaults.colors(
                    thumbColor = LoomSecondary,
                    activeTrackColor = LoomSecondary,
                    inactiveTrackColor = LoomSurfaceContainerHighest
                ),
                modifier = Modifier.height(24.dp)
            )
        }
    }
}
