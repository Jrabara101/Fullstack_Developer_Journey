package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bauhaus Loom Design Tokens
val LoomSurface = Color(0xFF031427)
val LoomSurfaceDim = Color(0xFF031427)
val LoomSurfaceBright = Color(0xFF2A3A4F)
val LoomSurfaceContainerLowest = Color(0xFF000F21)
val LoomSurfaceContainerLow = Color(0xFF0B1C30)
val LoomSurfaceContainer = Color(0xFF102034)
val LoomSurfaceContainerHigh = Color(0xFF1B2B3F)
val LoomSurfaceContainerHighest = Color(0xFF26364A)

val LoomOnSurface = Color(0xFFD3E4FE)
val LoomOnSurfaceVariant = Color(0xFFCBC3D7)
val LoomInverseSurface = Color(0xFFD3E4FE)
val LoomInverseOnSurface = Color(0xFF213145)

val LoomOutline = Color(0xFF958EA0)
val LoomOutlineVariant = Color(0xFF494454)

val LoomPrimary = Color(0xFFD0BCFF)
val LoomOnPrimary = Color(0xFF3C0091)
val LoomPrimaryContainer = Color(0xFFA078FF)
val LoomOnPrimaryContainer = Color(0xFF340080)
val LoomPrimaryFixed = Color(0xFFE9DDFF)
val LoomPrimaryFixedDim = Color(0xFFD0BCFF)

val LoomSecondary = Color(0xFF4CD7F6)
val LoomOnSecondary = Color(0xFF003640)
val LoomSecondaryContainer = Color(0xFF03B5D3)
val LoomOnSecondaryContainer = Color(0xFF00424E)
val LoomSecondaryFixed = Color(0xFFACEDFF)
val LoomSecondaryFixedDim = Color(0xFF4CD7F6)

val LoomTertiary = Color(0xFFC0C1FF)
val LoomOnTertiary = Color(0xFF1000A9)
val LoomTertiaryContainer = Color(0xFF8083FF)
val LoomOnTertiaryContainer = Color(0xFF0D0096)

val LoomBackground = Color(0xFF031427)
val LoomOnBackground = Color(0xFFD3E4FE)

val LoomError = Color(0xFFFFB4AB)
val LoomOnError = Color(0xFF690005)

// Master Colorway Palette Defaults
val SwatchLavender = Color(0xFFD0BCFF)
val SwatchCyan = Color(0xFF4CD7F6)
val SwatchPeriwinkle = Color(0xFFC0C1FF)
val SwatchObsidian = Color(0xFF2A3A4F)
val SwatchChalk = Color(0xFFD3E4FE)
