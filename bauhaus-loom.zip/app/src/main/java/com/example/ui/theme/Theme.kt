package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val BauhausLoomColorScheme = darkColorScheme(
    primary = LoomPrimary,
    onPrimary = LoomOnPrimary,
    primaryContainer = LoomPrimaryContainer,
    onPrimaryContainer = LoomOnPrimaryContainer,
    inversePrimary = LoomPrimaryFixedDim,

    secondary = LoomSecondary,
    onSecondary = LoomOnSecondary,
    secondaryContainer = LoomSecondaryContainer,
    onSecondaryContainer = LoomOnSecondaryContainer,

    tertiary = LoomTertiary,
    onTertiary = LoomOnTertiary,
    tertiaryContainer = LoomTertiaryContainer,
    onTertiaryContainer = LoomOnTertiaryContainer,

    background = LoomBackground,
    onBackground = LoomOnBackground,

    surface = LoomSurface,
    onSurface = LoomOnSurface,
    surfaceVariant = LoomSurfaceContainerHighest,
    onSurfaceVariant = LoomOnSurfaceVariant,
    surfaceTint = LoomPrimary,

    outline = LoomOutline,
    outlineVariant = LoomOutlineVariant,

    error = LoomError,
    onError = LoomOnError
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BauhausLoomColorScheme,
        typography = Typography,
        content = content
    )
}
