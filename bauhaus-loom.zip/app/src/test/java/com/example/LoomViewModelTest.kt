package com.example

import com.example.data.model.CameraAngle
import com.example.data.model.NavigationTab
import com.example.ui.LoomViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class LoomViewModelTest {

    private lateinit var viewModel: LoomViewModel

    @Before
    fun setup() {
        viewModel = LoomViewModel()
    }

    @Test
    fun initialState_hasCorrectDefaults() {
        assertEquals(NavigationTab.SELECT, viewModel.currentTab.value)
        assertEquals("Half-Drop", viewModel.repeatMode.value)
        assertEquals(125, viewModel.zoomPercent.value)
        assertTrue(viewModel.motifs.value.isNotEmpty())
        assertEquals("motif_arch", viewModel.selectedMotifId.value)
    }

    @Test
    fun selectTab_updatesCurrentTab() {
        viewModel.selectTab(NavigationTab.VIEW_3D)
        assertEquals(NavigationTab.VIEW_3D, viewModel.currentTab.value)

        viewModel.selectTab(NavigationTab.MOTIF)
        assertEquals(NavigationTab.MOTIF, viewModel.currentTab.value)
    }

    @Test
    fun updatePhysicsParameters_updatesState() {
        viewModel.setPhysicsSheen(85)
        assertEquals(85, viewModel.physicsState.value.sheenPercent)

        viewModel.setPhysicsStiffness(45)
        assertEquals(45, viewModel.physicsState.value.stiffnessPercent)

        viewModel.setCameraAngle(CameraAngle.MICRO_10X)
        assertEquals(CameraAngle.MICRO_10X, viewModel.physicsState.value.activeCameraAngle)
    }

    @Test
    fun updateColorSwatch_updatesSelectedColor() {
        viewModel.updateColorSwatch(0, "#E9DDFF")
        assertEquals("#E9DDFF", viewModel.colorway.value.colors[0])
    }
}
