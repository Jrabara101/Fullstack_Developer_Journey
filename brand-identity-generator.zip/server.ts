import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
app.use(express.json({ limit: "10mb" }));

const PORT = 3000;

// Initialize Google GenAI client lazily or when env key exists
function getAiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is not configured.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// 1. Health check route
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// 2. Generate Brand Bible Route
app.post("/api/generate-brand-bible", async (req, res) => {
  try {
    const { mission, brandName, industry, vibe, targetAudience, colorPreference } = req.body;

    if (!mission || typeof mission !== "string" || !mission.trim()) {
      return res.status(400).json({ error: "Company mission or description is required." });
    }

    const ai = getAiClient();

    const prompt = `You are a world-class Brand Strategist and Creative Director. Create a complete, cohesive, and deeply resonant Brand Identity (Brand Bible) based on the following input:

Company Mission/Description: "${mission.trim()}"
${brandName ? `Brand Name (User Preferred): "${brandName.trim()}"` : "Brand Name: Create a powerful, memorable brand name appropriate for this mission."}
${industry ? `Industry/Sector: "${industry.trim()}"` : ""}
${vibe ? `Desired Tone & Vibe: "${vibe.trim()}"` : ""}
${targetAudience ? `Target Audience: "${targetAudience.trim()}"` : ""}
${colorPreference ? `Color Preference: "${colorPreference.trim()}"` : ""}

Generate a high-craft Brand Identity containing:
1. Brand Name & Catchy Tagline
2. Elevator Pitch (2 sentences)
3. Refined Mission Statement & Vision Statement
4. 4 Core Brand Values (title + description)
5. Voice & Tone (4 distinct adjectives, 4 Do's, 4 Don'ts, 3 Sample Brand Phrases)
6. Exactly 5 Hex Color Palette with unique color names, assigned role (Primary, Secondary, Accent, Background, Surface), and visual usage notes.
7. Google Font Pairings for Headers and Body text (must be real, popular Google Fonts like Inter, Playfair Display, Montserrat, Space Grotesk, Plus Jakarta Sans, Lora, Outfit, Syne, Cabinet Grotesk, Poppins, etc.) with Google Font URLs and design rationale.
8. Logo Design Prompts for generating vector graphics (Primary logo prompt, Secondary mark prompt, Favicon/Icon prompt) and Design Philosophy.
9. Target Audience Persona (Name, Demographics, 3 Pain Points, Key Motivation).
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction: "You generate professional, premium Brand Identity Systems in structured JSON format.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            brandName: { type: Type.STRING },
            tagline: { type: Type.STRING },
            elevatorPitch: { type: Type.STRING },
            missionStatement: { type: Type.STRING },
            visionStatement: { type: Type.STRING },
            coreValues: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                },
                required: ["title", "description"],
              },
            },
            voiceAndTone: {
              type: Type.OBJECT,
              properties: {
                adjectives: { type: Type.ARRAY, items: { type: Type.STRING } },
                dos: { type: Type.ARRAY, items: { type: Type.STRING } },
                donts: { type: Type.ARRAY, items: { type: Type.STRING } },
                samplePhrases: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ["adjectives", "dos", "donts", "samplePhrases"],
            },
            colorPalette: {
              type: Type.ARRAY,
              description: "Must contain exactly 5 cohesive colors",
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  hex: { type: Type.STRING },
                  role: { type: Type.STRING, description: "Primary, Secondary, Accent, Background, or Surface" },
                  usage: { type: Type.STRING },
                },
                required: ["name", "hex", "role", "usage"],
              },
            },
            typography: {
              type: Type.OBJECT,
              properties: {
                headerFont: {
                  type: Type.OBJECT,
                  properties: {
                    family: { type: Type.STRING },
                    category: { type: Type.STRING },
                    googleFontUrl: { type: Type.STRING },
                    rationale: { type: Type.STRING },
                  },
                  required: ["family", "category", "googleFontUrl", "rationale"],
                },
                bodyFont: {
                  type: Type.OBJECT,
                  properties: {
                    family: { type: Type.STRING },
                    category: { type: Type.STRING },
                    googleFontUrl: { type: Type.STRING },
                    rationale: { type: Type.STRING },
                  },
                  required: ["family", "category", "googleFontUrl", "rationale"],
                },
                sampleHeadline: { type: Type.STRING },
                sampleBody: { type: Type.STRING },
              },
              required: ["headerFont", "bodyFont", "sampleHeadline", "sampleBody"],
            },
            logoConcepts: {
              type: Type.OBJECT,
              properties: {
                primaryLogoPrompt: { type: Type.STRING },
                secondaryMarkPrompt: { type: Type.STRING },
                faviconPrompt: { type: Type.STRING },
                designPhilosophy: { type: Type.STRING },
              },
              required: ["primaryLogoPrompt", "secondaryMarkPrompt", "faviconPrompt", "designPhilosophy"],
            },
            targetAudience: {
              type: Type.OBJECT,
              properties: {
                personaName: { type: Type.STRING },
                demographics: { type: Type.STRING },
                painPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
                keyMotivation: { type: Type.STRING },
              },
              required: ["personaName", "demographics", "painPoints", "keyMotivation"],
            },
          },
          required: [
            "brandName",
            "tagline",
            "elevatorPitch",
            "missionStatement",
            "visionStatement",
            "coreValues",
            "voiceAndTone",
            "colorPalette",
            "typography",
            "logoConcepts",
            "targetAudience",
          ],
        },
      },
    });

    const jsonText = response.text ? response.text.trim() : "";
    if (!jsonText) {
      throw new Error("Empty response received from Gemini AI.");
    }

    const brandData = JSON.parse(jsonText);
    return res.json({ success: true, brand: brandData });
  } catch (err: any) {
    console.error("Error generating brand bible:", err);
    return res.status(500).json({
      error: err.message || "Failed to generate brand bible.",
    });
  }
});

// Helper to generate a clean SVG vector mark fallback if AI image quota is exhausted
function generateFallbackSvgLogo(prompt: string): string {
  const cleanedPrompt = prompt.replace(/[^\w\s]/gi, " ").trim();
  const words = cleanedPrompt.split(/\s+/).filter((w) => w.length > 0);
  const initials = words.slice(0, 2).map((w) => w[0].toUpperCase()).join("") || "BI";
  const label = words.slice(0, 3).join(" ").toUpperCase() || "BRAND IDENTITY";

  const palettes = [
    { bg: "#121212", fg: "#F8F7F2", accent: "#E64D3D" },
    { bg: "#2D3A30", fg: "#F8F7F2", accent: "#D9C5B2" },
    { bg: "#1A2530", fg: "#F8F7F2", accent: "#3B82F6" },
    { bg: "#2A1B28", fg: "#F8F7F2", accent: "#EC4899" },
    { bg: "#291E16", fg: "#F8F7F2", accent: "#F59E0B" },
  ];

  let hash = 0;
  for (let i = 0; i < prompt.length; i++) {
    hash = (hash << 5) - hash + prompt.charCodeAt(i);
  }
  const palette = palettes[Math.abs(hash) % palettes.length];

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
    <rect width="512" height="512" fill="${palette.bg}" rx="32" />
    <circle cx="256" cy="220" r="120" fill="none" stroke="${palette.accent}" stroke-width="6" stroke-dasharray="12 8" />
    <circle cx="256" cy="220" r="90" fill="none" stroke="${palette.fg}" stroke-width="3" opacity="0.4" />
    <polygon points="256,120 286,220 256,200 226,220" fill="${palette.accent}" />
    <text x="256" y="240" font-family="Georgia, serif" font-size="64" font-weight="bold" font-style="italic" fill="${palette.fg}" text-anchor="middle" dominant-baseline="central">${initials}</text>
    <rect x="96" y="380" width="320" height="2" fill="${palette.accent}" />
    <text x="256" y="415" font-family="'Courier New', monospace" font-size="18" font-weight="bold" fill="${palette.fg}" letter-spacing="4" text-anchor="middle">${label}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// 3. Generate Image Route for Logos & Visual Marks
app.post("/api/generate-logo", async (req, res) => {
  try {
    const { prompt, aspectRatio = "1:1", imageSize = "1K", model = "gemini-3.1-flash-image" } = req.body;

    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({ error: "Prompt is required for logo generation." });
    }

    const enhancedPrompt = `${prompt}, clean vector art style, high quality minimalist brand mark, white studio background, ultra crisp lines, graphic design standard.`;

    // Sequence of models to try in case of quota limits or unavailability
    const candidateModels = [
      model,
      "gemini-3.1-flash-image",
      "gemini-3.1-flash-lite-image",
      "gemini-3-pro-image",
    ].filter((m, i, self) => m && self.indexOf(m) === i);

    let ai: GoogleGenAI | null = null;
    try {
      ai = getAiClient();
    } catch {
      // Missing API key -> return SVG fallback
      const fallbackUrl = generateFallbackSvgLogo(prompt);
      return res.json({
        success: true,
        imageUrl: fallbackUrl,
        isFallback: true,
        warning: "Vector mark rendered (API key not configured).",
      });
    }

    let imageUrl = "";
    let lastError: any = null;

    for (const targetModel of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: targetModel,
          contents: {
            parts: [{ text: enhancedPrompt }],
          },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
              imageSize: imageSize as any,
            },
          },
        });

        if (response.candidates && response.candidates[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData && part.inlineData.data) {
              const mime = part.inlineData.mimeType || "image/png";
              imageUrl = `data:${mime};base64,${part.inlineData.data}`;
              break;
            }
          }
        }

        if (imageUrl) {
          return res.json({ success: true, imageUrl, modelUsed: targetModel });
        }
      } catch (err: any) {
        console.warn(`Attempt with model ${targetModel} failed:`, err?.message || err);
        lastError = err;
      }
    }

    // If all models failed (e.g. 429 quota exhaustion limit 0), render clean SVG fallback mark gracefully!
    console.warn("All image generation models exhausted or failed. Using crisp vector fallback logo.");
    const fallbackUrl = generateFallbackSvgLogo(prompt);

    return res.json({
      success: true,
      imageUrl: fallbackUrl,
      isFallback: true,
      warning: lastError?.message ? `Notice: AI quota reached (${lastError.message.slice(0, 100)}...). Rendered crisp vector concept.` : "Rendered crisp vector concept.",
    });
  } catch (err: any) {
    console.error("Error generating logo image:", err);
    // Even in unexpected outer error, never break the user experience
    const fallbackUrl = generateFallbackSvgLogo(req.body?.prompt || "Brand Mark");
    return res.json({
      success: true,
      imageUrl: fallbackUrl,
      isFallback: true,
      warning: "Rendered crisp vector concept.",
    });
  }
});

// 4. Multi-turn AI Chat Consultant Route
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, systemInstruction, model = "gemini-3.5-flash" } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Messages array is required." });
    }

    const ai = getAiClient();

    // Format history for chat
    const history = messages.slice(0, -1).map((m: any) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.content || m.text }],
    }));

    const lastMessage = messages[messages.length - 1];
    const userMessage = lastMessage.content || lastMessage.text || "";

    const chat = ai.chats.create({
      model: model || "gemini-3.5-flash",
      history: history,
      config: {
        systemInstruction:
          systemInstruction ||
          "You are an expert Brand Identity Consultant, Brand Designer, and Marketing Strategist. Provide concise, high-value, creative advice regarding brand strategy, logos, typography, messaging, taglines, and brand positioning.",
      },
    });

    const response = await chat.sendMessage({ message: userMessage });

    return res.json({ success: true, reply: response.text });
  } catch (err: any) {
    console.error("Error in chat endpoint:", err);
    return res.status(500).json({ error: err.message || "Chat service error." });
  }
});

// 5. Serve Vite app or static assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
