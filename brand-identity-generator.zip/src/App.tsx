import React, { useState } from "react";
import { Navbar } from "./components/Navbar";
import { MissionInputForm } from "./components/MissionInputForm";
import { BrandBibleDashboard } from "./components/BrandBibleDashboard";
import { AiChatbotDrawer } from "./components/AiChatbotDrawer";
import { ExportTokensModal } from "./components/ExportTokensModal";
import { BRAND_PRESETS } from "./data/presets";
import { BrandBible } from "./types/brand";

export default function App() {
  const [currentBrand, setCurrentBrand] = useState<BrandBible | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isTokensModalOpen, setIsTokensModalOpen] = useState(false);

  // Generate Brand Bible API call
  const handleGenerate = async (formData: {
    mission: string;
    brandName: string;
    industry: string;
    vibe: string;
    targetAudience: string;
    colorPreference: string;
  }) => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/generate-brand-bible", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok || !data.success || !data.brand) {
        throw new Error(data.error || "Failed to generate brand identity.");
      }

      const newBrand: BrandBible = {
        ...data.brand,
        id: `brand-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };

      setCurrentBrand(newBrand);
    } catch (err: any) {
      console.error("Brand Bible generation error:", err);
      setError(err.message || "An unexpected error occurred while building your Brand Bible.");
    } finally {
      setIsLoading(false);
    }
  };

  // Select Preset Example
  const handleSelectPreset = (presetId: string) => {
    const found = BRAND_PRESETS.find((p) => p.id === presetId);
    if (found) {
      setCurrentBrand(found.brand);
      setError(null);
    }
  };

  // Update specific logo or mark URL on current brand state
  const handleUpdateLogoUrl = (type: "primaryLogoUrl" | "secondaryMarkUrl" | "faviconUrl", url: string) => {
    if (!currentBrand) return;
    setCurrentBrand((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        logoConcepts: {
          ...prev.logoConcepts,
          [type]: url,
        },
      };
    });
  };

  const handleReset = () => {
    setCurrentBrand(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navigation Bar */}
      <Navbar
        currentBrand={currentBrand}
        onSelectPreset={handleSelectPreset}
        onReset={handleReset}
        onOpenTokensModal={() => setIsTokensModalOpen(true)}
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
        isChatOpen={isChatOpen}
        isGenerating={isLoading}
      />

      {/* Main Workspace View */}
      <main className="pb-20">
        {currentBrand ? (
          <BrandBibleDashboard
            brand={currentBrand}
            onUpdateLogoUrl={handleUpdateLogoUrl}
            onOpenTokensModal={() => setIsTokensModalOpen(true)}
            onReset={handleReset}
          />
        ) : (
          <MissionInputForm
            onGenerate={handleGenerate}
            onSelectPreset={handleSelectPreset}
            isLoading={isLoading}
            error={error}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t-2 border-[#121212] bg-[#121212] text-[#F8F7F2] py-6 text-center text-xs print:hidden">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-[11px]">
          <p>© {new Date().getFullYear()} Brand Identity Studio. Powered by Gemini AI Studio.</p>
          <div className="flex items-center space-x-3 text-[#D9C5B2]">
            <span className="text-[#F8F7F2]">gemini-3.6-flash</span>
            <span>•</span>
            <span className="text-[#E64D3D]">gemini-3.1-flash-image</span>
          </div>
        </div>
      </footer>

      {/* Side Chatbot Drawer */}
      <AiChatbotDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        brand={currentBrand}
      />

      {/* Export Design Tokens Modal */}
      {currentBrand && (
        <ExportTokensModal
          isOpen={isTokensModalOpen}
          onClose={() => setIsTokensModalOpen(false)}
          brand={currentBrand}
        />
      )}
    </div>
  );
}
