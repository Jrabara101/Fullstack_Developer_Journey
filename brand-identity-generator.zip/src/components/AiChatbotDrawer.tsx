import React, { useState, useRef, useEffect } from "react";
import { MessageSquareText, X, Send, Sparkles, Bot, User, Zap, Brain, Feather, Copy, Check } from "lucide-react";
import { ChatMessage, BrandBible } from "../types/brand";

interface AiChatbotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  brand: BrandBible | null;
}

export const AiChatbotDrawer: React.FC<AiChatbotDrawerProps> = ({ isOpen, onClose, brand }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-1",
      role: "model",
      content: brand
        ? `Hello! I am your AI Brand Strategy Consultant for **${brand.brandName}**. How can I help refine your taglines, copywriting, social strategy, or design guidelines today?`
        : "Hello! I am your AI Brand Identity Consultant. Describe your brand concept or ask me any strategic branding question!",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<"gemini-3.1-pro-preview" | "gemini-3.5-flash" | "gemini-3.1-flash-lite">("gemini-3.5-flash");
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText.trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    if (!textToSend) setInputText("");
    setIsLoading(true);

    try {
      const systemInstruction = brand
        ? `You are an expert Brand Identity Consultant advising the user on their brand named '${brand.brandName}'. Industry: '${brand.tagline}'. Mission: '${brand.missionStatement}'. Give creative, structured, and strategic advice for branding, logo tweaks, taglines, social media captions, or copy.`
        : "You are an expert Brand Identity Consultant helping users build strong brand bibles and visual systems.";

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, text: m.content })),
          systemInstruction,
          model: selectedModel,
        }),
      });

      const data = await res.json();
      if (!data.success || !data.reply) {
        throw new Error(data.error || "Failed to get reply from Gemini.");
      }

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: "model",
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        modelUsed: selectedModel,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      console.error("Error in AI Chat:", err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: "model",
        content: `⚠️ Error: ${err.message || "Failed to reach AI assistant."}`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(id);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[440px] bg-[#F8F7F2] border-l-2 border-[#121212] shadow-2xl flex flex-col justify-between print:hidden">
      {/* Drawer Header */}
      <div className="p-4 bg-[#121212] text-[#F8F7F2] flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 bg-[#F8F7F2] text-[#121212] border border-[#F8F7F2] flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-[#E64D3D]" />
          </div>
          <div>
            <h3 className="font-serif italic font-semibold text-base text-[#F8F7F2]">
              AI Brand Strategist
            </h3>
            <p className="text-[10px] uppercase tracking-widest text-[#D9C5B2]">Gemini Brand Consultant</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 text-[#D9C5B2] hover:text-[#FFFFFF] transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Role / Model Selector */}
      <div className="px-4 py-2 bg-[#F2EDE4] border-b border-[#121212]">
        <div className="text-[9px] font-bold uppercase tracking-widest text-[#7E6B5A] mb-1 flex items-center justify-between">
          <span>Engine Role</span>
          <span className="text-[#121212] font-mono">{selectedModel}</span>
        </div>
        <div className="grid grid-cols-3 gap-1 bg-[#FFFFFF] p-1 border border-[#121212] text-[10px]">
          <button
            onClick={() => setSelectedModel("gemini-3.1-pro-preview")}
            className={`py-1 font-bold uppercase tracking-wider flex flex-col items-center transition-all cursor-pointer ${
              selectedModel === "gemini-3.1-pro-preview"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#F8F7F2]"
            }`}
            title="Complex reasoning & deep brand strategy"
          >
            <Brain className="w-3.5 h-3.5 mb-0.5" />
            <span>3.1 Pro</span>
          </button>

          <button
            onClick={() => setSelectedModel("gemini-3.5-flash")}
            className={`py-1 font-bold uppercase tracking-wider flex flex-col items-center transition-all cursor-pointer ${
              selectedModel === "gemini-3.5-flash"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#F8F7F2]"
            }`}
            title="General copywriter & slogan tasks"
          >
            <Feather className="w-3.5 h-3.5 mb-0.5" />
            <span>3.5 Flash</span>
          </button>

          <button
            onClick={() => setSelectedModel("gemini-3.1-flash-lite")}
            className={`py-1 font-bold uppercase tracking-wider flex flex-col items-center transition-all cursor-pointer ${
              selectedModel === "gemini-3.1-flash-lite"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#F8F7F2]"
            }`}
            title="Fast responses & quick tweaks"
          >
            <Zap className="w-3.5 h-3.5 mb-0.5" />
            <span>Lite</span>
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((m) => {
          const isUser = m.role === "user";
          return (
            <div key={m.id} className={`flex items-start space-x-2.5 ${isUser ? "flex-row-reverse space-x-reverse" : ""}`}>
              <div
                className={`w-7 h-7 flex items-center justify-center flex-shrink-0 text-xs font-bold border border-[#121212] ${
                  isUser ? "bg-[#121212] text-[#F8F7F2]" : "bg-[#2D3A30] text-[#F8F7F2]"
                }`}
              >
                {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div className={`max-w-[85%] space-y-1 ${isUser ? "text-right" : ""}`}>
                <div
                  className={`p-3.5 text-xs sm:text-sm leading-relaxed border border-[#121212] font-sans ${
                    isUser
                      ? "bg-[#121212] text-[#F8F7F2] shadow-sm"
                      : "bg-[#FFFFFF] text-[#121212] shadow-sm whitespace-pre-wrap"
                  }`}
                >
                  {m.content}
                </div>

                <div className="flex items-center space-x-2 text-[10px] text-[#7E6B5A] px-1 font-mono">
                  <span>{m.timestamp}</span>
                  {!isUser && (
                    <button
                      onClick={() => handleCopyMessage(m.id, m.content)}
                      className="hover:text-[#121212] transition-colors cursor-pointer"
                      title="Copy Message"
                    >
                      {copiedMsgId === m.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center space-x-2 text-xs text-[#121212] bg-[#FFFFFF] p-3 border border-[#121212] font-serif italic">
            <Sparkles className="w-4 h-4 animate-spin text-[#E64D3D]" />
            <span>AI Consultant is crafting strategic advice...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompt Suggestions */}
      {brand && (
        <div className="p-3 bg-[#F2EDE4] border-t border-[#121212]">
          <span className="text-[9px] font-bold uppercase tracking-widest text-[#7E6B5A] block mb-1.5">Suggested Prompts</span>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => handleSendMessage("Suggest 5 catchy alternative taglines for my brand.")}
              className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 bg-[#FFFFFF] hover:bg-[#121212] hover:text-[#F8F7F2] border border-[#121212] text-[#121212] transition-colors cursor-pointer"
            >
              💡 5 Slogans
            </button>
            <button
              type="button"
              onClick={() => handleSendMessage("Write 3 Instagram launch post captions.")}
              className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 bg-[#FFFFFF] hover:bg-[#121212] hover:text-[#F8F7F2] border border-[#121212] text-[#121212] transition-colors cursor-pointer"
            >
              📲 Social Captions
            </button>
            <button
              type="button"
              onClick={() => handleSendMessage("Draft an 'About Us' story based on my mission.")}
              className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 bg-[#FFFFFF] hover:bg-[#121212] hover:text-[#F8F7F2] border border-[#121212] text-[#121212] transition-colors cursor-pointer"
            >
              📖 Founder Story
            </button>
          </div>
        </div>
      )}

      {/* Input Field Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3 bg-[#FFFFFF] border-t-2 border-[#121212] flex items-center space-x-2"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask brand consultant..."
          disabled={isLoading}
          className="flex-1 bg-[#F8F7F2] border border-[#121212] px-3.5 py-2.5 text-xs text-[#121212] placeholder-[#7E6B5A] focus:outline-none focus:ring-1 focus:ring-[#121212] font-sans"
        />
        <button
          type="submit"
          disabled={isLoading || !inputText.trim()}
          className="bg-[#121212] hover:bg-[#E64D3D] text-[#F8F7F2] p-2.5 transition-colors disabled:opacity-50 cursor-pointer border border-[#121212]"
        >
          <Send className="w-4 h-4 font-bold" />
        </button>
      </form>
    </div>
  );
};
