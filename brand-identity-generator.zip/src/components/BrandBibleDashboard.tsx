import React, { useState } from "react";
import { Sparkles, Layers, FileText, Image, Palette, Type, MessageSquare, Monitor, RefreshCw, ChevronRight } from "lucide-react";
import { BrandBible } from "../types/brand";
import { LogoSection } from "./LogoSection";
import { ColorPaletteSection } from "./ColorPaletteSection";
import { TypographySection } from "./TypographySection";
import { BrandVoiceSection } from "./BrandVoiceSection";
import { BrandMockupsSection } from "./BrandMockupsSection";

interface BrandBibleDashboardProps {
  brand: BrandBible;
  onUpdateLogoUrl: (type: "primaryLogoUrl" | "secondaryMarkUrl" | "faviconUrl", url: string) => void;
  onOpenTokensModal: () => void;
  onReset: () => void;
}

export const BrandBibleDashboard: React.FC<BrandBibleDashboardProps> = ({
  brand,
  onUpdateLogoUrl,
  onOpenTokensModal,
  onReset,
}) => {
  const [activeTab, setActiveTab] = useState<"logos" | "colors" | "typography" | "voice" | "mockups">("logos");

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Brand Header Banner */}
      <div className="relative overflow-hidden bg-[#121212] border-2 border-[#121212] p-6 sm:p-10 shadow-md text-[#F8F7F2]">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 bg-[#2D3A30] text-[#F8F7F2] border border-[#3E4E42] text-[10px] font-bold uppercase tracking-widest">
                Official Brand Bible
              </span>
              <span className="text-[10px] uppercase tracking-widest text-[#D9C5B2] font-mono">
                System v.01 / {new Date(brand.createdAt).getFullYear()}
              </span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-serif italic font-light tracking-tighter text-[#F8F7F2]">
              {brand.brandName}
            </h1>

            <p className="text-base sm:text-lg text-[#D9C5B2] font-serif italic max-w-2xl">
              "{brand.tagline}"
            </p>

            <p className="text-xs sm:text-sm text-[#F8F7F2]/80 max-w-3xl leading-relaxed font-sans">
              {brand.elevatorPitch}
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap lg:flex-col gap-2.5 self-start lg:self-center print:hidden">
            <button
              onClick={onOpenTokensModal}
              className="px-4 py-2.5 bg-[#E64D3D] hover:bg-[#121212] hover:border-[#F8F7F2] border border-[#E64D3D] text-[#FFFFFF] font-bold text-xs uppercase tracking-wider transition-colors flex items-center space-x-2 cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>Export Design Tokens</span>
            </button>

            <button
              onClick={() => window.print()}
              className="px-4 py-2.5 bg-[#222222] hover:bg-[#333333] border border-[#333333] text-[#F8F7F2] font-semibold text-xs uppercase tracking-wider transition-colors flex items-center space-x-2 cursor-pointer"
            >
              <FileText className="w-4 h-4 text-[#D9C5B2]" />
              <span>Print / Save PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Module Tabs */}
      <div className="sticky top-16 z-30 bg-[#FFFFFF] p-1.5 border-2 border-[#121212] flex overflow-x-auto gap-1 shadow-md print:hidden">
        <button
          onClick={() => setActiveTab("logos")}
          className={`flex-1 min-w-[130px] px-4 py-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer whitespace-nowrap border ${
            activeTab === "logos"
              ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
              : "bg-[#F8F7F2] text-[#121212] border-transparent hover:border-[#121212]"
          }`}
        >
          <Image className="w-4 h-4 text-[#E64D3D]" />
          <span>Logos & Marks</span>
        </button>

        <button
          onClick={() => setActiveTab("colors")}
          className={`flex-1 min-w-[130px] px-4 py-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer whitespace-nowrap border ${
            activeTab === "colors"
              ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
              : "bg-[#F8F7F2] text-[#121212] border-transparent hover:border-[#121212]"
          }`}
        >
          <Palette className="w-4 h-4 text-[#E64D3D]" />
          <span>5-Color System</span>
        </button>

        <button
          onClick={() => setActiveTab("typography")}
          className={`flex-1 min-w-[130px] px-4 py-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer whitespace-nowrap border ${
            activeTab === "typography"
              ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
              : "bg-[#F8F7F2] text-[#121212] border-transparent hover:border-[#121212]"
          }`}
        >
          <Type className="w-4 h-4 text-[#E64D3D]" />
          <span>Font Pairings</span>
        </button>

        <button
          onClick={() => setActiveTab("voice")}
          className={`flex-1 min-w-[130px] px-4 py-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer whitespace-nowrap border ${
            activeTab === "voice"
              ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
              : "bg-[#F8F7F2] text-[#121212] border-transparent hover:border-[#121212]"
          }`}
        >
          <MessageSquare className="w-4 h-4 text-[#E64D3D]" />
          <span>Voice & Persona</span>
        </button>

        <button
          onClick={() => setActiveTab("mockups")}
          className={`flex-1 min-w-[130px] px-4 py-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer whitespace-nowrap border ${
            activeTab === "mockups"
              ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
              : "bg-[#F8F7F2] text-[#121212] border-transparent hover:border-[#121212]"
          }`}
        >
          <Monitor className="w-4 h-4 text-[#E64D3D]" />
          <span>Mockup Canvas</span>
        </button>
      </div>

      {/* Active Tab View or Print Full View */}
      <div className="space-y-8">
        {(activeTab === "logos" || window.matchMedia("print").matches) && (
          <LogoSection brand={brand} onUpdateLogoUrl={onUpdateLogoUrl} />
        )}

        {(activeTab === "colors" || window.matchMedia("print").matches) && (
          <ColorPaletteSection colors={brand.colorPalette} />
        )}

        {(activeTab === "typography" || window.matchMedia("print").matches) && (
          <TypographySection typography={brand.typography} />
        )}

        {(activeTab === "voice" || window.matchMedia("print").matches) && (
          <BrandVoiceSection brand={brand} />
        )}

        {(activeTab === "mockups" || window.matchMedia("print").matches) && (
          <BrandMockupsSection brand={brand} />
        )}
      </div>
    </div>
  );
};
