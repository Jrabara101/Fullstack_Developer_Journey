import React, { useState } from "react";
import { Monitor, CreditCard, Instagram, Package, Smartphone, Sparkles, ExternalLink } from "lucide-react";
import { BrandBible } from "../types/brand";

interface BrandMockupsSectionProps {
  brand: BrandBible;
}

export const BrandMockupsSection: React.FC<BrandMockupsSectionProps> = ({ brand }) => {
  const [activeTab, setActiveTab] = useState<"businessCard" | "social" | "website" | "packaging">("website");

  // Get primary color, background color, accent color from brand palette
  const primaryColor = brand.colorPalette.find((c) => c.role === "Primary")?.hex || "#00F2FE";
  const secondaryColor = brand.colorPalette.find((c) => c.role === "Secondary")?.hex || "#4FACFE";
  const accentColor = brand.colorPalette.find((c) => c.role === "Accent")?.hex || "#7C3AED";
  const bgColor = brand.colorPalette.find((c) => c.role === "Background")?.hex || "#0B0F19";

  const headerFontFamily = brand.typography.headerFont.family;
  const bodyFontFamily = brand.typography.bodyFont.family;

  const logoImage = brand.logoConcepts.primaryLogoUrl || brand.logoConcepts.secondaryMarkUrl;

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#121212] p-6 sm:p-8 space-y-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2DEC9] pb-5">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] font-bold border-l-4 border-[#121212] pl-2 mb-1 flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#E64D3D]" />
            <span>Real-World Applications</span>
          </h3>
          <h2 className="text-2xl font-serif italic text-[#121212]">Brand Applications & Mockups</h2>
          <p className="text-[#7E6B5A] text-xs sm:text-sm mt-0.5">
            Interactive real-time preview applying your generated logos, fonts, and 5-color palette across collateral.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex bg-[#F8F7F2] p-1 border border-[#121212] self-start sm:self-auto overflow-x-auto max-w-full">
          <button
            onClick={() => setActiveTab("website")}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "website"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#E2DEC9]"
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Website Hero</span>
          </button>

          <button
            onClick={() => setActiveTab("businessCard")}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "businessCard"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#E2DEC9]"
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Business Card</span>
          </button>

          <button
            onClick={() => setActiveTab("social")}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "social"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#E2DEC9]"
            }`}
          >
            <Instagram className="w-3.5 h-3.5" />
            <span>Social Banner</span>
          </button>

          <button
            onClick={() => setActiveTab("packaging")}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "packaging"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#E2DEC9]"
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Packaging</span>
          </button>
        </div>
      </div>

      {/* Mockup Canvas Viewports */}
      <div className="pt-2">
        {/* 1. Website Hero Mockup */}
        {activeTab === "website" && (
          <div className="border-2 border-[#121212] overflow-hidden shadow-md bg-[#F8F7F2]">
            {/* Browser Header Bar */}
            <div className="bg-[#121212] px-4 py-2.5 border-b border-[#121212] flex items-center space-x-2">
              <div className="flex space-x-1.5">
                <div className="w-3 h-3 rounded-full bg-[#E64D3D]" />
                <div className="w-3 h-3 rounded-full bg-[#D9C5B2]" />
                <div className="w-3 h-3 rounded-full bg-[#2D3A30]" />
              </div>
              <div className="flex-1 max-w-sm mx-auto bg-[#F8F7F2] px-3 py-0.5 text-[11px] text-[#121212] font-mono text-center border border-[#121212] truncate">
                https://www.{brand.brandName.toLowerCase().replace(/\s+/g, "")}.com
              </div>
            </div>

            {/* Website Canvas */}
            <div
              style={{ backgroundColor: bgColor }}
              className="p-8 sm:p-12 text-[#121212] min-h-[380px] flex flex-col justify-between relative overflow-hidden"
            >
              {/* Navbar */}
              <div className="flex items-center justify-between border-b border-[#121212]/20 pb-4 mb-8">
                <div className="flex items-center space-x-3">
                  {logoImage ? (
                    <img
                      src={logoImage}
                      alt="Logo"
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 object-contain bg-white/80 p-1 border border-[#121212]"
                    />
                  ) : (
                    <div
                      style={{ backgroundColor: primaryColor }}
                      className="w-8 h-8 flex items-center justify-center font-bold text-[#121212] text-xs border border-[#121212]"
                    >
                      {brand.brandName.charAt(0)}
                    </div>
                  )}
                  <span
                    style={{ fontFamily: `'${headerFontFamily}', serif` }}
                    className="font-bold text-xl text-[#121212]"
                  >
                    {brand.brandName}
                  </span>
                </div>

                <div className="hidden sm:flex items-center space-x-6 text-xs text-[#121212] font-bold uppercase tracking-wider">
                  <span>Product</span>
                  <span>Features</span>
                  <span>Pricing</span>
                  <span>About</span>
                  <button
                    style={{ backgroundColor: primaryColor }}
                    className="px-3.5 py-1.5 font-bold text-[#121212] text-xs border border-[#121212] shadow-sm uppercase tracking-wider"
                  >
                    Get Started
                  </button>
                </div>
              </div>

              {/* Hero Content */}
              <div className="max-w-2xl mx-auto text-center space-y-4 my-auto">
                <span
                  style={{ color: primaryColor, backgroundColor: `${primaryColor}15`, borderColor: `${primaryColor}` }}
                  className="inline-block px-3 py-1 text-xs font-bold border uppercase tracking-widest"
                >
                  {brand.tagline}
                </span>

                <h1
                  style={{ fontFamily: `'${headerFontFamily}', serif` }}
                  className="text-3xl sm:text-5xl font-serif italic font-bold text-[#121212] leading-tight"
                >
                  {brand.typography.sampleHeadline}
                </h1>

                <p
                  style={{ fontFamily: `'${bodyFontFamily}', sans-serif` }}
                  className="text-xs sm:text-sm text-[#333333] leading-relaxed max-w-xl mx-auto font-sans"
                >
                  {brand.elevatorPitch}
                </p>

                <div className="flex items-center justify-center space-x-3 pt-2">
                  <button
                    style={{ backgroundColor: primaryColor }}
                    className="px-5 py-2.5 font-bold text-[#121212] text-xs sm:text-sm border border-[#121212] uppercase tracking-wider shadow-sm hover:opacity-90 transition-opacity cursor-pointer"
                  >
                    Explore Experience
                  </button>
                  <button className="px-5 py-2.5 font-bold text-[#121212] border border-[#121212] bg-[#FFFFFF] text-xs sm:text-sm uppercase tracking-wider hover:bg-[#F8F7F2] transition-colors cursor-pointer">
                    Watch Demo
                  </button>
                </div>
              </div>

              <div className="text-center text-[10px] text-[#7E6B5A] pt-8 font-mono">
                © {new Date().getFullYear()} {brand.brandName}. All rights reserved.
              </div>
            </div>
          </div>
        )}

        {/* 2. Business Card Mockup */}
        {activeTab === "businessCard" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Front of Card */}
            <div
              style={{ backgroundColor: bgColor, borderColor: "#121212" }}
              className="aspect-[1.75/1] border-2 p-6 flex flex-col justify-between shadow-md relative overflow-hidden"
            >
              <div className="flex items-center space-x-3">
                {logoImage ? (
                  <img
                    src={logoImage}
                    alt="Logo"
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 object-contain bg-white p-1 border border-[#121212]"
                  />
                ) : (
                  <div
                    style={{ backgroundColor: primaryColor }}
                    className="w-10 h-10 border border-[#121212] flex items-center justify-center font-extrabold text-[#121212] text-sm"
                  >
                    {brand.brandName.charAt(0)}
                  </div>
                )}
                <div>
                  <h3
                    style={{ fontFamily: `'${headerFontFamily}', serif` }}
                    className="font-bold text-xl font-serif italic text-[#121212] tracking-wide"
                  >
                    {brand.brandName}
                  </h3>
                  <p className="text-[11px] text-[#7E6B5A] uppercase tracking-wider font-sans">{brand.tagline}</p>
                </div>
              </div>

              <div className="self-end text-right">
                <span
                  style={{ color: primaryColor }}
                  className="text-xs font-mono font-bold tracking-widest block uppercase"
                >
                  PREMIUM EDITION
                </span>
              </div>
            </div>

            {/* Back of Card */}
            <div
              style={{ backgroundColor: "#F8F7F2", borderLeftColor: primaryColor }}
              className="aspect-[1.75/1] border-2 border-l-8 border-[#121212] p-6 flex flex-col justify-between shadow-md"
            >
              <div>
                <h4
                  style={{ fontFamily: `'${headerFontFamily}', serif` }}
                  className="font-bold text-lg font-serif italic text-[#121212]"
                >
                  {brand.targetAudience.personaName}
                </h4>
                <p style={{ color: primaryColor }} className="text-xs font-bold uppercase tracking-wider mt-0.5">
                  Founder & Chief Executive Officer
                </p>
              </div>

              <div className="space-y-1 text-xs text-[#121212] font-mono">
                <p>m.{brand.brandName.toLowerCase().replace(/\s+/g, "")}@brand.com</p>
                <p>+1 (800) 555-0199</p>
                <p>www.{brand.brandName.toLowerCase().replace(/\s+/g, "")}.com</p>
              </div>
            </div>
          </div>
        )}

        {/* 3. Social Media Banner Mockup */}
        {activeTab === "social" && (
          <div className="max-w-xl mx-auto border-2 border-[#121212] bg-[#F8F7F2] shadow-md">
            {/* Instagram Header */}
            <div className="bg-[#121212] p-3 flex items-center justify-between border-b border-[#121212]">
              <div className="flex items-center space-x-2.5">
                <div
                  style={{ backgroundColor: primaryColor }}
                  className="w-7 h-7 flex items-center justify-center font-bold text-[#121212] text-xs border border-white/20"
                >
                  {brand.brandName.charAt(0)}
                </div>
                <span className="font-bold text-xs text-[#F8F7F2] uppercase tracking-wider">
                  {brand.brandName.toLowerCase().replace(/\s+/g, "_")}
                </span>
              </div>
              <Instagram className="w-4 h-4 text-[#F8F7F2]" />
            </div>

            {/* Post Image Banner */}
            <div
              style={{
                backgroundColor: bgColor,
              }}
              className="aspect-square p-8 flex flex-col justify-between items-center text-center relative overflow-hidden border-b border-[#121212]"
            >
              {logoImage && (
                <img
                  src={logoImage}
                  alt="Logo"
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 object-contain bg-white p-2 border border-[#121212] shadow-sm"
                />
              )}

              <div className="my-auto space-y-3">
                <h2
                  style={{ fontFamily: `'${headerFontFamily}', serif` }}
                  className="text-2xl sm:text-3xl font-serif italic font-bold text-[#121212] leading-tight"
                >
                  "{brand.voiceAndTone.samplePhrases[0] || brand.tagline}"
                </h2>
                <p
                  style={{ color: primaryColor, fontFamily: `'${bodyFontFamily}', sans-serif` }}
                  className="text-xs font-bold uppercase tracking-widest"
                >
                  — {brand.brandName} Manifesto
                </p>
              </div>

              <div className="text-[10px] text-[#7E6B5A] font-mono">
                #BrandIdentity #{brand.brandName.replace(/\s+/g, "")} #ArtisticFlair
              </div>
            </div>
          </div>
        )}

        {/* 4. Product Packaging Mockup */}
        {activeTab === "packaging" && (
          <div className="max-w-2xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Box Rendering */}
            <div className="aspect-square bg-[#F8F7F2] border-2 border-[#121212] p-8 flex flex-col justify-between items-center text-center shadow-md relative">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#7E6B5A]">
                Packaging Front Box
              </span>

              <div className="space-y-4 my-auto">
                {logoImage ? (
                  <img
                    src={logoImage}
                    alt="Logo"
                    referrerPolicy="no-referrer"
                    className="w-20 h-20 mx-auto object-contain bg-white p-2 border border-[#121212] shadow-sm"
                  />
                ) : (
                  <div
                    style={{ backgroundColor: primaryColor }}
                    className="w-16 h-16 mx-auto border border-[#121212] flex items-center justify-center font-extrabold text-[#121212] text-2xl"
                  >
                    {brand.brandName.charAt(0)}
                  </div>
                )}

                <div>
                  <h3
                    style={{ fontFamily: `'${headerFontFamily}', serif` }}
                    className="text-2xl font-serif italic font-bold text-[#121212]"
                  >
                    {brand.brandName}
                  </h3>
                  <p style={{ color: primaryColor }} className="text-xs font-bold uppercase tracking-wider mt-1">
                    {brand.tagline}
                  </p>
                </div>
              </div>

              <div className="text-[11px] text-[#7E6B5A] border-t border-[#E2DEC9] pt-2 w-full font-mono">
                NET WT. 250ML / 8.5 FL. OZ
              </div>
            </div>

            {/* Label / Bottle Back Detail */}
            <div className="aspect-square bg-[#F8F7F2] border-2 border-[#121212] p-6 flex flex-col justify-between text-xs text-[#121212] shadow-md">
              <div>
                <span style={{ color: primaryColor }} className="font-bold uppercase tracking-widest text-[10px] block">
                  Product Formula & Heritage
                </span>
                <p className="mt-2 text-[#333333] leading-relaxed text-xs font-sans">
                  {brand.missionStatement}
                </p>
              </div>

              <div className="space-y-2 border-t border-[#E2DEC9] pt-3">
                <span className="font-bold text-[#121212] uppercase tracking-wider block text-[10px]">Core Attributes:</span>
                <div className="flex flex-wrap gap-1.5">
                  {brand.voiceAndTone.adjectives.map((a) => (
                    <span key={a} className="bg-[#FFFFFF] border border-[#121212] px-2 py-0.5 text-[9px] text-[#121212] font-mono font-bold uppercase">
                      {a}
                    </span>
                  ))}
                </div>
              </div>

              <div className="text-[10px] text-[#7E6B5A] font-mono pt-2 border-t border-[#E2DEC9]">
                Designed & Formulated by {brand.brandName} Studio
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
