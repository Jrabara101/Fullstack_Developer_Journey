import React from "react";
import { MessageSquare, CheckCircle2, XCircle, Users, Target, ShieldCheck, Sparkles, Quote } from "lucide-react";
import { BrandBible } from "../types/brand";

interface BrandVoiceSectionProps {
  brand: BrandBible;
}

export const BrandVoiceSection: React.FC<BrandVoiceSectionProps> = ({ brand }) => {
  return (
    <div className="bg-[#FFFFFF] border-2 border-[#121212] p-6 sm:p-8 space-y-8 shadow-sm">
      {/* Header */}
      <div className="border-b border-[#E2DEC9] pb-5">
        <h3 className="text-[10px] uppercase tracking-[0.2em] font-bold border-l-4 border-[#121212] pl-2 mb-1 flex items-center space-x-1.5">
          <MessageSquare className="w-3.5 h-3.5 text-[#E64D3D]" />
          <span>Brand Voice & Strategy Bible</span>
        </h3>
        <h2 className="text-2xl font-serif italic text-[#121212]">Tone, Values & Audience Persona</h2>
        <p className="text-[#7E6B5A] text-xs sm:text-sm mt-0.5">
          Messaging guidelines, communication principles, and target audience alignment.
        </p>
      </div>

      {/* Grid: Voice Adjectives & Elevator Pitch */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (5 cols): Voice Adjectives */}
        <div className="lg:col-span-5 bg-[#F8F7F2] border border-[#121212] p-6 space-y-4">
          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#121212] flex items-center space-x-2">
            <Sparkles className="w-3.5 h-3.5 text-[#E64D3D]" />
            <span>Voice & Tone Pillars</span>
          </h3>
          <div className="flex flex-wrap gap-2">
            {brand.voiceAndTone.adjectives.map((adj) => (
              <span
                key={adj}
                className="px-3.5 py-1.5 bg-[#FFFFFF] border border-[#121212] text-[#121212] text-xs font-bold uppercase tracking-wider shadow-sm"
              >
                {adj}
              </span>
            ))}
          </div>

          <div className="pt-3 border-t border-[#E2DEC9] space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#7E6B5A] block">Sample Brand Phrases</span>
            <ul className="space-y-2 text-xs text-[#121212]">
              {brand.voiceAndTone.samplePhrases.map((phrase, idx) => (
                <li key={idx} className="flex items-start space-x-2 font-serif italic">
                  <Quote className="w-3.5 h-3.5 text-[#E64D3D] flex-shrink-0 mt-0.5" />
                  <span>"{phrase}"</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right (7 cols): Mission & Elevator Pitch */}
        <div className="lg:col-span-7 bg-[#F8F7F2] border border-[#121212] p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <span className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 bg-[#121212] text-[#F8F7F2]">
                Elevator Pitch
              </span>
              <p className="text-base text-[#121212] font-serif italic mt-2 leading-relaxed">
                "{brand.elevatorPitch}"
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-[#E2DEC9]">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#7E6B5A] block">Refined Mission</span>
                <p className="text-xs text-[#333333] mt-1 leading-relaxed font-sans">{brand.missionStatement}</p>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#7E6B5A] block">Long-Term Vision</span>
                <p className="text-xs text-[#333333] mt-1 leading-relaxed font-sans">{brand.visionStatement}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Do's and Don'ts Table */}
      <div className="space-y-3">
        <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#121212] flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-[#2D3A30]" />
          <span>Communication Guidelines (Do's & Don'ts)</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Do's Card */}
          <div className="bg-[#F2EDE4] border-2 border-[#2D3A30] p-5 space-y-3">
            <div className="flex items-center space-x-2 text-[#2D3A30] font-bold text-xs uppercase tracking-widest">
              <CheckCircle2 className="w-4 h-4" />
              <span>DO</span>
            </div>
            <ul className="space-y-2 text-xs text-[#121212] font-sans">
              {brand.voiceAndTone.dos.map((item, idx) => (
                <li key={idx} className="flex items-start space-x-2">
                  <span className="text-[#2D3A30] font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Don'ts Card */}
          <div className="bg-[#F2EDE4] border-2 border-[#E64D3D] p-5 space-y-3">
            <div className="flex items-center space-x-2 text-[#E64D3D] font-bold text-xs uppercase tracking-widest">
              <XCircle className="w-4 h-4" />
              <span>DON'T</span>
            </div>
            <ul className="space-y-2 text-[#121212] text-xs font-sans">
              {brand.voiceAndTone.donts.map((item, idx) => (
                <li key={idx} className="flex items-start space-x-2">
                  <span className="text-[#E64D3D] font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Core Values & Target Audience Persona Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Core Values (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#121212] flex items-center space-x-2">
            <Target className="w-4 h-4 text-[#7E6B5A]" />
            <span>Core Brand Values</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {brand.coreValues.map((value, idx) => (
              <div key={idx} className="bg-[#F8F7F2] border border-[#121212] p-4 space-y-1">
                <span className="text-[10px] font-bold text-[#E64D3D] uppercase">0{idx + 1}</span>
                <h4 className="font-serif italic font-bold text-sm text-[#121212]">{value.title}</h4>
                <p className="text-[11px] text-[#333333] leading-snug font-sans">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Target Audience Persona Card (5 cols) */}
        <div className="lg:col-span-5 bg-[#F8F7F2] border-2 border-[#121212] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#E2DEC9] pb-3">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-[#E64D3D]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#121212]">Target Audience Persona</h3>
            </div>
            <span className="text-[9px] font-bold text-[#F8F7F2] bg-[#121212] px-2 py-0.5 uppercase tracking-widest">
              Ideal Customer
            </span>
          </div>

          <div>
            <h4 className="text-xl font-serif italic text-[#121212]">{brand.targetAudience.personaName}</h4>
            <p className="text-xs uppercase tracking-wider text-[#7E6B5A] mt-0.5">{brand.targetAudience.demographics}</p>
          </div>

          <div className="space-y-2">
            <span className="text-[10px] font-bold text-[#7E6B5A] uppercase tracking-wider block">Pain Points</span>
            <ul className="space-y-1 text-xs text-[#121212] font-sans">
              {brand.targetAudience.painPoints.map((pt, idx) => (
                <li key={idx} className="flex items-start space-x-2">
                  <span className="text-[#E64D3D]">✦</span>
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-2 border-t border-[#E2DEC9]">
            <span className="text-[10px] font-bold text-[#7E6B5A] uppercase tracking-wider block">Key Motivation</span>
            <p className="text-xs text-[#121212] font-serif italic font-semibold mt-0.5">{brand.targetAudience.keyMotivation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
