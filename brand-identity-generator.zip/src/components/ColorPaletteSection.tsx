import React, { useState } from "react";
import { Palette, Copy, Check, ShieldCheck, Sparkles, Code2 } from "lucide-react";
import { ColorItem } from "../types/brand";
import { getWCAGBadge, getTextColorForBackground } from "../utils/colorUtils";

interface ColorPaletteSectionProps {
  colors: ColorItem[];
}

export const ColorPaletteSection: React.FC<ColorPaletteSectionProps> = ({ colors }) => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  const [copiedCss, setCopiedCss] = useState(false);

  const handleCopyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  const handleCopyCssVariables = () => {
    const cssVars = colors
      .map((c) => `--color-${c.role.toLowerCase()}: ${c.hex}; /* ${c.name} */`)
      .join("\n");
    navigator.clipboard.writeText(`:root {\n${cssVars}\n}`);
    setCopiedCss(true);
    setTimeout(() => setCopiedCss(false), 2000);
  };

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#121212] p-6 sm:p-8 space-y-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2DEC9] pb-5">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] font-bold border-l-4 border-[#121212] pl-2 mb-1 flex items-center space-x-1.5">
            <Palette className="w-3.5 h-3.5 text-[#E64D3D]" />
            <span>Harmonized Color System</span>
          </h3>
          <h2 className="text-2xl font-serif italic text-[#121212]">5-Color Hex Palette & Guidelines</h2>
          <p className="text-[#7E6B5A] text-xs sm:text-sm mt-0.5">
            Curated 5-tone brand palette with designated roles, WCAG accessibility benchmarks, and usage notes.
          </p>
        </div>

        <button
          onClick={handleCopyCssVariables}
          className="inline-flex items-center space-x-2 bg-[#121212] hover:bg-[#E64D3D] border border-[#121212] text-[#F8F7F2] px-3.5 py-2 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer self-start sm:self-auto"
        >
          {copiedCss ? (
            <>
              <Check className="w-4 h-4 text-[#F8F7F2]" />
              <span>CSS Copied!</span>
            </>
          ) : (
            <>
              <Code2 className="w-4 h-4 text-[#D9C5B2]" />
              <span>Copy CSS Variables</span>
            </>
          )}
        </button>
      </div>

      {/* Combined Color Harmony Bar */}
      <div className="space-y-1.5">
        <div className="text-[10px] font-bold uppercase tracking-wider text-[#7E6B5A] flex items-center justify-between">
          <span>Palette Proportion Balance</span>
          <span>5-Tone Chromatic Ratio</span>
        </div>
        <div className="h-7 w-full border-2 border-[#121212] overflow-hidden flex shadow-sm">
          {colors.map((color, idx) => {
            const widthPct = idx === 0 ? "35%" : idx === 1 ? "25%" : idx === 2 ? "15%" : "12.5%";
            return (
              <div
                key={color.hex + idx}
                style={{ backgroundColor: color.hex, width: widthPct }}
                className="h-full relative group transition-transform hover:scale-105 hover:z-10 cursor-pointer border-r last:border-r-0 border-[#121212]/30"
                title={`${color.name} (${color.role}): ${color.hex}`}
                onClick={() => handleCopyHex(color.hex)}
              />
            );
          })}
        </div>
      </div>

      {/* 5 Color Swatch Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 pt-2">
        {colors.map((color) => {
          const textColor = getTextColorForBackground(color.hex);
          const wcagOnWhite = getWCAGBadge(color.hex, "#FFFFFF");
          const isCopied = copiedHex === color.hex;

          return (
            <div
              key={color.hex + color.role}
              className="bg-[#F8F7F2] border border-[#121212] overflow-hidden shadow-sm flex flex-col justify-between hover:border-[#E64D3D] transition-all group"
            >
              {/* Top Color Box */}
              <div
                style={{ backgroundColor: color.hex }}
                className="h-28 w-full p-3 flex flex-col justify-between relative cursor-pointer border-b border-[#121212]"
                onClick={() => handleCopyHex(color.hex)}
              >
                {/* Role Badge */}
                <span
                  style={{ color: textColor, backgroundColor: textColor === "#FFFFFF" ? "rgba(0,0,0,0.4)" : "rgba(255,255,255,0.6)" }}
                  className="self-start text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 border border-[#121212]/20"
                >
                  {color.role}
                </span>

                {/* Hex Display & Copy Overlay */}
                <div className="flex items-center justify-between">
                  <span style={{ color: textColor }} className="font-mono font-bold text-xs tracking-widest">
                    {color.hex}
                  </span>
                  <button
                    style={{ color: textColor }}
                    className="p-1 bg-black/10 hover:bg-black/30 transition-colors"
                    title="Copy Hex Code"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Bottom Card Info */}
              <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-serif italic font-semibold text-base text-[#121212] group-hover:text-[#E64D3D] transition-colors">
                    {color.name}
                  </h3>
                  <p className="text-[11px] text-[#333333] mt-1 leading-snug line-clamp-3 font-sans">
                    {color.usage}
                  </p>
                </div>

                {/* Accessibility Badge */}
                <div className="pt-2 border-t border-[#E2DEC9] flex items-center justify-between text-[10px]">
                  <span className="text-[#7E6B5A] font-bold uppercase tracking-wider flex items-center space-x-1">
                    <ShieldCheck className="w-3 h-3 text-[#121212]" />
                    <span>Contrast</span>
                  </span>
                  <span
                    className={`font-bold uppercase tracking-wider px-1.5 py-0.5 border ${
                      wcagOnWhite.pass ? "bg-[#2D3A30] text-[#F8F7F2] border-[#2D3A30]" : "bg-[#F2EDE4] text-[#7E6B5A] border-[#D9C5B2]"
                    }`}
                  >
                    {wcagOnWhite.label}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
