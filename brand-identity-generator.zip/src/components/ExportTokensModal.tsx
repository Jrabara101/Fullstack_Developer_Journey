import React, { useState } from "react";
import { X, Layers, Copy, Check, Download, Code, FileCode } from "lucide-react";
import { BrandBible } from "../types/brand";

interface ExportTokensModalProps {
  isOpen: boolean;
  onClose: () => void;
  brand: BrandBible;
}

export const ExportTokensModal: React.FC<ExportTokensModalProps> = ({ isOpen, onClose, brand }) => {
  const [activeFormat, setActiveFormat] = useState<"css" | "tailwind" | "json">("css");
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const getCssVars = () => {
    const vars = brand.colorPalette
      .map((c) => `  --color-${c.role.toLowerCase()}: ${c.hex}; /* ${c.name} */`)
      .join("\n");
    return `:root {\n  /* ${brand.brandName} Design Tokens */\n${vars}\n  --font-header: '${brand.typography.headerFont.family}', sans-serif;\n  --font-body: '${brand.typography.bodyFont.family}', sans-serif;\n}`;
  };

  const getTailwindConfig = () => {
    const colorsObj = brand.colorPalette.reduce((acc, c) => {
      acc[c.role.toLowerCase()] = c.hex;
      return acc;
    }, {} as Record<string, string>);

    return `// tailwind.config.js for ${brand.brandName}
module.exports = {
  theme: {
    extend: {
      colors: ${JSON.stringify(colorsObj, null, 8)},
      fontFamily: {
        header: ['"${brand.typography.headerFont.family}"', 'sans-serif'],
        body: ['"${brand.typography.bodyFont.family}"', 'sans-serif'],
      },
    },
  },
};`;
  };

  const getJsonManifest = () => {
    return JSON.stringify(brand, null, 2);
  };

  const getActiveCode = () => {
    if (activeFormat === "css") return getCssVars();
    if (activeFormat === "tailwind") return getTailwindConfig();
    return getJsonManifest();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getActiveCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const code = getActiveCode();
    const ext = activeFormat === "json" ? "json" : activeFormat === "tailwind" ? "js" : "css";
    const blob = new Blob([code], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${brand.brandName.toLowerCase().replace(/\s+/g, "-")}-tokens.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#121212]/70 backdrop-blur-sm flex items-center justify-center p-4 print:hidden">
      <div className="bg-[#F8F7F2] border-2 border-[#121212] w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="p-5 bg-[#121212] text-[#F8F7F2] flex items-center justify-between border-b border-[#121212]">
          <div className="flex items-center space-x-2.5">
            <Layers className="w-5 h-5 text-[#E64D3D]" />
            <div>
              <h3 className="font-serif italic font-semibold text-lg text-[#F8F7F2]">Export Design Tokens</h3>
              <p className="text-[10px] uppercase tracking-widest text-[#D9C5B2]">Copy CSS, Tailwind Config, or JSON manifests</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-[#D9C5B2] hover:text-[#FFFFFF] cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Format Selector Tabs */}
        <div className="px-5 py-3 bg-[#F2EDE4] border-b border-[#121212] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex space-x-1.5 overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveFormat("css")}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                activeFormat === "css" ? "bg-[#121212] text-[#F8F7F2]" : "bg-[#FFFFFF] border border-[#121212] text-[#121212] hover:bg-[#F8F7F2]"
              }`}
            >
              CSS Vars
            </button>
            <button
              onClick={() => setActiveFormat("tailwind")}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                activeFormat === "tailwind" ? "bg-[#121212] text-[#F8F7F2]" : "bg-[#FFFFFF] border border-[#121212] text-[#121212] hover:bg-[#F8F7F2]"
              }`}
            >
              Tailwind
            </button>
            <button
              onClick={() => setActiveFormat("json")}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                activeFormat === "json" ? "bg-[#121212] text-[#F8F7F2]" : "bg-[#FFFFFF] border border-[#121212] text-[#121212] hover:bg-[#F8F7F2]"
              }`}
            >
              Full JSON
            </button>
          </div>

          <div className="flex items-center space-x-2 self-end sm:self-auto">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 bg-[#FFFFFF] hover:bg-[#121212] hover:text-[#F8F7F2] border border-[#121212] text-[#121212] text-xs font-bold uppercase tracking-wider transition-colors flex items-center space-x-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied!" : "Copy"}</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-3 py-1.5 bg-[#121212] hover:bg-[#E64D3D] text-[#F8F7F2] text-xs font-bold uppercase tracking-wider transition-colors flex items-center space-x-1.5 cursor-pointer border border-[#121212]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Code Content View */}
        <div className="p-5 flex-1 overflow-y-auto bg-[#FFFFFF] border-t border-[#121212] font-mono text-xs text-[#121212] leading-relaxed">
          <pre>{getActiveCode()}</pre>
        </div>
      </div>
    </div>
  );
};
