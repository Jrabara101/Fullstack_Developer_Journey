import React, { useState } from "react";
import { Sparkles, Download, RefreshCw, Sliders, Image, Sparkle, Maximize2, Layers } from "lucide-react";
import { BrandBible, ImageSizeOption, AspectRatioOption } from "../types/brand";

interface LogoSectionProps {
  brand: BrandBible;
  onUpdateLogoUrl: (type: "primaryLogoUrl" | "secondaryMarkUrl" | "faviconUrl", url: string) => void;
}

export const LogoSection: React.FC<LogoSectionProps> = ({ brand, onUpdateLogoUrl }) => {
  const [selectedType, setSelectedType] = useState<"primaryLogoUrl" | "secondaryMarkUrl" | "faviconUrl">("primaryLogoUrl");
  const [model, setModel] = useState<"gemini-3.1-flash-image" | "gemini-3.1-flash-lite-image" | "gemini-3-pro-image-preview">("gemini-3.1-flash-image");
  const [imageSize, setImageSize] = useState<ImageSizeOption>("1K");
  const [aspectRatio, setAspectRatio] = useState<AspectRatioOption>("1:1");
  const [customPrompt, setCustomPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [genNotice, setGenNotice] = useState<string | null>(null);

  // Default active prompt based on selected asset tab
  const getActivePrompt = () => {
    if (customPrompt) return customPrompt;
    if (selectedType === "primaryLogoUrl") return brand.logoConcepts.primaryLogoPrompt;
    if (selectedType === "secondaryMarkUrl") return brand.logoConcepts.secondaryMarkPrompt;
    return brand.logoConcepts.faviconPrompt;
  };

  const currentImageUrl = brand.logoConcepts[selectedType];

  const handleGenerateLogo = async () => {
    setIsGenerating(true);
    setGenError(null);
    setGenNotice(null);

    const promptToUse = customPrompt.trim() || getActivePrompt();

    try {
      const res = await fetch("/api/generate-logo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: promptToUse,
          aspectRatio,
          imageSize,
          model,
        }),
      });

      const data = await res.json();
      if (!data.success || !data.imageUrl) {
        throw new Error(data.error || "Failed to generate image.");
      }

      if (data.warning) {
        setGenNotice(data.warning);
      }

      onUpdateLogoUrl(selectedType, data.imageUrl);
    } catch (err: any) {
      console.error("Error generating logo image:", err);
      setGenError(err.message || "Failed to generate logo image.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (type: string, url: string) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = `${brand.brandName.toLowerCase().replace(/\s+/g, "-")}-${type}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#121212] p-6 sm:p-8 space-y-8 shadow-sm">
      {/* Section Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2DEC9] pb-5">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] font-bold border-l-4 border-[#121212] pl-2 mb-1 flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#E64D3D]" />
            <span>Visual Identity & Asset Studio</span>
          </h3>
          <h2 className="text-2xl font-serif italic text-[#121212]">Logos & Secondary Marks</h2>
          <p className="text-[#7E6B5A] text-xs sm:text-sm mt-0.5">
            Vector concepts generated with Imagen & Gemini <span className="text-[#121212] font-bold">gemini-3.1-flash-image</span> at 1K, 2K, or 4K.
          </p>
        </div>

        {/* Tab Switcher for Primary / Secondary / Favicon */}
        <div className="flex bg-[#F8F7F2] p-1 border border-[#121212] self-start sm:self-auto">
          <button
            onClick={() => {
              setSelectedType("primaryLogoUrl");
              setCustomPrompt("");
            }}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedType === "primaryLogoUrl"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#E2DEC9]"
            }`}
          >
            Primary Logo
          </button>
          <button
            onClick={() => {
              setSelectedType("secondaryMarkUrl");
              setCustomPrompt("");
            }}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedType === "secondaryMarkUrl"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#E2DEC9]"
            }`}
          >
            Secondary Mark
          </button>
          <button
            onClick={() => {
              setSelectedType("faviconUrl");
              setCustomPrompt("");
            }}
            className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedType === "faviconUrl"
                ? "bg-[#121212] text-[#F8F7F2]"
                : "text-[#121212] hover:bg-[#E2DEC9]"
            }`}
          >
            Favicon / Badge
          </button>
        </div>
      </div>

      {/* Main Grid: Preview Canvas & Generator Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column (5 cols): Logo Preview Canvas */}
        <div className="lg:col-span-5 space-y-4">
          <div className="relative aspect-square w-full bg-[#F8F7F2] border-2 border-[#121212] flex items-center justify-center p-8 overflow-hidden shadow-sm group">
            {currentImageUrl ? (
              <div className="relative z-10 w-full h-full flex items-center justify-center">
                <img
                  src={currentImageUrl}
                  alt={`${brand.brandName} ${selectedType}`}
                  referrerPolicy="no-referrer"
                  className="max-w-full max-h-full object-contain shadow-md transition-transform duration-300 group-hover:scale-105"
                />
              </div>
            ) : (
              <div className="relative z-10 text-center p-6 space-y-4">
                <div className="w-16 h-16 mx-auto bg-[#FFFFFF] border-2 border-[#121212] flex items-center justify-center text-[#121212]">
                  <Image className="w-8 h-8 text-[#E64D3D]" />
                </div>
                <div>
                  <p className="text-sm font-serif italic text-[#121212]">
                    {selectedType === "primaryLogoUrl"
                      ? "Primary Brand Logo"
                      : selectedType === "secondaryMarkUrl"
                      ? "Secondary Visual Mark"
                      : "Favicon / App Badge"}
                  </p>
                  <p className="text-xs text-[#7E6B5A] mt-1 max-w-xs mx-auto">
                    Click generate to craft a pristine vector asset at up to 4K resolution using Gemini.
                  </p>
                </div>
              </div>
            )}

            {/* Quick Download Overlay Button */}
            {currentImageUrl && (
              <div className="absolute bottom-4 right-4 z-20">
                <button
                  onClick={() => handleDownload(selectedType, currentImageUrl)}
                  className="bg-[#121212] hover:bg-[#E64D3D] text-[#F8F7F2] p-2.5 border border-[#121212] shadow-md transition-colors flex items-center space-x-1 text-xs font-bold uppercase tracking-wider cursor-pointer"
                  title="Download Image Asset"
                >
                  <Download className="w-4 h-4" />
                  <span>PNG</span>
                </button>
              </div>
            )}
          </div>

          {/* Design Philosophy Note */}
          <div className="p-4 bg-[#F2EDE4] border border-[#D9C5B2] text-xs text-[#121212] space-y-1">
            <span className="font-bold uppercase tracking-wider text-[10px] block text-[#7E6B5A]">Design Philosophy:</span>
            <p className="font-serif italic text-sm">{brand.logoConcepts.designPhilosophy}</p>
          </div>
        </div>

        {/* Right Column (7 cols): Gemini Image Controls & Prompt Editor */}
        <div className="lg:col-span-7 space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#E2DEC9] pb-2">
              <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#121212] flex items-center space-x-1.5">
                <Sliders className="w-4 h-4 text-[#E64D3D]" />
                <span>Image Generation Configuration</span>
              </label>
              <span className="text-[10px] text-[#121212] bg-[#F2EDE4] border border-[#D9C5B2] px-2.5 py-0.5 font-bold uppercase tracking-widest">
                Engine: {model}
              </span>
            </div>

            {/* Controls Grid: Size (1K, 2K, 4K), Aspect Ratio, Model */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Image Size Selection (1K, 2K, 4K) */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#7E6B5A] mb-1 flex items-center space-x-1">
                  <Maximize2 className="w-3 h-3 text-[#121212]" />
                  <span>Resolution Size</span>
                </label>
                <div className="grid grid-cols-3 gap-1 bg-[#F8F7F2] p-1 border border-[#121212]">
                  {(["1K", "2K", "4K"] as ImageSizeOption[]).map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setImageSize(size)}
                      className={`py-1 text-xs font-bold uppercase transition-all cursor-pointer ${
                        imageSize === size
                          ? "bg-[#121212] text-[#F8F7F2]"
                          : "text-[#121212] hover:bg-[#E2DEC9]"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Aspect Ratio */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#7E6B5A] mb-1 flex items-center space-x-1">
                  <Layers className="w-3 h-3 text-[#121212]" />
                  <span>Aspect Ratio</span>
                </label>
                <select
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value as AspectRatioOption)}
                  className="w-full bg-[#F8F7F2] border border-[#121212] px-2.5 py-1.5 text-xs text-[#121212] font-bold uppercase focus:outline-none focus:border-[#E64D3D]"
                >
                  <option value="1:1">1:1 (Square)</option>
                  <option value="16:9">16:9 (Banner)</option>
                  <option value="4:3">4:3 (Card)</option>
                  <option value="3:4">3:4 (Portrait)</option>
                </select>
              </div>

              {/* Model Choice */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#7E6B5A] mb-1 flex items-center space-x-1">
                  <Sparkle className="w-3 h-3 text-[#121212]" />
                  <span>Engine Model</span>
                </label>
                <select
                  value={model}
                  onChange={(e) => setModel(e.target.value as any)}
                  className="w-full bg-[#F8F7F2] border border-[#121212] px-2.5 py-1.5 text-xs text-[#121212] font-bold focus:outline-none focus:border-[#E64D3D]"
                >
                  <option value="gemini-3.1-flash-image">gemini-3.1-flash-image (High Quality)</option>
                  <option value="gemini-3.1-flash-lite-image">gemini-3.1-flash-lite-image (Fast)</option>
                  <option value="gemini-3-pro-image-preview">gemini-3-pro-image-preview (Pro)</option>
                </select>
              </div>
            </div>

            {/* Prompt Editor */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-[#121212]">
                  Concept Generation Prompt
                </label>
                <button
                  type="button"
                  onClick={() => setCustomPrompt(brand.logoConcepts.primaryLogoPrompt)}
                  className="text-[10px] text-[#E64D3D] hover:underline uppercase tracking-wider font-bold"
                >
                  Reset to Original Prompt
                </button>
              </div>
              <textarea
                rows={3}
                value={customPrompt || getActivePrompt()}
                onChange={(e) => setCustomPrompt(e.target.value)}
                className="w-full bg-[#F8F7F2] border border-[#121212] p-3 text-xs text-[#121212] focus:outline-none focus:border-[#E64D3D] resize-none font-mono"
              />
            </div>

            {genNotice && (
              <div className="p-3 bg-[#FEF3C7] border border-[#D97706] text-[#92400E] text-xs font-semibold">
                {genNotice}
              </div>
            )}

            {genError && (
              <div className="p-3 bg-[#FEE2E2] border border-[#E64D3D] text-[#991B1B] text-xs font-bold">
                {genError}
              </div>
            )}

            {/* Generate Action Button */}
            <button
              type="button"
              onClick={handleGenerateLogo}
              disabled={isGenerating}
              className="w-full bg-[#121212] hover:bg-[#E64D3D] text-[#F8F7F2] font-bold py-3.5 px-5 border-2 border-[#121212] transition-colors disabled:opacity-50 flex items-center justify-center space-x-2 cursor-pointer uppercase tracking-widest text-xs"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-[#F8F7F2]" />
                  <span>
                    Rendering {selectedType.replace("Url", "")} ({imageSize})...
                  </span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-[#E64D3D]" />
                  <span>
                    {currentImageUrl ? "Regenerate" : "Generate"} {selectedType.replace("Url", "")} Asset ({imageSize})
                  </span>
                </>
              )}
            </button>
          </div>

          {/* Asset Prompts Reference Table */}
          <div className="pt-4 border-t border-[#E2DEC9] space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#7E6B5A] block">
              Auto-Designed Asset Prompts
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div
                onClick={() => {
                  setSelectedType("primaryLogoUrl");
                  setCustomPrompt("");
                }}
                className={`p-3 border text-left cursor-pointer transition-all ${
                  selectedType === "primaryLogoUrl"
                    ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
                    : "bg-[#F8F7F2] text-[#121212] border-[#D9C5B2] hover:border-[#121212]"
                }`}
              >
                <div className="text-[11px] font-bold uppercase tracking-wider">Primary Mark</div>
                <div className="text-[10px] opacity-80 line-clamp-2 mt-0.5">
                  {brand.logoConcepts.primaryLogoPrompt}
                </div>
              </div>

              <div
                onClick={() => {
                  setSelectedType("secondaryMarkUrl");
                  setCustomPrompt("");
                }}
                className={`p-3 border text-left cursor-pointer transition-all ${
                  selectedType === "secondaryMarkUrl"
                    ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
                    : "bg-[#F8F7F2] text-[#121212] border-[#D9C5B2] hover:border-[#121212]"
                }`}
              >
                <div className="text-[11px] font-bold uppercase tracking-wider">Secondary Mark</div>
                <div className="text-[10px] opacity-80 line-clamp-2 mt-0.5">
                  {brand.logoConcepts.secondaryMarkPrompt}
                </div>
              </div>

              <div
                onClick={() => {
                  setSelectedType("faviconUrl");
                  setCustomPrompt("");
                }}
                className={`p-3 border text-left cursor-pointer transition-all ${
                  selectedType === "faviconUrl"
                    ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
                    : "bg-[#F8F7F2] text-[#121212] border-[#D9C5B2] hover:border-[#121212]"
                }`}
              >
                <div className="text-[11px] font-bold uppercase tracking-wider">Favicon Badge</div>
                <div className="text-[10px] opacity-80 line-clamp-2 mt-0.5">
                  {brand.logoConcepts.faviconPrompt}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
