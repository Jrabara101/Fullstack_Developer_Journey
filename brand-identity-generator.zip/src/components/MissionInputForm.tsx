import React, { useState } from "react";
import { Sparkles, Wand2, ArrowRight, Building2, Palette, Users, Tag, AlertCircle } from "lucide-react";
import { BRAND_PRESETS } from "../data/presets";

interface MissionInputFormProps {
  onGenerate: (formData: {
    mission: string;
    brandName: string;
    industry: string;
    vibe: string;
    targetAudience: string;
    colorPreference: string;
  }) => void;
  onSelectPreset: (presetId: string) => void;
  isLoading: boolean;
  error: string | null;
}

const TONE_TAGS = [
  "Sleek & Cyberpunk",
  "Luxury & Serene",
  "Warm & Organic",
  "Modern & Minimalist",
  "Bold & Disruptive",
  "Trustworthy & Corporate",
  "Playful & Energetic",
  "Artisanal & Vintage",
];

const COLOR_PREFERENCES = [
  "Electric Cyan & Deep Obsidian",
  "Sage Green & Terra Cotta",
  "Navy Blue & Champagne Gold",
  "Monochrome & High Contrast",
  "Warm Sunset Pastel",
  "Emerald & Brass",
  "Neon Violet & Deep Blue",
];

export const MissionInputForm: React.FC<MissionInputFormProps> = ({
  onGenerate,
  onSelectPreset,
  isLoading,
  error,
}) => {
  const [mission, setMission] = useState("");
  const [brandName, setBrandName] = useState("");
  const [industry, setIndustry] = useState("");
  const [vibe, setVibe] = useState("");
  const [targetAudience, setTargetAudience] = useState("");
  const [colorPreference, setColorPreference] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mission.trim()) return;
    onGenerate({
      mission,
      brandName,
      industry,
      vibe,
      targetAudience,
      colorPreference,
    });
  };

  const handleQuickTagClick = (tag: string) => {
    if (vibe.includes(tag)) {
      setVibe(vibe.replace(tag, "").replace(/,\s*,/g, ",").trim());
    } else {
      setVibe(vibe ? `${vibe}, ${tag}` : tag);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12">
      {/* Hero Welcome Banner */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#F2EDE4] border border-[#D9C5B2] text-[#121212] text-xs font-bold uppercase tracking-widest mb-4">
          <Sparkles className="w-3.5 h-3.5 text-[#E64D3D]" />
          <span>Gemini AI & Imagen 4K Brand Engine</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-serif italic font-light tracking-tighter text-[#121212] mb-4">
          Generate Your Complete <span className="underline decoration-[#E64D3D] decoration-2 underline-offset-8">Brand Bible</span>
        </h1>
        <p className="text-[#333333] text-sm sm:text-base max-w-2xl mx-auto leading-relaxed font-sans">
          Describe your company mission and vision. Our AI Creative Director generates vector logo concepts, 5-color hex palettes, Google font pairings, voice guidelines, and interactive mockups in seconds.
        </p>
      </div>

      {/* Preset Quick-Start Bar */}
      <div className="mb-8 p-5 bg-[#FFFFFF] border-2 border-[#121212] text-[#121212] shadow-sm">
        <div className="flex items-center justify-between mb-3 border-b border-[#E2DEC9] pb-2">
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold border-l-4 border-[#121212] pl-2 flex items-center space-x-1.5">
            <Wand2 className="w-3.5 h-3.5 text-[#E64D3D]" />
            <span>Instant Demo Presets</span>
          </span>
          <span className="text-[10px] uppercase tracking-widest opacity-60">1-click identity system load</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {BRAND_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => onSelectPreset(p.id)}
              disabled={isLoading}
              className="text-left p-3.5 bg-[#F8F7F2] hover:bg-[#121212] hover:text-[#F8F7F2] border border-[#121212] transition-all group cursor-pointer disabled:opacity-50"
            >
              <div className="font-serif italic text-sm font-semibold group-hover:text-[#F8F7F2] transition-colors">
                {p.title}
              </div>
              <div className="text-[10px] uppercase tracking-wider opacity-60 truncate mt-0.5">{p.industry}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Input Form */}
      <form onSubmit={handleSubmit} className="bg-[#FFFFFF] border-2 border-[#121212] p-6 sm:p-8 shadow-md relative">
        {error && (
          <div className="mb-6 p-4 bg-[#FEE2E2] border-2 border-[#E64D3D] text-[#991B1B] text-xs sm:text-sm flex items-start space-x-2.5">
            <AlertCircle className="w-5 h-5 text-[#E64D3D] flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold uppercase tracking-wider text-xs">Generation Error</p>
              <p className="mt-0.5">{error}</p>
            </div>
          </div>
        )}

        <div className="space-y-6">
          {/* Mission Statement Input (Required) */}
          <div>
            <h2 className="text-[10px] uppercase tracking-[0.2em] mb-2 font-bold border-l-4 border-[#121212] pl-2">
              The Core Mission & Concept <span className="text-[#E64D3D]">*</span>
            </h2>
            <textarea
              id="mission"
              rows={4}
              value={mission}
              onChange={(e) => setMission(e.target.value)}
              placeholder="e.g. To provide a ritualistic coffee experience that honors both the soil of the farm and the soul of the city, creating a bridge through sustainable excellence..."
              required
              className="w-full bg-[#F8F7F2] border border-[#121212] p-3.5 text-[#121212] text-sm placeholder:text-[#7E6B5A]/60 focus:outline-none focus:border-[#E64D3D] transition-all resize-none font-sans"
            />
          </div>

          {/* Optional Inputs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Brand Name */}
            <div>
              <label htmlFor="brandName" className="block text-[10px] uppercase tracking-[0.15em] font-bold text-[#121212] mb-1.5 flex items-center space-x-1.5">
                <Tag className="w-3.5 h-3.5 text-[#E64D3D]" />
                <span>Brand Name (Optional)</span>
              </label>
              <input
                type="text"
                id="brandName"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="e.g. Ethos Coffee (or leave blank)"
                className="w-full bg-[#F8F7F2] border border-[#121212] px-3.5 py-2.5 text-[#121212] text-sm placeholder:text-[#7E6B5A]/60 focus:outline-none focus:border-[#E64D3D] transition-all"
              />
            </div>

            {/* Industry */}
            <div>
              <label htmlFor="industry" className="block text-[10px] uppercase tracking-[0.15em] font-bold text-[#121212] mb-1.5 flex items-center space-x-1.5">
                <Building2 className="w-3.5 h-3.5 text-[#7E6B5A]" />
                <span>Industry / Sector</span>
              </label>
              <input
                type="text"
                id="industry"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                placeholder="e.g. Artisanal Coffee, Luxury Hospitality"
                className="w-full bg-[#F8F7F2] border border-[#121212] px-3.5 py-2.5 text-[#121212] text-sm placeholder:text-[#7E6B5A]/60 focus:outline-none focus:border-[#E64D3D] transition-all"
              />
            </div>
          </div>

          {/* Vibe & Personality Chips */}
          <div>
            <label className="block text-[10px] uppercase tracking-[0.15em] font-bold text-[#121212] mb-2 flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#E64D3D]" />
              <span>Identity Tone & Aesthetic Attributes</span>
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {TONE_TAGS.map((tag) => {
                const isSelected = vibe.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleQuickTagClick(tag)}
                    className={`px-3 py-1 text-xs font-bold uppercase tracking-wider transition-all border ${
                      isSelected
                        ? "bg-[#121212] text-[#F8F7F2] border-[#121212]"
                        : "bg-[#F8F7F2] text-[#121212] border-[#D9C5B2] hover:border-[#121212]"
                    }`}
                  >
                    {isSelected ? "✓ " : "+ "}
                    {tag}
                  </button>
                );
              })}
            </div>
            <input
              type="text"
              value={vibe}
              onChange={(e) => setVibe(e.target.value)}
              placeholder="Or type custom attributes (e.g. Organic, Heritage, Sophisticated)"
              className="w-full bg-[#F8F7F2] border border-[#121212] px-3.5 py-2 text-[#121212] text-xs placeholder:text-[#7E6B5A]/60 focus:outline-none focus:border-[#E64D3D] transition-all"
            />
          </div>

          {/* Color & Target Audience Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Color Preference */}
            <div>
              <label htmlFor="colorPreference" className="block text-[10px] uppercase tracking-[0.15em] font-bold text-[#121212] mb-1.5 flex items-center space-x-1.5">
                <Palette className="w-3.5 h-3.5 text-[#2D3A30]" />
                <span>Chromatic Palette Concept</span>
              </label>
              <select
                id="colorPreference"
                value={colorPreference}
                onChange={(e) => setColorPreference(e.target.value)}
                className="w-full bg-[#F8F7F2] border border-[#121212] px-3.5 py-2.5 text-[#121212] text-xs font-bold uppercase focus:outline-none focus:border-[#E64D3D] transition-all"
              >
                <option value="">✦ AI Chromatic Auto-Harmonize</option>
                {COLOR_PREFERENCES.map((pref) => (
                  <option key={pref} value={pref}>
                    {pref}
                  </option>
                ))}
              </select>
            </div>

            {/* Target Audience */}
            <div>
              <label htmlFor="targetAudience" className="block text-[10px] uppercase tracking-[0.15em] font-bold text-[#121212] mb-1.5 flex items-center space-x-1.5">
                <Users className="w-3.5 h-3.5 text-[#7E6B5A]" />
                <span>Primary Target Audience</span>
              </label>
              <input
                type="text"
                id="targetAudience"
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                placeholder="e.g. Urban Connoisseurs, Eco-conscious Professionals"
                className="w-full bg-[#F8F7F2] border border-[#121212] px-3.5 py-2.5 text-[#121212] text-sm placeholder:text-[#7E6B5A]/60 focus:outline-none focus:border-[#E64D3D] transition-all"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading || !mission.trim()}
              className="w-full bg-[#121212] hover:bg-[#E64D3D] text-[#F8F7F2] font-bold py-4 px-6 border-2 border-[#121212] transition-all duration-200 disabled:opacity-50 cursor-pointer flex items-center justify-center space-x-2 uppercase tracking-widest text-xs sm:text-sm"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-5 h-5 animate-spin text-[#F8F7F2]" />
                  <span>Generating Identity System...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 text-[#E64D3D] group-hover:text-white" />
                  <span>Generate Complete Brand Bible</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
