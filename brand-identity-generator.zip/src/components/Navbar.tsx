import React from "react";
import { Sparkles, Download, MessageSquareText, Layers, RefreshCw, FileText } from "lucide-react";
import { BRAND_PRESETS } from "../data/presets";
import { BrandBible } from "../types/brand";

interface NavbarProps {
  currentBrand: BrandBible | null;
  onSelectPreset: (presetId: string) => void;
  onReset: () => void;
  onOpenTokensModal: () => void;
  onToggleChat: () => void;
  isChatOpen: boolean;
  isGenerating: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentBrand,
  onSelectPreset,
  onReset,
  onOpenTokensModal,
  onToggleChat,
  isChatOpen,
  isGenerating,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#121212] border-b-2 border-[#2A2A2A] text-[#F8F7F2] shadow-md print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: Branding */}
        <div className="flex items-center space-x-3.5 cursor-pointer group" onClick={onReset}>
          <div className="w-9 h-9 border-2 border-[#F8F7F2] bg-[#121212] flex items-center justify-center transition-transform group-hover:rotate-45 duration-200">
            <div className="w-4 h-4 bg-[#E64D3D]" />
          </div>
          <div>
            <h1 className="font-serif italic text-xl sm:text-2xl font-light tracking-tighter text-[#F8F7F2]">
              The Brand Bible
            </h1>
            <p className="text-[9px] uppercase tracking-[0.2em] text-[#D9C5B2] hidden sm:block">
              Identity System & Design Engine
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Preset Selector Dropdown */}
          <div className="relative">
            <select
              onChange={(e) => {
                if (e.target.value) {
                  onSelectPreset(e.target.value);
                  e.target.value = "";
                }
              }}
              defaultValue=""
              className="bg-[#222222] hover:bg-[#2A2A2A] border border-[#333333] text-xs text-[#F8F7F2] rounded-none px-3 py-1.5 focus:outline-none focus:border-[#E64D3D] transition-colors cursor-pointer font-sans"
            >
              <option value="" disabled>
                ✦ Load Example Presets...
              </option>
              {BRAND_PRESETS.map((preset) => (
                <option key={preset.id} value={preset.id}>
                  {preset.title} ({preset.industry})
                </option>
              ))}
            </select>
          </div>

          {currentBrand && (
            <>
              {/* Export Tokens Modal Trigger */}
              <button
                onClick={onOpenTokensModal}
                className="hidden sm:inline-flex items-center space-x-1.5 bg-[#222222] hover:bg-[#333333] text-[#F8F7F2] border border-[#333333] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors"
                title="Export Design Tokens (CSS, JSON, SVG)"
              >
                <Layers className="w-3.5 h-3.5 text-[#D9C5B2]" />
                <span>Tokens</span>
              </button>

              {/* Print Brand Bible PDF */}
              <button
                onClick={() => window.print()}
                className="inline-flex items-center space-x-1.5 bg-[#222222] hover:bg-[#333333] text-[#F8F7F2] border border-[#333333] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors"
                title="Print or Save Brand Bible PDF"
              >
                <FileText className="w-3.5 h-3.5 text-[#D9C5B2]" />
                <span className="hidden md:inline">Print Bible</span>
              </button>

              {/* Start New */}
              <button
                onClick={onReset}
                disabled={isGenerating}
                className="inline-flex items-center space-x-1.5 bg-[#222222] hover:bg-[#333333] text-[#D9C5B2] border border-[#333333] px-2.5 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors disabled:opacity-50"
                title="Create New Brand Identity"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">New</span>
              </button>
            </>
          )}

          {/* AI Chat Drawer Toggle */}
          <button
            onClick={onToggleChat}
            className={`relative inline-flex items-center space-x-2 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider transition-all border ${
              isChatOpen
                ? "bg-[#E64D3D] text-[#FFFFFF] border-[#E64D3D]"
                : "bg-[#F8F7F2] text-[#121212] border-[#F8F7F2] hover:bg-[#E64D3D] hover:text-[#FFFFFF] hover:border-[#E64D3D]"
            }`}
          >
            <MessageSquareText className="w-4 h-4" />
            <span className="hidden xs:inline">AI Strategist</span>
            {!isChatOpen && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#E64D3D] rounded-full animate-ping" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
