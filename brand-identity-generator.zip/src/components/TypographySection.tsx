import React, { useEffect, useState } from "react";
import { Type, ExternalLink, Copy, Check, SlidersHorizontal, Sparkles } from "lucide-react";
import { TypographySystem } from "../types/brand";

interface TypographySectionProps {
  typography: TypographySystem;
}

export const TypographySection: React.FC<TypographySectionProps> = ({ typography }) => {
  const [headlineText, setHeadlineText] = useState(typography.sampleHeadline);
  const [bodyText, setBodyText] = useState(typography.sampleBody);
  const [headerFontSize, setHeaderFontSize] = useState(32);
  const [copiedFontCss, setCopiedFontCss] = useState<string | null>(null);

  // Load Google Fonts dynamically when component mounts or font URLs change
  useEffect(() => {
    if (typography.headerFont.googleFontUrl) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = typography.headerFont.googleFontUrl;
      document.head.appendChild(link);
    }
    if (typography.bodyFont.googleFontUrl) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = typography.bodyFont.googleFontUrl;
      document.head.appendChild(link);
    }
  }, [typography.headerFont.googleFontUrl, typography.bodyFont.googleFontUrl]);

  const handleCopyCss = (fontFamily: string, key: string) => {
    const snippet = `font-family: '${fontFamily}', sans-serif;`;
    navigator.clipboard.writeText(snippet);
    setCopiedFontCss(key);
    setTimeout(() => setCopiedFontCss(null), 2000);
  };

  return (
    <div className="bg-[#FFFFFF] border-2 border-[#121212] p-6 sm:p-8 space-y-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2DEC9] pb-5">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] font-bold border-l-4 border-[#121212] pl-2 mb-1 flex items-center space-x-1.5">
            <Type className="w-3.5 h-3.5 text-[#E64D3D]" />
            <span>Typography System & Pairing</span>
          </h3>
          <h2 className="text-2xl font-serif italic text-[#121212]">Google Font Pairings</h2>
          <p className="text-[#7E6B5A] text-xs sm:text-sm mt-0.5">
            Curated Google Font pairings for headers and body copy. Type custom text below to test live rendered typography.
          </p>
        </div>

        {/* Font Size Adjuster Control */}
        <div className="flex items-center space-x-3 bg-[#F8F7F2] p-2 border border-[#121212] text-xs self-start sm:self-auto">
          <SlidersHorizontal className="w-4 h-4 text-[#121212]" />
          <span className="text-[#121212] font-bold uppercase tracking-wider text-[10px]">Scale: {headerFontSize}px</span>
          <input
            type="range"
            min={20}
            max={48}
            value={headerFontSize}
            onChange={(e) => setHeaderFontSize(Number(e.target.value))}
            className="w-24 accent-[#121212] cursor-pointer"
          />
        </div>
      </div>

      {/* Font Pairings Comparison Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Header Font Card */}
        <div className="bg-[#F8F7F2] border border-[#121212] p-6 space-y-4 shadow-sm flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 bg-[#121212] text-[#F8F7F2]">
                  Header Font
                </span>
                <h3 className="text-2xl font-serif italic font-semibold text-[#121212] mt-1">{typography.headerFont.family}</h3>
                <p className="text-xs uppercase tracking-wider text-[#7E6B5A]">{typography.headerFont.category}</p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleCopyCss(typography.headerFont.family, "header")}
                  className="p-2 bg-[#FFFFFF] hover:bg-[#121212] hover:text-[#F8F7F2] border border-[#121212] text-[#121212] text-xs transition-colors cursor-pointer"
                  title="Copy CSS font-family"
                >
                  {copiedFontCss === "header" ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <a
                  href={typography.headerFont.googleFontUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 bg-[#FFFFFF] hover:bg-[#E64D3D] hover:text-[#FFFFFF] border border-[#121212] text-[#121212] text-xs transition-colors"
                  title="Open on Google Fonts"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            <p className="text-xs text-[#333333] font-serif italic leading-relaxed border-l-2 border-[#E64D3D] pl-3">
              "{typography.headerFont.rationale}"
            </p>

            {/* Live Editable Headline Preview */}
            <div className="pt-3 border-t border-[#E2DEC9]">
              <label className="text-[9px] font-bold uppercase tracking-widest text-[#7E6B5A] mb-1 block">Live Header Preview</label>
              <textarea
                rows={2}
                value={headlineText}
                onChange={(e) => setHeadlineText(e.target.value)}
                style={{
                  fontFamily: `'${typography.headerFont.family}', serif`,
                  fontSize: `${headerFontSize}px`,
                }}
                className="w-full bg-transparent text-[#121212] focus:outline-none resize-none leading-tight border-b border-dashed border-[#121212] pb-1"
              />
            </div>
          </div>

          <div className="text-[10px] font-mono text-[#7E6B5A] pt-2 border-t border-[#E2DEC9]">
            font-family: '{typography.headerFont.family}', serif;
          </div>
        </div>

        {/* Body Font Card */}
        <div className="bg-[#F8F7F2] border border-[#121212] p-6 space-y-4 shadow-sm flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 bg-[#2D3A30] text-[#F8F7F2]">
                  Body Copy Font
                </span>
                <h3 className="text-2xl font-serif italic font-semibold text-[#121212] mt-1">{typography.bodyFont.family}</h3>
                <p className="text-xs uppercase tracking-wider text-[#7E6B5A]">{typography.bodyFont.category}</p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleCopyCss(typography.bodyFont.family, "body")}
                  className="p-2 bg-[#FFFFFF] hover:bg-[#121212] hover:text-[#F8F7F2] border border-[#121212] text-[#121212] text-xs transition-colors cursor-pointer"
                  title="Copy CSS font-family"
                >
                  {copiedFontCss === "body" ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <a
                  href={typography.bodyFont.googleFontUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 bg-[#FFFFFF] hover:bg-[#E64D3D] hover:text-[#FFFFFF] border border-[#121212] text-[#121212] text-xs transition-colors"
                  title="Open on Google Fonts"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            <p className="text-xs text-[#333333] font-serif italic leading-relaxed border-l-2 border-[#2D3A30] pl-3">
              "{typography.bodyFont.rationale}"
            </p>

            {/* Live Editable Body Preview */}
            <div className="pt-3 border-t border-[#E2DEC9]">
              <label className="text-[9px] font-bold uppercase tracking-widest text-[#7E6B5A] mb-1 block">Live Body Copy Preview</label>
              <textarea
                rows={3}
                value={bodyText}
                onChange={(e) => setBodyText(e.target.value)}
                style={{
                  fontFamily: `'${typography.bodyFont.family}', sans-serif`,
                }}
                className="w-full bg-transparent text-[#121212] text-sm focus:outline-none resize-none leading-relaxed border-b border-dashed border-[#121212] pb-1 font-sans"
              />
            </div>
          </div>

          <div className="text-[10px] font-mono text-[#7E6B5A] pt-2 border-t border-[#E2DEC9]">
            font-family: '{typography.bodyFont.family}', sans-serif;
          </div>
        </div>
      </div>
    </div>
  );
};
