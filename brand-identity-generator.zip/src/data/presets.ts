import { BrandPreset } from "../types/brand";

export const BRAND_PRESETS: BrandPreset[] = [
  {
    id: "apex-quantum",
    title: "Apex Quantum",
    tagline: "Autonomous Intelligence for Enterprise Operations",
    industry: "Artificial Intelligence & Cloud",
    vibe: "Sleek, Cutting-Edge, High Precision, Electric",
    mission: "To empower global enterprises with hyper-efficient autonomous workflows and sub-millisecond AI intelligence.",
    brand: {
      id: "preset-apex",
      createdAt: new Date().toISOString(),
      brandName: "Apex Quantum",
      tagline: "Autonomous Intelligence for Enterprise Operations",
      elevatorPitch: "Apex Quantum delivers continuous real-time intelligence infrastructure, transforming complex unstructured enterprise telemetry into high-conviction automated action.",
      missionStatement: "To pioneer sub-millisecond autonomous workflow intelligence that scales human capital and eliminates operational friction.",
      visionStatement: "A world where zero-latency AI orchestration powers every resilient, future-ready enterprise.",
      coreValues: [
        { title: "Deterministic Precision", description: "Every algorithm and response is engineered for zero-defect reliability." },
        { title: "Velocity Without Compromise", description: "Accelerating execution while maintaining rigorous security standards." },
        { title: "Transparent Autonomy", description: "Building inspectable AI systems that earn absolute operator trust." },
        { title: "Forward Innovation", description: "Relentlessly pushing the boundaries of compute efficiency." }
      ],
      voiceAndTone: {
        adjectives: ["Authoritative", "Crisp", "Visionary", "Engineered"],
        dos: [
          "Use direct, active verb statements",
          "Highlight quantifiable performance metrics",
          "Maintain a sophisticated, tech-forward tone",
          "Emphasize precision and architectural elegance"
        ],
        donts: [
          "Avoid trendy consumer buzzwords or fluff",
          "Never exaggerate system capabilities",
          "Don't use overly casual or colloquial phrasing",
          "Avoid cluttered visual layouts or vague promises"
        ],
        samplePhrases: [
          "Sub-millisecond decisions at global scale.",
          "Engineered for zero-downtime intelligence.",
          "Transform telemetry into deterministic action."
        ]
      },
      colorPalette: [
        { name: "Obsidian Void", hex: "#0B0F19", role: "Background", usage: "Primary dark canvas, deep hero backgrounds, and dark UI surfaces." },
        { name: "Quantum Cyan", hex: "#00F2FE", role: "Primary", usage: "Main brand accent, active state indicators, primary call-to-action buttons." },
        { name: "Electric Indigo", hex: "#4FACFE", role: "Secondary", usage: "Data visualizers, gradient stops, secondary feature badges." },
        { name: "Cobalt Depth", hex: "#1E293B", role: "Surface", usage: "Card backgrounds, elevated container borders, code block fields." },
        { name: "Laser Violet", hex: "#7C3AED", role: "Accent", usage: "AI badge tags, hover state glows, high-priority highlights." }
      ],
      typography: {
        headerFont: {
          family: "Space Grotesk",
          category: "Sans-Serif / Tech Display",
          googleFontUrl: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&display=swap",
          rationale: "Geometrically structured displaying clean tech precision with distinctive modernist terminals."
        },
        bodyFont: {
          family: "Plus Jakarta Sans",
          category: "Sans-Serif / Clean Humanist",
          googleFontUrl: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600&display=swap",
          rationale: "Exceptional screen legibility across dense data tables, dashboards, and long-form whitepapers."
        },
        sampleHeadline: "Next-Generation Autonomous Compute Engine",
        sampleBody: "Apex Quantum orchestrates multi-agent model pipelines with sub-millisecond execution. Built on deterministic neural routes, your infrastructure scales dynamically without human intervention."
      },
      logoConcepts: {
        primaryLogoPrompt: "Minimalist geometric logo icon for a quantum AI tech company, intersecting abstract glowing cyan laser prism monogram 'A', dark background, sharp clean vector design",
        secondaryMarkPrompt: "Abstract geometric icon of a glowing cyan particle lattice, minimalist tech symbol, clean crisp vector logo mark on white background",
        faviconPrompt: "Minimalist 'A' monogram tech emblem inside a sleek rounded hexagon tile, electric cyan outline on deep obsidian back",
        designPhilosophy: "Constructed on a golden-ratio geometric grid, combining sharp 45-degree angles with luminous gradient strokes that signify rapid throughput and continuous flow."
      },
      targetAudience: {
        personaName: "Devon Vance",
        demographics: "Chief Technology Officer / VP of Infrastructure, 34-52 years old, Enterprise Tech",
        painPoints: [
          "High latency in real-time decision loops",
          "Scaling AI inference costs outstripping ROI",
          "Fragmented data pipelines requiring manual oversight"
        ],
        keyMotivation: "Deploying bulletproof, low-latency AI infrastructure that drives measurable enterprise efficiency."
      }
    }
  },
  {
    id: "lumina-botanicals",
    title: "Lumina Organics",
    tagline: "Biocompatible Cellular Skincare Born From Nature",
    industry: "Luxury Beauty & Wellness",
    vibe: "Earthy, Sophisticated, Serene, Radiantly Clean",
    mission: "To restore skin vitality using wild-harvested botanicals and bio-fermented clinical active ingredients.",
    brand: {
      id: "preset-lumina",
      createdAt: new Date().toISOString(),
      brandName: "Lumina Organics",
      tagline: "Biocompatible Cellular Skincare Born From Nature",
      elevatorPitch: "Lumina Organics pairs cold-pressed botanical essences with bio-fermented hyaluronic peptides to deliver clinical skin renewal with zero synthetic additives.",
      missionStatement: "To elevate holistic self-care through transparent, ethically harvested skincare formulations that nourish both skin and planet.",
      visionStatement: "Setting the new luxury standard for conscious, high-efficacy skincare created in harmony with natural ecosystems.",
      coreValues: [
        { title: "Pure Biocompatibility", description: "Formulating solely with clean, skin-identical ingredients that absorb seamlessly." },
        { title: "Regenerative Sourcing", description: "Partnering exclusively with organic micro-farms practicing zero-waste cultivation." },
        { title: "Clinical Transparency", description: "Publishing full ingredient origin disclosures and third-party lab potency audits." },
        { title: "Mindful Ritual", description: "Designing tactile, calming daily skincare experiences that ground the senses." }
      ],
      voiceAndTone: {
        adjectives: ["Serene", "Nourishing", "Transparent", "Elegantly Grounded"],
        dos: [
          "Speak with gentle clarity and calm assurance",
          "Highlight botanical origins and biocompatible science",
          "Use poetic yet accurate descriptive sensory cues",
          "Focus on long-term skin health over quick fixes"
        ],
        donts: [
          "Avoid aggressive anti-aging fear marketing",
          "Never use synthetic chemical jargon to intimidate",
          "Don't clutter visual collateral with heavy dark tones",
          "Avoid loud discount callouts or artificial urgency"
        ],
        samplePhrases: [
          "Cellular harmony, harvested in silence.",
          "Nourish your skin barrier with wild-crafted botanical vitality.",
          "Pure bio-fermented actives for lasting luminosity."
        ]
      },
      colorPalette: [
        { name: "Eucalyptus Dew", hex: "#E8EFE9", role: "Background", usage: "Soft cream canvas, product unboxing tissue, background surfaces." },
        { name: "Sage Moss", hex: "#4A6B5B", role: "Primary", usage: "Primary brand mark, product typography, main navigation accents." },
        { name: "Terra Cotta Rose", hex: "#D48B7B", role: "Accent", usage: "Warm highlight badges, serum label accents, call-to-action buttons." },
        { name: "Sandstone Silk", hex: "#F5F0EB", role: "Surface", usage: "Secondary container backgrounds, subtle divider borders." },
        { name: "Deep Botanical Emerald", hex: "#1C3127", role: "Secondary", usage: "Editorial body text, luxury bottle caps, high-contrast footers." }
      ],
      typography: {
        headerFont: {
          family: "Playfair Display",
          category: "Serif / Editorial Elegance",
          googleFontUrl: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700;1,400&display=swap",
          rationale: "Timeless serif curves that exude high-end organic luxury and apothecary refinement."
        },
        bodyFont: {
          family: "Montserrat",
          category: "Sans-Serif / Modernist Geometric",
          googleFontUrl: "https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500&display=swap",
          rationale: "Clean open tracking providing effortless legibility on cosmetic packaging and ingredient labels."
        },
        sampleHeadline: "Pure Cellular Renewal from Forest to Skin",
        sampleBody: "Infused with cold-pressed Alpine Rose stem cells and organic squalane, our Replenishing Facial Serum penetrates deeply to calm redness and lock in 72-hour moisture."
      },
      logoConcepts: {
        primaryLogoPrompt: "Minimalist luxury emblem for an organic botanical skincare brand, elegant botanical leaf drawing combined with sun rays icon, fine line art aesthetic, sage green color, white background",
        secondaryMarkPrompt: "Fine line art floral monoline mark, minimalist botanical botanical drop icon, sage green and rose terra cotta aesthetic, clean vector mark",
        faviconPrompt: "Sleek monoline leaf emblem in sage green on eucalyptus dew soft background tile",
        designPhilosophy: "Rooted in organic symmetry and delicate monoline illustration, echoing natural botanical architecture and gentle light rays."
      },
      targetAudience: {
        personaName: "Elena Vance",
        demographics: "Wellness Enthusiast & Creative Director, 28-48 years old, Urban / Suburban",
        painPoints: [
          "Sensitive skin prone to irritation from harsh synthetic additives",
          "Frustration with misleading 'clean beauty' greenwashing claims",
          "Desire for luxurious packaging that aligns with sustainable values"
        ],
        keyMotivation: "Invested in clinically proven botanical rituals that support a healthy skin barrier sustainably."
      }
    }
  },
  {
    id: "finova-wealth",
    title: "Finova Wealth",
    tagline: "Intelligent Wealth Management for Modern Founders",
    industry: "Fintech & Private Banking",
    vibe: "Trustworthy, Modern, Prestigious, Strategic",
    mission: "Democratizing institutional-grade portfolio intelligence and global tax optimization for high-growth creators.",
    brand: {
      id: "preset-finova",
      createdAt: new Date().toISOString(),
      brandName: "Finova Wealth",
      tagline: "Intelligent Wealth Management for Modern Founders",
      elevatorPitch: "Finova Wealth combines private banking advisory with automated multi-asset yield optimization, giving founders total control over their liquidity and heritage capital.",
      missionStatement: "To empower visionary entrepreneurs with transparent, high-yield wealth management built for the digital economy.",
      visionStatement: "Building the global standard for frictionless, transparent private wealth architecture.",
      coreValues: [
        { title: "Uncompromising Fiduciary Duty", description: "Putting founder wealth growth and capital protection above all else." },
        { title: "Algorithmic Efficiency", description: "Automating portfolio rebalancing to capture global yield in real time." },
        { title: "Institutional Defense", description: "Deploying multi-layer security and banking-grade cold custody protection." },
        { title: "Clarity in Complexity", description: "Distilling intricate tax and equity strategies into simple visual dashboards." }
      ],
      voiceAndTone: {
        adjectives: ["Confident", "Insightful", "Balanced", "Unshakeable"],
        dos: [
          "Maintain a crisp, professional, institutional voice",
          "Focus on long-term wealth preservation and growth",
          "Use precise financial terminology with clear explanations",
          "Highlight data security and fiduciary stewardship"
        ],
        donts: [
          "Never sound like speculative crypto gambling or hype",
          "Avoid chaotic or flashy visual aesthetics",
          "Don't promise guaranteed returns or risky shortcuts",
          "Avoid dense legal jargon without plain-English context"
        ],
        samplePhrases: [
          "Institutional precision for private portfolios.",
          "Automated yield optimization, tailored for founders.",
          "Protecting liquid capital across global markets."
        ]
      },
      colorPalette: [
        { name: "Navy Heritage", hex: "#0F172A", role: "Primary", usage: "Main brand typography, header bar, authoritative cards." },
        { name: "Champagne Gold", hex: "#D97706", role: "Accent", usage: "Premium status badges, key metrics, primary CTA accents." },
        { name: "Frost White", hex: "#F8FAFC", role: "Background", usage: "Clean financial portal background, print document paper." },
        { name: "Slate Balance", hex: "#64748B", role: "Secondary", usage: "Chart grid lines, secondary metric labels, border outlines." },
        { name: "Pure Marble", hex: "#FFFFFF", role: "Surface", usage: "Dashboard card panels, interactive input fields." }
      ],
      typography: {
        headerFont: {
          family: "Cabinet Grotesk",
          category: "Display / Premium Grotesque",
          googleFontUrl: "https://fonts.googleapis.com/css2?family=Cabinet+Grotesk:wght@700;800&display=swap",
          rationale: "Strong, confident letterforms with distinct structural weight representing stability and capital growth."
        },
        bodyFont: {
          family: "Inter",
          category: "Sans-Serif / Precision Screen",
          googleFontUrl: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap",
          rationale: "The gold standard for financial dashboards, numerical clarity, and high data density readability."
        },
        sampleHeadline: "Institutional Multi-Asset Yield for Founders",
        sampleBody: "Finova's proprietary smart vault automatically routes excess liquid treasury across top-tier treasury bills and insured money market funds, maximizing yield while preserving same-day liquidity."
      },
      logoConcepts: {
        primaryLogoPrompt: "Minimalist prestige logo mark for a fintech wealth management platform, geometric stylized infinity diamond mark symbol, navy blue and metallic gold color palette, white background",
        secondaryMarkPrompt: "Abstract geometric diamond shield icon, clean financial mark vector, navy and gold accent minimalist design",
        faviconPrompt: "Sleek geometric 'F' monogram in champagne gold framed in a deep navy rounded tile",
        designPhilosophy: "Interlocking geometric facets representing security, growth vectors, and multi-asset portfolio balance."
      },
      targetAudience: {
        personaName: "Marcus Thorne",
        demographics: "Tech Founder & CEO, 30-45 years old, Liquid Net Worth $2M-$25M",
        painPoints: [
          "Idle startup treasury earning zero yield in traditional banks",
          "Fragmented accounts across multiple legacy wealth managers",
          "Complex cross-border equity exercise tax liabilities"
        ],
        keyMotivation: "Consolidating liquid wealth into a single automated, high-yield private dashboard."
      }
    }
  }
];
