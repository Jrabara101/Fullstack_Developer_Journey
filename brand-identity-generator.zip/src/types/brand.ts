export interface ColorItem {
  name: string;
  hex: string;
  role: "Primary" | "Secondary" | "Accent" | "Background" | "Surface";
  usage: string;
}

export interface FontItem {
  family: string;
  category: string;
  googleFontUrl: string;
  rationale: string;
}

export interface TypographySystem {
  headerFont: FontItem;
  bodyFont: FontItem;
  sampleHeadline: string;
  sampleBody: string;
}

export interface LogoConcepts {
  primaryLogoPrompt: string;
  secondaryMarkPrompt: string;
  faviconPrompt: string;
  designPhilosophy: string;
  primaryLogoUrl?: string;
  secondaryMarkUrl?: string;
  faviconUrl?: string;
}

export interface CoreValue {
  title: string;
  description: string;
}

export interface VoiceAndTone {
  adjectives: string[];
  dos: string[];
  donts: string[];
  samplePhrases: string[];
}

export interface TargetAudience {
  personaName: string;
  demographics: string;
  painPoints: string[];
  keyMotivation: string;
}

export interface BrandBible {
  id: string;
  createdAt: string;
  brandName: string;
  tagline: string;
  elevatorPitch: string;
  missionStatement: string;
  visionStatement: string;
  coreValues: CoreValue[];
  voiceAndTone: VoiceAndTone;
  colorPalette: ColorItem[];
  typography: TypographySystem;
  logoConcepts: LogoConcepts;
  targetAudience: TargetAudience;
}

export type ImageSizeOption = "1K" | "2K" | "4K";
export type AspectRatioOption = "1:1" | "3:4" | "4:3" | "16:9" | "9:16";

export interface LogoGenerationConfig {
  prompt: string;
  aspectRatio: AspectRatioOption;
  imageSize: ImageSizeOption;
  model: "gemini-3.1-flash-image" | "gemini-3.1-flash-lite-image" | "gemini-3-pro-image-preview";
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  content: string;
  timestamp: string;
  modelUsed?: string;
}

export interface BrandPreset {
  id: string;
  title: string;
  tagline: string;
  industry: string;
  vibe: string;
  mission: string;
  brand: BrandBible;
}
