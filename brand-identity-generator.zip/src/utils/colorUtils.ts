// Utility functions for calculating WCAG contrast ratios and color formats

export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  let cleanHex = hex.replace("#", "").trim();
  if (cleanHex.length === 3) {
    cleanHex = cleanHex
      .split("")
      .map((c) => c + c)
      .join("");
  }
  if (cleanHex.length !== 6) return null;

  const num = parseInt(cleanHex, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

export function getLuminance(r: number, g: number, b: number): number {
  const a = [r, g, b].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
}

export function getContrastRatio(hex1: string, hex2: string): number {
  const rgb1 = hexToRgb(hex1);
  const rgb2 = hexToRgb(hex2);

  if (!rgb1 || !rgb2) return 1;

  const lum1 = getLuminance(rgb1.r, rgb1.g, rgb1.b);
  const lum2 = getLuminance(rgb2.r, rgb2.g, rgb2.b);

  const brightest = Math.max(lum1, lum2);
  const darkest = Math.min(lum1, lum2);

  return (brightest + 0.05) / (darkest + 0.05);
}

export function getTextColorForBackground(bgHex: string): "#000000" | "#FFFFFF" {
  const contrastWithWhite = getContrastRatio(bgHex, "#FFFFFF");
  const contrastWithBlack = getContrastRatio(bgHex, "#000000");
  return contrastWithWhite >= contrastWithBlack ? "#FFFFFF" : "#000000";
}

export function getWCAGBadge(hex: string, bgHex = "#FFFFFF"): { label: string; pass: boolean } {
  const ratio = getContrastRatio(hex, bgHex);
  if (ratio >= 7) return { label: `AAA (${ratio.toFixed(1)}:1)`, pass: true };
  if (ratio >= 4.5) return { label: `AA (${ratio.toFixed(1)}:1)`, pass: true };
  if (ratio >= 3) return { label: `AA Large (${ratio.toFixed(1)}:1)`, pass: true };
  return { label: `Fail (${ratio.toFixed(1)}:1)`, pass: false };
}
