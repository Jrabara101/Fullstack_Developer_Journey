import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '20mb' }));

const apiKey = process.env.GEMINI_API_KEY || '';

const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper to calculate contrast ratio against black (#000000) and white (#ffffff)
function getContrastRatio(hexColor: string, isAgainstWhite: boolean): number {
  const cleanHex = hexColor.replace('#', '');
  if (cleanHex.length !== 6) return 4.5;
  const r = parseInt(cleanHex.substring(0, 2), 16) / 255;
  const g = parseInt(cleanHex.substring(2, 4), 16) / 255;
  const b = parseInt(cleanHex.substring(4, 6), 16) / 255;

  const srgbToLin = (c: number) => (c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));
  const L1 = 0.2126 * srgbToLin(r) + 0.7152 * srgbToLin(g) + 0.0722 * srgbToLin(b);
  const L2 = isAgainstWhite ? 1.0 : 0.0;

  const lighter = Math.max(L1, L2);
  const darker = Math.min(L1, L2);
  const ratio = (lighter + 0.05) / (darker + 0.05);
  return Math.round(ratio * 10) / 10;
}

// Convert Hex to RGB and CMYK strings
function convertHexColors(hexColor: string) {
  const clean = hexColor.replace('#', '');
  if (clean.length !== 6) {
    return {
      rgb: 'rgb(24, 24, 27)',
      cmyk: 'cmyk(0%, 0%, 0%, 90%)',
    };
  }
  const r = parseInt(clean.substring(0, 2), 16);
  const g = parseInt(clean.substring(2, 4), 16);
  const b = parseInt(clean.substring(4, 6), 16);

  const rgb = `rgb(${r}, ${g}, ${b})`;

  // RGB to CMYK
  const rNorm = r / 255;
  const gNorm = g / 255;
  const bNorm = b / 255;
  const k = 1 - Math.max(rNorm, gNorm, bNorm);
  if (k === 1) {
    return { rgb, cmyk: 'cmyk(0%, 0%, 0%, 100%)' };
  }
  const c = Math.round(((1 - rNorm - k) / (1 - k)) * 100);
  const m = Math.round(((1 - gNorm - k) / (1 - k)) * 100);
  const y = Math.round(((1 - bNorm - k) / (1 - k)) * 100);
  const kPercent = Math.round(k * 100);

  return {
    rgb,
    cmyk: `cmyk(${c}%, ${m}%, ${y}%, ${kPercent}%)`,
  };
}

// 1. API: Generate Brand Bible
app.post('/api/generate-brand', async (req: Request, res: Response) => {
  try {
    const {
      mission,
      companyName = '',
      industry = 'Technology & Modern Services',
      tone = 'Bold & Visionary',
      visualStyle = 'Swiss Minimalist & Contemporary',
      targetAudience = 'Forward-thinking professionals and modern consumers',
      values = 'Innovation, Precision, Trust',
    } = req.body;

    if (!mission || typeof mission !== 'string' || !mission.trim()) {
      res.status(400).json({ error: 'Company mission is required.' });
      return;
    }

    const systemPrompt = `You are a Principal Brand Strategist and Executive Creative Director from world-class identity agencies like Pentagram, Collins, and Wolff Olins.
The user provides their company mission and context.
Generate a comprehensive, mathematically sound, deeply cohesive "Brand Bible" specification in valid JSON format.

Your output JSON must strictly follow this structure:
{
  "companyName": "string (use provided name or create a memorable, punchy name)",
  "tagline": "string (concise, memorable, powerful)",
  "alternateTaglines": ["string", "string", "string"],
  "refinedMission": "string (elevated, inspiring version of user mission, 1-2 punchy sentences)",
  "brandNarrative": "string (compelling 2-3 paragraph brand ethos & origin story)",
  "elevatorPitch": "string (sharp 30-second summary)",
  "pillars": [
    { "title": "string", "statement": "string", "rationale": "string" },
    { "title": "string", "statement": "string", "rationale": "string" },
    { "title": "string", "statement": "string", "rationale": "string" }
  ],
  "palette": [
    {
      "role": "primary",
      "name": "string (evocative poetic name)",
      "hex": "#xxxxxx (valid 6-digit hex code)",
      "usageNotes": "string (e.g. 60% rule: primary brand moments, core surfaces, key signatures)",
      "suggestedProportion": "60%"
    },
    {
      "role": "secondary",
      "name": "string",
      "hex": "#xxxxxx",
      "usageNotes": "string (e.g. 25% rule: supportive UI elements, card accents, secondary badges)",
      "suggestedProportion": "25%"
    },
    {
      "role": "accent",
      "name": "string",
      "hex": "#xxxxxx",
      "usageNotes": "string (e.g. 10% rule: high-conversion CTAs, interactive highlights, status accents)",
      "suggestedProportion": "10%"
    },
    {
      "role": "neutral-dark",
      "name": "string",
      "hex": "#xxxxxx",
      "usageNotes": "string (e.g. Deep body typography, borders, dark mode canvas)",
      "suggestedProportion": "3%"
    },
    {
      "role": "neutral-light",
      "name": "string",
      "hex": "#xxxxxx",
      "usageNotes": "string (e.g. Primary light canvas, whitespace backgrounds, container fill)",
      "suggestedProportion": "2%"
    }
  ],
  "fonts": {
    "header": {
      "family": "string (pick an authentic, distinctive Google Font, e.g., 'Syne', 'Cabinet Grotesk', 'Cormorant Garamond', 'Fraunces', 'Cinzel', 'Space Grotesk', 'Plus Jakarta Sans', 'Outfit', 'Clash Display', 'Lexend', 'Manrope')",
      "category": "sans-serif | serif | display",
      "recommendedWeights": ["600", "700", "800"],
      "googleFontUrl": "https://fonts.google.com/specimen/...",
      "sampleHeadline": "string (a resonant brand statement in this voice)"
    },
    "body": {
      "family": "string (pick a supremely readable Google Font, e.g., 'Plus Jakarta Sans', 'Source Serif 4', 'Lora', 'Outfit', 'Inter Tight', 'DM Sans', 'Public Sans', 'Mulish')",
      "category": "sans-serif | serif",
      "recommendedWeights": ["400", "500", "600"],
      "googleFontUrl": "https://fonts.google.com/specimen/...",
      "sampleBody": "string (a thoughtful brand manifesto paragraph)"
    },
    "accentMono": {
      "family": "string (e.g., 'JetBrains Mono', 'IBM Plex Mono', 'Space Mono')",
      "category": "monospace",
      "recommendedWeights": ["400", "500"],
      "googleFontUrl": "https://fonts.google.com/specimen/..."
    },
    "pairingRationale": "string (why this specific pairing establishes typographic tension and harmony)",
    "scale": [
      { "level": "Display H1", "size": "48px / 3rem", "lineHeight": "1.05", "letterSpacing": "-0.025em", "weight": "700", "sampleText": "Title statement" },
      { "level": "Section H2", "size": "32px / 2rem", "lineHeight": "1.15", "letterSpacing": "-0.02em", "weight": "600", "sampleText": "Major Section" },
      { "level": "Subhead H3", "size": "24px / 1.5rem", "lineHeight": "1.25", "letterSpacing": "-0.015em", "weight": "600", "sampleText": "Subsection Anchor" },
      { "level": "Lead H4", "size": "18px / 1.125rem", "lineHeight": "1.35", "letterSpacing": "-0.01em", "weight": "500", "sampleText": "Key Highlight Lead" },
      { "level": "Body Text", "size": "16px / 1rem", "lineHeight": "1.6", "letterSpacing": "0", "weight": "400", "sampleText": "Prose paragraph explaining value delivery." },
      { "level": "Caption / Meta", "size": "13px / 0.8125rem", "lineHeight": "1.4", "letterSpacing": "0.02em", "weight": "500", "sampleText": "METADATA & SPECIFICATION" }
    ]
  },
  "logos": {
    "primary": {
      "type": "primary",
      "title": "Primary Wordmark & Icon Lockup",
      "description": "string (visual breakdown)",
      "promptUsed": "string (rich descriptive prompt for generating vector-style logo on solid clean background)",
      "clearSpaceRules": "Maintain clearance equal to 1.5x the height of the primary emblem 'X' on all 4 quadrants.",
      "minimumSizeRule": "Minimum digital render: 32px height. Minimum print render: 12mm height."
    },
    "secondaryMark": {
      "type": "secondary-mark",
      "title": "Sub-Mark / Favicon Emblem",
      "description": "string (simplified compact monogram or glyph for app icons and social avatars)",
      "promptUsed": "string (minimalist geometric submark icon prompt)",
      "clearSpaceRules": "Minimum 20% surrounding padding within circular or squircle container bounds.",
      "minimumSizeRule": "Readable down to 16x16px favicon resolution."
    },
    "badge": {
      "type": "badge",
      "title": "Emblem & Seal of Craft",
      "description": "string (circular or badge lockup for packaging, stamps, and physical hardware)",
      "promptUsed": "string (circular seal badge prompt)",
      "clearSpaceRules": "Maintain 12px outer boundary margin in all layout environments.",
      "minimumSizeRule": "Minimum print stamp diameter: 20mm."
    }
  },
  "toneGuidelines": [
    { "attribute": "e.g. Visionary yet Grounded", "doText": "Speak with conviction, lean on verifiable impact and clear outcomes.", "dontText": "Avoid empty corporate buzzwords and ungrounded hyperbole." },
    { "attribute": "e.g. Human & Precise", "doText": "Use plain, elegant language that respects the reader's intellect.", "dontText": "Never patronize or bury truth under technical jargon." },
    { "attribute": "e.g. Resolute & Minimal", "doText": "Say what matters in few words, letting design and craft breathe.", "dontText": "Don't over-explain obvious mechanics or crowd the message." }
  ],
  "applications": {
    "websiteHeadline": "string (powerful website hero headline)",
    "websiteSubhead": "string (supporting hero narrative)",
    "socialHandle": "string (e.g. @brandforge)",
    "packagingNote": "string (packaging tagline or stamp text)"
  }
}

Ensure the 5-color palette hex codes are strictly valid 6-digit hex (e.g. #0A0A0A, #2563EB).
Ensure the palette has high contrast between neutral-dark and neutral-light.
Respond ONLY with valid JSON.`;

    const userPrompt = `Company Mission: "${mission}"
Company Name (optional): "${companyName}"
Industry: "${industry}"
Tone: "${tone}"
Visual Style: "${visualStyle}"
Target Audience: "${targetAudience}"
Core Values: "${values}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.7,
      },
    });

    const responseText = response.text || '{}';
    const parsedData = JSON.parse(responseText);

    // Enhance palette with computed RGB, CMYK, and contrast ratios
    if (Array.isArray(parsedData.palette)) {
      parsedData.palette = parsedData.palette.map((color: any) => {
        const hex = color.hex && color.hex.startsWith('#') ? color.hex : '#1e293b';
        const converted = convertHexColors(hex);
        const contrastOnWhite = getContrastRatio(hex, true);
        const contrastOnDark = getContrastRatio(hex, false);
        return {
          ...color,
          hex,
          rgb: converted.rgb,
          cmyk: converted.cmyk,
          contrastOnWhite,
          contrastOnDark,
        };
      });
    }

    const brandBible = {
      id: 'brand_' + Date.now(),
      createdAt: new Date().toISOString(),
      originalMission: mission,
      industry,
      targetAudience,
      visualStyle,
      ...parsedData,
    };

    res.json({ brandBible });
  } catch (err: any) {
    console.error('Error generating brand:', err);
    res.status(500).json({
      error: 'Failed to generate brand identity: ' + (err.message || String(err)),
    });
  }
});

// 2. API: Generate Logo Images using gemini-3-pro-image-preview
// Affordance for 1K, 2K, 4K resolution!
app.post('/api/generate-image', async (req: Request, res: Response) => {
  try {
    const {
      prompt,
      imageSize = '1K', // '1K' | '2K' | '4K'
      aspectRatio = '1:1',
      brandName = 'Brand',
      logoType = 'primary', // 'primary' | 'secondary-mark' | 'badge'
    } = req.body;

    if (!prompt) {
      res.status(400).json({ error: 'Prompt is required.' });
      return;
    }

    // Format prompt specifically for professional vector-style brand marks
    const enhancedPrompt = `Professional modern minimalist corporate logo design for "${brandName}". ${prompt}. Clean vector aesthetic, flat colors, isolated on solid neutral studio background, crisp vector geometry, no gradients, no photorealistic noise, graphic design masterpiece, Behance brand identity standard, 8k clarity, perfectly centered symbol.`;

    const validSize = ['1K', '2K', '4K'].includes(imageSize) ? imageSize : '1K';
    const validAspectRatio = ['1:1', '4:3', '16:9', '3:4'].includes(aspectRatio) ? aspectRatio : '1:1';

    // Model required: gemini-3-pro-image-preview (with fallback handling if needed)
    let imageUrl = '';
    let usedModel = 'gemini-3-pro-image-preview';

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: validAspectRatio as any,
            imageSize: validSize as any,
          },
        },
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            imageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
            break;
          }
        }
      }
    } catch (primaryModelErr: any) {
      console.warn('gemini-3-pro-image-preview generation notice, attempting fallback:', primaryModelErr.message);
      // Attempt fallback with gemini-3.1-flash-image
      usedModel = 'gemini-3.1-flash-image';
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-3.1-flash-image',
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: validAspectRatio as any,
            imageSize: validSize as any,
          },
        },
      });

      if (fallbackResponse.candidates?.[0]?.content?.parts) {
        for (const part of fallbackResponse.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            imageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
            break;
          }
        }
      }
    }

    if (!imageUrl) {
      res.status(500).json({ error: 'Image was not returned by the model.' });
      return;
    }

    res.json({
      imageUrl,
      imageSize: validSize,
      aspectRatio: validAspectRatio,
      modelUsed: usedModel,
    });
  } catch (err: any) {
    console.error('Image generation error:', err);
    res.status(500).json({
      error: 'Failed to generate logo image: ' + (err.message || String(err)),
    });
  }
});

// 3. API: Multi-turn Chat with Gemini Creative Director
// Uses: gemini-3.1-pro-preview for complex tasks, gemini-3.5-flash for general tasks, and gemini-3.1-flash-lite for fast tasks.
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const {
      messages,
      currentBrand,
      modelType = 'gemini-3.5-flash', // 'gemini-3.1-pro-preview' | 'gemini-3.5-flash' | 'gemini-3.1-flash-lite'
      role = 'Executive Creative Director & Brand Strategist',
    } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages array is required.' });
      return;
    }

    // Determine target model
    let targetModel = 'gemini-3.5-flash';
    if (['gemini-3.1-pro-preview', 'gemini-3.5-flash', 'gemini-3.1-flash-lite'].includes(modelType)) {
      targetModel = modelType;
    }

    const brandContext = currentBrand
      ? `CURRENT ACTIVE BRAND SPECIFICATION:
- Brand Name: ${currentBrand.companyName || 'Unnamed'}
- Tagline: ${currentBrand.tagline || 'N/A'}
- Refined Mission: ${currentBrand.refinedMission || currentBrand.originalMission || 'N/A'}
- Industry: ${currentBrand.industry || 'N/A'}
- Visual Style: ${currentBrand.visualStyle || 'N/A'}
- Palette: ${currentBrand.palette ? currentBrand.palette.map((c: any) => `${c.name} (${c.hex}, ${c.role})`).join(', ') : 'N/A'}
- Fonts: Display: ${currentBrand.fonts?.header?.family || 'N/A'}, Body: ${currentBrand.fonts?.body?.family || 'N/A'}
- Tone Pillars: ${currentBrand.pillars ? currentBrand.pillars.map((p: any) => p.title).join(' / ') : 'N/A'}`
      : 'No brand has been generated yet.';

    const systemInstruction = `You are the ${role} at a legendary design agency (Pentagram / Collins caliber).
You advise founders and design leads on high-level brand strategy, visual coherence, typography pairings, color psychology, launch copywriting, and brand consistency.

Guidelines:
1. Maintain an authoritative, tasteful, inspiring, and direct design voice.
2. Provide precise, actionable advice with concrete examples (specific hex codes, font weights, real copywriting slogans, packaging placement notes).
3. If the user asks for new taglines, suggest 4 distinct creative angles (e.g. poetic, bold imperative, architectural, provocative).
4. If the user asks for palette or font changes, give exact hex codes or Google Font pairings with clear aesthetic justification.
5. Keep your tone concise, sophisticated, and free of AI fluff or repetitive pleasantries.

${brandContext}`;

    // Format messages for Gemini API contents
    const contents = messages.map((m: any) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    const response = await ai.models.generateContent({
      model: targetModel,
      contents,
      config: {
        systemInstruction,
        temperature: 0.75,
      },
    });

    const replyText = response.text || 'I have analyzed your brand requirements.';

    res.json({
      reply: replyText,
      modelUsed: targetModel,
    });
  } catch (err: any) {
    console.error('Chat error:', err);
    res.status(500).json({
      error: 'Failed to communicate with AI Creative Director: ' + (err.message || String(err)),
    });
  }
});

// Mount Vite or static build
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    console.log(`BrandForge server running on http://localhost:${PORT}`);
  });
}

startServer();
