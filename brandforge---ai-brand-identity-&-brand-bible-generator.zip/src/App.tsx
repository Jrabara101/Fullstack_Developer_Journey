import React, { useState } from 'react';
import { BrandBible, LogoAsset } from './types';
import { SAMPLE_BRAND_BIBLE } from './services/sampleBrand';
import { generateBrandAPI } from './services/api';
import { Navbar } from './components/Navbar';
import { MissionInputForm } from './components/MissionInputForm';
import { OverviewTab } from './components/tabs/OverviewTab';
import { LogoSuiteTab } from './components/tabs/LogoSuiteTab';
import { ColorSystemTab } from './components/tabs/ColorSystemTab';
import { TypographyTab } from './components/tabs/TypographyTab';
import { VoiceTab } from './components/tabs/VoiceTab';
import { MockupsTab } from './components/tabs/MockupsTab';
import { CreativeDirectorChat } from './components/CreativeDirectorChat';
import { ExportBrandBookModal } from './components/ExportBrandBookModal';
import { Sparkles, MessageSquare, AlertCircle } from 'lucide-react';

export default function App() {
  const [brand, setBrand] = useState<BrandBible>(SAMPLE_BRAND_BIBLE);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [isNewBrandModalOpen, setIsNewBrandModalOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isGeneratingBrand, setIsGeneratingBrand] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);

  const handleGenerateBrand = async (params: {
    mission: string;
    companyName?: string;
    industry?: string;
    tone?: string;
    visualStyle?: string;
    targetAudience?: string;
    values?: string;
  }) => {
    setIsGeneratingBrand(true);
    setGlobalError(null);
    try {
      const newBrand = await generateBrandAPI(params);
      setBrand(newBrand);
      setIsNewBrandModalOpen(false);
      setActiveTab('overview');
    } catch (err: any) {
      console.error('Failed to generate brand:', err);
      setGlobalError(
        err.message || 'Failed to generate brand. Please verify your Gemini API key in Settings > Secrets.'
      );
    } finally {
      setIsGeneratingBrand(false);
    }
  };

  const handleUpdateLogo = (
    logoKey: 'primary' | 'secondaryMark' | 'badge',
    updated: Partial<LogoAsset>
  ) => {
    setBrand((prev) => ({
      ...prev,
      logos: {
        ...prev.logos,
        [logoKey]: {
          ...prev.logos[logoKey],
          ...updated,
        },
      },
    }));
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Navbar */}
      <Navbar
        currentBrand={brand}
        onOpenNewModal={() => setIsNewBrandModalOpen(true)}
        onOpenChat={() => setIsChatOpen((prev) => !prev)}
        isChatOpen={isChatOpen}
        onExport={() => setIsExportModalOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Global Error Banner */}
      {globalError && (
        <div className="border-b border-rose-800/80 bg-rose-950/70 px-4 py-2.5 text-xs text-rose-200 flex items-center justify-between">
          <div className="mx-auto flex max-w-7xl items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
            <span>{globalError}</span>
          </div>
          <button
            onClick={() => setGlobalError(null)}
            className="text-rose-400 hover:text-white text-xs font-semibold px-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {activeTab === 'overview' && (
          <OverviewTab brand={brand} onNavigateToTab={(tab) => setActiveTab(tab)} />
        )}
        {activeTab === 'logos' && (
          <LogoSuiteTab brand={brand} onUpdateLogo={handleUpdateLogo} />
        )}
        {activeTab === 'colors' && <ColorSystemTab brand={brand} />}
        {activeTab === 'typography' && <TypographyTab brand={brand} />}
        {activeTab === 'voice' && <VoiceTab brand={brand} />}
        {activeTab === 'mockups' && <MockupsTab brand={brand} />}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-900 bg-neutral-950/80 py-6 text-xs text-neutral-500">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-300">BrandForge</span>
            <span>·</span>
            <span>AI Brand Identity & Brand Bible Generator</span>
          </div>
          <div className="flex items-center gap-4 text-neutral-400">
            <span>Powered by Gemini 3.8 Flash & Gemini 3 Pro</span>
            <span>·</span>
            <span>1K / 2K / 4K Resolution Vector Suite</span>
          </div>
        </div>
      </footer>

      {/* Modals & Chat Overlays */}
      <MissionInputForm
        isOpen={isNewBrandModalOpen}
        onClose={() => setIsNewBrandModalOpen(false)}
        onSubmit={handleGenerateBrand}
        isLoading={isGeneratingBrand}
      />

      <CreativeDirectorChat
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        brand={brand}
      />

      <ExportBrandBookModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        brand={brand}
      />

      {/* Floating Chat Trigger when Chat is Closed */}
      {!isChatOpen && (
        <button
          onClick={() => setIsChatOpen(true)}
          className="fixed bottom-5 right-5 z-30 flex items-center gap-2 rounded-full bg-indigo-600 px-4 py-3 text-xs font-semibold text-white shadow-xl shadow-indigo-600/30 transition-transform hover:scale-105 hover:bg-indigo-500"
        >
          <MessageSquare className="h-4 w-4" />
          <span>Chat with Creative Director</span>
        </button>
      )}
    </div>
  );
}
