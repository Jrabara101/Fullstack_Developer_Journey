import React, { useState, useRef, useEffect } from 'react';
import { BrandBible, ChatMessage, ChatModel } from '../types';
import { sendChatMessageAPI } from '../services/api';
import {
  MessageSquare,
  Send,
  X,
  Sparkles,
  Bot,
  User,
  Zap,
  BrainCircuit,
  Trash2,
  RefreshCw,
} from 'lucide-react';

interface CreativeDirectorChatProps {
  isOpen: boolean;
  onClose: () => void;
  brand: BrandBible | null;
}

export const CreativeDirectorChat: React.FC<CreativeDirectorChatProps> = ({
  isOpen,
  onClose,
  brand,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome_1',
      role: 'assistant',
      content: brand
        ? `Hello! I am your Executive Creative Director & Brand Strategist. I have reviewed the active brand specification for **${brand.companyName}** ("${brand.tagline}"). How can I help refine your visual identity, critique your font pairings, or author launch campaigns today?`
        : `Greetings! I am your Executive Creative Director. Once you generate or select a brand, I can critique typography pairings, optimize color contrasts, write launch copy, or brainstorm strategic taglines. What brand challenge are we addressing?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      modelUsed: 'gemini-3.5-flash',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<ChatModel>('gemini-3.5-flash');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const handleSendMessage = async (userText: string) => {
    const textToSend = userText.trim();
    if (!textToSend || isLoading) return;

    const userMessage: ChatMessage = {
      id: 'user_' + Date.now(),
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInput('');
    setIsLoading(true);

    try {
      const response = await sendChatMessageAPI({
        messages: newHistory.map((m) => ({ role: m.role, content: m.content })),
        currentBrand: brand,
        modelType: selectedModel,
      });

      const assistantMessage: ChatMessage = {
        id: 'assistant_' + Date.now(),
        role: 'assistant',
        content: response.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: response.modelUsed,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: 'assistant_err_' + Date.now(),
        role: 'assistant',
        content: `Error: Unable to complete conversation turn (${err.message || 'Server error'}). Please ensure your Gemini API key is configured.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPrompt = (prompt: string) => {
    handleSendMessage(prompt);
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'reset_' + Date.now(),
        role: 'assistant',
        content: `Conversation reset. Ready to advise on brand identity strategy, typography, color harmony, and market positioning.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: selectedModel,
      },
    ]);
  };

  return (
    <aside className="fixed bottom-0 right-0 z-50 flex h-[620px] max-h-[85vh] w-full sm:w-[440px] flex-col rounded-t-2xl sm:rounded-2xl border border-neutral-800 bg-neutral-950 shadow-2xl overflow-hidden sm:bottom-4 sm:right-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800 bg-neutral-900/90 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
            <Bot className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-tight">
              AI Creative Director
            </h3>
            <p className="text-[10px] text-neutral-400">
              {brand ? `Advising: ${brand.companyName}` : 'Brand Identity Consultant'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handleClearChat}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
            title="Clear Chat History"
          >
            <Trash2 className="h-4 w-4" />
          </button>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Model Selector Bar */}
      <div className="border-b border-neutral-800/80 bg-neutral-900/50 px-3 py-2">
        <div className="flex items-center justify-between text-[11px] mb-1">
          <span className="text-neutral-400 font-medium">Model Engine:</span>
          <span className="font-mono text-[10px] text-indigo-400">{selectedModel}</span>
        </div>
        <div className="grid grid-cols-3 gap-1">
          <button
            onClick={() => setSelectedModel('gemini-3.5-flash')}
            className={`px-2 py-1 text-[11px] font-medium rounded transition-all text-center ${
              selectedModel === 'gemini-3.5-flash'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'bg-neutral-900 text-neutral-400 hover:text-neutral-200'
            }`}
            title="gemini-3.5-flash for general tasks"
          >
            General Flash
          </button>
          <button
            onClick={() => setSelectedModel('gemini-3.1-pro-preview')}
            className={`px-2 py-1 text-[11px] font-medium rounded transition-all text-center flex items-center justify-center gap-1 ${
              selectedModel === 'gemini-3.1-pro-preview'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'bg-neutral-900 text-neutral-400 hover:text-neutral-200'
            }`}
            title="gemini-3.1-pro-preview for particularly complex tasks"
          >
            <BrainCircuit className="h-3 w-3" />
            <span>3.1 Pro</span>
          </button>
          <button
            onClick={() => setSelectedModel('gemini-3.1-flash-lite')}
            className={`px-2 py-1 text-[11px] font-medium rounded transition-all text-center flex items-center justify-center gap-1 ${
              selectedModel === 'gemini-3.1-flash-lite'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'bg-neutral-900 text-neutral-400 hover:text-neutral-200'
            }`}
            title="gemini-3.1-flash-lite for fast tasks"
          >
            <Zap className="h-3 w-3" />
            <span>Fast Lite</span>
          </button>
        </div>
      </div>

      {/* Messages Scrollable Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        {messages.map((m) => {
          const isUser = m.role === 'user';
          return (
            <div
              key={m.id}
              className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-white text-[10px] font-bold">
                  CD
                </div>
              )}
              <div
                className={`max-w-[82%] rounded-2xl p-3 leading-relaxed ${
                  isUser
                    ? 'bg-indigo-600 text-white rounded-br-none shadow-md'
                    : 'bg-neutral-900 text-neutral-200 border border-neutral-800 rounded-bl-none shadow-sm'
                }`}
              >
                <div className="whitespace-pre-wrap font-sans">{m.content}</div>
                <div
                  className={`flex items-center justify-between gap-2 mt-1.5 text-[9px] font-mono ${
                    isUser ? 'text-indigo-200' : 'text-neutral-500'
                  }`}
                >
                  <span>{m.timestamp}</span>
                  {m.modelUsed && <span>{m.modelUsed.replace('gemini-', '')}</span>}
                </div>
              </div>
              {isUser && (
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-neutral-800 text-neutral-300 text-[10px] font-bold">
                  You
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-2.5 justify-start">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-white text-[10px]">
              <div className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
            </div>
            <div className="rounded-2xl rounded-bl-none bg-neutral-900 border border-neutral-800 p-3 text-neutral-400 italic">
              Evaluating brand identity with {selectedModel}...
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Bar */}
      <div className="border-t border-neutral-900 bg-neutral-950 px-3 py-2">
        <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1">
          <button
            onClick={() => handleQuickPrompt('Suggest 4 alternative punchy taglines for our mission')}
            className="whitespace-nowrap rounded-md border border-neutral-800 bg-neutral-900 px-2.5 py-1 text-[10px] text-neutral-300 hover:border-neutral-700 hover:text-white"
          >
            Tagline Sprint
          </button>
          <button
            onClick={() => handleQuickPrompt('How should we apply this 5-color palette to a dark mode mobile app?')}
            className="whitespace-nowrap rounded-md border border-neutral-800 bg-neutral-900 px-2.5 py-1 text-[10px] text-neutral-300 hover:border-neutral-700 hover:text-white"
          >
            Mobile UI Colors
          </button>
          <button
            onClick={() => handleQuickPrompt('Critique our Google Font pairing and suggest an editorial alternative')}
            className="whitespace-nowrap rounded-md border border-neutral-800 bg-neutral-900 px-2.5 py-1 text-[10px] text-neutral-300 hover:border-neutral-700 hover:text-white"
          >
            Font Critique
          </button>
          <button
            onClick={() => handleQuickPrompt('Write a punchy LinkedIn launch announcement post')}
            className="whitespace-nowrap rounded-md border border-neutral-800 bg-neutral-900 px-2.5 py-1 text-[10px] text-neutral-300 hover:border-neutral-700 hover:text-white"
          >
            Launch Copy
          </button>
        </div>
      </div>

      {/* Input Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(input);
        }}
        className="flex items-center gap-2 border-t border-neutral-800 bg-neutral-900 p-3"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Ask Creative Director (${selectedModel})...`}
          disabled={isLoading}
          className="flex-1 rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-xs text-neutral-100 placeholder-neutral-500 focus:border-indigo-500 focus:outline-none"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white shadow hover:bg-indigo-500 transition-colors disabled:opacity-40"
        >
          <Send className="h-3.5 w-3.5" />
        </button>
      </form>
    </aside>
  );
};
