import React, { useState } from 'react';
import { BrandBible } from '../types';
import { X, Printer, Download, Copy, Check, FileText } from 'lucide-react';

interface ExportBrandBookModalProps {
  isOpen: boolean;
  onClose: () => void;
  brand: BrandBible;
}

export const ExportBrandBookModal: React.FC<ExportBrandBookModalProps> = ({
  isOpen,
  onClose,
  brand,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(brand, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `${brand.companyName.toLowerCase().replace(/\s+/g, '_')}_brand_bible.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const generateMarkdownBible = () => {
    return `# BRAND BIBLE: ${brand.companyName.toUpperCase()}
*Identity & Visual Specification Document*
Generated: ${new Date(brand.createdAt).toLocaleDateString()}

---

## 1. EXECUTIVE MISSION & PURPOSE
**Refined Mission:**
> ${brand.refinedMission}

**Tagline:** "${brand.tagline}"

**Elevator Pitch:**
${brand.elevatorPitch}

**Brand Narrative:**
${brand.brandNarrative}

---

## 2. STRATEGIC PILLARS
${brand.pillars.map((p, i) => `### 0${i + 1}. ${p.title}
- Statement: ${p.statement}
- Rationale: ${p.rationale}`).join('\n\n')}

---

## 3. COLOR SYSTEM (5-COLOR PALETTE)
${brand.palette.map((c) => `- **${c.role.toUpperCase()}: ${c.name}**
  Hex: ${c.hex} | RGB: ${c.rgb} | CMYK: ${c.cmyk}
  Proportion: ${c.suggestedProportion}
  Usage: ${c.usageNotes}
  Contrast vs. White: ${c.contrastOnWhite}:1 | vs. Black: ${c.contrastOnDark}:1`).join('\n\n')}

---

## 4. TYPOGRAPHY
- **Display Face:** ${brand.fonts.header.family} (${brand.fonts.header.category})
- **Body Face:** ${brand.fonts.body.family} (${brand.fonts.body.category})
- **Monospace Face:** ${brand.fonts.accentMono?.family || 'JetBrains Mono'}
- **Pairing Rationale:** ${brand.fonts.pairingRationale}

---

## 5. VOICE & EDITORIAL GUIDELINES
${brand.toneGuidelines.map((t) => `### ${t.attribute}
- DO: ${t.doText}
- DON'T: ${t.dontText}`).join('\n\n')}

---
© ${new Date().getFullYear()} ${brand.companyName}. All Rights Reserved.`;
  };

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(generateMarkdownBible());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm print:p-0 print:bg-white print:static">
      <div className="relative flex max-h-[92vh] w-full max-w-4xl flex-col rounded-2xl border border-neutral-800 bg-neutral-950 shadow-2xl text-neutral-100 overflow-hidden print:border-none print:bg-white print:text-black print:max-h-none print:shadow-none">
        {/* Modal Action Bar (Hidden on print) */}
        <div className="flex items-center justify-between border-b border-neutral-800 bg-neutral-900/90 px-6 py-4 print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-indigo-400" />
            <div>
              <h2 className="text-base font-semibold text-white">
                Export Brand Bible Dossier
              </h2>
              <p className="text-xs text-neutral-400">
                Print, save as PDF, or download raw specifications
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-indigo-500 transition-colors"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={handleDownloadJson}
              className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-200 hover:bg-neutral-800 hover:text-white transition-colors"
            >
              <Download className="h-3.5 w-3.5 text-sky-400" />
              <span>Download JSON</span>
            </button>
            <button
              onClick={handleCopyMarkdown}
              className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-200 hover:bg-neutral-800 hover:text-white transition-colors"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5 text-neutral-400" />}
              <span>{copied ? 'Copied MD!' : 'Copy Markdown'}</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors ml-2"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Brand Bible Printable Content */}
        <div className="flex-1 overflow-y-auto p-8 sm:p-12 space-y-10 print:overflow-visible print:p-0">
          {/* Cover Page */}
          <div className="border-b border-neutral-800 pb-10 space-y-4 print:border-black">
            <div className="flex items-center justify-between text-xs text-neutral-400 print:text-neutral-600 font-mono">
              <span>BRAND IDENTITY MANUAL</span>
              <span>VERSION 1.0 · {new Date().getFullYear()}</span>
            </div>
            <h1
              className="text-4xl sm:text-6xl font-extrabold uppercase tracking-tight text-white print:text-black"
              style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
            >
              {brand.companyName}
            </h1>
            <p className="text-xl sm:text-2xl font-medium text-indigo-400 print:text-neutral-700 italic">
              "{brand.tagline}"
            </p>
            <p className="text-sm text-neutral-300 print:text-neutral-800 leading-relaxed max-w-3xl pt-2">
              {brand.refinedMission}
            </p>
          </div>

          {/* Palette Preview */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400 print:text-neutral-600">
              01. Chromatic Specification (5-Color Palette)
            </h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-5">
              {brand.palette.map((c, i) => (
                <div key={i} className="rounded-lg border border-neutral-800 overflow-hidden print:border-black">
                  <div className="h-16 w-full" style={{ backgroundColor: c.hex }} />
                  <div className="p-3 text-xs space-y-1">
                    <span className="font-bold block text-white print:text-black">{c.name}</span>
                    <span className="font-mono text-[11px] block text-neutral-400 print:text-neutral-700">{c.hex}</span>
                    <span className="font-mono text-[10px] block text-neutral-500">{c.rgb}</span>
                    <p className="text-[10px] text-neutral-400 print:text-neutral-600 mt-1">{c.usageNotes}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Typography Spec */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400 print:text-neutral-600">
              02. Typography Pairing
            </h3>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div className="rounded-lg border border-neutral-800 p-4 print:border-black">
                <span className="text-xs text-neutral-400 print:text-neutral-600 block mb-1">Display / Header</span>
                <h4
                  className="text-2xl font-bold text-white print:text-black"
                  style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
                >
                  {brand.fonts.header.family}
                </h4>
                <p className="text-xs text-neutral-400 print:text-neutral-600 mt-2">
                  Category: {brand.fonts.header.category} · Weights: {brand.fonts.header.recommendedWeights.join(', ')}
                </p>
              </div>

              <div className="rounded-lg border border-neutral-800 p-4 print:border-black">
                <span className="text-xs text-neutral-400 print:text-neutral-600 block mb-1">Body / Prose</span>
                <h4
                  className="text-2xl font-semibold text-white print:text-black"
                  style={{ fontFamily: `'${brand.fonts.body.family}', sans-serif` }}
                >
                  {brand.fonts.body.family}
                </h4>
                <p className="text-xs text-neutral-400 print:text-neutral-600 mt-2">
                  Category: {brand.fonts.body.category} · Weights: {brand.fonts.body.recommendedWeights.join(', ')}
                </p>
              </div>
            </div>
          </div>

          {/* Strategic Pillars */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400 print:text-neutral-600">
              03. Strategic Pillars & Mission
            </h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              {brand.pillars.map((p, i) => (
                <div key={i} className="rounded-lg border border-neutral-800 p-4 space-y-2 print:border-black">
                  <span className="font-mono text-xs text-indigo-400 print:text-neutral-700">0{i + 1}</span>
                  <h5 className="font-bold text-white print:text-black text-sm">{p.title}</h5>
                  <p className="text-xs text-neutral-300 print:text-neutral-700">"{p.statement}"</p>
                  <p className="text-[11px] text-neutral-400 print:text-neutral-600 pt-2 border-t border-neutral-800 print:border-neutral-300">{p.rationale}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
