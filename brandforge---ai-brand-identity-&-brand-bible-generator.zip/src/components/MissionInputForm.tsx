import React, { useState } from 'react';
import { Sparkles, Wand2, X, ArrowRight, Compass, Shield, Lightbulb } from 'lucide-react';
import { MISSION_PRESETS } from '../services/sampleBrand';

interface MissionInputFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (params: {
    mission: string;
    companyName?: string;
    industry?: string;
    tone?: string;
    visualStyle?: string;
    targetAudience?: string;
    values?: string;
  }) => Promise<void>;
  isLoading: boolean;
}

export const MissionInputForm: React.FC<MissionInputFormProps> = ({
  isOpen,
  onClose,
  onSubmit,
  isLoading,
}) => {
  const [mission, setMission] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [industry, setIndustry] = useState('Technology & Autonomous Systems');
  const [tone, setTone] = useState('Bold, Visionary & Rigorous');
  const [visualStyle, setVisualStyle] = useState('Swiss Precision & Contemporary Minimalism');
  const [targetAudience, setTargetAudience] = useState('');
  const [values, setValues] = useState('Innovation, Integrity, Precision');

  if (!isOpen) return null;

  const handleApplyPreset = (preset: typeof MISSION_PRESETS[0]) => {
    setMission(preset.mission);
    setCompanyName(preset.name.split(' (')[0]);
    setIndustry(preset.industry);
    setTone(preset.tone);
    setVisualStyle(preset.visualStyle);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mission.trim()) return;
    await onSubmit({
      mission,
      companyName,
      industry,
      tone,
      visualStyle,
      targetAudience,
      values,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-neutral-800 bg-neutral-900 p-6 shadow-2xl text-neutral-100">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Wand2 className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-lg font-semibold tracking-tight text-white">
                Generate Brand Bible
              </h2>
              <p className="text-xs text-neutral-400">
                Transform your mission into an executive identity system
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isLoading}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Quick Presets */}
        <div className="mt-4">
          <p className="text-xs font-medium text-neutral-400 mb-2 flex items-center gap-1.5">
            <Compass className="h-3.5 w-3.5 text-sky-400" />
            Quick Presets / Inspiration:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {MISSION_PRESETS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleApplyPreset(p)}
                className="rounded-md border border-neutral-800 bg-neutral-950 px-2.5 py-1 text-xs text-neutral-300 hover:border-neutral-700 hover:bg-neutral-800 hover:text-white transition-colors text-left"
              >
                {p.name.split(' (')[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Mission statement */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300 mb-1.5">
              Company Mission Statement <span className="text-rose-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={mission}
              onChange={(e) => setMission(e.target.value)}
              placeholder="e.g. Accelerating global decarbonization through next-generation solid-state thermal storage for heavy industrial metallurgy."
              className="w-full rounded-lg border border-neutral-700 bg-neutral-950 p-3 text-sm text-neutral-100 placeholder-neutral-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <p className="mt-1 text-[11px] text-neutral-400">
              Describe the primary purpose, impact, and core ambition of your enterprise.
            </p>
          </div>

          {/* Company Name & Industry */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Company Name (Optional)
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="Leave blank to auto-name"
                className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-neutral-100 placeholder-neutral-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Industry / Domain
              </label>
              <input
                type="text"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                placeholder="e.g. Sustainable Energy, AI, Luxury"
                className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-neutral-100 placeholder-neutral-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Tone & Style */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Tone of Voice
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-neutral-100 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="Bold, Visionary & Rigorous">Bold, Visionary & Rigorous</option>
                <option value="Minimalist, Quiet Luxury & Poetic">Minimalist, Quiet Luxury & Poetic</option>
                <option value="Warm, Humanist & Artisanal">Warm, Humanist & Artisanal</option>
                <option value="High-Energy, Disruptive & Sharp">High-Energy, Disruptive & Sharp</option>
                <option value="Authoritative, Institutional & Trustworthy">Authoritative, Institutional & Trustworthy</option>
                <option value="Technical, Empirical & Cybernetic">Technical, Empirical & Cybernetic</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Visual Style Aesthetic
              </label>
              <select
                value={visualStyle}
                onChange={(e) => setVisualStyle(e.target.value)}
                className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-neutral-100 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="Swiss Precision & Contemporary Minimalism">Swiss Precision & Contemporary Minimalism</option>
                <option value="Monolithic Aerospace & High-Tech Monoline">Monolithic Aerospace & High-Tech Monoline</option>
                <option value="Neo-Classical Serif & Heritage Elegance">Neo-Classical Serif & Heritage Elegance</option>
                <option value="Warm Organic Modern & Earth Textures">Warm Organic Modern & Earth Textures</option>
                <option value="Industrial Brutalism & High Contrast">Industrial Brutalism & High Contrast</option>
                <option value="Playful Geometric & Kinetic Modern">Playful Geometric & Kinetic Modern</option>
              </select>
            </div>
          </div>

          {/* Target Audience & Values */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Target Audience
              </label>
              <input
                type="text"
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                placeholder="e.g. Enterprise CTOs, design connoisseurs"
                className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-neutral-100 placeholder-neutral-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Core Values (Comma-separated)
              </label>
              <input
                type="text"
                value={values}
                onChange={(e) => setValues(e.target.value)}
                placeholder="e.g. Precision, Craft, Speed"
                className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-sm text-neutral-100 placeholder-neutral-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading || !mission.trim()}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-600/30 transition-all hover:bg-indigo-500 disabled:opacity-50 disabled:pointer-events-none"
            >
              {isLoading ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  <span>Synthesizing Brand Bible Architecture...</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  <span>Generate Full Brand Bible</span>
                  <ArrowRight className="h-4 w-4 ml-1" />
                </>
              )}
            </button>
            <p className="mt-2 text-center text-[11px] text-neutral-400">
              Generates a complete Brand Bible with primary logo, secondary marks, 5-color hex palette, and Google Font pairings.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
