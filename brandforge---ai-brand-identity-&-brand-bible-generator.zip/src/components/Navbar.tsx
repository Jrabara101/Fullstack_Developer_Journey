import React from 'react';
import { Sparkles, BookOpen, MessageSquare, Download, Palette, Layers, RefreshCw } from 'lucide-react';
import { BrandBible } from '../types';

interface NavbarProps {
  currentBrand: BrandBible | null;
  onOpenNewModal: () => void;
  onOpenChat: () => void;
  isChatOpen: boolean;
  onExport: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentBrand,
  onOpenNewModal,
  onOpenChat,
  isChatOpen,
  onExport,
  activeTab,
  setActiveTab,
}) => {
  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'logos', label: 'Logo Suite & 4K Generator' },
    { id: 'colors', label: '5-Color Palette' },
    { id: 'typography', label: 'Typography' },
    { id: 'voice', label: 'Voice & Pillars' },
    { id: 'mockups', label: 'Brand in Wild' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800/80 bg-neutral-950/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-sky-400 text-white shadow-lg shadow-indigo-500/20">
            <Layers className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-white sm:text-lg">BrandForge</span>
              <span className="text-xs text-neutral-400">· Brand Bible Studio</span>
            </div>
            {currentBrand && (
              <p className="truncate text-xs text-indigo-400 font-medium">
                Active: {currentBrand.companyName}
              </p>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenNewModal}
            className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-200 transition-colors hover:border-neutral-600 hover:bg-neutral-800 hover:text-white"
          >
            <RefreshCw className="h-3.5 w-3.5 text-sky-400" />
            <span className="hidden sm:inline">New Brand</span>
          </button>

          <button
            onClick={onExport}
            className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-200 transition-colors hover:border-neutral-600 hover:bg-neutral-800 hover:text-white"
            title="Export Brand Bible Document"
          >
            <Download className="h-3.5 w-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Export Bible</span>
          </button>

          <button
            onClick={onOpenChat}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
              isChatOpen
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'border border-indigo-500/40 bg-indigo-950/40 text-indigo-300 hover:bg-indigo-900/50 hover:text-white'
            }`}
          >
            <MessageSquare className="h-3.5 w-3.5" />
            <span>AI Creative Director</span>
          </button>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="border-t border-neutral-900 bg-neutral-950 px-4 sm:px-6">
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto py-1 scrollbar-none">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`whitespace-nowrap px-3 py-2 text-xs font-medium transition-colors border-b-2 ${
                  isActive
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
