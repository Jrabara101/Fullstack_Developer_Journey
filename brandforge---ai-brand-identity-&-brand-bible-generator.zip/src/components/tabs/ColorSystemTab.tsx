import React, { useState } from 'react';
import { BrandBible, ColorSwatch } from '../../types';
import { Copy, Check, Palette, FileCode, Sliders, ShieldCheck } from 'lucide-react';

interface ColorSystemTabProps {
  brand: BrandBible;
}

export const ColorSystemTab: React.FC<ColorSystemTabProps> = ({ brand }) => {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const getCssVariables = () => {
    return `:root {\n` +
      brand.palette.map((c) => `  --brand-${c.role}: ${c.hex}; /* ${c.name} */`).join('\n') +
      `\n}`;
  };

  const getTailwindConfig = () => {
    const colorsObj = brand.palette.reduce((acc, c) => {
      acc[c.role] = c.hex;
      return acc;
    }, {} as Record<string, string>);
    return `// tailwind.config.js\nmodule.exports = {\n  theme: {\n    extend: {\n      colors: {\n        brand: ${JSON.stringify(colorsObj, null, 10)}\n      }\n    }\n  }\n};`;
  };

  return (
    <div className="space-y-10">
      {/* Header & 60-30-10 Proportion Guide */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-400">
              <Palette className="h-4 w-4" />
              <span>Harmonic 5-Color System</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
              Color Palette & Usage Notes
            </h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-xl">
              Mathematically balanced chromatic architecture adhering to the 60-30-10 rule and strict WCAG contrast compliance.
            </p>
          </div>

          {/* Quick Copy CSS and JSON */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => copyToClipboard(getCssVariables(), 'css')}
              className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:bg-neutral-800 hover:text-white transition-colors"
            >
              {copiedText === 'css' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <FileCode className="h-3.5 w-3.5 text-indigo-400" />}
              <span>{copiedText === 'css' ? 'Copied CSS!' : 'Copy CSS Variables'}</span>
            </button>
            <button
              onClick={() => copyToClipboard(JSON.stringify(brand.palette, null, 2), 'json')}
              className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:bg-neutral-800 hover:text-white transition-colors"
            >
              {copiedText === 'json' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5 text-neutral-400" />}
              <span>{copiedText === 'json' ? 'Copied JSON!' : 'Copy JSON'}</span>
            </button>
          </div>
        </div>

        {/* 60-30-10 Proportion Visualizer */}
        <div>
          <div className="flex justify-between items-center text-xs text-neutral-400 mb-2">
            <span>Visual Weight Allocation (60% Primary · 25% Secondary · 10% Accent · 5% Neutrals)</span>
          </div>
          <div className="flex h-10 w-full overflow-hidden rounded-xl border border-neutral-800 shadow-inner">
            {brand.palette.map((color, idx) => {
              const widthMap: Record<string, string> = {
                'primary': 'w-[55%]',
                'secondary': 'w-[25%]',
                'accent': 'w-[12%]',
                'neutral-dark': 'w-[4%]',
                'neutral-light': 'w-[4%]',
              };
              const widthClass = widthMap[color.role] || 'flex-1';
              return (
                <div
                  key={idx}
                  className={`${widthClass} h-full relative group transition-all cursor-pointer`}
                  style={{ backgroundColor: color.hex }}
                  onClick={() => copyToClipboard(color.hex, color.hex)}
                  title={`${color.name} (${color.hex})`}
                >
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/50 text-[10px] text-white font-mono transition-opacity">
                    {color.role}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* The 5 Individual Swatch Cards with Detailed Notes & Contrast */}
      <section className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-5">
        {brand.palette.map((color, idx) => {
          const isCopied = copiedText === color.hex;

          return (
            <div
              key={idx}
              className="flex flex-col justify-between rounded-xl border border-neutral-800 bg-neutral-900/60 overflow-hidden"
            >
              {/* Swatch Header */}
              <div
                className="relative h-36 w-full cursor-pointer group p-4 flex flex-col justify-between"
                style={{ backgroundColor: color.hex }}
                onClick={() => copyToClipboard(color.hex, color.hex)}
              >
                <div className="flex justify-between items-start">
                  <span
                    className="font-mono text-[10px] uppercase font-bold px-2 py-0.5 rounded shadow-sm"
                    style={{
                      backgroundColor: color.contrastOnDark > 4.5 ? '#00000088' : '#ffffff88',
                      color: color.contrastOnDark > 4.5 ? '#ffffff' : '#000000',
                    }}
                  >
                    {color.role}
                  </span>
                  <div
                    className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded bg-black/40 text-white"
                    title="Click to copy hex"
                  >
                    {isCopied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                  </div>
                </div>

                <div
                  className="font-mono text-sm font-bold tracking-wider"
                  style={{
                    color: color.contrastOnDark > 4.5 ? '#ffffff' : '#000000',
                  }}
                >
                  {color.hex}
                </div>
              </div>

              {/* Swatch Details */}
              <div className="p-4 space-y-4 flex-1 flex flex-col justify-between text-xs">
                <div className="space-y-2">
                  <div>
                    <h3 className="font-semibold text-white text-sm tracking-tight">{color.name}</h3>
                    <p className="font-mono text-[11px] text-neutral-400 mt-0.5">{color.rgb}</p>
                    <p className="font-mono text-[11px] text-neutral-500">{color.cmyk}</p>
                  </div>

                  <div className="pt-2 border-t border-neutral-800/80">
                    <span className="font-semibold text-neutral-300 block mb-1 text-[11px]">Usage Notes:</span>
                    <p className="text-neutral-400 leading-relaxed text-[11px]">
                      {color.usageNotes}
                    </p>
                  </div>
                </div>

                {/* Contrast Scores */}
                <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-2.5 space-y-1 text-[10px] font-mono">
                  <div className="flex justify-between items-center">
                    <span className="text-neutral-400">vs. White (#FFF):</span>
                    <span className={`font-semibold ${color.contrastOnWhite >= 4.5 ? 'text-emerald-400' : 'text-neutral-400'}`}>
                      {color.contrastOnWhite}:1 {color.contrastOnWhite >= 4.5 ? '✓ AA' : ''}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-neutral-400">vs. Black (#000):</span>
                    <span className={`font-semibold ${color.contrastOnDark >= 4.5 ? 'text-emerald-400' : 'text-neutral-400'}`}>
                      {color.contrastOnDark}:1 {color.contrastOnDark >= 4.5 ? '✓ AA' : ''}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </section>

      {/* 5x5 Accessibility Contrast Grid */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/40 p-6 sm:p-8 space-y-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">
            Color Accessibility & Pairwise Contrast Matrix
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Test legibility of text rendered on each background combination across the 5 brand colors.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-800">
                <th className="p-3 text-neutral-400 font-mono text-[11px]">Foreground / Background</th>
                {brand.palette.map((c, i) => (
                  <th key={i} className="p-3 text-neutral-300 font-medium">
                    {c.name.split(' ')[0]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono text-[11px]">
              {brand.palette.map((fg, rIdx) => (
                <tr key={rIdx}>
                  <td className="p-3 text-neutral-300 font-sans font-medium">
                    {fg.name} <span className="text-neutral-500 font-mono text-[10px]">({fg.role})</span>
                  </td>
                  {brand.palette.map((bg, cIdx) => {
                    const isSame = rIdx === cIdx;
                    return (
                      <td key={cIdx} className="p-2">
                        <div
                          className="h-10 rounded flex items-center justify-center font-bold px-2 text-center"
                          style={{
                            backgroundColor: bg.hex,
                            color: fg.hex,
                            border: '1px solid rgba(255,255,255,0.08)',
                          }}
                        >
                          {isSame ? '—' : 'Aa Sample'}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
