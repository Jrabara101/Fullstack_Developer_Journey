import React, { useState } from 'react';
import { BrandBible, ImageSize, AspectRatio, LogoAsset } from '../../types';
import { generateLogoImageAPI } from '../../services/api';
import {
  Download,
  Sparkles,
  Maximize2,
  Sliders,
  Copy,
  Check,
  Eye,
  Sun,
  Moon,
  Grid,
  ShieldCheck,
  Layers,
} from 'lucide-react';

interface LogoSuiteTabProps {
  brand: BrandBible;
  onUpdateLogo: (logoKey: 'primary' | 'secondaryMark' | 'badge', updated: Partial<LogoAsset>) => void;
}

export const LogoSuiteTab: React.FC<LogoSuiteTabProps> = ({ brand, onUpdateLogo }) => {
  const [selectedResolution, setSelectedResolution] = useState<ImageSize>('1K');
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatio>('1:1');
  const [activeBackground, setActiveBackground] = useState<'dark' | 'light'>('dark');
  const [showClearSpace, setShowClearSpace] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [customPrompts, setCustomPrompts] = useState<{ [key: string]: string }>({
    primary: brand.logos.primary.promptUsed,
    secondaryMark: brand.logos.secondaryMark.promptUsed,
    badge: brand.logos.badge.promptUsed,
  });
  const [loadingState, setLoadingState] = useState<{ [key: string]: boolean }>({});
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleGenerateImage = async (logoKey: 'primary' | 'secondaryMark' | 'badge') => {
    setLoadingState((prev) => ({ ...prev, [logoKey]: true }));
    setErrorMessage(null);

    const logo = brand.logos[logoKey];
    const prompt = customPrompts[logoKey] || logo.promptUsed;

    try {
      const result = await generateLogoImageAPI({
        prompt,
        imageSize: selectedResolution,
        aspectRatio: selectedAspectRatio,
        brandName: brand.companyName,
        logoType: logo.type as any,
      });

      onUpdateLogo(logoKey, {
        imageUrl: result.imageUrl,
        imageSize: selectedResolution,
        promptUsed: prompt,
      });
    } catch (err: any) {
      console.error('Logo generation error:', err);
      setErrorMessage(
        err.message || 'Generation failed. Please verify API key permissions for gemini-3-pro-image-preview.'
      );
    } finally {
      setLoadingState((prev) => ({ ...prev, [logoKey]: false }));
    }
  };

  const handleDownload = (logo: LogoAsset, name: string) => {
    if (logo.imageUrl) {
      const link = document.createElement('a');
      link.href = logo.imageUrl;
      link.download = `${brand.companyName.toLowerCase().replace(/\s+/g, '_')}_${name}_${selectedResolution}.png`;
      link.click();
    } else if (logo.svgFallback) {
      const blob = new Blob([logo.svgFallback], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${brand.companyName.toLowerCase().replace(/\s+/g, '_')}_${name}.svg`;
      link.click();
      URL.revokeObjectURL(url);
    }
  };

  const handleCopySvg = (logo: LogoAsset, key: string) => {
    if (logo.svgFallback) {
      navigator.clipboard.writeText(logo.svgFallback);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    }
  };

  const logoKeys: Array<{ key: 'primary' | 'secondaryMark' | 'badge'; label: string }> = [
    { key: 'primary', label: 'Primary Brand Logo' },
    { key: 'secondaryMark', label: 'Secondary Sub-Mark & Favicon' },
    { key: 'badge', label: 'Emblem Seal & Chassis Badge' },
  ];

  return (
    <div className="space-y-8">
      {/* Studio Header & Global Controls */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 sm:p-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-400">
              <Sparkles className="h-4 w-4" />
              <span>Gemini 3 Pro Image Preview Studio</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
              Primary Logos & Secondary Marks
            </h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl leading-relaxed">
              Generate ultra-high-fidelity vector-grade marks using <span className="text-neutral-200 font-mono">gemini-3-pro-image-preview</span> with precise resolution control (1K, 2K, 4K) and aspect ratios.
            </p>
          </div>

          {/* Affordance Controls for Image Size (1K, 2K, 4K) and Aspect Ratio */}
          <div className="flex flex-wrap items-center gap-4 rounded-xl border border-neutral-800 bg-neutral-950 p-4">
            {/* Resolution Selector (1K, 2K, 4K) */}
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">
                Resolution Affordance
              </label>
              <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-lg border border-neutral-800">
                {(['1K', '2K', '4K'] as ImageSize[]).map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedResolution(size)}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                      selectedResolution === size
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio Selector */}
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">
                Aspect Ratio
              </label>
              <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-lg border border-neutral-800">
                {(['1:1', '4:3', '16:9', '3:4'] as AspectRatio[]).map((ratio) => (
                  <button
                    key={ratio}
                    onClick={() => setSelectedAspectRatio(ratio)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                      selectedAspectRatio === ratio
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            {/* Visual Preview Mode Toggles */}
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-neutral-400 mb-1.5">
                Canvas Mode
              </label>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveBackground(activeBackground === 'dark' ? 'light' : 'dark')}
                  className="flex items-center gap-1.5 rounded-lg border border-neutral-800 bg-neutral-900 px-2.5 py-1.5 text-xs text-neutral-300 hover:text-white transition-colors"
                  title="Toggle Light / Dark backdrop"
                >
                  {activeBackground === 'dark' ? (
                    <>
                      <Moon className="h-3.5 w-3.5 text-indigo-400" />
                      <span>Dark</span>
                    </>
                  ) : (
                    <>
                      <Sun className="h-3.5 w-3.5 text-amber-400" />
                      <span>Light</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => setShowClearSpace(!showClearSpace)}
                  className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition-colors ${
                    showClearSpace
                      ? 'border-rose-500/50 bg-rose-950/40 text-rose-300'
                      : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-neutral-200'
                  }`}
                  title="Toggle clear-space exclusion grid overlay"
                >
                  <Grid className="h-3.5 w-3.5" />
                  <span>Clear Space</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="mt-4 rounded-lg border border-rose-500/30 bg-rose-950/30 p-3 text-xs text-rose-300">
            {errorMessage}
          </div>
        )}
      </section>

      {/* 3 Logo Cards: Primary, Secondary Sub-Mark, Emblem Badge */}
      <section className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {logoKeys.map(({ key, label }) => {
          const logo = brand.logos[key];
          const isLoading = loadingState[key];
          const prompt = customPrompts[key] ?? logo.promptUsed;

          return (
            <div
              key={key}
              className="flex flex-col justify-between rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-5"
            >
              {/* Card Title & Type */}
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[11px] font-mono uppercase tracking-wider text-indigo-400">
                    {key === 'primary' ? '01. MASTER LOCKUP' : key === 'secondaryMark' ? '02. FAVICON & MONOGRAM' : '03. EMBLEM & STAMP'}
                  </span>
                  <h3 className="text-lg font-bold text-white tracking-tight mt-0.5">
                    {logo.title}
                  </h3>
                </div>
                {logo.imageSize && (
                  <span className="font-mono text-[11px] text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800/60">
                    {logo.imageSize}
                  </span>
                )}
              </div>

              {/* Mark Canvas Container */}
              <div
                className={`relative flex aspect-square w-full items-center justify-center overflow-hidden rounded-xl border transition-colors ${
                  activeBackground === 'dark'
                    ? 'border-neutral-800 bg-neutral-950'
                    : 'border-neutral-300 bg-neutral-100'
                }`}
              >
                {/* Clear Space Exclusion Overlay */}
                {showClearSpace && (
                  <div className="absolute inset-4 z-20 pointer-events-none border border-dashed border-rose-500/60 bg-rose-500/5 flex items-center justify-center">
                    <span className="absolute top-1 left-1 font-mono text-[9px] text-rose-400 bg-black/60 px-1 rounded">
                      Exclusion Zone: 1.5x
                    </span>
                  </div>
                )}

                {/* Mark Render: AI Generated Image or Vector SVG Fallback */}
                {logo.imageUrl ? (
                  <img
                    src={logo.imageUrl}
                    alt={logo.title}
                    className="h-full w-full object-contain p-4 transition-transform duration-300 hover:scale-105"
                  />
                ) : logo.svgFallback ? (
                  <div
                    className="h-full w-full p-6 flex items-center justify-center"
                    dangerouslySetInnerHTML={{ __html: logo.svgFallback }}
                  />
                ) : (
                  <div className="text-center p-6 text-neutral-500">
                    <Layers className="mx-auto h-8 w-8 mb-2 opacity-40" />
                    <p className="text-xs">No image generated yet</p>
                  </div>
                )}

                {/* Loading Spinner */}
                {isLoading && (
                  <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm text-white">
                    <div className="h-8 w-8 animate-spin rounded-full border-2 border-indigo-500 border-t-transparent mb-2" />
                    <span className="text-xs font-medium text-neutral-300">
                      Generating {selectedResolution} Mark...
                    </span>
                    <span className="text-[10px] text-neutral-500 font-mono mt-0.5">
                      gemini-3-pro-image-preview
                    </span>
                  </div>
                )}
              </div>

              {/* Description & Rules */}
              <div className="space-y-3 text-xs">
                <p className="text-neutral-300 leading-relaxed font-normal">
                  {logo.description}
                </p>

                <div className="rounded-lg border border-neutral-800/80 bg-neutral-950 p-3 space-y-1.5 text-[11px] text-neutral-400">
                  <div className="flex items-start gap-1.5">
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong className="text-neutral-200">Clear Space:</strong> {logo.clearSpaceRules}</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <Maximize2 className="h-3.5 w-3.5 text-sky-400 shrink-0 mt-0.5" />
                    <span><strong className="text-neutral-200">Minimum Scale:</strong> {logo.minimumSizeRule}</span>
                  </div>
                </div>

                {/* Prompt Fine-tuning Input */}
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
                    Fine-tune AI Prompt:
                  </label>
                  <textarea
                    rows={2}
                    value={prompt}
                    onChange={(e) =>
                      setCustomPrompts((prev) => ({ ...prev, [key]: e.target.value }))
                    }
                    className="w-full rounded-md border border-neutral-800 bg-neutral-950 p-2 text-xs text-neutral-200 placeholder-neutral-600 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2 pt-2 border-t border-neutral-800">
                <button
                  onClick={() => handleGenerateImage(key)}
                  disabled={isLoading}
                  className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-2 text-xs font-semibold text-white shadow-md shadow-indigo-600/20 hover:bg-indigo-500 transition-colors disabled:opacity-50"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>
                    {logo.imageUrl ? `Re-render (${selectedResolution})` : `Generate Mark (${selectedResolution})`}
                  </span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDownload(logo, key)}
                    className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-neutral-700 bg-neutral-950 px-2.5 py-1.5 text-xs font-medium text-neutral-300 hover:bg-neutral-800 hover:text-white transition-colors"
                  >
                    <Download className="h-3.5 w-3.5 text-neutral-400" />
                    <span>Download</span>
                  </button>

                  {logo.svgFallback && (
                    <button
                      onClick={() => handleCopySvg(logo, key)}
                      className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-neutral-700 bg-neutral-950 px-2.5 py-1.5 text-xs font-medium text-neutral-300 hover:bg-neutral-800 hover:text-white transition-colors"
                      title="Copy raw SVG markup"
                    >
                      {copiedKey === key ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5 text-neutral-400" />
                          <span>Copy SVG</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </section>

      {/* Brand Identity Guidelines & Forbidden Alterations */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/40 p-6 space-y-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-neutral-300">
          Strict Logo Usage Rules & Prohibited Alterations
        </h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-4 text-xs text-neutral-400">
          <div className="rounded-lg border border-neutral-800/80 bg-neutral-950 p-3">
            <span className="font-semibold text-rose-400 block mb-1">01. Do Not Distort</span>
            Never stretch, skew, or alter horizontal/vertical aspect ratios under any media format.
          </div>
          <div className="rounded-lg border border-neutral-800/80 bg-neutral-950 p-3">
            <span className="font-semibold text-rose-400 block mb-1">02. No Unapproved Colors</span>
            Render strictly in brand hex palette swatches or monochrome (pure black / pure white).
          </div>
          <div className="rounded-lg border border-neutral-800/80 bg-neutral-950 p-3">
            <span className="font-semibold text-rose-400 block mb-1">03. Maintain Exclusion</span>
            Do not place text, icons, or visual noise within the defined 1.5x exclusion zone.
          </div>
          <div className="rounded-lg border border-neutral-800/80 bg-neutral-950 p-3">
            <span className="font-semibold text-rose-400 block mb-1">04. No Drop Shadows</span>
            Avoid drop shadows, glows, bevels, or skeuomorphic styling on primary marks.
          </div>
        </div>
      </section>
    </div>
  );
};
