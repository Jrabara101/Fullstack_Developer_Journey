import React, { useState } from 'react';
import { BrandBible } from '../../types';
import { RotateCw, Globe, CreditCard, Share2, Box, Sparkles, ArrowRight } from 'lucide-react';

interface MockupsTabProps {
  brand: BrandBible;
}

export const MockupsTab: React.FC<MockupsTabProps> = ({ brand }) => {
  const [isCardFlipped, setIsCardFlipped] = useState(false);
  const primaryColor = brand.palette.find((c) => c.role === 'primary')?.hex || '#0A0E17';
  const secondaryColor = brand.palette.find((c) => c.role === 'secondary')?.hex || '#1E293B';
  const accentColor = brand.palette.find((c) => c.role === 'accent')?.hex || '#38BDF8';
  const lightNeutral = brand.palette.find((c) => c.role === 'neutral-light')?.hex || '#F8FAFC';
  const darkNeutral = brand.palette.find((c) => c.role === 'neutral-dark')?.hex || '#020617';

  return (
    <div className="space-y-12">
      {/* Header */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 sm:p-8 space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-400">
          <Globe className="h-4 w-4" />
          <span>Brand in the Wild</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
          Real-World Application & Surface Mockups
        </h2>
        <p className="text-xs text-neutral-400 max-w-2xl leading-relaxed">
          Witness your primary logo, secondary marks, 5-color palette, and Google Fonts seamlessly synthesized across digital interfaces, physical stationery, and product packaging.
        </p>
      </section>

      {/* 1. Interactive 3D Business Card */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-sky-400" />
              <span>01. Heavyweight Tactile Business Card</span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Interactive 3D stationery mockup with hot-stamped foil on 600gsm uncoated cotton board.
            </p>
          </div>
          <button
            onClick={() => setIsCardFlipped(!isCardFlipped)}
            className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-200 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <RotateCw className="h-3.5 w-3.5 text-sky-400" />
            <span>Flip Card ({isCardFlipped ? 'Back' : 'Front'})</span>
          </button>
        </div>

        <div className="flex items-center justify-center p-8 sm:p-12 rounded-2xl border border-neutral-800 bg-neutral-950/80 perspective-1000">
          <div
            onClick={() => setIsCardFlipped(!isCardFlipped)}
            className="relative h-64 w-full max-w-md cursor-pointer transition-transform duration-700 preserve-3d"
            style={{
              transform: isCardFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
              transformStyle: 'preserve-3d',
            }}
          >
            {/* FRONT FACE */}
            <div
              className="absolute inset-0 flex flex-col justify-between rounded-xl p-8 shadow-2xl backface-hidden border"
              style={{
                backgroundColor: primaryColor,
                borderColor: 'rgba(255,255,255,0.1)',
                color: lightNeutral,
                backfaceVisibility: 'hidden',
              }}
            >
              <div className="flex items-center justify-between">
                {brand.logos.primary.imageUrl ? (
                  <img
                    src={brand.logos.primary.imageUrl}
                    alt={brand.companyName}
                    className="h-10 w-10 object-contain rounded"
                  />
                ) : brand.logos.secondaryMark.svgFallback ? (
                  <div
                    className="h-10 w-10"
                    dangerouslySetInnerHTML={{ __html: brand.logos.secondaryMark.svgFallback }}
                  />
                ) : (
                  <div className="h-8 w-8 rounded-full" style={{ backgroundColor: accentColor }} />
                )}
                <span className="font-mono text-[10px] tracking-widest uppercase opacity-75">
                  SPEC. 600GSM
                </span>
              </div>

              <div>
                <h4
                  className="text-2xl font-bold tracking-tight uppercase"
                  style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
                >
                  {brand.companyName}
                </h4>
                <p className="text-xs font-medium italic mt-1" style={{ color: accentColor }}>
                  {brand.tagline}
                </p>
              </div>

              <div className="flex items-end justify-between border-t border-white/10 pt-3 text-[11px] font-mono opacity-80">
                <span>IDENTITY SPECIFICATION</span>
                <span className="text-[10px] text-sky-400">CLICK TO FLIP ↻</span>
              </div>
            </div>

            {/* BACK FACE */}
            <div
              className="absolute inset-0 flex flex-col justify-between rounded-xl p-8 shadow-2xl backface-hidden border"
              style={{
                backgroundColor: secondaryColor,
                borderColor: 'rgba(255,255,255,0.12)',
                color: lightNeutral,
                transform: 'rotateY(180deg)',
                backfaceVisibility: 'hidden',
              }}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h5
                    className="text-base font-bold tracking-tight"
                    style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
                  >
                    ALEXANDER VANE
                  </h5>
                  <p className="text-[11px] font-mono text-sky-400">Chief Executive Officer</p>
                </div>
                <div
                  className="h-7 w-7 rounded-full flex items-center justify-center text-[10px] font-bold"
                  style={{ backgroundColor: accentColor, color: darkNeutral }}
                >
                  {brand.companyName.charAt(0)}
                </div>
              </div>

              <div className="space-y-1.5 text-xs font-mono">
                <p className="opacity-90">alexander@{brand.companyName.toLowerCase().replace(/\s+/g, '')}.com</p>
                <p className="opacity-75">+1 (415) 890-4200</p>
                <p className="opacity-75">{brand.applications?.websiteHeadline?.slice(0, 36) || 'Headquarters'} · Suite 400</p>
              </div>

              <div className="flex justify-between items-center text-[10px] font-mono border-t border-white/10 pt-2 opacity-70">
                <span>{brand.applications?.socialHandle || '@brand'}</span>
                <span>VERIFIED IDENTITY</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Modern Website Hero Mockup */}
      <section className="space-y-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Globe className="h-4 w-4 text-indigo-400" />
            <span>02. High-Conversion Website Hero & UI Shell</span>
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real dynamic preview of your typography, primary logo, and accent button hierarchy in digital product UI.
          </p>
        </div>

        <div className="overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-950 shadow-2xl">
          {/* Browser Chrome Header */}
          <div className="flex items-center justify-between border-b border-neutral-800 bg-neutral-900/90 px-4 py-3">
            <div className="flex items-center gap-1.5">
              <div className="h-3 w-3 rounded-full bg-rose-500/80" />
              <div className="h-3 w-3 rounded-full bg-amber-500/80" />
              <div className="h-3 w-3 rounded-full bg-emerald-500/80" />
            </div>
            <div className="flex items-center gap-2 rounded-md border border-neutral-800 bg-neutral-950 px-3 py-1 text-[11px] font-mono text-neutral-400 w-72 justify-center">
              https://{brand.companyName.toLowerCase().replace(/\s+/g, '')}.com
            </div>
            <div className="text-[11px] font-mono text-neutral-500">LIVE PREVIEW</div>
          </div>

          {/* Website Content */}
          <div
            className="p-8 sm:p-14 space-y-10"
            style={{
              backgroundColor: primaryColor,
              color: lightNeutral,
            }}
          >
            {/* Website Nav */}
            <nav className="flex items-center justify-between border-b border-white/10 pb-6">
              <div className="flex items-center gap-3">
                {brand.logos.primary.imageUrl ? (
                  <img
                    src={brand.logos.primary.imageUrl}
                    alt={brand.companyName}
                    className="h-8 w-8 object-contain rounded"
                  />
                ) : brand.logos.secondaryMark.svgFallback ? (
                  <div
                    className="h-8 w-8"
                    dangerouslySetInnerHTML={{ __html: brand.logos.secondaryMark.svgFallback }}
                  />
                ) : (
                  <div className="h-7 w-7 rounded" style={{ backgroundColor: accentColor }} />
                )}
                <span
                  className="font-bold tracking-tight text-lg"
                  style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
                >
                  {brand.companyName}
                </span>
              </div>

              <div className="hidden sm:flex items-center gap-6 text-xs font-medium opacity-80">
                <span className="hover:opacity-100 cursor-pointer">Platform</span>
                <span className="hover:opacity-100 cursor-pointer">Architecture</span>
                <span className="hover:opacity-100 cursor-pointer">Manifesto</span>
                <span className="hover:opacity-100 cursor-pointer">Documentation</span>
              </div>

              <button
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md transition-transform hover:scale-105"
                style={{
                  backgroundColor: accentColor,
                  color: darkNeutral,
                }}
              >
                Access System
              </button>
            </nav>

            {/* Hero Banner */}
            <div className="max-w-3xl space-y-6 py-6">
              <div className="flex items-center gap-2 text-xs font-mono tracking-wider uppercase opacity-80">
                <span className="h-2 w-2 rounded-full animate-ping" style={{ backgroundColor: accentColor }} />
                <span>Next-Generation Specification · {brand.industry}</span>
              </div>

              <h1
                className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-[1.08]"
                style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
              >
                {brand.applications.websiteHeadline || brand.refinedMission}
              </h1>

              <p
                className="text-sm sm:text-base opacity-85 leading-relaxed max-w-2xl"
                style={{ fontFamily: `'${brand.fonts.body.family}', sans-serif` }}
              >
                {brand.applications.websiteSubhead || brand.elevatorPitch}
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  className="flex items-center gap-2 px-5 py-3 rounded-xl text-xs font-bold shadow-lg transition-transform hover:scale-105"
                  style={{
                    backgroundColor: accentColor,
                    color: darkNeutral,
                  }}
                >
                  <span>Initiate Deployment</span>
                  <ArrowRight className="h-4 w-4" />
                </button>

                <button
                  className="px-5 py-3 rounded-xl text-xs font-semibold border transition-colors hover:bg-white/5"
                  style={{
                    borderColor: 'rgba(255,255,255,0.2)',
                    color: lightNeutral,
                  }}
                >
                  Read Technical Whitepaper
                </button>
              </div>
            </div>

            {/* Feature Cards Showcase */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 pt-6 border-t border-white/10">
              {brand.pillars.map((pillar, idx) => (
                <div
                  key={idx}
                  className="rounded-xl p-5 border backdrop-blur-sm"
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.04)',
                    borderColor: 'rgba(255,255,255,0.1)',
                  }}
                >
                  <span className="font-mono text-xs opacity-60">0{idx + 1}</span>
                  <h4
                    className="font-bold text-sm mt-1"
                    style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
                  >
                    {pillar.title}
                  </h4>
                  <p
                    className="text-xs opacity-75 mt-2 leading-relaxed"
                    style={{ fontFamily: `'${brand.fonts.body.family}', sans-serif` }}
                  >
                    {pillar.statement}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 3. Social Media & Packaging Grid */}
      <section className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* Social Square Post */}
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Share2 className="h-4 w-4 text-emerald-400" />
            <span>03. Social Identity & Launch Post (1:1 Square)</span>
          </h3>

          <div
            className="relative aspect-square w-full rounded-2xl p-8 sm:p-12 flex flex-col justify-between overflow-hidden shadow-xl border"
            style={{
              backgroundColor: primaryColor,
              borderColor: 'rgba(255,255,255,0.1)',
              color: lightNeutral,
            }}
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs opacity-75">{brand.applications.socialHandle}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded border border-white/20">
                LAUNCH NOTE
              </span>
            </div>

            <div className="space-y-4 my-auto">
              {brand.logos.primary.imageUrl ? (
                <img
                  src={brand.logos.primary.imageUrl}
                  alt={brand.companyName}
                  className="h-16 w-16 object-contain rounded-lg"
                />
              ) : brand.logos.badge.svgFallback ? (
                <div
                  className="h-16 w-16"
                  dangerouslySetInnerHTML={{ __html: brand.logos.badge.svgFallback }}
                />
              ) : null}

              <h4
                className="text-2xl sm:text-3xl font-extrabold tracking-tight leading-tight"
                style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
              >
                "{brand.tagline}"
              </h4>

              <p
                className="text-xs opacity-80 leading-relaxed max-w-sm"
                style={{ fontFamily: `'${brand.fonts.body.family}', sans-serif` }}
              >
                {brand.refinedMission}
              </p>
            </div>

            <div className="flex items-center justify-between border-t border-white/10 pt-4 text-[11px] font-mono opacity-75">
              <span>{brand.companyName} © {new Date().getFullYear()}</span>
              <span style={{ color: accentColor }}>BRAND ARCHITECTURE</span>
            </div>
          </div>
        </div>

        {/* Physical Packaging / Hardware Stamp */}
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Box className="h-4 w-4 text-amber-400" />
            <span>04. Hardware Chassis / Packaging Seal</span>
          </h3>

          <div
            className="relative aspect-square w-full rounded-2xl p-8 sm:p-12 flex flex-col justify-between overflow-hidden shadow-xl border"
            style={{
              backgroundColor: darkNeutral,
              borderColor: 'rgba(255,255,255,0.15)',
              color: lightNeutral,
            }}
          >
            <div className="flex items-center justify-between font-mono text-[10px] opacity-60">
              <span>SERIAL: AL-{Math.floor(1000 + Math.random() * 9000)}</span>
              <span>CALIBRE: GRADE-A</span>
            </div>

            <div className="my-auto text-center space-y-4">
              <div className="mx-auto flex justify-center">
                {brand.logos.badge.imageUrl ? (
                  <img
                    src={brand.logos.badge.imageUrl}
                    alt={brand.companyName}
                    className="h-28 w-28 object-contain rounded-full shadow-lg"
                  />
                ) : brand.logos.badge.svgFallback ? (
                  <div
                    className="h-28 w-28"
                    dangerouslySetInnerHTML={{ __html: brand.logos.badge.svgFallback }}
                  />
                ) : (
                  <div className="h-24 w-24 rounded-full border-2 border-dashed border-white/40 mx-auto flex items-center justify-center font-bold">
                    SEAL
                  </div>
                )}
              </div>

              <div>
                <h4
                  className="text-xl font-bold tracking-widest uppercase"
                  style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
                >
                  {brand.companyName}
                </h4>
                <p className="font-mono text-[10px] mt-1 text-sky-400 uppercase tracking-widest">
                  {brand.applications.packagingNote}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between font-mono text-[10px] border-t border-white/10 pt-3 opacity-60">
              <span>SECURITY SEALED</span>
              <span>TAMPER EVIDENT</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
