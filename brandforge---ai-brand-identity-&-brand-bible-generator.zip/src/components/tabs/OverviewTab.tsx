import React from 'react';
import { BrandBible } from '../../types';
import { Target, Flag, Compass, Award, Quote, Sparkles } from 'lucide-react';

interface OverviewTabProps {
  brand: BrandBible;
  onNavigateToTab: (tab: string) => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({ brand, onNavigateToTab }) => {
  return (
    <div className="space-y-10">
      {/* Brand Hero Cover Banner */}
      <section className="relative overflow-hidden rounded-2xl border border-neutral-800 bg-gradient-to-b from-neutral-900 via-neutral-900/90 to-neutral-950 p-8 sm:p-12">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(99,102,241,0.15),transparent_60%)] pointer-events-none" />

        <div className="relative z-10 max-w-4xl space-y-6">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span>Official Identity Specification</span>
            <span aria-hidden="true">·</span>
            <span>{brand.industry}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{new Date(brand.createdAt).getFullYear()}</span>
          </div>

          <div>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white uppercase" style={{ letterSpacing: '-0.02em' }}>
              {brand.companyName}
            </h1>
            <p className="mt-3 text-lg sm:text-2xl font-medium text-neutral-300 italic" style={{ textWrap: 'balance' }}>
              "{brand.tagline}"
            </p>
          </div>

          <div className="rounded-xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-sm">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-indigo-400 mb-2 flex items-center gap-2">
              <Target className="h-4 w-4" /> Refined Mission Statement
            </h2>
            <p className="text-base sm:text-lg text-neutral-100 leading-relaxed font-normal">
              {brand.refinedMission}
            </p>
          </div>

          {/* Quick Palette Bar Preview */}
          <div className="pt-2">
            <div className="text-xs text-neutral-400 mb-2 flex items-center justify-between">
              <span>Primary Brand Palette Spectrum</span>
              <button
                onClick={() => onNavigateToTab('colors')}
                className="text-indigo-400 hover:text-indigo-300 text-xs font-medium underline underline-offset-2"
              >
                Inspect 5-Color System →
              </button>
            </div>
            <div className="grid grid-cols-5 h-8 w-full overflow-hidden rounded-lg border border-neutral-800">
              {brand.palette.map((color, idx) => (
                <div
                  key={idx}
                  className="h-full relative group cursor-pointer"
                  style={{ backgroundColor: color.hex }}
                  onClick={() => onNavigateToTab('colors')}
                  title={`${color.name} (${color.hex}) - ${color.role}`}
                >
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/40 text-[10px] text-white font-mono transition-opacity">
                    {color.hex}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Brand Narrative & Elevator Pitch */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl border border-neutral-800/80 bg-neutral-900/60 p-6 sm:p-8 space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
            <Compass className="h-4 w-4 text-sky-400" />
            <span>Brand Narrative & Ethos</span>
          </div>
          <div className="prose prose-invert max-w-none text-neutral-300 leading-relaxed space-y-4 text-sm sm:text-base">
            {brand.brandNarrative.split('\n\n').map((paragraph, idx) => (
              <p key={idx}>{paragraph}</p>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-neutral-800/80 bg-neutral-900/60 p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
              <Quote className="h-4 w-4 text-emerald-400" />
              <span>The 30-Second Elevator Pitch</span>
            </div>
            <p className="text-sm sm:text-base text-neutral-200 leading-relaxed font-medium">
              "{brand.elevatorPitch}"
            </p>
          </div>

          <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 space-y-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 block">
              Alternate Tagline Explorations
            </span>
            <ul className="space-y-1 text-xs text-neutral-300">
              {brand.alternateTaglines.map((tag, idx) => (
                <li key={idx} className="flex items-center gap-2">
                  <span className="text-indigo-400">·</span>
                  <span>{tag}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* 3 Core Value Pillars */}
      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">01. Strategic Value Pillars</h2>
          <p className="text-xs text-neutral-400 mt-1">
            Foundational commitments governing product execution, identity coherence, and market positioning
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {brand.pillars.map((pillar, idx) => (
            <div
              key={idx}
              className="rounded-xl border border-neutral-800 bg-neutral-900/50 p-6 space-y-3 transition-colors hover:border-neutral-700"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs text-indigo-400">0{idx + 1}</span>
                <Award className="h-4 w-4 text-neutral-500" />
              </div>
              <h3 className="text-base font-semibold text-white tracking-tight">
                {pillar.title}
              </h3>
              <p className="text-xs font-medium text-neutral-200">
                "{pillar.statement}"
              </p>
              <p className="text-xs text-neutral-400 leading-relaxed pt-2 border-t border-neutral-800/80">
                {pillar.rationale}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
