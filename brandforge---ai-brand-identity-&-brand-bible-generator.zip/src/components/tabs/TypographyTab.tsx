import React, { useState, useEffect } from 'react';
import { BrandBible } from '../../types';
import { Type, ExternalLink, Sliders, Copy, Check, Sparkles } from 'lucide-react';

interface TypographyTabProps {
  brand: BrandBible;
}

export const TypographyTab: React.FC<TypographyTabProps> = ({ brand }) => {
  const [headlinePreviewText, setHeadlinePreviewText] = useState(
    brand.fonts.header.sampleHeadline || brand.tagline
  );
  const [bodyPreviewText, setBodyPreviewText] = useState(
    brand.fonts.body.sampleBody || brand.refinedMission
  );
  const [headlineFontSize, setHeadlineFontSize] = useState<number>(44);
  const [copiedLink, setCopiedLink] = useState(false);

  // Dynamically load Google Fonts if not already loaded
  useEffect(() => {
    const fontsToLoad = [brand.fonts.header.family, brand.fonts.body.family];
    if (brand.fonts.accentMono?.family) {
      fontsToLoad.push(brand.fonts.accentMono.family);
    }

    const fontQuery = fontsToLoad
      .map((f) => f.replace(/\s+/g, '+') + ':wght@400;500;600;700;800')
      .join('&family=');

    const linkId = 'dynamic-google-fonts';
    let link = document.getElementById(linkId) as HTMLLinkElement;
    if (!link) {
      link = document.createElement('link');
      link.id = linkId;
      link.rel = 'stylesheet';
      document.head.appendChild(link);
    }
    link.href = `https://fonts.googleapis.com/css2?family=${fontQuery}&display=swap`;
  }, [brand.fonts]);

  const copyEmbedCode = () => {
    const headerName = brand.fonts.header.family;
    const bodyName = brand.fonts.body.family;
    const monoName = brand.fonts.accentMono?.family || 'JetBrains Mono';

    const embedCode = `<!-- Google Fonts Embed -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=${headerName.replace(/\s+/g, '+')}:wght@600;700;800&family=${bodyName.replace(/\s+/g, '+')}:wght@400;500;600&family=${monoName.replace(/\s+/g, '+')}:wght@400;500&display=swap" rel="stylesheet">

/* CSS Custom Rules */
:root {
  --font-display: '${headerName}', ${brand.fonts.header.category};
  --font-body: '${bodyName}', ${brand.fonts.body.category};
  --font-mono: '${monoName}', monospace;
}`;

    navigator.clipboard.writeText(embedCode);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-10">
      {/* Header & Pairing Overview */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-400">
              <Type className="h-4 w-4" />
              <span>Google Font Pairing Architecture</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
              {brand.fonts.header.family} + {brand.fonts.body.family}
            </h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl leading-relaxed">
              Curated under the 2+1 typographic constitution: 1 expressive display face, 1 refined editorial body face, and 1 precision monospaced face.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyEmbedCode}
              className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-1.5 text-xs font-medium text-neutral-200 hover:bg-neutral-800 hover:text-white transition-colors"
            >
              {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5 text-neutral-400" />}
              <span>{copiedLink ? 'Copied Embed Code!' : 'Copy Font Embed'}</span>
            </button>
            <a
              href={`https://fonts.google.com/?query=${encodeURIComponent(brand.fonts.header.family)}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-1.5 text-xs font-medium text-neutral-200 hover:bg-neutral-800 hover:text-white transition-colors"
            >
              <ExternalLink className="h-3.5 w-3.5 text-sky-400" />
              <span>Google Fonts</span>
            </a>
          </div>
        </div>

        {/* Pairing Rationale */}
        <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-400 block mb-1">
            Typographic Rationale & Theory:
          </span>
          <p className="text-xs text-neutral-300 leading-relaxed">
            {brand.fonts.pairingRationale}
          </p>
        </div>
      </section>

      {/* Font Family Cards: Display, Body, Monospace */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Display / Header Font */}
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[11px] uppercase tracking-wider text-indigo-400">
              01. Primary Display Face
            </span>
            <span className="text-[11px] font-mono text-neutral-500 uppercase">
              {brand.fonts.header.category}
            </span>
          </div>

          <div>
            <h3
              className="text-3xl font-bold text-white tracking-tight"
              style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
            >
              {brand.fonts.header.family}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              Recommended weights: {brand.fonts.header.recommendedWeights.join(', ')}
            </p>
          </div>

          <div
            className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 text-neutral-200 text-lg font-bold leading-tight"
            style={{ fontFamily: `'${brand.fonts.header.family}', sans-serif` }}
          >
            ABCDEFGHIJKLM<br />
            NOPQRSTUVWXYZ<br />
            0123456789
          </div>
        </div>

        {/* Body / Prose Font */}
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[11px] uppercase tracking-wider text-sky-400">
              02. Primary Body Prose
            </span>
            <span className="text-[11px] font-mono text-neutral-500 uppercase">
              {brand.fonts.body.category}
            </span>
          </div>

          <div>
            <h3
              className="text-3xl font-semibold text-white tracking-tight"
              style={{ fontFamily: `'${brand.fonts.body.family}', sans-serif` }}
            >
              {brand.fonts.body.family}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              Recommended weights: {brand.fonts.body.recommendedWeights.join(', ')}
            </p>
          </div>

          <div
            className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 text-neutral-300 text-xs leading-relaxed"
            style={{ fontFamily: `'${brand.fonts.body.family}', sans-serif` }}
          >
            The quick brown fox jumps over the lazy dog. Legible at micro scales with balanced x-height and open counters for optimal mobile and desktop clarity.
          </div>
        </div>

        {/* Accent / Monospace Font */}
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[11px] uppercase tracking-wider text-emerald-400">
              03. Monospace / Spec Face
            </span>
            <span className="text-[11px] font-mono text-neutral-500 uppercase">
              monospace
            </span>
          </div>

          <div>
            <h3
              className="text-3xl font-normal text-white tracking-tight font-mono"
              style={{ fontFamily: `'${brand.fonts.accentMono?.family || 'JetBrains Mono'}', monospace` }}
            >
              {brand.fonts.accentMono?.family || 'JetBrains Mono'}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              For code, tabular data, coordinates, and serial metadata
            </p>
          </div>

          <div
            className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 text-neutral-300 font-mono text-xs leading-relaxed tabular-nums"
            style={{ fontFamily: `'${brand.fonts.accentMono?.family || 'JetBrains Mono'}', monospace` }}
          >
            SYS.SCALE: 100%<br />
            LAT: 37.7749° N, LON: 122.4194° W<br />
            HEX: #0A0E17 // TOKEN_ID: 94021
          </div>
        </div>
      </section>

      {/* Live Interactive Specimen Playground */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">
              Interactive Typography Playground
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Type custom copy and adjust scale slider to inspect pairing dynamics in real-time.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-neutral-400">
              Size: {headlineFontSize}px
            </span>
            <input
              type="range"
              min={24}
              max={72}
              value={headlineFontSize}
              onChange={(e) => setHeadlineFontSize(Number(e.target.value))}
              className="w-32 accent-indigo-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Live headline input */}
        <div className="space-y-2">
          <label className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 block">
            Display Headline ({brand.fonts.header.family}):
          </label>
          <input
            type="text"
            value={headlinePreviewText}
            onChange={(e) => setHeadlinePreviewText(e.target.value)}
            className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3 py-2 text-xs text-neutral-200 focus:border-indigo-500 focus:outline-none"
          />
          <div
            className="rounded-xl border border-neutral-800 bg-neutral-950 p-6 text-white leading-none font-bold"
            style={{
              fontFamily: `'${brand.fonts.header.family}', sans-serif`,
              fontSize: `${headlineFontSize}px`,
              letterSpacing: '-0.025em',
            }}
          >
            {headlinePreviewText || 'TYPE YOUR HEADLINE'}
          </div>
        </div>

        {/* Live body input */}
        <div className="space-y-2">
          <label className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 block">
            Body Prose ({brand.fonts.body.family}):
          </label>
          <textarea
            rows={2}
            value={bodyPreviewText}
            onChange={(e) => setBodyPreviewText(e.target.value)}
            className="w-full rounded-lg border border-neutral-700 bg-neutral-950 p-3 text-xs text-neutral-200 focus:border-indigo-500 focus:outline-none"
          />
          <div
            className="rounded-xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-300 text-sm leading-relaxed"
            style={{
              fontFamily: `'${brand.fonts.body.family}', sans-serif`,
              maxWidth: '70ch',
            }}
          >
            {bodyPreviewText}
          </div>
        </div>
      </section>

      {/* Typographic Scale Hierarchy Table */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/40 p-6 sm:p-8 space-y-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">
            Typographic Scale & Layout Token Hierarchy
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Strict mathematical type scale specifying font sizes, line heights, letter-spacing, and roles.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-800 font-mono text-[11px] text-neutral-400">
                <th className="p-3">Level</th>
                <th className="p-3">Family</th>
                <th className="p-3">Scale</th>
                <th className="p-3">Line Height</th>
                <th className="p-3">Tracking</th>
                <th className="p-3">Live Specimen</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-sans">
              {brand.fonts.scale.map((item, idx) => {
                const isDisplay = item.level.includes('H1') || item.level.includes('H2') || item.level.includes('Display');
                const isMono = item.level.includes('Caption') || item.level.includes('Meta') || item.level.includes('Mono');
                const fontFam = isMono
                  ? `'${brand.fonts.accentMono?.family || 'JetBrains Mono'}', monospace`
                  : isDisplay
                  ? `'${brand.fonts.header.family}', sans-serif`
                  : `'${brand.fonts.body.family}', sans-serif`;

                return (
                  <tr key={idx} className="hover:bg-neutral-800/30">
                    <td className="p-3 font-semibold text-white whitespace-nowrap">{item.level}</td>
                    <td className="p-3 text-neutral-400 font-mono text-[11px] whitespace-nowrap">
                      {isMono ? brand.fonts.accentMono?.family || 'JetBrains Mono' : isDisplay ? brand.fonts.header.family : brand.fonts.body.family}
                    </td>
                    <td className="p-3 font-mono text-[11px] text-neutral-300 whitespace-nowrap">{item.size}</td>
                    <td className="p-3 font-mono text-[11px] text-neutral-400">{item.lineHeight}</td>
                    <td className="p-3 font-mono text-[11px] text-neutral-400">{item.letterSpacing}</td>
                    <td className="p-3">
                      <div
                        className="truncate max-w-md text-neutral-200"
                        style={{
                          fontFamily: fontFam,
                          letterSpacing: item.letterSpacing,
                          lineHeight: item.lineHeight,
                          fontWeight: item.weight,
                        }}
                      >
                        {item.sampleText}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
