import React, { useState } from 'react';
import { BrandBible } from '../../types';
import { CheckCircle2, XCircle, Volume2, MessageSquare, Copy, Check } from 'lucide-react';

interface VoiceTabProps {
  brand: BrandBible;
}

export const VoiceTab: React.FC<VoiceTabProps> = ({ brand }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-10">
      {/* Header */}
      <section className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-400">
          <Volume2 className="h-4 w-4" />
          <span>Brand Voice & Verbal Identity</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
          Editorial Philosophy & Messaging Framework
        </h2>
        <p className="text-xs text-neutral-400 max-w-2xl leading-relaxed">
          The verbal architecture that keeps brand copy, customer communications, investor decks, and product UI uncompromisingly consistent across all channels.
        </p>
      </section>

      {/* Tone of Voice DOs & DONTs */}
      <section className="space-y-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">
            Strict Voice Dimensions: Do's & Don'ts
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Operational boundaries for writers, marketers, and executive spokespeople.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {brand.toneGuidelines.map((guideline, idx) => (
            <div
              key={idx}
              className="flex flex-col justify-between rounded-xl border border-neutral-800 bg-neutral-900/50 p-6 space-y-4"
            >
              <div>
                <span className="font-mono text-xs text-indigo-400">0{idx + 1}</span>
                <h4 className="text-base font-bold text-white mt-1">
                  {guideline.attribute}
                </h4>
              </div>

              <div className="space-y-3 text-xs">
                {/* DO */}
                <div className="rounded-lg border border-emerald-900/40 bg-emerald-950/20 p-3.5 space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-emerald-400">
                    <CheckCircle2 className="h-4 w-4 shrink-0" />
                    <span>Always Do:</span>
                  </div>
                  <p className="text-neutral-300 leading-relaxed pl-5">
                    {guideline.doText}
                  </p>
                </div>

                {/* DONT */}
                <div className="rounded-lg border border-rose-900/40 bg-rose-950/20 p-3.5 space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-rose-400">
                    <XCircle className="h-4 w-4 shrink-0" />
                    <span>Never Do:</span>
                  </div>
                  <p className="text-neutral-300 leading-relaxed pl-5">
                    {guideline.dontText}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Taglines & Messaging Toolkit */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Taglines */}
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-white tracking-tight">
              Tagline Ecosystem
            </h4>
            <span className="text-[11px] font-mono text-indigo-400">HERO + ALTERNATES</span>
          </div>

          <div className="rounded-lg border border-indigo-900/50 bg-indigo-950/30 p-4">
            <span className="text-[10px] font-mono uppercase text-indigo-300 block mb-1">
              Primary Hero Tagline
            </span>
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-white italic">
                "{brand.tagline}"
              </span>
              <button
                onClick={() => copyText(brand.tagline, 'primary-tagline')}
                className="text-neutral-400 hover:text-white p-1"
                title="Copy Tagline"
              >
                {copiedKey === 'primary-tagline' ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-xs font-semibold text-neutral-400 block">
              Secondary Campaign Taglines:
            </span>
            {brand.alternateTaglines.map((alt, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between rounded-lg border border-neutral-800 bg-neutral-950 px-3.5 py-2.5 text-xs text-neutral-300"
              >
                <span>"{alt}"</span>
                <button
                  onClick={() => copyText(alt, `alt-${idx}`)}
                  className="text-neutral-500 hover:text-white"
                >
                  {copiedKey === `alt-${idx}` ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Official Boilerplate Copy */}
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white tracking-tight">
                Official Press & Media Boilerplate
              </h4>
              <span className="text-[11px] font-mono text-neutral-500">ABOUT THE COMPANY</span>
            </div>

            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 text-xs text-neutral-300 leading-relaxed font-normal space-y-3">
              <p>
                <strong>About {brand.companyName}:</strong> {brand.refinedMission} Founded to advance {brand.industry.toLowerCase()}, {brand.companyName} combines {brand.pillars.map((p) => p.title.toLowerCase()).join(', ')} to deliver uncompromising performance and design integrity.
              </p>
              <p className="text-neutral-400">
                For more information, visit brand media kit or contact media relations.
              </p>
            </div>
          </div>

          <button
            onClick={() =>
              copyText(
                `About ${brand.companyName}: ${brand.refinedMission} Founded to advance ${brand.industry.toLowerCase()}, ${brand.companyName} combines ${brand.pillars.map((p) => p.title.toLowerCase()).join(', ')} to deliver uncompromising performance and design integrity.`,
                'boilerplate'
              )
            }
            className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-2 text-xs font-semibold text-neutral-200 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            {copiedKey === 'boilerplate' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5 text-neutral-400" />}
            <span>{copiedKey === 'boilerplate' ? 'Copied Boilerplate!' : 'Copy Official Boilerplate'}</span>
          </button>
        </div>
      </section>
    </div>
  );
};
