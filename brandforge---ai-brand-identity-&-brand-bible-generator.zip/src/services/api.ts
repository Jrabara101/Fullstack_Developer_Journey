import { BrandBible, ImageSize, AspectRatio, ChatMessage, ChatModel } from '../types';

export async function generateBrandAPI(params: {
  mission: string;
  companyName?: string;
  industry?: string;
  tone?: string;
  visualStyle?: string;
  targetAudience?: string;
  values?: string;
}): Promise<BrandBible> {
  const res = await fetch('/api/generate-brand', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Server responded with ${res.status}`);
  }

  const data = await res.json();
  return data.brandBible;
}

export async function generateLogoImageAPI(params: {
  prompt: string;
  imageSize: ImageSize;
  aspectRatio: AspectRatio;
  brandName?: string;
  logoType?: 'primary' | 'secondary-mark' | 'badge';
}): Promise<{ imageUrl: string; modelUsed: string }> {
  const res = await fetch('/api/generate-image', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Image generation failed with status ${res.status}`);
  }

  const data = await res.json();
  return {
    imageUrl: data.imageUrl,
    modelUsed: data.modelUsed,
  };
}

export async function sendChatMessageAPI(params: {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  currentBrand: BrandBible | null;
  modelType: ChatModel;
}): Promise<{ reply: string; modelUsed: string }> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Chat failed with status ${res.status}`);
  }

  const data = await res.json();
  return data;
}
