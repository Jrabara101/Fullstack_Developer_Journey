import { BrandBible } from '../types';

export const SAMPLE_BRAND_BIBLE: BrandBible = {
  id: 'brand_sample_aerolith',
  createdAt: new Date().toISOString(),
  companyName: 'AEROLITH DYNAMICS',
  originalMission: 'Pioneering clean hypersonic aerospace propulsion and autonomous orbital transport systems for sustainable deep-space exploration.',
  industry: 'Aerospace & Deep Tech',
  targetAudience: 'Commercial space pioneers, planetary scientists, and defense aerospace consortia',
  visualStyle: 'Monolithic Minimalist & Precision Technical',
  tagline: 'Defying Velocity. Safeguarding Horizon.',
  alternateTaglines: [
    'Silence Above the Stratosphere',
    'Precision Architecture for Orbit',
    'The Velocity of Intent',
  ],
  refinedMission: 'To engineer uncompromising zero-emission atmospheric and orbital propulsion systems, unlocking human scientific presence across celestial horizons with mathematical grace.',
  brandNarrative: 'Born at the intersection of orbital mechanics and quantum fluid dynamics, Aerolith Dynamics rejects both legacy aerospace bureaucracy and speculative fiction. We build monolithic, flight-certified propulsion engines crafted with micron-level tolerances.\n\nOur identity reflects that singular devotion: pure geometric clarity, deliberate negative space, and absolute fidelity to aerodynamic truth.',
  elevatorPitch: 'Aerolith Dynamics manufactures modular, next-generation hypersonic propulsion units that cut orbital deployment cycles by 80% while utilizing zero-carbon propellant architecture.',
  pillars: [
    {
      title: 'Monolithic Precision',
      statement: 'Every curve serves aerodynamic necessity; zero decorative excess.',
      rationale: 'In extreme vacuum and hypersonic shear, ornamentation is failure. We design with mathematical purity.',
    },
    {
      title: 'Orbital Stewardship',
      statement: 'Pioneering space transit with zero kinetic debris and clean combustion.',
      rationale: 'Exploration without preservation is reckless. Our propulsion systems dissolve cleanly upon reentry.',
    },
    {
      title: 'Radical Transparency',
      statement: 'Telemetry, safety tolerances, and engineering data openly verifiable.',
      rationale: 'Deep trust in mission-critical aerospace requires open architectural scrutiny.',
    },
  ],
  palette: [
    {
      role: 'primary',
      name: 'Stratosphere Obsidian',
      hex: '#0A0E17',
      rgb: 'rgb(10, 14, 23)',
      cmyk: 'cmyk(57%, 39%, 0%, 91%)',
      usageNotes: 'Dominant 60% brand canvas. Governs all primary dark backgrounds, hardware anodization, and foundational editorial layouts.',
      suggestedProportion: '60%',
      contrastOnWhite: 17.5,
      contrastOnDark: 1.2,
    },
    {
      role: 'secondary',
      name: 'Celestial Slate',
      hex: '#1E293B',
      rgb: 'rgb(30, 41, 59)',
      cmyk: 'cmyk(49%, 31%, 0%, 77%)',
      usageNotes: 'Supportive 25% architecture. Card surfaces, structural boundaries, and technical data container containers.',
      suggestedProportion: '25%',
      contrastOnWhite: 12.1,
      contrastOnDark: 1.8,
    },
    {
      role: 'accent',
      name: 'Ion Plasma Blue',
      hex: '#38BDF8',
      rgb: 'rgb(56, 189, 248)',
      cmyk: 'cmyk(77%, 24%, 0%, 3%)',
      usageNotes: 'High-impact 10% focal point. Critical ignition telemetry, high-conversion launch CTAs, and active navigation indicators.',
      suggestedProportion: '10%',
      contrastOnWhite: 1.8,
      contrastOnDark: 9.8,
    },
    {
      role: 'neutral-dark',
      name: 'Carbon Matrix',
      hex: '#020617',
      rgb: 'rgb(2, 6, 23)',
      cmyk: 'cmyk(91%, 74%, 0%, 91%)',
      usageNotes: 'Ultra-deep base contrast. Viewport anchors, technical metadata backgrounds, and high-density code surfaces.',
      suggestedProportion: '3%',
      contrastOnWhite: 19.8,
      contrastOnDark: 1.0,
    },
    {
      role: 'neutral-light',
      name: 'Lunar Titanium',
      hex: '#F8FAFC',
      rgb: 'rgb(248, 250, 252)',
      cmyk: 'cmyk(2%, 1%, 0%, 1%)',
      usageNotes: 'Light typography and print stationery ground. High-readability prose on dark surfaces and high-grade print spec sheets.',
      suggestedProportion: '2%',
      contrastOnWhite: 1.05,
      contrastOnDark: 18.9,
    },
  ],
  fonts: {
    header: {
      family: 'Syne',
      role: 'header',
      category: 'display',
      recommendedWeights: ['700', '800'],
      googleFontUrl: 'https://fonts.google.com/specimen/Syne',
      sampleHeadline: 'DEFYING VELOCITY. SAFEGUARDING HORIZON.',
    },
    body: {
      family: 'Plus Jakarta Sans',
      role: 'body',
      category: 'sans-serif',
      recommendedWeights: ['400', '500', '600'],
      googleFontUrl: 'https://fonts.google.com/specimen/Plus+Jakarta+Sans',
      sampleBody: 'Aerolith propulsion architectures eliminate chemical propellant hazards through high-impulse magnetic constriction, delivering unprecedented delta-V for deep solar orbital trajectories.',
    },
    accentMono: {
      family: 'JetBrains Mono',
      role: 'monospace',
      category: 'monospace',
      recommendedWeights: ['400', '500'],
      googleFontUrl: 'https://fonts.google.com/specimen/JetBrains+Mono',
    },
    pairingRationale: 'The brutal geometric tension of Syne captures high-velocity industrial gravity, while Plus Jakarta Sans delivers surgical legibility across mission control displays and executive dossiers.',
    scale: [
      {
        level: 'Display Hero H1',
        size: '56px / 3.5rem',
        lineHeight: '1.02',
        letterSpacing: '-0.03em',
        weight: '800',
        sampleText: 'DEFYING VELOCITY',
      },
      {
        level: 'Section Headline H2',
        size: '36px / 2.25rem',
        lineHeight: '1.15',
        letterSpacing: '-0.025em',
        weight: '700',
        sampleText: 'Hypersonic Propulsion Systems',
      },
      {
        level: 'Subhead H3',
        size: '24px / 1.5rem',
        lineHeight: '1.25',
        letterSpacing: '-0.015em',
        weight: '600',
        sampleText: 'Zero-Emission Atmospheric Trajectory',
      },
      {
        level: 'Lead Paragraph H4',
        size: '18px / 1.125rem',
        lineHeight: '1.4',
        letterSpacing: '-0.01em',
        weight: '500',
        sampleText: 'Modular flight units engineered for multi-stage orbital insertion.',
      },
      {
        level: 'Body Regular',
        size: '15px / 0.9375rem',
        lineHeight: '1.65',
        letterSpacing: '0',
        weight: '400',
        sampleText: 'Propulsion chambers tested under simulated thermosphere conditions, maintaining thermal stability beyond 2,400 Kelvin.',
      },
      {
        level: 'Metadata / Mono',
        size: '12px / 0.75rem',
        lineHeight: '1.4',
        letterSpacing: '0.04em',
        weight: '500',
        sampleText: 'SYS.ORB // DELTA_V: 14.8 KM/S // CERTIFIED',
      },
    ],
  },
  logos: {
    primary: {
      type: 'primary',
      title: 'Monolithic Delta Vector Lockup',
      description: 'An angular aerospace delta chevron intersecting an orbital horizon, representing atmospheric breakout and steady celestial orbit.',
      promptUsed: 'Minimalist aerodynamic chevron logo mark for aerospace company Aerolith Dynamics, sharp geometric angles, crisp vector icon with typography AEROLITH, dark obsidian background, electric cyan accent, graphic design mark by Dieter Rams and Paul Rand style',
      clearSpaceRules: 'Maintain clearance equal to 1.5x the height of the primary delta chevron on all four perimeter margins.',
      minimumSizeRule: 'Digital minimum: 36px height. Print reproduction minimum: 14mm height.',
      svgFallback: `<svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" rx="32" fill="#0A0E17"/>
        <path d="M100 35L155 145H125L100 95L75 145H45L100 35Z" fill="#38BDF8"/>
        <path d="M100 70L130 135H112L100 110L88 135H70L100 70Z" fill="#0A0E17"/>
        <circle cx="100" cy="148" r="5" fill="#38BDF8"/>
        <line x1="45" y1="165" x2="155" y2="165" stroke="#1E293B" stroke-width="2"/>
      </svg>`,
    },
    secondaryMark: {
      type: 'secondary-mark',
      title: 'Orbital Chevron Favicon & Sub-Mark',
      description: 'Simplified standalone delta glyph optimized for 16px to 64px micro-environments, browser tabs, and hardware chassis stamps.',
      promptUsed: 'Micro-icon delta chevron favicon symbol for aerospace tech brand, solid vector glyph, cyan blue on dark slate background, ultra clean vector geometry',
      clearSpaceRules: 'Minimum 25% internal perimeter breathing margin within circular or squircle container boundaries.',
      minimumSizeRule: 'Engineered for crisp 16x16 pixel favicon reproduction without edge aliasing.',
      svgFallback: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="50" cy="50" r="46" fill="#1E293B" stroke="#38BDF8" stroke-width="3"/>
        <path d="M50 24L74 72H60L50 52L40 72H26L50 24Z" fill="#38BDF8"/>
      </svg>`,
    },
    badge: {
      type: 'badge',
      title: 'Chassis Seal & Mission Crest',
      description: 'Circular technical badge for flight hardware certification, titanium propulsion casing stamps, and physical uniform patches.',
      promptUsed: 'Circular aerospace mission patch crest, technical telemetry border, central chevron vector icon, AEROLITH DYNAMICS ORBITAL PROPULSION text around rim',
      clearSpaceRules: 'Maintain 20px perimeter distance from surrounding technical readouts or packaging copy.',
      minimumSizeRule: 'Minimum laser-etched hardware stamp diameter: 22mm.',
      svgFallback: `<svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="100" cy="100" r="90" stroke="#38BDF8" stroke-width="2" stroke-dasharray="4 4"/>
        <circle cx="100" cy="100" r="82" fill="#0A0E17" stroke="#1E293B" stroke-width="3"/>
        <path d="M100 48L136 122H116L100 90L84 122H64L100 48Z" fill="#38BDF8"/>
        <text x="100" y="152" fill="#F8FAFC" font-size="10" font-family="sans-serif" font-weight="700" letter-spacing="3" text-anchor="middle">AEROLITH</text>
        <text x="100" y="165" fill="#38BDF8" font-size="7" font-family="sans-serif" letter-spacing="2" text-anchor="middle">ORBITAL PROPULSION</text>
      </svg>`,
    },
  },
  toneGuidelines: [
    {
      attribute: 'Rigorous & Mathematical',
      doText: 'Speak with empirical certainty and precise aerospace specifications (thrust, delta-V, tolerances).',
      dontText: 'Never use hyperbolic buzzwords like "game-changing magic" or vague promises.',
    },
    {
      attribute: 'Quiet Authority',
      doText: 'State our capabilities with understated confidence, letting flight records lead.',
      dontText: 'Avoid aggressive chest-beating, competitor call-outs, or defensive marketing copy.',
    },
    {
      attribute: 'Stewardship of Horizon',
      doText: 'Reinforce planetary sustainability, zero orbital pollution, and scientific legacy.',
      dontText: 'Never treat space exploration as frivolous novelty or vanity conquest.',
    },
  ],
  applications: {
    websiteHeadline: 'The Architecture of Clean Hypersonic Transit',
    websiteSubhead: 'Precision-manufactured propulsion cores delivering verified orbital breakout without chemical carbon residue.',
    socialHandle: '@aerolithdynamics',
    packagingNote: 'FLIGHT HARDWARE // CLASS-1 ORBITAL SPECIFICATION // SERIAL AL-9042',
  },
};

export const MISSION_PRESETS = [
  {
    name: 'Aerolith Dynamics (Aerospace & Deep Tech)',
    mission: 'Pioneering clean hypersonic aerospace propulsion and autonomous orbital transport systems for sustainable deep-space exploration.',
    industry: 'Aerospace & Deep Tech',
    tone: 'Monolithic, Rigorous & Visionary',
    visualStyle: 'Swiss Precision & Technical Minimalism',
  },
  {
    name: 'Verdant Biome (Regenerative Bio-AgTech)',
    mission: 'Restoring planetary soil microbiology through closed-loop mycelium biopolymers and autonomous agro-forestry sensors.',
    industry: 'Sustainable AgriTech & Climate',
    tone: 'Artisanal, Organic yet Scientific',
    visualStyle: 'Warm Earth Naturalist & Refined Humanist',
  },
  {
    name: 'Kroma Studio (Spatial Architecture & Design)',
    mission: 'Crafting sculptural, light-bathed residential sanctuaries that reconnect urban dwellers with natural diurnal rhythms and tactile stone.',
    industry: 'Architecture & Interior Artistry',
    tone: 'Poetic, Quiet Luxury & Tactile',
    visualStyle: 'Serif Elegance & Monochromatic Restraint',
  },
  {
    name: 'Valence Health (Longevity & Metabolic AI)',
    mission: 'Decoding cellular senescence and metabolic biomarkers into personalized daily micro-interventions for vibrant, extended human vitality.',
    industry: 'BioTech & Preventative Health',
    tone: 'Warm, Empathetic & Clinically Validated',
    visualStyle: 'Clean Clinical Neo-Modern & Radiant',
  },
  {
    name: 'Kinetix Forge (Autonomous Robotics & Edge AI)',
    mission: 'Empowering physical industries with agile bipedal robots and low-latency spatial intelligence for dangerous industrial maintenance.',
    industry: 'Robotics & Industrial Automation',
    tone: 'High-Energy, Robust & Relentless',
    visualStyle: 'Industrial Brutalism & High-Contrast Cybernetics',
  },
];
