export type ImageSize = '1K' | '2K' | '4K';
export type AspectRatio = '1:1' | '4:3' | '16:9' | '3:4';

export interface ColorSwatch {
  role: 'primary' | 'secondary' | 'accent' | 'neutral-dark' | 'neutral-light';
  name: string;
  hex: string;
  rgb: string;
  cmyk: string;
  usageNotes: string;
  suggestedProportion: string; // e.g. "60%", "25%", "10%", "5%"
  contrastOnWhite: number; // e.g. 8.2
  contrastOnDark: number; // e.g. 1.8
}

export interface FontDefinition {
  family: string;
  role: 'header' | 'body' | 'monospace';
  category: 'sans-serif' | 'serif' | 'display' | 'monospace';
  recommendedWeights: string[];
  googleFontUrl: string;
  sampleHeadline?: string;
  sampleBody?: string;
}

export interface TypographicScaleItem {
  level: string; // "Display H1", "H2 Section", "H3 Subhead", "H4 Title", "Body Regular", "Caption/Meta"
  size: string; // e.g. "48px / 3rem"
  lineHeight: string; // e.g. "1.1"
  letterSpacing: string; // e.g. "-0.02em"
  weight: string; // e.g. "700"
  sampleText: string;
}

export interface LogoAsset {
  type: 'primary' | 'secondary-mark' | 'badge' | 'monogram';
  title: string;
  description: string;
  promptUsed: string;
  imageUrl?: string;
  imageSize?: ImageSize;
  svgFallback?: string;
  clearSpaceRules: string;
  minimumSizeRule: string;
  isGenerating?: boolean;
}

export interface ValuePillar {
  title: string;
  statement: string;
  rationale: string;
}

export interface ToneGuideline {
  attribute: string; // e.g. "Authoritative yet Approachable"
  doText: string;
  dontText: string;
}

export interface BrandBible {
  id: string;
  createdAt: string;
  companyName: string;
  originalMission: string;
  industry: string;
  targetAudience: string;
  visualStyle: string;
  tagline: string;
  alternateTaglines: string[];
  refinedMission: string;
  brandNarrative: string;
  elevatorPitch: string;
  pillars: ValuePillar[];
  palette: ColorSwatch[];
  fonts: {
    header: FontDefinition;
    body: FontDefinition;
    accentMono: FontDefinition;
    pairingRationale: string;
    scale: TypographicScaleItem[];
  };
  logos: {
    primary: LogoAsset;
    secondaryMark: LogoAsset;
    badge: LogoAsset;
  };
  toneGuidelines: ToneGuideline[];
  applications: {
    websiteHeadline: string;
    websiteSubhead: string;
    socialHandle: string;
    packagingNote: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  modelUsed?: string;
}

export type ChatModel = 'gemini-3.1-pro-preview' | 'gemini-3.5-flash' | 'gemini-3.1-flash-lite';
