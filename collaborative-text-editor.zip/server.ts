/**
 * Full-Stack Collaborative Document Editor HTTP + WebSocket Server (port 3000)
 */
import express from 'express';
import { createServer as createHttpServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { DocumentSnapshot, MessageType, SocketMessage, Operation, Presence, DocumentHistoryEntry, TextOpComponent } from './src/types';
import { applyOp, transform } from './src/ot';

// User Name & Color Generator Constants
const ANIMAL_NAMES = [
  'Frontend Fox', 'Backend Badger', 'Distributed Owl', 'System Eagle',
  'Algorithmic Seal', 'Syntax Sloth', 'Async Antelope', 'Cyber Beaver',
  'Byte Bear', 'Protocol Penguin', 'Database Dolphin', 'Compiler Cheetah'
];

const CURSOR_COLORS = [
  '#f59e0b', // Amber
  '#10b981', // Emerald
  '#3b82f6', // Blue
  '#ec4899', // Pink
  '#8b5cf6', // Violet
  '#06b6d4', // Cyan
  '#ef4444', // Red
  '#84cc16'  // Lime
];

interface ExtendedWebSocket extends WebSocket {
  isAlive?: boolean;
  userId?: string;
  userName?: string;
  userColor?: string;
  currentDocId?: string | null;
}

// In-Memory Document Store
interface ServerDocument {
  id: string;
  title: string;
  content: string;
  version: number;
  history: DocumentHistoryEntry[]; // Index matches baseVersion
}

const documents: Map<string, ServerDocument> = new Map();

// Populate initial mock documents
const initialDocsList = [
  {
    id: 'doc-1',
    title: '🚀 Project Pitch Outline',
    content: 'Collaborative Editor Implementation Pitch\n=========================================\n\nWelcome to our real-time collaborative workspace! Under the hood, this editor utilizes an Operational Transformation (OT) engine designed to preserve user intentions when concurrent edits collide.\n\n### Core Goals of This Architecture\n- Zero conflict divergence across multiple typing cursors.\n- Maintain low network overhead and handle extreme latency spikes.\n- Synchronize remote cursors, selections, and presence in real-time.\n\nTry opening this application in a side-by-side split screen inside the UI, or in a new browser tab to see standard OT in action!'
  },
  {
    id: 'doc-2',
    title: '🧠 Distributed Systems Architecture',
    content: 'Architecture Notes: Operational Transformation vs CRDTs\n=======================================================\n\n### 1. Operational Transformation (OT)\n- Uses standard indexing (Insert, Delete, Retain).\n- Requires a centralized server to order concurrent operations in a linear log.\n- Client-side maintains a history queue of sent, pending, and unacknowledged operations.\n\n### 2. Conflict-Free Replicated Data Types (CRDTs)\n- Peer-to-peer friendly using unique UUID identifiers per character.\n- Avoids the need for a central sequencer but incurs high memory/state overhead.\n\nThis application uses OT with a Centralized WebSocket sequencer to keep the runtime lightweight.'
  },
  {
    id: 'doc-3',
    title: '🛰️ Real-Time Concurrency Playground',
    content: 'Concurrency Playground\n======================\n\nEdit this document simultaneously to trigger active OT transformation steps! The bottom visual terminal dashboard will capture of each text component transform rule:\n\n1. Insert vs Insert: Resolves concurrent cursors typing at the same character offsite.\n2. Retain vs Delete: Correctly shifts a user\'s cursor when a remote deletion occurred ahead of their text block.\n3. Delete vs Delete: Safeguards against double-deleting existing characters.\n\nTyping here shows live cursor indices with customizable developer names.'
  }
];

initialDocsList.forEach(doc => {
  documents.set(doc.id, {
    id: doc.id,
    title: doc.title,
    content: doc.content,
    version: 0,
    history: []
  });
});

async function startServer() {
  const app = express();
  const PORT = 3000;
  const httpServer = createHttpServer(app);
  const wss = new WebSocketServer({ noServer: true });

  // Handle Upgrade from HTTP to WebSocket
  httpServer.on('upgrade', (request, socket, head) => {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  });

  // Client connection maps
  const activePresences: Map<string, Presence> = new Map();

  // Helper: Broadcast to a specific document room
  function broadcastToRoom(docId: string | null | undefined, message: SocketMessage, excludeUserId?: string) {
    if (!docId) return;
    const data = JSON.stringify(message);
    wss.clients.forEach((client: ExtendedWebSocket) => {
      if (client.readyState === WebSocket.OPEN && client.currentDocId === docId) {
        if (excludeUserId && client.userId === excludeUserId) {
          return;
        }
        client.send(data);
      }
    });
  }

  // Helper: Broadcast system-wide state (like documents list updates)
  function broadcastSystem(message: SocketMessage) {
    const data = JSON.stringify(message);
    wss.clients.forEach((client: ExtendedWebSocket) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }

  // WebSocket Connection Handler
  wss.on('connection', (ws: ExtendedWebSocket) => {
    ws.isAlive = true;

    // Allocate clean randomized User Metadata
    const randomId = Math.random().toString(36).substring(2, 6);
    const userId = `user-${randomId}`;
    const userName = ANIMAL_NAMES[Math.floor(Math.random() * ANIMAL_NAMES.length)] + ` (${randomId.toUpperCase()})`;
    const userColor = CURSOR_COLORS[Math.floor(Math.random() * CURSOR_COLORS.length)];

    ws.userId = userId;
    ws.userName = userName;
    ws.userColor = userColor;
    ws.currentDocId = null;

    // Send initial configuration to this newly connected client
    const docSnapshots: DocumentSnapshot[] = Array.from(documents.values()).map(doc => ({
      id: doc.id,
      title: doc.title,
      content: doc.content,
      version: doc.version
    }));

    const initMsg: SocketMessage = {
      type: 'init',
      payload: {
        userId,
        userName,
        userColor,
        documents: docSnapshots
      }
    };
    ws.send(JSON.stringify(initMsg));

    // Handle WebSocket Pong Response
    ws.on('pong', () => {
      ws.isAlive = true;
    });

    // Handle Incoming WebSocket Messages
    ws.on('message', (rawData: string) => {
      try {
        const message: SocketMessage = JSON.parse(rawData);

        switch (message.type) {
          case 'heartbeat': {
            ws.send(JSON.stringify({ type: 'heartbeat', payload: 'pong' }));
            break;
          }

          case 'join_room': {
            const { docId } = message.payload;
            const oldDocId = ws.currentDocId;

            // Leave old room
            if (oldDocId) {
              const presenceId = `${ws.userId}_${oldDocId}`;
              activePresences.delete(presenceId);
              broadcastToRoom(oldDocId, {
                type: 'user_left',
                payload: { userId: ws.userId, docId: oldDocId }
              }, ws.userId);
            }

            // Join new room
            ws.currentDocId = docId;
            const doc = documents.get(docId);

            if (doc) {
              // Register new presence structure
              const presenceId = `${ws.userId}_${docId}`;
              const newPresence: Presence = {
                userId: ws.userId!,
                name: ws.userName!,
                color: ws.userColor!,
                cursorIndex: null,
                selectionEnd: null,
                isTyping: false,
                lastActive: Date.now()
              };
              activePresences.set(presenceId, newPresence);

              // Gather existing presences in this new room
              const roomPresences: Presence[] = [];
              activePresences.forEach((p, key) => {
                const [pUser, pDoc] = key.split('_');
                if (pDoc === docId && pUser !== ws.userId) {
                  roomPresences.push(p);
                }
              });

              // Send join confirmation & existing room presence info
              ws.send(JSON.stringify({
                type: 'join_room',
                payload: {
                  docId,
                  title: doc.title,
                  content: doc.content,
                  version: doc.version,
                  activePresences: roomPresences
                }
              }));

              // Notify existing occupants that we joined
              broadcastToRoom(docId, {
                type: 'user_joined',
                payload: {
                  userId: ws.userId!,
                  name: ws.userName!,
                  color: ws.userColor!
                }
              }, ws.userId);
            }
            break;
          }

          case 'edit': {
            // AUTHORITATIVE OT SYNCHRONIZATION LOOP
            const clientOp: Operation = message.payload;
            const doc = documents.get(clientOp.docId);

            if (!doc) {
              console.error(`Document not found: ${clientOp.docId}`);
              return;
            }

            let finalOp = clientOp;
            const originalBase = clientOp.baseVersion;
            const currentServerVersion = doc.version;

            let logDesc = '';

            if (originalBase === currentServerVersion) {
              // Happy path: no concurrent changes.
              logDesc = `Direct apply of version ${originalBase}`;
            } else if (originalBase < currentServerVersion) {
              // COLLISION ROUTE: concurrent edits happened.
              // We must transform the client's operation against the historical edits
              // that happened on the server since its original base version.
              logDesc = `Stale branch version ${originalBase}. SERVER resolves collision against ${currentServerVersion}. Transformed through ${currentServerVersion - originalBase} items.`;
              
              for (let v = originalBase; v < currentServerVersion; v++) {
                const histEntry = doc.history[v];
                if (histEntry) {
                  // Transform client's operation against this historical operations step
                  const [transformedClient, _] = transform(finalOp, histEntry.operation);
                  finalOp = transformedClient;
                }
              }
            } else {
              // Future versions should not occur on standard linear clients.
              console.warn(`Future version error: client sent version ${originalBase}, server is at ${currentServerVersion}`);
              return;
            }

            // Apply transformed operation to authoritative in-memory snapshot
            const prevContent = doc.content;
            doc.content = applyOp(doc.content, finalOp);

            // Record this transformed operation in server history (index = doc.version)
            doc.history.push({
              version: currentServerVersion,
              operation: finalOp,
              userId: ws.userId!
            });

            // Increment version
            doc.version = currentServerVersion + 1;

            // Broadcast the resolved/transformed operation to everyone else in the document room
            broadcastToRoom(doc.id, {
              type: 'edit',
              payload: {
                operation: finalOp,
                version: doc.version,
                content: doc.content, // Provide fall-back sync snap
                logInfo: {
                  desc: logDesc,
                  originalBase,
                  transformedVersion: doc.version
                }
              }
            }, ws.userId);

            // Ack to sender they are synchronized at the new version
            ws.send(JSON.stringify({
              type: 'edit_ack',
              payload: {
                docId: doc.id,
                baseVersion: originalBase,
                appliedVersion: doc.version,
                content: doc.content,
                logInfo: {
                  desc: logDesc,
                  originalBase,
                  appliedVersion: doc.version
                }
              }
            }));
            break;
          }

          case 'presence': {
            // Live cursor and range trackers
            const { docId, cursorIndex, selectionEnd, isTyping } = message.payload;
            const presenceId = `${ws.userId}_${docId}`;
            const pres = activePresences.get(presenceId);

            if (pres) {
              pres.cursorIndex = cursorIndex;
              pres.selectionEnd = selectionEnd;
              pres.isTyping = isTyping;
              pres.lastActive = Date.now();

              // Broadcast update
              broadcastToRoom(docId, {
                type: 'presence',
                payload: pres
              }, ws.userId);
            }
            break;
          }

          default:
            console.warn(`Unhandled socket event type: ${message.type}`);
        }
      } catch (err) {
        console.error('Socket message parse error', err);
      }
    });

    // Handle WebSocket Client Disconnect
    ws.on('close', () => {
      ws.isAlive = false;
      const oldDocId = ws.currentDocId;

      if (oldDocId) {
        const presenceId = `${ws.userId}_${oldDocId}`;
        activePresences.delete(presenceId);

        broadcastToRoom(oldDocId, {
          type: 'user_left',
          payload: { userId: ws.userId, docId: oldDocId }
        }, ws.userId);
      }
    });
  });

  // Keep-alive heartbeat sweep (runs every 15 seconds)
  const heartbeatInterval = setInterval(() => {
    wss.clients.forEach((client: ExtendedWebSocket) => {
      if (client.isAlive === false) {
        client.terminate();
        return;
      }
      client.isAlive = false;
      client.ping();
    });
  }, 15000);

  wss.on('close', () => {
    clearInterval(heartbeatInterval);
  });

  // RESTful Fallbacks to support creation and deletion of documents
  app.use(express.json());

  app.get('/api/docs', (req, res) => {
    const list = Array.from(documents.values()).map(doc => ({
      id: doc.id,
      title: doc.title,
      version: doc.version,
      snippet: doc.content.substring(0, 100) + (doc.content.length > 100 ? '...' : '')
    }));
    res.json(list);
  });

  app.post('/api/docs/create', (req, res) => {
    const { title, content } = req.body;
    const id = `doc-${Date.now()}`;
    const newDoc: ServerDocument = {
      id,
      title: title || `📄 Untitled Collaborative Note`,
      content: content || '',
      version: 0,
      history: []
    };
    documents.set(id, newDoc);

    const snapshotMessage: SocketMessage = {
      type: 'doc_created',
      payload: {
        id,
        title: newDoc.title,
        content: newDoc.content,
        version: 0
      }
    };
    broadcastSystem(snapshotMessage);

    res.json({ success: true, docId: id });
  });

  app.post('/api/docs/delete', (req, res) => {
    const { docId } = req.body;
    if (documents.has(docId)) {
      documents.delete(docId);
      broadcastSystem({
        type: 'doc_deleted',
        payload: { docId }
      });
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'Document not found' });
    }
  });

  // --- Vite Dev Server Middleware or Static Static Hosting ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Bind server to port 3000
  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Collaborative Sequencer HTTP + WS running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start collaborative backend server:', err);
});
