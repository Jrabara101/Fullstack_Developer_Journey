/**
 * Collaborative Real-Time Workspace Dashboard (React)
 */
import { useEffect, useState, startTransition, FormEvent, MouseEvent } from 'react';
import { EditorFrame } from './components/EditorFrame';
import {
  FileText,
  Plus,
  Compass,
  GitFork,
  ArrowRightLeft,
  LayoutGrid,
  Sparkles,
  Info,
  GitPullRequest,
  CheckCircle2,
  Trash2
} from 'lucide-react';

interface ServerDocListItem {
  id: string;
  title: string;
  version: number;
  snippet: string;
}

export default function App() {
  const [docsList, setDocsList] = useState<ServerDocListItem[]>([]);
  const [selectedDocId, setSelectedDocId] = useState<string>('doc-1');
  const [viewMode, setViewMode] = useState<'split' | 'single'>('split');
  
  // Title for new doc creation
  const [newTitle, setNewTitle] = useState<string>('');
  const [isCreating, setIsCreating] = useState<boolean>(false);

  // Load document list from backend REST endpoints on mount and websocket updates
  const fetchDocs = async () => {
    try {
      const res = await fetch('/api/docs');
      if (res.ok) {
        const data = await res.json();
        setDocsList(data || []);
      }
    } catch (err) {
      console.error('Error fetching document directory:', err);
    }
  };

  useEffect(() => {
    fetchDocs();
    // Poll index periodically for fallback sync updates
    const timer = setInterval(fetchDocs, 4000);
    return () => clearInterval(timer);
  }, []);

  const handleCreateDocument = async (e: FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    
    setIsCreating(true);
    try {
      const res = await fetch('/api/docs/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: `📄 ${newTitle.trim()}`,
          content: 'Title\n=====\n\nType some text here collaboratively! Open split view or duplicate this browser tab to observe synchronized text states.'
        })
      });

      if (res.ok) {
        const data = await res.json();
        await fetchDocs();
        setNewTitle('');
        startTransition(() => {
          setSelectedDocId(data.docId);
        });
      }
    } catch (err) {
      console.error('Failed to create new document snapshot:', err);
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteDocument = async (docId: string, e: MouseEvent) => {
    e.stopPropagation(); // Avoid triggering document selection
    if (!confirm('Are you sure you want to delete this document from the sequencer database?')) return;

    try {
      const res = await fetch('/api/docs/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ docId })
      });

      if (res.ok) {
        await fetchDocs();
        if (selectedDocId === docId) {
          setSelectedDocId('doc-1'); // Fallback trigger
        }
      }
    } catch (err) {
      console.error('Failed to remove document snapshot:', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB] flex flex-col font-sans select-text text-gray-800">
      
      {/* Interactive Top-bar Banner with clean stats */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 px-6 py-3.5 shadow-sm shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center shrink-0 shadow-xs">
              <div className="w-4 h-4 border-2 border-white rounded-sm"></div>
            </div>
            <div className="flex flex-col">
              <h1 className="text-sm font-semibold text-slate-800">Collaborative Document Hub</h1>
              <p className="text-[10px] text-slate-500 font-medium tracking-tight uppercase leading-none mt-0.5">Distributed Sync Service • Live Engine</p>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap items-center gap-3 self-end md:self-auto text-xs">
            <div className="flex items-center gap-0.5 border border-slate-200 bg-slate-50/50 p-1.5 rounded-lg font-mono text-[10px]">
              <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse mr-1"></div>
              <span className="text-slate-500 font-medium">WebSocket Stack:</span>
              <span className="font-bold text-slate-800 uppercase ml-1">ONLINE</span>
            </div>

            <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                onClick={() => setViewMode('split')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all text-[11px] font-semibold ${
                  viewMode === 'split'
                    ? 'bg-white shadow-xs text-indigo-700'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <ArrowRightLeft className="h-3 w-3" />
                <span>Simulate Editor Split</span>
              </button>
              <button
                onClick={() => setViewMode('single')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all text-[11px] font-semibold ${
                  viewMode === 'single'
                    ? 'bg-white shadow-xs text-indigo-700'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <LayoutGrid className="h-3 w-3" />
                <span>Wide Layout</span>
              </button>
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                alert('Workspace URL copied to clipboard! Share it with a colleague to test simultaneous edits.');
              }}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-semibold rounded shadow-sm transition-colors cursor-pointer select-none"
            >
              Share Workspace
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace Frame container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Sidebar Document Picker & Creators */}
        <section className="lg:col-span-3 flex flex-col gap-6">
          
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs">
            <h2 className="text-[10px] font-display font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5 select-none">
              <Compass className="h-4 w-4 text-slate-400" />
              <span>Project Roadmap</span>
            </h2>

            {/* Document Collection List */}
            <div className="space-y-1 max-h-[220px] overflow-y-auto pr-1">
              {docsList.map((doc) => (
                <button
                  key={doc.id}
                  onClick={() => setSelectedDocId(doc.id)}
                  className={`w-full text-left p-2 rounded-lg text-xs leading-snug flex items-center justify-between gap-1.5 transition-all group ${
                    selectedDocId === doc.id
                      ? 'bg-indigo-50 border border-indigo-100 text-indigo-700 font-bold'
                      : 'bg-white text-slate-600 border border-transparent hover:bg-slate-50'
                  }`}
                >
                  <div className="truncate flex-1 flex items-center gap-2">
                    <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      selectedDocId === doc.id ? 'bg-indigo-600 text-white shadow-xs' : 'border border-slate-300'
                    }`}>
                      {selectedDocId === doc.id && (
                        <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                    <div className="truncate font-semibold">{doc.title}</div>
                  </div>
                  
                  {/* Delete Button (Keep Project files clean) */}
                  {doc.id !== 'doc-1' && doc.id !== 'doc-2' && doc.id !== 'doc-3' && (
                    <button
                      onClick={(e) => handleDeleteDocument(doc.id, e)}
                      className={`text-rose-500 p-1 rounded hover:bg-rose-50/50 opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100 ${
                        selectedDocId === doc.id ? 'text-rose-600' : ''
                      }`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Create Snapshot Frame */}
          <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs">
            <h3 className="text-[10px] font-display font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5 select-none">
              <Plus className="h-4 w-4 text-slate-400" />
              <span>Add Document</span>
            </h3>

            <form onSubmit={handleCreateDocument} className="space-y-3">
              <input
                type="text"
                placeholder="E.g., System Design Overview"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-100 transition-all placeholder-slate-400 bg-white"
                disabled={isCreating}
              />
              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-2 rounded shadow-sm transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 select-none cursor-pointer"
                disabled={isCreating || !newTitle.trim()}
              >
                <Plus className="h-3.5 w-3.5" />
                <span>{isCreating ? 'Provisioning...' : 'Add Slate'}</span>
              </button>
            </form>
          </div>

          {/* Quick Reference Box */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl text-[11px] text-slate-600 leading-relaxed space-y-2">
            <h4 className="font-semibold flex items-center gap-1.5 text-slate-800">
              <Info className="h-4 w-4 text-indigo-600" />
              <span>Multiplayer Setup</span>
            </h4>
            <p>
              To observe real-time cursor indicators and Operational Transformation resolving simultaneous edits across users:
            </p>
            <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono text-[9px]">
              <li>Use the split screen editor below to type in both sides.</li>
              <li>Or click the <strong className="text-slate-700">Share Workspace</strong> button above to invite peers!</li>
            </ul>
          </div>

        </section>

        {/* Right Active Workspaces Frame panels */}
        <section className={`lg:col-span-9 flex flex-col gap-6`}>
          
          <div className="bg-white border border-slate-200 p-3 rounded-xl shadow-xs flex items-center gap-2">
            <FileText className="h-4 w-4 text-indigo-600" />
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-tight">Active Room:</span>
            <span className="text-xs font-bold text-slate-800">
              {docsList.find(d => d.id === selectedDocId)?.title || 'Loading active document...'}
            </span>
          </div>

          {viewMode === 'split' ? (
            /* Split View Simulator */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="text-[10px] uppercase font-mono tracking-wider px-2 text-slate-400 font-semibold">
                  🖥️ CLIENT FRAME A (Latency Simulator: 0ms)
                </div>
                <EditorFrame
                  key={`${selectedDocId}-A`}
                  docId={selectedDocId}
                  clientLabel="Client-A"
                  initialDelayMs={0}
                />
              </div>
              <div className="space-y-2">
                <div className="text-[10px] uppercase font-mono tracking-wider px-2 text-slate-400 font-semibold">
                  🖥️ CLIENT FRAME B (Simulated Peer)
                </div>
                <EditorFrame
                  key={`${selectedDocId}-B`}
                  docId={selectedDocId}
                  clientLabel="Client-B"
                  initialDelayMs={200}
                />
              </div>
            </div>
          ) : (
            /* Single Wide Inspector View */
            <div className="w-full space-y-2">
              <div className="text-[10px] uppercase font-mono px-2 text-slate-400 font-semibold">
                🖥️ FULL WORKSPACE VIEW (Client-A)
              </div>
              <EditorFrame
                key={`${selectedDocId}-wide`}
                docId={selectedDocId}
                clientLabel="Client-A"
                initialDelayMs={0}
              />
            </div>
          )}

          {/* Core Architectural Deep Dive Lesson */}
          <div className="bg-slate-900 text-white rounded-2xl p-5 md:p-6 mt-2 space-y-4 shadow-xl border border-slate-800 leading-relaxed text-xs">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
              <GitFork className="h-5 w-5 text-indigo-400" />
              <h3 className="text-sm font-display font-bold tracking-tight text-white">
                Architectural Breakdown: The Distributed Consensus Conflict Challenge
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-sans">
              
              <div className="space-y-2">
                <h4 className="text-zinc-200 font-semibold flex items-center gap-1.5 font-display text-[11px]">
                  <ArrowRightLeft className="h-4 w-4 text-zinc-400" />
                  <span>The Naive Conflict Failure</span>
                </h4>
                <p className="text-zinc-400 text-[11px]">
                  In client-server apps, sending the full document payload on every keystroke causes race override failures.
                </p>
                <div className="bg-black/30 p-2 rounded text-[10px] text-rose-300 font-mono space-y-1">
                  <strong>Conflict Case:</strong>
                  <div>1. Initial: "CAT"</div>
                  <div>2. User A inserts 'S' at end: "CATS"</div>
                  <div>3. User B concurrent key 'R' at start: "RCAT"</div>
                  <div>4. Laggy A overwrites B: "CATS" (R lost!)</div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-zinc-200 font-semibold flex items-center gap-1.5 font-display text-[11px]">
                  <GitPullRequest className="h-4 w-4 text-indigo-400" />
                  <span>Mathematical OT Solution</span>
                </h4>
                <p className="text-zinc-400 text-[11px]">
                  Operational Transformation translates index points rather than texts. Two edits $A$ and $B$ are transformed such that:
                </p>
                <div className="bg-indigo-950/40 border border-indigo-900 p-2 rounded text-[10px] text-indigo-200 font-mono leading-normal">
                  $S$ = "CAT"<br />
                  $A$ = Insert(3, 'S')<br />
                  $B$ = Insert(0, 'R')<br />
                  $A'$ = transform($A$, $B$) = Insert(4, 'S')<br />
                  $B'$ = transform($B$, $A$) = Insert(0, 'R')<br />
                  <strong>Result = "RCATS" (Preserved!)</strong>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-zinc-200 font-semibold flex items-center gap-1.5 font-display text-[11px]">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <span>Resilient Offline Buffer</span>
                </h4>
                <p className="text-zinc-400 text-[11px]">
                  When a client turns offline, edits are buffered locally. On reconnect, the cached ops are updated to the server's newest sequenced version.
                </p>
                <p className="text-zinc-400 text-[11px]">
                  Cursors of other users are synchronized via custom typing hooks, avoiding cursor drift or selection misalignment inside standard textareas.
                </p>
              </div>

            </div>
          </div>

        </section>

      </main>

    </div>
  );
}
