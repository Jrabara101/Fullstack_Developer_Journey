/**
 * Collaborative roster listing online users, typing indicators, and connection metrics
 */
import { Presence } from '../types';
import { Wifi, Keyboard } from 'lucide-react';

interface ActiveUsersProps {
  connectionStatus: 'connecting' | 'connected' | 'disconnected';
  latency: number;
  activePresences: Presence[];
  typingUsers: string[];
  clientLabel: string;
}

export function ActiveUsers({
  connectionStatus,
  latency,
  activePresences,
  typingUsers,
  clientLabel
}: ActiveUsersProps) {
  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected': return 'bg-emerald-500';
      case 'connecting': return 'bg-amber-500';
      case 'disconnected': return 'bg-rose-500';
    }
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-4 py-2.5 px-4 border-b border-slate-200 bg-slate-50/70 text-xs text-slate-600 rounded-t-xl select-none">
      {/* Network Diagnostics */}
      <div className="flex items-center gap-2">
        <span className="relative flex h-2 w-2">
          {connectionStatus === 'connected' && (
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          )}
          <span className={`relative inline-flex rounded-full h-2 w-2 ${getStatusColor()}`}></span>
        </span>
        <span className="font-semibold text-slate-800">{clientLabel} Socket:</span>
        <span className="capitalize font-medium">{connectionStatus}</span>
        {connectionStatus === 'connected' && (
          <div className="flex items-center gap-1 ml-2 text-slate-400 font-mono text-[10px]">
            <Wifi className="h-3 w-3 text-indigo-500" />
            <span>{latency}ms RTT</span>
          </div>
        )}
      </div>

      {/* Online Roster */}
      <div className="flex items-center gap-3">
        <div className="flex items-center -space-x-1.5 overflow-hidden">
          {activePresences.map((pres) => (
            <div
              key={pres.userId}
              title={`${pres.name} (At index: ${pres.cursorIndex ?? 'unknown'})`}
              className="relative inline-block h-6 w-6 rounded-full ring-2 ring-white flex items-center justify-center text-white text-[9px] font-bold shadow-xs select-none"
              style={{ backgroundColor: pres.color }}
            >
              {pres.name.substring(0, 2).toUpperCase()}
              {pres.isTyping && (
                <span className="absolute -bottom-0.5 -right-0.5 block h-2 w-2 rounded-full bg-emerald-400 ring-1 ring-white animate-bounce" />
              )}
            </div>
          ))}

          {activePresences.length === 0 && (
            <span className="text-slate-400 italic text-[10px]">No other peers online</span>
          )}
        </div>

        {/* Typing Bubble */}
        {typingUsers.length > 0 && (
          <div className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full text-[10px] font-medium animate-pulse border border-emerald-100">
            <Keyboard className="h-3 w-3 inline" />
            <span>{typingUsers.join(', ')} typing...</span>
          </div>
        )}
      </div>
    </div>
  );
}
