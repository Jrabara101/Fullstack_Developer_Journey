/**
 * Isolated Collaborative Editor Panel Component
 */
import { SyntheticEvent } from 'react';
import { useCollaborativeEditor } from './useCollaborativeEditor';
import { ActiveUsers } from './ActiveUsers';
import { Play, Pause, Terminal, Sliders, FileText, User } from 'lucide-react';

interface EditorFrameProps {
  docId: string;
  clientLabel: string;
  initialDelayMs: number;
  key?: string;
}

export function EditorFrame({ docId, clientLabel, initialDelayMs }: EditorFrameProps) {
  const {
    connectionStatus,
    latency,
    docTitle,
    docContent,
    docVersion,
    userId,
    userName,
    userColor,
    activePresences,
    typingUsers,
    logs,
    networkDelay,
    setNetworkDelay,
    isOffline,
    toggleOffline,
    handleLocalChange,
    sendPresence,
    textareaRef
  } = useCollaborativeEditor(docId, clientLabel, initialDelayMs);

  // Monitor text selections and cursor movements
  const onCursorUpdate = (e: SyntheticEvent<HTMLTextAreaElement>) => {
    const tar = e.currentTarget;
    sendPresence(tar.selectionStart, tar.selectionEnd, false);
  };

  return (
    <div className="flex flex-col h-[650px] bg-white border border-slate-200 shadow-sm rounded-xl overflow-hidden transition-all hover:border-slate-300">
      
      {/* 1. Header with Active Collaborative Roster */}
      <ActiveUsers
        connectionStatus={connectionStatus}
        latency={latency}
        activePresences={activePresences}
        typingUsers={typingUsers}
        clientLabel={clientLabel}
      />

      {/* 2. Controls Panel: Simulated Delay / offline states */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-4 py-2 border-b border-slate-200 bg-slate-50 text-[11px] text-slate-500">
        <div className="flex items-center gap-2">
          <User className="h-3 w-3" style={{ color: userColor || '#ddd' }} />
          <span className="font-medium">User:</span>
          <span className="font-bold text-slate-700" style={{ color: userColor }}>
            {userName || 'Acquiring alias...'}
          </span>
          <span className="bg-slate-200/80 text-slate-600 rounded px-1.5 py-0.5 text-[9px] font-mono select-none uppercase font-bold">
            v{docVersion}
          </span>
        </div>

        {/* Network Jitter Sliders and Buffer Toggles */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Sliders className="h-3 w-3 text-slate-400" />
            <span className="font-medium">Latency Delay:</span>
            <input
              type="range"
              min="0"
              max="1500"
              step="100"
              value={networkDelay}
              onChange={(e) => setNetworkDelay(Number(e.target.value))}
              className="accent-indigo-600 w-20 h-1 bg-slate-200 rounded-lg cursor-pointer"
            />
            <span className="font-mono w-10 text-right font-medium text-slate-700">{networkDelay}ms</span>
          </div>

          <button
            onClick={toggleOffline}
            className={`flex items-center gap-1.5 px-3 py-1 rounded shadow-xs text-[10px] font-bold tracking-wide uppercase transition-colors cursor-pointer ${
              isOffline
                ? 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            {isOffline ? <Play className="h-2.5 w-2.5" /> : <Pause className="h-2.5 w-2.5" />}
            <span>{isOffline ? 'Sync Online' : 'Go Offline'}</span>
          </button>
        </div>
      </div>

      {/* 3. Main Editor splitting text-area vs logs/visual pointers */}
      <div className="flex-1 grid grid-rows-2 h-1/2">
        
        {/* Top: Textarea with absolute custom colored borders */}
        <div className="relative border-b border-slate-200 flex flex-col p-2.5 bg-[#FCFDFE]">
          <div className="text-[10px] uppercase font-mono px-1.5 text-slate-400 flex items-center gap-1 select-none py-1 font-bold tracking-wider">
            <FileText className="h-3.5 w-3.5 text-indigo-500" />
            <span>Workspace Editor Text</span>
          </div>
          
          <div className="relative flex-1 overflow-hidden rounded bg-white border border-slate-200 focus-within:border-indigo-400 focus-within:ring-1 focus-within:ring-indigo-100 transition-all">
            <textarea
              ref={textareaRef}
              value={docContent}
              onChange={(e) => handleLocalChange(e.target.value, e.target.selectionStart)}
              onSelect={onCursorUpdate}
              onKeyUp={onCursorUpdate}
              onClick={onCursorUpdate}
              onFocus={onCursorUpdate}
              placeholder="Begin typing collaborative contents here..."
              className="absolute inset-0 w-full h-full p-3.5 font-mono text-xs text-slate-800 bg-transparent resize-none focus:outline-none placeholder-slate-400 select-text overflow-y-auto leading-relaxed"
              disabled={connectionStatus === 'disconnected' && !isOffline}
            />
          </div>
        </div>

        {/* Bottom Split: Operational Logs console console and cursors */}
        <div className="grid grid-cols-1 md:grid-cols-2 text-[11px] bg-slate-950 border-t border-slate-800 text-slate-300">
          
          {/* Diagnostic operational transformation logs block */}
          <div className="border-r border-slate-900 flex flex-col p-3 overflow-hidden">
            <div className="flex items-center gap-1.5 text-[9px] font-mono uppercase tracking-wider text-slate-500 mb-2 select-none font-bold">
              <Terminal className="h-3 w-3 text-indigo-400" />
              <span>Diagnostic OT Sequencer Protocol ({clientLabel})</span>
            </div>
            
            <div className="flex-1 overflow-y-auto font-mono space-y-1.5 pr-1 select-text scrollbar-thin">
              {logs.map((log) => (
                <div key={log.id} className="text-[10px] border-b border-slate-900 pb-1 flex items-start gap-1">
                  <span className="text-slate-600 shrink-0">{log.time}</span>
                  {log.badge && (
                    <span className={`px-1 rounded text-[8px] font-bold tracking-tight shrink-0 ${
                      log.type === 'success' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/30' :
                      log.type === 'error' ? 'bg-rose-950 text-rose-400 border border-rose-900/30' :
                      log.type === 'warning' ? 'bg-amber-950 text-amber-400 border border-amber-900/30' :
                      'bg-slate-900 text-slate-400'
                    }`}>
                      {log.badge}
                    </span>
                  )}
                  <span className={`text-left leading-relaxed ${
                    log.type === 'success' ? 'text-emerald-400' :
                    log.type === 'error' ? 'text-rose-400' :
                    log.type === 'warning' ? 'text-amber-400' :
                    'text-slate-300'
                  }`}>
                    {log.message}
                  </span>
                </div>
              ))}
              {logs.length === 0 && (
                <div className="text-slate-600 italic select-none text-center py-4 text-[10px]">
                  Awaiting operational events...
                </div>
              )}
            </div>
          </div>

          {/* Peer Cursor indices indicator block */}
          <div className="flex flex-col p-3 overflow-hidden bg-slate-950/80">
            <div className="flex items-center gap-1.5 text-[9px] font-mono uppercase tracking-wider text-slate-500 mb-2 select-none font-bold">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Active Peer Cursor Tracking</span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1 select-none text-[10px]">
              {/* Showcase list of remote active positions */}
              {activePresences.map((pres) => (
                <div
                  key={pres.userId}
                  className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800/80 transition-all"
                >
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: pres.color }} />
                    <span className="text-slate-200 font-semibold">{pres.name}</span>
                  </div>
                  <div className="text-slate-400 font-mono text-[9px]">
                    Index Position: <span className="text-white font-bold">{pres.cursorIndex !== null ? pres.cursorIndex : 'N/A'}</span>
                  </div>
                </div>
              ))}

              {activePresences.length === 0 && (
                <div className="text-center py-6 text-slate-600 italic text-[10px]">
                  No concurrent peers to map. Open another tab or use the split screen to test concurrent cursors!
                </div>
              )}

              {/* Character pointer simulator matrix summary */}
              {docContent && (
                <div className="mt-2 pt-2 border-t border-slate-900 text-[9px] text-slate-500">
                  <span className="font-bold text-slate-400 block mb-1 tracking-wider uppercase">REAL-TIME INDEX MAPPING:</span>
                  <div className="flex flex-wrap gap-0.5 max-h-16 overflow-y-auto font-mono text-[8px] bg-black/50 p-2 rounded border border-slate-905 scrollbar-thin">
                    {docContent.split('').slice(0, 150).map((char, index) => {
                      // Check which peer is on this character index
                      const pointingPeer = activePresences.find(p => p.cursorIndex === index);
                      const charText = char === '\n' ? '↵' : char;
                      
                      return (
                        <span
                          key={index}
                          title={`Index ${index}: "${char}"`}
                          className={`inline-block px-0.5 rounded transition-all ${
                            pointingPeer ? 'text-black font-extrabold animate-pulse' : 'text-slate-500 hover:bg-slate-900 hover:text-white'
                          }`}
                          style={pointingPeer ? { backgroundColor: pointingPeer.color } : {}}
                        >
                          {charText}
                        </span>
                      );
                    })}
                    {docContent.length > 150 && <span className="text-slate-600">...</span>}
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
