/**
 * Client-Side Collaborative Socket Controller and OT State Machine
 */
import { useEffect, useRef, useState, useCallback } from 'react';
import { SocketMessage, Operation, Presence, DocumentSnapshot } from '../types';
import { applyOp, transform, makeInsertOp, makeDeleteOp, transformCursor } from '../ot';

export interface LogEntry {
  id: string;
  time: string;
  type: 'info' | 'error' | 'success' | 'warning';
  message: string;
  badge?: string;
}

export function useCollaborativeEditor(docId: string, clientLabel: string, initialDelayMs: number = 0) {
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
  const [latency, setLatency] = useState<number>(0);
  const [docContent, setDocContent] = useState<string>('');
  const [docVersion, setDocVersion] = useState<number>(0);
  const [docTitle, setDocTitle] = useState<string>('');
  const [activePresences, setActivePresences] = useState<Presence[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  
  // Local identity (populated on 'init')
  const [userId, setUserId] = useState<string>('');
  const [userName, setUserName] = useState<string>('');
  const [userColor, setUserColor] = useState<string>('');

  // Diagnostic Logs
  const [logs, setLogs] = useState<LogEntry[]>([]);

  // Simulation controls
  const [networkDelay, setNetworkDelay] = useState<number>(initialDelayMs);
  const [isOffline, setIsOffline] = useState<boolean>(false);

  // References to preserve state across effects
  const socketRef = useRef<WebSocket | null>(null);
  const bufferedOpsRef = useRef<Operation[]>([]); // Ops made while offline
  const contentRef = useRef<string>('');
  const versionRef = useRef<number>(0);
  const isTypingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isSelfTypingRef = useRef<boolean>(false);

  // Synchronization references for local vs remote cursor correction
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const selectionRef = useRef<{ start: number; end: number }>({ start: 0, end: 0 });

  // Sync state refs to prevent closed-over stale React state
  contentRef.current = docContent;
  versionRef.current = docVersion;

  const addLog = useCallback((type: LogEntry['type'], message: string, badge?: string) => {
    const entry: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      time: new Date().toLocaleTimeString(),
      type,
      message,
      badge
    };
    setLogs(prev => [entry, ...prev].slice(0, 40));
  }, []);

  // Compute operational changes on key downs / character edits
  const handleLocalChange = useCallback((newText: string, selectionStart: number) => {
    const oldText = contentRef.current;
    if (oldText === newText) return;

    selectionRef.current = { start: selectionStart, end: selectionStart };

    // Simple diff calculator
    let prefixLen = 0;
    while (prefixLen < oldText.length && prefixLen < newText.length && oldText[prefixLen] === newText[prefixLen]) {
      prefixLen++;
    }

    let suffixLen = 0;
    while (
      suffixLen < oldText.length - prefixLen &&
      suffixLen < newText.length - prefixLen &&
      oldText[oldText.length - 1 - suffixLen] === newText[newText.length - 1 - suffixLen]
    ) {
      suffixLen++;
    }

    const removedCount = oldText.length - prefixLen - suffixLen;
    const addedText = newText.substring(prefixLen, newText.length - suffixLen);

    let op: Operation | null = null;
    const baseVer = versionRef.current;

    if (removedCount > 0 && addedText.length > 0) {
      // Combined delete and insert (e.g. text replacements or paste-overs)
      // To preserve OT linear sequence, we execute standard delete first, then insert
      const delOp = makeDeleteOp(oldText.length, prefixLen, removedCount, userId, docId, baseVer);
      const intermediateText = applyOp(oldText, delOp);
      const insOp = makeInsertOp(intermediateText.length, prefixLen, addedText, userId, docId, baseVer);
      
      // Let's chain them into a combined components list
      const combinedComponents = [...delOp.components];
      // Since delete shortened the text, we reconcile the insert components position offset
      // Standard layout:
      op = {
        components: [
          ...(prefixLen > 0 ? [{ type: 'retain' as const, count: prefixLen }] : []),
          { type: 'delete' as const, count: removedCount },
          { type: 'insert' as const, value: addedText },
          ...(oldText.length > prefixLen + removedCount ? [{ type: 'retain' as const, count: oldText.length - (prefixLen + removedCount) }] : [])
        ],
        userId,
        docId,
        baseVersion: baseVer
      };
    } else if (addedText.length > 0) {
      op = makeInsertOp(oldText.length, prefixLen, addedText, userId, docId, baseVer);
    } else if (removedCount > 0) {
      op = makeDeleteOp(oldText.length, prefixLen, removedCount, userId, docId, baseVer);
    }

    // Set optimistic client state instantly
    setDocContent(newText);

    if (op) {
      const opDesc = op.components.map(c => `${c.type === 'retain' ? 'Retain' : c.type === 'insert' ? 'Insert' : 'Delete'}(${c.count || `'${c.value}'`})`).join(', ');

      if (isOffline) {
        // Enqueue offline buffer
        bufferedOpsRef.current.push(op);
        addLog('warning', `Offline mode active: Buffered operation locally`, `BUFFER`);
      } else {
        // Broadcast over WebSockets (with simulated latency filter if specified)
        const sendOp = op;
        const sendEditMsg = () => {
          if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && !isOffline) {
            const msg: SocketMessage = {
              type: 'edit',
              payload: sendOp
            };
            socketRef.current.send(JSON.stringify(msg));
            addLog('info', `Sent op: ${opDesc} (Base Version: ${sendOp.baseVersion})`, `SEND`);
          }
        };

        if (networkDelay > 0) {
          setTimeout(sendEditMsg, networkDelay);
        } else {
          sendEditMsg();
        }
      }

      // Update typing status over network
      if (!isSelfTypingRef.current) {
        isSelfTypingRef.current = true;
        sendPresence(selectionStart, selectionStart, true);
      }

      if (isTypingTimeoutRef.current) clearTimeout(isTypingTimeoutRef.current);
      isTypingTimeoutRef.current = setTimeout(() => {
        isSelfTypingRef.current = false;
        sendPresence(selectionStart, selectionStart, false);
      }, 1500);
    }
  }, [userId, docId, isOffline, networkDelay, addLog]);

  // Send mouse selections/focus indicators
  const sendPresence = useCallback((cursorIndex: number | null, selectionEnd: number | null, isTyping: boolean) => {
    if (isOffline || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;

    const payload = {
      docId,
      cursorIndex,
      selectionEnd,
      isTyping
    };

    const msg: SocketMessage = {
      type: 'presence',
      payload
    };

    if (networkDelay > 0) {
      setTimeout(() => {
        if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && !isOffline) {
          socketRef.current.send(JSON.stringify(msg));
        }
      }, networkDelay);
    } else {
      socketRef.current.send(JSON.stringify(msg));
    }
  }, [docId, isOffline, networkDelay]);

  // Handle manual offline toggle
  const toggleOffline = useCallback(() => {
    setIsOffline(prev => {
      const nextOffline = !prev;
      if (nextOffline) {
        addLog('warning', `${clientLabel} entered Offline mode. Edits will be isolated and buffered.`, `CONN`);
      } else {
        addLog('success', `${clientLabel} re-established container sync. Operational Transformation resolving buffered list...`, `CONN`);
        
        // RECONCILE AND FLUSH BUFFERED OFFLINE OPERATIONS
        if (bufferedOpsRef.current.length > 0) {
          addLog('info', `Flushing ${bufferedOpsRef.current.length} buffered offline operations to server database sequence.`, `SYNC`);
          
          bufferedOpsRef.current.forEach((op) => {
            // Update operation's target base version so that server-side historical transformation runs correctly
            op.baseVersion = versionRef.current;
            
            if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
              socketRef.current.send(JSON.stringify({
                type: 'edit',
                payload: op
              }));
            }
          });
          bufferedOpsRef.current = [];
        }
      }
      return nextOffline;
    });
  }, [clientLabel, addLog]);

  // Initialize and maintain WebSocket connection
  useEffect(() => {
    setConnectionStatus('connecting');
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socketUrl = `${protocol}//${window.location.host}`;
    
    addLog('info', `Connecting to collaborative sequencer on ${socketUrl}...`, `WS`);
    const ws = new WebSocket(socketUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      setConnectionStatus('connected');
      addLog('success', `WebSocket socket connected under node room space`, `WS`);

      // Automatically join document room
      ws.send(JSON.stringify({
        type: 'join_room',
        payload: { docId }
      }));
    };

    ws.onmessage = (event) => {
      if (isOffline) return; // Drop incoming messages when simulating offline state

      try {
        const message: SocketMessage = JSON.parse(event.data);

        switch (message.type) {
          case 'init': {
            const { userId: sUserId, userName: sUserName, userColor: sUserColor } = message.payload;
            setUserId(sUserId);
            setUserName(`${sUserName} (${clientLabel})`);
            setUserColor(sUserColor);
            addLog('success', `Assigned ID ${sUserId} | Alias: ${sUserName}`, `AUTH`);
            break;
          }

          case 'join_room': {
            const { title, content, version, activePresences: initialPresences } = message.payload;
            setDocTitle(title);
            setDocContent(content);
            setDocVersion(version);
            setActivePresences(initialPresences);
            addLog('success', `Entered document workspace (v${version})`, `ROOM`);
            break;
          }

          case 'edit': {
            // REMOTE OPERATION ARRIVED (User B or someone else modified text)
            const { operation, version, logInfo } = message.payload;
            const remoteOpDesc = (operation as Operation).components.map(c => 
              `${c.type === 'retain' ? 'Retain' : c.type === 'insert' ? 'Insert' : 'Delete'}(${c.count || `'${c.value}'`})`
            ).join(', ');

            addLog('warning', `Remote edit received: ${remoteOpDesc} (New version: v${version})`, `RECV`);
            if (logInfo?.desc) {
              addLog('info', `Server log: ${logInfo.desc}`, `OT-SEQ`);
            }

            // Capture previous local cursor variables
            const textarea = textareaRef.current;
            const localCursor = textarea ? textarea.selectionStart : contentRef.current.length;

            // Update local content using OT
            const prevContent = contentRef.current;
            const updatedContent = applyOp(prevContent, operation);
            
            setDocContent(updatedContent);
            setDocVersion(version);

            // Correct local cursor position so insertion/deletion doesn't cause focus jumps!
            if (textarea) {
              const newCursor = transformCursor(localCursor, operation, false);
              setTimeout(() => {
                textarea.focus();
                textarea.setSelectionRange(newCursor, newCursor);
              }, 0);
            }
            break;
          }

          case 'edit_ack': {
            // ACK RECEIVED FROM THE SERVER
            const { appliedVersion, logInfo } = message.payload;
            setDocVersion(appliedVersion);
            addLog('success', `Server acknowledged document edit. Sequenced at v${appliedVersion}`, `ACK`);
            break;
          }

          case 'presence': {
            const remotePresence: Presence = message.payload;
            setActivePresences(prev => {
              const cleaned = prev.filter(p => p.userId !== remotePresence.userId);
              return [...cleaned, remotePresence];
            });

            // Update active typing list
            setTypingUsers(prev => {
              if (remotePresence.isTyping) {
                if (!prev.includes(remotePresence.name)) {
                  return [...prev, remotePresence.name];
                }
              } else {
                return prev.filter(name => name !== remotePresence.name);
              }
              return prev;
            });
            break;
          }

          case 'user_joined': {
            const { userId: jId, name: jName, color: jColor } = message.payload;
            setActivePresences(prev => [
              ...prev.filter(p => p.userId !== jId),
              {
                userId: jId,
                name: jName,
                color: jColor,
                cursorIndex: null,
                selectionEnd: null,
                isTyping: false,
                lastActive: Date.now()
              }
            ]);
            addLog('info', `Collaborator entered: ${jName}`, `PRES`);
            break;
          }

          case 'user_left': {
            const { userId: lId } = message.payload;
            setActivePresences(prev => {
              const departing = prev.find(p => p.userId === lId);
              if (departing) {
                addLog('warning', `Collaborator left: ${departing.name}`, `PRES`);
                setTypingUsers(t => t.filter(name => name !== departing.name));
              }
              return prev.filter(p => p.userId !== lId);
            });
            break;
          }
        }
      } catch (err) {
        addLog('error', `Failed to parse socket message: ${err}`, `ERROR`);
      }
    };

    ws.onerror = (err) => {
      addLog('error', `WebSocket transport error! Connecting closed.`, `ERROR`);
    };

    ws.onclose = () => {
      setConnectionStatus('disconnected');
      addLog('error', `Connection severed, socket closed.`, `CONN`);
    };

    // Keepalive pinging
    const pingInterval = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN && !isOffline) {
        const start = Date.now();
        ws.send(JSON.stringify({ type: 'heartbeat', payload: 'ping' }));
        // Simple mock ping latency estimator
        setLatency(Math.floor(Math.random() * 8) + 12); // Average RTT estimation
      }
    }, 10000);

    return () => {
      clearInterval(pingInterval);
      ws.close();
      if (isTypingTimeoutRef.current) clearTimeout(isTypingTimeoutRef.current);
    };
  }, [docId, clientLabel, isOffline, addLog]);

  return {
    connectionStatus,
    latency,
    docTitle,
    docContent,
    docVersion,
    userId,
    userName,
    userColor,
    activePresences,
    typingUsers,
    logs,
    networkDelay,
    setNetworkDelay,
    isOffline,
    toggleOffline,
    handleLocalChange,
    sendPresence,
    textareaRef
  };
}
