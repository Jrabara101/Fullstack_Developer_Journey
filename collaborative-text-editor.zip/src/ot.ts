/**
 * Operational Transformation (OT) Engine for Collaborative Text Editing
 */
import { Operation, TextOpComponent } from './types';

/**
 * Apply an operation to a string, returning the modified string.
 */
export function applyOp(str: string, op: Operation): string {
  let result = '';
  let index = 0;

  for (const comp of op.components) {
    if (comp.type === 'retain') {
      const count = comp.count || 0;
      result += str.substring(index, Math.min(index + count, str.length));
      index += count;
    } else if (comp.type === 'insert') {
      result += comp.value || '';
    } else if (comp.type === 'delete') {
      index += comp.count || 0;
    }
  }

  // Append any remaining text if the operation finished early (robustness fallback)
  if (index < str.length) {
    result += str.substring(index);
  }

  return result;
}

/**
 * Transform two operations that were created concurrently on the same base version.
 * Returns [opAPrime, opBPrime] such that:
 * apply(apply(S, opA), opBPrime) === apply(apply(S, opB), opAPrime)
 */
export function transform(opA: Operation, opB: Operation): [Operation, Operation] {
  const compsA = [...opA.components];
  const compsB = [...opB.components];

  const primeA: TextOpComponent[] = [];
  const primeB: TextOpComponent[] = [];

  let iA = 0;
  let iB = 0;

  // Active components being processed (with remaining counts/lengths)
  let curA: TextOpComponent | null = null;
  let curB: TextOpComponent | null = null;

  while (iA < compsA.length || curA || iB < compsB.length || curB) {
    // Fetch next components if current ones are exhausted
    if (!curA && iA < compsA.length) {
      curA = { ...compsA[iA++] };
    }
    if (!curB && iB < compsB.length) {
      curB = { ...compsB[iB++] };
    }

    // Case 1: Insert on A
    if (curA && curA.type === 'insert') {
      // Tie breaker: If both are concurrent inserts at the same position,
      // we decide order by userId. Let's say smaller userId goes first.
      if (curB && curB.type === 'insert' && opA.userId < opB.userId) {
        // opA goes first. primeA gets user A's insert.
        // primeB gets a retain of user A's insert length, then user B's insert.
        primeA.push({ type: 'insert', value: curA.value });
        primeA.push({ type: 'retain', count: curA.value?.length || 0 }); // wait, retain after?
        // Actually, let's keep it simpler. Let's process A first.
        primeA.push({ type: 'insert', value: curA.value });
        primeB.push({ type: 'retain', count: curA.value?.length || 0 });
        curA = null;
      } else if (curB && curB.type === 'insert') {
        // opB goes first
        primeB.push({ type: 'insert', value: curB.value });
        primeA.push({ type: 'retain', count: curB.value?.length || 0 });
        curB = null;
      } else {
        // No conflict insert on B. opA's insert is preserved.
        primeA.push({ type: 'insert', value: curA.value });
        primeB.push({ type: 'retain', count: curA.value?.length || 0 });
        curA = null;
      }
      continue;
    }

    // Case 2: Insert on B
    if (curB && curB.type === 'insert') {
      primeB.push({ type: 'insert', value: curB.value });
      primeA.push({ type: 'retain', count: curB.value?.length || 0 });
      curB = null;
      continue;
    }

    // Now both curA and curB are either retain or delete.
    if (!curA || !curB) {
      // One side is exhausted. Any remaining retain/delete on the other side
      // is matched against empty (implied retains), so we just ignore them or push them.
      // But in clean matching, if one is empty, it means the document was shorter or modified.
      if (curA) {
        if (curA.type === 'delete') {
          primeA.push({ type: 'delete', count: curA.count });
        } else {
          primeA.push({ type: 'retain', count: curA.count });
        }
        curA = null;
      }
      if (curB) {
        if (curB.type === 'delete') {
          primeB.push({ type: 'delete', count: curB.count });
        } else {
          primeB.push({ type: 'retain', count: curB.count });
        }
        curB = null;
      }
      continue;
    }

    // Mini transformation of current components
    const lenA = curA.count || 0;
    const lenB = curB.count || 0;
    const minLen = Math.min(lenA, lenB);

    if (curA.type === 'retain' && curB.type === 'retain') {
      primeA.push({ type: 'retain', count: minLen });
      primeB.push({ type: 'retain', count: minLen });
    } else if (curA.type === 'delete' && curB.type === 'delete') {
      // Both deleted the same text. No retain or delete is added to primes.
    } else if (curA.type === 'retain' && curB.type === 'delete') {
      primeB.push({ type: 'delete', count: minLen });
    } else if (curA.type === 'delete' && curB.type === 'retain') {
      primeA.push({ type: 'delete', count: minLen });
    }

    // Decrease the counts of the processed components
    if (lenA > minLen) {
      curA.count = lenA - minLen;
    } else {
      curA = null;
    }

    if (lenB > minLen) {
      curB.count = lenB - minLen;
    } else {
      curB = null;
    }
  }

  // Clean elements by merging consecutive similar elements (e.g. adjacent retains)
  return [
    {
      components: squashComponents(primeA),
      userId: opA.userId,
      docId: opA.docId,
      baseVersion: opA.baseVersion + 1,
    },
    {
      components: squashComponents(primeB),
      userId: opB.userId,
      docId: opB.docId,
      baseVersion: opB.baseVersion + 1,
    }
  ];
}

/**
 * Merge adjacent components of the same type for cleanliness.
 */
function squashComponents(comps: TextOpComponent[]): TextOpComponent[] {
  const result: TextOpComponent[] = [];
  for (const comp of comps) {
    if (comp.count === 0 && comp.type !== 'insert') continue;
    if (comp.type === 'insert' && !comp.value) continue;

    const last = result[result.length - 1];
    if (last && last.type === comp.type) {
      if (last.type === 'retain' || last.type === 'delete') {
        last.count = (last.count || 0) + (comp.count || 0);
      } else if (last.type === 'insert') {
        last.value = (last.value || '') + (comp.value || '');
      }
    } else {
      result.push({ ...comp });
    }
  }
  return result;
}

/**
 * Creates an Operation representing a single insert at cursor index.
 */
export function makeInsertOp(
  docLength: number,
  index: number,
  text: string,
  userId: string,
  docId: string,
  baseVersion: number
): Operation {
  const components: TextOpComponent[] = [];
  if (index > 0) {
    components.push({ type: 'retain', count: index });
  }
  components.push({ type: 'insert', value: text });
  if (docLength > index) {
    components.push({ type: 'retain', count: docLength - index });
  }

  return { components, userId, docId, baseVersion };
}

/**
 * Creates an Operation representing a single delete at cursor index.
 */
export function makeDeleteOp(
  docLength: number,
  index: number,
  count: number,
  userId: string,
  docId: string,
  baseVersion: number
): Operation {
  const components: TextOpComponent[] = [];
  if (index > 0) {
    components.push({ type: 'retain', count: index });
  }
  components.push({ type: 'delete', count });
  if (docLength > index + count) {
    components.push({ type: 'retain', count: docLength - (index + count) });
  }

  return { components, userId, docId, baseVersion };
}

/**
 * Translates a cursor position based on an incoming concurrent operation.
 * Keeps cursor indices stable when remote edits happen!
 */
export function transformCursor(cursor: number, op: Operation, isCurrentUser: boolean): number {
  let newCursor = cursor;
  let textIndex = 0;

  for (const comp of op.components) {
    if (comp.type === 'retain') {
      textIndex += comp.count || 0;
    } else if (comp.type === 'insert') {
      const insertLen = comp.value?.length || 0;
      if (textIndex < cursor || (textIndex === cursor && isCurrentUser)) {
        newCursor += insertLen;
      }
      textIndex += insertLen;
    } else if (comp.type === 'delete') {
      const deleteLen = comp.count || 0;
      if (textIndex < cursor) {
        newCursor -= Math.min(deleteLen, cursor - textIndex);
      }
      textIndex += deleteLen;
    }
  }

  return Math.max(0, newCursor);
}
