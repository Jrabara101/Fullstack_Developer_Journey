/**
 * Types for the Collaborative Text Editor (OT Protocol)
 */

export interface User {
  id: string;
  name: string;
  color: string;
}

export interface Presence {
  userId: string;
  name: string;
  color: string;
  cursorIndex: number | null;
  selectionEnd: number | null;
  isTyping: boolean;
  lastActive: number;
}

export interface DocumentSnapshot {
  id: string;
  title: string;
  content: string;
  version: number;
}

export type OpType = 'insert' | 'delete' | 'retain';

export interface TextOpComponent {
  type: OpType;
  value?: string; // String to insert
  count?: number; // Number of characters to retain or delete
}

/**
 * An Operation is an array of text operation components.
 * For example: [Retain(5), Insert("hello"), Delete(3)]
 */
export interface Operation {
  components: TextOpComponent[];
  userId: string;
  docId: string;
  baseVersion: number;
}

export interface DocumentHistoryEntry {
  version: number;
  operation: Operation;
  userId: string;
}

// WebSocket message formats
export type MessageType =
  | 'init'          // Server -> Client: initial documents and user assignments
  | 'join_room'     // Client -> Server: join room of docId
  | 'doc_created'   // Server -> Client: new doc added
  | 'doc_deleted'   // Server -> Client: doc deleted
  | 'edit'          // Client <-> Server: text delta changes
  | 'edit_ack'      // Server -> Client: acknowledge client edit and return status
  | 'presence'      // Client <-> Server: broadcast cursor, selection, typing state
  | 'user_joined'   // Server -> Client: user entered
  | 'user_left'     // Server -> Client: user exited
  | 'heartbeat';    // Client <-> Server: ping-pong keepalive

export interface SocketMessage {
  type: MessageType;
  payload: any;
}
