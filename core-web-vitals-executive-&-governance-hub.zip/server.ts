import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Lazy Gemini client initialization
  let aiClient: GoogleGenAI | null = null;
  function getGeminiClient(): GoogleGenAI | null {
    if (!aiClient && process.env.GEMINI_API_KEY) {
      aiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
    return aiClient;
  }

  // Health endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // AI CWV Advisor Endpoint
  app.post('/api/gemini/advisor', async (req, res) => {
    try {
      const { scenario, scripts, metrics, mode } = req.body;
      const ai = getGeminiClient();

      if (!ai) {
        return res.status(503).json({
          error: 'Gemini API key is not configured in the environment. Using governance rule engine analysis instead.',
        });
      }

      let prompt = '';
      if (mode === 'script-audit') {
        prompt = `You are a Principal Web Performance Architect and Financial Governance Auditor.
Analyze the following third-party script setup:
${JSON.stringify(scripts, null, 2)}

Provide a strict, high-impact tag governance breakdown in JSON format with:
1. "executiveSummary": 2 sentences explaining financial conversion risk and LCP/INP impact.
2. "tagTiers": array of items with { "name": string, "tier": "Tier 1: Essential" | "Tier 2: Defer Interaction" | "Tier 3: Facade/On-Demand" | "Deprecated/Remove", "action": string, "savingsMs": number, "conversionRisk": string }.
3. "governancePolicy": 3 bullet rules for marketing/engineering contracts.
4. "estimatedLcpRecoveryMs": total estimated LCP recovery.
5. "estimatedInpRecoveryMs": total estimated INP recovery.`;
      } else if (mode === 'executive-brief') {
        prompt = `You are the VP of Engineering presenting to the Chief Financial Officer and Chief Product Officer.
Current CWV Performance:
${JSON.stringify(metrics, null, 2)}
Scenario Context:
${scenario || 'E-commerce Checkout & Mobile Funnel'}

Write an executive-ready CWV Financial & Business Governance memo.
Include:
1. "financialHeadline": Bold, dollar-quantified headline regarding latency tax and conversion loss.
2. "cognitiveImpact": How users feel during LCP, INP, and CLS states (Trust, Flow, Stability).
3. "recommendations": 3 prioritized cross-functional investments (Engineering, Marketing Tag Governance, Design SLA).
4. "boardroomQuote": A 1-sentence punchy takeaway for the CEO.`;
      } else {
        prompt = `You are a Core Web Vitals expert. Provide performance optimization advice for: ${JSON.stringify(req.body)}`;
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        },
      });

      const text = response.text || '{}';
      res.json({ result: JSON.parse(text) });
    } catch (err: any) {
      console.error('Error generating AI audit response:', err);
      res.status(500).json({ error: err.message || 'Failed to generate audit response' });
    }
  });

  // Vite development vs production serving
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Core Web Vitals Hub server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
