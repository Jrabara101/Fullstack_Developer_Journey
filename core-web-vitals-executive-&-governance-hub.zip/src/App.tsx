import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { EconomicsCalculator } from './components/EconomicsCalculator';
import { CognitiveExperiences } from './components/CognitiveExperiences';
import { TagGovernance } from './components/TagGovernance';
import { LabVsField } from './components/LabVsField';
import { OrgCultureSLAs } from './components/OrgCultureSLAs';
import { AiAdvisorModal } from './components/AiAdvisorModal';
import {
  PRESET_PROFILES,
  INITIAL_THIRD_PARTY_SCRIPTS,
} from './data/cwvData';
import {
  PresetProfile,
  FinancialModelInputs,
  ThirdPartyScript,
} from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('economics');
  const [selectedPreset, setSelectedPreset] = useState<PresetProfile>(PRESET_PROFILES[0]);
  const [scripts, setScripts] = useState<ThirdPartyScript[]>(INITIAL_THIRD_PARTY_SCRIPTS);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);

  // Financial & Performance State
  const [financialInputs, setFinancialInputs] = useState<FinancialModelInputs>({
    monthlyTraffic: selectedPreset.monthlyTraffic,
    mobileSharePercent: selectedPreset.mobileShare,
    baselineConversionRate: selectedPreset.baselineCr,
    averageOrderValue: selectedPreset.aov,
    currentLcpMs: selectedPreset.currentLcp,
    targetLcpMs: selectedPreset.targetLcp,
    currentInpMs: selectedPreset.currentInp,
    targetInpMs: selectedPreset.targetInp,
    currentCls: selectedPreset.currentCls,
    targetCls: selectedPreset.targetCls,
    conversionDropPer100ms: 1.8,
  });

  // When preset changes, update financial inputs
  const handleSelectPreset = (preset: PresetProfile) => {
    setSelectedPreset(preset);
    setFinancialInputs((prev) => ({
      ...prev,
      monthlyTraffic: preset.monthlyTraffic,
      mobileSharePercent: preset.mobileShare,
      baselineConversionRate: preset.baselineCr,
      averageOrderValue: preset.aov,
      currentLcpMs: preset.currentLcp,
      targetLcpMs: preset.targetLcp,
      currentInpMs: preset.currentInp,
      targetInpMs: preset.targetInp,
      currentCls: preset.currentCls,
      targetCls: preset.targetCls,
    }));
  };

  // Compute composite CWV status
  const overallStatus = {
    lcp: financialInputs.targetLcpMs,
    inp: financialInputs.targetInpMs,
    cls: financialInputs.targetCls,
    isPassing:
      financialInputs.targetLcpMs <= 2.5 &&
      financialInputs.targetInpMs <= 200 &&
      financialInputs.targetCls <= 0.1,
  };

  // Trigger celebratory confetti when passing state is first achieved
  const [hasCelebrated, setHasCelebrated] = useState<boolean>(false);
  useEffect(() => {
    if (overallStatus.isPassing && !hasCelebrated) {
      confetti({
        particleCount: 50,
        spread: 50,
        origin: { y: 0.8 },
      });
      setHasCelebrated(true);
    } else if (!overallStatus.isPassing && hasCelebrated) {
      setHasCelebrated(false);
    }
  }, [overallStatus.isPassing, hasCelebrated]);

  // Calculate annual revenue lift for executive memo
  const speedDeltaMs =
    (financialInputs.currentLcpMs - financialInputs.targetLcpMs) * 1000 * 0.65 +
    (financialInputs.currentInpMs - financialInputs.targetInpMs) * 0.35;
  const hundredMsUnits = speedDeltaMs / 100;
  const liftFactor = (hundredMsUnits * financialInputs.conversionDropPer100ms) / 100;
  const newCr =
    (financialInputs.baselineConversionRate / 100) *
    (1 + Math.max(-0.5, Math.min(0.7, liftFactor)));
  const monthlyLift =
    (financialInputs.monthlyTraffic * newCr -
      financialInputs.monthlyTraffic * (financialInputs.baselineConversionRate / 100)) *
    financialInputs.averageOrderValue;
  const annualRevenueLift = monthlyLift * 12;

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] flex flex-col font-sans selection:bg-[#141414] selection:text-white">
      {/* Header with Navigation & Live CWV Score */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedPreset={selectedPreset}
        onSelectPreset={handleSelectPreset}
        onOpenAiAdvisor={() => setIsAiModalOpen(true)}
        overallStatus={overallStatus}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'economics' && (
          <EconomicsCalculator
            inputs={financialInputs}
            setInputs={setFinancialInputs}
          />
        )}

        {activeTab === 'cognitive' && <CognitiveExperiences />}

        {activeTab === 'tag-governance' && (
          <TagGovernance
            scripts={scripts}
            setScripts={setScripts}
            onOpenAiAudit={() => setIsAiModalOpen(true)}
          />
        )}

        {activeTab === 'lab-vs-field' && <LabVsField />}

        {activeTab === 'culture-sla' && (
          <OrgCultureSLAs
            onOpenAiAdvisor={() => setIsAiModalOpen(true)}
            lcp={overallStatus.lcp}
            inp={overallStatus.inp}
            cls={overallStatus.cls}
            annualRevenueLift={annualRevenueLift}
          />
        )}
      </main>

      {/* Footer & Industry Citations */}
      <footer className="border-t border-[#141414] bg-white py-4 mt-8 text-xs text-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#141414]">
              CWV_EXECUTIVE_GOVERNANCE_HUB
            </span>
            <span>•</span>
            <span className="font-serif-italic font-normal">Google Chrome CrUX &amp; Financial Governance Framework</span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-gray-500">
            <span>Deloitte Speed Study</span>
            <span>/</span>
            <span>Amazon 100ms Latency Tax</span>
            <span>/</span>
            <span>Google Page Experience Signal</span>
          </div>
        </div>
      </footer>

      {/* Gemini AI Governance Modal */}
      <AiAdvisorModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        scripts={scripts}
        inputs={financialInputs}
        overallStatus={overallStatus}
      />
    </div>
  );
}
