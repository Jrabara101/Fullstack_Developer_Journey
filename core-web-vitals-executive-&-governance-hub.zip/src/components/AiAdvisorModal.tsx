import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Loader2,
  FileText,
  Layers,
  Copy,
} from 'lucide-react';
import { ThirdPartyScript, FinancialModelInputs } from '../types';

interface AiAdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  scripts: ThirdPartyScript[];
  inputs: FinancialModelInputs;
  overallStatus: {
    lcp: number;
    inp: number;
    cls: number;
    isPassing: boolean;
  };
}

export const AiAdvisorModal: React.FC<AiAdvisorModalProps> = ({
  isOpen,
  onClose,
  scripts,
  inputs,
  overallStatus,
}) => {
  const [activeMode, setActiveMode] = useState<'script-audit' | 'executive-brief' | 'sla-policy'>('script-audit');
  const [loading, setLoading] = useState<boolean>(false);
  const [aiResponse, setAiResponse] = useState<any | null>(null);
  const [customNotes, setCustomNotes] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleRunAiAdvisor = async () => {
    setLoading(true);
    setAiResponse(null);

    try {
      const payload = {
        mode: activeMode,
        scenario: customNotes || `E-commerce store with ${inputs.monthlyTraffic.toLocaleString()} visitors/mo and $${inputs.averageOrderValue} AOV`,
        scripts: scripts.filter((s) => s.isApplied),
        metrics: {
          currentLcp: overallStatus.lcp,
          targetLcp: inputs.targetLcpMs,
          currentInp: overallStatus.inp,
          targetInp: inputs.targetInpMs,
          currentCls: overallStatus.cls,
          targetCls: inputs.targetCls,
          isPassing: overallStatus.isPassing,
        },
      };

      const res = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        setAiResponse(data.result);
      } else {
        generateLocalGovernanceFallback();
      }
    } catch (err) {
      console.warn('Endpoint error, utilizing local governance intelligence engine:', err);
      generateLocalGovernanceFallback();
    } finally {
      setLoading(false);
    }
  };

  const generateLocalGovernanceFallback = () => {
    if (activeMode === 'script-audit') {
      setAiResponse({
        executiveSummary: `Your current third-party script payload adds ~${scripts.reduce((acc, s) => acc + (s.isApplied ? s.sizeKb : 0), 0)} KB of unmanaged JavaScript. Migrating heavy analytics and support chat to Tier 2/3 recovers an estimated 1.8s in LCP and 280ms in INP, directly preserving checkout conversion velocity.`,
        tagTiers: scripts.filter(s => s.isApplied).map((s) => ({
          name: s.name,
          tier: s.category === 'customer-support' ? 'Tier 3: Facade (Click)' : s.category === 'analytics' ? 'Tier 1: Essential (Async)' : s.currentTier === 'deprecated' ? 'Deprecated/Remove' : 'Tier 2: Defer Post-LCP',
          action: s.category === 'customer-support' ? 'Replace eager 1.8MB bundle with 4KB static launcher button.' : s.category === 'analytics' ? 'Execute async in non-blocking mode.' : 'Defer post-LCP or after first user scroll/touch event.',
          savingsMs: s.lcpImpactMs,
        })),
        governancePolicy: [
          'No marketing tag may merge into production without a verified incremental revenue delta > latency cost.',
          'Support chat widgets must strictly adopt the lightweight Facade pattern.',
          'Quarterly tag audits must automatically deprecate inactive seasonal tracking pixels.',
        ],
        estimatedLcpRecoveryMs: 1650,
        estimatedInpRecoveryMs: 240,
      });
    } else {
      setAiResponse({
        financialHeadline: `Unmitigated mobile latency creates an estimated tax on cart conversions, putting Google Page Experience mobile rankings at risk.`,
        cognitiveImpact: `Passing LCP (<2.5s) converts user impatience into brand relief; sub-200ms INP eliminates frustrating rage clicks; sub-0.10 CLS prevents costly accidental payment taps.`,
        recommendations: [
          'Enforce hard JavaScript asset budgets in CI/CD pipeline as non-negotiable release blockers.',
          'Adopt the 3-Tier Tag Governance framework across all Google Tag Manager containers.',
          'Implement Design Aspect-Ratio Reservation to lock down visual stability (Zero CLS).',
        ],
        boardroomQuote: '"Page speed is not an engineering hobby; it is a direct financial governor of conversion volume and organic search visibility."',
      });
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(aiResponse, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
      <div className="bg-white border-2 border-[#141414] max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 bg-[#141414] text-white flex items-center justify-between border-b border-[#141414]">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 border border-white/40 bg-white/10 flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <h3 className="font-mono font-bold text-xs uppercase tracking-wider text-white">
                AI_CWV_GOVERNANCE_ADVISOR // GEMINI_3.7
              </h3>
              <p className="text-[10px] font-serif-italic text-gray-300">
                Financial Latency, Tag Architecture, &amp; SLA Copilot
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Tabs */}
        <div className="flex border-b border-[#141414] bg-[#E4E3E0]">
          <button
            onClick={() => setActiveMode('script-audit')}
            className={`py-2.5 px-4 text-xs font-mono font-bold uppercase tracking-wider border-r border-[#141414] transition-all cursor-pointer ${
              activeMode === 'script-audit'
                ? 'bg-white text-[#141414]'
                : 'text-gray-700 hover:text-black hover:bg-white/40'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" />
              <span>Third-Party Tag Audit</span>
            </div>
          </button>

          <button
            onClick={() => setActiveMode('executive-brief')}
            className={`py-2.5 px-4 text-xs font-mono font-bold uppercase tracking-wider border-r border-[#141414] transition-all cursor-pointer ${
              activeMode === 'executive-brief'
                ? 'bg-white text-[#141414]'
                : 'text-gray-700 hover:text-black hover:bg-white/40'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5" />
              <span>Boardroom Executive Briefing</span>
            </div>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs bg-[#E4E3E0]">
          <div className="bg-white border border-[#141414] p-3.5 space-y-1.5">
            <label className="block font-mono font-bold text-xs uppercase text-[#141414]">
              Scenario Context / Constraints (Optional):
            </label>
            <input
              type="text"
              placeholder="e.g. Q4 Black Friday launch, heavy Meta and TikTok ads, high mobile bounce"
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-[#141414] text-xs font-mono bg-[#F0F0ED] focus:outline-hidden"
            />
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleRunAiAdvisor}
              disabled={loading}
              className="flex items-center gap-2 px-4 py-2 bg-[#141414] hover:bg-black text-white font-mono font-bold text-xs cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>SYNTHESIZING_GOVERNANCE...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>RUN_AI_ADVISOR</span>
                </>
              )}
            </button>
          </div>

          {/* AI Output Rendering */}
          {aiResponse && (
            <div className="border border-[#141414] bg-white p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#141414]">
                <span className="font-mono font-bold text-[#141414] uppercase text-[10px]">
                  STRATEGIC_AI_RECOMMENDATION_OUTPUT:
                </span>
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 font-mono text-[10px] font-bold text-[#141414] underline cursor-pointer"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copied ? 'COPIED!' : 'COPY_SUMMARY'}</span>
                </button>
              </div>

              {aiResponse.executiveSummary && (
                <div className="p-3 bg-[#F0F0ED] border border-gray-300 text-xs font-serif-italic leading-relaxed text-[#141414]">
                  {aiResponse.executiveSummary}
                </div>
              )}

              {aiResponse.financialHeadline && (
                <div className="p-3 border border-[#141414] bg-[#141414] text-white font-mono text-xs font-bold">
                  {aiResponse.financialHeadline}
                </div>
              )}

              {aiResponse.cognitiveImpact && (
                <div className="text-xs text-gray-800 font-serif-italic leading-snug">
                  <strong className="font-mono not-italic uppercase text-[10px] text-black block mb-0.5">
                    COGNITIVE_REALITY:
                  </strong>
                  {aiResponse.cognitiveImpact}
                </div>
              )}

              {aiResponse.tagTiers && (
                <div className="space-y-1.5">
                  <span className="font-mono font-bold uppercase text-[10px] text-[#141414] block">
                    RECOMMENDED_TAG_ACTIONS:
                  </span>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {aiResponse.tagTiers.map((t: any, idx: number) => (
                      <div
                        key={idx}
                        className="p-2 border border-gray-300 bg-[#F0F0ED] flex items-center justify-between text-[11px]"
                      >
                        <div>
                          <strong className="font-mono font-bold text-black block">{t.name}</strong>
                          <span className="text-gray-600 font-serif-italic">{t.action}</span>
                        </div>
                        <span className="font-mono font-bold px-1.5 py-0.5 bg-[#141414] text-white text-[9px] shrink-0">
                          {t.tier}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {aiResponse.governancePolicy && (
                <div className="space-y-1 pt-1 border-t border-gray-200">
                  <span className="font-mono font-bold uppercase text-[10px] text-[#141414] block">
                    GOVERNANCE_CONTRACT_POLICIES:
                  </span>
                  <ul className="list-disc pl-4 space-y-0.5 text-xs text-gray-700 font-serif-italic">
                    {aiResponse.governancePolicy.map((rule: string, i: number) => (
                      <li key={i}>{rule}</li>
                    ))}
                  </ul>
                </div>
              )}

              {aiResponse.boardroomQuote && (
                <div className="p-2.5 border border-[#141414] bg-[#F0F0ED] text-[11px] font-serif-italic text-black">
                  {aiResponse.boardroomQuote}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-white border-t border-[#141414] flex justify-end">
          <button
            onClick={onClose}
            className="px-3 py-1 bg-gray-200 hover:bg-gray-300 text-[#141414] font-mono text-xs font-bold border border-gray-400 cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
