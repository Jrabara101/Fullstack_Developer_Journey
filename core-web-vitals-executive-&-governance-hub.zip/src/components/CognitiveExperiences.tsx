import React, { useState, useRef } from 'react';
import {
  Zap,
  Smile,
  Frown,
  Meh,
  Flame,
  MousePointerClick,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';

export const CognitiveExperiences: React.FC = () => {
  const [activePillar, setActivePillar] = useState<'LCP' | 'INP' | 'CLS'>('LCP');

  // LCP Simulator States
  const [lcpSimDelay, setLcpSimDelay] = useState<number>(2.2);
  const [lcpLoading, setLcpLoading] = useState<boolean>(false);
  const [lcpLoadedTime, setLcpLoadedTime] = useState<number | null>(2.2);

  // INP Simulator States
  const [inpBlockMs, setInpBlockMs] = useState<number>(350);
  const [inpState, setInpState] = useState<'idle' | 'processing' | 'responded'>('idle');
  const [lastInpTime, setLastInpTime] = useState<number | null>(null);
  const [rageClicks, setRageClicks] = useState<number>(0);
  const clickCountRef = useRef<number>(0);

  // CLS Simulator States
  const [clsShiftApplied, setClsShiftApplied] = useState<boolean>(false);
  const [clsReservedRatio, setClsReservedRatio] = useState<boolean>(false);
  const [clsClickResult, setClsClickResult] = useState<string | null>(null);

  // Handle LCP test trigger
  const runLcpTest = () => {
    setLcpLoading(true);
    setLcpLoadedTime(null);

    setTimeout(() => {
      setLcpLoading(false);
      setLcpLoadedTime(+(lcpSimDelay).toFixed(1));
    }, lcpSimDelay * 1000);
  };

  // Handle INP Click test
  const handleInpClick = () => {
    clickCountRef.current += 1;
    if (inpState === 'processing') {
      setRageClicks((prev) => prev + 1);
      return;
    }

    setInpState('processing');
    const start = performance.now();

    // Simulate main thread blocking computation
    setTimeout(() => {
      const blockingStart = performance.now();
      while (performance.now() - blockingStart < Math.min(inpBlockMs, 100)) {
        // busy wait simulation
      }
      const totalElapsed = Math.round(performance.now() - start);
      setLastInpTime(Math.max(inpBlockMs, totalElapsed));
      setInpState('responded');
      clickCountRef.current = 0;
    }, inpBlockMs);
  };

  // Get cognitive feedback based on LCP
  const getLcpCognition = (seconds: number) => {
    if (seconds <= 1.5) {
      return {
        emotion: 'DELIGHT & TRUST',
        icon: Smile,
        color: 'border-emerald-700 bg-emerald-50 text-emerald-900',
        desc: 'Instant perceptual delivery. The user perceives the brand as authoritative, modern, and trustworthy.',
      };
    }
    if (seconds <= 2.5) {
      return {
        emotion: 'RELIEF & ACTIVE FOCUS (TARGET)',
        icon: Smile,
        color: 'border-emerald-700 bg-emerald-50 text-emerald-900',
        desc: 'Smooth cognitive transition. Content appears before attention breaks, preserving cart velocity.',
      };
    }
    if (seconds <= 4.0) {
      return {
        emotion: 'IMPATIENCE & COGNITIVE DOUBT',
        icon: Meh,
        color: 'border-amber-700 bg-amber-50 text-amber-900',
        desc: 'User experiences perceptual lag. Begins questioning connection quality and considers switching tabs.',
      };
    }
    return {
      emotion: 'SEVERE FRICTION & BOUNCE CLIFF',
      icon: Frown,
      color: 'border-red-700 bg-red-50 text-red-900',
      desc: 'Over 24% of mobile visitors hit the back button. The page is perceived as unresponsive or broken.',
    };
  };

  const lcpCognition = getLcpCognition(lcpSimDelay);

  return (
    <div className="space-y-6" id="cognitive-experiences-section">
      {/* High Density Section Header */}
      <div className="border border-[#141414] bg-white p-5 text-[#141414] shadow-xs">
        <div className="space-y-1.5 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-2 py-0.5 bg-[#141414] text-white text-[10px] font-mono font-bold uppercase tracking-wider">
            <Zap className="w-3 h-3 text-amber-300" />
            <span>PILLAR_02 // HUMAN_PERCEPTION</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#141414] uppercase">
            Human Cognitive Experiences &amp; Psychological Friction
          </h2>
          <p className="text-xs text-gray-700 font-serif-italic leading-relaxed">
            Core Web Vitals quantify human cognitive patience. Every metric correlates to an exact psychological transition from confidence to frustration.
          </p>
        </div>

        {/* Cognitive User Journey Map */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-3 pt-4 border-t border-gray-200">
          <div
            onClick={() => setActivePillar('LCP')}
            className={`p-3 border transition-all cursor-pointer ${
              activePillar === 'LCP'
                ? 'border-[#141414] bg-white ring-2 ring-black/10'
                : 'border-[#141414]/30 bg-[#F0F0ED] hover:border-[#141414] hover:bg-white'
            }`}
          >
            <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
              <span className="font-bold text-[#141414]">1. LCP (Value Delivery)</span>
              <span className="text-[10px] px-1.5 py-0.5 bg-[#141414] text-white font-bold">
                &lt; 2.5s
              </span>
            </div>
            <div className="text-xs font-serif-italic text-gray-700 mb-0.5">
              "Is this page useful yet?"
            </div>
            <div className="text-[11px] font-mono text-gray-600">
              <strong className="text-black">State:</strong> Impatience ➔ Trust &amp; Relief
            </div>
          </div>

          <div
            onClick={() => setActivePillar('INP')}
            className={`p-3 border transition-all cursor-pointer ${
              activePillar === 'INP'
                ? 'border-[#141414] bg-white ring-2 ring-black/10'
                : 'border-[#141414]/30 bg-[#F0F0ED] hover:border-[#141414] hover:bg-white'
            }`}
          >
            <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
              <span className="font-bold text-[#141414]">2. INP (Tactile Feedback)</span>
              <span className="text-[10px] px-1.5 py-0.5 bg-[#141414] text-white font-bold">
                &lt; 200ms
              </span>
            </div>
            <div className="text-xs font-serif-italic text-gray-700 mb-0.5">
              "Is this interface responsive?"
            </div>
            <div className="text-[11px] font-mono text-gray-600">
              <strong className="text-black">State:</strong> Frustration ➔ Competence &amp; Flow
            </div>
          </div>

          <div
            onClick={() => setActivePillar('CLS')}
            className={`p-3 border transition-all cursor-pointer ${
              activePillar === 'CLS'
                ? 'border-[#141414] bg-white ring-2 ring-black/10'
                : 'border-[#141414]/30 bg-[#F0F0ED] hover:border-[#141414] hover:bg-white'
            }`}
          >
            <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
              <span className="font-bold text-[#141414]">3. CLS (Visual Stability)</span>
              <span className="text-[10px] px-1.5 py-0.5 bg-[#141414] text-white font-bold">
                &lt; 0.10
              </span>
            </div>
            <div className="text-xs font-serif-italic text-gray-700 mb-0.5">
              "Is this interface stable?"
            </div>
            <div className="text-[11px] font-mono text-gray-600">
              <strong className="text-black">State:</strong> Deception ➔ Safety &amp; Control
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Sandbox Panels */}
      {activePillar === 'LCP' && (
        <div className="border border-[#141414] bg-white p-5 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-3 border-b border-[#141414]">
            <div>
              <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
                LCP Simulator // Largest Contentful Paint
              </div>
              <h3 className="font-bold text-sm text-[#141414] mt-0.5">
                The "Value Delivery" Moment (Target: &le; 2.50s)
              </h3>
            </div>

            <button
              onClick={runLcpTest}
              disabled={lcpLoading}
              className="flex items-center justify-center gap-2 px-3 py-1.5 bg-[#141414] hover:bg-black text-white text-xs font-mono font-bold cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${lcpLoading ? 'animate-spin' : ''}`} />
              <span>{lcpLoading ? 'RUNNING_SIMULATION...' : 'SIMULATE_PAGE_LOAD'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Controls & Emotion Gauge (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-[#F0F0ED] p-3 border border-gray-300">
                <div className="flex justify-between text-xs font-mono mb-1">
                  <span className="font-serif-italic text-gray-600 font-normal">Simulated Render Latency:</span>
                  <span
                    className={`font-bold ${
                      lcpSimDelay <= 2.5 ? 'text-emerald-700' : 'text-red-700'
                    }`}
                  >
                    {lcpSimDelay.toFixed(1)}s
                  </span>
                </div>
                <input
                  type="range"
                  min="0.6"
                  max="5.0"
                  step="0.1"
                  value={lcpSimDelay}
                  onChange={(e) => setLcpSimDelay(Number(e.target.value))}
                  className="w-full h-1.5 bg-gray-300 appearance-none cursor-pointer accent-black"
                />
                <div className="flex justify-between text-[10px] font-mono text-gray-500 mt-1">
                  <span>0.6s (FAST)</span>
                  <span className="font-bold text-emerald-700">2.5s (CWV_GATE)</span>
                  <span>5.0s (POOR)</span>
                </div>
              </div>

              {/* Dynamic Emotional State Card */}
              <div className={`p-3.5 border text-xs ${lcpCognition.color}`}>
                <div className="flex items-center gap-1.5 font-mono font-bold text-xs mb-1">
                  {React.createElement(lcpCognition.icon, { className: 'w-4 h-4' })}
                  <span>PSYCHOLOGY: {lcpCognition.emotion}</span>
                </div>
                <p className="leading-snug font-serif-italic">{lcpCognition.desc}</p>
              </div>

              <div className="border border-gray-300 bg-white p-3.5 text-xs space-y-2">
                <span className="font-mono font-bold text-[#141414] block uppercase text-[11px]">
                  ENGINEERING_ACTIONS_LCP:
                </span>
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-gray-700 font-serif-italic">
                  <li>Preload critical hero images via <code className="font-mono text-black">fetchpriority="high"</code></li>
                  <li>Eliminate render-blocking CSS/JS in the document <code className="font-mono text-black">&lt;head&gt;</code></li>
                  <li>Serve modern AVIF/WebP formats with responsive <code className="font-mono text-black">srcset</code></li>
                  <li>Deploy edge CDN full-page caching to keep TTFB &lt; 200ms</li>
                </ul>
              </div>
            </div>

            {/* Viewport Simulation Frame (7 cols) */}
            <div className="lg:col-span-7 border border-[#141414] bg-[#141414] p-3 text-white">
              <div className="flex items-center justify-between text-[10px] font-mono text-gray-400 mb-2 px-1">
                <span>URL: https://store.example.com/product/101</span>
                <span className="text-amber-300 font-bold">
                  {lcpLoading ? 'BUFFERING_STREAM...' : `RENDER_COMPLETE: ${lcpLoadedTime ?? lcpSimDelay}s`}
                </span>
              </div>

              <div className="bg-white text-[#141414] p-4 min-h-[260px] flex flex-col justify-between overflow-hidden relative border border-gray-400">
                {lcpLoading ? (
                  <div className="space-y-3 animate-pulse">
                    <div className="h-5 bg-gray-300 w-3/4" />
                    <div className="h-28 bg-gray-200 w-full flex items-center justify-center text-gray-500 font-mono text-xs">
                      [WAITING_FOR_LCP_HERO_PAYLOAD...]
                    </div>
                    <div className="space-y-1.5">
                      <div className="h-3 bg-gray-200 w-5/6" />
                      <div className="h-3 bg-gray-200 w-4/6" />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-base text-[#141414] uppercase">
                        Next-Gen Wireless Headphones Pro
                      </h4>
                      <span className="text-xs font-mono px-2 py-0.5 bg-[#141414] text-white font-bold">
                        $299.00
                      </span>
                    </div>

                    <div className="border border-[#141414] bg-[#F0F0ED] p-4 flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-[9px] font-mono uppercase font-bold text-gray-500">
                          LCP_RENDER_TARGET
                        </span>
                        <h5 className="font-bold text-sm text-[#141414]">Studio Acoustic Fidelity</h5>
                        <p className="text-xs text-gray-700 font-serif-italic">Spatial Audio + 45h Battery</p>
                      </div>
                      <div className="w-12 h-12 border border-[#141414] bg-white flex items-center justify-center text-[#141414]">
                        <Sparkles className="w-6 h-6" />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="text-[11px] font-serif-italic text-gray-600">
                        In stock • Express dispatch
                      </div>
                      <button className="px-3 py-1.5 bg-[#141414] text-white font-mono text-xs font-bold">
                        ADD_TO_CART
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {activePillar === 'INP' && (
        <div className="border border-[#141414] bg-white p-5 shadow-xs space-y-5">
          <div className="pb-3 border-b border-[#141414]">
            <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
              INP &amp; Rage Click Sandbox // Interaction to Next Paint
            </div>
            <h3 className="font-bold text-sm text-[#141414] mt-0.5">
              The "Tactile Feedback" Check (Target: &le; 200ms)
            </h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Controls & Thread Block Slider (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-[#F0F0ED] p-3 border border-gray-300">
                <div className="flex justify-between text-xs font-mono mb-1">
                  <span className="font-serif-italic text-gray-600 font-normal">Main Thread Blocking Time:</span>
                  <span
                    className={`font-bold ${
                      inpBlockMs <= 200 ? 'text-emerald-700' : 'text-red-700'
                    }`}
                  >
                    {inpBlockMs}ms
                  </span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="900"
                  step="20"
                  value={inpBlockMs}
                  onChange={(e) => setInpBlockMs(Number(e.target.value))}
                  className="w-full h-1.5 bg-gray-300 appearance-none cursor-pointer accent-black"
                />
                <div className="flex justify-between text-[10px] font-mono text-gray-500 mt-1">
                  <span>20ms (INSTANT)</span>
                  <span className="font-bold text-emerald-700">200ms (GOOD)</span>
                  <span>900ms (FROZEN)</span>
                </div>
              </div>

              {/* Rage Click Alert Box */}
              <div
                className={`p-3.5 border text-xs ${
                  rageClicks > 0
                    ? 'border-red-700 bg-red-50 text-red-950'
                    : 'border-gray-300 bg-[#F0F0ED] text-gray-800'
                }`}
              >
                <div className="flex items-center justify-between font-mono font-bold mb-1 text-xs">
                  <div className="flex items-center gap-1.5">
                    <Flame className={`w-4 h-4 ${rageClicks > 0 ? 'text-red-700' : 'text-gray-500'}`} />
                    <span>RAGE_CLICK_DETECTOR</span>
                  </div>
                  <span>{rageClicks} DETECTED</span>
                </div>
                <p className="font-serif-italic leading-snug">
                  {rageClicks > 0
                    ? 'Repeated clicks during main thread blockage trigger duplicate API requests, cart corruption, and severe customer support overhead.'
                    : 'Click the button on the right multiple times while it processes to test rage-click detection.'}
                </p>
                {rageClicks > 0 && (
                  <button
                    onClick={() => setRageClicks(0)}
                    className="mt-2 font-mono text-[10px] font-bold text-red-800 underline cursor-pointer"
                  >
                    [RESET_COUNTER]
                  </button>
                )}
              </div>

              <div className="border border-gray-300 bg-white p-3.5 text-xs space-y-2">
                <span className="font-mono font-bold text-[#141414] block uppercase text-[11px]">
                  ENGINEERING_ACTIONS_INP:
                </span>
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-gray-700 font-serif-italic">
                  <li>Break long tasks using <code className="font-mono text-black">scheduler.yield()</code> or <code className="font-mono text-black">requestIdleCallback()</code></li>
                  <li>Avoid heavy synchronous JSON parsing or DOM layout thrashing in click handlers</li>
                  <li>Provide immediate optimistic visual feedback before state calculations</li>
                  <li>Offload analytics telemetry away from high-priority touch events</li>
                </ul>
              </div>
            </div>

            {/* Right Interactive Button Sandbox (7 cols) */}
            <div className="lg:col-span-7 border border-[#141414] bg-[#F0F0ED] p-5 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between pb-2 border-b border-gray-300">
                  <span className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
                    Interactive Tactile Testbed
                  </span>
                  {lastInpTime !== null && (
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 border ${
                        lastInpTime <= 200
                          ? 'border-emerald-700 bg-emerald-50 text-emerald-800'
                          : 'border-red-700 bg-red-50 text-red-800'
                      }`}
                    >
                      INP: {lastInpTime}ms
                    </span>
                  )}
                </div>

                <p className="text-xs font-serif-italic text-gray-700">
                  Tap the button below. High main-thread blockage locks the browser from acknowledging pointer events:
                </p>
              </div>

              <div className="py-6 flex flex-col items-center justify-center space-y-3">
                <button
                  id="btn-test-inp"
                  onClick={handleInpClick}
                  className={`w-full max-w-sm py-3.5 px-5 font-mono font-bold text-xs border border-[#141414] transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    inpState === 'processing'
                      ? 'bg-amber-400 text-black animate-pulse'
                      : 'bg-[#141414] hover:bg-black active:bg-gray-800 text-white'
                  }`}
                >
                  <MousePointerClick className="w-4 h-4" />
                  <span>
                    {inpState === 'processing'
                      ? `[THREAD_LOCKED: ${inpBlockMs}ms...]`
                      : 'FILTER_4800_PRODUCTS_APPLY_PROMO'}
                  </span>
                </button>

                <span className="text-[10px] font-mono text-gray-500">
                  {inpState === 'responded'
                    ? `✓ Next Paint rendered in ${lastInpTime}ms`
                    : 'Tap rapidly to simulate mobile user behavior'}
                </span>
              </div>

              <div className="border border-gray-300 bg-white p-2.5 flex items-center justify-between text-xs font-mono">
                <span className="text-gray-600 font-serif-italic">Tactile Feedback State:</span>
                <span className="font-bold text-black">
                  {inpBlockMs <= 200
                    ? 'SNAPPY_FLUID (PASS)'
                    : inpBlockMs <= 500
                    ? 'SLUGGISH_LAG (WARN)'
                    : 'FROZEN_MAIN_THREAD (FAIL)'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activePillar === 'CLS' && (
        <div className="border border-[#141414] bg-white p-5 shadow-xs space-y-5">
          <div className="pb-3 border-b border-[#141414]">
            <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
              CLS Visual Deception Sandbox // Cumulative Layout Shift
            </div>
            <h3 className="font-bold text-sm text-[#141414] mt-0.5">
              The "Visual Deception" Trigger (Target: &le; 0.10)
            </h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Controls (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-[#F0F0ED] border border-gray-300 p-3 space-y-2">
                <span className="font-mono text-xs font-bold text-[#141414] block uppercase">
                  GOVERNANCE_CONTROL
                </span>
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={clsReservedRatio}
                    onChange={(e) => {
                      setClsReservedRatio(e.target.checked);
                      setClsShiftApplied(false);
                      setClsClickResult(null);
                    }}
                    className="mt-0.5 w-4 h-4 accent-black"
                  />
                  <div>
                    <span className="text-xs font-bold text-[#141414] block">
                      Enforce Design Aspect-Ratio Reservation (SLA)
                    </span>
                    <span className="text-[10px] font-serif-italic text-gray-600">
                      Locks container geometry in CSS (CLS = 0.00) before dynamic ad payloads arrive.
                    </span>
                  </div>
                </label>
              </div>

              {clsClickResult && (
                <div
                  className={`p-3.5 border text-xs leading-relaxed ${
                    clsClickResult.includes('ACCIDENTAL')
                      ? 'border-red-700 bg-red-50 text-red-950'
                      : 'border-emerald-700 bg-emerald-50 text-emerald-950'
                  }`}
                >
                  <div className="font-mono font-bold mb-1 flex items-center gap-1.5">
                    {clsClickResult.includes('ACCIDENTAL') ? (
                      <AlertTriangle className="w-4 h-4 text-red-700" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                    )}
                    <span>{clsClickResult}</span>
                  </div>
                  <p className="font-serif-italic">
                    {clsClickResult.includes('ACCIDENTAL')
                      ? 'Because the un-dimensioned ad injected without pre-allocated layout space, the button shifted unexpectedly under your pointer. In real-world e-commerce, this causes accidental charges, chargebacks, and permanent loss of trust.'
                      : 'The layout remained stable because the design container reserved fixed dimensions before the banner payload arrived. Zero accidental clicks.'}
                  </p>
                </div>
              )}

              <div className="border border-gray-300 bg-white p-3.5 text-xs space-y-2">
                <span className="font-mono font-bold text-[#141414] block uppercase text-[11px]">
                  ENGINEERING_ACTIONS_CLS:
                </span>
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-gray-700 font-serif-italic">
                  <li>Set explicit <code className="font-mono text-black">width</code> and <code className="font-mono text-black">height</code> on images and video slots</li>
                  <li>Reserve minimum slot heights for dynamic ads (<code className="font-mono text-black">min-height: 250px</code>)</li>
                  <li>Use <code className="font-mono text-black">font-display: optional</code> or <code className="font-mono text-black">size-adjust</code> fallback font metrics</li>
                  <li>Never insert new DOM elements above existing viewport content</li>
                </ul>
              </div>
            </div>

            {/* Right Interactive Checkout Simulation (7 cols) */}
            <div className="lg:col-span-7 border border-[#141414] bg-[#141414] p-4 text-white flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-gray-700 text-xs font-mono">
                <span className="text-gray-300">MODAL_PREVIEW: CHECKOUT</span>
                <span className="text-amber-300 font-bold">
                  CLS: {clsReservedRatio ? '0.00 (PERFECT)' : clsShiftApplied ? '0.28 (POOR)' : '0.00'}
                </span>
              </div>

              <div className="bg-white text-[#141414] p-4 space-y-3 border border-gray-400">
                {clsReservedRatio ? (
                  <div className="h-16 bg-[#F0F0ED] border border-[#141414] p-2.5 flex items-center justify-between text-xs font-mono">
                    <span className="font-bold text-[#141414]">PROMO: 20% DISCOUNT APPLIED</span>
                    <span className="text-[9px] bg-[#141414] text-white px-1.5 py-0.5">
                      RESERVED_SLOT
                    </span>
                  </div>
                ) : (
                  clsShiftApplied && (
                    <div className="h-16 bg-red-50 border border-red-700 p-2.5 flex items-center justify-between text-red-900 text-xs font-mono">
                      <div>
                        <span className="font-bold block">BREAKING_PROMO_INJECTED_LATE</span>
                        <span className="text-[10px] font-serif-italic text-red-800">Shifted button down 64px!</span>
                      </div>
                      <span className="text-[9px] bg-red-700 text-white px-1.5 py-0.5 font-bold">
                        CLS +0.28
                      </span>
                    </div>
                  )
                )}

                <div className="space-y-0.5">
                  <h4 className="font-bold text-sm text-[#141414] uppercase">Order Confirmation</h4>
                  <p className="text-xs text-gray-600 font-serif-italic">Annual Enterprise License — $499.00/yr</p>
                </div>

                <div className="pt-2 border-t border-gray-200 flex flex-col sm:flex-row gap-2">
                  <button
                    onMouseEnter={() => {
                      if (!clsReservedRatio && !clsShiftApplied) {
                        setClsShiftApplied(true);
                      }
                    }}
                    onClick={() => {
                      if (!clsReservedRatio && clsShiftApplied) {
                        setClsClickResult('ACCIDENTAL $499 CHARGE TRIGGERED! (Mis-click due to CLS)');
                      } else {
                        setClsClickResult('Action Cancelled Safely');
                      }
                    }}
                    className="flex-1 py-2 px-3 bg-red-700 hover:bg-red-800 text-white font-mono font-bold text-xs cursor-pointer"
                  >
                    CONFIRM $499 ORDER
                  </button>

                  <button
                    onClick={() => {
                      setClsClickResult('Safely returned without accidental charges');
                    }}
                    className="flex-1 py-2 px-3 border border-[#141414] bg-white hover:bg-gray-100 text-[#141414] font-mono font-bold text-xs cursor-pointer"
                  >
                    CANCEL &amp; RETURN
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-gray-400 pt-1">
                <span>Hover near the buttons to trigger dynamic script injection</span>
                <button
                  onClick={() => {
                    setClsShiftApplied(false);
                    setClsClickResult(null);
                  }}
                  className="text-amber-300 underline cursor-pointer"
                >
                  [RESET_DEMO]
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
