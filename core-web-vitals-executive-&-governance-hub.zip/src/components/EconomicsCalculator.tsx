import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  Percent,
  ShoppingCart,
  ShieldAlert,
  ArrowUpRight,
  HelpCircle,
  BarChart3,
  Award,
  Sparkles,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { FinancialModelInputs, FinancialCalculationResult } from '../types';
import { BENCHMARKS } from '../data/cwvData';

interface EconomicsCalculatorProps {
  inputs: FinancialModelInputs;
  setInputs: React.Dispatch<React.SetStateAction<FinancialModelInputs>>;
}

export const EconomicsCalculator: React.FC<EconomicsCalculatorProps> = ({
  inputs,
  setInputs,
}) => {
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<number>(0);

  // Financial calculations
  const calculateResults = (): FinancialCalculationResult => {
    const monthlyTraffic = inputs.monthlyTraffic;
    const baseCr = inputs.baselineConversionRate / 100;
    const aov = inputs.averageOrderValue;

    // Latency change in milliseconds (positive = improvement, negative = degradation)
    const lcpDeltaMs = (inputs.currentLcpMs - inputs.targetLcpMs) * 1000;
    const inpDeltaMs = inputs.currentInpMs - inputs.targetInpMs;
    // Composite weighted user speed improvement in 100ms units
    const compositeSpeedDeltaMs = lcpDeltaMs * 0.65 + inpDeltaMs * 0.35;
    const hundredMsUnits = compositeSpeedDeltaMs / 100;

    // Conversion lift percentage (e.g. +2.0% per 100ms improvement)
    const rawLiftPercent = hundredMsUnits * (inputs.conversionDropPer100ms / 100);
    const cappedLiftPercent = Math.max(-0.6, Math.min(0.8, rawLiftPercent)); // sanity bound

    // LCP < 2.5s bonus: +24% less abandonment on mobile funnel
    const passesTargetLcp = inputs.targetLcpMs <= 2.5;
    const lcpAbandonmentBonus = passesTargetLcp && inputs.currentLcpMs > 2.5 ? 0.04 : 0;

    // Total new conversion rate
    const newCr = Math.max(0.001, baseCr * (1 + cappedLiftPercent + lcpAbandonmentBonus));

    const monthlyBaselineOrders = monthlyTraffic * baseCr;
    const monthlyBaselineRevenue = monthlyBaselineOrders * aov;

    const projectedMonthlyOrders = monthlyTraffic * newCr;
    const projectedMonthlyRevenue = projectedMonthlyOrders * aov;

    const monthlyRevenueDelta = projectedMonthlyRevenue - monthlyBaselineRevenue;
    const annualRevenueDelta = monthlyRevenueDelta * 12;

    const conversionsSavedMonthly = Math.round(projectedMonthlyOrders - monthlyBaselineOrders);
    const cartAbandonmentReductionPercent = passesTargetLcp ? 24 : 0;

    // CLS < 0.1 prevents mis-clicks and dispute chargebacks
    const passesTargetCls = inputs.targetCls <= 0.1;
    const misclickReductionMonthly =
      passesTargetCls && inputs.currentCls > 0.1 ? monthlyBaselineOrders * 0.008 * 45 : 0;

    // SEO Google Search Ranking Boost (qualifying URLs for Page Experience)
    const passesAllThree =
      inputs.targetLcpMs <= 2.5 && inputs.targetInpMs <= 200 && inputs.targetCls <= 0.1;
    const seoRankingProbability = passesAllThree ? 95 : inputs.targetLcpMs <= 2.5 ? 60 : 30;

    return {
      monthlyRevenueBaseline: monthlyBaselineRevenue,
      projectedMonthlyRevenue: projectedMonthlyRevenue,
      monthlyRevenueDelta: monthlyRevenueDelta,
      annualRevenueDelta: annualRevenueDelta,
      conversionsSavedMonthly: conversionsSavedMonthly,
      cartAbandonmentReductionPercent: cartAbandonmentReductionPercent,
      preventedMisclickChargebacksCost: misclickReductionMonthly,
      seoRankingProbability: seoRankingProbability,
    };
  };

  const results = calculateResults();

  // Generate Conversion vs Latency Decay Curve Data
  const generateDecayCurveData = () => {
    const baseCr = inputs.baselineConversionRate;
    const stepSize = 200; // ms
    const data = [];

    for (let delay = -800; delay <= 2000; delay += stepSize) {
      const units100 = delay / 100;
      const decayFactor = 1 - units100 * (inputs.conversionDropPer100ms / 100);
      const effectiveCr = Math.max(0.2, +(baseCr * decayFactor).toFixed(2));
      const monthlyRev = Math.round((inputs.monthlyTraffic * (effectiveCr / 100) * inputs.averageOrderValue) / 1000);

      data.push({
        latencyShift: delay === 0 ? '0ms (Baseline)' : delay > 0 ? `+${delay}ms` : `${delay}ms`,
        delayMs: delay,
        conversionRate: effectiveCr,
        monthlyRevenueK: monthlyRev,
      });
    }
    return data;
  };

  const decayData = generateDecayCurveData();

  // Format currency helpers
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const formatCompactCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(val);
  };

  return (
    <div className="space-y-6" id="economics-calculator-section">
      {/* High Density Section Header Banner */}
      <div className="border border-[#141414] bg-white p-5 text-[#141414] shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
          <div className="space-y-1.5 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-2 py-0.5 bg-[#141414] text-white text-[10px] font-mono font-bold uppercase tracking-wider">
              <DollarSign className="w-3 h-3 text-amber-300" />
              <span>PILLAR_01 // FINANCIAL_GOVERNANCE</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#141414] uppercase">
              Business Economics &amp; Conversion Correlation
            </h2>
            <p className="text-xs text-gray-700 font-serif-italic leading-relaxed">
              Latency functions as a direct financial tax on conversion funnels. Every 100ms of friction drains conversion velocity and organic mobile search rank.
            </p>
          </div>

          {/* Headline Annual ROI Impact */}
          <div className="border border-[#141414] bg-[#F0F0ED] p-4 min-w-[260px]">
            <div className="text-[10px] font-serif-italic uppercase opacity-60 text-[#141414]">
              Projected Annual Financial Impact
            </div>
            <div className={`font-mono text-2xl sm:text-3xl font-bold mt-1 tracking-tight ${results.annualRevenueDelta >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
              {results.annualRevenueDelta >= 0 ? '+' : ''}
              {formatCompactCurrency(results.annualRevenueDelta)}
            </div>
            <div className="text-[11px] font-mono text-gray-600 mt-0.5">
              {results.monthlyRevenueDelta >= 0 ? 'NET_LIFT' : 'NET_DRAIN'}: {formatCurrency(results.monthlyRevenueDelta)}/mo
            </div>
          </div>
        </div>
      </div>

      {/* Real-World Industry Benchmarks Grid */}
      <div>
        <div className="text-[10px] font-serif-italic uppercase opacity-60 mb-2 tracking-wider">
          Empirical Case Studies // Conversion vs Speed
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {BENCHMARKS.map((benchmark, idx) => (
            <div
              key={idx}
              onClick={() => setSelectedCaseStudy(idx)}
              className={`p-3.5 border transition-all cursor-pointer ${
                selectedCaseStudy === idx
                  ? 'border-[#141414] bg-white ring-2 ring-black/10'
                  : 'border-[#141414]/30 bg-white/70 hover:border-[#141414] hover:bg-white'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
                <span className="font-bold bg-[#141414] text-white px-1.5 py-0.5 text-[10px]">
                  {benchmark.metricShift}
                </span>
                <span className="text-gray-600 text-[10px] uppercase font-bold">{benchmark.tag}</span>
              </div>
              <div className="text-sm font-bold text-[#141414] mb-1 font-mono">{benchmark.impact}</div>
              <p className="text-xs text-gray-700 leading-snug font-serif-italic">{benchmark.details}</p>
              <div className="mt-2.5 pt-2 border-t border-gray-200 flex items-center justify-between text-[10px] font-mono text-gray-500">
                <span>{benchmark.source}</span>
                <ArrowUpRight className="w-3 h-3 text-black" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Interactive Modeler: Inputs & Real-Time Output Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Financial & CWV Controls (5 cols) */}
        <div className="lg:col-span-5 border border-[#141414] bg-white p-5 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-2 border-b border-[#141414]">
            <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
              Control Parameters &amp; Simulation
            </div>
            <span className="text-[10px] font-mono bg-[#141414] text-white px-1.5 py-0.5 font-bold">
              LIVE_EVAL
            </span>
          </div>

          {/* Traffic & Economics Inputs */}
          <div className="space-y-3.5">
            <div className="bg-[#F0F0ED] p-3 border border-gray-300">
              <div className="flex justify-between text-xs font-mono font-bold text-[#141414] mb-1">
                <span className="font-serif-italic text-gray-600 font-normal">Monthly Traffic:</span>
                <span>{new Intl.NumberFormat('en-US').format(inputs.monthlyTraffic)} visitors</span>
              </div>
              <input
                id="input-monthly-traffic"
                type="range"
                min="50000"
                max="10000000"
                step="50000"
                value={inputs.monthlyTraffic}
                onChange={(e) =>
                  setInputs((prev) => ({ ...prev, monthlyTraffic: Number(e.target.value) }))
                }
                className="w-full h-1.5 bg-gray-300 appearance-none cursor-pointer accent-black"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#F0F0ED] p-3 border border-gray-300">
                <label className="block text-[11px] font-serif-italic text-gray-600 mb-1">
                  Baseline Conv. Rate (%):
                </label>
                <div className="relative">
                  <input
                    id="input-baseline-cr"
                    type="number"
                    step="0.1"
                    min="0.1"
                    max="15"
                    value={inputs.baselineConversionRate}
                    onChange={(e) =>
                      setInputs((prev) => ({
                        ...prev,
                        baselineConversionRate: Math.max(0.1, Number(e.target.value)),
                      }))
                    }
                    className="w-full px-2 py-1 text-xs font-mono font-bold bg-white border border-[#141414] focus:outline-hidden"
                  />
                  <Percent className="w-3 h-3 text-gray-500 absolute right-2.5 top-2" />
                </div>
              </div>

              <div className="bg-[#F0F0ED] p-3 border border-gray-300">
                <label className="block text-[11px] font-serif-italic text-gray-600 mb-1">
                  Average Order Value ($):
                </label>
                <div className="relative">
                  <input
                    id="input-aov"
                    type="number"
                    step="5"
                    min="5"
                    max="2000"
                    value={inputs.averageOrderValue}
                    onChange={(e) =>
                      setInputs((prev) => ({
                        ...prev,
                        averageOrderValue: Math.max(1, Number(e.target.value)),
                      }))
                    }
                    className="w-full px-2 py-1 text-xs font-mono font-bold bg-white border border-[#141414] focus:outline-hidden"
                  />
                  <DollarSign className="w-3 h-3 text-gray-500 absolute right-2.5 top-2" />
                </div>
              </div>
            </div>

            <div className="bg-[#F0F0ED] p-3 border border-gray-300">
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="font-serif-italic text-gray-600 font-normal">Conversion Decay / 100ms:</span>
                <span className="font-bold text-red-700">-{inputs.conversionDropPer100ms.toFixed(1)}%</span>
              </div>
              <input
                id="input-conv-sensitivity"
                type="range"
                min="0.5"
                max="7.0"
                step="0.1"
                value={inputs.conversionDropPer100ms}
                onChange={(e) =>
                  setInputs((prev) => ({
                    ...prev,
                    conversionDropPer100ms: Number(e.target.value),
                  }))
                }
                className="w-full h-1.5 bg-gray-300 appearance-none cursor-pointer accent-black"
              />
              <p className="text-[10px] font-serif-italic text-gray-500 mt-1">
                Deloitte: 1.1% • Amazon: 1.0% • Walmart: 2.0%
              </p>
            </div>
          </div>

          {/* Speed Shift Comparison (Current vs Target CWVs) */}
          <div className="pt-3 border-t border-[#141414] space-y-3">
            <div className="text-[10px] font-serif-italic uppercase opacity-70 font-bold tracking-wider">
              Target Core Web Vitals Optimization Gate
            </div>

            {/* LCP Slider */}
            <div className="p-2.5 border border-gray-300 bg-white">
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="font-serif-italic text-gray-700 font-normal">LCP (Load):</span>
                <span>
                  <span className="text-red-700 font-bold">{inputs.currentLcpMs.toFixed(1)}s</span> ➔{' '}
                  <span className="text-emerald-700 font-bold">{inputs.targetLcpMs.toFixed(1)}s</span>
                </span>
              </div>
              <input
                id="input-target-lcp"
                type="range"
                min="1.0"
                max="5.0"
                step="0.1"
                value={inputs.targetLcpMs}
                onChange={(e) =>
                  setInputs((prev) => ({ ...prev, targetLcpMs: Number(e.target.value) }))
                }
                className="w-full h-1.5 bg-gray-300 appearance-none cursor-pointer accent-emerald-700"
              />
            </div>

            {/* INP Slider */}
            <div className="p-2.5 border border-gray-300 bg-white">
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="font-serif-italic text-gray-700 font-normal">INP (Response):</span>
                <span>
                  <span className="text-red-700 font-bold">{Math.round(inputs.currentInpMs)}ms</span> ➔{' '}
                  <span className="text-emerald-700 font-bold">{Math.round(inputs.targetInpMs)}ms</span>
                </span>
              </div>
              <input
                id="input-target-inp"
                type="range"
                min="50"
                max="600"
                step="10"
                value={inputs.targetInpMs}
                onChange={(e) =>
                  setInputs((prev) => ({ ...prev, targetInpMs: Number(e.target.value) }))
                }
                className="w-full h-1.5 bg-gray-300 appearance-none cursor-pointer accent-emerald-700"
              />
            </div>

            {/* CLS Slider */}
            <div className="p-2.5 border border-gray-300 bg-white">
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="font-serif-italic text-gray-700 font-normal">CLS (Stability):</span>
                <span>
                  <span className="text-red-700 font-bold">{inputs.currentCls.toFixed(2)}</span> ➔{' '}
                  <span className="text-emerald-700 font-bold">{inputs.targetCls.toFixed(2)}</span>
                </span>
              </div>
              <input
                id="input-target-cls"
                type="range"
                min="0.0"
                max="0.4"
                step="0.01"
                value={inputs.targetCls}
                onChange={(e) =>
                  setInputs((prev) => ({ ...prev, targetCls: Number(e.target.value) }))
                }
                className="w-full h-1.5 bg-gray-300 appearance-none cursor-pointer accent-emerald-700"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic Financial Dashboard & Charts (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Key Metric Scorecard Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="border border-[#141414] bg-white p-4">
              <div className="font-serif-italic text-[11px] uppercase opacity-60 text-[#141414] mb-1">
                Monthly Delta
              </div>
              <div className="font-mono text-xl sm:text-2xl font-bold text-[#141414]">
                {results.monthlyRevenueDelta >= 0 ? '+' : ''}
                {formatCompactCurrency(results.monthlyRevenueDelta)}
              </div>
              <div className="text-[10px] font-mono text-emerald-700 font-bold mt-1">
                {results.monthlyRevenueDelta >= 0 ? 'ANNUAL: ' : 'LOSS: '}
                {formatCompactCurrency(results.annualRevenueDelta)}
              </div>
            </div>

            <div className="border border-[#141414] bg-white p-4">
              <div className="font-serif-italic text-[11px] uppercase opacity-60 text-[#141414] mb-1">
                Orders Preserved
              </div>
              <div className="font-mono text-xl sm:text-2xl font-bold text-[#141414]">
                {results.conversionsSavedMonthly > 0 ? '+' : ''}
                {new Intl.NumberFormat('en-US').format(results.conversionsSavedMonthly)}
              </div>
              <div className="text-[10px] font-mono text-gray-600 mt-1">
                TRANSACTIONS / MO
              </div>
            </div>

            <div className="border border-[#141414] bg-white p-4 col-span-2 sm:col-span-1">
              <div className="font-serif-italic text-[11px] uppercase opacity-60 text-[#141414] mb-1">
                Google SERP Index
              </div>
              <div className="font-mono text-xl sm:text-2xl font-bold text-[#141414]">
                {results.seoRankingProbability}%
              </div>
              <div className="text-[10px] font-mono font-bold text-gray-700 mt-1">
                {results.seoRankingProbability >= 90 ? 'STATUS: QUALIFIED' : 'STATUS: AT_RISK'}
              </div>
            </div>
          </div>

          {/* Conversion vs Latency Decay Curve Chart */}
          <div className="border border-[#141414] bg-white p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3 border-b border-gray-200 pb-2">
              <div>
                <div className="font-serif-italic text-xs uppercase opacity-70 font-bold tracking-wider">
                  Conversion Rate &amp; Revenue Sensitivity Curve
                </div>
                <p className="text-[11px] text-gray-600 font-serif-italic">
                  Modeling conversion decay across 100ms latency intervals
                </p>
              </div>
              <div className="text-[10px] font-mono bg-[#141414] text-white px-2 py-0.5 font-bold">
                DECAY_CURVE
              </div>
            </div>

            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={decayData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#E4E3E0" />
                  <XAxis dataKey="latencyShift" tick={{ fontSize: 9, fill: '#141414', fontFamily: 'monospace' }} />
                  <YAxis
                    tick={{ fontSize: 9, fill: '#141414', fontFamily: 'monospace' }}
                    domain={['auto', 'auto']}
                    unit="%"
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="border border-[#141414] bg-white p-2.5 text-xs font-mono shadow-md space-y-0.5">
                            <p className="font-bold text-[#141414]">{d.latencyShift}</p>
                            <p className="text-gray-700">
                              Conv Rate: <strong className="text-black">{d.conversionRate}%</strong>
                            </p>
                            <p className="text-gray-700">
                              Est Revenue: <strong>${new Intl.NumberFormat('en-US').format(d.monthlyRevenueK)}k</strong>
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="conversionRate"
                    stroke="#141414"
                    strokeWidth={2}
                    fill="#F0F0ED"
                    name="Conversion Rate (%)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 flex items-center justify-between text-[10px] font-mono text-gray-500 border-t border-gray-200 pt-2">
              <span>← FASTER RESPONSE (+FOCUS)</span>
              <span>SLOWER RESPONSE (FRICTION &amp; ABANDONMENT) →</span>
            </div>
          </div>

          {/* Strategic Executive Takeaway Box */}
          <div className="border border-[#141414] bg-[#F0F0ED] p-4 text-xs font-serif-italic text-[#141414] leading-relaxed">
            <div className="font-sans font-bold uppercase text-[10px] text-gray-600 mb-1 tracking-wider">
              Executive Governance Rationale:
            </div>
            Every 100ms of latency reduction returns an estimated{' '}
            <strong className="font-mono not-italic text-black font-bold">
              {formatCurrency(
                results.monthlyRevenueDelta /
                  Math.max(1, (inputs.currentLcpMs - inputs.targetLcpMs) * 10)
              )}
            </strong>{' '}
            in monthly revenue. Reaching <strong className="not-italic">LCP &lt; 2.5s</strong> eliminates mobile checkout bounce cliffs and secures Google mobile search eligibility.
          </div>
        </div>
      </div>
    </div>
  );
};
