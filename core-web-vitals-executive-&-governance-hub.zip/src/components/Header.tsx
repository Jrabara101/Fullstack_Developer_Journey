import React from 'react';
import { Zap, Activity, ShieldCheck, Sparkles, Building2, Layers, Cpu, Scale, LineChart, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { PRESET_PROFILES } from '../data/cwvData';
import { PresetProfile } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedPreset: PresetProfile;
  onSelectPreset: (preset: PresetProfile) => void;
  onOpenAiAdvisor: () => void;
  overallStatus: {
    lcp: number;
    inp: number;
    cls: number;
    isPassing: boolean;
  };
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  selectedPreset,
  onSelectPreset,
  onOpenAiAdvisor,
  overallStatus,
}) => {
  const tabs = [
    { id: 'economics', label: '1. Financial ROI & Latency Tax', icon: LineChart },
    { id: 'cognitive', label: '2. Human Cognitive Journey', icon: Zap },
    { id: 'tag-governance', label: '3. Third-Party Script & GTM', icon: Layers },
    { id: 'lab-vs-field', label: '4. Lab (Lighthouse) vs Field (CrUX)', icon: Cpu },
    { id: 'culture-sla', label: '5. SLAs & Org Culture', icon: Scale },
  ];

  return (
    <header className="border-b border-[#141414] bg-[#E4E3E0] sticky top-0 z-40" id="cwv-main-header">
      {/* Top Industrial Environment Status Bar */}
      <div className="border-b border-[#141414] bg-white px-4 sm:px-6 lg:px-8 py-2 text-xs flex flex-wrap items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block animate-pulse"></span>
            <span className="text-[11px] font-bold tracking-tight text-[#141414]">REALTIME_SYNC_OK</span>
          </div>
          <span className="text-gray-400">|</span>
          <div className="flex items-center gap-2">
            <span className="font-serif-italic text-gray-600 text-xs normal-case">Current Environment:</span>
            <span className="bg-[#141414] text-white px-1.5 py-0.5 text-[11px] font-bold">
              PRODUCTION_MAIN
            </span>
          </div>
          <span className="text-gray-400 hidden sm:inline">|</span>
          <div className="hidden sm:flex items-center gap-1.5 text-gray-700 text-[11px]">
            <span className="font-serif-italic">Active Cohort:</span>
            <span className="font-bold">Mobile p75 (Rolling 28-Day CrUX)</span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <div>
            <span className="font-serif-italic text-gray-500 mr-1.5">Gate Status:</span>
            <span
              className={`font-bold px-1.5 py-0.5 border ${
                overallStatus.isPassing
                  ? 'border-emerald-700 bg-emerald-50 text-emerald-800'
                  : 'border-red-700 bg-red-50 text-red-800'
              }`}
            >
              {overallStatus.isPassing ? 'CRUX_PASS' : 'CRUX_FAIL'}
            </span>
          </div>
          <div className="text-right hidden md:block">
            <span className="text-gray-500 font-serif-italic">CrUX Engine v2026.8</span>
          </div>
        </div>
      </div>

      {/* Main Header & Metrics Ribbon */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 border border-[#141414] bg-[#141414] text-white flex items-center justify-center font-mono font-bold text-sm shrink-0">
            CWV
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-[#141414] uppercase">
                Core Web Vitals Executive &amp; Governance Hub
              </h1>
              <span className="text-[10px] font-mono border border-[#141414] px-1.5 py-0.5 bg-white text-[#141414] font-bold">
                HIGH_DENSITY
              </span>
            </div>
            <p className="text-xs font-serif-italic text-gray-700">
              Financial latency economics, human cognitive perception &amp; third-party GTM payload governance
            </p>
          </div>
        </div>

        {/* Global CWV Status Pills & Controls */}
        <div className="flex items-center flex-wrap gap-2.5">
          {/* Preset Selector */}
          <div className="flex items-center gap-1.5 bg-white border border-[#141414] px-2 py-1 text-xs shadow-xs">
            <Building2 className="w-3.5 h-3.5 text-gray-700" />
            <span className="font-serif-italic text-gray-600 text-xs hidden sm:inline">Profile:</span>
            <select
              id="preset-profile-select"
              value={selectedPreset.id}
              onChange={(e) => {
                const found = PRESET_PROFILES.find((p) => p.id === e.target.value);
                if (found) onSelectPreset(found);
              }}
              className="bg-transparent font-mono font-bold text-[#141414] text-xs outline-hidden cursor-pointer"
            >
              {PRESET_PROFILES.map((profile) => (
                <option key={profile.id} value={profile.id}>
                  {profile.name}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Metrics Badge */}
          <div className="flex items-center gap-2.5 bg-white border border-[#141414] px-3 py-1 text-xs">
            <div className="flex items-baseline gap-1">
              <span className="font-serif-italic text-[11px] text-gray-500">LCP:</span>
              <span
                className={`font-mono font-bold text-xs ${
                  overallStatus.lcp <= 2.5 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {overallStatus.lcp.toFixed(1)}s
              </span>
            </div>
            <span className="text-gray-300">/</span>
            <div className="flex items-baseline gap-1">
              <span className="font-serif-italic text-[11px] text-gray-500">INP:</span>
              <span
                className={`font-mono font-bold text-xs ${
                  overallStatus.inp <= 200 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {Math.round(overallStatus.inp)}ms
              </span>
            </div>
            <span className="text-gray-300">/</span>
            <div className="flex items-baseline gap-1">
              <span className="font-serif-italic text-[11px] text-gray-500">CLS:</span>
              <span
                className={`font-mono font-bold text-xs ${
                  overallStatus.cls <= 0.1 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {overallStatus.cls.toFixed(2)}
              </span>
            </div>
          </div>

          {/* AI Advisor Button */}
          <button
            id="btn-open-ai-advisor"
            onClick={onOpenAiAdvisor}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#141414] hover:bg-black active:bg-gray-800 text-white font-mono text-xs font-bold border border-[#141414] transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI_ADVISOR</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs - High Density Grid Bar */}
      <div className="border-t border-[#141414] bg-[#E4E3E0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex overflow-x-auto no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold whitespace-nowrap border-r border-[#141414] uppercase tracking-wider transition-all cursor-pointer ${
                  isActive
                    ? 'bg-white text-[#141414] border-b-2 border-b-[#141414]'
                    : 'text-gray-700 hover:text-black hover:bg-white/40'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#141414]' : 'text-gray-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
