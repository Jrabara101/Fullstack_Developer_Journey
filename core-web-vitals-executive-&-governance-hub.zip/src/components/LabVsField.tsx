import React from 'react';
import {
  Cpu,
  Smartphone,
  Laptop,
  Wifi,
  AlertOctagon,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  ReferenceLine,
} from 'recharts';

export const LabVsField: React.FC = () => {
  // Simulated CrUX Percentile Histogram Data
  const cruxDistributionData = [
    { percentile: 'p10', lcpSeconds: 1.1, category: 'Good', label: 'Fiber / M3 Mac' },
    { percentile: 'p25', lcpSeconds: 1.4, category: 'Good', label: 'iPhone / 5G' },
    { percentile: 'p50', lcpSeconds: 1.9, category: 'Good', label: 'Standard 4G / Android' },
    { percentile: 'p75 (CWV_GATE)', lcpSeconds: 2.7, category: 'Needs Improvement', label: 'Budget Phone / 4G' },
    { percentile: 'p90', lcpSeconds: 3.9, category: 'Needs Improvement', label: 'Throttled 3G' },
    { percentile: 'p99', lcpSeconds: 6.4, category: 'Poor', label: 'Congested Radio' },
  ];

  const dimensions = [
    {
      dimension: 'Testing Environment',
      lab: 'High-end developer machine (MacBook Pro M3), simulated 4G CPU throttling',
      field: 'Real devices (budget Androids, aging iPhones, enterprise laptops, low-RAM tablets)',
      icon: Laptop,
    },
    {
      dimension: 'Interaction Coverage',
      lab: 'Measures only the initial synthetic page load from zero state',
      field: 'Captures every tap, filter, search, and click across the entire multi-page user session',
      icon: Smartphone,
    },
    {
      dimension: 'Network Conditions',
      lab: 'Stable, synthetic packet delivery on corporate fiber Wi-Fi',
      field: 'Variable real-world conditions (spotty cellular, subway tunnels, congested public Wi-Fi)',
      icon: Wifi,
    },
    {
      dimension: 'Google Search Ranking Weight',
      lab: '0% Direct Weight (Used strictly for local developer debugging & CI smoke checks)',
      field: '100% of the Ranking Signal (Evaluated at the 75th percentile over a rolling 28-day window)',
      icon: AlertOctagon,
    },
  ];

  return (
    <div className="space-y-6" id="lab-vs-field-section">
      {/* High Density Section Header */}
      <div className="border border-[#141414] bg-white p-5 text-[#141414] shadow-xs">
        <div className="space-y-1.5 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-2 py-0.5 bg-[#141414] text-white text-[10px] font-mono font-bold uppercase tracking-wider">
            <Cpu className="w-3 h-3 text-amber-300" />
            <span>PILLAR_04 // LAB_VS_FIELD_CRUX</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#141414] uppercase">
            Lab Data (Lighthouse) vs Field Reality (CrUX p75)
          </h2>
          <p className="text-xs text-gray-700 font-serif-italic leading-relaxed">
            Automated synthetic CI audits on gigabit fiber do not reflect real field users on mid-tier hardware. Google Page Experience evaluates 100% field telemetry at p75.
          </p>
        </div>

        {/* Executive Rule Alert */}
        <div className="mt-4 border border-[#141414] bg-[#F0F0ED] p-3 text-xs text-[#141414] flex items-start gap-2.5">
          <AlertOctagon className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
          <div className="leading-snug">
            <strong className="font-mono font-bold text-black uppercase text-[11px] block">
              EXECUTIVE_RULE_P75:
            </strong>
            <span className="font-serif-italic">
              Never declare performance victory over a 100/100 Lighthouse score run on developer machines. Google ranking algorithms evaluate <strong>100% field RUM data at the 75th percentile (p75)</strong> across a rolling 28-day cohort of actual visitors.
            </span>
          </div>
        </div>
      </div>

      {/* Comparison Matrix Table */}
      <div className="border border-[#141414] bg-white overflow-hidden shadow-xs">
        <div className="p-4 border-b border-[#141414] bg-[#F0F0ED]">
          <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
            Synthetic Lab Audits vs Field RUM Telemetry
          </div>
          <p className="text-[11px] text-gray-600 font-serif-italic">
            Dimension-by-dimension breakdown between local CI testing and Google CrUX field data
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#141414]">
            <thead className="bg-[#F0F0ED] border-b border-[#141414] text-gray-700 uppercase font-mono text-[10px]">
              <tr>
                <th className="px-4 py-2.5 w-1/4">Evaluation Dimension</th>
                <th className="px-4 py-2.5 w-3/8 text-gray-700">Lab Data (Lighthouse CI)</th>
                <th className="px-4 py-2.5 w-3/8 text-black font-bold bg-[#E4E3E0]/40">
                  Field Reality (CrUX 28-Day p75)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {dimensions.map((row, idx) => {
                const Icon = row.icon;
                return (
                  <tr key={idx} className="hover:bg-[#F0F0ED]/50 transition-colors">
                    <td className="px-4 py-3 font-mono font-bold text-[#141414] flex items-center gap-2">
                      <Icon className="w-3.5 h-3.5 text-black shrink-0" />
                      <span>{row.dimension}</span>
                    </td>
                    <td className="px-4 py-3 text-gray-700 font-serif-italic leading-snug">
                      {row.lab}
                    </td>
                    <td className="px-4 py-3 text-black font-bold font-serif-italic leading-snug bg-[#E4E3E0]/20 border-l border-gray-300">
                      {row.field}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* The P75 Distribution Visualizer Chart */}
      <div className="border border-[#141414] bg-white p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-gray-200">
          <div>
            <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
              Why 75% of Real Traffic (p75) Dictates Google Ranking
            </div>
            <p className="text-[11px] text-gray-600 font-serif-italic">
              Distribution of real page loads across devices and network realities
            </p>
          </div>
          <div className="font-mono text-xs px-2 py-1 bg-[#141414] text-white font-bold">
            GOOGLE_GATE: LCP &le; 2.50s @ p75
          </div>
        </div>

        {/* Histogram */}
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={cruxDistributionData}
              margin={{ top: 20, right: 15, left: -20, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="2 2" stroke="#E4E3E0" />
              <XAxis
                dataKey="percentile"
                tick={{ fontSize: 10, fill: '#141414', fontFamily: 'monospace', fontWeight: 'bold' }}
                interval={0}
              />
              <YAxis
                unit="s"
                tick={{ fontSize: 10, fill: '#141414', fontFamily: 'monospace' }}
                domain={[0, 7]}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className="border border-[#141414] bg-white p-2.5 text-xs font-mono shadow-md space-y-0.5">
                        <p className="font-bold text-[#141414]">{d.percentile}</p>
                        <p className="text-gray-600">Cohort: {d.label}</p>
                        <p>
                          LCP: <strong className="text-black">{d.lcpSeconds}s</strong> ({d.category})
                        </p>
                        <p className="text-[10px] text-gray-500">
                          {d.lcpSeconds <= 2.5 ? 'STATUS: CWV_PASS' : 'STATUS: CWV_FAIL'}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <ReferenceLine
                y={2.5}
                stroke="#15803d"
                strokeDasharray="3 3"
                strokeWidth={2}
                label={{ value: '2.5s LCP Threshold', position: 'top', fill: '#15803d', fontSize: 10, fontFamily: 'monospace', fontWeight: 'bold' }}
              />
              <Bar dataKey="lcpSeconds">
                {cruxDistributionData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={
                      entry.percentile.includes('p75')
                        ? entry.lcpSeconds <= 2.5 ? '#15803d' : '#b91c1c'
                        : entry.lcpSeconds <= 2.5
                        ? '#141414'
                        : '#71717a'
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div className="border border-gray-300 bg-[#F0F0ED] p-3 text-xs space-y-1">
            <span className="font-mono font-bold text-[#141414] uppercase text-[11px] block">
              THE_CORPORATE_WIFI_FALLACY:
            </span>
            <p className="text-gray-700 font-serif-italic leading-snug">
              When internal stakeholders test the app on gigabit office Wi-Fi, they test within the <strong>p10 (1.1s)</strong> cohort. They assume the site is fast, unaware that 25% of mobile customers at <strong>p75 (2.7s)</strong> are hitting bounce triggers.
            </p>
          </div>

          <div className="border border-gray-300 bg-white p-3 text-xs space-y-1 text-[#141414]">
            <span className="font-mono font-bold text-black uppercase text-[11px] block">
              ENGINEERING_SLA_FOR_P75:
            </span>
            <p className="font-serif-italic leading-snug text-gray-700">
              Target testing on mid-tier Android devices throttled to 4G in Chrome DevTools. If your p75 cohort passes Core Web Vitals, 75% of all traffic experiences sub-second speed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
