import React, { useState } from 'react';
import {
  Scale,
  CheckCircle2,
  Lock,
  FileText,
  Copy,
  Code2,
  Palette,
  Briefcase,
  Sparkles,
} from 'lucide-react';
import { SlaRule } from '../types';
import { INITIAL_SLA_RULES } from '../data/cwvData';

interface OrgCultureSLAsProps {
  onOpenAiAdvisor: () => void;
  lcp: number;
  inp: number;
  cls: number;
  annualRevenueLift: number;
}

export const OrgCultureSLAs: React.FC<OrgCultureSLAsProps> = ({
  onOpenAiAdvisor,
  lcp,
  inp,
  cls,
  annualRevenueLift,
}) => {
  const [slaRules, setSlaRules] = useState<SlaRule[]>(INITIAL_SLA_RULES);
  const [copied, setCopied] = useState<boolean>(false);
  const [activeDepartment, setActiveDepartment] = useState<'all' | 'engineering' | 'design' | 'product'>('all');

  const toggleEnforce = (id: string) => {
    setSlaRules((prev) =>
      prev.map((rule) => (rule.id === id ? { ...rule, isEnforced: !rule.isEnforced } : rule))
    );
  };

  const filteredRules =
    activeDepartment === 'all'
      ? slaRules
      : slaRules.filter((r) => r.category === activeDepartment);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Generate Executive Boardroom Memo text
  const generateExecutiveMemo = () => {
    return `# EXECUTIVE MEMO: Core Web Vitals Governance & ROI Policy
**TO:** Chief Executive Officer, Chief Financial Officer, Chief Product Officer
**FROM:** VP of Engineering & Product Governance
**DATE:** ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
**SUBJECT:** Core Web Vitals Performance SLAs & Financial Value Realization

## 1. Executive Summary & Financial Impact
Web performance is a financial and product governance discipline. Every 100ms of latency reduction directly accelerates checkout conversion funnels and protects search rankings.
- **Current P75 LCP:** ${lcp.toFixed(2)}s (${lcp <= 2.5 ? 'Passing' : 'Failing'})
- **Current P75 INP:** ${Math.round(inp)}ms (${inp <= 200 ? 'Passing' : 'Failing'})
- **Current P75 CLS:** ${cls.toFixed(2)} (${cls <= 0.1 ? 'Passing' : 'Failing'})
- **Projected Annual Value Lift:** ${formatCurrency(annualRevenueLift)} / year

## 2. Cross-Functional SLAs & Release Gates
1. **Engineering Release Blockers:**
   - Client JS Bundle Cap: Hard limit < 180 KB gzipped. Pull requests breaching budget are blocked in CI.
   - Long Task Elimination: Max main-thread task execution < 50ms to protect sub-200ms INP.
2. **Design System Governance:**
   - 100% of media and banners must render in reserved aspect-ratio containers to guarantee Zero CLS (0.00).
3. **Product & Marketing Tag Governance:**
   - Quarterly Third-Party Tag ROI Audit: Every marketing script in GTM must mathematically justify its revenue vs conversion latency tax.
   - 20% Sprint Allocation reserved for performance debt and core vital maintenance.

## 3. Human Experience & Trust
Core Web Vitals represent human cognitive states:
- LCP (<2.5s) delivers Trust & Relief ("Is this page useful yet?")
- INP (<200ms) preserves Competence & Flow ("Is this interface responsive?")
- CLS (<0.10) guarantees Safety & Physical Control ("Is this interface stable?")
`;
  };

  const copyMemoToClipboard = () => {
    navigator.clipboard.writeText(generateExecutiveMemo());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6" id="culture-sla-section">
      {/* High Density Section Header */}
      <div className="border border-[#141414] bg-white p-5 text-[#141414] shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
          <div className="space-y-1.5 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-2 py-0.5 bg-[#141414] text-white text-[10px] font-mono font-bold uppercase tracking-wider">
              <Scale className="w-3 h-3 text-amber-300" />
              <span>PILLAR_05 // SLA_CULTURE_GOVERNANCE</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#141414] uppercase">
              Organizational Performance Culture &amp; Cross-Functional SLAs
            </h2>
            <p className="text-xs text-gray-700 font-serif-italic leading-relaxed">
              Performance is a continuous organizational discipline. Sustained speed requires hard CI/CD release gates, shared ownership between Product and Design, and executive ROI alignment.
            </p>
          </div>

          <button
            onClick={onOpenAiAdvisor}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#141414] hover:bg-black text-white font-mono font-bold text-xs border border-[#141414] cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI_EXECUTIVE_BRIEF</span>
          </button>
        </div>
      </div>

      {/* The Three Pillars of SLA Ownership */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="border border-[#141414] bg-white p-4 space-y-2">
          <div className="flex items-center justify-between font-mono">
            <span className="font-bold text-xs uppercase text-[#141414] flex items-center gap-1.5">
              <Code2 className="w-3.5 h-3.5 text-black" />
              <span>Engineering</span>
            </span>
            <span className="text-[9px] bg-[#141414] text-white px-1.5 py-0.5 font-bold">
              CI_GATES
            </span>
          </div>
          <p className="text-xs text-gray-700 font-serif-italic leading-snug">
            Automate bundle size budgets, image compression gates, and main-thread task execution caps in GitHub Actions. PRs exceeding limits cannot merge.
          </p>
        </div>

        <div className="border border-[#141414] bg-white p-4 space-y-2">
          <div className="flex items-center justify-between font-mono">
            <span className="font-bold text-xs uppercase text-[#141414] flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-black" />
              <span>Design System</span>
            </span>
            <span className="text-[9px] bg-[#141414] text-white px-1.5 py-0.5 font-bold">
              ASPECT_LOCK
            </span>
          </div>
          <p className="text-xs text-gray-700 font-serif-italic leading-snug">
            Designers commit to specifying exact container aspect ratios, skeleton loaders, and fallback font metrics before dynamic media renders, eliminating layout shift.
          </p>
        </div>

        <div className="border border-[#141414] bg-white p-4 space-y-2">
          <div className="flex items-center justify-between font-mono">
            <span className="font-bold text-xs uppercase text-[#141414] flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-black" />
              <span>Product &amp; GTM</span>
            </span>
            <span className="text-[9px] bg-[#141414] text-white px-1.5 py-0.5 font-bold">
              20%_SPRINT_SLA
            </span>
          </div>
          <p className="text-xs text-gray-700 font-serif-italic leading-snug">
            Product managers reserve 1 in 5 story points for speed debt, while marketing conducts quarterly audits to prune abandoned tags and justify new scripts against conversion loss.
          </p>
        </div>
      </div>

      {/* SLA Policy Enforcer Rules Grid */}
      <div className="border border-[#141414] bg-white overflow-hidden shadow-xs">
        <div className="p-4 border-b border-[#141414] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#F0F0ED]">
          <div>
            <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
              Organizational SLA Policies &amp; Gate Enforcement
            </div>
            <p className="text-[11px] text-gray-600 font-serif-italic">
              Configure and enforce automated cross-department performance contracts
            </p>
          </div>

          <div className="flex items-center gap-1 font-mono text-xs">
            {(['all', 'engineering', 'design', 'product'] as const).map((dept) => (
              <button
                key={dept}
                onClick={() => setActiveDepartment(dept)}
                className={`px-2.5 py-1 uppercase font-bold border transition-all cursor-pointer ${
                  activeDepartment === dept
                    ? 'border-[#141414] bg-[#141414] text-white'
                    : 'border-[#141414]/40 bg-white text-[#141414] hover:bg-gray-100'
                }`}
              >
                {dept}
              </button>
            ))}
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {filteredRules.map((rule) => (
            <div
              key={rule.id}
              className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#F0F0ED]/50 transition-colors"
            >
              <div className="space-y-0.5 max-w-2xl">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase bg-[#141414] text-white">
                    {rule.category}
                  </span>
                  <h4 className="font-bold text-[#141414] text-xs font-mono">{rule.title}</h4>
                  <span className="font-mono text-[10px] text-gray-600 border border-gray-300 px-1.5 py-0.5">
                    Target: {rule.target}
                  </span>
                </div>
                <p className="text-xs text-gray-700 font-serif-italic leading-snug">{rule.description}</p>
                <div className="text-[10px] font-mono text-gray-500">
                  <span>Rationale: {rule.rationale}</span>
                </div>
              </div>

              <div className="shrink-0">
                <button
                  onClick={() => toggleEnforce(rule.id)}
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs font-mono font-bold border cursor-pointer ${
                    rule.isEnforced
                      ? 'border-[#141414] bg-[#141414] text-white'
                      : 'border-gray-300 bg-white text-gray-600 hover:text-black'
                  }`}
                >
                  {rule.isEnforced ? (
                    <>
                      <Lock className="w-3 h-3 text-amber-300" />
                      <span>ENFORCED_BLOCKER</span>
                    </>
                  ) : (
                    <span>ADVISORY_ONLY</span>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Executive Briefing Memo Preview */}
      <div className="border border-[#141414] bg-[#141414] p-5 text-white shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-gray-700">
          <div>
            <div className="flex items-center gap-1.5 font-mono text-xs text-amber-300 font-bold uppercase">
              <FileText className="w-3.5 h-3.5" />
              <span>Executive Core Web Vitals Boardroom Memo</span>
            </div>
            <p className="text-[11px] text-gray-400 font-serif-italic">
              Translating milliseconds into dollars for executive and board governance
            </p>
          </div>

          <button
            onClick={copyMemoToClipboard}
            className="flex items-center gap-1.5 px-3 py-1 bg-white hover:bg-gray-100 text-[#141414] font-mono text-xs font-bold cursor-pointer"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                <span>COPIED_TO_CLIPBOARD</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-black" />
                <span>COPY_MARKDOWN_MEMO</span>
              </>
            )}
          </button>
        </div>

        <div className="border border-gray-700 bg-black p-3.5 font-mono text-[11px] text-gray-300 overflow-x-auto max-h-72 leading-relaxed">
          <pre className="whitespace-pre-wrap">{generateExecutiveMemo()}</pre>
        </div>
      </div>
    </div>
  );
};
