import React, { useState } from 'react';
import {
  Layers,
  Sparkles,
  CheckCircle2,
  MessageSquare,
  Plus,
} from 'lucide-react';
import { ThirdPartyScript, TagTier } from '../types';

interface TagGovernanceProps {
  scripts: ThirdPartyScript[];
  setScripts: React.Dispatch<React.SetStateAction<ThirdPartyScript[]>>;
  onOpenAiAudit: () => void;
}

export const TagGovernance: React.FC<TagGovernanceProps> = ({
  scripts,
  setScripts,
  onOpenAiAudit,
}) => {
  const [facadeLoaded, setFacadeLoaded] = useState<boolean>(false);
  const [newTagName, setNewTagName] = useState<string>('');
  const [newTagCategory, setNewTagCategory] = useState<ThirdPartyScript['category']>('advertising');
  const [newTagSize, setNewTagSize] = useState<number>(120);

  // Baseline engineering payload
  const engineeringPayloadKb = 150;
  const engineeringLcpMs = 1100;
  const engineeringInpMs = 35;

  // Calculate composite impact based on applied tags and tiering
  const calculateImpact = () => {
    let thirdPartyKb = 0;
    let lcpPenaltyMs = 0;
    let inpPenaltyMs = 0;

    scripts.forEach((script) => {
      if (!script.isApplied) return;

      if (script.currentTier === 'deprecated') {
        return;
      }

      if (script.currentTier === 'tier-1') {
        thirdPartyKb += script.sizeKb;
        lcpPenaltyMs += script.lcpImpactMs * 0.45;
        inpPenaltyMs += script.inpImpactMs * 0.3;
      } else if (script.currentTier === 'tier-2') {
        thirdPartyKb += script.sizeKb;
        lcpPenaltyMs += 0;
        inpPenaltyMs += script.inpImpactMs * 0.25;
      } else if (script.currentTier === 'tier-3') {
        thirdPartyKb += 4;
        lcpPenaltyMs += 10;
        inpPenaltyMs += 5;
      }
    });

    const totalPayloadKb = engineeringPayloadKb + thirdPartyKb;
    const totalLcpSeconds = (engineeringLcpMs + lcpPenaltyMs) / 1000;
    const totalInpMs = engineeringInpMs + inpPenaltyMs;
    const passesCwv = totalLcpSeconds <= 2.5 && totalInpMs <= 200;

    return {
      totalPayloadKb,
      thirdPartyKb,
      totalLcpSeconds,
      totalInpMs,
      passesCwv,
    };
  };

  const impact = calculateImpact();

  const handleTierChange = (scriptId: string, newTier: TagTier) => {
    setScripts((prev) =>
      prev.map((s) => (s.id === scriptId ? { ...s, currentTier: newTier } : s))
    );
  };

  const handleToggleScript = (scriptId: string) => {
    setScripts((prev) =>
      prev.map((s) => (s.id === scriptId ? { ...s, isApplied: !s.isApplied } : s))
    );
  };

  const applyRecommendedTiers = () => {
    setScripts((prev) =>
      prev.map((s) => ({
        ...s,
        currentTier: s.defaultTier,
      }))
    );
  };

  const resetToUnmanagedBloat = () => {
    setScripts((prev) =>
      prev.map((s) => ({
        ...s,
        currentTier: 'tier-1',
        isApplied: true,
      }))
    );
  };

  const handleAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName) return;

    const newScript: ThirdPartyScript = {
      id: `custom-${Date.now()}`,
      name: newTagName,
      vendor: 'Custom Vendor',
      category: newTagCategory,
      sizeKb: newTagSize,
      lcpImpactMs: Math.round(newTagSize * 2.8),
      inpImpactMs: Math.round(newTagSize * 0.6),
      defaultTier: 'tier-2',
      currentTier: 'tier-2',
      revenueJustification: 'Custom marketing tag under audit review.',
      isApplied: true,
    };

    setScripts((prev) => [newScript, ...prev]);
    setNewTagName('');
  };

  return (
    <div className="space-y-6" id="tag-governance-section">
      {/* High Density Section Header */}
      <div className="border border-[#141414] bg-white p-5 text-[#141414] shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
          <div className="space-y-1.5 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-2 py-0.5 bg-[#141414] text-white text-[10px] font-mono font-bold uppercase tracking-wider">
              <Layers className="w-3 h-3 text-amber-300" />
              <span>PILLAR_03 // GTM_TAG_GOVERNANCE</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#141414] uppercase">
              Strategic Tag Governance &amp; Payload Tiering
            </h2>
            <p className="text-xs text-gray-700 font-serif-italic leading-relaxed">
              Unmanaged GTM tag bloat accounts for over 70% of Core Web Vitals degradation. Implement 3-tier lifecycle management and facade patterns.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={applyRecommendedTiers}
              className="px-3 py-1.5 bg-[#141414] hover:bg-black text-white font-mono font-bold text-xs cursor-pointer"
            >
              APPLY_3_TIER_SLA
            </button>
            <button
              onClick={resetToUnmanagedBloat}
              className="px-3 py-1.5 border border-[#141414] bg-white hover:bg-gray-100 text-[#141414] font-mono font-bold text-xs cursor-pointer"
            >
              SIMULATE_GTM_BLOAT
            </button>
          </div>
        </div>
      </div>

      {/* Payload Waterfall Visualizer Bar */}
      <div className="border border-[#141414] bg-white p-5 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-gray-200">
          <div>
            <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
              Payload &amp; Waterfall Impact Analysis
            </div>
            <p className="text-[11px] text-gray-600 font-serif-italic">
              Clean Engineering App Shell vs Third-Party GTM Injections
            </p>
          </div>
          <div className="flex items-center gap-4 font-mono">
            <div>
              <span className="text-[10px] text-gray-500 font-serif-italic block">Total Payload:</span>
              <span className="text-xs font-bold text-[#141414]">{impact.totalPayloadKb} KB</span>
            </div>
            <div>
              <span className="text-[10px] text-gray-500 font-serif-italic block">Simulated LCP:</span>
              <span
                className={`text-xs font-bold ${
                  impact.totalLcpSeconds <= 2.5 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {impact.totalLcpSeconds.toFixed(2)}s
              </span>
            </div>
            <div>
              <span className="text-[10px] text-gray-500 font-serif-italic block">Simulated INP:</span>
              <span
                className={`text-xs font-bold ${
                  impact.totalInpMs <= 200 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {Math.round(impact.totalInpMs)}ms
              </span>
            </div>
          </div>
        </div>

        {/* Stacked Bar Visualizer */}
        <div className="space-y-1.5">
          <div className="h-5 w-full bg-gray-200 border border-[#141414] overflow-hidden flex">
            <div
              style={{ width: `${Math.min(100, (engineeringPayloadKb / impact.totalPayloadKb) * 100)}%` }}
              className="bg-[#141414] h-full flex items-center justify-center text-[9px] text-white font-mono font-bold px-1 truncate"
              title="Engineering App Shell (150 KB)"
            >
              APP_SHELL (150 KB)
            </div>
            <div
              style={{ width: `${Math.min(100, (impact.thirdPartyKb / impact.totalPayloadKb) * 100)}%` }}
              className="bg-[#F0F0ED] border-l border-[#141414] h-full flex items-center justify-center text-[9px] text-[#141414] font-mono font-bold px-1 truncate"
              title={`Third-Party Scripts (${impact.thirdPartyKb} KB)`}
            >
              3RD_PARTY ({impact.thirdPartyKb} KB)
            </div>
          </div>
          <div className="flex justify-between text-[10px] font-mono text-gray-600">
            <span>[■] Internal Engineered Bundle (150 KB)</span>
            <span>[□] GTM Marketing/Tracking Injections ({impact.thirdPartyKb} KB)</span>
          </div>
        </div>
      </div>

      {/* 3-Tier Governance Explainer Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="border border-[#141414] bg-white p-3.5">
          <div className="flex items-center justify-between mb-1.5 font-mono">
            <span className="font-bold bg-[#141414] text-white px-1.5 py-0.5 text-[10px]">
              TIER 1: ESSENTIAL
            </span>
            <span className="text-[10px] text-gray-500">ASYNC_EXEC</span>
          </div>
          <h4 className="font-bold text-xs text-[#141414] uppercase mb-1">
            Core Analytics &amp; GDPR Consent
          </h4>
          <p className="text-xs text-gray-700 font-serif-italic leading-snug">
            Loaded asynchronously without blocking the critical HTML parse tree. Reserved strictly for cookie consent and baseline Google Analytics 4.
          </p>
        </div>

        <div className="border border-[#141414] bg-white p-3.5">
          <div className="flex items-center justify-between mb-1.5 font-mono">
            <span className="font-bold bg-[#141414] text-white px-1.5 py-0.5 text-[10px]">
              TIER 2: DEFERRED
            </span>
            <span className="text-[10px] text-gray-500">POST_LCP_HOOK</span>
          </div>
          <h4 className="font-bold text-xs text-[#141414] uppercase mb-1">
            Heatmaps &amp; Retargeting Pixels
          </h4>
          <p className="text-xs text-gray-700 font-serif-italic leading-snug">
            Deferred until after first user touch or scroll event, or post-LCP paint. Meta, TikTok, and Hotjar run completely off the critical render path.
          </p>
        </div>

        <div className="border border-[#141414] bg-white p-3.5">
          <div className="flex items-center justify-between mb-1.5 font-mono">
            <span className="font-bold bg-[#141414] text-white px-1.5 py-0.5 text-[10px]">
              TIER 3: FACADE
            </span>
            <span className="text-[10px] text-gray-500">ON_DEMAND_CLICK</span>
          </div>
          <h4 className="font-bold text-xs text-[#141414] uppercase mb-1">
            Heavy Chat (Intercom/Zendesk)
          </h4>
          <p className="text-xs text-gray-700 font-serif-italic leading-snug">
            Replaced with a zero-cost ~4KB static SVG launcher button. The heavy 1.8MB SDK downloads ONLY when the user actively initiates chat!
          </p>
        </div>
      </div>

      {/* Script Catalog Table & Tier Reassignment */}
      <div className="border border-[#141414] bg-white overflow-hidden shadow-xs">
        <div className="p-4 border-b border-[#141414] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#F0F0ED]">
          <div>
            <div className="font-serif-italic uppercase text-xs opacity-70 font-bold tracking-wider">
              Third-Party Tag Catalog &amp; Budget Gate
            </div>
            <p className="text-[11px] text-gray-600 font-serif-italic">
              Audit vendor scripts, reassign governance tiers, and enforce revenue justification
            </p>
          </div>
          <button
            onClick={onOpenAiAudit}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#141414] text-white font-mono text-xs font-bold cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI_TAG_AUDIT</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#141414]">
            <thead className="bg-[#F0F0ED] border-b border-[#141414] text-gray-700 uppercase font-mono text-[10px]">
              <tr>
                <th className="px-3 py-2.5">Vendor &amp; Script Name</th>
                <th className="px-2.5 py-2.5">Category</th>
                <th className="px-2.5 py-2.5">Size</th>
                <th className="px-2.5 py-2.5">Penalty</th>
                <th className="px-3 py-2.5">Governance Tier</th>
                <th className="px-3 py-2.5 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {scripts.map((script) => (
                <tr
                  key={script.id}
                  className={`hover:bg-[#F0F0ED]/60 transition-colors ${
                    !script.isApplied || script.currentTier === 'deprecated' ? 'opacity-40 bg-gray-100' : ''
                  }`}
                >
                  <td className="px-3 py-2.5">
                    <div className="font-bold text-[#141414] font-mono">{script.name}</div>
                    <div className="text-[10px] text-gray-600 font-serif-italic">{script.revenueJustification}</div>
                  </td>
                  <td className="px-2.5 py-2.5">
                    <span className="uppercase px-1.5 py-0.5 bg-gray-200 text-gray-800 text-[9px] font-mono font-bold">
                      {script.category}
                    </span>
                  </td>
                  <td className="px-2.5 py-2.5 font-mono font-bold">
                    {script.sizeKb} KB
                  </td>
                  <td className="px-2.5 py-2.5 font-mono text-[10px]">
                    <span className="text-red-700">+{script.lcpImpactMs}ms LCP</span>{' '}
                    <span className="text-gray-500">/</span>{' '}
                    <span className="text-red-700">+{script.inpImpactMs}ms INP</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <select
                      value={script.currentTier}
                      onChange={(e) => handleTierChange(script.id, e.target.value as TagTier)}
                      className="bg-white border border-[#141414] px-2 py-1 text-xs font-mono font-bold text-[#141414] focus:outline-hidden cursor-pointer"
                    >
                      <option value="tier-1">Tier 1: Essential (Async)</option>
                      <option value="tier-2">Tier 2: Defer Post-LCP</option>
                      <option value="tier-3">Tier 3: Facade / Click</option>
                      <option value="deprecated">Deprecated / Remove</option>
                    </select>
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <button
                      onClick={() => handleToggleScript(script.id)}
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 border cursor-pointer ${
                        script.isApplied
                          ? 'border-red-700 bg-red-50 text-red-800 hover:bg-red-100'
                          : 'border-emerald-700 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                      }`}
                    >
                      {script.isApplied ? 'DISABLE' : 'ENABLE'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add Tag Form */}
        <div className="p-3.5 bg-[#F0F0ED] border-t border-[#141414]">
          <form onSubmit={handleAddTag} className="flex flex-wrap items-center gap-2.5">
            <span className="text-xs font-mono font-bold text-[#141414]">ADD_TAG:</span>
            <input
              type="text"
              placeholder="Tag Name (e.g. Criteo)"
              value={newTagName}
              onChange={(e) => setNewTagName(e.target.value)}
              className="px-2.5 py-1 text-xs font-mono bg-white border border-[#141414] focus:outline-hidden min-w-[180px]"
            />
            <select
              value={newTagCategory}
              onChange={(e) => setNewTagCategory(e.target.value as any)}
              className="px-2 py-1 text-xs font-mono bg-white border border-[#141414] focus:outline-hidden"
            >
              <option value="analytics">analytics</option>
              <option value="advertising">advertising</option>
              <option value="session-recording">session-recording</option>
              <option value="customer-support">customer-support</option>
            </select>
            <input
              type="number"
              placeholder="Size (KB)"
              value={newTagSize}
              onChange={(e) => setNewTagSize(Number(e.target.value))}
              className="w-20 px-2 py-1 text-xs font-mono bg-white border border-[#141414] focus:outline-hidden"
            />
            <button
              type="submit"
              className="flex items-center gap-1 px-3 py-1 bg-[#141414] text-white font-mono text-xs font-bold cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>SUBMIT</span>
            </button>
          </form>
        </div>
      </div>

      {/* Support Chat Facade Pattern Demo */}
      <div className="border border-[#141414] bg-[#141414] p-5 text-white shadow-xs">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-7 space-y-2">
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 text-[10px] font-mono font-bold bg-white text-black">
              <MessageSquare className="w-3 h-3" />
              <span>ENGINEERING_PATTERN // FACADE_LAUNCHER</span>
            </div>
            <h4 className="text-base font-bold tracking-tight uppercase">
              The "Facade Pattern" for Heavy Support Chat Widgets
            </h4>
            <p className="text-xs text-gray-300 font-serif-italic leading-relaxed">
              Standard Intercom or Zendesk widgets inject <strong>1.8 MB to 3.2 MB</strong> of JavaScript and trigger massive DOM mutations before the user ever initiates a query. The Facade pattern ships a zero-cost 4KB static SVG button. Heavy bundles load strictly on-demand.
            </p>

            <div className="pt-1 flex flex-wrap items-center gap-3 text-[11px] font-mono">
              <div className="flex items-center gap-1 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>-1.2s LCP</span>
              </div>
              <div className="flex items-center gap-1 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>-240ms INP</span>
              </div>
              <div className="flex items-center gap-1 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>-1,846 KB INITIAL JS</span>
              </div>
            </div>
          </div>

          {/* Interactive Facade Demo Button */}
          <div className="lg:col-span-5 border border-gray-600 bg-black/40 p-4 text-center space-y-2.5">
            <span className="text-[11px] font-mono text-gray-300 block">
              LIVE_FACADE_DEMO:
            </span>

            {facadeLoaded ? (
              <div className="bg-white text-[#141414] p-3 text-xs space-y-1.5 border border-gray-400 font-mono">
                <div className="flex items-center justify-between font-bold border-b border-gray-200 pb-1">
                  <span>LIVE_SUPPORT_CONNECTED</span>
                  <button
                    onClick={() => setFacadeLoaded(false)}
                    className="text-gray-500 hover:text-black text-xs font-bold cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
                <p className="text-gray-700 text-[11px] font-serif-italic">
                  "Support agent available. How may we assist your order?"
                </p>
                <div className="text-[10px] text-emerald-800 font-bold">
                  ✓ 1.85 MB SDK loaded dynamically post-click.
                </div>
              </div>
            ) : (
              <button
                onClick={() => setFacadeLoaded(true)}
                className="w-full py-3 px-4 bg-white hover:bg-gray-100 text-[#141414] font-mono font-bold text-xs border border-white transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-black" />
                <span>CHAT_WITH_SUPPORT (FACADE_LAUNCHER)</span>
              </button>
            )}

            <span className="text-[10px] font-mono text-gray-400 block">
              {facadeLoaded ? 'STATUS: SESSION_ACTIVE' : 'INITIAL JS PAYLOAD COST: 0 KB'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
