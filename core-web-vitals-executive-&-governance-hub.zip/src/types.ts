export type CwvMetricType = 'LCP' | 'INP' | 'CLS';

export interface CwvThresholds {
  good: number;
  needsImprovement: number;
  poor: number;
  unit: string;
}

export interface MetricDefinition {
  id: CwvMetricType;
  name: string;
  fullName: string;
  question: string;
  humanReality: string;
  psychologicalState: string;
  targetThreshold: string;
  unit: string;
  goodThreshold: number;
  poorThreshold: number;
  rankingWeight: string;
  iconName: string;
  gradient: string;
}

export interface FinancialModelInputs {
  monthlyTraffic: number;
  mobileSharePercent: number;
  baselineConversionRate: number;
  averageOrderValue: number;
  currentLcpMs: number;
  targetLcpMs: number;
  currentInpMs: number;
  targetInpMs: number;
  currentCls: number;
  targetCls: number;
  conversionDropPer100ms: number; // e.g. 1.5%
}

export interface FinancialCalculationResult {
  monthlyRevenueBaseline: number;
  projectedMonthlyRevenue: number;
  monthlyRevenueDelta: number;
  annualRevenueDelta: number;
  conversionsSavedMonthly: number;
  cartAbandonmentReductionPercent: number;
  preventedMisclickChargebacksCost: number;
  seoRankingProbability: number;
}

export type TagTier = 'tier-1' | 'tier-2' | 'tier-3' | 'deprecated';

export interface ThirdPartyScript {
  id: string;
  name: string;
  vendor: string;
  category: 'analytics' | 'advertising' | 'session-recording' | 'customer-support' | 'consent';
  sizeKb: number;
  lcpImpactMs: number;
  inpImpactMs: number;
  defaultTier: TagTier;
  currentTier: TagTier;
  revenueJustification: string;
  isFacadeAvailable?: boolean;
  isApplied: boolean;
}

export interface SlaRule {
  id: string;
  category: 'engineering' | 'design' | 'product';
  title: string;
  target: string;
  isEnforced: boolean;
  description: string;
  rationale: string;
}

export interface PresetProfile {
  id: string;
  name: string;
  description: string;
  monthlyTraffic: number;
  mobileShare: number;
  baselineCr: number;
  aov: number;
  currentLcp: number;
  targetLcp: number;
  currentInp: number;
  targetInp: number;
  currentCls: number;
  targetCls: number;
}
