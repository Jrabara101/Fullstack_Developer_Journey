import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// API endpoint to start the adventure
app.post("/api/adventure/start", async (req, res) => {
  try {
    const { character, artStyle, setting, modelName = "gemini-3.5-flash" } = req.body;

    const prompt = `
      You are the Dungeon Master of an infinite choose-your-own-adventure game.
      
      Start a new adventure with the following configuration:
      - Character Name: ${character.name}
      - Character Class: ${character.classType}
      - Character Background: ${character.background}
      - Character Visual Description: ${character.description}
      - Adventure Setting: ${setting}
      
      Generate the very first scene of the adventure. The scene must:
      1. Establish the atmosphere based on the setting.
      2. Hook the player with an immediate situation or discovery.
      3. Introduce an initial quest or goal.
      4. Give the player some basic starting inventory relevant to their class and background.
      
      You must respond with a JSON object matching this schema exactly:
      {
        "narrative": "A rich 2-3 paragraph introductory story segment introducing the setting, the character, and the initial predicament.",
        "imagePrompt": "A highly detailed visual scene description for generating an illustration of this start. Avoid abstract words, describe specific characters, clothing, posture, and environmental features.",
        "choices": ["Action choice 1", "Action choice 2", "Action choice 3", "Action choice 4"],
        "startingQuests": [
          {
            "title": "Title of the main quest",
            "description": "Short description of what the player needs to accomplish."
          }
        ],
        "startingInventory": [
          {
            "name": "Item Name",
            "description": "Short description of the starting item.",
            "quantity": 1
          }
        ]
      }
    `;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            narrative: { type: Type.STRING },
            imagePrompt: { type: Type.STRING },
            choices: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            startingQuests: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ["title", "description"]
              }
            },
            startingInventory: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  quantity: { type: Type.INTEGER }
                },
                required: ["name", "description", "quantity"]
              }
            }
          },
          required: ["narrative", "imagePrompt", "choices", "startingQuests", "startingInventory"]
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    res.json(data);
  } catch (error: any) {
    console.error("Error starting adventure:", error);
    res.status(500).json({ error: error.message || "Failed to start adventure." });
  }
});

// API endpoint to continue the adventure based on player choice
app.post("/api/adventure/continue", async (req, res) => {
  try {
    const {
      character,
      artStyle,
      setting,
      choice,
      history,
      currentQuests,
      inventory,
      modelName = "gemini-3.5-flash"
    } = req.body;

    // Build history context
    const historyText = history
      .slice(-6) // Keep the last 6 steps to preserve enough context without bloating
      .map((seg: any, idx: number) => `Scene ${idx + 1}: ${seg.narrative}\nPlayer's Choice: ${seg.selectedChoice || 'None'}`)
      .join("\n\n");

    const prompt = `
      You are the Dungeon Master of an infinite choose-your-own-adventure game.
      
      The player is continuing their journey.
      
      === CHARACTER INFO ===
      Name: ${character.name}
      Class: ${character.classType}
      Description: ${character.description}
      Background: ${character.background}
      
      === CURRENT ADVENTURE SETTING ===
      ${setting}
      
      === ADVENTURE HISTORY ===
      ${historyText}
      
      === PLAYER'S CHOSEN ACTION ===
      "${choice}"
      
      === CURRENT QUESTS ===
      ${JSON.stringify(currentQuests)}
      
      === CURRENT INVENTORY ===
      ${JSON.stringify(inventory)}
      
      === INSTRUCTIONS ===
      1. Write the next narrative segment based on how the player's action unfolds. Choices must genuinely alter the upcoming plot, leading to unique consequences, challenges, or rewards.
      2. If the action succeeds or fails, describe the immediate sensory details.
      3. Update the QUESTS:
         - You can complete active quests if the conditions are met (indicate this by adding their titles to "toComplete").
         - You can fail active quests if the player made a terrible choice (add to "toFail").
         - You can assign brand-new quests relevant to the plot (add to "toAdd").
      4. Update the INVENTORY:
         - If they found, stole, bought, or received items, add them to "toAdd" (including descriptions and quantities).
         - If they consumed, lost, sold, or broke items, add their exact names to "toRemove".
      5. Formulate exactly 4 choices for what they can do next. They should be varied, challenging, and appropriate to the current environment and plot development. If the adventure reaches a natural, dramatic, or tragic conclusion (character dies or completes their ultimate quest), set "isGameOver" to true and describe the reason.
      6. Create a highly detailed description for "imagePrompt". It should paint a specific scene containing the characters, actions, or environments described in this new narrative segment, incorporating elements of the character's appearance (${character.description}) for visual consistency. Avoid vague art style buzzwords—describe physical actions and elements.
      
      Respond with a JSON object matching this schema exactly:
      {
        "narrative": "A rich 2-3 paragraph continuation of the story, reacting specifically and realistically to the player's action.",
        "imagePrompt": "A detailed scene visual description (physical characteristics, clothes, posture, scene elements, lighting) to feed to the image generator.",
        "choices": ["Option 1", "Option 2", "Option 3", "Option 4"],
        "questUpdates": {
          "toAdd": [
            { "title": "New Quest Title", "description": "New Quest Description" }
          ],
          "toComplete": ["Title of quest to mark completed"],
          "toFail": ["Title of quest to mark failed"]
        },
        "inventoryUpdates": {
          "toAdd": [
            { "name": "Item Name", "description": "Description of item", "quantity": 1 }
          ],
          "toRemove": ["Exact name of item to remove"]
        },
        "isGameOver": false,
        "gameOverReason": ""
      }
    `;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            narrative: { type: Type.STRING },
            imagePrompt: { type: Type.STRING },
            choices: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            questUpdates: {
              type: Type.OBJECT,
              properties: {
                toAdd: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      description: { type: Type.STRING }
                    },
                    required: ["title", "description"]
                  }
                },
                toComplete: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                toFail: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              }
            },
            inventoryUpdates: {
              type: Type.OBJECT,
              properties: {
                toAdd: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      description: { type: Type.STRING },
                      quantity: { type: Type.INTEGER }
                    },
                    required: ["name", "description", "quantity"]
                  }
                },
                toRemove: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              }
            },
            isGameOver: { type: Type.BOOLEAN },
            gameOverReason: { type: Type.STRING }
          },
          required: ["narrative", "imagePrompt", "choices", "isGameOver"]
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    res.json(data);
  } catch (error: any) {
    console.error("Error continuing adventure:", error);
    res.status(500).json({ error: error.message || "Failed to progress story." });
  }
});

// API endpoint to generate high-quality images using gemini-3-pro-image-preview
app.post("/api/adventure/generate-image", async (req, res) => {
  try {
    const { prompt, artStylePrompt, imageSize = "1K" } = req.body;

    // Combine visual description with art style modifier for absolute visual style consistency
    const fullPrompt = `${prompt}. Style of: ${artStylePrompt}. Masterpiece digital concept art illustration, high-fidelity details, beautiful lighting, consistent color palette.`;

    console.log(`Generating image. Size: ${imageSize}. Style: ${artStylePrompt}. Prompt: ${prompt}`);

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-image-preview",
      contents: {
        parts: [{ text: fullPrompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
          imageSize: imageSize, // Supports '1K', '2K', '4K'
        },
      },
    });

    let base64Image = "";
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          base64Image = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!base64Image) {
      throw new Error("No image data found in model response.");
    }

    res.json({ imageUrl: base64Image });
  } catch (error: any) {
    console.error("Error generating scene image:", error);
    res.status(500).json({ error: error.message || "Failed to generate scene image." });
  }
});

// API endpoint for Companion Chatbot
app.post("/api/adventure/chat", async (req, res) => {
  try {
    const {
      character,
      quests,
      inventory,
      history, // Story narrative history
      chatHistory, // Chat messages history
      companion,
      modelName = "gemini-3.5-flash"
    } = req.body;

    // Map companion details to system instructions
    const systemInstructions = `
      You are "${companion.name}", who plays the role of a "${companion.role}" accompanying the player on their adventure.
      
      === YOUR PERSONALITY & SPEAKER PROFILE ===
      - Personality: ${companion.personality}
      - Speaking style: Maintain this exact persona. Use tone, vocabulary, and expressions suitable for this role.
      
      === PLAYER'S CHARACTER DETAILS ===
      - Name: ${character.name}
      - Class: ${character.classType}
      - Description: ${character.description}
      - Background: ${character.background}
      
      === CURRENT GAME CONTEXT ===
      - Story so far (last narrative segment): "${history.length > 0 ? history[history.length - 1].narrative : "Just started."}"
      - Active Quests: ${JSON.stringify(quests)}
      - Player's Inventory: ${JSON.stringify(inventory)}
      
      === CHAT INSTRUCTIONS ===
      1. Talk directly to the player. Refer to them as ${character.name}.
      2. Respond in character! React specifically to their queries, but also reference their current quest, setting, or items in their inventory if relevant.
      3. Give suggestions, share lore, or express skepticism/excitement depending on your personality.
      4. Keep your answer engaging, medium-short (1-3 paragraphs), and conversational. Do not output markdown code blocks or structured system logs. Talk as a true roleplay companion.
    `;

    // Reconstruct conversation history formatted for GoogleGenAI SDK chats
    const formattedContents = chatHistory.map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.parts[0].text }]
    }));

    const response = await ai.models.generateContent({
      model: modelName,
      contents: formattedContents,
      config: {
        systemInstruction: systemInstructions,
        temperature: 0.8,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Error in companion chat:", error);
    res.status(500).json({ error: error.message || "Failed to generate companion response." });
  }
});

// Vite middleware for development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Adventure Engine Server running on http://localhost:${PORT}`);
  });
}

startServer();
