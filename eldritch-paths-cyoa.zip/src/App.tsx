import React, { useState } from 'react';
import { Character, GameState, StorySegment, ChatMessage, Companion, InventoryItem, Quest } from './types';
import SetupScreen from './components/SetupScreen';
import AdventureSidebar from './components/AdventureSidebar';
import GamePanel from './components/GamePanel';
import ChatPanel from './components/ChatPanel';
import { Backpack, MessageSquare, Gamepad2, Compass, AlertCircle } from 'lucide-react';

const INITIAL_GAME_STATE: GameState = {
  character: null,
  artStyle: null,
  setting: '',
  history: [],
  currentQuests: [],
  inventory: [],
  imageSize: '1K',
  isGameOver: false,
};

export default function App() {
  const [screen, setScreen] = useState<'setup' | 'adventure'>('setup');
  const [gameState, setGameState] = useState<GameState>(INITIAL_GAME_STATE);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  
  // Loading indicators
  const [isStoryLoading, setIsStoryLoading] = useState(false);
  const [isImageLoading, setIsImageLoading] = useState(false);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);

  // Responsive panel states for mobile view
  const [mobileActivePanel, setMobileActivePanel] = useState<'game' | 'sidebar' | 'chat'>('game');

  // Triggered when starting the adventure
  const handleStartAdventure = async (
    character: Character,
    artStyle: { id: string; name: string; prompt: string },
    setting: string,
    imageSize: '1K' | '2K' | '4K'
  ) => {
    setIsStoryLoading(true);
    setIsImageLoading(true);
    setGlobalError(null);
    setScreen('adventure');

    try {
      // 1. Fetch initial narrative, quests, and starting items
      const startRes = await fetch('/api/adventure/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ character, artStyle, setting }),
      });

      if (!startRes.ok) {
        throw new Error('Failed to communicate with Dungeon Master server.');
      }

      const startData = await startRes.json();

      const initialSegment: StorySegment = {
        id: 'start_scene',
        narrative: startData.narrative,
        imagePrompt: startData.imagePrompt,
        choices: startData.choices,
      };

      // Map starting quests and inventory items with unique keys
      const mappedQuests: Quest[] = startData.startingQuests.map((q: any, i: number) => ({
        id: `start_quest_${i}`,
        title: q.title,
        description: q.description,
        status: 'active',
      }));

      const mappedInventory: InventoryItem[] = startData.startingInventory.map((item: any, i: number) => ({
        id: `start_item_${i}`,
        name: item.name,
        description: item.description,
        quantity: item.quantity || 1,
      }));

      // Set the initial game state with the starter narrative segment
      setGameState({
        character,
        artStyle,
        setting,
        imageSize,
        history: [initialSegment],
        currentQuests: mappedQuests,
        inventory: mappedInventory,
        isGameOver: false,
      });

      setIsStoryLoading(false);

      // 2. Generate the scene illustration asynchronously in the background
      try {
        const imageRes = await fetch('/api/adventure/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: startData.imagePrompt,
            artStylePrompt: artStyle.prompt,
            imageSize,
          }),
        });

        if (imageRes.ok) {
          const imageData = await imageRes.json();
          setGameState((prev) => ({
            ...prev,
            history: prev.history.map((seg) =>
              seg.id === 'start_scene' ? { ...seg, imageUrl: imageData.imageUrl } : seg
            ),
          }));
        }
      } catch (imgErr) {
        console.error('Error generating startup scene visual:', imgErr);
      } finally {
        setIsImageLoading(false);
      }
    } catch (err: any) {
      console.error('Error initializing adventure:', err);
      setGlobalError(err.message || 'An error occurred while establishing the story path.');
      setIsStoryLoading(false);
      setIsImageLoading(false);
      setScreen('setup');
    }
  };

  // Triggered when selecting an option or writing a custom action
  const handleChoice = async (choice: string, modelName: string) => {
    if (isStoryLoading || gameState.isGameOver) return;

    setIsStoryLoading(true);
    setIsImageLoading(true);
    setGlobalError(null);
    setMobileActivePanel('game'); // Ensure they see the story change

    const { character, artStyle, setting, history, currentQuests, inventory, imageSize } = gameState;
    const currentSegment = history[history.length - 1];

    // Record chosen action on current segment
    const updatedHistory = [...history];
    updatedHistory[updatedHistory.length - 1] = {
      ...currentSegment,
      choices: [choice], // Overwrite standard choices array to show what was chosen
    };

    try {
      // 1. Fetch continuation narrative
      const contRes = await fetch('/api/adventure/continue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          character,
          artStyle,
          setting,
          choice,
          history: updatedHistory,
          currentQuests,
          inventory,
          modelName,
        }),
      });

      if (!contRes.ok) {
        throw new Error('Dungeon Master model failed to compute outcomes.');
      }

      const contData = await contRes.json();

      const newSegmentId = `scene_${Date.now()}`;
      const newSegment: StorySegment = {
        id: newSegmentId,
        narrative: contData.narrative,
        imagePrompt: contData.imagePrompt,
        choices: contData.choices || [],
      };

      // 2. Compute dynamic quest state modifications
      let updatedQuests = [...currentQuests];
      const { questUpdates } = contData;

      if (questUpdates) {
        // Complete quests
        if (questUpdates.toComplete) {
          updatedQuests = updatedQuests.map((q) =>
            questUpdates.toComplete.some((title: string) => q.title.toLowerCase() === title.toLowerCase())
              ? { ...q, status: 'completed' as const }
              : q
          );
        }
        // Fail quests
        if (questUpdates.toFail) {
          updatedQuests = updatedQuests.map((q) =>
            questUpdates.toFail.some((title: string) => q.title.toLowerCase() === title.toLowerCase())
              ? { ...q, status: 'failed' as const }
              : q
          );
        }
        // Add brand new quests
        if (questUpdates.toAdd) {
          questUpdates.toAdd.forEach((nq: any, i: number) => {
            if (!updatedQuests.some((eq) => eq.title.toLowerCase() === nq.title.toLowerCase())) {
              updatedQuests.push({
                id: `quest_${Date.now()}_${i}`,
                title: nq.title,
                description: nq.description,
                status: 'active',
              });
            }
          });
        }
      }

      // 3. Compute dynamic inventory modifications
      let updatedInventory = [...inventory];
      const { inventoryUpdates } = contData;

      if (inventoryUpdates) {
        // Remove items
        if (inventoryUpdates.toRemove) {
          inventoryUpdates.toRemove.forEach((name: string) => {
            const idx = updatedInventory.findIndex((item) => item.name.toLowerCase() === name.toLowerCase());
            if (idx !== -1) {
              if (updatedInventory[idx].quantity > 1) {
                updatedInventory[idx] = {
                  ...updatedInventory[idx],
                  quantity: updatedInventory[idx].quantity - 1,
                };
              } else {
                updatedInventory.splice(idx, 1);
              }
            }
          });
        }
        // Add or stack new items
        if (inventoryUpdates.toAdd) {
          inventoryUpdates.toAdd.forEach((addItem: any, i: number) => {
            const idx = updatedInventory.findIndex((item) => item.name.toLowerCase() === addItem.name.toLowerCase());
            if (idx !== -1) {
              updatedInventory[idx] = {
                ...updatedInventory[idx],
                quantity: updatedInventory[idx].quantity + (addItem.quantity || 1),
              };
            } else {
              updatedInventory.push({
                id: `item_${Date.now()}_${i}`,
                name: addItem.name,
                description: addItem.description,
                quantity: addItem.quantity || 1,
              });
            }
          });
        }
      }

      // Set the active state
      setGameState((prev) => ({
        ...prev,
        history: [...updatedHistory, newSegment],
        currentQuests: updatedQuests,
        inventory: updatedInventory,
        isGameOver: contData.isGameOver || false,
        gameOverReason: contData.gameOverReason || '',
      }));

      setIsStoryLoading(false);

      // 4. Generate the scene illustration in the background using the consistent style
      try {
        const imageRes = await fetch('/api/adventure/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: contData.imagePrompt,
            artStylePrompt: artStyle?.prompt,
            imageSize,
          }),
        });

        if (imageRes.ok) {
          const imageData = await imageRes.json();
          setGameState((prev) => ({
            ...prev,
            history: prev.history.map((seg) =>
              seg.id === newSegmentId ? { ...seg, imageUrl: imageData.imageUrl } : seg
            ),
          }));
        }
      } catch (imgErr) {
        console.error('Error generating continuation illustration:', imgErr);
      } finally {
        setIsImageLoading(false);
      }
    } catch (err: any) {
      console.error('Error continuing adventure:', err);
      setGlobalError(err.message || 'Dungeon Master server ran into an anomaly. Please try choice again.');
      setIsStoryLoading(false);
      setIsImageLoading(false);
    }
  };

  // Handles Companion Chat submissions
  const handleSendMessage = async (text: string, companion: Companion, modelName: string) => {
    if (isChatLoading) return;

    const userMessage: ChatMessage = {
      id: `chat_user_${Date.now()}`,
      role: 'user',
      parts: [{ text }],
      timestamp: new Date().toLocaleTimeString(),
    };

    setChatHistory((prev) => [...prev, userMessage]);
    setIsChatLoading(true);

    try {
      const response = await fetch('/api/adventure/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          character: gameState.character,
          quests: gameState.currentQuests,
          inventory: gameState.inventory,
          history: gameState.history,
          chatHistory: [...chatHistory, userMessage],
          companion,
          modelName,
        }),
      });

      if (!response.ok) {
        throw new Error('Companion failed to formulate a response.');
      }

      const data = await response.json();

      const companionMessage: ChatMessage = {
        id: `chat_comp_${Date.now()}`,
        role: 'model',
        parts: [{ text: data.text }],
        timestamp: new Date().toLocaleTimeString(),
      };

      setChatHistory((prev) => [...prev, companionMessage]);
    } catch (err) {
      console.error('Error in chat endpoint:', err);
      setChatHistory((prev) => [
        ...prev,
        {
          id: `chat_err_${Date.now()}`,
          role: 'model',
          parts: [{ text: "*Cough* I'm having trouble channeling my thoughts... We should focus on our surroundings." }],
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleRestart = () => {
    setGameState(INITIAL_GAME_STATE);
    setChatHistory([]);
    setScreen('setup');
    setMobileActivePanel('game');
  };

  if (screen === 'setup') {
    return <SetupScreen onStart={handleStartAdventure} />;
  }

  return (
    <div id="adventure-app" className="h-screen bg-slate-950 text-slate-100 flex flex-col overflow-hidden select-none">
      
      {/* Global Error Banner */}
      {globalError && (
        <div className="bg-rose-950/40 border-b border-rose-900/60 p-3 flex items-center justify-between z-50 text-xs">
          <div className="flex items-center gap-2 text-rose-400">
            <AlertCircle className="w-4 h-4" />
            <span>{globalError}</span>
          </div>
          <button
            onClick={() => setGlobalError(null)}
            className="text-rose-400 hover:text-rose-200 font-bold px-2 py-0.5 rounded border border-rose-900 bg-slate-950"
          >
            Acknowledge
          </button>
        </div>
      )}

      {/* Main Panels Container */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        
        {/* Panel 1: Inventory & Quests Sidebar */}
        <div className={`h-full ${mobileActivePanel === 'sidebar' ? 'block' : 'hidden'} lg:block`}>
          <AdventureSidebar gameState={gameState} />
        </div>

        {/* Panel 2: Center Story Scene Illustration & Narrative */}
        <div className={`h-full flex-1 ${mobileActivePanel === 'game' ? 'block' : 'hidden'} lg:block`}>
          <GamePanel
            gameState={gameState}
            onChoice={handleChoice}
            onRestart={handleRestart}
            isStoryLoading={isStoryLoading}
            isImageLoading={isImageLoading}
          />
        </div>

        {/* Panel 3: Companion Multi-Role Chatbot thread */}
        <div className={`h-full ${mobileActivePanel === 'chat' ? 'block' : 'hidden'} lg:block`}>
          <ChatPanel
            gameState={gameState}
            chatHistory={chatHistory}
            onSendMessage={handleSendMessage}
            isChatLoading={isChatLoading}
          />
        </div>
      </main>

      {/* Mobile Footer Tab Navigation */}
      <nav className="lg:hidden h-14 bg-slate-900 border-t border-slate-800 flex items-center justify-around shrink-0 select-none">
        <button
          onClick={() => setMobileActivePanel('sidebar')}
          className={`flex flex-col items-center justify-center w-full h-full text-center transition-all ${
            mobileActivePanel === 'sidebar' ? 'text-violet-400 font-bold' : 'text-slate-500'
          }`}
        >
          <Backpack className="w-4.5 h-4.5" />
          <span className="text-[10px] mt-1">Backpack</span>
        </button>

        <button
          onClick={() => setMobileActivePanel('game')}
          className={`flex flex-col items-center justify-center w-full h-full text-center transition-all ${
            mobileActivePanel === 'game' ? 'text-violet-400 font-bold' : 'text-slate-500'
          }`}
        >
          <Gamepad2 className="w-4.5 h-4.5" />
          <span className="text-[10px] mt-1">Adventure</span>
        </button>

        <button
          onClick={() => setMobileActivePanel('chat')}
          className={`flex flex-col items-center justify-center w-full h-full text-center transition-all ${
            mobileActivePanel === 'chat' ? 'text-violet-400 font-bold' : 'text-slate-500'
          }`}
        >
          <MessageSquare className="w-4.5 h-4.5" />
          <span className="text-[10px] mt-1">Companions</span>
        </button>
      </nav>
    </div>
  );
}
