import React from 'react';
import { GameState, InventoryItem, Quest } from '../types';
import { Backpack, Scroll, ClipboardList, Shield, User, Image as ImageIcon, CheckCircle2, XCircle, Info } from 'lucide-react';

interface AdventureSidebarProps {
  gameState: GameState;
}

export default function AdventureSidebar({ gameState }: AdventureSidebarProps) {
  const { character, artStyle, currentQuests, inventory, imageSize } = gameState;

  if (!character) return null;

  // Split quests into active and resolved
  const activeQuests = currentQuests.filter((q) => q.status === 'active');
  const resolvedQuests = currentQuests.filter((q) => q.status !== 'active');

  return (
    <aside id="adventure-sidebar" className="w-full lg:w-80 bg-slate-900 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col h-full overflow-y-auto shrink-0 select-none">
      {/* 1. Character Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-violet-950/80 border border-violet-800 flex items-center justify-center text-violet-400 font-bold uppercase shadow-inner">
            {character.name.charAt(0)}
          </div>
          <div>
            <h3 className="font-bold text-slate-100 text-sm leading-tight">{character.name}</h3>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-violet-400 bg-violet-950/40 px-2 py-0.5 rounded-md border border-violet-900/60 mt-1">
              {character.classType}
            </span>
          </div>
        </div>
        <p className="mt-3 text-xs text-slate-400 leading-relaxed italic border-l-2 border-violet-800 pl-2">
          "{character.background}"
        </p>
      </div>

      {/* 2. Visual Settings Metadata */}
      <div className="p-3 border-b border-slate-800 bg-slate-950/10 text-[11px] text-slate-500 space-y-1">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1"><ImageIcon className="w-3 h-3" /> Art Consistency:</span>
          <span className="font-medium text-slate-300">{artStyle?.name || 'Default'}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1"><Info className="w-3 h-3" /> Rendering Quality:</span>
          <span className="font-mono text-slate-300 bg-slate-950 px-1 py-0.2 rounded border border-slate-800">{imageSize}</span>
        </div>
      </div>

      {/* 3. Dynamic Current Quests */}
      <div className="flex-1 p-4 space-y-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider pb-1.5 border-b border-slate-800">
            <span className="flex items-center gap-1.5"><Scroll className="w-4 h-4 text-fuchsia-400" /> Current Quests</span>
            <span className="bg-fuchsia-950/40 border border-fuchsia-900/60 text-fuchsia-400 px-1.5 py-0.2 rounded text-[10px]">
              {activeQuests.length}
            </span>
          </div>

          {activeQuests.length === 0 ? (
            <div className="text-center py-6 px-4 bg-slate-950/20 border border-dashed border-slate-800 rounded-lg text-xs text-slate-500">
              No active quests. Progress the story to discover new objectives.
            </div>
          ) : (
            <div className="space-y-3">
              {activeQuests.map((quest) => (
                <div key={quest.id} className="p-3 rounded-lg bg-slate-950/30 border border-slate-800/80 hover:border-slate-800 transition-colors">
                  <h4 className="text-xs font-bold text-fuchsia-300 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-500 animate-pulse inline-block" />
                    {quest.title}
                  </h4>
                  <p className="mt-1 text-[11px] text-slate-400 leading-normal">{quest.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 4. Dynamic Inventory Sidebar */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider pb-1.5 border-b border-slate-800">
            <span className="flex items-center gap-1.5"><Backpack className="w-4 h-4 text-emerald-400" /> Inventory</span>
            <span className="bg-emerald-950/40 border border-emerald-900/60 text-emerald-400 px-1.5 py-0.2 rounded text-[10px]">
              {inventory.reduce((acc, item) => acc + item.quantity, 0)}
            </span>
          </div>

          {inventory.length === 0 ? (
            <div className="text-center py-6 px-4 bg-slate-950/20 border border-dashed border-slate-800 rounded-lg text-xs text-slate-500">
              Your inventory is empty. Complete quests or loot enemies to acquire gear.
            </div>
          ) : (
            <div className="space-y-2">
              {inventory.map((item) => (
                <div key={item.id} className="flex items-start gap-2.5 p-2.5 rounded-lg bg-slate-950/20 border border-slate-800/40 hover:bg-slate-950/40 transition-colors">
                  <div className="w-6 h-6 rounded-md bg-emerald-950/20 border border-emerald-900/40 text-emerald-500 flex items-center justify-center text-xs font-bold font-mono shrink-0 select-none">
                    x{item.quantity}
                  </div>
                  <div className="min-w-0">
                    <h5 className="text-xs font-bold text-slate-200 truncate">{item.name}</h5>
                    <p className="text-[10px] text-slate-400 leading-normal mt-0.5 line-clamp-2">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 5. Quest Ledger History */}
        {resolvedQuests.length > 0 && (
          <div className="space-y-3 pt-2">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider pb-1.5 border-b border-slate-800 flex items-center gap-1.5">
              <ClipboardList className="w-4 h-4 text-indigo-400" /> Quest Ledger
            </div>
            <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
              {resolvedQuests.map((quest) => (
                <div key={quest.id} className="flex items-center justify-between p-2 rounded bg-slate-950/10 border border-slate-800/30 text-[11px]">
                  <span className="text-slate-400 truncate max-w-[150px]">{quest.title}</span>
                  {quest.status === 'completed' ? (
                    <span className="flex items-center gap-1 text-emerald-400 font-medium">
                      <CheckCircle2 className="w-3 h-3" /> Done
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-rose-400 font-medium">
                      <XCircle className="w-3 h-3" /> Failed
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
