import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GameState, ChatMessage, Companion } from '../types';
import { MessageSquare, Send, Sparkles, HelpCircle, Shield, Bot, Flame, Compass, Zap } from 'lucide-react';

interface ChatPanelProps {
  gameState: GameState;
  chatHistory: ChatMessage[];
  onSendMessage: (text: string, companion: Companion, modelName: string) => void;
  isChatLoading: boolean;
}

const COMPANIONS: Companion[] = [
  {
    id: 'dm_guide',
    name: 'Omniscient Narrator',
    role: 'Game Guide & Historian',
    avatar: '📜',
    personality: 'Wise, cryptic, and atmospheric. Speaks of lore, cosmic balance, and ancient paths. Willing to provide subtle hints or riddles about mystery symbols.',
    greeting: "Greetings, traveler. I record the threads of time. If you seek lore, clarity on your objectives, or whispers of the past, ask me."
  },
  {
    id: 'lyra_rogue',
    name: 'Lyra Moonshade',
    role: 'Elven Thief Companion',
    avatar: '🗡️',
    personality: 'Sarcastic, silver-tongued, sharp, and highly practical. Loves gold, stealthy ambushes, and complaining about dangerous traps. Checks out inventory for shiny loot.',
    greeting: "Hey there. Keep your voice down. That last corridor was crawling with trouble. What's the plan? And please tell me you didn't trigger any pressure plates."
  },
  {
    id: 'elidor_mage',
    name: 'Archmage Elidor',
    role: 'Arcane scholar',
    avatar: '🔮',
    personality: 'Formal, scholarly, caution-driven, and highly analytical. Warns of magical anomalies, curses, and reckless choices. Analyzes found magic relics.',
    greeting: "May the arcane winds protect us. I sense strange fluctuations in this sector. Consult me before touching any glowing objects or reading unshielded scrolls."
  },
  {
    id: 'arc7_droid',
    name: 'ARC-7',
    role: 'Tactical Recon Droid',
    avatar: '🤖',
    personality: 'Analytical, factual, literal, and slightly mechanical. Evaluates tactical odds, scans environments, translates strange dialects, and gives logical danger percentages.',
    greeting: "Beep-boop. Neural interface synchronized. Tactical threat levels are currently at nominal limits. State your query for hazard scan or translation diagnostics."
  }
];

const CHAT_MODELS = [
  { id: 'gemini-3.1-flash-lite', name: 'Lite (Fast)', icon: Zap },
  { id: 'gemini-3.5-flash', name: 'Balanced', icon: Compass },
  { id: 'gemini-3.1-pro-preview', name: 'Pro (Complex)', icon: Bot }
];

export default function ChatPanel({
  gameState,
  chatHistory,
  onSendMessage,
  isChatLoading
}: ChatPanelProps) {
  const [activeCompanion, setActiveCompanion] = useState<Companion>(COMPANIONS[0]);
  const [chatModel, setChatModel] = useState('gemini-3.5-flash');
  const [inputText, setInputText] = useState('');
  
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll when new messages arrive
  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory, isChatLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isChatLoading) return;
    onSendMessage(inputText.trim(), activeCompanion, chatModel);
    setInputText('');
  };

  return (
    <section id="chat-panel" className="w-full lg:w-96 bg-slate-900 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col h-full overflow-hidden">
      {/* Chat Header & Companion Selector */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/40">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <MessageSquare className="w-4 h-4 text-violet-400" /> Companion Chat
        </h3>

        {/* Horizontal scroll selection for companions */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin select-none">
          {COMPANIONS.map((comp) => {
            const isSelected = activeCompanion.id === comp.id;
            return (
              <button
                key={comp.id}
                onClick={() => setActiveCompanion(comp)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-violet-950/40 border-violet-500 text-violet-200 shadow-sm shadow-violet-500/5'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <span className="text-base">{comp.avatar}</span>
                <span>{comp.name.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Companion description & Model toggle */}
        <div className="mt-2.5 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800 text-[10px] text-slate-400 leading-normal flex flex-col gap-2">
          <div>
            <span className="font-bold text-slate-300">{activeCompanion.name} ({activeCompanion.role}):</span>{' '}
            {activeCompanion.personality}
          </div>
          
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-slate-500">AI Model:</span>
            <div className="flex gap-1">
              {CHAT_MODELS.map((model) => (
                <button
                  key={model.id}
                  onClick={() => setChatModel(model.id)}
                  className={`px-1.5 py-0.5 rounded text-[9px] font-semibold transition-all border ${
                    chatModel === model.id
                      ? 'bg-violet-950 text-violet-300 border-violet-800'
                      : 'bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-400'
                  }`}
                >
                  {model.name.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Message History Thread */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-950/30">
        {/* Companion Initial Greeting Bubble */}
        <div className="flex gap-2.5">
          <div className="w-7 h-7 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-sm shrink-0 select-none shadow">
            {activeCompanion.avatar}
          </div>
          <div className="max-w-[85%] rounded-2xl rounded-tl-none bg-slate-900 border border-slate-850 p-3 text-xs text-slate-300 leading-relaxed">
            <p>{activeCompanion.greeting}</p>
          </div>
        </div>

        {chatHistory
          .filter((msg) => msg.id !== 'greeting') // filter initial greeting if mock added
          .map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-sm shrink-0 select-none shadow">
                    {activeCompanion.avatar}
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                    isUser
                      ? 'rounded-tr-none bg-violet-600 text-white shadow-md'
                      : 'rounded-tl-none bg-slate-900 border border-slate-850 text-slate-300'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.parts[0].text}</p>
                </div>
              </div>
            );
          })}

        {/* Streaming / Response Loading Bubble */}
        {isChatLoading && (
          <div className="flex gap-2.5">
            <div className="w-7 h-7 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-sm shrink-0 animate-pulse">
              {activeCompanion.avatar}
            </div>
            <div className="max-w-[85%] rounded-2xl rounded-tl-none bg-slate-900 border border-slate-850 p-3 text-xs text-slate-400 flex items-center gap-1.5 animate-pulse">
              <span>Thinking</span>
              <span className="flex gap-0.5">
                <span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </span>
            </div>
          </div>
        )}

        <div ref={chatBottomRef} />
      </div>

      {/* Input Form Footer */}
      <form onSubmit={handleSubmit} className="p-3 bg-slate-900 border-t border-slate-800 flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={`Talk to ${activeCompanion.name.split(' ')[0]}...`}
          disabled={isChatLoading}
          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-violet-500"
        />
        <button
          type="submit"
          disabled={isChatLoading || !inputText.trim()}
          className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-all ${
            isChatLoading || !inputText.trim()
              ? 'bg-slate-950 text-slate-700 cursor-not-allowed border border-slate-900'
              : 'bg-violet-600 text-white hover:bg-violet-500 shadow-md shadow-violet-950/20'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </section>
  );
}
