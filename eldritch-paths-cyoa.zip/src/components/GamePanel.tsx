import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GameState, StorySegment } from '../types';
import { Sparkles, ArrowRight, CornerDownLeft, RefreshCw, Zap, Cpu, Swords, Compass, HelpCircle } from 'lucide-react';

interface GamePanelProps {
  gameState: GameState;
  onChoice: (choice: string, modelName: string) => void;
  onRestart: () => void;
  isStoryLoading: boolean;
  isImageLoading: boolean;
}

const MODEL_OPTIONS = [
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Low-Latency Lite',
    desc: 'Extremely fast responses, ideal for prompt action progression.',
    icon: Zap,
    color: 'text-amber-400 bg-amber-950/20 border-amber-900/60'
  },
  {
    id: 'gemini-3.5-flash',
    name: 'Standard Flash',
    desc: 'Balanced reasoning and descriptive lore, perfect for rich stories.',
    icon: Compass,
    color: 'text-violet-400 bg-violet-950/20 border-violet-900/60'
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Advanced Pro',
    desc: 'Maximum narrative depth, complex puzzles, and intelligent world reacts.',
    icon: Cpu,
    color: 'text-fuchsia-400 bg-fuchsia-950/20 border-fuchsia-900/60'
  }
];

export default function GamePanel({
  gameState,
  onChoice,
  onRestart,
  isStoryLoading,
  isImageLoading
}: GamePanelProps) {
  const { history, isGameOver, gameOverReason } = gameState;
  const currentSegment = history[history.length - 1];

  const [customAction, setCustomAction] = useState('');
  const [selectedModel, setSelectedModel] = useState('gemini-3.5-flash');
  const [showModelConfig, setShowModelConfig] = useState(false);
  
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [history, isStoryLoading]);

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customAction.trim() || isStoryLoading) return;
    onChoice(customAction.trim(), selectedModel);
    setCustomAction('');
  };

  const handleChoiceClick = (choice: string) => {
    if (isStoryLoading) return;
    onChoice(choice, selectedModel);
  };

  // Render placeholder while generating
  const renderImageLoadingPlaceholder = () => (
    <div className="w-full aspect-video bg-slate-950 border border-slate-800 rounded-xl flex flex-col items-center justify-center p-6 text-center text-slate-500 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 animate-pulse" />
      <div className="relative z-10 flex flex-col items-center">
        <div className="w-10 h-10 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin mb-3" />
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 animate-pulse">Rendering Illustration</span>
        <p className="text-[10px] text-slate-500 max-w-sm italic">
          "Drafting scene in consistent {gameState.artStyle?.name} style..."
        </p>
      </div>
    </div>
  );

  return (
    <div id="game-panel" className="flex-1 flex flex-col h-full bg-slate-950 border-r border-slate-800 overflow-y-auto">
      {/* Upper Navigation / Control Bar */}
      <header className="p-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between sticky top-0 z-20 backdrop-blur-sm">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block animate-pulse" />
          <span className="text-xs font-bold text-slate-300">Adventure Phase {history.length}</span>
        </div>

        {/* Model Selector Pill */}
        <div className="relative">
          <button
            onClick={() => setShowModelConfig(!showModelConfig)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-full text-[11px] font-semibold text-slate-300 transition-all cursor-pointer"
          >
            {React.createElement(MODEL_OPTIONS.find(m => m.id === selectedModel)?.icon || Compass, { className: 'w-3 h-3 text-violet-400' })}
            {MODEL_OPTIONS.find(m => m.id === selectedModel)?.name.split(' ')[1]} DM
          </button>

          <AnimatePresence>
            {showModelConfig && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setShowModelConfig(false)} />
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-800 rounded-xl p-3 shadow-xl z-40 space-y-2.5"
                >
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Select Dungeon Master AI</h4>
                  <div className="space-y-1.5">
                    {MODEL_OPTIONS.map((opt) => {
                      const IconComp = opt.icon;
                      const isSelected = selectedModel === opt.id;
                      return (
                        <button
                          key={opt.id}
                          onClick={() => {
                            setSelectedModel(opt.id);
                            setShowModelConfig(false);
                          }}
                          className={`w-full text-left p-2 rounded-lg border text-xs transition-all flex items-start gap-2 ${
                            isSelected
                              ? 'bg-violet-950/30 border-violet-500 text-violet-200'
                              : 'bg-slate-950 border-slate-900 hover:border-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <IconComp className="w-4 h-4 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-bold block">{opt.name}</span>
                            <span className="text-[10px] text-slate-500 leading-normal">{opt.desc}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 p-4 sm:p-6 space-y-6 max-w-3xl mx-auto w-full">
        {/* Story History Thread */}
        <div className="space-y-6">
          {history.slice(0, -1).map((seg, idx) => (
            <div key={seg.id} className="opacity-40 border-l border-slate-800 pl-4 py-1 space-y-2">
              <span className="text-[10px] font-bold font-mono text-slate-600">Scene {idx + 1}</span>
              <p className="text-xs text-slate-400 leading-relaxed font-sans line-clamp-3">{seg.narrative}</p>
              {seg.choices && (
                <div className="text-[11px] font-semibold text-violet-500 italic">
                  &gt; Chosen: {seg.choices[0] || 'Custom Action'}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Current Active Scene Segment */}
        {currentSegment && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            {/* Real-time Generated Consistent Image Visual */}
            <div className="space-y-2">
              {isImageLoading || !currentSegment.imageUrl ? (
                renderImageLoadingPlaceholder()
              ) : (
                <div className="relative w-full aspect-video bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-lg shadow-black/40 group">
                  <img
                    src={currentSegment.imageUrl}
                    alt="Current Scene Visual Illustration"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3">
                    <p className="text-[10px] text-slate-300 bg-slate-900/80 px-2 py-1 rounded border border-slate-800 line-clamp-1 italic">
                      Prompt: "{currentSegment.imagePrompt}"
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Narrative Prose */}
            <div className="space-y-3 font-sans text-slate-200 leading-relaxed text-sm sm:text-base border-l-2 border-violet-500 pl-4 py-1">
              {currentSegment.narrative.split('\n\n').map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>

            {/* Dynamic Options or Game Over Display */}
            <div className="pt-4 border-t border-slate-900 space-y-4">
              {isGameOver ? (
                <motion.div
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="p-5 rounded-xl border border-violet-900/60 bg-violet-950/10 text-center space-y-4"
                >
                  <div className="w-12 h-12 rounded-full bg-violet-950 border border-violet-500 flex items-center justify-center text-violet-400 mx-auto shadow-md">
                    <Swords className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-100 text-lg">The Journey Concludes</h3>
                    <p className="mt-2 text-xs text-slate-400 leading-relaxed max-w-md mx-auto">
                      {gameOverReason || "Your story has run its course. Your deeds and path are carved permanently in the annals of this world."}
                    </p>
                  </div>
                  <button
                    onClick={onRestart}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs rounded-lg uppercase tracking-wider transition-all shadow-md shadow-indigo-950/40"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Start New Adventure
                  </button>
                </motion.div>
              ) : (
                <>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-violet-400" /> What do you do next?
                  </h4>

                  {/* Pre-set Choices */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {currentSegment.choices.map((choice, i) => (
                      <button
                        key={i}
                        onClick={() => handleChoiceClick(choice)}
                        disabled={isStoryLoading}
                        className={`text-left p-3.5 rounded-xl border text-xs leading-normal transition-all duration-200 flex items-start gap-2.5 ${
                          isStoryLoading
                            ? 'bg-slate-900/30 border-slate-900 text-slate-600 cursor-not-allowed'
                            : 'bg-slate-900 border-slate-800 hover:border-violet-800 hover:bg-violet-950/10 text-slate-200 hover:text-violet-300 shadow-sm hover:shadow-violet-500/5'
                        }`}
                      >
                        <span className="w-5 h-5 rounded bg-slate-950 border border-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400 shrink-0 select-none group-hover:border-violet-700">
                          {i + 1}
                        </span>
                        <span>{choice}</span>
                      </button>
                    ))}
                  </div>

                  {/* Custom Prompt Choice Input */}
                  <form onSubmit={handleCustomSubmit} className="space-y-2">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Or type your own custom action:</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={customAction}
                        onChange={(e) => setCustomAction(e.target.value)}
                        placeholder="e.g., Cast lock-melt on the brass hinges while checking for hidden runes..."
                        disabled={isStoryLoading}
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent min-w-0"
                      />
                      <button
                        type="submit"
                        disabled={isStoryLoading || !customAction.trim()}
                        className={`px-4 rounded-xl border font-bold text-xs flex items-center justify-center gap-1 shrink-0 transition-all ${
                          isStoryLoading || !customAction.trim()
                            ? 'bg-slate-950 border-slate-900 text-slate-600 cursor-not-allowed'
                            : 'bg-violet-900/20 border-violet-800 hover:bg-violet-900/30 text-violet-300 hover:text-violet-200 cursor-pointer'
                        }`}
                      >
                        Action <CornerDownLeft className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </form>
                </>
              )}
            </div>
          </motion.div>
        )}

        {/* Global Adventure Progression Spinner */}
        {isStoryLoading && (
          <div className="flex items-center justify-center gap-3 py-10 text-slate-400">
            <div className="relative w-8 h-8">
              <div className="absolute inset-0 rounded-full border-4 border-violet-950" />
              <div className="absolute inset-0 rounded-full border-4 border-violet-500 border-t-transparent animate-spin" />
            </div>
            <div className="text-xs">
              <span className="font-bold block text-slate-300 animate-pulse">Consulting the Oracle...</span>
              <span className="text-[10px] text-slate-500">Dungeon Master is calculating your path outcomes</span>
            </div>
          </div>
        )}

        {/* Bottom reference for scrolling */}
        <div ref={bottomRef} className="h-4" />
      </div>
    </div>
  );
}
