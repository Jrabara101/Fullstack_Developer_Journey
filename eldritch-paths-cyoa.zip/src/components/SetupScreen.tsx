import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Character, GameState } from '../types';
import { Sparkles, Wand2, Shield, Eye, HelpCircle, Image as ImageIcon, Swords, Orbit, Compass, User } from 'lucide-react';

interface SetupScreenProps {
  onStart: (
    character: Character,
    artStyle: { id: string; name: string; prompt: string },
    setting: string,
    imageSize: '1K' | '2K' | '4K'
  ) => void;
}

const CLASS_PRESETS = [
  {
    type: 'Spellweaver',
    icon: Wand2,
    description: 'Wielder of volatile elements and reality-warping incantations. Shines in intelligence and magic.',
    defaultDesc: 'A spellweaver clad in embroidered midnight-blue robes, wielding a staff tipped with a glowing crystal.'
  },
  {
    type: 'Dreadnought',
    icon: Shield,
    description: 'Clad in iron and iron-will, master of direct martial solutions. Heavy defense and brute strength.',
    defaultDesc: 'A battle-worn dreadnought clad in dark plate armor, holding a massive shield and sword.'
  },
  {
    type: 'Shadowdancer',
    icon: Swords,
    description: 'Specialist in shadow-meld, lockpicking, and silent blades. Exceptional agility and stealth.',
    defaultDesc: 'A stealthy shadowdancer wearing leather armor and a dark cowl, dual-wielding curved daggers.'
  },
  {
    type: 'Cyber-Decker',
    icon: Orbit,
    description: 'A netrunner who hacks electronic brains, neural plugs, and security drones. Tech and speed.',
    defaultDesc: 'A cyber-decker with glowing green cybernetic eye-implants, futuristic jacket, and portable neural deck.'
  }
];

const SETTING_PRESETS = [
  {
    name: 'Forgotten Elven Sanctuary',
    desc: 'An ancient mossy tree-city built into giant banyans, illuminated by luminescent flora and magic wards.',
    theme: 'high-fantasy'
  },
  {
    name: 'Neon Cyberpunk Metropolis',
    desc: 'A rain-slicked mega-city of chrome sky-bridges, flickering holograms, and black-market cyber-shops.',
    theme: 'cyberpunk'
  },
  {
    name: 'Gothic Vampire Castle',
    desc: 'A crumbling gothic fortress nestled in foggy mountain peaks, ruled by blood aristocrats.',
    theme: 'horror'
  },
  {
    name: 'Subterranean Steampunk Mine',
    desc: 'A subterranean labyrinth of brass gears, roaring furnace-pipes, and volatile crystal mining rails.',
    theme: 'steampunk'
  }
];

const ART_STYLE_PRESETS = [
  {
    id: 'dark-fantasy',
    name: 'Dark Fantasy Oil Painting',
    prompt: 'moody dark fantasy oil painting, textured canvas strokes, dramatic chiaroscuro lighting, rich deep color palette'
  },
  {
    id: 'retro-pixel',
    name: 'Retro 16-bit Pixel Art',
    prompt: 'detailed retro 16-bit pixel art style, classic sierra/lucasarts adventure aesthetic, vibrant palettes, clean dithered rendering'
  },
  {
    id: 'futuristic-synthwave',
    name: 'Futuristic Synthwave',
    prompt: 'glowing synthwave retro-futuristic digital illustration, cyber neon purples, glowing blues, grids, vector lines'
  },
  {
    id: 'dnd-sketch',
    name: 'D&D Pen & Ink Sketch',
    prompt: 'hand-drawn pen and ink dnd rulebook sketch, paper texture background, crosshatching detailing, fantasy line-art'
  },
  {
    id: 'anime-concept',
    name: 'Vibrant Anime Concept Art',
    prompt: 'cinematic digital anime concept illustration, vibrant cel-shading, wide-angle atmospheric lighting, epic background'
  }
];

export default function SetupScreen({ onStart }: SetupScreenProps) {
  const [charName, setCharName] = useState('Valen');
  const [selectedClass, setSelectedClass] = useState(CLASS_PRESETS[0]);
  const [customClass, setCustomClass] = useState('');
  const [charBackground, setCharBackground] = useState(
    'An exiled scholar searching for forbidden archives to restore a fallen kingdom.'
  );
  const [charDesc, setCharDesc] = useState(CLASS_PRESETS[0].defaultDesc);
  const [selectedSetting, setSelectedSetting] = useState(SETTING_PRESETS[0].name);
  const [customSetting, setCustomSetting] = useState('');
  const [selectedStyle, setSelectedStyle] = useState(ART_STYLE_PRESETS[0]);
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isGeneratingStart, setIsGeneratingStart] = useState(false);

  const handleClassSelect = (cls: typeof CLASS_PRESETS[0]) => {
    setSelectedClass(cls);
    setCharDesc(cls.defaultDesc);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsGeneratingStart(true);

    const finalClass = customClass.trim() || selectedClass.type;
    const finalSetting = customSetting.trim() || selectedSetting;

    const character: Character = {
      name: charName || 'Adventurer',
      classType: finalClass,
      background: charBackground || 'An eager explorer searching for glory.',
      description: charDesc || `A skilled ${finalClass} wearing protective gear.`
    };

    onStart(character, selectedStyle, finalSetting, imageSize);
  };

  return (
    <div id="setup-container" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto w-full">
        {/* Title & Introduction */}
        <div className="text-center mb-10">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-violet-950 border border-violet-800 text-violet-300 text-xs font-semibold rounded-full uppercase tracking-wider mb-3"
          >
            <Sparkles className="w-3.5 h-3.5" /> Infinite CYOA Engine
          </motion.div>
          <motion.h1
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-violet-400 via-fuchsia-300 to-indigo-400"
          >
            Eldritch Paths
          </motion.h1>
          <p className="mt-3 text-slate-400 text-sm max-w-xl mx-auto">
            Design your identity, establish your visual style, and set your course. Our engine dynamically shapes a boundless narrative based on your precise choices.
          </p>
        </div>

        <form onSubmit={handleFormSubmit} className="space-y-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl shadow-indigo-950/20">
          
          {/* Section 1: Character Creation */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold flex items-center gap-2 text-violet-400 border-b border-slate-800 pb-2">
              <User className="w-5 h-5" /> 1. Character Sheet
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Character Name</label>
                <input
                  type="text"
                  value={charName}
                  onChange={(e) => setCharName(e.target.value)}
                  placeholder="Enter name..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-violet-500 text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Custom Class (Optional)</label>
                <input
                  type="text"
                  value={customClass}
                  onChange={(e) => setCustomClass(e.target.value)}
                  placeholder="e.g., Void-Knight, Chrono-Mage..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-violet-500 text-sm"
                />
              </div>
            </div>

            {!customClass && (
              <div>
                <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Choose Archetype</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {CLASS_PRESETS.map((cls) => {
                    const IconComp = cls.icon;
                    const isSelected = selectedClass.type === cls.type;
                    return (
                      <button
                        key={cls.type}
                        type="button"
                        onClick={() => handleClassSelect(cls)}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                          isSelected
                            ? 'bg-violet-950/40 border-violet-500 text-violet-300 shadow-md shadow-violet-500/10'
                            : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <IconComp className={`w-5 h-5 mb-1.5 ${isSelected ? 'text-violet-400' : ''}`} />
                        <span className="text-xs font-bold">{cls.type}</span>
                      </button>
                    );
                  })}
                </div>
                <p className="mt-2 text-xs text-slate-500 italic">{selectedClass.description}</p>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Background & Motivation</label>
              <textarea
                value={charBackground}
                onChange={(e) => setCharBackground(e.target.value)}
                placeholder="Briefly state your origin or personal quest..."
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-violet-500 text-sm"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider">Physical Description (For Art Consistency)</label>
                <span className="text-[10px] text-slate-500">Determines character appearance in generated images</span>
              </div>
              <input
                type="text"
                value={charDesc}
                onChange={(e) => setCharDesc(e.target.value)}
                placeholder="Describe clothes, hair, unique gear..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-violet-500 text-sm"
              />
            </div>
          </div>

          {/* Section 2: Adventure Setting */}
          <div className="space-y-6 pt-4 border-t border-slate-800">
            <h2 className="text-xl font-bold flex items-center gap-2 text-fuchsia-400 border-b border-slate-800 pb-2">
              <Compass className="w-5 h-5" /> 2. Quest Setting
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {SETTING_PRESETS.map((set) => {
                const isSelected = selectedSetting === set.name && !customSetting;
                return (
                  <button
                    key={set.name}
                    type="button"
                    onClick={() => {
                      setSelectedSetting(set.name);
                      setCustomSetting('');
                    }}
                    className={`text-left p-4 rounded-xl border transition-all ${
                      isSelected
                        ? 'bg-fuchsia-950/20 border-fuchsia-500 shadow-md shadow-fuchsia-500/10'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <h3 className={`text-sm font-bold ${isSelected ? 'text-fuchsia-300' : 'text-slate-200'}`}>{set.name}</h3>
                    <p className="mt-1 text-xs text-slate-400 leading-relaxed">{set.desc}</p>
                  </button>
                );
              })}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Or Design Your Own Custom Setting</label>
              <input
                type="text"
                value={customSetting}
                onChange={(e) => setCustomSetting(e.target.value)}
                placeholder="e.g., A floating steam-fortress drifting in toxic violet clouds..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 text-sm"
              />
            </div>
          </div>

          {/* Section 3: Unified Art Style & Image size */}
          <div className="space-y-6 pt-4 border-t border-slate-800">
            <h2 className="text-xl font-bold flex items-center gap-2 text-indigo-400 border-b border-slate-800 pb-2">
              <ImageIcon className="w-5 h-5" /> 3. Visual Rendering Options
            </h2>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider">Visual Art Style Consistency</label>
                <span className="text-[10px] text-slate-500">Fixed modifiers added to all scene image generations</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {ART_STYLE_PRESETS.map((style) => {
                  const isSelected = selectedStyle.id === style.id;
                  return (
                    <button
                      key={style.id}
                      type="button;submit" // wait, make it regular button so it doesn't trigger submit
                      onClick={(e) => {
                        e.preventDefault();
                        setSelectedStyle(style);
                      }}
                      className={`text-left p-3 rounded-lg border text-xs transition-all ${
                        isSelected
                          ? 'bg-indigo-950/40 border-indigo-500 text-indigo-200 shadow-sm shadow-indigo-500/10'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <span className="font-bold block mb-1">{style.name}</span>
                      <span className="text-[10px] text-slate-500 line-clamp-1">{style.prompt}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Image Generation Quality (Size)</label>
              <div className="grid grid-cols-3 gap-3">
                {(['1K', '2K', '4K'] as const).map((size) => {
                  const isSelected = imageSize === size;
                  return (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setImageSize(size)}
                      className={`py-3 rounded-lg border font-mono font-bold text-sm transition-all ${
                        isSelected
                          ? 'bg-indigo-950/40 border-indigo-500 text-indigo-300 shadow-sm'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-500'
                      }`}
                    >
                      {size} {size === '1K' ? '(Standard)' : size === '2K' ? '(High)' : '(Ultra)'}
                    </button>
                  );
                })}
              </div>
              <p className="mt-2 text-xs text-slate-500 italic">
                Generates visuals using <code className="text-indigo-400">gemini-3-pro-image-preview</code> in 16:9 cinematic aspect ratio.
              </p>
            </div>
          </div>

          {/* Start Button */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={isGeneratingStart}
              className={`w-full py-4 rounded-xl font-bold uppercase tracking-wider text-sm transition-all shadow-lg flex items-center justify-center gap-2 ${
                isGeneratingStart
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-violet-600 via-indigo-600 to-fuchsia-600 text-white hover:from-violet-500 hover:via-indigo-500 hover:to-fuchsia-500 active:scale-[0.99] shadow-indigo-950/50'
              }`}
            >
              {isGeneratingStart ? (
                <>
                  <div className="animate-spin rounded-full h-4.5 w-4.5 border-t-2 border-b-2 border-violet-400" />
                  Generating Initial Narrative Segment...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 animate-pulse" />
                  Begin Adventure
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
