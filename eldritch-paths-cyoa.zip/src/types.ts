export interface Character {
  name: string;
  classType: string; // e.g., Warrior, Mage, Rogue, Cyber-Decker, Tech-Priest
  background: string; // Background story
  description: string; // Physical appearance (for image consistency)
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  status: 'active' | 'completed' | 'failed';
}

export interface InventoryItem {
  id: string;
  name: string;
  description: string;
  quantity: number;
}

export interface StorySegment {
  id: string;
  narrative: string;
  imagePrompt: string; // Detailed description of the scene for consistent generation
  imageUrl?: string; // Generated scene image
  choices: string[];
}

export interface GameState {
  character: Character | null;
  artStyle: {
    id: string;
    name: string;
    prompt: string; // Style modifiers for image generator
  } | null;
  setting: string;
  history: StorySegment[];
  currentQuests: Quest[];
  inventory: InventoryItem[];
  imageSize: '1K' | '2K' | '4K';
  isGameOver: boolean;
  gameOverReason?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  parts: { text: string }[];
  timestamp: string;
}

export interface Companion {
  id: string;
  name: string;
  role: string;
  avatar: string;
  personality: string;
  greeting: string;
}
