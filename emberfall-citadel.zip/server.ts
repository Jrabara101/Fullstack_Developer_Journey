import express from 'express';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { WebSocket, WebSocketServer } from 'ws';
import type { LeaderboardEntry, RaidRoomSummary, RemoteRaiderState } from './src/game/types';

const PORT = 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const LEADERBOARD_FILE = path.join(DATA_DIR, 'leaderboard.json');

const SEED_LEADERBOARD: LeaderboardEntry[] = [
  {
    id: 'seed-1',
    callsign: 'K.VANGUARD',
    score: 28450,
    wave: 11,
    kills: 142,
    bossesDefeated: 3,
    skin: 'solaris_vanguard',
    element: 'frost',
    mode: 'solo',
    season: 'Season 1: Obsidian Dawn',
    createdAt: '2026-11-12T18:10:00.000Z',
  },
  {
    id: 'seed-2',
    callsign: 'NYX.RIFT',
    score: 24120,
    wave: 9,
    kills: 118,
    bossesDefeated: 3,
    skin: 'void_stalker',
    element: 'void',
    mode: 'solo',
    season: 'Season 1: Obsidian Dawn',
    createdAt: '2026-11-13T09:45:00.000Z',
  },
  {
    id: 'seed-3',
    callsign: 'IRON.BASTION',
    score: 31900,
    wave: 12,
    kills: 168,
    bossesDefeated: 4,
    skin: 'cobalt_warden',
    element: 'volt',
    mode: 'coop',
    season: 'Season 1: Obsidian Dawn',
    createdAt: '2026-11-13T21:15:00.000Z',
  },
  {
    id: 'seed-4',
    callsign: 'EMBER.VALE',
    score: 19640,
    wave: 8,
    kills: 96,
    bossesDefeated: 2,
    skin: 'ashwalker',
    element: 'fire',
    mode: 'coop',
    season: 'Season 1: Obsidian Dawn',
    createdAt: '2026-11-14T04:20:00.000Z',
  },
  {
    id: 'seed-5',
    callsign: 'FROST.PIKE',
    score: 15880,
    wave: 6,
    kills: 79,
    bossesDefeated: 2,
    skin: 'cobalt_warden',
    element: 'frost',
    mode: 'solo',
    season: 'Season 1: Obsidian Dawn',
    createdAt: '2026-11-14T11:05:00.000Z',
  },
];

function loadLeaderboard(): LeaderboardEntry[] {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(LEADERBOARD_FILE)) {
      fs.writeFileSync(LEADERBOARD_FILE, JSON.stringify(SEED_LEADERBOARD, null, 2), 'utf8');
      return [...SEED_LEADERBOARD];
    }
    const raw = fs.readFileSync(LEADERBOARD_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [...SEED_LEADERBOARD];
  } catch {
    return [...SEED_LEADERBOARD];
  }
}

function saveLeaderboard(entries: LeaderboardEntry[]): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(LEADERBOARD_FILE, JSON.stringify(entries.slice(0, 100), null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to persist leaderboard:', err);
  }
}

interface RaidRoom {
  id: string;
  name: string;
  hostCallsign: string;
  maxPlayers: number;
  wave: number;
  status: 'open' | 'in_combat';
  clients: Map<string, { ws: WebSocket; state: RemoteRaiderState }>;
}

const raidRooms = new Map<string, RaidRoom>();

function toRoomSummary(room: RaidRoom): RaidRoomSummary {
  return {
    id: room.id,
    name: room.name,
    hostCallsign: room.hostCallsign,
    playerCount: room.clients.size,
    maxPlayers: room.maxPlayers,
    wave: room.wave,
    status: room.status,
  };
}

function broadcastToRoom(
  room: RaidRoom,
  payload: unknown,
  excludeClientId?: string
): void {
  const msg = JSON.stringify(payload);
  for (const [cid, entry] of room.clients.entries()) {
    if (cid === excludeClientId) continue;
    if (entry.ws.readyState === WebSocket.OPEN) {
      entry.ws.send(msg);
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  let leaderboard: LeaderboardEntry[] = loadLeaderboard();

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/leaderboard', (req, res) => {
    const mode = String(req.query.mode || 'all');
    const season = String(req.query.season || 'Season 1: Obsidian Dawn');
    const filtered = leaderboard
      .filter((e) => e.season === season && (mode === 'all' || e.mode === mode))
      .sort((a, b) => b.score - a.score)
      .slice(0, 25);
    res.json({ entries: filtered, season });
  });

  app.post('/api/leaderboard', (req, res) => {
    const body = req.body || {};
    const callsign = String(body.callsign || '').trim().toUpperCase().slice(0, 16);
    const score = Number(body.score);
    const wave = Number(body.wave);
    const kills = Number(body.kills || 0);
    const bossesDefeated = Number(body.bossesDefeated || 0);
    const skin = String(body.skin || 'ashwalker') as LeaderboardEntry['skin'];
    const element = String(body.element || 'fire') as LeaderboardEntry['element'];
    const mode = body.mode === 'coop' ? 'coop' : 'solo';
    const season = String(body.season || 'Season 1: Obsidian Dawn');

    if (!callsign || !Number.isFinite(score) || score < 0 || !Number.isFinite(wave) || wave < 1) {
      res.status(400).json({ error: 'Valid callsign, score, and wave are required.' });
      return;
    }

    const entry: LeaderboardEntry = {
      id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      callsign,
      score: Math.round(score),
      wave: Math.round(wave),
      kills: Math.max(0, Math.round(kills)),
      bossesDefeated: Math.max(0, Math.round(bossesDefeated)),
      skin,
      element,
      mode,
      season,
      createdAt: new Date().toISOString(),
    };

    leaderboard.push(entry);
    leaderboard.sort((a, b) => b.score - a.score);
    leaderboard = leaderboard.slice(0, 100);
    saveLeaderboard(leaderboard);

    res.status(201).json({ entry });
  });

  app.get('/api/raids', (_req, res) => {
    const rooms = Array.from(raidRooms.values()).map(toRoomSummary);
    res.json({ rooms });
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    const clientId = `raider-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
    let currentRoomId: string | null = null;

    const leaveCurrentRoom = () => {
      if (!currentRoomId) return;
      const room = raidRooms.get(currentRoomId);
      if (room) {
        room.clients.delete(clientId);
        broadcastToRoom(room, { type: 'raid:player_left', clientId });
        if (room.clients.size === 0) {
          raidRooms.delete(currentRoomId);
        }
      }
      currentRoomId = null;
    };

    ws.send(JSON.stringify({ type: 'ws:welcome', clientId }));

    ws.on('message', (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      const type = String(msg.type || '');
      if (type === 'raid:create') {
        leaveCurrentRoom();
        const code = `RAID-${Math.floor(100 + Math.random() * 900)}`;
        const callsign = String(msg.callsign || 'WARDEN').trim().toUpperCase().slice(0, 16) || 'WARDEN';
        const roomName = String(msg.roomName || `${callsign}'s Citadel Raid`).slice(0, 32);
        const room: RaidRoom = {
          id: code,
          name: roomName,
          hostCallsign: callsign,
          maxPlayers: 4,
          wave: 1,
          status: 'open',
          clients: new Map(),
        };
        const initialState: RemoteRaiderState = {
          clientId,
          callsign,
          skin: (msg.skin as RemoteRaiderState['skin']) || 'ashwalker',
          element: (msg.element as RemoteRaiderState['element']) || 'fire',
          x: 780,
          y: 710,
          vx: 0,
          vy: 0,
          facing: 1,
          hp: 100,
          maxHp: 100,
          attacking: false,
          dashing: false,
          updatedAt: Date.now(),
        };
        room.clients.set(clientId, { ws, state: initialState });
        raidRooms.set(code, room);
        currentRoomId = code;

        ws.send(
          JSON.stringify({
            type: 'raid:joined',
            room: toRoomSummary(room),
            players: [],
          })
        );
      } else if (type === 'raid:join') {
        const roomId = String(msg.roomId || '').trim().toUpperCase();
        const room = raidRooms.get(roomId);
        if (!room) {
          ws.send(JSON.stringify({ type: 'raid:error', message: `Raid room ${roomId} not found.` }));
          return;
        }
        if (room.clients.size >= room.maxPlayers) {
          ws.send(JSON.stringify({ type: 'raid:error', message: `Raid room ${roomId} is full.` }));
          return;
        }

        leaveCurrentRoom();
        const callsign = String(msg.callsign || 'WARDEN').trim().toUpperCase().slice(0, 16) || 'WARDEN';
        const initialState: RemoteRaiderState = {
          clientId,
          callsign,
          skin: (msg.skin as RemoteRaiderState['skin']) || 'ashwalker',
          element: (msg.element as RemoteRaiderState['element']) || 'fire',
          x: 720,
          y: 710,
          vx: 0,
          vy: 0,
          facing: 1,
          hp: 100,
          maxHp: 100,
          attacking: false,
          dashing: false,
          updatedAt: Date.now(),
        };
        const existingPlayers = Array.from(room.clients.values()).map((c) => c.state);
        room.clients.set(clientId, { ws, state: initialState });
        currentRoomId = roomId;

        ws.send(
          JSON.stringify({
            type: 'raid:joined',
            room: toRoomSummary(room),
            players: existingPlayers,
          })
        );
        broadcastToRoom(
          room,
          { type: 'raid:player_joined', player: initialState },
          clientId
        );
      } else if (type === 'raid:leave') {
        leaveCurrentRoom();
      } else if (type === 'raid:start') {
        if (!currentRoomId) return;
        const room = raidRooms.get(currentRoomId);
        if (!room) return;
        room.status = 'in_combat';
        broadcastToRoom(room, { type: 'raid:started', roomId: room.id });
      } else if (type === 'raid:player_state') {
        if (!currentRoomId) return;
        const room = raidRooms.get(currentRoomId);
        if (!room) return;
        const entry = room.clients.get(clientId);
        if (!entry) return;
        const payload = (msg.state || {}) as Partial<RemoteRaiderState>;
        entry.state = {
          ...entry.state,
          ...payload,
          clientId,
          updatedAt: Date.now(),
        };
        broadcastToRoom(
          room,
          { type: 'raid:state_sync', player: entry.state },
          clientId
        );
      }
    });

    ws.on('close', () => {
      leaveCurrentRoom();
    });
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Emberfall Citadel server listening on http://localhost:${PORT}`);
  });
}

startServer();
