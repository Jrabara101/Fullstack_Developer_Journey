import { useCallback, useEffect, useRef, useState } from 'react';
import { GameHud } from './components/GameHud';
import { GameOverModal, PauseModal } from './components/GameModals';
import { LoadoutModal } from './components/LoadoutModal';
import { RaidLeaderboardModal } from './components/RaidLeaderboardModal';
import { TitleScreen } from './components/TitleScreen';
import { gameAudio } from './game/audio';
import { INITIAL_PROFILE } from './game/catalog';
import { GameEngine } from './game/engine';
import {
  unlockAbilityNode,
  unlockOrSelectCompanion,
  unlockOrSelectSkin,
  upgradeWeaponElement,
} from './game/rules';
import type {
  CompanionId,
  ElementAffinity,
  GameStatus,
  HudSnapshot,
  PlayerProfile,
  RaidRoomSummary,
  RemoteRaiderState,
  RunSummary,
  SkinId,
} from './game/types';

const PROFILE_STORAGE_KEY = 'emberfall_profile_v1';

function loadProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(PROFILE_STORAGE_KEY);
    if (!raw) return INITIAL_PROFILE;
    const parsed = JSON.parse(raw);
    return {
      ...INITIAL_PROFILE,
      ...parsed,
      weaponLevels: {
        ...INITIAL_PROFILE.weaponLevels,
        ...(parsed.weaponLevels || {}),
      },
    };
  } catch {
    return INITIAL_PROFILE;
  }
}

const DEFAULT_HUD: HudSnapshot = {
  hp: 100,
  maxHp: 100,
  ghostHp: 100,
  score: 0,
  combo: 0,
  maxCombo: 0,
  wave: 1,
  enemiesRemaining: 0,
  kills: 0,
  essenceEarned: 0,
  activeElement: 'fire',
  weaponLevel: 1,
  dashReadyRatio: 1,
  companionReadyRatio: 1,
  companionActive: false,
  activeBuff: null,
  boss: null,
  shrinePrompt: {
    active: false,
    progress: 0,
    requiredElement: 'fire',
    solvedCount: 0,
  },
  bossesDefeated: 0,
  puzzlesSolved: 0,
  muted: false,
  raidRoomId: null,
  raidPlayersCount: 1,
};

export default function App() {
  const [profile, setProfile] = useState<PlayerProfile>(() => loadProfile());
  const [gameStatus, setGameStatus] = useState<GameStatus>('title');
  const [hud, setHud] = useState<HudSnapshot>(DEFAULT_HUD);
  const [runSummary, setRunSummary] = useState<RunSummary | null>(null);

  const [loadoutOpen, setLoadoutOpen] = useState(false);
  const [raidModalOpen, setRaidModalOpen] = useState(false);

  // WebSocket Raid state
  const [wsConnected, setWsConnected] = useState(false);
  const [activeRaidRoom, setActiveRaidRoom] = useState<RaidRoomSummary | null>(null);
  const [raidError, setRaidError] = useState<string | null>(null);
  const [raidPlayersCount, setRaidPlayersCount] = useState(1);

  const canvasContainerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const remotePlayersRef = useRef<Map<string, RemoteRaiderState>>(new Map());

  const profileRef = useRef(profile);
  profileRef.current = profile;
  const gameStatusRef = useRef(gameStatus);
  gameStatusRef.current = gameStatus;
  const activeRaidRef = useRef(activeRaidRoom);
  activeRaidRef.current = activeRaidRoom;

  // Persist profile
  useEffect(() => {
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
    } catch {
      // ignore storage quota errors
    }
    engineRef.current?.updateProfile(profile);
  }, [profile]);

  // Mirror game state onto body[data-state]
  useEffect(() => {
    document.body.dataset.state = gameStatus;
  }, [gameStatus]);

  const startRun = useCallback((raidRoomId: string | null = null) => {
    (document.activeElement as HTMLElement | null)?.blur?.();
    setLoadoutOpen(false);
    setRaidModalOpen(false);
    setRunSummary(null);
    setGameStatus('playing');
    document.body.dataset.state = 'playing';

    const roomId = raidRoomId ?? activeRaidRef.current?.id ?? null;
    if (engineRef.current) {
      engineRef.current.setRaidContext(
        roomId,
        Array.from(remotePlayersRef.current.values())
      );
      engineRef.current.startNewRun(roomId);
    }
  }, []);

  const togglePause = useCallback(() => {
    const status = gameStatusRef.current;
    if (status === 'playing') {
      engineRef.current?.setPaused(true);
      setGameStatus('paused');
    } else if (status === 'paused') {
      setLoadoutOpen(false);
      engineRef.current?.setPaused(false);
      setGameStatus('playing');
    }
  }, []);

  const handleToggleMute = useCallback(() => {
    gameAudio.muted = !gameAudio.muted;
    setHud((prev) => ({ ...prev, muted: gameAudio.muted }));
  }, []);

  const handleSelectElement = useCallback((elem: ElementAffinity) => {
    setProfile((prev) => ({ ...prev, activeElement: elem }));
  }, []);

  // Initialize GameEngine & ResizeObserver once
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = canvasContainerRef.current;
    if (!canvas || !container) return;

    const updateCanvasSize = () => {
      const rect = container.getBoundingClientRect();
      const targetW = Math.min(1024, Math.max(480, Math.floor(rect.width)));
      const aspect = rect.height > 0 ? rect.height / Math.max(1, rect.width) : 9 / 16;
      const targetH = Math.max(270, Math.round(targetW * aspect));
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }
    };
    updateCanvasSize();

    const ro = new ResizeObserver(updateCanvasSize);
    ro.observe(container);

    const engine = new GameEngine(canvas, profileRef.current, {
      onHudUpdate: (snapshot) => {
        setHud(snapshot);
      },
      onGameOver: (summary) => {
        setProfile((prev) => ({
          ...prev,
          essence: prev.essence + summary.essenceEarned,
          bestScore: Math.max(prev.bestScore, summary.score),
          bestWave: Math.max(prev.bestWave, summary.wave),
        }));
        setRunSummary(summary);
        setGameStatus('gameover');
      },
      onElementSwitch: (elem) => {
        setProfile((prev) => ({ ...prev, activeElement: elem }));
      },
      onPauseToggle: () => {
        togglePause();
      },
      onQuickRestart: () => {
        startRun();
      },
      onBroadcastPlayerState: (playerState) => {
        if (wsRef.current?.readyState === WebSocket.OPEN && activeRaidRef.current) {
          wsRef.current.send(
            JSON.stringify({
              type: 'raid:player_state',
              state: playerState,
            })
          );
        }
      },
    });
    engineRef.current = engine;

    // Support ?autostart=1
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      startRun(null);
    }

    return () => {
      ro.disconnect();
      engine.destroy();
      engineRef.current = null;
    };
  }, [startRun, togglePause]);

  // Connect WebSocket for real-time Co-Op Raids
  useEffect(() => {
    let alive = true;
    let reconnectTimer: number | null = null;

    const connect = () => {
      if (!alive) return;
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        if (!alive) return;
        setWsConnected(true);
        setRaidError(null);
      };

      ws.onclose = () => {
        if (!alive) return;
        setWsConnected(false);
        reconnectTimer = window.setTimeout(connect, 2500);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'raid:joined') {
            setRaidError(null);
            setActiveRaidRoom(msg.room);
            remotePlayersRef.current.clear();
            const players: RemoteRaiderState[] = Array.isArray(msg.players) ? msg.players : [];
            for (const p of players) {
              remotePlayersRef.current.set(p.clientId, p);
            }
            setRaidPlayersCount(1 + remotePlayersRef.current.size);
            engineRef.current?.setRaidContext(
              msg.room.id,
              Array.from(remotePlayersRef.current.values())
            );
          } else if (msg.type === 'raid:player_joined') {
            const p = msg.player as RemoteRaiderState;
            if (p?.clientId) {
              remotePlayersRef.current.set(p.clientId, p);
              setRaidPlayersCount(1 + remotePlayersRef.current.size);
              engineRef.current?.setRaidContext(
                activeRaidRef.current?.id ?? null,
                Array.from(remotePlayersRef.current.values())
              );
            }
          } else if (msg.type === 'raid:player_left') {
            remotePlayersRef.current.delete(msg.clientId);
            setRaidPlayersCount(1 + remotePlayersRef.current.size);
            engineRef.current?.setRaidContext(
              activeRaidRef.current?.id ?? null,
              Array.from(remotePlayersRef.current.values())
            );
          } else if (msg.type === 'raid:state_sync') {
            const p = msg.player as RemoteRaiderState;
            if (p?.clientId) {
              remotePlayersRef.current.set(p.clientId, p);
              engineRef.current?.setRaidContext(
                activeRaidRef.current?.id ?? null,
                Array.from(remotePlayersRef.current.values())
              );
            }
          } else if (msg.type === 'raid:started') {
            startRun(msg.roomId);
          } else if (msg.type === 'raid:error') {
            setRaidError(msg.message || 'Raid connection error');
          }
        } catch {
          // ignore malformed frames
        }
      };
    };

    connect();
    return () => {
      alive = false;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [startRun]);

  // Global keyboard shortcuts (Title Enter/Space start, M mute)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;

      if (e.code === 'KeyM') {
        handleToggleMute();
        return;
      }

      if (
        gameStatusRef.current === 'title' &&
        !loadoutOpen &&
        !raidModalOpen &&
        (e.code === 'Enter' || e.code === 'Space')
      ) {
        e.preventDefault();
        startRun(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleToggleMute, loadoutOpen, raidModalOpen, startRun]);

  // Raid actions
  const handleCreateRaid = (roomName: string) => {
    if (wsRef.current?.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(
      JSON.stringify({
        type: 'raid:create',
        roomName,
        callsign: profile.callsign,
        skin: profile.selectedSkin,
        element: profile.activeElement,
      })
    );
  };

  const handleJoinRaid = (roomId: string) => {
    if (wsRef.current?.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(
      JSON.stringify({
        type: 'raid:join',
        roomId,
        callsign: profile.callsign,
        skin: profile.selectedSkin,
        element: profile.activeElement,
      })
    );
  };

  const handleLeaveRaid = () => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'raid:leave' }));
    }
    remotePlayersRef.current.clear();
    setActiveRaidRoom(null);
    setRaidPlayersCount(1);
    engineRef.current?.setRaidContext(null, []);
  };

  const handleStartRaidRun = () => {
    if (wsRef.current?.readyState === WebSocket.OPEN && activeRaidRoom) {
      wsRef.current.send(JSON.stringify({ type: 'raid:start' }));
      startRun(activeRaidRoom.id);
    }
  };

  const handleReturnTitle = () => {
    engineRef.current?.stop();
    setRunSummary(null);
    setGameStatus('title');
  };

  return (
    <div className="relative w-full h-full bg-[#0b0d14] overflow-hidden">
      {/* Isolated Canvas Mount Container */}
      <div
        ref={canvasContainerRef}
        className={`absolute inset-0 ${gameStatus === 'title' ? 'invisible' : 'visible'}`}
      >
        <canvas
          ref={canvasRef}
          data-testid="game-canvas"
          className="block w-full h-full pixel-canvas"
        />
      </div>

      {/* Title Screen */}
      {gameStatus === 'title' && (
        <TitleScreen
          bestScore={profile.bestScore}
          bestWave={profile.bestWave}
          essence={profile.essence}
          onStartRun={() => startRun(null)}
          onOpenLoadout={() => setLoadoutOpen(true)}
          onOpenRaidLobby={() => setRaidModalOpen(true)}
        />
      )}

      {/* Active Gameplay HUD */}
      {(gameStatus === 'playing' || gameStatus === 'paused') && (
        <GameHud
          hud={hud}
          weaponLevels={profile.weaponLevels}
          onSelectElement={handleSelectElement}
          onToggleMute={handleToggleMute}
          onPause={togglePause}
          onRestart={() => startRun()}
        />
      )}

      {/* Pause Modal */}
      {gameStatus === 'paused' && !loadoutOpen && (
        <PauseModal
          onResume={togglePause}
          onRestart={() => startRun()}
          onOpenLoadout={() => setLoadoutOpen(true)}
          onExitTitle={handleReturnTitle}
        />
      )}

      {/* Game Over Modal */}
      {gameStatus === 'gameover' && runSummary && !loadoutOpen && !raidModalOpen && (
        <GameOverModal
          summary={runSummary}
          initialCallsign={profile.callsign}
          onPlayAgain={() => startRun()}
          onOpenLoadout={() => setLoadoutOpen(true)}
          onOpenLeaderboard={() => setRaidModalOpen(true)}
          onReturnTitle={handleReturnTitle}
        />
      )}

      {/* Character Customization, Ability Tree, Weapons & Companion Modal */}
      {loadoutOpen && (
        <LoadoutModal
          profile={profile}
          onClose={() => setLoadoutOpen(false)}
          onUnlockOrSelectSkin={(skinId: SkinId) =>
            setProfile((prev) => unlockOrSelectSkin(prev, skinId))
          }
          onUnlockNode={(nodeId: string) =>
            setProfile((prev) => unlockAbilityNode(prev, nodeId))
          }
          onUpgradeElement={(elem: ElementAffinity) =>
            setProfile((prev) => upgradeWeaponElement(prev, elem))
          }
          onSelectElement={handleSelectElement}
          onUnlockOrSelectCompanion={(compId: CompanionId) =>
            setProfile((prev) => unlockOrSelectCompanion(prev, compId))
          }
          onCallsignChange={(callsign: string) =>
            setProfile((prev) => ({ ...prev, callsign: callsign || 'WARDEN' }))
          }
        />
      )}

      {/* Seasonal Leaderboard & Co-Op Dungeon Raid Lobby */}
      {raidModalOpen && (
        <RaidLeaderboardModal
          callsign={profile.callsign}
          activeRaidRoom={activeRaidRoom}
          raidPlayersCount={raidPlayersCount}
          wsConnected={wsConnected}
          raidError={raidError}
          onClose={() => setRaidModalOpen(false)}
          onCreateRaid={handleCreateRaid}
          onJoinRaid={handleJoinRaid}
          onLeaveRaid={handleLeaveRaid}
          onStartRaidRun={handleStartRaidRun}
        />
      )}
    </div>
  );
}
