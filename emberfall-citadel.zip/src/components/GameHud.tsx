import { Pause, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { ELEMENTS } from '../game/catalog';
import type { ElementAffinity, HudSnapshot } from '../game/types';
import { ElementIcon, VitalityHeart } from './HudIcons';

interface GameHudProps {
  hud: HudSnapshot;
  weaponLevels: Record<ElementAffinity, number>;
  onSelectElement: (elem: ElementAffinity) => void;
  onToggleMute: () => void;
  onPause: () => void;
  onRestart: () => void;
}

const ELEMENT_ORDER: ElementAffinity[] = ['fire', 'frost', 'volt', 'void'];

export function GameHud({
  hud,
  weaponLevels,
  onSelectElement,
  onToggleMute,
  onPause,
  onRestart,
}: GameHudProps) {
  const hpPct = Math.max(0, Math.min(100, (hud.hp / Math.max(1, hud.maxHp)) * 100));
  const ghostPct = Math.max(hpPct, Math.min(100, (hud.ghostHp / Math.max(1, hud.maxHp)) * 100));
  const lowHp = hpPct <= 30;

  // 5 discrete vitality sockets derived from current HP ratio
  const sockets = Array.from({ length: 5 }, (_, idx) => {
    const threshold = (idx + 1) * 20;
    if (hpPct >= threshold - 5) return 'full';
    if (hpPct >= threshold - 18) return 'damaged';
    return 'empty';
  });

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4 md:p-5">
      {/* Low HP Peripheral Warning Vignette */}
      {lowHp && (
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            boxShadow: 'inset 0 0 90px rgba(220, 38, 38, 0.45)',
          }}
        />
      )}

      {/* Top Perimeter Row */}
      <div className="flex items-start justify-between gap-4">
        {/* Top-Left Cluster: Vitality + Cooldowns + Active Buff */}
        <div className="flex flex-col gap-2 min-w-[230px]">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1" aria-label={`Vitality ${hud.hp} of ${hud.maxHp}`}>
              {sockets.map((s, i) => (
                <VitalityHeart key={i} state={s} />
              ))}
            </div>
            <span className="font-mono-tabular text-sm font-bold text-white hud-text-stroke">
              {hud.hp}/{hud.maxHp}
            </span>
          </div>

          {/* Continuous HP bar with delayed drain ghost */}
          <div className="relative h-2.5 w-52 bg-[#090b12] border border-slate-700 overflow-hidden">
            <div
              className="absolute inset-y-0 left-0 bg-amber-300/75"
              style={{ width: `${ghostPct}%` }}
            />
            <div
              className="absolute inset-y-0 left-0 bg-red-500"
              style={{ width: `${hpPct}%` }}
            />
          </div>

          {/* Dash & Companion Readiness */}
          <div className="flex items-center gap-3 text-[11px] font-mono-tabular text-slate-200 hud-text-stroke">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">[K] DASH</span>
              <div className="w-14 h-1.5 bg-[#090b12] border border-slate-700">
                <div
                  className="h-full bg-sky-400"
                  style={{ width: `${Math.round(hud.dashReadyRatio * 100)}%` }}
                />
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">[Q] ALLY</span>
              <div className="w-14 h-1.5 bg-[#090b12] border border-slate-700">
                <div
                  className="h-full bg-amber-400"
                  style={{ width: `${Math.round(hud.companionReadyRatio * 100)}%` }}
                />
              </div>
            </div>
          </div>

          {hud.activeBuff && (
            <div className="text-xs font-display font-semibold text-emerald-300 hud-text-stroke">
              {hud.activeBuff.label} · {hud.activeBuff.remaining.toFixed(1)}s
            </div>
          )}
        </div>

        {/* Top-Center Cluster: Wave / Boss Phase / Shrine Cue */}
        <div className="flex flex-col items-center gap-2 max-w-md w-full">
          <div className="flex items-center gap-3 font-display font-bold text-sm md:text-base tracking-wide text-slate-100 hud-text-stroke">
            <span>WAVE {hud.wave}</span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span className="font-mono-tabular text-slate-300 text-xs">
              HOSTILES {hud.enemiesRemaining}
            </span>
            {hud.raidRoomId && (
              <>
                <span aria-hidden="true" className="text-slate-500">·</span>
                <span className="font-mono-tabular text-sky-300 text-xs">
                  RAID {hud.raidRoomId} ({hud.raidPlayersCount})
                </span>
              </>
            )}
          </div>

          {hud.boss && (
            <div className="w-full max-w-sm bg-[#0b0e18]/90 border-2 border-slate-700 px-3 py-2">
              <div className="flex items-center justify-between gap-2 text-xs mb-1">
                <span className="font-display font-bold text-amber-300 uppercase tracking-wider truncate">
                  {hud.boss.name} · PHASE {hud.boss.phase}
                </span>
                <span className="inline-flex items-center gap-1 font-mono-tabular text-slate-200 shrink-0">
                  <span>WEAK:</span>
                  <ElementIcon element={hud.boss.weakness} className="w-3.5 h-3.5" />
                  <span className="uppercase">{ELEMENTS[hud.boss.weakness].name}</span>
                </span>
              </div>
              <div className="relative h-3 w-full bg-[#07090f] border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-red-600 to-orange-500"
                  style={{
                    width: `${Math.max(0, Math.min(100, (hud.boss.hp / Math.max(1, hud.boss.maxHp)) * 100))}%`,
                  }}
                />
                {/* Phase Break Notches at 28% and 62% */}
                <div className="absolute inset-y-0 left-[28%] w-0.5 bg-[#07090f]" />
                <div className="absolute inset-y-0 left-[62%] w-0.5 bg-[#07090f]" />
              </div>
            </div>
          )}

          {hud.shrinePrompt.active && (
            <div className="text-xs font-display font-semibold text-emerald-300 hud-text-stroke">
              RUNIC SHRINE ACTIVE · MATCH {ELEMENTS[hud.shrinePrompt.requiredElement].name.toUpperCase()} &amp; PRESS [Q] ({Math.round(hud.shrinePrompt.progress * 100)}%)
            </div>
          )}
        </div>

        {/* Top-Right Cluster: Score + Essence + Utility Controls */}
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-[10px] font-mono-tabular text-slate-400 tracking-wider hud-text-stroke">
                SCORE {hud.combo > 1 ? `· ${hud.combo}X COMBO` : ''}
              </div>
              <div className="font-mono-tabular text-2xl font-bold text-white leading-none hud-text-stroke">
                {hud.score.toLocaleString()}
              </div>
            </div>

            <div className="flex items-center gap-1.5 pointer-events-auto">
              <button
                type="button"
                tabIndex={-1}
                aria-label={hud.muted ? 'Unmute audio' : 'Mute audio'}
                title="Toggle Audio [M]"
                onClick={(e) => {
                  e.currentTarget.blur();
                  onToggleMute();
                }}
                className="w-9 h-9 flex items-center justify-center bg-[#0f131e]/90 hover:bg-slate-800 border-2 border-slate-700 text-slate-200 cursor-pointer"
              >
                {hud.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <button
                type="button"
                tabIndex={-1}
                aria-label="Restart run"
                title="Restart Run [R]"
                onClick={(e) => {
                  e.currentTarget.blur();
                  onRestart();
                }}
                className="w-9 h-9 flex items-center justify-center bg-[#0f131e]/90 hover:bg-slate-800 border-2 border-slate-700 text-slate-200 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                type="button"
                tabIndex={-1}
                aria-label="Pause game"
                title="Pause [P / Esc]"
                onClick={(e) => {
                  e.currentTarget.blur();
                  onPause();
                }}
                className="w-9 h-9 flex items-center justify-center bg-[#0f131e]/90 hover:bg-slate-800 border-2 border-slate-700 text-slate-200 cursor-pointer"
              >
                <Pause className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="text-xs font-mono-tabular text-amber-300 hud-text-stroke">
            +{hud.essenceEarned.toLocaleString()} ESSENCE · {hud.kills} SLAIN
          </div>
        </div>
      </div>

      {/* Bottom Perimeter: 1-4 Elemental Weapon Switcher */}
      <div className="flex items-end justify-between gap-4">
        <div className="flex items-center gap-2 pointer-events-auto">
          {ELEMENT_ORDER.map((elemId, index) => {
            const def = ELEMENTS[elemId];
            const active = hud.activeElement === elemId;
            const isBossWeakness = hud.boss?.weakness === elemId;
            return (
              <button
                key={elemId}
                type="button"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  onSelectElement(elemId);
                }}
                aria-label={`Switch weapon to ${def.name} affinity`}
                className={`flex items-center gap-2 px-2.5 py-1.5 border-2 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[#171e30] border-amber-400 text-white'
                    : 'bg-[#0b0e18]/85 border-slate-700 text-slate-300 hover:border-slate-500'
                }`}
              >
                <span className="font-mono-tabular text-[11px] text-slate-400">[{index + 1}]</span>
                <ElementIcon element={elemId} className="w-4 h-4" />
                <span className="font-display font-bold text-xs tracking-wide">
                  {def.name} Lv.{weaponLevels[elemId] ?? 1}
                </span>
                {isBossWeakness && (
                  <span className="text-[10px] font-mono-tabular text-amber-300 font-bold">
                    WEAK
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="hidden md:block text-[11px] font-mono-tabular text-slate-300 hud-text-stroke">
          WASD Move · J Attack · K Dash · Q Companion · 1-4 Affinity
        </div>
      </div>
    </div>
  );
}
