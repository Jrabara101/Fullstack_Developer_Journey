import { useState } from 'react';
import { Play, RotateCcw, SlidersHorizontal, Trophy } from 'lucide-react';
import { CURRENT_SEASON } from '../game/catalog';
import type { RunSummary } from '../game/types';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onOpenLoadout: () => void;
  onExitTitle: () => void;
}

export function PauseModal({
  onResume,
  onRestart,
  onOpenLoadout,
  onExitTitle,
}: PauseModalProps) {
  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-black/70"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pause-modal-title"
    >
      <div className="pixel-panel w-full max-w-sm p-6 space-y-5">
        <div className="text-center">
          <div className="text-xs font-mono-tabular text-amber-400 tracking-wider">
            CITADEL PAUSED
          </div>
          <h2 id="pause-modal-title" className="font-display text-2xl font-bold text-white mt-1">
            Hold the Line
          </h2>
        </div>

        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onResume}
            className="pixel-btn inline-flex items-center justify-center gap-2 py-3 bg-orange-600 hover:bg-orange-500 border-orange-300/60 text-white font-display font-bold text-sm whitespace-nowrap cursor-pointer"
          >
            <Play className="w-4 h-4" />
            <span>Resume Battle</span>
          </button>

          <button
            type="button"
            onClick={onOpenLoadout}
            className="pixel-btn inline-flex items-center justify-center gap-2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-display font-semibold text-sm whitespace-nowrap cursor-pointer"
          >
            <SlidersHorizontal className="w-4 h-4 text-amber-400" />
            <span>Loadout &amp; Tree</span>
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="pixel-btn inline-flex items-center justify-center gap-2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-display font-semibold text-sm whitespace-nowrap cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart Run</span>
          </button>

          <button
            type="button"
            onClick={onExitTitle}
            className="py-2 text-xs font-display font-semibold text-slate-400 hover:text-white cursor-pointer"
          >
            Return to Title Screen
          </button>
        </div>
      </div>
    </div>
  );
}

interface GameOverModalProps {
  summary: RunSummary;
  initialCallsign: string;
  onPlayAgain: () => void;
  onOpenLoadout: () => void;
  onOpenLeaderboard: () => void;
  onReturnTitle: () => void;
}

export function GameOverModal({
  summary,
  initialCallsign,
  onPlayAgain,
  onOpenLoadout,
  onOpenLeaderboard,
  onReturnTitle,
}: GameOverModalProps) {
  const [callsign, setCallsign] = useState(initialCallsign);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmitScore = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = callsign.trim().toUpperCase();
    if (!trimmed) {
      setError('Enter a callsign before submitting.');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/leaderboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callsign: trimmed,
          score: summary.score,
          wave: summary.wave,
          kills: summary.kills,
          bossesDefeated: summary.bossesDefeated,
          skin: summary.skin,
          element: summary.element,
          mode: summary.mode,
          season: CURRENT_SEASON,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || 'Could not submit score.');
      } else {
        setSubmitted(true);
      }
    } catch {
      setError('Network error submitting score.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-black/78"
      role="dialog"
      aria-modal="true"
      aria-labelledby="gameover-modal-title"
    >
      <div className="pixel-panel w-full max-w-md p-6 space-y-5">
        <div className="text-center">
          <div className="text-xs font-mono-tabular text-red-400 tracking-wider">
            CITADEL BREACHED · WAVE {summary.wave}
          </div>
          <h2 id="gameover-modal-title" className="font-display text-3xl font-bold text-white mt-1">
            Fallen in Battle
          </h2>
        </div>

        {/* 3 Core Run Metrics */}
        <div className="grid grid-cols-3 gap-2.5 text-center">
          <div className="p-3 bg-[#0c101b] border border-slate-800">
            <div className="text-[10px] font-mono-tabular text-slate-400">FINAL SCORE</div>
            <div className="font-mono-tabular text-lg font-bold text-white mt-0.5">
              {summary.score.toLocaleString()}
            </div>
          </div>
          <div className="p-3 bg-[#0c101b] border border-slate-800">
            <div className="text-[10px] font-mono-tabular text-slate-400">BEST RECORD</div>
            <div className="font-mono-tabular text-lg font-bold text-amber-400 mt-0.5">
              {summary.bestScore.toLocaleString()}
            </div>
          </div>
          <div className="p-3 bg-[#0c101b] border border-slate-800">
            <div className="text-[10px] font-mono-tabular text-slate-400">ESSENCE</div>
            <div className="font-mono-tabular text-lg font-bold text-emerald-400 mt-0.5">
              +{summary.essenceEarned}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-center gap-3 text-xs font-mono-tabular text-slate-300">
          <span>{summary.kills} Slain</span>
          <span aria-hidden="true">·</span>
          <span>{summary.bossesDefeated} Bosses</span>
          <span aria-hidden="true">·</span>
          <span>{summary.puzzlesSolved} Shrines</span>
          <span aria-hidden="true">·</span>
          <span>{summary.maxCombo}x Max Combo</span>
        </div>

        {/* Submit to Seasonal Leaderboard */}
        {!submitted ? (
          <form onSubmit={handleSubmitScore} className="space-y-2">
            <div className="flex items-center gap-2">
              <label htmlFor="callsign-submit" className="sr-only">
                Callsign
              </label>
              <input
                id="callsign-submit"
                type="text"
                maxLength={16}
                value={callsign}
                onChange={(e) => setCallsign(e.target.value.toUpperCase())}
                placeholder="CALLSIGN"
                className="flex-1 px-3 py-2 bg-[#090b12] border border-slate-700 text-white font-mono-tabular text-sm focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                disabled={submitting}
                className="pixel-btn px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-display font-bold text-xs whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
              >
                {submitting ? 'Saving...' : 'Post Score'}
              </button>
            </div>
            {error && <div className="text-xs text-red-400">{error}</div>}
          </form>
        ) : (
          <div className="flex items-center justify-between p-2.5 bg-emerald-950/50 border border-emerald-600/60 text-xs text-emerald-300">
            <span>Score posted to {CURRENT_SEASON}!</span>
            <button
              type="button"
              onClick={onOpenLeaderboard}
              className="inline-flex items-center gap-1 font-display font-bold text-white underline cursor-pointer"
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>View Ranks</span>
            </button>
          </div>
        )}

        {/* Primary & Secondary Actions */}
        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            data-start="true"
            onClick={onPlayAgain}
            className="pixel-btn inline-flex items-center justify-center gap-2 py-3 bg-orange-600 hover:bg-orange-500 border-orange-300/60 text-white font-display font-bold text-sm whitespace-nowrap cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Play Again</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={onOpenLoadout}
              className="pixel-btn inline-flex items-center justify-center gap-1.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-display font-semibold text-xs whitespace-nowrap cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
              <span>Upgrade Tree</span>
            </button>
            <button
              type="button"
              onClick={onReturnTitle}
              className="pixel-btn py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-display font-semibold text-xs whitespace-nowrap cursor-pointer"
            >
              Title Screen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
