import type { ElementAffinity } from '../game/types';

export function EmberfallEmblem() {
  return (
    <svg
      viewBox="0 0 460 132"
      className="w-full max-w-[430px] h-auto"
      role="img"
      aria-label="Emberfall Citadel"
    >
      {/* Crest Sword & Bastion Crown Silhouette */}
      <g transform="translate(8, 12)">
        <polygon
          points="32,4 42,20 56,14 50,34 62,48 44,54 32,96 20,54 2,48 14,34 8,14 22,20"
          fill="#090b12"
          stroke="#f97316"
          strokeWidth="2.5"
        />
        <polygon points="32,12 37,48 32,84 27,48" fill="#fde047" />
        <rect x="20" y="42" width="24" height="6" fill="#ea580c" />
      </g>

      {/* Main Title Typography */}
      <text
        x="86"
        y="68"
        fill="#f8fafc"
        stroke="#07090f"
        strokeWidth="6"
        paintOrder="stroke fill"
        style={{
          fontFamily: "'Chakra Petch', sans-serif",
          fontWeight: 700,
          fontSize: '46px',
          letterSpacing: '0.04em',
        }}
      >
        EMBERFALL
      </text>
      <text
        x="88"
        y="104"
        fill="#fb923c"
        stroke="#07090f"
        strokeWidth="5"
        paintOrder="stroke fill"
        style={{
          fontFamily: "'Chakra Petch', sans-serif",
          fontWeight: 700,
          fontSize: '26px',
          letterSpacing: '0.24em',
        }}
      >
        CITADEL
      </text>
    </svg>
  );
}

export function ElementIcon({
  element,
  className = 'w-5 h-5',
}: {
  element: ElementAffinity;
  className?: string;
}) {
  if (element === 'fire') {
    return (
      <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
        <path
          d="M12 2L16 8L19 7L18 14C18 17.5 15.3 20.5 12 21C8.7 20.5 6 17.5 6 14L7 8L10 10L12 2Z"
          fill="#f97316"
          stroke="#07090f"
          strokeWidth="1.6"
        />
        <path d="M12 10L14 14L12 18L10 14L12 10Z" fill="#fde047" />
      </svg>
    );
  }
  if (element === 'frost') {
    return (
      <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
        <polygon
          points="12,2 15,8 21,9 16,13 18,20 12,16 6,20 8,13 3,9 9,8"
          fill="#38bdf8"
          stroke="#07090f"
          strokeWidth="1.6"
        />
        <rect x="10" y="9" width="4" height="6" fill="#e0f2fe" />
      </svg>
    );
  }
  if (element === 'volt') {
    return (
      <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
        <polygon
          points="14,2 5,13 11,13 9,22 19,10 13,10"
          fill="#facc15"
          stroke="#07090f"
          strokeWidth="1.6"
        />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <circle cx="12" cy="12" r="8" fill="#9333ea" stroke="#07090f" strokeWidth="1.6" />
      <polygon points="12,6 16,12 12,18 8,12" fill="#f0abfc" />
    </svg>
  );
}

export function VitalityHeart({
  state,
}: {
  state: 'full' | 'damaged' | 'empty';
}) {
  const fill =
    state === 'full' ? '#ef4444' : state === 'damaged' ? '#f97316' : '#1e293b';
  const highlight = state === 'full' ? '#fca5a5' : state === 'damaged' ? '#fde047' : '#334155';
  return (
    <svg viewBox="0 0 20 20" className="w-5 h-5" aria-hidden="true">
      <path
        d="M4 3H8L10 5L12 3H16L18 6V10L10 18L2 10V6L4 3Z"
        fill={fill}
        stroke="#07090f"
        strokeWidth="1.8"
      />
      <rect x="4" y="5" width="3" height="3" fill={highlight} />
    </svg>
  );
}
