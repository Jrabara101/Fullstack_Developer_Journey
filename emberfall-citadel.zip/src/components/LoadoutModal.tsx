import { useState } from 'react';
import { Check, Lock, Sparkles, X } from 'lucide-react';
import { ABILITY_TREE, COMPANIONS, ELEMENTS, SKINS } from '../game/catalog';
import {
  canUnlockAbilityNode,
  computePlayerStats,
  getWeaponDamageMultiplier,
  getWeaponUpgradeCost,
} from '../game/rules';
import type {
  AbilityBranch,
  CompanionId,
  ElementAffinity,
  PlayerProfile,
  SkinId,
} from '../game/types';
import { ElementIcon } from './HudIcons';

interface LoadoutModalProps {
  profile: PlayerProfile;
  onClose: () => void;
  onUnlockOrSelectSkin: (skinId: SkinId) => void;
  onUnlockNode: (nodeId: string) => void;
  onUpgradeElement: (elem: ElementAffinity) => void;
  onSelectElement: (elem: ElementAffinity) => void;
  onUnlockOrSelectCompanion: (compId: CompanionId) => void;
  onCallsignChange: (callsign: string) => void;
}

type LoadoutTab = 'skins' | 'abilities' | 'weapons' | 'companions';

const BRANCH_LABELS: Record<AbilityBranch, string> = {
  vanguard: 'Vanguard · Combat',
  tempest: 'Tempest · Mobility',
  arcana: 'Arcana · Survival',
};

export function LoadoutModal({
  profile,
  onClose,
  onUnlockOrSelectSkin,
  onUnlockNode,
  onUpgradeElement,
  onSelectElement,
  onUnlockOrSelectCompanion,
  onCallsignChange,
}: LoadoutModalProps) {
  const [tab, setTab] = useState<LoadoutTab>('skins');
  const stats = computePlayerStats(profile);

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/75"
      role="dialog"
      aria-modal="true"
      aria-labelledby="loadout-modal-title"
    >
      <div className="pixel-panel w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 border-b-2 border-slate-800 bg-[#0c101b]">
          <div>
            <h2
              id="loadout-modal-title"
              className="font-display text-xl font-bold tracking-wide text-white"
            >
              Vanguard Loadout &amp; Ability Tree
            </h2>
            <div className="flex items-center gap-3 text-xs font-mono-tabular text-slate-400 mt-1">
              <span>MAX HP {stats.maxHp}</span>
              <span aria-hidden="true">·</span>
              <span>BASE DMG {stats.baseDamage}</span>
              <span aria-hidden="true">·</span>
              <span>CRIT {Math.round(stats.critChance * 100)}%</span>
              <span aria-hidden="true">·</span>
              <span>SPEED {stats.moveSpeed}</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm font-mono-tabular font-bold text-amber-400">
              <Sparkles className="w-4 h-4" />
              <span>{profile.essence.toLocaleString()} ESSENCE</span>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close loadout"
              className="w-9 h-9 flex items-center justify-center bg-slate-800 hover:bg-slate-700 border-2 border-slate-600 text-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs + Callsign */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3 border-b border-slate-800 bg-[#101524]">
          <div className="flex items-center gap-1.5" role="tablist" aria-label="Loadout sections">
            {(
              [
                ['skins', 'Armor Skins'],
                ['abilities', 'Ability Tree'],
                ['weapons', 'Elemental Weapons'],
                ['companions', 'Companions'],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={tab === id}
                onClick={() => setTab(id)}
                className={`px-3.5 py-2 text-xs font-display font-bold tracking-wide border-2 whitespace-nowrap shrink-0 cursor-pointer ${
                  tab === id
                    ? 'bg-orange-600 border-orange-300/60 text-white'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-300">
            <span className="font-mono-tabular text-slate-400">CALLSIGN</span>
            <input
              type="text"
              value={profile.callsign}
              maxLength={16}
              onChange={(e) => onCallsignChange(e.target.value.toUpperCase())}
              className="w-32 px-2.5 py-1 bg-[#090b12] border border-slate-700 text-white font-mono-tabular text-xs focus:outline-none focus:border-amber-400"
            />
          </label>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {tab === 'skins' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {SKINS.map((skin) => {
                const unlocked = profile.unlockedSkins.includes(skin.id);
                const selected = profile.selectedSkin === skin.id;
                const canAfford = profile.essence >= skin.cost;

                return (
                  <div
                    key={skin.id}
                    className={`p-4 border-2 flex items-center justify-between gap-4 ${
                      selected
                        ? 'bg-[#172033] border-amber-400'
                        : 'bg-[#111625] border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-4 min-w-0">
                      {/* Pixel Armor Swatch */}
                      <div className="w-14 h-16 shrink-0 bg-[#090b12] border border-slate-700 flex flex-col items-center justify-center p-1.5">
                        <div
                          className="w-6 h-4 border border-black"
                          style={{ backgroundColor: skin.armorPrimary }}
                        />
                        <div className="flex items-center w-8 h-6">
                          <div
                            className="w-2 h-5"
                            style={{ backgroundColor: skin.capeColor }}
                          />
                          <div
                            className="w-6 h-6 border border-black flex items-center justify-center"
                            style={{ backgroundColor: skin.armorSecondary }}
                          >
                            <div
                              className="w-3 h-1.5"
                              style={{ backgroundColor: skin.visorGlow }}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="min-w-0">
                        <div className="font-display font-bold text-base text-white truncate">
                          {skin.name}
                        </div>
                        <div className="text-xs text-slate-400">
                          {skin.title} · {skin.bonusLabel}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={!unlocked && !canAfford}
                      onClick={() => onUnlockOrSelectSkin(skin.id)}
                      className={`pixel-btn px-3.5 py-2 text-xs font-display font-bold whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed ${
                        selected
                          ? 'bg-emerald-600 border-emerald-300/60 text-white'
                          : unlocked
                          ? 'bg-slate-700 hover:bg-slate-600 text-white'
                          : 'bg-amber-600 hover:bg-amber-500 text-white'
                      }`}
                    >
                      {selected ? 'Equipped' : unlocked ? 'Equip' : `Unlock · ${skin.cost}`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'abilities' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {(['vanguard', 'tempest', 'arcana'] as AbilityBranch[]).map((branch) => {
                const nodes = ABILITY_TREE.filter((n) => n.branch === branch);
                return (
                  <div key={branch} className="bg-[#111625] border-2 border-slate-700 p-4 flex flex-col gap-3">
                    <h3 className="font-display font-bold text-sm text-amber-300 tracking-wide border-b border-slate-800 pb-2">
                      {BRANCH_LABELS[branch]}
                    </h3>
                    {nodes.map((node, idx) => {
                      const unlocked = profile.unlockedNodes.includes(node.id);
                      const available = canUnlockAbilityNode(profile, node.id);
                      const reqMet = !node.requires || profile.unlockedNodes.includes(node.requires);

                      return (
                        <div
                          key={node.id}
                          className={`p-3 border ${
                            unlocked
                              ? 'bg-[#172638] border-emerald-500/70'
                              : available
                              ? 'bg-[#161c2e] border-amber-400/70'
                              : 'bg-[#0d111c] border-slate-800 opacity-80'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="font-display font-bold text-sm text-white">
                              {idx + 1}. {node.name}
                            </span>
                            {unlocked ? (
                              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : !reqMet ? (
                              <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            ) : null}
                          </div>
                          <p className="text-xs text-slate-300 mb-2.5">{node.description}</p>
                          <button
                            type="button"
                            disabled={unlocked || !available}
                            onClick={() => onUnlockNode(node.id)}
                            className={`w-full py-1.5 text-xs font-display font-bold border whitespace-nowrap cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed ${
                              unlocked
                                ? 'bg-emerald-900/40 border-emerald-600/50 text-emerald-300'
                                : available
                                ? 'bg-amber-600 hover:bg-amber-500 border-amber-300/60 text-white'
                                : 'bg-slate-800 border-slate-700 text-slate-400'
                            }`}
                          >
                            {unlocked
                              ? 'Unlocked'
                              : reqMet
                              ? `Unlock · ${node.cost} Essence`
                              : 'Requires Previous Tier'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'weapons' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(['fire', 'frost', 'volt', 'void'] as ElementAffinity[]).map((elemId) => {
                const elem = ELEMENTS[elemId];
                const lvl = profile.weaponLevels[elemId] ?? 1;
                const cost = getWeaponUpgradeCost(lvl);
                const isMax = lvl >= 5;
                const canAfford = profile.essence >= cost;
                const active = profile.activeElement === elemId;
                const dmgMul = Math.round(getWeaponDamageMultiplier(lvl) * 100);

                return (
                  <div
                    key={elemId}
                    className={`p-4 border-2 flex flex-col justify-between gap-3 ${
                      active ? 'bg-[#172033] border-amber-400' : 'bg-[#111625] border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#090b12] border border-slate-700 flex items-center justify-center">
                          <ElementIcon element={elemId} className="w-6 h-6" />
                        </div>
                        <div>
                          <div className="font-display font-bold text-base text-white">
                            {elem.weaponName} · Lv.{lvl}
                          </div>
                          <div className="text-xs text-slate-400">
                            {elem.name} Affinity · {dmgMul}% Power
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="text-xs text-slate-300 space-y-1">
                      <div>{elem.role}</div>
                      <div className="text-amber-300 font-medium">{elem.countersLabel}</div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => onSelectElement(elemId)}
                        className={`flex-1 py-2 text-xs font-display font-bold border whitespace-nowrap cursor-pointer ${
                          active
                            ? 'bg-emerald-600 border-emerald-400 text-white'
                            : 'bg-slate-800 hover:bg-slate-700 border-slate-600 text-slate-200'
                        }`}
                      >
                        {active ? 'Starting Affinity' : 'Set Starting Affinity'}
                      </button>

                      <button
                        type="button"
                        disabled={isMax || !canAfford}
                        onClick={() => onUpgradeElement(elemId)}
                        className="flex-1 py-2 text-xs font-display font-bold bg-orange-600 hover:bg-orange-500 border border-orange-300/60 text-white whitespace-nowrap cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed"
                      >
                        {isMax ? 'Max Level' : `Upgrade · ${cost}`}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'companions' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {COMPANIONS.map((comp) => {
                const unlocked = profile.unlockedCompanions.includes(comp.id);
                const selected = profile.selectedCompanion === comp.id;
                const canAfford = profile.essence >= comp.cost;

                return (
                  <div
                    key={comp.id}
                    className={`p-4 border-2 flex flex-col justify-between gap-4 ${
                      selected
                        ? 'bg-[#172033] border-amber-400'
                        : 'bg-[#111625] border-slate-700'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-8 h-8 border-2 border-black shrink-0"
                          style={{ backgroundColor: comp.color }}
                        />
                        <div className="font-display font-bold text-base text-white">
                          {comp.name}
                        </div>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{comp.role}</p>
                      <div className="text-xs text-emerald-300">{comp.puzzleBonus}</div>
                      <div className="text-xs text-amber-300">{comp.buffDescription}</div>
                    </div>

                    <button
                      type="button"
                      disabled={!unlocked && !canAfford}
                      onClick={() => onUnlockOrSelectCompanion(comp.id)}
                      className={`pixel-btn w-full py-2 text-xs font-display font-bold whitespace-nowrap cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed ${
                        selected
                          ? 'bg-emerald-600 border-emerald-300/60 text-white'
                          : unlocked
                          ? 'bg-slate-700 hover:bg-slate-600 text-white'
                          : 'bg-amber-600 hover:bg-amber-500 text-white'
                      }`}
                    >
                      {selected
                        ? 'Active Companion'
                        : unlocked
                        ? 'Summon Partner'
                        : `Unlock · ${comp.cost}`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
