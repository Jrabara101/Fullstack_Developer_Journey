import { useEffect, useState } from 'react';
import { RefreshCw, Swords, Trophy, Users, X } from 'lucide-react';
import { CURRENT_SEASON, ELEMENTS } from '../game/catalog';
import type { LeaderboardEntry, RaidRoomSummary } from '../game/types';
import { ElementIcon } from './HudIcons';

interface RaidLeaderboardModalProps {
  callsign: string;
  activeRaidRoom: RaidRoomSummary | null;
  raidPlayersCount: number;
  wsConnected: boolean;
  raidError: string | null;
  onClose: () => void;
  onCreateRaid: (roomName: string) => void;
  onJoinRaid: (roomId: string) => void;
  onLeaveRaid: () => void;
  onStartRaidRun: () => void;
}

export function RaidLeaderboardModal({
  callsign,
  activeRaidRoom,
  raidPlayersCount,
  wsConnected,
  raidError,
  onClose,
  onCreateRaid,
  onJoinRaid,
  onLeaveRaid,
  onStartRaidRun,
}: RaidLeaderboardModalProps) {
  const [tab, setTab] = useState<'leaderboard' | 'coop'>('leaderboard');
  const [modeFilter, setModeFilter] = useState<'all' | 'solo' | 'coop'>('all');
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loadingBoard, setLoadingBoard] = useState(false);

  const [rooms, setRooms] = useState<RaidRoomSummary[]>([]);
  const [roomName, setRoomName] = useState(`${callsign} Citadel Raid`);
  const [joinCode, setJoinCode] = useState('');

  const fetchLeaderboard = async (mode: 'all' | 'solo' | 'coop') => {
    setLoadingBoard(true);
    try {
      const res = await fetch(
        `/api/leaderboard?mode=${encodeURIComponent(mode)}&season=${encodeURIComponent(CURRENT_SEASON)}`
      );
      if (res.ok) {
        const data = await res.json();
        setEntries(Array.isArray(data.entries) ? data.entries : []);
      }
    } catch {
      // ignore transient errors
    } finally {
      setLoadingBoard(false);
    }
  };

  const fetchRooms = async () => {
    try {
      const res = await fetch('/api/raids');
      if (res.ok) {
        const data = await res.json();
        setRooms(Array.isArray(data.rooms) ? data.rooms : []);
      }
    } catch {
      // ignore transient errors
    }
  };

  useEffect(() => {
    if (tab === 'leaderboard') {
      fetchLeaderboard(modeFilter);
    } else {
      fetchRooms();
    }
  }, [tab, modeFilter, activeRaidRoom]);

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/75"
      role="dialog"
      aria-modal="true"
      aria-labelledby="network-modal-title"
    >
      <div className="pixel-panel w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 px-6 py-4 border-b-2 border-slate-800 bg-[#0c101b]">
          <div>
            <h2
              id="network-modal-title"
              className="font-display text-xl font-bold tracking-wide text-white"
            >
              Seasonal Ranks &amp; Co-Op Dungeon Raids
            </h2>
            <div className="text-xs font-mono-tabular text-slate-400 mt-1">
              {CURRENT_SEASON} · Network {wsConnected ? 'Connected' : 'Connecting...'}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close network modal"
            className="w-9 h-9 flex items-center justify-center bg-slate-800 hover:bg-slate-700 border-2 border-slate-600 text-slate-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3 border-b border-slate-800 bg-[#101524]">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setTab('leaderboard')}
              className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-display font-bold border-2 whitespace-nowrap cursor-pointer ${
                tab === 'leaderboard'
                  ? 'bg-orange-600 border-orange-300/60 text-white'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span>Seasonal Leaderboard</span>
            </button>

            <button
              type="button"
              onClick={() => setTab('coop')}
              className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-display font-bold border-2 whitespace-nowrap cursor-pointer ${
                tab === 'coop'
                  ? 'bg-sky-600 border-sky-300/60 text-white'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Co-Op Raid Lobby</span>
            </button>
          </div>

          {tab === 'leaderboard' && (
            <div className="flex items-center gap-1">
              {(['all', 'solo', 'coop'] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setModeFilter(m)}
                  className={`px-3 py-1.5 text-xs font-mono-tabular uppercase border whitespace-nowrap cursor-pointer ${
                    modeFilter === m
                      ? 'bg-slate-700 border-amber-400 text-white'
                      : 'bg-[#090b12] border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {tab === 'leaderboard' && (
            <div>
              {loadingBoard ? (
                <div className="py-12 text-center text-sm text-slate-400">
                  Loading seasonal standings...
                </div>
              ) : entries.length === 0 ? (
                <div className="py-12 text-center text-sm text-slate-400">
                  No seasonal records yet. Complete a run to claim Rank #1.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-700 text-[11px] font-mono-tabular text-slate-400 uppercase">
                        <th className="py-2.5 px-3">Rank</th>
                        <th className="py-2.5 px-3">Warden</th>
                        <th className="py-2.5 px-3">Mode</th>
                        <th className="py-2.5 px-3">Affinity</th>
                        <th className="py-2.5 px-3 text-right">Wave</th>
                        <th className="py-2.5 px-3 text-right">Bosses</th>
                        <th className="py-2.5 px-3 text-right">Score</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 text-sm">
                      {entries.map((entry, idx) => (
                        <tr key={entry.id} className="hover:bg-slate-800/40">
                          <td className="py-2.5 px-3 font-mono-tabular font-bold text-amber-400">
                            #{idx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-display font-bold text-white">
                            {entry.callsign}
                          </td>
                          <td className="py-2.5 px-3 font-mono-tabular text-xs text-slate-300 uppercase">
                            {entry.mode}
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="inline-flex items-center gap-1.5 text-xs text-slate-200">
                              <ElementIcon element={entry.element} className="w-4 h-4" />
                              <span>{ELEMENTS[entry.element]?.name ?? entry.element}</span>
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-tabular text-slate-200">
                            {entry.wave}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-tabular text-slate-300">
                            {entry.bossesDefeated}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-tabular font-bold text-white">
                            {entry.score.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {tab === 'coop' && (
            <div className="space-y-6">
              {raidError && (
                <div className="p-3 bg-red-950/60 border border-red-500 text-xs text-red-200">
                  {raidError}
                </div>
              )}

              {activeRaidRoom ? (
                <div className="p-5 bg-[#121a2d] border-2 border-sky-400 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <div className="text-xs font-mono-tabular text-sky-300">
                        ACTIVE RAID SQUAD · CODE {activeRaidRoom.id}
                      </div>
                      <h3 className="font-display font-bold text-xl text-white mt-0.5">
                        {activeRaidRoom.name}
                      </h3>
                      <div className="text-xs text-slate-300 mt-1">
                        Host: {activeRaidRoom.hostCallsign} · Raiders Connected: {raidPlayersCount}/{activeRaidRoom.maxPlayers}
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      <button
                        type="button"
                        onClick={onStartRaidRun}
                        data-start="true"
                        className="pixel-btn inline-flex items-center gap-2 px-5 py-2.5 bg-orange-600 hover:bg-orange-500 border-orange-300/60 text-white font-display font-bold text-sm whitespace-nowrap cursor-pointer"
                      >
                        <Swords className="w-4 h-4" />
                        <span>Deploy Raid</span>
                      </button>
                      <button
                        type="button"
                        onClick={onLeaveRaid}
                        className="pixel-btn px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-display font-semibold text-xs whitespace-nowrap cursor-pointer"
                      >
                        Leave Room
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400">
                    Share code <span className="font-mono-tabular text-white">{activeRaidRoom.id}</span> with
                    another browser tab or squadmate to battle synchronized Co-Op Raid bosses together.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* Create Raid Room */}
                  <div className="p-4 bg-[#111625] border-2 border-slate-700 space-y-3">
                    <h3 className="font-display font-bold text-base text-white">
                      Host Co-Op Raid Room
                    </h3>
                    <label className="block text-xs text-slate-300 space-y-1">
                      <span>Squad Name</span>
                      <input
                        type="text"
                        value={roomName}
                        maxLength={32}
                        onChange={(e) => setRoomName(e.target.value)}
                        className="w-full px-3 py-2 bg-[#090b12] border border-slate-700 text-white text-sm focus:outline-none focus:border-sky-400"
                      />
                    </label>
                    <button
                      type="button"
                      disabled={!wsConnected}
                      onClick={() => onCreateRaid(roomName)}
                      className="pixel-btn w-full py-2.5 bg-sky-600 hover:bg-sky-500 border-sky-300/60 text-white font-display font-bold text-xs whitespace-nowrap cursor-pointer disabled:opacity-50"
                    >
                      Create Raid Room
                    </button>
                  </div>

                  {/* Join by Room Code */}
                  <div className="p-4 bg-[#111625] border-2 border-slate-700 space-y-3">
                    <h3 className="font-display font-bold text-base text-white">
                      Join by Raid Code
                    </h3>
                    <label className="block text-xs text-slate-300 space-y-1">
                      <span>Room Code (e.g. RAID-402)</span>
                      <input
                        type="text"
                        value={joinCode}
                        placeholder="RAID-XXX"
                        onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                        className="w-full px-3 py-2 bg-[#090b12] border border-slate-700 text-white font-mono-tabular text-sm focus:outline-none focus:border-amber-400"
                      />
                    </label>
                    <button
                      type="button"
                      disabled={!wsConnected || !joinCode.trim()}
                      onClick={() => onJoinRaid(joinCode.trim())}
                      className="pixel-btn w-full py-2.5 bg-slate-700 hover:bg-slate-600 text-white font-display font-bold text-xs whitespace-nowrap cursor-pointer disabled:opacity-45"
                    >
                      Join Raid Squad
                    </button>
                  </div>
                </div>
              )}

              {/* Open Raid Rooms List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-display font-bold text-sm text-slate-200 tracking-wide">
                    Active Raid Sessions
                  </h3>
                  <button
                    type="button"
                    onClick={fetchRooms}
                    className="inline-flex items-center gap-1.5 text-xs text-slate-300 hover:text-white cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>

                {rooms.length === 0 ? (
                  <div className="p-4 bg-[#0d111c] border border-slate-800 text-xs text-slate-400">
                    No active raid rooms open right now. Host a squad above to open one.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {rooms.map((r) => (
                      <div
                        key={r.id}
                        className="p-3.5 bg-[#111625] border border-slate-700 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <div className="font-display font-bold text-sm text-white truncate">
                            {r.name}
                          </div>
                          <div className="text-xs font-mono-tabular text-slate-400">
                            {r.id} · {r.playerCount}/{r.maxPlayers} Raiders · Host {r.hostCallsign}
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={activeRaidRoom?.id === r.id}
                          onClick={() => onJoinRaid(r.id)}
                          className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-display font-bold text-xs whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-45"
                        >
                          {activeRaidRoom?.id === r.id ? 'Joined' : 'Join'}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
