import titleBgUrl from '../assets/images/title_bg_1794713754965.jpg';
import { EmberfallEmblem } from './HudIcons';
import { Swords, SlidersHorizontal, Users } from 'lucide-react';

interface TitleScreenProps {
  bestScore: number;
  bestWave: number;
  essence: number;
  onStartRun: () => void;
  onOpenLoadout: () => void;
  onOpenRaidLobby: () => void;
}

export function TitleScreen({
  bestScore,
  bestWave,
  essence,
  onStartRun,
  onOpenLoadout,
  onOpenRaidLobby,
}: TitleScreenProps) {
  return (
    <div className="relative w-full h-full overflow-hidden bg-[#0a0d17]">
      {/* Illustrated Pixel-Art Citadel Key Art Backdrop */}
      <img
        src={titleBgUrl}
        alt="Emberfall Citadel perched above glowing magma fissures"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover object-center pixel-canvas"
      />

      {/* Contrast Scrim over Left Negative Space */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'linear-gradient(90deg, rgba(8,10,18,0.92) 0%, rgba(8,10,18,0.72) 42%, rgba(8,10,18,0.18) 100%)',
        }}
      />

      {/* Left-Third Title Lockup & Menu Actions */}
      <main className="relative z-10 h-full flex flex-col justify-between px-8 py-8 md:px-14 md:py-10">
        {/* Top Best Record Line (clean unboxed text) */}
        <div className="flex items-center gap-3 text-xs font-mono-tabular text-slate-300 tracking-wide">
          <span>BEST SCORE {bestScore.toLocaleString()}</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span>MAX WAVE {bestWave}</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="text-amber-400">{essence.toLocaleString()} ESSENCE</span>
        </div>

        {/* Center Hero Lockup */}
        <div className="my-auto flex flex-col items-start gap-6 max-w-xl">
          <EmberfallEmblem />
          <p className="text-sm md:text-base text-slate-300 max-w-md leading-relaxed">
            Survive relentless obsidian hordes, counter multi-stage bullet-hell bosses
            with elemental weapons, and awaken companion shrine relics alone or in co-op raids.
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              type="button"
              data-start="true"
              onClick={onStartRun}
              className="pixel-btn inline-flex items-center justify-center gap-2.5 px-6 py-3.5 bg-orange-600 hover:bg-orange-500 border-orange-300/60 text-white font-display font-bold text-base tracking-wide whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Swords className="w-5 h-5" />
              <span>Start Endless Run</span>
            </button>

            <button
              type="button"
              onClick={onOpenLoadout}
              className="pixel-btn inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-display font-semibold text-sm tracking-wide whitespace-nowrap shrink-0 cursor-pointer"
            >
              <SlidersHorizontal className="w-4 h-4 text-amber-400" />
              <span>Loadout &amp; Tree</span>
            </button>

            <button
              type="button"
              onClick={onOpenRaidLobby}
              className="pixel-btn inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-display font-semibold text-sm tracking-wide whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Users className="w-4 h-4 text-sky-400" />
              <span>Co-Op &amp; Ranks</span>
            </button>
          </div>
        </div>

        {/* Single Flat Control-Hint Line */}
        <div className="text-xs font-mono-tabular text-slate-300 tracking-wide whitespace-nowrap overflow-hidden text-ellipsis">
          A/D Move · W/Space Jump · J/Click Attack · K Dash · Q Companion · 1-4 Element · Esc Pause
        </div>
      </main>
    </div>
  );
}
