class GameAudio {
  private ctx: AudioContext | null = null;
  public muted = false;

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private vary(baseFreq: number): number {
    return baseFreq * (0.92 + Math.random() * 0.16);
  }

  private tone(
    type: OscillatorType,
    startFreq: number,
    endFreq: number,
    duration: number,
    volume: number,
    delay = 0
  ): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(40, startFreq), now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(30, endFreq), now + duration);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  public playJump(isDouble = false): void {
    const base = isDouble ? 340 : 250;
    this.tone('square', this.vary(base), this.vary(base * 1.9), 0.11, 0.06);
  }

  public playLand(): void {
    this.tone('triangle', this.vary(115), 52, 0.07, 0.05);
  }

  public playDash(): void {
    this.tone('sawtooth', this.vary(480), 140, 0.12, 0.065);
  }

  public playSlash(): void {
    this.tone('sawtooth', this.vary(320), 95, 0.09, 0.07);
    this.tone('triangle', this.vary(680), 220, 0.06, 0.04);
  }

  public playHit(isWeakness = false, isCrit = false): void {
    const f = isWeakness ? 560 : 380;
    this.tone('square', this.vary(f), 90, 0.09, isCrit ? 0.1 : 0.075);
    if (isWeakness || isCrit) {
      this.tone('triangle', this.vary(920), 480, 0.11, 0.06, 0.015);
    }
  }

  public playKill(): void {
    this.tone('square', this.vary(240), 65, 0.14, 0.085);
    this.tone('triangle', this.vary(520), 820, 0.12, 0.055, 0.03);
  }

  public playHurt(): void {
    this.tone('sawtooth', 160, 48, 0.19, 0.11);
  }

  public playPickup(): void {
    this.tone('triangle', this.vary(560), 880, 0.09, 0.065);
  }

  public playTelegraph(): void {
    this.tone('sine', 440, 720, 0.16, 0.045);
  }

  public playCompanion(): void {
    this.tone('triangle', 420, 630, 0.12, 0.065);
    this.tone('triangle', 630, 945, 0.14, 0.055, 0.07);
  }

  public playPuzzleSolved(): void {
    this.tone('triangle', 523.25, 659.25, 0.12, 0.08);
    this.tone('triangle', 659.25, 783.99, 0.12, 0.08, 0.09);
    this.tone('triangle', 783.99, 1046.5, 0.22, 0.09, 0.18);
  }

  public playBossPhase(): void {
    this.tone('sawtooth', 140, 58, 0.32, 0.11);
    this.tone('square', 280, 560, 0.25, 0.07, 0.08);
  }

  public playGameOver(): void {
    this.tone('sawtooth', 260, 180, 0.2, 0.08);
    this.tone('sawtooth', 180, 120, 0.24, 0.08, 0.18);
    this.tone('sawtooth', 120, 62, 0.36, 0.09, 0.36);
  }
}

export const gameAudio = new GameAudio();
