import type {
  AbilityNodeDef,
  BossDef,
  BossId,
  CompanionDef,
  ElementAffinity,
  ElementDef,
  PlatformDef,
  PlayerProfile,
  SkinDef,
} from './types';

export const WORLD_WIDTH = 1600;
export const WORLD_HEIGHT = 900;
export const GROUND_Y = 760;

export const ARENA_PLATFORMS: PlatformDef[] = [
  // Main stone bastion floor
  { x: 0, y: GROUND_Y, w: WORLD_WIDTH, h: 140, oneWay: false, label: 'Bastion Floor' },
  // Left & Right lower catwalks
  { x: 140, y: 615, w: 300, h: 22, oneWay: true, label: 'West Catwalk' },
  { x: 1160, y: 615, w: 300, h: 22, oneWay: true, label: 'East Catwalk' },
  // Center elevated bridge
  { x: 560, y: 530, w: 480, h: 24, oneWay: true, label: 'Citadel Bridge' },
  // Upper shrine platforms
  { x: 240, y: 400, w: 260, h: 22, oneWay: true, label: 'West Spire' },
  { x: 1100, y: 400, w: 260, h: 22, oneWay: true, label: 'East Spire' },
  // High sanctum perch
  { x: 660, y: 290, w: 280, h: 22, oneWay: true, label: 'High Sanctum' },
];

export const SKINS: SkinDef[] = [
  {
    id: 'ashwalker',
    name: 'Ashwalker',
    title: 'Citadel Vanguard',
    cost: 0,
    armorPrimary: '#475569',
    armorSecondary: '#1e293b',
    capeColor: '#ea580c',
    visorGlow: '#fbbf24',
    bonusLabel: 'Balanced Citadel Plate',
    statBonus: {},
  },
  {
    id: 'cobalt_warden',
    name: 'Cobalt Warden',
    title: 'Frostguard Sentinel',
    cost: 120,
    armorPrimary: '#2563eb',
    armorSecondary: '#1e3a8a',
    capeColor: '#38bdf8',
    visorGlow: '#bae6fd',
    bonusLabel: '+20 Max HP · Steadfast Guard',
    statBonus: { maxHp: 20 },
  },
  {
    id: 'solaris_vanguard',
    name: 'Solaris Vanguard',
    title: 'Ember Knight',
    cost: 220,
    armorPrimary: '#d97706',
    armorSecondary: '#78350f',
    capeColor: '#fef08a',
    visorGlow: '#fde047',
    bonusLabel: '+15% Base Damage · +5% Crit',
    statBonus: { baseDamage: 4, critChance: 0.05 },
  },
  {
    id: 'void_stalker',
    name: 'Void Stalker',
    title: 'Rift Assassin',
    cost: 340,
    armorPrimary: '#6d28d9',
    armorSecondary: '#2e1065',
    capeColor: '#c084fc',
    visorGlow: '#e879f9',
    bonusLabel: '+45 Move Speed · Faster Dash',
    statBonus: { moveSpeed: 45, dashCooldown: -0.25 },
  },
];

export const ELEMENTS: Record<ElementAffinity, ElementDef> = {
  fire: {
    id: 'fire',
    name: 'Ember',
    weaponName: 'Cinder Cleaver',
    role: 'Ignites targets · Counters Abyssal & Frost',
    color: '#f97316',
    glow: '#fdba74',
    countersLabel: 'Strong vs Abyssal Sovereign',
  },
  frost: {
    id: 'frost',
    name: 'Cryo',
    weaponName: 'Glacier Glaive',
    role: 'Chills & slows hordes · Counters Fire',
    color: '#38bdf8',
    glow: '#bae6fd',
    countersLabel: 'Strong vs Ignis Colossus',
  },
  volt: {
    id: 'volt',
    name: 'Volt',
    weaponName: 'Storm Halberd',
    role: 'Stuns shielded chargers · Rapid arcs',
    color: '#facc15',
    glow: '#fef08a',
    countersLabel: 'Strong vs Tempest & Ironclad',
  },
  void: {
    id: 'void',
    name: 'Void',
    weaponName: 'Rift Scythe',
    role: 'Pierces armor · Counters Tempest',
    color: '#c084fc',
    glow: '#f0abfc',
    countersLabel: 'Strong vs Tempest Leviathan',
  },
};

export const ABILITY_TREE: AbilityNodeDef[] = [
  // Vanguard branch
  {
    id: 'vanguard_1',
    branch: 'vanguard',
    name: 'Tempered Edge',
    description: '+5 Base weapon damage on all strikes.',
    cost: 60,
    statDelta: { baseDamage: 5 },
  },
  {
    id: 'vanguard_2',
    branch: 'vanguard',
    name: 'Executioner Rhythm',
    description: '+18% Attack speed and +8% critical strike chance.',
    cost: 110,
    requires: 'vanguard_1',
    statDelta: { attackSpeed: 0.18, critChance: 0.08 },
  },
  {
    id: 'vanguard_3',
    branch: 'vanguard',
    name: 'Ember Rupture',
    description: '+9 Base weapon damage and +10% critical strike chance.',
    cost: 180,
    requires: 'vanguard_2',
    statDelta: { baseDamage: 9, critChance: 0.1 },
  },
  // Tempest branch
  {
    id: 'tempest_1',
    branch: 'tempest',
    name: 'Windstrider Boots',
    description: '+40 Movement speed across platforms.',
    cost: 60,
    statDelta: { moveSpeed: 40 },
  },
  {
    id: 'tempest_2',
    branch: 'tempest',
    name: 'Phantom Step',
    description: 'Reduces Dash cooldown by 0.30s.',
    cost: 110,
    requires: 'tempest_1',
    statDelta: { dashCooldown: -0.3 },
  },
  {
    id: 'tempest_3',
    branch: 'tempest',
    name: 'Skyvault Mastery',
    description: 'Grants +1 mid-air jump and +45 Jump impulse.',
    cost: 180,
    requires: 'tempest_2',
    statDelta: { extraJumps: 1, jumpForce: 45 },
  },
  // Arcana branch
  {
    id: 'arcana_1',
    branch: 'arcana',
    name: 'Bastion Vitality',
    description: '+25 Maximum HP.',
    cost: 60,
    statDelta: { maxHp: 25 },
  },
  {
    id: 'arcana_2',
    branch: 'arcana',
    name: 'Soul Siphon',
    description: 'Restore 3 HP per enemy slain and +25% Essence yield.',
    cost: 120,
    requires: 'arcana_1',
    statDelta: { lifestealOnKill: 3, essenceBonus: 0.25 },
  },
  {
    id: 'arcana_3',
    branch: 'arcana',
    name: 'Runic Resonance',
    description: '+5s Companion & Shrine Relic buff duration, +25 Max HP.',
    cost: 180,
    requires: 'arcana_2',
    statDelta: { buffDuration: 5, maxHp: 25 },
  },
];

export const COMPANIONS: CompanionDef[] = [
  {
    id: 'ember_wisp',
    name: 'Ember Wisp',
    role: 'Auto-fires homing cinder bolts at nearby enemies.',
    puzzleBonus: 'Solves Runic Shrine seals 35% faster.',
    buffDescription: 'Summon [Q]: Overdrive (+35% Attack Speed for 8s)',
    cost: 0,
    color: '#fb923c',
  },
  {
    id: 'aegis_drone',
    name: 'Aegis Sentinel',
    role: 'Orbits closely and zaps diving wisps.',
    puzzleBonus: 'Extends Shrine interaction radius by 50%.',
    buffDescription: 'Summon [Q]: Iron Skin (-45% Damage Taken + 15 HP heal)',
    cost: 140,
    color: '#38bdf8',
  },
  {
    id: 'chrono_owl',
    name: 'Chrono Familiar',
    role: 'Pulses slowing time rings around bosses & chargers.',
    puzzleBonus: 'Doubles Shrine Relic duration and +30% Essence.',
    buffDescription: 'Summon [Q]: Elemental Surge (+40% Elemental Weakness Damage)',
    cost: 240,
    color: '#c084fc',
  },
];

export const BOSSES: Record<BossId, BossDef> = {
  ignis_colossus: {
    id: 'ignis_colossus',
    name: 'Ignis Colossus',
    subtitle: 'Lord of Magma Fissures',
    weakness: 'frost',
    resistance: 'fire',
    baseHp: 560,
    primaryColor: '#ea580c',
    accentColor: '#fde047',
  },
  tempest_leviathan: {
    id: 'tempest_leviathan',
    name: 'Tempest Leviathan',
    subtitle: 'Sovereign of Gale Spires',
    weakness: 'void',
    resistance: 'volt',
    baseHp: 780,
    primaryColor: '#0284c7',
    accentColor: '#bae6fd',
  },
  abyssal_sovereign: {
    id: 'abyssal_sovereign',
    name: 'Abyssal Sovereign',
    subtitle: 'Warden of the Shattered Rift',
    weakness: 'fire',
    resistance: 'void',
    baseHp: 1020,
    primaryColor: '#7c3aed',
    accentColor: '#f0abfc',
  },
};

export const INITIAL_PROFILE: PlayerProfile = {
  callsign: 'WARDEN-01',
  essence: 180,
  bestScore: 0,
  bestWave: 0,
  unlockedSkins: ['ashwalker'],
  selectedSkin: 'ashwalker',
  unlockedNodes: [],
  weaponLevels: {
    fire: 1,
    frost: 1,
    volt: 1,
    void: 1,
  },
  activeElement: 'fire',
  unlockedCompanions: ['ember_wisp'],
  selectedCompanion: 'ember_wisp',
};

export const CURRENT_SEASON = 'Season 1: Obsidian Dawn';
