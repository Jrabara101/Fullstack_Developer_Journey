import { gameAudio } from './audio';
import {
  ARENA_PLATFORMS,
  BOSSES,
  COMPANIONS,
  ELEMENTS,
  GROUND_Y,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from './catalog';
import {
  drawBossSprite,
  drawCitadelBackdrop,
  drawCompanion,
  drawEnemySprite,
  drawPixelPlayer,
  drawPlatforms,
  drawShrinePuzzle,
  ParticlePool,
} from './pixelSprites';
import {
  calculateElementalMultiplier,
  calculateRunScore,
  checkAABB,
  clamp,
  computePlayerStats,
  getBossPhase,
  getWaveConfig,
  getWeaponDamageMultiplier,
  resolveOneWayLanding,
  selectBossBulletPattern,
} from './rules';
import type {
  ActiveBuffType,
  BossId,
  BossPhase,
  ElementAffinity,
  EnemyArchetype,
  HudSnapshot,
  PlayerComputedStats,
  PlayerProfile,
  RemoteRaiderState,
  RunSummary,
} from './types';

interface EnemyEntity {
  id: number;
  archetype: EnemyArchetype;
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  maxHp: number;
  isGrounded: boolean;
  hitFlash: number;
  chillTimer: number;
  stunTimer: number;
  windupTimer: number;
  windupMax: number;
  attackCooldown: number;
  hasToken: boolean;
  koTimer: number;
  aiPhase: number;
}

interface BossEntity {
  id: BossId;
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  maxHp: number;
  phase: BossPhase;
  hitFlash: number;
  telegraphTimer: number;
  patternCooldown: number;
  patternCycle: number;
  spiralAngle: number;
}

interface Projectile {
  active: boolean;
  fromPlayer: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  color: string;
  element?: ElementAffinity;
  life: number;
}

interface PickupEntity {
  id: number;
  kind: 'heart' | 'essence' | 'fury';
  x: number;
  y: number;
  vy: number;
  value: number;
  life: number;
}

interface FloatingText {
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
}

interface ShrinePuzzle {
  active: boolean;
  x: number;
  y: number;
  requiredElement: ElementAffinity;
  progress: number;
  solved: boolean;
}

export interface EngineCallbacks {
  onHudUpdate: (hud: HudSnapshot) => void;
  onGameOver: (summary: RunSummary) => void;
  onElementSwitch: (elem: ElementAffinity) => void;
  onPauseToggle: () => void;
  onQuickRestart: () => void;
  onBroadcastPlayerState?: (state: Omit<RemoteRaiderState, 'clientId' | 'updatedAt'>) => void;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private callbacks: EngineCallbacks;
  private profile: PlayerProfile;
  private stats: PlayerComputedStats;

  private rafId: number | null = null;
  private lastTs = 0;
  private running = false;
  private paused = false;
  private isRaidMode = false;
  private raidRoomId: string | null = null;
  private remotePlayers: Map<string, RemoteRaiderState> = new Map();

  // Camera & Juice
  private camX = 0;
  private trauma = 0;
  private hitstopTimer = 0;
  private time = 0;
  private runTime = 0;
  private particles = new ParticlePool(340);
  private ambientEmbers: Array<{ x: number; y: number; vx: number; vy: number; s: number }> = [];

  // Input hub
  private heldKeys = new Set<string>();
  private justPressed = new Set<string>();
  private mouseDown = false;
  private mouseJustPressed = false;
  private jumpBufferTimer = 0;
  private attackBufferTimer = 0;

  // Player state
  private player = {
    x: 780,
    y: GROUND_Y - 52,
    w: 28,
    h: 50,
    vx: 0,
    vy: 0,
    facing: 1 as 1 | -1,
    hp: 100,
    ghostHp: 100,
    isGrounded: true,
    coyoteTimer: 0,
    jumpsLeft: 1,
    dropTimer: 0,
    dashTimer: 0,
    dashCooldownTimer: 0,
    invulnTimer: 0,
    attackTimer: 0,
    attackDuration: 0.24,
    attackCooldownTimer: 0,
    hasHitThisSwing: new Set<number>(),
    walkCycle: 0,
    squashX: 1,
    squashY: 1,
  };

  // Companion & Buffs
  private companion = {
    x: 740,
    y: GROUND_Y - 84,
    fireTimer: 0,
    cooldownTimer: 0,
    cooldownMax: 12,
  };

  private activeBuff: {
    type: ActiveBuffType;
    label: string;
    remaining: number;
    duration: number;
  } | null = null;

  // Wave & Combat state
  private wave = 1;
  private enemiesToSpawn = 0;
  private spawnTimer = 0;
  private waveClearDelay = 0;
  private nextEntityId = 1;
  private enemies: EnemyEntity[] = [];
  private boss: BossEntity | null = null;
  private projectiles: Projectile[] = Array.from({ length: 180 }, () => ({
    active: false,
    fromPlayer: false,
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    radius: 5,
    damage: 10,
    color: '#ef4444',
    life: 0,
  }));
  private pickups: PickupEntity[] = [];
  private floatingTexts: FloatingText[] = [];
  private shrine: ShrinePuzzle = {
    active: false,
    x: 800,
    y: 290,
    requiredElement: 'fire',
    progress: 0,
    solved: false,
  };

  // Run counters
  private kills = 0;
  private bossesDefeated = 0;
  private puzzlesSolved = 0;
  private combo = 0;
  private maxCombo = 0;
  private comboTimer = 0;
  private essenceEarned = 0;
  private defeatDelayTimer = -1;

  private hudEmitTimer = 0;
  private netBroadcastTimer = 0;

  // Bound handlers
  private handleKeyDownBound: (e: KeyboardEvent) => void;
  private handleKeyUpBound: (e: KeyboardEvent) => void;
  private handleBlurBound: () => void;
  private handleMouseDownBound: (e: MouseEvent) => void;
  private handleMouseUpBound: () => void;

  constructor(
    canvas: HTMLCanvasElement,
    profile: PlayerProfile,
    callbacks: EngineCallbacks
  ) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Canvas 2D context unavailable');
    }
    this.ctx = context;
    this.ctx.imageSmoothingEnabled = false;
    this.profile = profile;
    this.stats = computePlayerStats(profile);
    this.callbacks = callbacks;

    for (let i = 0; i < 42; i++) {
      this.ambientEmbers.push({
        x: Math.random() * WORLD_WIDTH,
        y: Math.random() * WORLD_HEIGHT,
        vx: -18 - Math.random() * 25,
        vy: -20 - Math.random() * 35,
        s: 2 + Math.floor(Math.random() * 3),
      });
    }

    this.handleKeyDownBound = this.onKeyDown.bind(this);
    this.handleKeyUpBound = this.onKeyUp.bind(this);
    this.handleBlurBound = this.clearInputs.bind(this);
    this.handleMouseDownBound = this.onMouseDown.bind(this);
    this.handleMouseUpBound = () => {
      this.mouseDown = false;
    };

    window.addEventListener('keydown', this.handleKeyDownBound);
    window.addEventListener('keyup', this.handleKeyUpBound);
    window.addEventListener('blur', this.handleBlurBound);
    document.addEventListener('visibilitychange', this.handleBlurBound);
    this.canvas.addEventListener('mousedown', this.handleMouseDownBound);
    window.addEventListener('mouseup', this.handleMouseUpBound);
  }

  public destroy(): void {
    this.stop();
    window.removeEventListener('keydown', this.handleKeyDownBound);
    window.removeEventListener('keyup', this.handleKeyUpBound);
    window.removeEventListener('blur', this.handleBlurBound);
    document.removeEventListener('visibilitychange', this.handleBlurBound);
    this.canvas.removeEventListener('mousedown', this.handleMouseDownBound);
    window.removeEventListener('mouseup', this.handleMouseUpBound);
  }

  public updateProfile(profile: PlayerProfile): void {
    const prevMaxHp = this.stats.maxHp;
    this.profile = profile;
    this.stats = computePlayerStats(profile);
    if (this.stats.maxHp > prevMaxHp) {
      this.player.hp += this.stats.maxHp - prevMaxHp;
    }
    this.player.hp = Math.min(this.player.hp, this.stats.maxHp);
    this.emitHud();
  }

  public setRaidContext(roomId: string | null, remotePlayers: RemoteRaiderState[]): void {
    this.raidRoomId = roomId;
    this.isRaidMode = Boolean(roomId);
    this.remotePlayers.clear();
    for (const rp of remotePlayers) {
      this.remotePlayers.set(rp.clientId, rp);
    }
  }

  public startNewRun(raidRoomId: string | null = null): void {
    this.raidRoomId = raidRoomId;
    this.isRaidMode = Boolean(raidRoomId);
    this.stats = computePlayerStats(this.profile);
    this.clearInputs();

    this.paused = false;
    this.running = true;
    this.runTime = 0;
    this.hitstopTimer = 0;
    this.trauma = 0;
    this.defeatDelayTimer = -1;

    this.player.x = 780;
    this.player.y = GROUND_Y - this.player.h;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.facing = 1;
    this.player.hp = this.stats.maxHp;
    this.player.ghostHp = this.stats.maxHp;
    this.player.isGrounded = true;
    this.player.coyoteTimer = 0.11;
    this.player.jumpsLeft = this.stats.extraJumps;
    this.player.dashTimer = 0;
    this.player.dashCooldownTimer = 0;
    this.player.invulnTimer = 0.6;
    this.player.attackTimer = 0;
    this.player.attackCooldownTimer = 0;
    this.player.squashX = 1;
    this.player.squashY = 1;

    this.companion.x = this.player.x - 36;
    this.companion.y = this.player.y - 24;
    this.companion.cooldownTimer = 0;
    this.companion.fireTimer = 0.5;
    this.activeBuff = null;

    this.enemies = [];
    this.boss = null;
    this.pickups = [];
    this.floatingTexts = [];
    this.particles.clear();
    for (const p of this.projectiles) p.active = false;

    this.kills = 0;
    this.bossesDefeated = 0;
    this.puzzlesSolved = 0;
    this.combo = 0;
    this.maxCombo = 0;
    this.comboTimer = 0;
    this.essenceEarned = 0;

    this.beginWave(1);
    this.emitHud();

    if (this.rafId === null) {
      this.lastTs = performance.now();
      this.rafId = requestAnimationFrame(this.loop);
    }
  }

  public setPaused(paused: boolean): void {
    this.paused = paused;
    this.clearInputs();
    if (paused) {
      this.render();
      if (this.rafId !== null) {
        cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
    } else if (this.running && this.rafId === null) {
      this.lastTs = performance.now();
      this.rafId = requestAnimationFrame(this.loop);
    }
  }

  public stop(): void {
    this.running = false;
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  public applyRemoteBossHit(damage: number): void {
    if (!this.boss) return;
    this.boss.hp = Math.max(0, this.boss.hp - damage);
    this.boss.hitFlash = 0.06;
  }

  private clearInputs(): void {
    this.heldKeys.clear();
    this.justPressed.clear();
    this.mouseDown = false;
    this.mouseJustPressed = false;
  }

  private onKeyDown(e: KeyboardEvent): void {
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    const code = e.code;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(code)) {
      e.preventDefault();
    }

    if (code === 'Escape' || code === 'KeyP') {
      if (this.running && this.defeatDelayTimer < 0) {
        this.callbacks.onPauseToggle();
      }
      return;
    }

    if (code === 'KeyR' && this.running && !this.paused && this.defeatDelayTimer < 0) {
      this.callbacks.onQuickRestart();
      return;
    }

    if (!this.heldKeys.has(code)) {
      this.justPressed.add(code);
    }
    this.heldKeys.add(code);

    if (this.running && !this.paused) {
      if (code === 'Digit1') this.callbacks.onElementSwitch('fire');
      if (code === 'Digit2') this.callbacks.onElementSwitch('frost');
      if (code === 'Digit3') this.callbacks.onElementSwitch('volt');
      if (code === 'Digit4') this.callbacks.onElementSwitch('void');
    }
  }

  private onKeyUp(e: KeyboardEvent): void {
    const code = e.code;
    this.heldKeys.delete(code);

    // Variable jump height cut
    if (
      (code === 'Space' || code === 'KeyW' || code === 'ArrowUp') &&
      this.player.vy < -120 &&
      this.player.dashTimer <= 0
    ) {
      this.player.vy *= 0.45;
    }
  }

  private onMouseDown(e: MouseEvent): void {
    if (e.button === 0) {
      this.mouseDown = true;
      this.mouseJustPressed = true;
    }
  }

  private loop = (ts: number): void => {
    if (!this.running) {
      this.rafId = null;
      return;
    }

    const rawDt = Math.max(0, (ts - this.lastTs) / 1000);
    this.lastTs = ts;
    const dt = Math.min(rawDt, 0.05);

    if (!this.paused) {
      this.tick(dt);
    }
    this.render();

    this.justPressed.clear();
    this.mouseJustPressed = false;
    this.rafId = requestAnimationFrame(this.loop);
  };

  private beginWave(waveNum: number): void {
    this.wave = waveNum;
    const cfg = getWaveConfig(waveNum, this.isRaidMode);
    this.enemiesToSpawn = cfg.enemyBudget;
    this.spawnTimer = 0.8;
    this.waveClearDelay = 0;

    if (cfg.isBossWave && cfg.bossId) {
      const def = BOSSES[cfg.bossId];
      const raidMul = this.isRaidMode ? 1.45 : 1;
      const scale = 1 + Math.floor(waveNum / 3 - 1) * 0.35;
      const maxHp = Math.round(def.baseHp * scale * raidMul);
      this.boss = {
        id: cfg.bossId,
        x: 740,
        y: 160,
        w: 84,
        h: 96,
        vx: 110,
        vy: 0,
        facing: -1,
        hp: maxHp,
        maxHp,
        phase: 1,
        hitFlash: 0,
        telegraphTimer: 0.7,
        patternCooldown: 2.2,
        patternCycle: 0,
        spiralAngle: 0,
      };
      this.addFloatingText(800, 220, `${def.name.toUpperCase()} AWAKENS!`, def.accentColor);
      gameAudio.playBossPhase();
    }

    if (cfg.hasShrinePuzzle) {
      const spots = [
        { x: 370, y: 400 },
        { x: 1230, y: 400 },
        { x: 800, y: 290 },
      ];
      const spot = spots[waveNum % spots.length];
      const elems: ElementAffinity[] = ['fire', 'frost', 'volt', 'void'];
      this.shrine = {
        active: true,
        x: spot.x,
        y: spot.y,
        requiredElement: elems[waveNum % elems.length],
        progress: 0,
        solved: false,
      };
    } else {
      this.shrine.active = false;
    }
  }

  private tick(dt: number): void {
    this.time += dt;

    // Update camera trauma & particles even during hitstop
    this.trauma = Math.max(0, this.trauma - dt * 1.9);
    this.particles.update(dt);
    for (const ember of this.ambientEmbers) {
      ember.x += ember.vx * dt;
      ember.y += ember.vy * dt;
      if (ember.x < 0) ember.x += WORLD_WIDTH;
      if (ember.y < 0) ember.y += WORLD_HEIGHT;
    }

    // Delayed drain bar
    if (this.player.ghostHp > this.player.hp) {
      this.player.ghostHp = Math.max(this.player.hp, this.player.ghostHp - dt * 38);
    } else {
      this.player.ghostHp = this.player.hp;
    }

    if (this.defeatDelayTimer >= 0) {
      this.defeatDelayTimer -= dt;
      if (this.defeatDelayTimer <= 0) {
        this.finishRun();
      }
      return;
    }

    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    this.runTime += dt;
    this.updateFloatingTexts(dt);
    this.updatePlayer(dt);
    this.updateCompanion(dt);
    this.updateShrine(dt);
    this.updateSpawning(dt);
    this.updateEnemies(dt);
    this.updateBoss(dt);
    this.updateProjectiles(dt);
    this.updatePickups(dt);

    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) this.combo = 0;
    }

    if (this.activeBuff) {
      this.activeBuff.remaining -= dt;
      if (this.activeBuff.remaining <= 0) {
        this.activeBuff = null;
      }
    }

    this.hudEmitTimer += dt;
    if (this.hudEmitTimer >= 0.1) {
      this.hudEmitTimer = 0;
      this.emitHud();
    }

    if (this.isRaidMode && this.callbacks.onBroadcastPlayerState) {
      this.netBroadcastTimer += dt;
      if (this.netBroadcastTimer >= 0.05) {
        this.netBroadcastTimer = 0;
        this.callbacks.onBroadcastPlayerState({
          callsign: this.profile.callsign,
          skin: this.profile.selectedSkin,
          element: this.profile.activeElement,
          x: Math.round(this.player.x),
          y: Math.round(this.player.y),
          vx: Math.round(this.player.vx),
          vy: Math.round(this.player.vy),
          facing: this.player.facing,
          hp: Math.round(this.player.hp),
          maxHp: Math.round(this.stats.maxHp),
          attacking: this.player.attackTimer > 0,
          dashing: this.player.dashTimer > 0,
        });
      }
    }
  }

  private updatePlayer(dt: number): void {
    const p = this.player;
    p.squashX += (1 - p.squashX) * Math.min(1, dt * 14);
    p.squashY += (1 - p.squashY) * Math.min(1, dt * 14);
    p.invulnTimer = Math.max(0, p.invulnTimer - dt);
    p.dashCooldownTimer = Math.max(0, p.dashCooldownTimer - dt);
    p.attackCooldownTimer = Math.max(0, p.attackCooldownTimer - dt);
    p.dropTimer = Math.max(0, p.dropTimer - dt);

    // Input buffering
    const jumpJust =
      this.justPressed.has('Space') ||
      this.justPressed.has('KeyW') ||
      this.justPressed.has('ArrowUp');
    if (jumpJust) this.jumpBufferTimer = 0.12;
    else this.jumpBufferTimer = Math.max(0, this.jumpBufferTimer - dt);

    const attackJust =
      this.justPressed.has('KeyJ') ||
      this.justPressed.has('KeyZ') ||
      this.mouseJustPressed;
    if (attackJust) this.attackBufferTimer = 0.12;
    else this.attackBufferTimer = Math.max(0, this.attackBufferTimer - dt);

    const moveLeft = this.heldKeys.has('KeyA') || this.heldKeys.has('ArrowLeft');
    const moveRight = this.heldKeys.has('KeyD') || this.heldKeys.has('ArrowRight');
    const moveDir = (moveRight ? 1 : 0) - (moveLeft ? 1 : 0);

    if (moveDir !== 0 && p.dashTimer <= 0) {
      p.facing = moveDir as 1 | -1;
    }

    if (this.heldKeys.has('KeyS') || this.heldKeys.has('ArrowDown')) {
      p.dropTimer = 0.18;
    }

    // Dash action
    const dashJust =
      this.justPressed.has('KeyK') ||
      this.justPressed.has('ShiftLeft') ||
      this.justPressed.has('ShiftRight');
    if (dashJust && p.dashCooldownTimer <= 0 && p.dashTimer <= 0) {
      p.dashTimer = 0.16;
      p.dashCooldownTimer = this.stats.dashCooldown;
      p.invulnTimer = Math.max(p.invulnTimer, 0.2);
      p.vx = p.facing * 860;
      p.vy = 0;
      p.squashX = 1.28;
      p.squashY = 0.75;
      gameAudio.playDash();
      this.particles.burst(p.x + p.w / 2, p.y + p.h / 2, 8, ELEMENTS[this.profile.activeElement].glow, 60, 160, 4, 0.25, 0);
    }

    if (p.dashTimer > 0) {
      p.dashTimer -= dt;
    } else {
      const targetVx = moveDir * this.stats.moveSpeed;
      const accel = p.isGrounded ? 2600 : 1700;
      if (p.vx < targetVx) p.vx = Math.min(targetVx, p.vx + accel * dt);
      else if (p.vx > targetVx) p.vx = Math.max(targetVx, p.vx - accel * dt);

      // Gravity
      p.vy = Math.min(1100, p.vy + 1680 * dt);
    }

    // Coyote time & Jump execution
    if (p.isGrounded) {
      p.coyoteTimer = 0.11;
      p.jumpsLeft = this.stats.extraJumps;
    } else {
      p.coyoteTimer = Math.max(0, p.coyoteTimer - dt);
    }

    if (this.jumpBufferTimer > 0) {
      if (p.coyoteTimer > 0) {
        p.vy = -this.stats.jumpForce;
        p.isGrounded = false;
        p.coyoteTimer = 0;
        this.jumpBufferTimer = 0;
        p.squashX = 0.82;
        p.squashY = 1.22;
        gameAudio.playJump(false);
        this.particles.burst(p.x + p.w / 2, p.y + p.h, 5, '#94a3b8', 40, 110, 3, 0.28, 220);
      } else if (p.jumpsLeft > 0) {
        p.jumpsLeft -= 1;
        p.vy = -this.stats.jumpForce * 0.92;
        this.jumpBufferTimer = 0;
        p.squashX = 0.84;
        p.squashY = 1.18;
        gameAudio.playJump(true);
        this.particles.burst(p.x + p.w / 2, p.y + p.h, 6, ELEMENTS[this.profile.activeElement].color, 50, 130, 3, 0.28, 120);
      }
    }

    // Integrate & collide with platforms
    const prevBottom = p.y + p.h;
    p.x = clamp(p.x + p.vx * dt, 24, WORLD_WIDTH - p.w - 24);
    p.y += p.vy * dt;
    const nextBottom = p.y + p.h;

    const wasGrounded = p.isGrounded;
    p.isGrounded = false;

    for (const plat of ARENA_PLATFORMS) {
      if (!plat.oneWay) {
        if (nextBottom >= plat.y && p.vy >= 0) {
          p.y = plat.y - p.h;
          p.vy = 0;
          p.isGrounded = true;
        }
      } else if (
        resolveOneWayLanding(
          prevBottom,
          nextBottom,
          p.vy,
          p.x,
          p.x + p.w,
          plat,
          p.dropTimer > 0
        )
      ) {
        p.y = plat.y - p.h;
        p.vy = 0;
        p.isGrounded = true;
      }
    }

    if (!wasGrounded && p.isGrounded) {
      p.squashX = 1.22;
      p.squashY = 0.78;
      gameAudio.playLand();
      this.particles.burst(p.x + p.w / 2, p.y + p.h, 4, '#64748b', 35, 90, 3, 0.22, 300);
    }

    if (p.isGrounded && Math.abs(p.vx) > 20) {
      p.walkCycle += Math.abs(p.vx) * dt * 0.32;
    }

    // Attack action (Melee arc + Elemental Blade Wave)
    const atkSpeedMul =
      this.stats.attackSpeed * (this.activeBuff?.type === 'overdrive' ? 1.35 : 1);
    if (this.attackBufferTimer > 0 && p.attackCooldownTimer <= 0) {
      this.attackBufferTimer = 0;
      p.attackDuration = 0.22 / atkSpeedMul;
      p.attackTimer = p.attackDuration;
      p.attackCooldownTimer = 0.3 / atkSpeedMul;
      p.hasHitThisSwing.clear();
      p.squashX = 1.15;
      p.squashY = 0.9;
      gameAudio.playSlash();

      // Fire short-range elemental wave projectile
      const elem = this.profile.activeElement;
      const lvl = this.profile.weaponLevels[elem] ?? 1;
      const waveDmg =
        this.stats.baseDamage * 0.68 * getWeaponDamageMultiplier(lvl);
      this.spawnProjectile({
        fromPlayer: true,
        x: p.x + p.w / 2 + p.facing * 20,
        y: p.y + p.h * 0.45,
        vx: p.facing * 640,
        vy: 0,
        radius: 8,
        damage: waveDmg,
        color: ELEMENTS[elem].glow,
        element: elem,
        life: 0.48,
      });
    }

    if (p.attackTimer > 0) {
      p.attackTimer = Math.max(0, p.attackTimer - dt);
      this.checkPlayerMeleeHits();
    }

    // Companion summon [Q]
    if (this.justPressed.has('KeyQ') && this.companion.cooldownTimer <= 0) {
      this.triggerCompanionSkill();
    }
  }

  private checkPlayerMeleeHits(): void {
    const p = this.player;
    const slashBox = {
      x: p.facing === 1 ? p.x + p.w * 0.5 : p.x - 62,
      y: p.y - 8,
      w: 74,
      h: p.h + 16,
    };

    const elem = this.profile.activeElement;
    const lvl = this.profile.weaponLevels[elem] ?? 1;
    let dmg = this.stats.baseDamage * getWeaponDamageMultiplier(lvl);

    for (const enemy of this.enemies) {
      if (enemy.koTimer > 0 || p.hasHitThisSwing.has(enemy.id)) continue;
      if (checkAABB(slashBox, enemy)) {
        p.hasHitThisSwing.add(enemy.id);

        // Shielded charger front block check
        const hitFromFront =
          enemy.archetype === 'charger' &&
          enemy.stunTimer <= 0 &&
          p.facing !== enemy.facing;
        if (hitFromFront && elem !== 'volt' && elem !== 'void') {
          this.addFloatingText(enemy.x + enemy.w / 2, enemy.y - 10, 'BLOCKED!', '#94a3b8');
          enemy.vx = p.facing * 90;
          gameAudio.playLand();
          continue;
        }

        if (elem === 'volt' && enemy.archetype === 'charger') {
          enemy.stunTimer = 1.2;
        }
        this.damageEnemy(enemy, dmg, elem, p.facing);
      }
    }

    if (this.boss && !p.hasHitThisSwing.has(-999)) {
      if (checkAABB(slashBox, this.boss)) {
        p.hasHitThisSwing.add(-999);
        this.damageBoss(dmg, elem);
      }
    }
  }

  private damageEnemy(
    enemy: EnemyEntity,
    rawDmg: number,
    elem: ElementAffinity,
    knockDir: 1 | -1
  ): void {
    const isCrit = Math.random() < this.stats.critChance;
    let dmg = rawDmg * (isCrit ? 1.65 : 1);
    if (elem === 'frost') enemy.chillTimer = 2.4;

    enemy.hp -= dmg;
    enemy.hitFlash = 0.06;
    enemy.vx = knockDir * (enemy.archetype === 'charger' ? 110 : 210);
    enemy.vy = Math.min(enemy.vy, -120);

    this.particles.burst(
      enemy.x + enemy.w / 2,
      enemy.y + enemy.h / 2,
      isCrit ? 14 : 8,
      ELEMENTS[elem].glow,
      70,
      230,
      4,
      0.35,
      360
    );

    this.addFloatingText(
      enemy.x + enemy.w / 2,
      enemy.y - 8,
      `${Math.round(dmg)}${isCrit ? '!' : ''}`,
      isCrit ? '#fde047' : '#f8fafc'
    );

    if (enemy.hp <= 0) {
      enemy.koTimer = 0.01;
      enemy.hasToken = false;
      this.kills += 1;
      this.combo += 1;
      this.maxCombo = Math.max(this.maxCombo, this.combo);
      this.comboTimer = 3.2;

      const essenceDrop = Math.round(8 * this.stats.essenceBonus);
      this.essenceEarned += essenceDrop;
      if (this.stats.lifestealOnKill > 0) {
        this.player.hp = Math.min(this.stats.maxHp, this.player.hp + this.stats.lifestealOnKill);
      }

      this.hitstopTimer = Math.max(this.hitstopTimer, 0.038);
      this.trauma = Math.min(1, this.trauma + 0.22);
      gameAudio.playKill();
      this.particles.burst(
        enemy.x + enemy.w / 2,
        enemy.y + enemy.h / 2,
        18,
        ELEMENTS[elem].color,
        90,
        280,
        5,
        0.48,
        420
      );

      // Drop loot chance
      const r = Math.random();
      if (r < 0.22) {
        this.pickups.push({
          id: this.nextEntityId++,
          kind: 'heart',
          x: enemy.x + enemy.w / 2,
          y: enemy.y,
          vy: -220,
          value: 16,
          life: 10,
        });
      } else if (r < 0.58) {
        this.pickups.push({
          id: this.nextEntityId++,
          kind: 'essence',
          x: enemy.x + enemy.w / 2,
          y: enemy.y,
          vy: -220,
          value: 10,
          life: 10,
        });
      }
    } else {
      this.hitstopTimer = Math.max(this.hitstopTimer, 0.025);
      this.trauma = Math.min(1, this.trauma + 0.12);
      gameAudio.playHit(false, isCrit);
    }
  }

  private damageBoss(rawDmg: number, elem: ElementAffinity): void {
    const boss = this.boss;
    if (!boss) return;
    const def = BOSSES[boss.id];
    const mult = calculateElementalMultiplier(elem, def.weakness, def.resistance);
    const surgeBonus =
      this.activeBuff?.type === 'elemental_surge' && mult > 1 ? 1.4 : 1;
    const isCrit = Math.random() < this.stats.critChance;
    const dmg = rawDmg * mult * surgeBonus * (isCrit ? 1.55 : 1);

    const prevPhase = boss.phase;
    boss.hp = Math.max(0, boss.hp - dmg);
    boss.hitFlash = 0.06;
    boss.phase = getBossPhase(boss.hp, boss.maxHp);

    const isWeakness = mult > 1.2;
    this.hitstopTimer = Math.max(this.hitstopTimer, isWeakness ? 0.05 : 0.03);
    this.trauma = Math.min(1, this.trauma + (isWeakness ? 0.28 : 0.14));
    gameAudio.playHit(isWeakness, isCrit);

    this.particles.burst(
      boss.x + boss.w / 2,
      boss.y + boss.h / 2,
      isWeakness ? 16 : 9,
      isWeakness ? '#fde047' : ELEMENTS[elem].color,
      80,
      260,
      5,
      0.4,
      300
    );

    const label = isWeakness
      ? `${Math.round(dmg)} WEAK!`
      : mult < 1
      ? `${Math.round(dmg)} RESIST`
      : `${Math.round(dmg)}`;
    this.addFloatingText(
      boss.x + boss.w / 2 + (Math.random() - 0.5) * 30,
      boss.y - 12,
      label,
      isWeakness ? '#fde047' : mult < 1 ? '#94a3b8' : '#f8fafc'
    );

    if (boss.phase > prevPhase && boss.hp > 0) {
      this.hitstopTimer = 0.075;
      this.trauma = 0.75;
      gameAudio.playBossPhase();
      this.addFloatingText(
        boss.x + boss.w / 2,
        boss.y - 34,
        `PHASE ${boss.phase}!`,
        '#ef4444'
      );
      this.particles.burst(boss.x + boss.w / 2, boss.y + boss.h / 2, 28, def.accentColor, 120, 380, 6, 0.65, 160);
    }

    if (boss.hp <= 0) {
      this.bossesDefeated += 1;
      this.essenceEarned += Math.round(95 * this.stats.essenceBonus);
      this.hitstopTimer = 0.08;
      this.trauma = 0.85;
      gameAudio.playPuzzleSolved();
      this.particles.burst(boss.x + boss.w / 2, boss.y + boss.h / 2, 36, def.accentColor, 140, 420, 6, 0.75, 240);
      this.addFloatingText(boss.x + boss.w / 2, boss.y, 'BOSS VANQUISHED!', '#fde047');
      this.boss = null;
      this.waveClearDelay = 1.6;
    }
  }

  private triggerCompanionSkill(): void {
    const comp = COMPANIONS.find((c) => c.id === this.profile.selectedCompanion) ?? COMPANIONS[0];
    this.companion.cooldownTimer = this.companion.cooldownMax;
    gameAudio.playCompanion();

    let buffType: ActiveBuffType = 'overdrive';
    let label = 'Overdrive (+35% Atk Spd)';
    if (comp.id === 'aegis_drone') {
      buffType = 'iron_skin';
      label = 'Iron Skin (-45% Dmg)';
      this.player.hp = Math.min(this.stats.maxHp, this.player.hp + 15);
    } else if (comp.id === 'chrono_owl') {
      buffType = 'elemental_surge';
      label = 'Elemental Surge (+40% Weak Dmg)';
      for (const e of this.enemies) e.chillTimer = Math.max(e.chillTimer, 4.0);
    }

    const dur = this.stats.buffDuration;
    this.activeBuff = {
      type: buffType,
      label,
      remaining: dur,
      duration: dur,
    };

    this.particles.burst(this.companion.x, this.companion.y, 14, comp.color, 70, 200, 4, 0.45, 0);
    this.addFloatingText(this.player.x + 14, this.player.y - 26, `${comp.name.toUpperCase()}!`, comp.color);
  }

  private updateCompanion(dt: number): void {
    this.companion.cooldownTimer = Math.max(0, this.companion.cooldownTimer - dt);

    const targetX =
      this.shrine.active &&
      !this.shrine.solved &&
      Math.hypot(this.player.x - this.shrine.x, this.player.y - this.shrine.y) < 220
        ? this.shrine.x
        : this.player.x + (this.player.facing === 1 ? -34 : 52);
    const targetY =
      this.shrine.active &&
      !this.shrine.solved &&
      Math.hypot(this.player.x - this.shrine.x, this.player.y - this.shrine.y) < 220
        ? this.shrine.y - 54
        : this.player.y - 26;

    this.companion.x += (targetX - this.companion.x) * Math.min(1, dt * 6.5);
    this.companion.y += (targetY - this.companion.y) * Math.min(1, dt * 6.5);

    this.companion.fireTimer -= dt;
    if (this.companion.fireTimer <= 0) {
      this.companion.fireTimer = this.profile.selectedCompanion === 'ember_wisp' ? 1.15 : 1.5;
      // Target nearest enemy or boss
      let bestX: number | null = null;
      let bestY: number | null = null;
      let bestDist = 420;
      for (const e of this.enemies) {
        if (e.koTimer > 0) continue;
        const d = Math.hypot(e.x - this.companion.x, e.y - this.companion.y);
        if (d < bestDist) {
          bestDist = d;
          bestX = e.x + e.w / 2;
          bestY = e.y + e.h / 2;
        }
      }
      if (bestX === null && this.boss) {
        bestX = this.boss.x + this.boss.w / 2;
        bestY = this.boss.y + this.boss.h / 2;
      }
      if (bestX !== null && bestY !== null) {
        const ang = Math.atan2(bestY - this.companion.y, bestX - this.companion.x);
        const elem = this.profile.activeElement;
        this.spawnProjectile({
          fromPlayer: true,
          x: this.companion.x,
          y: this.companion.y,
          vx: Math.cos(ang) * 520,
          vy: Math.sin(ang) * 520,
          radius: 5,
          damage: this.stats.baseDamage * 0.45,
          color: ELEMENTS[elem].color,
          element: elem,
          life: 0.9,
        });
      }
    }
  }

  private updateShrine(dt: number): void {
    if (!this.shrine.active || this.shrine.solved) return;
    const radius = this.profile.selectedCompanion === 'aegis_drone' ? 165 : 115;
    const dist = Math.hypot(
      this.player.x + this.player.w / 2 - this.shrine.x,
      this.player.y + this.player.h - this.shrine.y
    );
    if (dist <= radius) {
      const elemMatch = this.profile.activeElement === this.shrine.requiredElement ? 1.85 : 1;
      const compSpeed = this.profile.selectedCompanion === 'ember_wisp' ? 1.35 : 1;
      this.shrine.progress = Math.min(1, this.shrine.progress + dt * 0.42 * elemMatch * compSpeed);
      if (this.shrine.progress >= 1) {
        this.shrine.solved = true;
        this.puzzlesSolved += 1;
        this.essenceEarned += Math.round(40 * this.stats.essenceBonus);
        this.player.hp = Math.min(this.stats.maxHp, this.player.hp + 25);
        const dur =
          this.stats.buffDuration *
          (this.profile.selectedCompanion === 'chrono_owl' ? 1.6 : 1);
        this.activeBuff = {
          type: 'elemental_surge',
          label: 'Relic Awakening (+40% Weak Dmg)',
          remaining: dur,
          duration: dur,
        };
        gameAudio.playPuzzleSolved();
        this.particles.burst(this.shrine.x, this.shrine.y - 48, 22, '#10b981', 80, 260, 5, 0.55, 180);
        this.addFloatingText(this.shrine.x, this.shrine.y - 95, 'RELIC UNLOCKED!', '#34d399');
      }
    }
  }

  private updateSpawning(dt: number): void {
    const cfg = getWaveConfig(this.wave, this.isRaidMode);
    if (this.enemiesToSpawn > 0) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnTimer = cfg.spawnInterval;
        this.enemiesToSpawn -= 1;
        const arch = cfg.archetypes[Math.floor(Math.random() * cfg.archetypes.length)];
        this.spawnEnemy(arch, cfg.hpScale);
      }
    } else if (this.enemies.length === 0 && !this.boss) {
      this.waveClearDelay += dt;
      if (this.waveClearDelay >= 1.4) {
        this.beginWave(this.wave + 1);
      }
    }
  }

  private spawnEnemy(archetype: EnemyArchetype, hpScale: number): void {
    const fromLeft = Math.random() < 0.5;
    const x = fromLeft ? 46 : WORLD_WIDTH - 90;
    const y = archetype === 'wisp' ? 210 + Math.random() * 140 : GROUND_Y - 56;
    const dims: Record<EnemyArchetype, { w: number; h: number; hp: number }> = {
      stalker: { w: 30, h: 32, hp: 44 },
      archer: { w: 26, h: 46, hp: 38 },
      charger: { w: 42, h: 48, hp: 82 },
      wisp: { w: 28, h: 28, hp: 34 },
    };
    const d = dims[archetype];
    const maxHp = Math.round(d.hp * hpScale);

    this.enemies.push({
      id: this.nextEntityId++,
      archetype,
      x,
      y,
      w: d.w,
      h: d.h,
      vx: 0,
      vy: 0,
      facing: fromLeft ? 1 : -1,
      hp: maxHp,
      maxHp,
      isGrounded: archetype !== 'wisp',
      hitFlash: 0,
      chillTimer: 0,
      stunTimer: 0,
      windupTimer: 0,
      windupMax: 0.45,
      attackCooldown: 1.0 + Math.random() * 0.8,
      hasToken: false,
      koTimer: 0,
      aiPhase: Math.random() * 6,
    });
  }

  private updateEnemies(dt: number): void {
    const cfg = getWaveConfig(this.wave, this.isRaidMode);
    let activeTokens = this.enemies.filter((e) => e.hasToken && e.koTimer <= 0).length;
    const px = this.player.x + this.player.w / 2;
    const py = this.player.y + this.player.h / 2;

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.hitFlash = Math.max(0, e.hitFlash - dt);
      e.chillTimer = Math.max(0, e.chillTimer - dt);
      e.stunTimer = Math.max(0, e.stunTimer - dt);

      if (e.koTimer > 0) {
        e.koTimer += dt;
        e.vy += 1200 * dt;
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        if (e.koTimer >= 0.34) {
          this.enemies.splice(i, 1);
        }
        continue;
      }

      const slowMul = e.chillTimer > 0 ? 0.55 : 1;
      const spdScale = cfg.speedScale * slowMul;
      const ex = e.x + e.w / 2;
      const ey = e.y + e.h / 2;
      const dx = px - ex;
      const dy = py - ey;
      const dist = Math.hypot(dx, dy);

      if (e.stunTimer > 0) {
        e.vx *= 0.88;
      } else if (e.windupTimer > 0) {
        e.windupTimer -= dt;
        e.vx *= 0.85;
        if (e.windupTimer <= 0) {
          // Execute telegraphed attack
          e.hasToken = false;
          activeTokens = Math.max(0, activeTokens - 1);
          if (e.archetype === 'stalker') {
            e.vx = e.facing * 430 * spdScale;
            e.vy = -340;
            e.attackCooldown = 1.6;
          } else if (e.archetype === 'charger') {
            e.vx = e.facing * 520 * spdScale;
            e.attackCooldown = 2.1;
          } else if (e.archetype === 'archer') {
            const ang = Math.atan2(dy, dx);
            this.spawnProjectile({
              fromPlayer: false,
              x: ex,
              y: ey - 6,
              vx: Math.cos(ang) * 420 * spdScale,
              vy: Math.sin(ang) * 420 * spdScale,
              radius: 5,
              damage: 13,
              color: '#fbbf24',
              life: 2.8,
            });
            e.attackCooldown = 2.1;
          } else if (e.archetype === 'wisp') {
            const ang = Math.atan2(dy, dx);
            this.spawnProjectile({
              fromPlayer: false,
              x: ex,
              y: ey,
              vx: Math.cos(ang) * 300 * spdScale,
              vy: Math.sin(ang) * 300 * spdScale,
              radius: 7,
              damage: 14,
              color: '#c084fc',
              life: 3.2,
            });
            e.attackCooldown = 2.2;
          }
        }
      } else {
        e.attackCooldown = Math.max(0, e.attackCooldown - dt);
        e.facing = dx >= 0 ? 1 : -1;

        if (e.archetype === 'stalker') {
          e.vx += (e.facing * 185 * spdScale - e.vx) * Math.min(1, dt * 6);
          if (dist < 170 && e.attackCooldown <= 0 && activeTokens < cfg.maxConcurrentAttackers) {
            e.hasToken = true;
            activeTokens++;
            e.windupMax = 0.38;
            e.windupTimer = 0.38;
            gameAudio.playTelegraph();
          }
        } else if (e.archetype === 'archer') {
          const desired = dist < 240 ? -e.facing * 130 : dist > 460 ? e.facing * 130 : 0;
          e.vx += (desired * spdScale - e.vx) * Math.min(1, dt * 5);
          if (dist < 620 && e.attackCooldown <= 0 && activeTokens < cfg.maxConcurrentAttackers) {
            e.hasToken = true;
            activeTokens++;
            e.windupMax = 0.55;
            e.windupTimer = 0.55;
            gameAudio.playTelegraph();
          }
        } else if (e.archetype === 'charger') {
          e.vx += (e.facing * 115 * spdScale - e.vx) * Math.min(1, dt * 5);
          if (
            Math.abs(dy) < 90 &&
            dist < 340 &&
            e.attackCooldown <= 0 &&
            activeTokens < cfg.maxConcurrentAttackers
          ) {
            e.hasToken = true;
            activeTokens++;
            e.windupMax = 0.52;
            e.windupTimer = 0.52;
            gameAudio.playTelegraph();
          }
        } else if (e.archetype === 'wisp') {
          e.aiPhase += dt * 2.3;
          const hoverX = px + Math.cos(e.aiPhase) * 210;
          const hoverY = Math.max(150, py - 140 + Math.sin(e.aiPhase * 1.4) * 55);
          e.vx = clamp((hoverX - ex) * 2.4 * spdScale, -220, 220);
          e.vy = clamp((hoverY - ey) * 2.4 * spdScale, -180, 180);
          if (dist < 420 && e.attackCooldown <= 0 && activeTokens < cfg.maxConcurrentAttackers) {
            e.hasToken = true;
            activeTokens++;
            e.windupMax = 0.45;
            e.windupTimer = 0.45;
            gameAudio.playTelegraph();
          }
        }
      }

      // Physics for ground enemies vs flying wisps
      if (e.archetype !== 'wisp') {
        e.vy = Math.min(980, e.vy + 1500 * dt);
      }
      e.x = clamp(e.x + e.vx * dt, 24, WORLD_WIDTH - e.w - 24);
      e.y += e.vy * dt;

      if (e.archetype !== 'wisp' && e.y + e.h >= GROUND_Y) {
        e.y = GROUND_Y - e.h;
        e.vy = 0;
        e.isGrounded = true;
      }

      // Contact hurt check
      if (checkAABB(this.player, e)) {
        this.hurtPlayer(e.archetype === 'charger' ? 18 : 12, e.x + e.w / 2);
      }
    }
  }

  private updateBoss(dt: number): void {
    const boss = this.boss;
    if (!boss) return;

    boss.hitFlash = Math.max(0, boss.hitFlash - dt);
    boss.telegraphTimer = Math.max(0, boss.telegraphTimer - dt);

    const px = this.player.x + this.player.w / 2;
    const py = this.player.y + this.player.h / 2;
    const bx = boss.x + boss.w / 2;
    const by = boss.y + boss.h / 2;
    boss.facing = px >= bx ? 1 : -1;

    // Hover & strafe above arena
    const targetX = clamp(px + Math.sin(this.time * 0.9) * 240, 160, WORLD_WIDTH - 240);
    const targetY = boss.phase === 3 ? 210 + Math.sin(this.time * 2.2) * 50 : 250 + Math.sin(this.time * 1.4) * 40;
    boss.vx = (targetX - bx) * 1.6;
    boss.vy = (targetY - by) * 1.6;
    boss.x = clamp(boss.x + boss.vx * dt, 90, WORLD_WIDTH - boss.w - 90);
    boss.y = clamp(boss.y + boss.vy * dt, 100, GROUND_Y - boss.h - 120);

    boss.patternCooldown -= dt;
    if (boss.patternCooldown <= 0.5 && boss.patternCooldown > 0 && boss.telegraphTimer <= 0) {
      boss.telegraphTimer = 0.5;
      gameAudio.playTelegraph();
    }

    if (boss.patternCooldown <= 0) {
      const pattern = selectBossBulletPattern(boss.phase, boss.patternCycle++);
      const def = BOSSES[boss.id];
      const bulletColor = boss.phase === 3 ? '#ef4444' : def.accentColor;

      if (pattern === 'aimed_fan') {
        const baseAng = Math.atan2(py - by, px - bx);
        const count = boss.phase === 1 ? 5 : 7;
        for (let i = 0; i < count; i++) {
          const offset = (i - (count - 1) / 2) * 0.2;
          const ang = baseAng + offset;
          this.spawnProjectile({
            fromPlayer: false,
            x: bx,
            y: by,
            vx: Math.cos(ang) * 340,
            vy: Math.sin(ang) * 340,
            radius: 7,
            damage: 15,
            color: bulletColor,
            life: 4.0,
          });
        }
        boss.patternCooldown = boss.phase === 3 ? 1.5 : 2.1;
      } else if (pattern === 'radial_ring') {
        const count = boss.phase === 1 ? 10 : boss.phase === 2 ? 14 : 18;
        for (let i = 0; i < count; i++) {
          const ang = (Math.PI * 2 * i) / count + boss.spiralAngle;
          this.spawnProjectile({
            fromPlayer: false,
            x: bx,
            y: by,
            vx: Math.cos(ang) * 260,
            vy: Math.sin(ang) * 260,
            radius: 7,
            damage: 14,
            color: bulletColor,
            life: 4.5,
          });
        }
        boss.spiralAngle += 0.35;
        boss.patternCooldown = boss.phase === 3 ? 1.45 : 2.0;
      } else if (pattern === 'spiral_curtain') {
        const arms = boss.phase === 3 ? 6 : 4;
        for (let i = 0; i < arms; i++) {
          const ang = boss.spiralAngle + (Math.PI * 2 * i) / arms;
          this.spawnProjectile({
            fromPlayer: false,
            x: bx,
            y: by,
            vx: Math.cos(ang) * 250,
            vy: Math.sin(ang) * 250,
            radius: 6,
            damage: 13,
            color: '#f97316',
            life: 4.8,
          });
        }
        boss.spiralAngle += 0.48;
        boss.patternCooldown = 0.42;
        if (boss.patternCycle % 6 === 0) boss.patternCooldown = 1.65;
      } else {
        // sky_rain
        for (let i = 0; i < 8; i++) {
          const rx = 140 + i * 190 + (Math.random() - 0.5) * 60;
          this.spawnProjectile({
            fromPlayer: false,
            x: rx,
            y: 40,
            vx: (Math.random() - 0.5) * 40,
            vy: 310,
            radius: 7,
            damage: 15,
            color: '#f43f5e',
            life: 3.4,
          });
        }
        boss.patternCooldown = 1.65;
      }
    }

    if (checkAABB(this.player, boss)) {
      this.hurtPlayer(18, bx);
    }
  }

  private spawnProjectile(opts: Omit<Projectile, 'active'>): void {
    for (const p of this.projectiles) {
      if (!p.active) {
        p.active = true;
        p.fromPlayer = opts.fromPlayer;
        p.x = opts.x;
        p.y = opts.y;
        p.vx = opts.vx;
        p.vy = opts.vy;
        p.radius = opts.radius;
        p.damage = opts.damage;
        p.color = opts.color;
        p.element = opts.element;
        p.life = opts.life;
        return;
      }
    }
  }

  private updateProjectiles(dt: number): void {
    for (const pr of this.projectiles) {
      if (!pr.active) continue;
      pr.life -= dt;
      if (pr.life <= 0 || pr.x < -30 || pr.x > WORLD_WIDTH + 30 || pr.y > GROUND_Y + 20) {
        pr.active = false;
        continue;
      }
      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;

      const box = {
        x: pr.x - pr.radius,
        y: pr.y - pr.radius,
        w: pr.radius * 2,
        h: pr.radius * 2,
      };

      if (pr.fromPlayer) {
        let hit = false;
        for (const e of this.enemies) {
          if (e.koTimer > 0) continue;
          if (checkAABB(box, e)) {
            this.damageEnemy(e, pr.damage, pr.element ?? 'fire', pr.vx >= 0 ? 1 : -1);
            hit = true;
            break;
          }
        }
        if (!hit && this.boss && checkAABB(box, this.boss)) {
          this.damageBoss(pr.damage, pr.element ?? 'fire');
          hit = true;
        }
        if (hit) pr.active = false;
      } else if (checkAABB(box, this.player)) {
        this.hurtPlayer(pr.damage, pr.x);
        pr.active = false;
      }
    }
  }

  private updatePickups(dt: number): void {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const pk = this.pickups[i];
      pk.life -= dt;
      if (pk.life <= 0) {
        this.pickups.splice(i, 1);
        continue;
      }
      pk.vy = Math.min(720, pk.vy + 1100 * dt);
      pk.y += pk.vy * dt;
      if (pk.y >= GROUND_Y - 12) {
        pk.y = GROUND_Y - 12;
        pk.vy = 0;
      }

      const d = Math.hypot(
        this.player.x + this.player.w / 2 - pk.x,
        this.player.y + this.player.h / 2 - pk.y
      );
      if (d < 44) {
        if (pk.kind === 'heart') {
          this.player.hp = Math.min(this.stats.maxHp, this.player.hp + pk.value);
          this.addFloatingText(pk.x, pk.y - 14, `+${pk.value} HP`, '#34d399');
        } else {
          const val = Math.round(pk.value * this.stats.essenceBonus);
          this.essenceEarned += val;
          this.addFloatingText(pk.x, pk.y - 14, `+${val} ESSENCE`, '#fbbf24');
        }
        gameAudio.playPickup();
        this.pickups.splice(i, 1);
      }
    }
  }

  private hurtPlayer(rawDmg: number, sourceX: number): void {
    if (this.player.invulnTimer > 0 || this.defeatDelayTimer >= 0) return;

    const mitigation = this.activeBuff?.type === 'iron_skin' ? 0.55 : 1;
    const dmg = Math.max(1, Math.round(rawDmg * mitigation));
    this.player.hp = Math.max(0, this.player.hp - dmg);
    this.player.invulnTimer = 0.75;
    this.combo = 0;

    const pushDir = this.player.x + this.player.w / 2 >= sourceX ? 1 : -1;
    this.player.vx = pushDir * 280;
    this.player.vy = -260;
    this.player.squashX = 1.25;
    this.player.squashY = 0.78;

    this.hitstopTimer = 0.05;
    this.trauma = Math.min(1, this.trauma + 0.55);
    gameAudio.playHurt();
    this.particles.burst(
      this.player.x + this.player.w / 2,
      this.player.y + this.player.h / 2,
      14,
      '#ef4444',
      80,
      240,
      4,
      0.4,
      360
    );
    this.addFloatingText(this.player.x + 14, this.player.y - 14, `-${dmg}`, '#ef4444');
    this.emitHud();

    if (this.player.hp <= 0) {
      this.defeatDelayTimer = 0.55;
      gameAudio.playGameOver();
    }
  }

  private finishRun(): void {
    this.running = false;
    const score = calculateRunScore(
      this.kills,
      this.wave,
      this.bossesDefeated,
      this.puzzlesSolved,
      this.maxCombo
    );
    this.callbacks.onGameOver({
      score,
      bestScore: Math.max(score, this.profile.bestScore),
      wave: this.wave,
      kills: this.kills,
      bossesDefeated: this.bossesDefeated,
      puzzlesSolved: this.puzzlesSolved,
      maxCombo: this.maxCombo,
      essenceEarned: this.essenceEarned,
      skin: this.profile.selectedSkin,
      element: this.profile.activeElement,
      mode: this.isRaidMode ? 'coop' : 'solo',
      durationSec: Math.round(this.runTime),
    });
  }

  private addFloatingText(x: number, y: number, text: string, color: string): void {
    this.floatingTexts.push({
      x,
      y,
      vy: -48,
      text,
      color,
      life: 0.75,
      maxLife: 0.75,
    });
  }

  private updateFloatingTexts(dt: number): void {
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const f = this.floatingTexts[i];
      f.life -= dt;
      f.y += f.vy * dt;
      if (f.life <= 0) this.floatingTexts.splice(i, 1);
    }
  }

  private emitHud(): void {
    const score = calculateRunScore(
      this.kills,
      this.wave,
      this.bossesDefeated,
      this.puzzlesSolved,
      this.maxCombo
    );
    const bossDef = this.boss ? BOSSES[this.boss.id] : null;
    this.callbacks.onHudUpdate({
      hp: Math.round(this.player.hp),
      maxHp: Math.round(this.stats.maxHp),
      ghostHp: Math.round(this.player.ghostHp),
      score,
      combo: this.combo,
      maxCombo: this.maxCombo,
      wave: this.wave,
      enemiesRemaining: this.enemiesToSpawn + this.enemies.length + (this.boss ? 1 : 0),
      kills: this.kills,
      essenceEarned: this.essenceEarned,
      activeElement: this.profile.activeElement,
      weaponLevel: this.profile.weaponLevels[this.profile.activeElement] ?? 1,
      dashReadyRatio: clamp(
        1 - this.player.dashCooldownTimer / Math.max(0.1, this.stats.dashCooldown),
        0,
        1
      ),
      companionReadyRatio: clamp(
        1 - this.companion.cooldownTimer / this.companion.cooldownMax,
        0,
        1
      ),
      companionActive: Boolean(this.activeBuff),
      activeBuff: this.activeBuff ? { ...this.activeBuff } : null,
      boss:
        this.boss && bossDef
          ? {
              name: bossDef.name,
              subtitle: bossDef.subtitle,
              hp: Math.round(this.boss.hp),
              maxHp: Math.round(this.boss.maxHp),
              phase: this.boss.phase,
              weakness: bossDef.weakness,
              resistance: bossDef.resistance,
            }
          : null,
      shrinePrompt: {
        active: this.shrine.active && !this.shrine.solved,
        progress: this.shrine.progress,
        requiredElement: this.shrine.requiredElement,
        solvedCount: this.puzzlesSolved,
      },
      bossesDefeated: this.bossesDefeated,
      puzzlesSolved: this.puzzlesSolved,
      muted: gameAudio.muted,
      raidRoomId: this.raidRoomId,
      raidPlayersCount: 1 + this.remotePlayers.size,
    });
  }

  private render(): void {
    const ctx = this.ctx;
    const cw = this.canvas.width;
    const ch = this.canvas.height;
    ctx.clearRect(0, 0, cw, ch);

    // Responsive fit from 1600x900 world to viewport
    const scale = Math.max(cw / WORLD_WIDTH, ch / WORLD_HEIGHT);
    const viewW = cw / scale;
    const viewH = ch / scale;
    const targetCamX = clamp(
      this.player.x + this.player.w / 2 - viewW / 2,
      0,
      Math.max(0, WORLD_WIDTH - viewW)
    );
    const targetCamY = clamp(
      this.player.y + this.player.h / 2 - viewH * 0.56,
      0,
      Math.max(0, WORLD_HEIGHT - viewH)
    );
    this.camX += (targetCamX - this.camX) * 0.16;

    const shake = this.trauma * this.trauma * 16;
    const sx = (Math.random() * 2 - 1) * shake;
    const sy = (Math.random() * 2 - 1) * shake;

    ctx.save();
    ctx.scale(scale, scale);
    ctx.translate(-this.camX + sx, -targetCamY + sy);

    const bossEnraged = Boolean(this.boss && this.boss.phase >= 2);
    drawCitadelBackdrop(ctx, this.camX, this.time, bossEnraged);

    // Ambient drifting embers
    for (const ember of this.ambientEmbers) {
      ctx.fillStyle = bossEnraged ? '#fb923c' : '#f59e0b';
      ctx.globalAlpha = 0.5;
      ctx.fillRect(Math.round(ember.x), Math.round(ember.y), ember.s, ember.s);
    }
    ctx.globalAlpha = 1;

    drawPlatforms(ctx, ARENA_PLATFORMS, this.time);

    if (this.shrine.active) {
      drawShrinePuzzle(
        ctx,
        this.shrine.x,
        this.shrine.y,
        this.shrine.requiredElement,
        this.shrine.progress,
        this.shrine.solved,
        this.time
      );
    }

    // Pickups
    for (const pk of this.pickups) {
      const py = Math.round(pk.y + Math.sin(this.time * 5 + pk.id) * 3);
      ctx.fillStyle = '#090b12';
      ctx.fillRect(Math.round(pk.x - 8), py - 8, 16, 16);
      ctx.fillStyle = pk.kind === 'heart' ? '#ef4444' : '#fbbf24';
      ctx.fillRect(Math.round(pk.x - 6), py - 6, 12, 12);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(Math.round(pk.x - 2), py - 4, 4, 4);
    }

    // Remote co-op raiders
    for (const rp of this.remotePlayers.values()) {
      drawPixelPlayer(ctx, {
        x: rp.x,
        y: rp.y,
        w: 28,
        h: 50,
        facing: rp.facing,
        skinId: rp.skin,
        element: rp.element,
        walkCycle: this.time * 18,
        isGrounded: true,
        attackProgress: rp.attacking ? 0.5 : 0,
        dashing: rp.dashing,
        invulnTimer: 0,
        squashX: 1,
        squashY: 1,
        callsign: rp.callsign,
        isRemote: true,
      });
    }

    // Enemies
    for (const e of this.enemies) {
      drawEnemySprite(ctx, {
        archetype: e.archetype,
        x: e.x,
        y: e.y,
        w: e.w,
        h: e.h,
        facing: e.facing,
        hp: e.hp,
        maxHp: e.maxHp,
        hitFlash: e.hitFlash,
        windupRatio: e.windupTimer > 0 ? e.windupTimer / e.windupMax : 0,
        koTimer: e.koTimer,
        chilled: e.chillTimer > 0,
        time: this.time,
      });
    }

    // Boss
    if (this.boss) {
      drawBossSprite(ctx, {
        def: BOSSES[this.boss.id],
        x: this.boss.x,
        y: this.boss.y,
        w: this.boss.w,
        h: this.boss.h,
        facing: this.boss.facing,
        phase: this.boss.phase,
        hitFlash: this.boss.hitFlash,
        telegraphTimer: this.boss.telegraphTimer,
        time: this.time,
      });
    }

    // Companion
    drawCompanion(
      ctx,
      this.profile.selectedCompanion,
      this.companion.x,
      this.companion.y,
      this.time,
      Boolean(this.activeBuff)
    );

    // Local Player
    const attackProg =
      this.player.attackTimer > 0
        ? 1 - this.player.attackTimer / Math.max(0.01, this.player.attackDuration)
        : 0;
    drawPixelPlayer(ctx, {
      x: this.player.x,
      y: this.player.y,
      w: this.player.w,
      h: this.player.h,
      facing: this.player.facing,
      skinId: this.profile.selectedSkin,
      element: this.profile.activeElement,
      walkCycle: this.player.walkCycle,
      isGrounded: this.player.isGrounded,
      attackProgress: attackProg,
      dashing: this.player.dashTimer > 0,
      invulnTimer: this.player.invulnTimer,
      squashX: this.player.squashX,
      squashY: this.player.squashY,
      callsign: this.isRaidMode ? this.profile.callsign : undefined,
    });

    // Projectiles
    for (const pr of this.projectiles) {
      if (!pr.active) continue;
      ctx.fillStyle = '#090b12';
      ctx.beginPath();
      ctx.arc(pr.x, pr.y, pr.radius + 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = pr.color;
      ctx.beginPath();
      ctx.arc(pr.x, pr.y, pr.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(Math.round(pr.x - 2), Math.round(pr.y - 2), 4, 4);
    }

    // Particles
    this.particles.draw(ctx);

    // Floating combat numbers
    for (const f of this.floatingTexts) {
      const alpha = Math.max(0, Math.min(1, f.life / f.maxLife));
      ctx.globalAlpha = alpha;
      ctx.font = 'bold 14px "Chakra Petch", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#090b12';
      ctx.fillText(f.text, Math.round(f.x) + 1, Math.round(f.y) + 1);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, Math.round(f.x), Math.round(f.y));
    }
    ctx.globalAlpha = 1;

    ctx.restore();
  }
}
