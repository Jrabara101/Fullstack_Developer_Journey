import { ELEMENTS, SKINS, WORLD_HEIGHT, WORLD_WIDTH, GROUND_Y } from './catalog';
import type {
  BossDef,
  BossPhase,
  CompanionId,
  ElementAffinity,
  EnemyArchetype,
  PlatformDef,
  SkinId,
} from './types';

export interface ParticleSlot {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  color: string;
  gravity: number;
}

export class ParticlePool {
  public readonly slots: ParticleSlot[];
  private cursor = 0;

  constructor(capacity = 320) {
    this.slots = Array.from({ length: capacity }, () => ({
      active: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      size: 3,
      life: 0,
      maxLife: 0.4,
      color: '#fb923c',
      gravity: 400,
    }));
  }

  public clear(): void {
    for (let i = 0; i < this.slots.length; i++) {
      this.slots[i].active = false;
    }
  }

  public spawn(
    x: number,
    y: number,
    vx: number,
    vy: number,
    color: string,
    size = 4,
    maxLife = 0.38,
    gravity = 420
  ): void {
    const p = this.slots[this.cursor];
    this.cursor = (this.cursor + 1) % this.slots.length;
    p.active = true;
    p.x = x;
    p.y = y;
    p.vx = vx;
    p.vy = vy;
    p.color = color;
    p.size = size;
    p.life = maxLife;
    p.maxLife = maxLife;
    p.gravity = gravity;
  }

  public burst(
    x: number,
    y: number,
    count: number,
    color: string,
    speedMin = 70,
    speedMax = 240,
    size = 4,
    maxLife = 0.42,
    gravity = 450
  ): void {
    for (let i = 0; i < count; i++) {
      const ang = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.5;
      const spd = speedMin + Math.random() * (speedMax - speedMin);
      this.spawn(
        x,
        y,
        Math.cos(ang) * spd,
        Math.sin(ang) * spd - 40,
        color,
        size + (Math.random() > 0.6 ? 2 : 0),
        maxLife * (0.7 + Math.random() * 0.5),
        gravity
      );
    }
  }

  public update(dt: number): void {
    for (let i = 0; i < this.slots.length; i++) {
      const p = this.slots[i];
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        continue;
      }
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
  }

  public draw(ctx: CanvasRenderingContext2D): void {
    for (let i = 0; i < this.slots.length; i++) {
      const p = this.slots[i];
      if (!p.active) continue;
      const alpha = Math.max(0, Math.min(1, p.life / p.maxLife));
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;
      const sz = Math.max(2, Math.round(p.size * (0.5 + 0.5 * alpha)));
      ctx.fillRect(Math.round(p.x - sz / 2), Math.round(p.y - sz / 2), sz, sz);
    }
    ctx.globalAlpha = 1;
  }
}

let cachedSkyNormal: CanvasGradient | null = null;
let cachedSkyEnraged: CanvasGradient | null = null;

export function drawCitadelBackdrop(
  ctx: CanvasRenderingContext2D,
  camX: number,
  time: number,
  bossEnraged: boolean
): void {
  // Sky gradient (cached to avoid per-frame allocation)
  if (!cachedSkyNormal) {
    cachedSkyNormal = ctx.createLinearGradient(0, 0, 0, WORLD_HEIGHT);
    cachedSkyNormal.addColorStop(0, '#0a0d17');
    cachedSkyNormal.addColorStop(0.6, '#13192b');
    cachedSkyNormal.addColorStop(1, '#231620');
  }
  if (!cachedSkyEnraged) {
    cachedSkyEnraged = ctx.createLinearGradient(0, 0, 0, WORLD_HEIGHT);
    cachedSkyEnraged.addColorStop(0, '#140b18');
    cachedSkyEnraged.addColorStop(0.55, '#251026');
    cachedSkyEnraged.addColorStop(1, '#3b1318');
  }
  ctx.fillStyle = bossEnraged ? cachedSkyEnraged : cachedSkyNormal;
  ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

  // Pixel crescent moon (subtle atmospheric highlight, won't compete with top-right HUD)
  const moonX = Math.round(1180 - camX * 0.04);
  const moonY = 148;
  ctx.fillStyle = bossEnraged ? 'rgba(249, 115, 22, 0.10)' : 'rgba(148, 163, 184, 0.08)';
  ctx.beginPath();
  ctx.arc(moonX, moonY, 64, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = bossEnraged ? '#fb923c' : '#94a3b8';
  ctx.fillRect(moonX - 18, moonY - 26, 36, 52);
  ctx.fillRect(moonX - 24, moonY - 18, 48, 36);
  ctx.fillStyle = bossEnraged ? '#1b0d1b' : '#0d111e';
  ctx.fillRect(moonX - 10, moonY - 22, 34, 42);
  ctx.fillRect(moonX - 4, moonY - 26, 32, 50);

  // Far parallax ruined spires
  ctx.fillStyle = '#111625';
  const farOffset = -(camX * 0.14) % 320;
  for (let x = farOffset - 320; x < WORLD_WIDTH + 320; x += 320) {
    const rx = Math.round(x);
    ctx.fillRect(rx + 20, 420, 90, 360);
    ctx.fillRect(rx + 42, 340, 46, 80);
    ctx.fillRect(rx + 56, 290, 18, 50);
    ctx.fillRect(rx + 165, 470, 110, 310);
    ctx.fillRect(rx + 185, 430, 26, 40);
    ctx.fillRect(rx + 230, 430, 26, 40);
  }

  // Mid parallax bastion arches & glowing torch windows
  ctx.fillStyle = '#182032';
  const midOffset = -(camX * 0.28) % 400;
  for (let x = midOffset - 400; x < WORLD_WIDTH + 400; x += 400) {
    const rx = Math.round(x);
    ctx.fillRect(rx, 540, 130, 240);
    ctx.fillRect(rx + 210, 500, 140, 280);
    // Glowing slit windows
    const flicker = 0.65 + 0.35 * Math.sin(time * 6 + rx * 0.02);
    ctx.fillStyle = bossEnraged
      ? `rgba(249, 115, 22, ${flicker})`
      : `rgba(251, 191, 36, ${flicker * 0.75})`;
    ctx.fillRect(rx + 56, 580, 16, 36);
    ctx.fillRect(rx + 270, 548, 18, 42);
    ctx.fillStyle = '#182032';
  }

  // Magma glow strip along abyss edge
  const lavaPulse = 0.22 + 0.08 * Math.sin(time * 3.5);
  ctx.fillStyle = `rgba(234, 88, 12, ${lavaPulse})`;
  ctx.fillRect(0, GROUND_Y - 36, WORLD_WIDTH, 36);
}

export function drawPlatforms(
  ctx: CanvasRenderingContext2D,
  platforms: PlatformDef[],
  time: number
): void {
  for (const p of platforms) {
    const x = Math.round(p.x);
    const y = Math.round(p.y);
    const w = Math.round(p.w);
    const h = Math.round(p.h);

    if (!p.oneWay) {
      // Main obsidian bastion floor
      ctx.fillStyle = '#1e2636';
      ctx.fillRect(x, y, w, h);
      // Top stone trim
      ctx.fillStyle = '#475569';
      ctx.fillRect(x, y, w, 8);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(x, y, w, 3);

      // Brick pattern
      ctx.fillStyle = '#141925';
      for (let bx = x; bx < x + w; bx += 48) {
        ctx.fillRect(bx, y + 12, 2, 28);
        ctx.fillRect(bx + 24, y + 40, 2, 28);
      }
      // Subtle magma fissures under floor
      const pulse = 0.45 + 0.25 * Math.sin(time * 2.8);
      ctx.fillStyle = `rgba(234, 88, 12, ${pulse})`;
      ctx.fillRect(x, y + 72, w, 4);
    } else {
      // Elevated catwalk / spire stone slab
      ctx.fillStyle = '#090c14';
      ctx.fillRect(x + 2, y + 4, w - 4, h);
      ctx.fillStyle = '#293548';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(x, y, w, 4);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(x + 4, y, w - 8, 2);

      // Stone rivets & rune notches
      ctx.fillStyle = '#161e2e';
      for (let bx = x + 16; bx < x + w - 12; bx += 36) {
        ctx.fillRect(bx, y + 8, 10, 6);
      }
    }
  }
}

export function drawPixelPlayer(
  ctx: CanvasRenderingContext2D,
  opts: {
    x: number;
    y: number;
    w: number;
    h: number;
    facing: 1 | -1;
    skinId: SkinId;
    element: ElementAffinity;
    walkCycle: number;
    isGrounded: boolean;
    attackProgress: number; // 0 if idle, >0..1 during swing
    dashing: boolean;
    invulnTimer: number;
    squashX: number;
    squashY: number;
    callsign?: string;
    isRemote?: boolean;
  }
): void {
  const skin = SKINS.find((s) => s.id === opts.skinId) ?? SKINS[0];
  const elem = ELEMENTS[opts.element];

  if (opts.invulnTimer > 0 && Math.floor(opts.invulnTimer * 24) % 2 === 0 && !opts.dashing) {
    ctx.globalAlpha = 0.45;
  } else if (opts.isRemote) {
    ctx.globalAlpha = 0.85;
  }

  const cx = Math.round(opts.x + opts.w / 2);
  const bottom = Math.round(opts.y + opts.h);

  ctx.save();
  ctx.translate(cx, bottom);
  ctx.scale(opts.facing * opts.squashX, opts.squashY);

  // Dash afterimage bar
  if (opts.dashing) {
    ctx.fillStyle = elem.glow;
    ctx.globalAlpha = 0.45;
    ctx.fillRect(-28, -42, 16, 36);
    ctx.globalAlpha = 1;
  }

  const stride = opts.isGrounded ? Math.sin(opts.walkCycle * 0.16) * 5 : 4;
  const bob = opts.isGrounded ? Math.abs(Math.cos(opts.walkCycle * 0.16)) * 2 : 0;

  // Flowing pixel cape
  ctx.fillStyle = skin.capeColor;
  const capeWave = Math.sin(opts.walkCycle * 0.14) * 3;
  ctx.fillRect(-15, -36 - bob + capeWave * 0.4, 9, 24);
  ctx.fillRect(-18, -28 - bob + capeWave, 6, 14);

  // Legs
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(-8 + stride, -12, 6, 12);
  ctx.fillRect(2 - stride, -12, 6, 12);
  // Boots
  ctx.fillStyle = skin.armorSecondary;
  ctx.fillRect(-9 + stride, -5, 8, 5);
  ctx.fillRect(1 - stride, -5, 8, 5);

  // Torso armor
  ctx.fillStyle = '#090b12';
  ctx.fillRect(-11, -33 - bob, 22, 23);
  ctx.fillStyle = skin.armorSecondary;
  ctx.fillRect(-10, -32 - bob, 20, 21);
  ctx.fillStyle = skin.armorPrimary;
  ctx.fillRect(-8, -30 - bob, 16, 14);
  // Elemental chest rune
  ctx.fillStyle = elem.color;
  ctx.fillRect(-2, -26 - bob, 5, 6);

  // Helmet & glowing visor
  ctx.fillStyle = '#090b12';
  ctx.fillRect(-10, -48 - bob, 20, 17);
  ctx.fillStyle = skin.armorPrimary;
  ctx.fillRect(-9, -47 - bob, 18, 15);
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(-3, -42 - bob, 11, 5);
  ctx.fillStyle = skin.visorGlow;
  ctx.fillRect(0, -41 - bob, 7, 3);

  // Weapon & Slash arc
  if (opts.attackProgress > 0) {
    const swingAngle = -1.2 + opts.attackProgress * 2.4;
    ctx.save();
    ctx.translate(6, -24 - bob);
    ctx.rotate(swingAngle);
    // Blade
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(0, -3, 32, 6);
    ctx.fillStyle = elem.color;
    ctx.fillRect(6, -2, 28, 4);
    ctx.fillStyle = elem.glow;
    ctx.fillRect(18, -1, 16, 2);
    ctx.restore();

    // Pixel slash crescent
    if (opts.attackProgress > 0.15 && opts.attackProgress < 0.85) {
      ctx.strokeStyle = elem.glow;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(10, -24 - bob, 44, -0.95, 0.85);
      ctx.stroke();
    }
  } else {
    // Carried weapon
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(8, -28 - bob, 5, 22);
    ctx.fillStyle = elem.color;
    ctx.fillRect(9, -32 - bob, 3, 18);
  }

  ctx.restore();
  ctx.globalAlpha = 1;

  if (opts.callsign) {
    ctx.font = 'bold 11px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#090b12';
    ctx.fillText(opts.callsign, cx + 1, opts.y - 9);
    ctx.fillStyle = opts.isRemote ? '#38bdf8' : '#f8fafc';
    ctx.fillText(opts.callsign, cx, opts.y - 10);
  }
}

export function drawEnemySprite(
  ctx: CanvasRenderingContext2D,
  opts: {
    archetype: EnemyArchetype;
    x: number;
    y: number;
    w: number;
    h: number;
    facing: 1 | -1;
    hp: number;
    maxHp: number;
    hitFlash: number;
    windupRatio: number; // 0..1 when telegraphing attack
    koTimer: number; // >0 during death fall
    chilled: boolean;
    time: number;
  }
): void {
  const cx = Math.round(opts.x + opts.w / 2);
  const bottom = Math.round(opts.y + opts.h);

  ctx.save();
  ctx.translate(cx, bottom);
  if (opts.koTimer > 0) {
    const t = Math.min(1, opts.koTimer / 0.32);
    ctx.globalAlpha = 1 - t;
    ctx.rotate(opts.facing * -t * 1.1);
  }
  ctx.scale(opts.facing, 1);

  const flash = opts.hitFlash > 0;
  const bounce = Math.sin(opts.time * 8 + opts.x * 0.05) * 2;

  if (opts.archetype === 'stalker') {
    // Agile clawed hound/ghoul
    ctx.fillStyle = flash ? '#ffffff' : opts.chilled ? '#38bdf8' : '#991b1b';
    ctx.fillRect(-14, -30 + bounce, 28, 22);
    ctx.fillStyle = flash ? '#ffffff' : '#450a0a';
    ctx.fillRect(-12, -10, 6, 10);
    ctx.fillRect(6, -10, 6, 10);
    // Glowing eyes & claws
    ctx.fillStyle = opts.windupRatio > 0 ? '#fde047' : '#fb923c';
    ctx.fillRect(4, -26 + bounce, 6, 4);
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(10, -16 + bounce, 8, 4);
  } else if (opts.archetype === 'archer') {
    // Hooded skeletal marksman
    ctx.fillStyle = flash ? '#ffffff' : opts.chilled ? '#38bdf8' : '#334155';
    ctx.fillRect(-11, -38, 22, 30);
    ctx.fillStyle = flash ? '#ffffff' : '#1e293b';
    ctx.fillRect(-9, -46, 18, 12);
    ctx.fillStyle = '#fbbf24';
    ctx.fillRect(2, -41, 5, 3);
    // Bow
    ctx.fillStyle = '#92400e';
    ctx.fillRect(10, -36, 4, 24);
  } else if (opts.archetype === 'charger') {
    // Heavy armored bull vanguard with front shield
    ctx.fillStyle = flash ? '#ffffff' : opts.chilled ? '#38bdf8' : '#475569';
    ctx.fillRect(-20, -44, 40, 36);
    // Horns
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(8, -52, 6, 10);
    ctx.fillRect(-2, -50, 5, 8);
    // Front iron shield
    ctx.fillStyle = flash ? '#ffffff' : '#94a3b8';
    ctx.fillRect(15, -42, 7, 36);
    ctx.fillStyle = opts.windupRatio > 0 ? '#ef4444' : '#f97316';
    ctx.fillRect(6, -34, 7, 5);
  } else {
    // Gloom wisp (floating orbiter)
    const floatY = -22 + Math.sin(opts.time * 5 + opts.x * 0.03) * 6;
    ctx.fillStyle = flash ? '#ffffff' : opts.chilled ? '#38bdf8' : '#6b21a8';
    ctx.fillRect(-14, floatY - 14, 28, 28);
    ctx.fillStyle = flash ? '#ffffff' : '#c084fc';
    ctx.fillRect(-8, floatY - 8, 16, 16);
    ctx.fillStyle = '#fde047';
    ctx.fillRect(2, floatY - 3, 5, 5);
  }

  ctx.restore();

  // Telegraph windup ring / exclamation
  if (opts.windupRatio > 0 && opts.koTimer <= 0) {
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    const r = 18 + (1 - opts.windupRatio) * 18;
    ctx.beginPath();
    ctx.arc(cx, opts.y + opts.h * 0.45, r, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = '#fde047';
    ctx.font = 'bold 14px "Chakra Petch", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('!', cx, opts.y - 8);
  }

  // Mini HP bar when damaged
  if (opts.hp < opts.maxHp && opts.koTimer <= 0) {
    const bw = Math.max(28, opts.w);
    const bx = Math.round(cx - bw / 2);
    const by = Math.round(opts.y - 10);
    ctx.fillStyle = '#090b12';
    ctx.fillRect(bx - 1, by - 1, bw + 2, 6);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(bx, by, Math.round((opts.hp / opts.maxHp) * bw), 4);
  }
}

export function drawBossSprite(
  ctx: CanvasRenderingContext2D,
  opts: {
    def: BossDef;
    x: number;
    y: number;
    w: number;
    h: number;
    facing: 1 | -1;
    phase: BossPhase;
    hitFlash: number;
    telegraphTimer: number;
    time: number;
  }
): void {
  const cx = Math.round(opts.x + opts.w / 2);
  const cy = Math.round(opts.y + opts.h / 2);
  const flash = opts.hitFlash > 0;
  const hover = Math.sin(opts.time * 3) * 5;

  ctx.save();
  ctx.translate(cx, cy + hover);

  // Outer aura ring for Phase 2 / 3
  if (opts.phase >= 2) {
    ctx.strokeStyle = opts.phase === 3 ? '#ef4444' : opts.def.accentColor;
    ctx.lineWidth = 3;
    ctx.globalAlpha = 0.45 + 0.25 * Math.sin(opts.time * 8);
    ctx.beginPath();
    ctx.arc(0, 0, 58 + Math.sin(opts.time * 6) * 4, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  // Telegraph warning ring
  if (opts.telegraphTimer > 0) {
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, 68 * opts.telegraphTimer + 34, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.scale(opts.facing, 1);

  // Boss armored chassis
  ctx.fillStyle = '#090b12';
  ctx.fillRect(-42, -48, 84, 96);
  ctx.fillStyle = flash ? '#ffffff' : opts.def.primaryColor;
  ctx.fillRect(-38, -44, 76, 88);

  // Crown / Horns
  ctx.fillStyle = flash ? '#ffffff' : opts.def.accentColor;
  ctx.fillRect(-34, -62, 14, 18);
  ctx.fillRect(20, -62, 14, 18);
  ctx.fillRect(-10, -58, 20, 14);

  // Pauldrons
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(-52, -32, 18, 36);
  ctx.fillRect(34, -32, 18, 36);

  // Glowing phase core
  ctx.fillStyle = '#090b12';
  ctx.fillRect(-18, -14, 36, 36);
  ctx.fillStyle = opts.phase === 3 ? '#fef08a' : opts.def.accentColor;
  ctx.fillRect(-12, -8, 24, 24);

  // Eyes
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(6, -34, 14, 7);
  ctx.fillRect(-18, -34, 14, 7);

  ctx.restore();
}

export function drawCompanion(
  ctx: CanvasRenderingContext2D,
  id: CompanionId,
  x: number,
  y: number,
  time: number,
  activeBuff: boolean
): void {
  const rx = Math.round(x);
  const ry = Math.round(y + Math.sin(time * 5) * 5);

  ctx.save();
  ctx.translate(rx, ry);

  if (activeBuff) {
    ctx.strokeStyle = id === 'ember_wisp' ? '#fb923c' : id === 'aegis_drone' ? '#38bdf8' : '#c084fc';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 18 + Math.sin(time * 10) * 2, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.fillStyle = '#090b12';
  ctx.fillRect(-10, -10, 20, 20);
  if (id === 'ember_wisp') {
    ctx.fillStyle = '#ea580c';
    ctx.fillRect(-8, -8, 16, 16);
    ctx.fillStyle = '#fde047';
    ctx.fillRect(-4, -4, 8, 8);
  } else if (id === 'aegis_drone') {
    ctx.fillStyle = '#0284c7';
    ctx.fillRect(-9, -7, 18, 14);
    ctx.fillStyle = '#bae6fd';
    ctx.fillRect(-5, -3, 10, 6);
  } else {
    ctx.fillStyle = '#7c3aed';
    ctx.fillRect(-8, -9, 16, 18);
    ctx.fillStyle = '#f0abfc';
    ctx.fillRect(-5, -4, 4, 4);
    ctx.fillRect(1, -4, 4, 4);
  }
  ctx.restore();
}

export function drawShrinePuzzle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  element: ElementAffinity,
  progress: number,
  solved: boolean,
  time: number
): void {
  const elem = ELEMENTS[element];
  const rx = Math.round(x);
  const ry = Math.round(y);

  // Obelisk stone base
  ctx.fillStyle = '#090b12';
  ctx.fillRect(rx - 18, ry - 58, 36, 58);
  ctx.fillStyle = '#334155';
  ctx.fillRect(rx - 15, ry - 55, 30, 55);
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(rx - 11, ry - 48, 22, 42);

  // Floating crystal
  const crystalY = ry - 72 + Math.sin(time * 4) * 4;
  ctx.fillStyle = solved ? '#10b981' : elem.color;
  ctx.fillRect(rx - 8, crystalY - 8, 16, 16);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(rx - 3, crystalY - 3, 6, 6);

  if (!solved) {
    // Channel progress ring
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(rx, ry - 32, 34, 0, Math.PI * 2);
    ctx.stroke();

    if (progress > 0) {
      ctx.strokeStyle = elem.glow;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(rx, ry - 32, 34, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * progress);
      ctx.stroke();
    }

    ctx.font = 'bold 11px "Chakra Petch", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(`[Q] SEAL · ${elem.name.toUpperCase()}`, rx, ry - 94);
  }
}
