import test from 'node:test';
import assert from 'node:assert/strict';
import { INITIAL_PROFILE } from './catalog';
import {
  calculateElementalMultiplier,
  calculateRunScore,
  checkAABB,
  computePlayerStats,
  getBossPhase,
  getWaveConfig,
  resolveOneWayLanding,
  selectBossBulletPattern,
  unlockAbilityNode,
  unlockOrSelectCompanion,
  unlockOrSelectSkin,
  upgradeWeaponElement,
} from './rules';

test('elemental counter matrix rewards matching weakness and penalizes resistance', () => {
  assert.equal(calculateElementalMultiplier('frost', 'frost', 'fire'), 1.65);
  assert.equal(calculateElementalMultiplier('fire', 'frost', 'fire'), 0.7);
  assert.equal(calculateElementalMultiplier('volt', 'frost', 'fire'), 1.0);
});

test('ability tree requires prerequisite node and deducts essence', () => {
  const blocked = unlockAbilityNode(INITIAL_PROFILE, 'vanguard_2');
  assert.deepEqual(blocked.unlockedNodes, []);

  const step1 = unlockAbilityNode(INITIAL_PROFILE, 'vanguard_1');
  assert.equal(step1.essence, INITIAL_PROFILE.essence - 60);
  assert.deepEqual(step1.unlockedNodes, ['vanguard_1']);

  const step2 = unlockAbilityNode(step1, 'vanguard_2');
  assert.equal(step2.essence, INITIAL_PROFILE.essence - 60 - 110);
  assert.deepEqual(step2.unlockedNodes, ['vanguard_1', 'vanguard_2']);

  const stats = computePlayerStats(step2);
  assert.equal(stats.baseDamage, 29);
  assert.ok(stats.attackSpeed > 1.15);
});

test('weapon upgrade, skin unlock, and companion unlock respect essence budget', () => {
  const upgraded = upgradeWeaponElement(INITIAL_PROFILE, 'fire');
  assert.equal(upgraded.weaponLevels.fire, 2);
  assert.equal(upgraded.essence, 130);

  const skinUnlocked = unlockOrSelectSkin(upgraded, 'cobalt_warden');
  assert.equal(skinUnlocked.selectedSkin, 'cobalt_warden');
  assert.equal(skinUnlocked.essence, 10);

  const compFail = unlockOrSelectCompanion(skinUnlocked, 'aegis_drone');
  assert.equal(compFail.selectedCompanion, 'ember_wisp');
});

test('wave config scales difficulty across multiple knobs and triggers bosses every 3 waves', () => {
  const w1 = getWaveConfig(1, false);
  const w2 = getWaveConfig(2, false);
  const w3 = getWaveConfig(3, false);

  assert.equal(w1.isBossWave, false);
  assert.equal(w2.hasShrinePuzzle, true);
  assert.equal(w3.isBossWave, true);
  assert.equal(w3.bossId, 'ignis_colossus');
  assert.ok(w2.enemyBudget > w1.enemyBudget);
  assert.ok(w3.hpScale > w1.hpScale);
});

test('boss phase transitions and bullet-hell patterns progress cleanly', () => {
  assert.equal(getBossPhase(100, 100), 1);
  assert.equal(getBossPhase(60, 100), 2);
  assert.equal(getBossPhase(25, 100), 3);

  assert.equal(selectBossBulletPattern(1, 0), 'aimed_fan');
  assert.equal(selectBossBulletPattern(2, 1), 'spiral_curtain');
  assert.equal(selectBossBulletPattern(3, 1), 'sky_rain');
});

test('AABB collision and one-way platform landing math are accurate', () => {
  assert.equal(checkAABB({ x: 0, y: 0, w: 20, h: 20 }, { x: 15, y: 15, w: 20, h: 20 }), true);
  assert.equal(checkAABB({ x: 0, y: 0, w: 20, h: 20 }, { x: 25, y: 0, w: 20, h: 20 }), false);

  const plat = { x: 100, y: 500, w: 200, h: 20 };
  assert.equal(resolveOneWayLanding(496, 504, 120, 140, 170, plat, false), true);
  assert.equal(resolveOneWayLanding(496, 504, 120, 140, 170, plat, true), false);
  assert.equal(resolveOneWayLanding(510, 520, 120, 140, 170, plat, false), false);
});

test('run score calculation rewards kills, waves, bosses, puzzles, and combo', () => {
  const score = calculateRunScore(15, 4, 1, 2, 12);
  assert.equal(score, 15 * 120 + 4 * 450 + 1800 + 2 * 650 + 12 * 45);
});
