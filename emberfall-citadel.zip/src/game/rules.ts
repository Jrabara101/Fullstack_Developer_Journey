import { ABILITY_TREE, COMPANIONS, SKINS } from './catalog';
import type {
  BossId,
  BossPhase,
  BulletPattern,
  CompanionId,
  ElementAffinity,
  EnemyArchetype,
  PlayerComputedStats,
  PlayerProfile,
  RectBox,
  SkinId,
  WaveConfig,
} from './types';

export function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export function computePlayerStats(profile: PlayerProfile): PlayerComputedStats {
  const stats: PlayerComputedStats = {
    maxHp: 100,
    baseDamage: 24,
    attackSpeed: 1,
    moveSpeed: 350,
    jumpForce: 690,
    extraJumps: 1,
    dashCooldown: 1.35,
    critChance: 0.08,
    lifestealOnKill: 0,
    buffDuration: 8,
    essenceBonus: 1,
  };

  const skin = SKINS.find((s) => s.id === profile.selectedSkin);
  if (skin) {
    applyStatDelta(stats, skin.statBonus);
  }

  for (const nodeId of profile.unlockedNodes) {
    const node = ABILITY_TREE.find((n) => n.id === nodeId);
    if (node) {
      applyStatDelta(stats, node.statDelta);
    }
  }

  // Clamp sensible bounds
  stats.dashCooldown = Math.max(0.55, stats.dashCooldown);
  stats.critChance = clamp(stats.critChance, 0, 0.75);
  return stats;
}

function applyStatDelta(target: PlayerComputedStats, delta: Partial<PlayerComputedStats>): void {
  if (delta.maxHp) target.maxHp += delta.maxHp;
  if (delta.baseDamage) target.baseDamage += delta.baseDamage;
  if (delta.attackSpeed) target.attackSpeed += delta.attackSpeed;
  if (delta.moveSpeed) target.moveSpeed += delta.moveSpeed;
  if (delta.jumpForce) target.jumpForce += delta.jumpForce;
  if (delta.extraJumps) target.extraJumps += delta.extraJumps;
  if (delta.dashCooldown) target.dashCooldown += delta.dashCooldown;
  if (delta.critChance) target.critChance += delta.critChance;
  if (delta.lifestealOnKill) target.lifestealOnKill += delta.lifestealOnKill;
  if (delta.buffDuration) target.buffDuration += delta.buffDuration;
  if (delta.essenceBonus) target.essenceBonus += delta.essenceBonus;
}

export function calculateElementalMultiplier(
  weaponElement: ElementAffinity,
  targetWeakness?: ElementAffinity | null,
  targetResistance?: ElementAffinity | null
): number {
  if (targetWeakness && weaponElement === targetWeakness) {
    return 1.65;
  }
  if (targetResistance && weaponElement === targetResistance) {
    return 0.7;
  }
  return 1.0;
}

export function getWeaponUpgradeCost(currentLevel: number): number {
  return 50 + (currentLevel - 1) * 45;
}

export function getWeaponDamageMultiplier(level: number): number {
  return 1 + (Math.max(1, level) - 1) * 0.22;
}

export function canUnlockAbilityNode(profile: PlayerProfile, nodeId: string): boolean {
  if (profile.unlockedNodes.includes(nodeId)) return false;
  const node = ABILITY_TREE.find((n) => n.id === nodeId);
  if (!node) return false;
  if (node.requires && !profile.unlockedNodes.includes(node.requires)) return false;
  return profile.essence >= node.cost;
}

export function unlockAbilityNode(profile: PlayerProfile, nodeId: string): PlayerProfile {
  if (!canUnlockAbilityNode(profile, nodeId)) return profile;
  const node = ABILITY_TREE.find((n) => n.id === nodeId)!;
  return {
    ...profile,
    essence: profile.essence - node.cost,
    unlockedNodes: [...profile.unlockedNodes, nodeId],
  };
}

export function upgradeWeaponElement(
  profile: PlayerProfile,
  element: ElementAffinity
): PlayerProfile {
  const current = profile.weaponLevels[element] ?? 1;
  if (current >= 5) return profile;
  const cost = getWeaponUpgradeCost(current);
  if (profile.essence < cost) return profile;
  return {
    ...profile,
    essence: profile.essence - cost,
    weaponLevels: {
      ...profile.weaponLevels,
      [element]: current + 1,
    },
  };
}

export function unlockOrSelectSkin(profile: PlayerProfile, skinId: SkinId): PlayerProfile {
  if (profile.unlockedSkins.includes(skinId)) {
    return { ...profile, selectedSkin: skinId };
  }
  const skin = SKINS.find((s) => s.id === skinId);
  if (!skin || profile.essence < skin.cost) return profile;
  return {
    ...profile,
    essence: profile.essence - skin.cost,
    unlockedSkins: [...profile.unlockedSkins, skinId],
    selectedSkin: skinId,
  };
}

export function unlockOrSelectCompanion(
  profile: PlayerProfile,
  companionId: CompanionId
): PlayerProfile {
  if (profile.unlockedCompanions.includes(companionId)) {
    return { ...profile, selectedCompanion: companionId };
  }
  const comp = COMPANIONS.find((c) => c.id === companionId);
  if (!comp || profile.essence < comp.cost) return profile;
  return {
    ...profile,
    essence: profile.essence - comp.cost,
    unlockedCompanions: [...profile.unlockedCompanions, companionId],
    selectedCompanion: companionId,
  };
}

export function getWaveConfig(waveNumber: number, isRaid: boolean): WaveConfig {
  const wave = Math.max(1, Math.floor(waveNumber));
  const isBossWave = wave % 3 === 0;
  const bossRotation: BossId[] = ['ignis_colossus', 'tempest_leviathan', 'abyssal_sovereign'];
  const bossIdx = Math.floor((wave / 3 - 1) % bossRotation.length);
  const bossId = isBossWave ? bossRotation[bossIdx] : null;

  const archetypes: EnemyArchetype[] = ['stalker'];
  if (wave >= 1) archetypes.push('archer');
  if (wave >= 2) archetypes.push('wisp');
  if (wave >= 2) archetypes.push('charger');

  const raidFactor = isRaid ? 1.35 : 1;
  const enemyBudget = isBossWave
    ? Math.round((4 + Math.floor(wave * 0.7)) * raidFactor)
    : wave === 1
    ? Math.round(6 * raidFactor)
    : Math.round((6 + wave * 3) * raidFactor);

  const spawnInterval = wave === 1 ? 1.85 : clamp(1.55 - wave * 0.08, 0.48, 1.55);
  const hpScale = (1 + (wave - 1) * 0.22) * (isRaid ? 1.25 : 1);
  const speedScale = clamp(1 + (wave - 1) * 0.045, 1, 1.55);
  const maxConcurrentAttackers = clamp(2 + Math.floor(wave / 2), 2, 5);
  const hasShrinePuzzle = wave >= 2 && !isBossWave && wave % 2 === 0;

  return {
    wave,
    enemyBudget,
    spawnInterval,
    hpScale,
    speedScale,
    maxConcurrentAttackers,
    archetypes,
    isBossWave,
    bossId,
    hasShrinePuzzle,
  };
}

export function getBossPhase(hp: number, maxHp: number): BossPhase {
  if (maxHp <= 0) return 1;
  const ratio = hp / maxHp;
  if (ratio <= 0.28) return 3;
  if (ratio <= 0.62) return 2;
  return 1;
}

export function selectBossBulletPattern(phase: BossPhase, cycleIndex: number): BulletPattern {
  if (phase === 1) {
    return cycleIndex % 2 === 0 ? 'aimed_fan' : 'radial_ring';
  }
  if (phase === 2) {
    const patterns: BulletPattern[] = ['radial_ring', 'spiral_curtain', 'aimed_fan'];
    return patterns[cycleIndex % patterns.length];
  }
  const enraged: BulletPattern[] = ['spiral_curtain', 'sky_rain', 'radial_ring'];
  return enraged[cycleIndex % enraged.length];
}

export function checkAABB(a: RectBox, b: RectBox): boolean {
  return (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );
}

export function resolveOneWayLanding(
  prevBottom: number,
  nextBottom: number,
  vy: number,
  entityLeft: number,
  entityRight: number,
  platform: RectBox,
  dropThrough: boolean
): boolean {
  if (dropThrough || vy < 0) return false;
  const horizOverlap = entityRight > platform.x + 4 && entityLeft < platform.x + platform.w - 4;
  if (!horizOverlap) return false;
  return prevBottom <= platform.y + 6 && nextBottom >= platform.y;
}

export function calculateRunScore(
  kills: number,
  wave: number,
  bossesDefeated: number,
  puzzlesSolved: number,
  maxCombo: number
): number {
  return Math.round(
    kills * 120 +
      wave * 450 +
      bossesDefeated * 1800 +
      puzzlesSolved * 650 +
      maxCombo * 45
  );
}
