export type GameStatus = 'title' | 'playing' | 'paused' | 'gameover';

export type ElementAffinity = 'fire' | 'frost' | 'volt' | 'void';

export type SkinId = 'ashwalker' | 'cobalt_warden' | 'solaris_vanguard' | 'void_stalker';

export type CompanionId = 'ember_wisp' | 'aegis_drone' | 'chrono_owl';

export type AbilityBranch = 'vanguard' | 'tempest' | 'arcana';

export interface AbilityNodeDef {
  id: string;
  branch: AbilityBranch;
  name: string;
  description: string;
  cost: number;
  requires?: string;
  statDelta: Partial<PlayerComputedStats>;
}

export interface SkinDef {
  id: SkinId;
  name: string;
  title: string;
  cost: number;
  armorPrimary: string;
  armorSecondary: string;
  capeColor: string;
  visorGlow: string;
  bonusLabel: string;
  statBonus: Partial<PlayerComputedStats>;
}

export interface ElementDef {
  id: ElementAffinity;
  name: string;
  weaponName: string;
  role: string;
  color: string;
  glow: string;
  countersLabel: string;
}

export interface CompanionDef {
  id: CompanionId;
  name: string;
  role: string;
  puzzleBonus: string;
  buffDescription: string;
  cost: number;
  color: string;
}

export interface PlayerComputedStats {
  maxHp: number;
  baseDamage: number;
  attackSpeed: number;
  moveSpeed: number;
  jumpForce: number;
  extraJumps: number;
  dashCooldown: number;
  critChance: number;
  lifestealOnKill: number;
  buffDuration: number;
  essenceBonus: number;
}

export interface PlayerProfile {
  callsign: string;
  essence: number;
  bestScore: number;
  bestWave: number;
  unlockedSkins: SkinId[];
  selectedSkin: SkinId;
  unlockedNodes: string[];
  weaponLevels: Record<ElementAffinity, number>;
  activeElement: ElementAffinity;
  unlockedCompanions: CompanionId[];
  selectedCompanion: CompanionId;
}

export type EnemyArchetype = 'stalker' | 'archer' | 'charger' | 'wisp';

export type BossId = 'ignis_colossus' | 'tempest_leviathan' | 'abyssal_sovereign';

export interface BossDef {
  id: BossId;
  name: string;
  subtitle: string;
  weakness: ElementAffinity;
  resistance: ElementAffinity;
  baseHp: number;
  primaryColor: string;
  accentColor: string;
}

export type BossPhase = 1 | 2 | 3;

export type BulletPattern = 'aimed_fan' | 'radial_ring' | 'spiral_curtain' | 'sky_rain';

export interface WaveConfig {
  wave: number;
  enemyBudget: number;
  spawnInterval: number;
  hpScale: number;
  speedScale: number;
  maxConcurrentAttackers: number;
  archetypes: EnemyArchetype[];
  isBossWave: boolean;
  bossId: BossId | null;
  hasShrinePuzzle: boolean;
}

export interface RectBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface PlatformDef extends RectBox {
  oneWay?: boolean;
  label?: string;
}

export type ActiveBuffType = 'overdrive' | 'vampiric' | 'iron_skin' | 'elemental_surge';

export interface HudSnapshot {
  hp: number;
  maxHp: number;
  ghostHp: number;
  score: number;
  combo: number;
  maxCombo: number;
  wave: number;
  enemiesRemaining: number;
  kills: number;
  essenceEarned: number;
  activeElement: ElementAffinity;
  weaponLevel: number;
  dashReadyRatio: number;
  companionReadyRatio: number;
  companionActive: boolean;
  activeBuff: {
    type: ActiveBuffType;
    label: string;
    remaining: number;
    duration: number;
  } | null;
  boss: {
    name: string;
    subtitle: string;
    hp: number;
    maxHp: number;
    phase: BossPhase;
    weakness: ElementAffinity;
    resistance: ElementAffinity;
  } | null;
  shrinePrompt: {
    active: boolean;
    progress: number;
    requiredElement: ElementAffinity;
    solvedCount: number;
  };
  bossesDefeated: number;
  puzzlesSolved: number;
  muted: boolean;
  raidRoomId: string | null;
  raidPlayersCount: number;
}

export interface RunSummary {
  score: number;
  bestScore: number;
  wave: number;
  kills: number;
  bossesDefeated: number;
  puzzlesSolved: number;
  maxCombo: number;
  essenceEarned: number;
  skin: SkinId;
  element: ElementAffinity;
  mode: 'solo' | 'coop';
  durationSec: number;
}

export interface LeaderboardEntry {
  id: string;
  callsign: string;
  score: number;
  wave: number;
  kills: number;
  bossesDefeated: number;
  skin: SkinId;
  element: ElementAffinity;
  mode: 'solo' | 'coop';
  season: string;
  createdAt: string;
}

export interface RaidRoomSummary {
  id: string;
  name: string;
  hostCallsign: string;
  playerCount: number;
  maxPlayers: number;
  wave: number;
  status: 'open' | 'in_combat';
}

export interface RemoteRaiderState {
  clientId: string;
  callsign: string;
  skin: SkinId;
  element: ElementAffinity;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  maxHp: number;
  attacking: boolean;
  dashing: boolean;
  updatedAt: number;
}
