
import React, { useState } from 'react';
import Layout from './components/Layout';
import PlantCard from './components/PlantCard';
import ChatBot from './components/ChatBot';
import { AppSection, PlantCareInfo } from './types';
import { analyzePlantImage } from './services/geminiService';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<AppSection>(AppSection.HOME);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<PlantCareInfo | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset states
    setResult(null);
    setError(null);
    setAnalyzing(true);
    setActiveSection(AppSection.ANALYZE);

    // Create preview
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      setPreviewUrl(base64);
      
      try {
        const base64Clean = base64.split(',')[1];
        const data = await analyzePlantImage(base64Clean);
        setResult(data);
      } catch (err: any) {
        setError(err.message || "Failed to analyze plant");
      } finally {
        setAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const renderHome = () => (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="relative h-64 md:h-80 rounded-3xl overflow-hidden shadow-2xl flex items-center justify-center text-center p-6">
        <img 
          src="https://picsum.photos/seed/garden/800/600" 
          alt="Lush Garden" 
          className="absolute inset-0 w-full h-full object-cover brightness-50" 
        />
        <div className="relative z-10 space-y-4">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight drop-shadow-lg">
            Cultivate Your <span className="text-emerald-400">Paradise</span>
          </h1>
          <p className="text-lg text-emerald-50 max-w-md mx-auto font-medium">
            AI-powered gardening wisdom right in your pocket.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-8 rounded-3xl shadow-lg border border-emerald-100 flex flex-col items-center text-center space-y-4 hover:shadow-xl transition-all">
          <div className="bg-emerald-100 p-4 rounded-full text-emerald-600">
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-slate-800">Identify Plants</h2>
          <p className="text-slate-500 text-sm">Upload a photo to discover species and get custom care guides instantly.</p>
          <label className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-2xl cursor-pointer transition-all shadow-md active:scale-95 text-center block">
            Analyze Photo
            <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
          </label>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-lg border border-emerald-100 flex flex-col items-center text-center space-y-4 hover:shadow-xl transition-all">
          <div className="bg-emerald-100 p-4 rounded-full text-emerald-600">
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-slate-800">Ask FloraGenie</h2>
          <p className="text-slate-500 text-sm">Have gardening questions? Chat with our AI expert about pests, soil, and more.</p>
          <button 
            onClick={() => setActiveSection(AppSection.CHAT)}
            className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 px-6 rounded-2xl transition-all shadow-md active:scale-95"
          >
            Start Chatting
          </button>
        </div>
      </div>

      <section className="space-y-4">
        <h3 className="text-xl font-bold text-slate-800 px-2">Common Indoor Plants</h3>
        <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
          {[
            { name: 'Monstera Deliciosa', img: 'https://picsum.photos/seed/monstera/300/300' },
            { name: 'Snake Plant', img: 'https://picsum.photos/seed/snake/300/300' },
            { name: 'Peace Lily', img: 'https://picsum.photos/seed/lily/300/300' },
            { name: 'Fiddle Leaf Fig', img: 'https://picsum.photos/seed/fiddle/300/300' }
          ].map((plant, i) => (
            <div key={i} className="min-w-[200px] bg-white rounded-2xl p-3 shadow-sm border border-emerald-50">
              <img src={plant.img} className="w-full h-40 object-cover rounded-xl mb-3" />
              <p className="font-bold text-slate-700 text-sm">{plant.name}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );

  const renderAnalyze = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-slate-900">Plant Analysis</h1>
        <label className="text-emerald-600 font-bold text-sm bg-emerald-50 px-4 py-2 rounded-xl cursor-pointer hover:bg-emerald-100 transition-colors">
          Take Another Photo
          <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
        </label>
      </div>

      {!previewUrl && !analyzing && (
        <div className="h-64 border-2 border-dashed border-emerald-200 rounded-3xl flex flex-col items-center justify-center bg-white p-6 text-center space-y-4">
          <svg className="w-12 h-12 text-emerald-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <p className="text-slate-500 font-medium">Snap or upload a photo of your plant to start</p>
          <label className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold cursor-pointer shadow-lg">
            Upload Photo
            <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
          </label>
        </div>
      )}

      {analyzing && (
        <div className="bg-white p-8 rounded-3xl shadow-xl border border-emerald-100 flex flex-col items-center justify-center space-y-6 text-center">
          <div className="relative w-48 h-48 rounded-2xl overflow-hidden shadow-md">
            {previewUrl && <img src={previewUrl} className="w-full h-full object-cover blur-[2px]" />}
            <div className="absolute inset-0 bg-emerald-600/20 flex items-center justify-center">
              <div className="w-full h-1 bg-emerald-400 absolute animate-[scan_2s_linear_infinite]"></div>
            </div>
          </div>
          <style>{`
            @keyframes scan {
              0% { top: 0% }
              50% { top: 100% }
              100% { top: 0% }
            }
          `}</style>
          <div>
            <h3 className="text-xl font-bold text-slate-800">Identifying Species...</h3>
            <p className="text-slate-500 text-sm mt-1">Our AI is consulting the botanical archives.</p>
          </div>
          <div className="flex gap-2">
            <div className="w-2 h-2 bg-emerald-600 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-emerald-600 rounded-full animate-bounce delay-100"></div>
            <div className="w-2 h-2 bg-emerald-600 rounded-full animate-bounce delay-200"></div>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-rose-50 border border-rose-100 p-6 rounded-3xl text-center space-y-4">
          <p className="text-rose-600 font-bold">{error}</p>
          <button 
            onClick={() => setError(null)}
            className="bg-rose-600 text-white px-6 py-2 rounded-xl font-bold text-sm shadow-md"
          >
            Try Again
          </button>
        </div>
      )}

      {result && (
        <PlantCard info={result} imageUrl={previewUrl || undefined} />
      )}
    </div>
  );

  return (
    <Layout activeSection={activeSection} onNavigate={setActiveSection}>
      {activeSection === AppSection.HOME && renderHome()}
      {activeSection === AppSection.ANALYZE && renderAnalyze()}
      {activeSection === AppSection.CHAT && <ChatBot />}
    </Layout>
  );
};

export default App;
