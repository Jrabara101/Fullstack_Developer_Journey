
import React from 'react';
import { PlantCareInfo } from '../types';

interface PlantCardProps {
  info: PlantCareInfo;
  imageUrl?: string;
}

const PlantCard: React.FC<PlantCardProps> = ({ info, imageUrl }) => {
  return (
    <div className="bg-white rounded-3xl overflow-hidden shadow-xl border border-emerald-100 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {imageUrl && (
        <div className="w-full h-56 md:h-72 relative">
          <img src={imageUrl} alt={info.commonName} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
            <div>
              <h2 className="text-2xl font-bold text-white">{info.commonName}</h2>
              <p className="text-emerald-100 italic">{info.scientificName}</p>
            </div>
          </div>
        </div>
      )}
      
      <div className="p-6 space-y-6">
        {!imageUrl && (
          <div>
            <h2 className="text-2xl font-bold text-slate-900">{info.commonName}</h2>
            <p className="text-emerald-600 italic font-medium">{info.scientificName}</p>
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          <Badge color="bg-emerald-100 text-emerald-700" label={info.maintenanceLevel} />
          <Badge color="bg-amber-100 text-amber-700" label={`Toxicity: ${info.toxicity}`} />
        </div>

        <section>
          <h3 className="text-lg font-bold text-slate-800 mb-2">Description</h3>
          <p className="text-slate-600 leading-relaxed">{info.description}</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InfoItem 
            title="Watering" 
            content={info.watering} 
            icon={<path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12c0 4.418-3.582 8-8 8s-8-3.582-8-8 3.582-8 8-8 8 3.582 8 8zM12 7v5l3 3" />}
          />
          <InfoItem 
            title="Sunlight" 
            content={info.sunlight} 
            icon={<path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707" />}
          />
          <InfoItem 
            title="Temperature" 
            content={info.temperature} 
            icon={<path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />}
          />
          <InfoItem 
            title="Soil" 
            content={info.soil} 
            icon={<path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />}
          />
        </div>

        <section className="bg-emerald-50 rounded-2xl p-5 border border-emerald-100">
          <h3 className="text-emerald-900 font-bold mb-3 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Pro Care Tips
          </h3>
          <ul className="space-y-2">
            {info.tips.map((tip, idx) => (
              <li key={idx} className="text-emerald-800 text-sm flex gap-3">
                <span className="shrink-0 font-bold text-emerald-400">•</span>
                {tip}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
};

const Badge: React.FC<{ color: string; label: string }> = ({ color, label }) => (
  <span className={`${color} px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider`}>
    {label}
  </span>
);

const InfoItem: React.FC<{ title: string; content: string; icon: React.ReactNode }> = ({ title, content, icon }) => (
  <div className="flex gap-4 p-3 rounded-xl bg-slate-50 border border-slate-100">
    <div className="w-10 h-10 shrink-0 bg-white rounded-lg flex items-center justify-center text-emerald-600 shadow-sm">
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        {icon}
      </svg>
    </div>
    <div>
      <h4 className="text-sm font-bold text-slate-900 uppercase tracking-tighter opacity-50">{title}</h4>
      <p className="text-slate-700 text-sm">{content}</p>
    </div>
  </div>
);

export default PlantCard;
