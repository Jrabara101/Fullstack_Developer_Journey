
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { PlantCareInfo } from "../types";

const MODEL_NAME = 'gemini-3-pro-preview';

export const analyzePlantImage = async (base64Image: string): Promise<PlantCareInfo> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `Identify this plant from the image and provide detailed care instructions. 
  Respond with a JSON object that strictly follows this schema:
  {
    "scientificName": "...",
    "commonName": "...",
    "description": "A short summary of the plant",
    "watering": "How often and how much water",
    "sunlight": "Lighting requirements",
    "soil": "Best type of soil",
    "temperature": "Optimal temperature range",
    "toxicity": "Safety info for pets/children",
    "maintenanceLevel": "Easy", "Moderate", or "Advanced",
    "tips": ["Tip 1", "Tip 2"]
  }`;

  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: {
      parts: [
        { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          scientificName: { type: Type.STRING },
          commonName: { type: Type.STRING },
          description: { type: Type.STRING },
          watering: { type: Type.STRING },
          sunlight: { type: Type.STRING },
          soil: { type: Type.STRING },
          temperature: { type: Type.STRING },
          toxicity: { type: Type.STRING },
          maintenanceLevel: { type: Type.STRING },
          tips: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["scientificName", "commonName", "description", "watering", "sunlight", "soil", "temperature", "toxicity", "maintenanceLevel", "tips"]
      }
    }
  });

  try {
    const data = JSON.parse(response.text);
    return data as PlantCareInfo;
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    throw new Error("Could not analyze the plant. Please try again with a clearer photo.");
  }
};

export const getChatSession = () => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  return ai.chats.create({
    model: MODEL_NAME,
    config: {
      systemInstruction: "You are FloraGenie, an expert botanist and gardening assistant. Provide helpful, accurate, and encouraging advice about plants, gardening, soil health, and pest control. Keep your tone friendly and professional."
    }
  });
};
