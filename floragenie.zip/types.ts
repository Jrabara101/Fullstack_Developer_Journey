
export interface PlantCareInfo {
  scientificName: string;
  commonName: string;
  description: string;
  watering: string;
  sunlight: string;
  soil: string;
  temperature: string;
  toxicity: string;
  maintenanceLevel: 'Easy' | 'Moderate' | 'Advanced';
  tips: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum AppSection {
  HOME = 'home',
  ANALYZE = 'analyze',
  CHAT = 'chat'
}
