import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Navbar } from './components/layout/Navbar';
import { PortfolioCanvas } from './components/three/PortfolioCanvas';
import { Immersive3DView } from './components/views/Immersive3DView';
import { Classic2DView } from './components/views/Classic2DView';
import { ProjectDetailModal } from './components/modals/ProjectDetailModal';
import { FreeRoamModal } from './components/three/FreeRoamModal';
import { ContactModal } from './components/modals/ContactModal';
import { ResumeModal } from './components/modals/ResumeModal';
import { TelemetryHUD } from './components/telemetry/TelemetryHUD';
import { useTelemetry } from './hooks/useTelemetry';
import { useDeepLink } from './hooks/useDeepLink';
import { CASE_STUDIES, ENGINEER_PROFILE } from './data/portfolioData';
import { CaseStudy, HardwareTier, ViewMode } from './types';
import { 
  Zap, 
  Layers, 
  Smartphone, 
  X, 
  AlertCircle, 
  Sparkles,
  Github,
  Linkedin,
  Mail,
  Heart
} from 'lucide-react';

export default function App() {
  const {
    telemetry,
    currentFps,
    gpuInfo,
    switchMode,
    trackProjectClick,
    trackContactConversion,
    trackResumeDownload,
    trackDeepLinkShare,
    setHardwareTier,
    dismissTouchHint,
    resetTelemetry
  } = useTelemetry();

  const {
    activeSection,
    activeProjectId,
    copiedUrl,
    navigateTo,
    copyShareLink,
    setActiveProjectId
  } = useDeepLink();

  // Modals state
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<CaseStudy | null>(null);
  const [freeRoamCaseStudy, setFreeRoamCaseStudy] = useState<CaseStudy | null>(null);
  const [isContactOpen, setIsContactOpen] = useState<boolean>(false);
  const [isResumeOpen, setIsResumeOpen] = useState<boolean>(false);

  // 3D Canvas Scrollytelling Choreography state
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [activeStationIndex, setActiveStationIndex] = useState<number>(0);
  const [hoveredObjectName, setHoveredObjectName] = useState<string | null>(null);
  const [reducedMotion, setReducedMotion] = useState<boolean>(false);

  // Sync deep link project to modal
  useEffect(() => {
    if (activeProjectId) {
      const found = CASE_STUDIES.find(c => c.id === activeProjectId);
      if (found) {
        setSelectedCaseStudy(found);
        trackProjectClick(found.id);
      }
    }
  }, [activeProjectId, trackProjectClick]);

  // System prefers-reduced-motion check
  useEffect(() => {
    try {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
      setReducedMotion(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    } catch {}
  }, []);

  // Keyboard Shortcuts (2 for 2D, 3 for 3D, Esc for close modals)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === '2') {
        switchMode('2d-classic');
      } else if (e.key === '3') {
        switchMode('3d-immersive');
      } else if (e.key === 'Escape') {
        setSelectedCaseStudy(null);
        setFreeRoamCaseStudy(null);
        setIsContactOpen(false);
        setIsResumeOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [switchMode]);

  // Scroll listener for 3D camera stations
  useEffect(() => {
    if (telemetry.currentMode !== '3d-immersive') return;

    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const current = window.scrollY;
      const progress = totalHeight > 0 ? current / totalHeight : 0;
      setScrollProgress(progress);

      // Map scroll to 6 stations
      // 0: Hero, 1-4: Projects, 5: Architecture/Timeline, 6: Contact
      if (current < 300) {
        setActiveStationIndex(0);
      } else if (current < 1200) {
        setActiveStationIndex(1);
      } else if (current < 2100) {
        setActiveStationIndex(2);
      } else if (current < 3000) {
        setActiveStationIndex(3);
      } else if (current < 3900) {
        setActiveStationIndex(4);
      } else if (current < 4800) {
        setActiveStationIndex(5);
      } else {
        setActiveStationIndex(6);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [telemetry.currentMode]);

  // Modal Handlers
  const handleOpenProject = useCallback((caseStudy: CaseStudy) => {
    setSelectedCaseStudy(caseStudy);
    trackProjectClick(caseStudy.id);
    navigateTo('projects', caseStudy.id);
  }, [trackProjectClick, navigateTo]);

  const handleCloseProject = useCallback(() => {
    setSelectedCaseStudy(null);
    setActiveProjectId(null);
    window.location.hash = 'projects';
  }, [setActiveProjectId]);

  const handleOpenFreeRoam = useCallback((caseStudy: CaseStudy) => {
    setFreeRoamCaseStudy(caseStudy);
  }, []);

  const handleCloseFreeRoam = useCallback(() => {
    setFreeRoamCaseStudy(null);
  }, []);

  const handleShareLink = useCallback((sectionOrProject: string) => {
    copyShareLink(sectionOrProject);
    trackDeepLinkShare();
  }, [copyShareLink, trackDeepLinkShare]);

  const handleNavigate = useCallback((section: string) => {
    navigateTo(section);
    const elem = document.getElementById(section);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  }, [navigateTo]);

  return (
    <div className="relative min-h-screen bg-[#050505] text-[#E0E0E0] flex flex-col font-sans selection:bg-[#00D1FF] selection:text-black overflow-x-hidden">
      
      {/* Elegant Dark Atmospheric Lighting Gradients & Perspective Grid (Non-blocking) */}
      <div className="fixed inset-0 pointer-events-none bg-[radial-gradient(circle_at_50%_25%,#0b1e2c_0%,transparent_60%)] opacity-35 z-0" />
      <div className="fixed bottom-0 w-full h-[280px] pointer-events-none bg-[linear-gradient(to_bottom,transparent,rgba(0,209,255,0.03))] [clip-path:polygon(0_100%,100%_100%,80%_0%,20%_0%)] border-t border-[#00D1FF]/15 z-0" />

      {/* 1. Persistent High-Contrast Dual-Mode Navbar */}
      <Navbar
        currentMode={telemetry.currentMode}
        onToggleMode={switchMode}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenResume={() => setIsResumeOpen(true)}
        hardwareTier={telemetry.hardwareTier}
        onChangeHardwareTier={setHardwareTier}
        reducedMotion={reducedMotion}
        onToggleReducedMotion={() => setReducedMotion(!reducedMotion)}
        onNavigate={handleNavigate}
      />

      {/* 2. Low FPS Alert Banner / Recruiter Fast Switch Affordance */}
      {telemetry.lowFpsFlag && telemetry.currentMode === '3d-immersive' && (
        <div className="fixed top-18 left-0 right-0 z-30 bg-[#0A0A0A]/95 border-b border-[#333] text-[#E0E0E0] px-6 py-2 text-xs font-mono flex items-center justify-between backdrop-blur-md">
          <div className="flex items-center gap-2 max-w-2xl">
            <AlertCircle className="w-4 h-4 text-[#00D1FF] flex-shrink-0" />
            <span className="text-xs">
              Framerate constrained ({currentFps} FPS). Would you like to switch to instant 2D mode?
            </span>
          </div>
          <button
            onClick={() => switchMode('2d-classic')}
            className="px-3 py-1 bg-white text-black font-bold uppercase tracking-wider text-[10px] rounded hover:bg-[#00D1FF] transition-colors whitespace-nowrap ml-2"
          >
            Switch to 2D Mode
          </button>
        </div>
      )}

      {/* 3. Mobile 2-Finger Touch Affordance Hint (Dismissible) */}
      {!telemetry.hasSeenTouchHint && telemetry.currentMode === '3d-immersive' && (
        <div className="sm:hidden fixed bottom-16 left-4 right-4 z-30 bg-[#080808]/95 border border-[#222] text-[#E0E0E0] p-3 rounded-xl flex items-center justify-between text-xs backdrop-blur-md shadow-2xl">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[#00D1FF] flex-shrink-0" />
            <span className="text-[11px] font-mono">1 finger: scroll page • 2 fingers: inspect 3D node</span>
          </div>
          <button
            onClick={dismissTouchHint}
            className="p-1 rounded text-[#666] hover:text-white"
            aria-label="Dismiss touch hint"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 4. Background 3D Spatial Canvas (Rendered only in 3D mode) */}
      {telemetry.currentMode === '3d-immersive' && (
        <PortfolioCanvas
          scrollProgress={scrollProgress}
          activeStationIndex={activeStationIndex}
          hardwareTier={telemetry.hardwareTier}
          reducedMotion={reducedMotion}
          onSelectStation={(stationIdx) => {
            const cs = CASE_STUDIES[stationIdx - 1];
            if (cs) handleOpenProject(cs);
          }}
          onObjectHover={setHoveredObjectName}
        />
      )}

      {/* 5. Semantic HTML Presentation Layer (Visible to SEO, Screen Readers & Users) */}
      <main id="main-content" className="flex-1 w-full relative">
        {telemetry.currentMode === '3d-immersive' ? (
          <Immersive3DView
            onSelectProject={handleOpenProject}
            onOpenFreeRoam={handleOpenFreeRoam}
            onOpenContact={() => setIsContactOpen(true)}
            onOpenResume={() => setIsResumeOpen(true)}
            onShareLink={handleShareLink}
            copiedUrl={copiedUrl}
            activeStationIndex={activeStationIndex}
            hoveredObjectName={hoveredObjectName}
          />
        ) : (
          <Classic2DView
            onSelectProject={handleOpenProject}
            onOpenFreeRoam={handleOpenFreeRoam}
            onOpenContact={() => setIsContactOpen(true)}
            onOpenResume={() => setIsResumeOpen(true)}
            onShareLink={handleShareLink}
            copiedUrl={copiedUrl}
            onSwitchTo3D={() => switchMode('3d-immersive')}
          />
        )}
      </main>

      {/* 6. Recruiter & Performance Telemetry HUD */}
      <TelemetryHUD
        telemetry={telemetry}
        currentFps={currentFps}
        gpuInfo={gpuInfo}
        onReset={resetTelemetry}
        onSelectProject={(pId) => {
          const cs = CASE_STUDIES.find(c => c.id === pId);
          if (cs) handleOpenProject(cs);
        }}
      />

      {/* 7. Comprehensive Case Study Deep Dive Modal */}
      <ProjectDetailModal
        caseStudy={selectedCaseStudy}
        isOpen={!!selectedCaseStudy}
        onClose={handleCloseProject}
        onOpenFreeRoam={handleOpenFreeRoam}
        onShareLink={handleShareLink}
        copiedUrl={copiedUrl}
      />

      {/* 8. 360° Free-Roam / Model Inspection Sandbox Modal */}
      <FreeRoamModal
        caseStudy={freeRoamCaseStudy}
        isOpen={!!freeRoamCaseStudy}
        onClose={handleCloseFreeRoam}
      />

      {/* 9. Direct Contact & Meeting Scheduler Modal */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
        onTrackConversion={trackContactConversion}
      />

      {/* 10. Printable Executive ATS Resume Modal */}
      <ResumeModal
        isOpen={isResumeOpen}
        onClose={() => setIsResumeOpen(false)}
        onTrackDownload={trackResumeDownload}
      />

      {/* 11. Elegant Dark Semantic Footer */}
      <footer className="relative z-10 border-t border-[#1A1A1A] bg-[#050505] py-8 px-4 sm:px-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] font-mono text-[#555] uppercase tracking-widest">
        <div className="flex items-center gap-4">
          <div>SYSTEM STATUS: <span className="text-[#00FF41]">READY</span></div>
          <div className="hidden md:inline">FPS: {currentFps} // GPU: {telemetry.hardwareTier.toUpperCase()}</div>
        </div>

        <div className="flex items-center gap-6 text-[#666]">
          <button 
            onClick={() => switchMode(telemetry.currentMode === '3d-immersive' ? '2d-classic' : '3d-immersive')}
            className="hover:text-white transition-colors"
          >
            {telemetry.currentMode === '3d-immersive' ? '2D VIEW (KEY 2)' : '3D VIEW (KEY 3)'}
          </button>
          <a href={ENGINEER_PROFILE.github} target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
            GITHUB
          </a>
          <a href={ENGINEER_PROFILE.linkedin} target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
            LINKEDIN
          </a>
          <button onClick={() => setIsContactOpen(true)} className="hover:text-[#00D1FF] transition-colors">
            CONTACT
          </button>
        </div>
      </footer>

    </div>
  );
}
