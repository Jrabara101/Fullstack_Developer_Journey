import React from 'react';
import { ViewMode, HardwareTier } from '../../types';
import { ENGINEER_PROFILE } from '../../data/portfolioData';
import { 
  Zap, 
  Layers, 
  FileText, 
  Mail, 
  Calendar, 
  Github, 
  Linkedin, 
  Sparkles, 
  ShieldAlert,
  BatteryCharging,
  Cpu,
  Monitor
} from 'lucide-react';

interface NavbarProps {
  currentMode: ViewMode;
  onToggleMode: (mode: ViewMode) => void;
  onOpenContact: () => void;
  onOpenResume: () => void;
  hardwareTier: HardwareTier;
  onChangeHardwareTier: (tier: HardwareTier) => void;
  reducedMotion: boolean;
  onToggleReducedMotion: () => void;
  onNavigate: (section: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentMode,
  onToggleMode,
  onOpenContact,
  onOpenResume,
  hardwareTier,
  onChangeHardwareTier,
  reducedMotion,
  onToggleReducedMotion,
  onNavigate
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#050505]/80 backdrop-blur-md border-b border-[#1A1A1A] transition-all">
      {/* Skip to Content for screen-readers & quick access */}
      <a
        href="#case-studies-container"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 px-4 py-2 bg-white text-black font-bold uppercase tracking-wider text-xs shadow-lg"
      >
        Skip to Case Studies
      </a>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 h-18 flex items-center justify-between gap-4">
        
        {/* Brand / Name & Status Badge */}
        <div className="flex items-center gap-4 min-w-0">
          <button 
            onClick={() => onNavigate('hero')} 
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="w-8 h-8 rounded-lg bg-[#111] border border-[#333] flex items-center justify-center font-bold text-xs text-white group-hover:border-[#00D1FF] group-hover:text-[#00D1FF] transition-all">
              AR
            </div>
            <div>
              <div className="text-sm font-bold tracking-tighter text-white group-hover:text-[#00D1FF] transition-colors flex items-center gap-1.5">
                <span>ALEX<span className="text-[#00D1FF]">.</span>RIVERA</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#00FF41] animate-pulse" />
              </div>
              <div className="text-[10px] font-mono text-[#666] tracking-widest uppercase line-clamp-1">
                STAFF ARCHITECT
              </div>
            </div>
          </button>

          {/* Availability Tag */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-full bg-[#06140c] border border-[#00FF41]/25 text-[10px] font-mono text-[#00FF41] tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00FF41] animate-ping" />
            <span>Open for Staff / Advisory</span>
          </div>
        </div>

        {/* Center Waypoint Navigation (2D & 3D links) */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium tracking-widest uppercase text-[#777]" aria-label="Main Navigation">
          {[
            { id: 'hero', label: 'Overview' },
            { id: 'projects', label: 'Projects' },
            { id: 'architecture', label: 'Architecture' },
            { id: 'stack', label: 'Tech Stack' },
            { id: 'experience', label: 'Timeline' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right Action Cluster: Mode Switch, Hardware, Resume, Contact */}
        <div className="flex items-center gap-3 sm:gap-4">
          
          {/* PRIMARY REQUIREMENT: DUAL-MODE HIGH-CONTRAST SWITCH */}
          <button
            onClick={() => onToggleMode(currentMode === '3d-immersive' ? '2d-classic' : '3d-immersive')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[10px] font-bold tracking-widest uppercase transition-all ${
              currentMode === '2d-classic'
                ? 'bg-[#00D1FF] text-black hover:bg-white shadow-[0_0_20px_rgba(0,209,255,0.3)]'
                : 'border border-[#333] bg-[#0A0A0A] text-[#E0E0E0] hover:bg-white hover:text-black hover:border-white'
            }`}
            title="Toggle between 3D Spatial Scrollytelling and Instant 2D Recruiter View"
          >
            {currentMode === '3d-immersive' ? (
              <>
                <Zap className="w-3 h-3 fill-current text-[#00D1FF]" />
                <span>2D CLASSIC VIEW</span>
              </>
            ) : (
              <>
                <Layers className="w-3 h-3 fill-current" />
                <span>3D SPATIAL VIEW</span>
              </>
            )}
          </button>

          {/* Hardware Tier Selector */}
          <div className="hidden xl:flex items-center gap-1 bg-[#0A0A0A] border border-[#222] p-1 rounded-lg">
            <button
              onClick={() => onChangeHardwareTier('high')}
              title="High Performance GPU"
              className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                hardwareTier === 'high' ? 'bg-[#1A1A1A] text-[#00D1FF] border border-[#333]' : 'text-[#666] hover:text-[#bbb]'
              }`}
            >
              High
            </button>
            <button
              onClick={() => onChangeHardwareTier('medium')}
              title="Balanced GPU Tier"
              className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                hardwareTier === 'medium' ? 'bg-[#1A1A1A] text-[#E0E0E0] border border-[#333]' : 'text-[#666] hover:text-[#bbb]'
              }`}
            >
              Med
            </button>
            <button
              onClick={() => onChangeHardwareTier('low-battery')}
              title="Low / Battery Saver"
              className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                hardwareTier === 'low-battery' ? 'bg-[#1A1A1A] text-[#00FF41] border border-[#333]' : 'text-[#666] hover:text-[#bbb]'
              }`}
            >
              Eco
            </button>
          </div>

          <div className="hidden sm:block h-4 w-[1px] bg-[#222]"></div>

          {/* Quick Resume Link */}
          <button
            onClick={onOpenResume}
            className="text-xs font-semibold tracking-wider text-[#00D1FF] hover:underline transition-colors uppercase"
          >
            RESUME
          </button>

          {/* Direct Contact Button */}
          <button
            onClick={onOpenContact}
            className="text-xs font-semibold tracking-wider text-white hover:text-[#00D1FF] transition-colors uppercase"
          >
            GET IN TOUCH
          </button>
        </div>
      </div>
    </header>
  );
};
