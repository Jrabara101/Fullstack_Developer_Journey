import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { ENGINEER_PROFILE } from '../../data/portfolioData';
import { 
  X, 
  Copy, 
  Check, 
  Calendar, 
  Mail, 
  Linkedin, 
  Github, 
  MessageSquare, 
  Sparkles,
  Send,
  Clock,
  MapPin
} from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTrackConversion: (type: 'email' | 'linkedin' | 'calendly') => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose, onTrackConversion }) => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [messageSent, setMessageSent] = useState(false);
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    roleOrCompany: '',
    message: ''
  });

  if (!isOpen) return null;

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#00D1FF', '#ffffff', '#00FF41', '#888888']
      });
    } catch {}
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(ENGINEER_PROFILE.email);
    setCopiedEmail(true);
    triggerConfetti();
    onTrackConversion('email');
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleSubmitMessage = (e: React.FormEvent) => {
    e.preventDefault();
    setMessageSent(true);
    triggerConfetti();
    onTrackConversion('email');
    setTimeout(() => {
      setMessageSent(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#000]/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#080808] border border-[#222] rounded-2xl shadow-[0_0_80px_rgba(0,0,0,0.9)] overflow-hidden max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-[#1A1A1A] bg-[#050505] flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse" />
              <span className="font-mono text-[10px] text-[#00FF41] font-bold uppercase tracking-widest">
                DIRECT CONTACT CHANNEL // PRIORITY QUEUE
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
              Let&apos;s Build Systems of <span className="italic font-serif font-normal">Impact.</span>
            </h2>
            <p className="text-xs text-[#888]">
              Available for Staff / Principal Engineer roles, architecture advisory, and high-throughput systems infrastructure.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-[#666] hover:text-white hover:bg-[#151515] transition-colors"
            aria-label="Close contact modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          
          {/* 1-Click Copy Email & Quick Actions Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* Instant Email Card */}
            <div className="p-4 bg-[#050505] border border-[#222] hover:border-[#00D1FF]/40 rounded-xl flex flex-col justify-between space-y-3 transition-colors">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#00D1FF] uppercase tracking-wider font-bold flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5" />
                    Direct Email
                  </span>
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#111] text-[#888] border border-[#222]">
                    Sub-2hr Response
                  </span>
                </div>
                <div className="font-mono text-xs font-bold text-white mt-2 truncate">
                  {ENGINEER_PROFILE.email}
                </div>
              </div>

              <button
                onClick={handleCopyEmail}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-white text-black hover:bg-[#E0E0E0] font-mono text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all shadow-sm"
              >
                {copiedEmail ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#00FF41]" />
                    <span>Copied to Clipboard</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>1-Click Copy Email</span>
                  </>
                )}
              </button>
            </div>

            {/* Direct Calendar Booking */}
            <div className="p-4 bg-[#050505] border border-[#222] hover:border-white/30 rounded-xl flex flex-col justify-between space-y-3 transition-colors">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-white uppercase tracking-wider font-bold flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#00FF41]" />
                    Technical Intro Call
                  </span>
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#111] text-[#888] border border-[#222]">
                    30 Min
                  </span>
                </div>
                <p className="text-xs text-[#888] mt-2 leading-relaxed">
                  Fast-track architectural discussions, team fit, or system advisory.
                </p>
              </div>

              <a
                href={ENGINEER_PROFILE.calendly}
                target="_blank"
                rel="noreferrer"
                onClick={() => onTrackConversion('calendly')}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-[#111] hover:bg-[#1a1a1a] text-white font-mono text-[10px] font-bold uppercase tracking-wider rounded-sm border border-[#333] transition-colors"
              >
                <Calendar className="w-3.5 h-3.5 text-[#00FF41]" />
                <span>Schedule Introduction</span>
              </a>
            </div>
          </div>

          {/* Social / External Links Bar */}
          <div className="flex items-center justify-between p-3 bg-[#050505] border border-[#1A1A1A] rounded-xl text-xs">
            <div className="flex items-center gap-4">
              <a
                href={ENGINEER_PROFILE.linkedin}
                target="_blank"
                rel="noreferrer"
                onClick={() => onTrackConversion('linkedin')}
                className="flex items-center gap-1.5 text-[#888] hover:text-[#00D1FF] transition-colors font-mono text-[11px] uppercase tracking-wider"
              >
                <Linkedin className="w-3.5 h-3.5 text-[#00D1FF]" />
                <span>LinkedIn</span>
              </a>
              <a
                href={ENGINEER_PROFILE.github}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-[#888] hover:text-white transition-colors font-mono text-[11px] uppercase tracking-wider"
              >
                <Github className="w-3.5 h-3.5" />
                <span>GitHub</span>
              </a>
            </div>
            <div className="hidden sm:flex items-center gap-1 text-[#555] font-mono text-[10px] uppercase">
              <MapPin className="w-3.5 h-3.5 text-[#00D1FF]" />
              <span>{ENGINEER_PROFILE.location}</span>
            </div>
          </div>

          {/* Quick Dispatch Form */}
          <form onSubmit={handleSubmitMessage} className="space-y-3 pt-2 border-t border-[#1A1A1A]">
            <div className="text-[10px] font-mono uppercase text-[#00D1FF] font-bold tracking-wider flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-[#00D1FF]" />
              Send Direct Message / Role Brief
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                required
                placeholder="Your Name / Organization"
                value={formState.name}
                onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                className="w-full bg-[#050505] border border-[#222] rounded-lg px-3 py-2 text-xs text-white placeholder-[#555] focus:outline-none focus:border-[#00D1FF] transition-colors font-sans"
              />
              <input
                type="email"
                required
                placeholder="Your Work Email"
                value={formState.email}
                onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                className="w-full bg-[#050505] border border-[#222] rounded-lg px-3 py-2 text-xs text-white placeholder-[#555] focus:outline-none focus:border-[#00D1FF] transition-colors font-sans"
              />
            </div>

            <input
              type="text"
              placeholder="Opportunity (e.g. Staff Architect Role / Real-Time 3D Advisory)"
              value={formState.roleOrCompany}
              onChange={(e) => setFormState({ ...formState, roleOrCompany: e.target.value })}
              className="w-full bg-[#050505] border border-[#222] rounded-lg px-3 py-2 text-xs text-white placeholder-[#555] focus:outline-none focus:border-[#00D1FF] transition-colors font-sans"
            />

            <textarea
              required
              rows={3}
              placeholder="Brief project details, timeline, or interview schedule..."
              value={formState.message}
              onChange={(e) => setFormState({ ...formState, message: e.target.value })}
              className="w-full bg-[#050505] border border-[#222] rounded-lg p-3 text-xs text-white placeholder-[#555] focus:outline-none focus:border-[#00D1FF] transition-colors resize-none font-sans"
            />

            <button
              type="submit"
              disabled={messageSent}
              className="w-full py-2.5 px-4 bg-white hover:bg-[#E0E0E0] disabled:bg-[#00FF41] disabled:text-black text-black font-mono text-[10px] font-bold uppercase tracking-widest rounded-sm flex items-center justify-center gap-2 transition-all shadow-md"
            >
              {messageSent ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Message Dispatched</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Dispatch Message Direct to Alex</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
