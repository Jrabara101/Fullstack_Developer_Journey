import React from 'react';
import { CaseStudy } from '../../types';
import { 
  X, 
  ExternalLink, 
  Github, 
  Share2, 
  Box, 
  CheckCircle2, 
  Cpu, 
  Layers, 
  TrendingUp, 
  ArrowRight,
  ShieldCheck,
  Zap
} from 'lucide-react';

interface ProjectDetailModalProps {
  caseStudy: CaseStudy | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenFreeRoam: (caseStudy: CaseStudy) => void;
  onShareLink: (projectId: string) => void;
  copiedUrl: boolean;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  caseStudy,
  isOpen,
  onClose,
  onOpenFreeRoam,
  onShareLink,
  copiedUrl
}) => {
  if (!isOpen || !caseStudy) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#000]/90 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#080808] border border-[#222] rounded-2xl shadow-[0_0_80px_rgba(0,0,0,0.8)] overflow-hidden my-auto max-h-[92vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-[#1A1A1A] bg-[#050505] flex items-start justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF]">
                {caseStudy.category}
              </span>
              <span className="text-[10px] font-mono text-[#555]">
                {caseStudy.period} • {caseStudy.clientOrOrg}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight">{caseStudy.title}</h2>
            <p className="text-xs sm:text-sm text-[#888] mt-1 leading-relaxed">{caseStudy.tagline}</p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-[#666] hover:text-white hover:bg-[#151515] transition-colors"
            aria-label="Close project modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar (Share, 3D Inspect, Live Demo, GitHub) */}
        <div className="px-6 py-3 bg-[#0c0c0c] border-b border-[#1A1A1A] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenFreeRoam(caseStudy)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white text-black hover:bg-[#E0E0E0] rounded-sm text-[10px] font-mono font-bold uppercase tracking-wider shadow-sm transition-all"
            >
              <Box className="w-3.5 h-3.5" />
              <span>Inspect 3D Geometry</span>
            </button>

            <button
              onClick={() => onShareLink(`project-${caseStudy.id}`)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#151515] hover:bg-[#222] text-[#ccc] border border-[#222] rounded-sm text-[10px] font-mono uppercase tracking-wider transition-colors"
            >
              <Share2 className="w-3.5 h-3.5 text-[#00D1FF]" />
              <span>{copiedUrl ? 'Copied Link!' : 'Share Link'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {caseStudy.githubUrl && (
              <a
                href={caseStudy.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 px-3 py-1.5 bg-[#151515] hover:bg-[#222] text-white border border-[#222] rounded-sm text-[10px] font-mono uppercase tracking-wider transition-colors"
              >
                <Github className="w-3.5 h-3.5" />
                <span>Source</span>
              </a>
            )}
            {caseStudy.liveDemoUrl && (
              <a
                href={caseStudy.liveDemoUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 px-3 py-1.5 bg-[#00D1FF]/10 hover:bg-[#00D1FF]/20 text-[#00D1FF] border border-[#00D1FF]/40 rounded-sm text-[10px] font-mono uppercase tracking-wider transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Live Demo</span>
              </a>
            )}
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          
          {/* Key Business Outcomes & Verified KPIs */}
          <div>
            <h3 className="text-[10px] font-mono uppercase tracking-widest text-[#00D1FF] mb-3 flex items-center gap-1.5 font-bold">
              <TrendingUp className="w-3.5 h-3.5 text-[#00FF41]" />
              Verified Business Outcomes & Metric Impact
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {caseStudy.keyOutcomes.map((kpi, idx) => (
                <div key={idx} className="p-3.5 bg-[#000] border border-[#1A1A1A] rounded-xl">
                  <div className="text-xl font-mono font-bold text-[#00D1FF]">{kpi.value}</div>
                  <div className="text-[10px] uppercase tracking-wider text-[#aaa] mt-0.5">{kpi.label}</div>
                  <div className="text-[9px] text-[#00FF41] font-mono mt-1">{kpi.change}</div>
                </div>
              ))}
            </div>
          </div>

          {/* System Architecture Blueprint */}
          <div className="space-y-4">
            <h3 className="text-[10px] font-mono uppercase tracking-widest text-[#00D1FF] flex items-center gap-1.5 font-bold">
              <Layers className="w-3.5 h-3.5 text-[#00D1FF]" />
              System Architecture & Data Flow
            </h3>
            
            <div className="p-4 bg-[#050505] border border-[#1A1A1A] rounded-xl space-y-3">
              <p className="text-xs text-[#888] leading-relaxed font-sans">
                {caseStudy.systemArchitecture.overview}
              </p>

              {/* Step-by-step pipeline */}
              <div className="space-y-2 pt-2 border-t border-[#1A1A1A]">
                <div className="text-[10px] font-mono text-[#00D1FF] uppercase tracking-wider">Execution Pipeline</div>
                <div className="grid gap-2">
                  {caseStudy.systemArchitecture.flowSteps.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-[#aaa]">
                      <span className="flex-shrink-0 w-5 h-5 rounded-full bg-[#111] border border-[#333] text-[#00D1FF] font-mono text-[10px] flex items-center justify-center font-bold">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed">{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Architecture Components Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {caseStudy.systemArchitecture.components.map((comp, idx) => (
                <div key={idx} className="p-3.5 bg-[#050505] border border-[#1A1A1A] rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white uppercase tracking-wide">{comp.name}</span>
                    <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#111] text-[#00D1FF] border border-[#222]">
                      {comp.latencyOrMetric}
                    </span>
                  </div>
                  <div className="text-xs text-[#888]">{comp.role}</div>
                  <div className="text-[10px] font-mono text-[#555] flex items-center gap-1">
                    <Cpu className="w-3 h-3 text-[#00D1FF]" />
                    {comp.tech}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Trade-offs & Engineering Rationales */}
          <div className="p-4 bg-[#050505] border border-[#333] rounded-xl space-y-2">
            <h4 className="text-[10px] font-mono uppercase tracking-widest text-[#00D1FF] flex items-center gap-1.5 font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00D1FF]" />
              Architectural Trade-offs & Decision Analysis
            </h4>
            <p className="text-xs text-[#888] leading-relaxed">
              {caseStudy.systemArchitecture.tradeOffsAnalyzed}
            </p>
          </div>

          {/* Technical Highlights */}
          <div>
            <h3 className="text-[10px] font-mono uppercase tracking-widest text-[#00D1FF] mb-3 flex items-center gap-1.5 font-bold">
              <Zap className="w-3.5 h-3.5 text-[#00D1FF]" />
              Key Implementation Innovations
            </h3>
            <ul className="space-y-2">
              {caseStudy.technicalHighlights.map((hl, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs text-[#aaa] leading-relaxed">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D1FF] flex-shrink-0 mt-0.5" />
                  <span>{hl}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Technologies Used */}
          <div>
            <h3 className="text-[10px] font-mono uppercase tracking-widest text-[#555] mb-2 font-bold">Technologies & Protocols</h3>
            <div className="flex flex-wrap gap-1.5">
              {caseStudy.techStack.map((tech, idx) => (
                <span key={idx} className="px-2.5 py-1 rounded bg-[#111] border border-[#222] font-mono text-[10px] text-[#bbb]">
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#1A1A1A] bg-[#050505] flex items-center justify-between">
          <div className="text-xs font-mono text-[#555]">
            Role: <span className="text-white">{caseStudy.role}</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-white text-black hover:bg-[#E0E0E0] text-[10px] font-mono font-bold uppercase tracking-widest rounded-sm transition-colors"
          >
            Close Deep Dive
          </button>
        </div>
      </div>
    </div>
  );
};
