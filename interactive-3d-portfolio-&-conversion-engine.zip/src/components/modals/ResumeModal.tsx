import React from 'react';
import { ENGINEER_PROFILE, CASE_STUDIES, WORK_EXPERIENCES, TECH_SKILLS } from '../../data/portfolioData';
import { X, Printer, Download, Mail, MapPin, Globe, ExternalLink, Sparkles } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTrackDownload: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, onTrackDownload }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    onTrackDownload();
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-[#000]/90 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#080808] border border-[#222] rounded-2xl shadow-[0_0_80px_rgba(0,0,0,0.9)] overflow-hidden max-h-[94vh] flex flex-col my-auto">
        
        {/* Top Control Bar */}
        <div className="p-4 border-b border-[#1A1A1A] bg-[#050505] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] text-[#00D1FF] font-bold uppercase tracking-widest">
              ATS-OPTIMIZED EXECUTIVE TECHNICAL RESUME // VERIFIED
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white text-black hover:bg-[#E0E0E0] rounded-sm text-[10px] font-mono font-bold uppercase tracking-wider transition-all shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#666] hover:text-white hover:bg-[#151515] transition-colors"
              aria-label="Close resume modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Resume Sheet */}
        <div className="p-6 sm:p-10 bg-[#050505] text-[#E0E0E0] overflow-y-auto space-y-8 font-sans print:p-0 print:bg-white print:text-black">
          
          {/* Header */}
          <div className="border-b border-[#1A1A1A] pb-6 print:border-black">
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
              <div>
                <h1 className="text-2xl sm:text-3xl font-light text-white tracking-tight print:text-black">
                  {ENGINEER_PROFILE.name}
                </h1>
                <p className="text-sm font-mono text-[#00D1FF] print:text-blue-700 mt-0.5">
                  {ENGINEER_PROFILE.title} ({ENGINEER_PROFILE.level})
                </p>
              </div>
              <div className="font-mono text-[11px] text-[#888] print:text-gray-700 space-y-1 sm:text-right">
                <div>{ENGINEER_PROFILE.location}</div>
                <div>{ENGINEER_PROFILE.email}</div>
                <div>github.com • linkedin.com</div>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-[#888] print:text-gray-800 mt-3 leading-relaxed max-w-3xl font-sans">
              {ENGINEER_PROFILE.tagline} {ENGINEER_PROFILE.bioParagraphs[0]}
            </p>
          </div>

          {/* Core Competencies Matrix */}
          <div>
            <h2 className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF] print:text-blue-800 mb-3">
              Core Technical Competencies
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-[#080808] print:bg-gray-100 rounded-lg border border-[#1A1A1A] print:border-gray-300">
                <span className="font-bold text-white print:text-black font-mono text-[11px] uppercase tracking-wider">Distributed Systems:</span>{' '}
                <span className="text-[#888] print:text-gray-800 text-xs">
                  Rust, Go, C++, gRPC, Raft Consensus, WebTransport, HTTP/3, Zero-Copy I/O, LSM-Trees.
                </span>
              </div>
              <div className="p-3 bg-[#080808] print:bg-gray-100 rounded-lg border border-[#1A1A1A] print:border-gray-300">
                <span className="font-bold text-white print:text-black font-mono text-[11px] uppercase tracking-wider">Graphics & WebGL:</span>{' '}
                <span className="text-[#888] print:text-gray-800 text-xs">
                  Three.js, WebGL, WebGPU, WGSL Compute Shaders, InstancedBufferGeometry, BVH Spatial Culling.
                </span>
              </div>
              <div className="p-3 bg-[#080808] print:bg-gray-100 rounded-lg border border-[#1A1A1A] print:border-gray-300">
                <span className="font-bold text-white print:text-black font-mono text-[11px] uppercase tracking-wider">Cloud Infrastructure:</span>{' '}
                <span className="text-[#888] print:text-gray-800 text-xs">
                  Kubernetes, Envoy, Anycast L4 Ingress, Docker, AWS/GCP Bare-Metal, Prometheus, Grafana.
                </span>
              </div>
              <div className="p-3 bg-[#080808] print:bg-gray-100 rounded-lg border border-[#1A1A1A] print:border-gray-300">
                <span className="font-bold text-white print:text-black font-mono text-[11px] uppercase tracking-wider">Frontend Engine:</span>{' '}
                <span className="text-[#888] print:text-gray-800 text-xs">
                  React 19, Strict TypeScript, Next.js, Tailwind CSS, Web Workers, Canvas APIs, Web Audio.
                </span>
              </div>
            </div>
          </div>

          {/* Professional Work Experience */}
          <div className="space-y-6">
            <h2 className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF] print:text-blue-800">
              Professional Experience & Verified Impact
            </h2>

            {WORK_EXPERIENCES.map((exp) => (
              <div key={exp.id} className="space-y-2 border-l border-[#222] print:border-gray-300 pl-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                  <h3 className="text-sm font-bold text-white print:text-black">
                    {exp.role} — <span className="text-[#00D1FF] print:text-blue-700">{exp.company}</span>
                  </h3>
                  <span className="font-mono text-[11px] text-[#555] print:text-gray-600">{exp.period}</span>
                </div>
                <div className="text-xs font-mono text-[#777] print:text-gray-700">
                  {exp.team} • {exp.location}
                </div>
                <p className="text-xs text-[#888] print:text-gray-800 leading-relaxed font-sans">{exp.summary}</p>
                <ul className="space-y-1.5 pt-1">
                  {exp.verifiedImpact.map((item, idx) => (
                    <li key={idx} className="text-xs text-[#aaa] print:text-gray-800 leading-relaxed list-disc list-inside">
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="flex flex-wrap gap-1 pt-1.5 font-mono text-[10px] text-[#555] print:text-gray-600">
                  <span className="text-[#00D1FF] font-bold">Tech:</span>
                  {exp.technologies.join(' • ')}
                </div>
              </div>
            ))}
          </div>

          {/* Flagship Architectural Case Studies */}
          <div className="space-y-4">
            <h2 className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF] print:text-blue-800">
              Flagship System Architectures & Production Case Studies
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {CASE_STUDIES.map((cs) => (
                <div key={cs.id} className="p-3.5 bg-[#080808] print:bg-gray-100 rounded-xl border border-[#1A1A1A] print:border-gray-300 space-y-2">
                  <div className="font-bold text-xs text-white print:text-black uppercase tracking-wide">{cs.title}</div>
                  <p className="text-xs text-[#888] print:text-gray-700 leading-relaxed font-sans">{cs.summary}</p>
                  <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[10px]">
                    {cs.keyOutcomes.slice(0, 2).map((kpi, idx) => (
                      <div key={idx} className="p-1.5 bg-[#050505] print:bg-white rounded border border-[#1A1A1A] print:border-gray-200">
                        <div className="text-[#00D1FF] print:text-blue-700 font-bold">{kpi.value}</div>
                        <div className="text-[#555] print:text-gray-600">{kpi.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education & Credentials */}
          <div className="border-t border-[#1A1A1A] print:border-black pt-4">
            <h2 className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF] print:text-blue-800 mb-2">
              Education & Honors
            </h2>
            <div className="flex justify-between items-baseline text-xs text-[#aaa] print:text-black">
              <div>
                <span className="font-bold text-white">B.S. in Computer Science & Applied Mathematics</span> — University of California, Berkeley
              </div>
              <span className="font-mono text-[#555] print:text-gray-600 text-[11px]">Honors Graduate</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
