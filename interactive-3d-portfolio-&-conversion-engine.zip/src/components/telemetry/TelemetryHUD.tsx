import React, { useState } from 'react';
import { TelemetryData, HardwareTier } from '../../types';
import { CASE_STUDIES } from '../../data/portfolioData';
import { 
  Activity, 
  ChevronUp, 
  ChevronDown, 
  Eye, 
  Zap, 
  MousePointerClick, 
  AlertTriangle, 
  CheckCircle2, 
  Cpu, 
  RotateCcw,
  Sparkles,
  BarChart2
} from 'lucide-react';

interface TelemetryHUDProps {
  telemetry: TelemetryData;
  currentFps: number;
  gpuInfo: string;
  onReset: () => void;
  onSelectProject: (id: string) => void;
}

export const TelemetryHUD: React.FC<TelemetryHUDProps> = ({
  telemetry,
  currentFps,
  gpuInfo,
  onReset,
  onSelectProject
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Compute conversion metrics
  const totalModeSwitches = telemetry.mode3DCount + telemetry.mode2DCount;
  const pref2DPercentage = totalModeSwitches > 0
    ? Math.round((telemetry.mode2DCount / totalModeSwitches) * 100)
    : 0;
  const pref3DPercentage = 100 - pref2DPercentage;

  const totalProjectClicks: number = (Object.values(telemetry.projectClicks) as number[]).reduce((a: number, b: number) => a + b, 0);
  const totalInteractions = totalProjectClicks + telemetry.contactConversions + telemetry.resumeDownloads;

  return (
    <aside 
      aria-label="Real-time Recruiter & Performance Telemetry HUD" 
      className="fixed bottom-3 right-3 sm:right-6 z-40 max-w-sm sm:max-w-md w-full pointer-events-auto transition-all"
    >
      <div className="bg-[#080808]/95 border border-[#222] backdrop-blur-md rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden">
        
        {/* Minimized Pill Bar */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full px-4 py-2.5 flex items-center justify-between hover:bg-[#111] transition-colors text-left"
          aria-expanded={isExpanded}
        >
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                currentFps >= 50 ? 'bg-[#00FF41]' : (currentFps >= 30 ? 'bg-amber-400' : 'bg-rose-400')
              }`} />
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                currentFps >= 50 ? 'bg-[#00FF41]' : (currentFps >= 30 ? 'bg-amber-500' : 'bg-rose-500')
              }`} />
            </span>
            <div className="font-mono text-xs font-semibold text-white flex items-center gap-2">
              <span className="text-[#00D1FF] uppercase tracking-wider text-[11px]">Telemetry Engine</span>
              <span className="text-[#444]">•</span>
              <span className={`font-mono text-[11px] ${currentFps >= 50 ? 'text-[#00FF41]' : 'text-amber-400'}`}>
                {currentFps} FPS
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 font-mono text-[10px] text-[#666] uppercase tracking-wider">
              <span>2D/3D:</span>
              <span className="text-white font-bold">{pref2DPercentage}%</span> /{' '}
              <span className="text-[#00D1FF] font-bold">{pref3DPercentage}%</span>
            </div>
            {isExpanded ? (
              <ChevronDown className="w-4 h-4 text-[#666]" />
            ) : (
              <ChevronUp className="w-4 h-4 text-[#666]" />
            )}
          </div>
        </button>

        {/* Expanded Telemetry Drawer */}
        {isExpanded && (
          <div className="p-4 border-t border-[#1A1A1A] space-y-4 text-xs font-mono bg-[#050505] max-h-[70vh] overflow-y-auto">
            
            {/* Header info */}
            <div className="flex items-center justify-between text-[#888] pb-2 border-b border-[#1A1A1A]">
              <span className="text-[10px] uppercase tracking-widest text-[#00D1FF] font-bold flex items-center gap-1.5">
                <BarChart2 className="w-3.5 h-3.5" />
                Live Recruiter Funnel Metrics
              </span>
              <button
                onClick={onReset}
                title="Reset session telemetry metrics"
                className="flex items-center gap-1 text-[10px] uppercase text-[#666] hover:text-white transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </button>
            </div>

            {/* 1. 2D vs 3D Preference Split */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-[10px] text-[#888] uppercase tracking-wider">
                <span>View Architecture Preference</span>
                <span className="text-white">{telemetry.timeIn3DSeconds}s 3D / {telemetry.timeIn2DSeconds}s 2D</span>
              </div>
              <div className="h-1.5 w-full bg-[#1A1A1A] rounded-full overflow-hidden flex">
                <div
                  style={{ width: `${pref3DPercentage}%` }}
                  className="bg-[#00D1FF] h-full transition-all"
                  title="Time in 3D Immersive Mode"
                />
                <div
                  style={{ width: `${pref2DPercentage}%` }}
                  className="bg-white h-full transition-all"
                  title="Time in 2D Fast Mode"
                />
              </div>
              <div className="flex justify-between text-[10px] text-[#555]">
                <span className="text-[#00D1FF] font-bold">3D SPATIAL ({pref3DPercentage}%)</span>
                <span className="text-white font-bold">2D CLASSIC ({pref2DPercentage}%)</span>
              </div>
            </div>

            {/* 2. Project CTR breakdown */}
            <div className="space-y-2">
              <div className="text-[10px] text-[#888] uppercase tracking-widest flex items-center justify-between font-bold">
                <span>Case Study Engagement</span>
                <span className="text-[#00D1FF]">{totalProjectClicks} Views</span>
              </div>
              <div className="space-y-1.5">
                {CASE_STUDIES.map((cs) => {
                  const clicks: number = (telemetry.projectClicks[cs.id] || 0) as number;
                  const pct = totalProjectClicks > 0 ? Math.round((clicks / totalProjectClicks) * 100) : 0;
                  return (
                    <div
                      key={cs.id}
                      onClick={() => onSelectProject(cs.id)}
                      className="p-2 bg-[#0A0A0A] hover:bg-[#111] rounded-lg cursor-pointer transition-colors border border-[#1A1A1A]"
                    >
                      <div className="flex justify-between text-[10px] text-white">
                        <span className="truncate max-w-[200px] uppercase">{cs.title.split(':')[0]}</span>
                        <span className="text-[#00D1FF] font-bold font-mono">{clicks} clicks ({pct}%)</span>
                      </div>
                      <div className="mt-1 h-1 w-full bg-[#1A1A1A] rounded-full overflow-hidden">
                        <div style={{ width: `${pct}%` }} className="bg-[#00D1FF] h-full" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 3. Conversion Funnel Triggers */}
            <div className="p-3 bg-[#080808] rounded-xl border border-[#1A1A1A] space-y-2">
              <div className="text-[10px] text-[#00FF41] font-bold uppercase tracking-widest flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Recruiter Conversion Funnel
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                <div className="p-1.5 bg-[#000] rounded border border-[#1A1A1A]">
                  <div className="text-[#666] uppercase text-[9px]">Email Copied</div>
                  <div className="text-sm font-bold text-[#00FF41] font-mono mt-0.5">{telemetry.contactConversions}</div>
                </div>
                <div className="p-1.5 bg-[#000] rounded border border-[#1A1A1A]">
                  <div className="text-[#666] uppercase text-[9px]">Resume View</div>
                  <div className="text-sm font-bold text-[#00D1FF] font-mono mt-0.5">{telemetry.resumeDownloads}</div>
                </div>
                <div className="p-1.5 bg-[#000] rounded border border-[#1A1A1A]">
                  <div className="text-[#666] uppercase text-[9px]">Deep Links</div>
                  <div className="text-sm font-bold text-white font-mono mt-0.5">{telemetry.deepLinkShares}</div>
                </div>
              </div>
            </div>

            {/* 4. GPU & Performance Telemetry */}
            <div className="space-y-1 text-[10px] text-[#555] pt-1 border-t border-[#1A1A1A]">
              <div className="flex items-center justify-between">
                <span className="uppercase">WebGL Context:</span>
                <span className="text-[#888] truncate max-w-[200px]">{gpuInfo}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="uppercase">FPS Budget Status:</span>
                <span className={currentFps >= 45 ? 'text-[#00FF41] font-bold' : 'text-amber-400'}>
                  {currentFps >= 45 ? '60 FPS Target Locked' : 'Throttled / Power Save Active'}
                </span>
              </div>
            </div>

          </div>
        )}

      </div>
    </aside>
  );
};
