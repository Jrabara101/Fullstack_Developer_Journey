import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { CaseStudy } from '../../types';
import { X, RotateCw, Box, Eye, Layers, Sun, Activity, Zap, Sparkles } from 'lucide-react';

interface FreeRoamModalProps {
  caseStudy: CaseStudy | null;
  isOpen: boolean;
  onClose: () => void;
}

export const FreeRoamModal: React.FC<FreeRoamModalProps> = ({ caseStudy, isOpen, onClose }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Inspector UI controls state
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [exploded, setExploded] = useState<boolean>(false);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [rotationSpeed, setRotationSpeed] = useState<number>(0.5);
  const [lightingTheme, setLightingTheme] = useState<'cyan' | 'emerald' | 'studio' | 'amber'>('cyan');
  const [activeTab, setActiveTab] = useState<'controls' | 'telemetry'>('controls');

  // Drag orbit state
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const modelRotation = useRef({ x: 0.2, y: 0 });
  const zoomDist = useRef(5);

  // Mesh stats
  const [stats, setStats] = useState({
    triangles: 2480,
    vertices: 1242,
    drawCalls: 3,
    memoryKB: 142
  });

  useEffect(() => {
    if (!isOpen || !containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, zoomDist.current);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    while (containerRef.current.firstChild) {
      containerRef.current.removeChild(containerRef.current.firstChild);
    }
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting setup
    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambient);

    const light1 = new THREE.DirectionalLight(0x38bdf8, 2.0);
    light1.position.set(5, 5, 5);
    scene.add(light1);

    const light2 = new THREE.PointLight(0x818cf8, 2.5, 10);
    light2.position.set(-4, -4, 4);
    scene.add(light2);

    // Build Detailed 3D Model based on caseStudy
    const modelGroup = new THREE.Group();
    modelGroupRef.current = modelGroup;
    scene.add(modelGroup);

    const geomType = caseStudy?.model3DConfig.geometryType || 'neural-mesh';
    const mainColor = new THREE.Color(caseStudy?.model3DConfig.color || '#06b6d4');
    const secColor = new THREE.Color(caseStudy?.model3DConfig.secondaryColor || '#3b82f6');

    if (geomType === 'neural-mesh') {
      // High-poly Torus Knot + orbital rings + node points
      const geom = new THREE.TorusKnotGeometry(1.2, 0.35, 128, 32);
      const mat = new THREE.MeshStandardMaterial({
        color: mainColor,
        metalness: 0.85,
        roughness: 0.2,
        wireframe: wireframe,
        emissive: mainColor,
        emissiveIntensity: 0.2
      });
      const knot = new THREE.Mesh(geom, mat);
      modelGroup.add(knot);

      // Orbital Rings for exploded view
      const ring1 = new THREE.Mesh(
        new THREE.TorusGeometry(2.2, 0.03, 16, 100),
        new THREE.MeshBasicMaterial({ color: secColor, wireframe: true })
      );
      ring1.name = 'exploded-layer-1';
      modelGroup.add(ring1);

      setStats({ triangles: 4096, vertices: 2048, drawCalls: 2, memoryKB: 180 });
    } else if (geomType === 'edge-db') {
      // Layered DB Tower segments
      for (let i = 0; i < 4; i++) {
        const segGeom = new THREE.CylinderGeometry(1.1 - i * 0.1, 1.2 - i * 0.1, 0.5, 12);
        const segMat = new THREE.MeshStandardMaterial({
          color: i % 2 === 0 ? mainColor : secColor,
          metalness: 0.8,
          roughness: 0.25,
          wireframe: wireframe
        });
        const segMesh = new THREE.Mesh(segGeom, segMat);
        segMesh.position.y = (i - 1.5) * 0.65;
        segMesh.name = `db-tier-${i}`;
        modelGroup.add(segMesh);
      }
      setStats({ triangles: 2880, vertices: 1440, drawCalls: 4, memoryKB: 120 });
    } else if (geomType === 'spatial-iot') {
      // Spatial Polyhedral Lattice + Sub-satellites
      const latticeGeom = new THREE.IcosahedronGeometry(1.4, 2);
      const latticeMat = new THREE.MeshStandardMaterial({
        color: mainColor,
        metalness: 0.9,
        roughness: 0.1,
        wireframe: wireframe
      });
      const lattice = new THREE.Mesh(latticeGeom, latticeMat);
      modelGroup.add(lattice);

      // Sub-satellites
      for (let s = 0; s < 8; s++) {
        const sat = new THREE.Mesh(
          new THREE.BoxGeometry(0.2, 0.2, 0.2),
          new THREE.MeshStandardMaterial({ color: secColor })
        );
        const phi = (s / 8) * Math.PI * 2;
        sat.position.set(Math.cos(phi) * 2.2, Math.sin(phi) * 2.2, Math.sin(phi * 2) * 0.5);
        sat.name = `sat-${s}`;
        modelGroup.add(sat);
      }
      setStats({ triangles: 3640, vertices: 1820, drawCalls: 5, memoryKB: 156 });
    } else {
      // AI Synapse Matrix
      const coreGeom = new THREE.DodecahedronGeometry(1.3, 1);
      const coreMat = new THREE.MeshStandardMaterial({
        color: mainColor,
        metalness: 0.85,
        roughness: 0.15,
        wireframe: wireframe
      });
      const core = new THREE.Mesh(coreGeom, coreMat);
      modelGroup.add(core);

      const halo = new THREE.Mesh(
        new THREE.SphereGeometry(2.0, 16, 16),
        new THREE.MeshBasicMaterial({ color: secColor, wireframe: true, transparent: true, opacity: 0.35 })
      );
      halo.name = 'halo-layer';
      modelGroup.add(halo);
      setStats({ triangles: 3200, vertices: 1600, drawCalls: 2, memoryKB: 140 });
    }

    // Grid Floor
    const gridHelper = new THREE.GridHelper(10, 20, 0x06b6d4, 0x1e293b);
    gridHelper.position.y = -2.2;
    scene.add(gridHelper);

    // Resize
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let clock = new THREE.Clock();
    const animate = () => {
      const delta = clock.getDelta();

      if (autoRotate && !isDraggingRef.current && modelGroupRef.current) {
        modelRotation.current.y += delta * rotationSpeed;
      }

      if (modelGroupRef.current) {
        modelGroupRef.current.rotation.x = modelRotation.current.x;
        modelGroupRef.current.rotation.y = modelRotation.current.y;

        // Exploded View expansion
        modelGroupRef.current.children.forEach((child) => {
          if (child.name.startsWith('db-tier-')) {
            const idx = parseInt(child.name.replace('db-tier-', ''));
            const targetY = exploded ? (idx - 1.5) * 1.2 : (idx - 1.5) * 0.65;
            child.position.y += (targetY - child.position.y) * 0.1;
          } else if (child.name.startsWith('sat-')) {
            const idx = parseInt(child.name.replace('sat-', ''));
            const phi = (idx / 8) * Math.PI * 2;
            const targetDist = exploded ? 3.2 : 2.2;
            const targetX = Math.cos(phi) * targetDist;
            const targetY = Math.sin(phi) * targetDist;
            child.position.x += (targetX - child.position.x) * 0.1;
            child.position.y += (targetY - child.position.y) * 0.1;
          } else if (child.name === 'exploded-layer-1' || child.name === 'halo-layer') {
            const targetScale = exploded ? 1.4 : 1.0;
            child.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
          }
        });
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
    };
  }, [isOpen, caseStudy]);

  // Update wireframe dynamically
  useEffect(() => {
    if (!modelGroupRef.current) return;
    modelGroupRef.current.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mat = (obj as THREE.Mesh).material;
        if (Array.isArray(mat)) {
          mat.forEach(m => (m as any).wireframe = wireframe);
        } else if (mat) {
          (mat as any).wireframe = wireframe;
        }
      }
    });
  }, [wireframe]);

  // Update lighting theme
  useEffect(() => {
    if (!sceneRef.current) return;
    const scene = sceneRef.current;
    scene.children.forEach(child => {
      if ((child as THREE.DirectionalLight).isDirectionalLight) {
        if (lightingTheme === 'cyan') (child as THREE.DirectionalLight).color.setHex(0x38bdf8);
        else if (lightingTheme === 'emerald') (child as THREE.DirectionalLight).color.setHex(0x34d399);
        else if (lightingTheme === 'amber') (child as THREE.DirectionalLight).color.setHex(0xfbbf24);
        else (child as THREE.DirectionalLight).color.setHex(0xffffff);
      }
    });
  }, [lightingTheme]);

  // Drag Orbit Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - prevMousePos.current.x;
    const deltaY = e.clientY - prevMousePos.current.y;

    modelRotation.current.y += deltaX * 0.008;
    modelRotation.current.x += deltaY * 0.008;

    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!cameraRef.current) return;
    zoomDist.current = Math.max(3.0, Math.min(8.5, zoomDist.current + e.deltaY * 0.005));
    cameraRef.current.position.z = zoomDist.current;
  };

  const handleResetCamera = () => {
    modelRotation.current = { x: 0.2, y: 0 };
    zoomDist.current = 5;
    if (cameraRef.current) cameraRef.current.position.set(0, 0, 5);
  };

  if (!isOpen || !caseStudy) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[88vh] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col md:flex-row overflow-hidden">
        
        {/* 3D Canvas Area */}
        <div
          ref={containerRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onWheel={handleWheel}
          className="relative flex-1 h-[55vh] md:h-full cursor-grab active:cursor-grabbing select-none"
        >
          {/* Top Overlaid Tag */}
          <div className="absolute top-4 left-4 z-10 flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-950/70 border border-cyan-500/30 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="font-mono text-xs text-cyan-300 font-medium tracking-wide">
              360° FREE-ROAM SANDBOX
            </span>
          </div>

          {/* Bottom Interaction Hint */}
          <div className="absolute bottom-4 left-4 right-4 z-10 flex justify-between items-center pointer-events-none">
            <div className="font-mono text-[11px] text-slate-400 bg-slate-950/70 px-3 py-1 rounded border border-slate-800 backdrop-blur-sm">
              🖱️ Drag to Orbit • Scroll to Zoom
            </div>
            <button
              onClick={handleResetCamera}
              className="pointer-events-auto flex items-center gap-1 text-xs font-mono text-cyan-300 hover:text-cyan-200 bg-slate-950/80 hover:bg-slate-900 px-3 py-1.5 rounded-lg border border-cyan-500/30 transition-colors"
            >
              <RotateCw className="w-3.5 h-3.5" />
              Reset Orientation
            </button>
          </div>
        </div>

        {/* Control Panel Sidebar */}
        <div className="w-full md:w-80 bg-slate-950/90 border-t md:border-t-0 md:border-l border-slate-800 flex flex-col justify-between overflow-y-auto">
          
          {/* Header */}
          <div className="p-5 border-b border-slate-800 flex items-center justify-between">
            <div>
              <div className="font-mono text-xs text-cyan-400 uppercase tracking-wider">{caseStudy.category}</div>
              <h3 className="text-base font-bold text-slate-100 mt-0.5 line-clamp-1">{caseStudy.title.split(':')[0]}</h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
              aria-label="Close free-roam modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-800 px-5 pt-3 gap-4">
            <button
              onClick={() => setActiveTab('controls')}
              className={`pb-2.5 font-mono text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors ${
                activeTab === 'controls' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Box className="w-3.5 h-3.5" />
              Model Controls
            </button>
            <button
              onClick={() => setActiveTab('telemetry')}
              className={`pb-2.5 font-mono text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors ${
                activeTab === 'telemetry' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              Mesh Metrics
            </button>
          </div>

          {/* Body content */}
          <div className="p-5 space-y-5 flex-1">
            {activeTab === 'controls' ? (
              <>
                {/* Visual Modes */}
                <div className="space-y-2.5">
                  <label className="font-mono text-xs text-slate-400 uppercase tracking-wider">Shader & Wireframe</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setWireframe(!wireframe)}
                      className={`flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-mono font-medium transition-all ${
                        wireframe
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-sm'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {wireframe ? 'Wireframe [ON]' : 'Solid Mesh'}
                    </button>

                    <button
                      onClick={() => setExploded(!exploded)}
                      className={`flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-mono font-medium transition-all ${
                        exploded
                          ? 'bg-purple-500/20 border-purple-400 text-purple-200 shadow-sm'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5" />
                      {exploded ? 'Disassembled' : 'Exploded View'}
                    </button>
                  </div>
                </div>

                {/* Auto Rotate & Speed */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="font-mono text-xs text-slate-400 uppercase tracking-wider">Turntable Rotation</label>
                    <button
                      onClick={() => setAutoRotate(!autoRotate)}
                      className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                        autoRotate ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {autoRotate ? 'ACTIVE' : 'PAUSED'}
                    </button>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="2.0"
                    step="0.1"
                    value={rotationSpeed}
                    disabled={!autoRotate}
                    onChange={(e) => setRotationSpeed(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                  <div className="flex justify-between font-mono text-[10px] text-slate-500">
                    <span>Slow (0.1x)</span>
                    <span>{rotationSpeed}x</span>
                    <span>Fast (2.0x)</span>
                  </div>
                </div>

                {/* Lighting Spectrum */}
                <div className="space-y-2.5">
                  <label className="font-mono text-xs text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    Lighting Profile
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { id: 'cyan', label: 'Cyan', color: 'bg-cyan-500' },
                      { id: 'emerald', label: 'Matrix', color: 'bg-emerald-500' },
                      { id: 'amber', label: 'Amber', color: 'bg-amber-500' },
                      { id: 'studio', label: 'Studio', color: 'bg-slate-200' }
                    ].map((t) => (
                      <button
                        key={t.id}
                        onClick={() => setLightingTheme(t.id as any)}
                        className={`flex flex-col items-center gap-1 p-2 rounded-lg border text-[11px] font-mono transition-all ${
                          lightingTheme === t.id
                            ? 'border-cyan-400 bg-slate-900 text-slate-100'
                            : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:bg-slate-900'
                        }`}
                      >
                        <span className={`w-3.5 h-3.5 rounded-full ${t.color}`} />
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="space-y-4">
                <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">Total Triangles:</span>
                    <span className="font-bold text-cyan-300">{stats.triangles.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">Vertex Count:</span>
                    <span className="font-bold text-cyan-300">{stats.vertices.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">GPU Draw Calls:</span>
                    <span className="font-bold text-emerald-400">{stats.drawCalls}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">VRAM Geometry:</span>
                    <span className="font-bold text-purple-300">{stats.memoryKB} KB</span>
                  </div>
                </div>

                <div className="p-3 bg-cyan-950/30 border border-cyan-800/40 rounded-xl text-xs text-cyan-200/90 space-y-1">
                  <div className="font-semibold flex items-center gap-1 text-cyan-300">
                    <Sparkles className="w-3.5 h-3.5" />
                    Zero-Asset Procedural Mesh
                  </div>
                  <p className="text-[11px] text-cyan-400/80 leading-relaxed">
                    This geometry is generated on-the-fly via mathematical buffer attributes, resulting in 0 KB network payload download.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Footer actions */}
          <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
            <span className="font-mono text-[11px] text-slate-400">
              Station #{caseStudy.model3DConfig.stationIndex + 1}
            </span>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
            >
              Done Inspecting
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
