import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { HardwareTier } from '../../types';
import { CASE_STUDIES } from '../../data/portfolioData';

interface PortfolioCanvasProps {
  scrollProgress: number;
  activeStationIndex: number;
  hardwareTier: HardwareTier;
  reducedMotion: boolean;
  onSelectStation?: (index: number) => void;
  onObjectHover?: (hoveredName: string | null) => void;
}

export const PortfolioCanvas: React.FC<PortfolioCanvasProps> = ({
  scrollProgress,
  activeStationIndex,
  hardwareTier,
  reducedMotion,
  onSelectStation,
  onObjectHover
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  
  // Interactive nodes container
  const interactiveObjectsRef = useRef<THREE.Object3D[]>([]);
  const hoveredObjectRef = useRef<THREE.Object3D | null>(null);
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2(-1000, -1000));
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());

  // Mouse parallax
  const targetMouseParallax = useRef({ x: 0, y: 0 });
  const currentMouseParallax = useRef({ x: 0, y: 0 });

  // Camera choreographing targets
  const cameraPositions = [
    new THREE.Vector3(0, 0, 8),      // Hero: Center core
    new THREE.Vector3(-4.5, 0.5, 6), // Station 0: AetherFlow
    new THREE.Vector3(4.5, 1.2, 5.5),// Station 1: HyperScale DB
    new THREE.Vector3(-4.2, -1.0, 5),// Station 2: OmniMesh
    new THREE.Vector3(4.2, -0.5, 5.8),// Station 3: Krypton Agent
    new THREE.Vector3(0, -3.5, 7),   // Timeline / Chronometer
    new THREE.Vector3(0, 0, 6.5)     // Contact Transmitter
  ];

  const cameraLookAts = [
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(-3.2, 0.2, 0),
    new THREE.Vector3(3.2, 0.8, 0),
    new THREE.Vector3(-3.0, -0.8, 0),
    new THREE.Vector3(3.0, -0.4, 0),
    new THREE.Vector3(0, -2.5, 0),
    new THREE.Vector3(0, 0, 0)
  ];

  const currentCamPos = useRef(new THREE.Vector3(0, 0, 8));
  const currentLookAt = useRef(new THREE.Vector3(0, 0, 0));

  // Station objects references for animation
  const stationsGroupRef = useRef<THREE.Group[]>([]);
  const corePolyhedronRef = useRef<THREE.Mesh | null>(null);
  const coreRingsRef = useRef<THREE.Group | null>(null);
  const particleMatrixRef = useRef<THREE.Points | null>(null);

  // Setup Three.js Scene
  useEffect(() => {
    if (!containerRef.current || hardwareTier === 'low-battery') return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030712, 0.045);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 8);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: hardwareTier === 'high',
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, hardwareTier === 'high' ? 2 : 1.25));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    
    // Clear container
    while (containerRef.current.firstChild) {
      containerRef.current.removeChild(containerRef.current.firstChild);
    }
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, hardwareTier === 'high' ? 0.9 : 1.2);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 2.5);
    dirLight1.position.set(5, 8, 5);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x818cf8, 1.8);
    dirLight2.position.set(-5, -5, 3);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0x06b6d4, 3.0, 15);
    pointLight.position.set(0, 0, 2);
    scene.add(pointLight);

    // 1. Central Hero Cyber Core
    const heroGroup = new THREE.Group();
    const icosaGeom = new THREE.IcosahedronGeometry(1.6, 1);
    const icosaMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      metalness: 0.85,
      roughness: 0.15,
      wireframe: false,
      emissive: 0x0369a1,
      emissiveIntensity: 0.35
    });
    const coreMesh = new THREE.Mesh(icosaGeom, icosaMat);
    coreMesh.name = 'Core System Engine';
    heroGroup.add(coreMesh);
    corePolyhedronRef.current = coreMesh;
    interactiveObjectsRef.current.push(coreMesh);

    // Core Wireframe Cage
    const wireGeom = new THREE.IcosahedronGeometry(1.8, 1);
    const wireMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.3
    });
    const wireMesh = new THREE.Mesh(wireGeom, wireMat);
    heroGroup.add(wireMesh);

    // Orbital Rings
    const ringsGroup = new THREE.Group();
    const ring1Geom = new THREE.TorusGeometry(2.3, 0.02, 16, 100);
    const ring1Mat = new THREE.MeshBasicMaterial({ color: 0x06b6d4, transparent: true, opacity: 0.6 });
    const ring1 = new THREE.Mesh(ring1Geom, ring1Mat);
    ring1.rotation.x = Math.PI / 3;
    ringsGroup.add(ring1);

    const ring2Geom = new THREE.TorusGeometry(2.6, 0.02, 16, 100);
    const ring2Mat = new THREE.MeshBasicMaterial({ color: 0x818cf8, transparent: true, opacity: 0.5 });
    const ring2 = new THREE.Mesh(ring2Geom, ring2Mat);
    ring2.rotation.y = Math.PI / 4;
    ring2.rotation.x = -Math.PI / 6;
    ringsGroup.add(ring2);

    heroGroup.add(ringsGroup);
    coreRingsRef.current = ringsGroup;
    scene.add(heroGroup);

    // 2. Background Particle Matrix
    const particleCount = hardwareTier === 'high' ? 1800 : (hardwareTier === 'medium' ? 900 : 300);
    const particleGeom = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 35;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 35;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 20;

      const pColor = new THREE.Color();
      const rand = Math.random();
      if (rand < 0.33) pColor.setHex(0x38bdf8);
      else if (rand < 0.66) pColor.setHex(0x818cf8);
      else pColor.setHex(0x10b981);

      colors[i * 3] = pColor.r;
      colors[i * 3 + 1] = pColor.g;
      colors[i * 3 + 2] = pColor.b;
    }

    particleGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeom.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.06,
      vertexColors: true,
      transparent: true,
      opacity: 0.65
    });
    const particlePoints = new THREE.Points(particleGeom, particleMat);
    scene.add(particlePoints);
    particleMatrixRef.current = particlePoints;

    // 3. Project Stations (4 Stations)
    const stations: THREE.Group[] = [];

    // Station 0: AetherFlow (Neural Streamer Torus Knot & Audio Wave Rings)
    const st0 = new THREE.Group();
    st0.position.set(-3.2, 0.2, 0);
    const knotGeom = new THREE.TorusKnotGeometry(1.0, 0.25, 100, 16);
    const knotMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      metalness: 0.9,
      roughness: 0.2,
      emissive: 0x0891b2,
      emissiveIntensity: 0.4
    });
    const knotMesh = new THREE.Mesh(knotGeom, knotMat);
    knotMesh.name = CASE_STUDIES[0].title;
    (knotMesh as any).stationIndex = 0;
    st0.add(knotMesh);
    interactiveObjectsRef.current.push(knotMesh);
    scene.add(st0);
    stations.push(st0);

    // Station 1: HyperScale DB (Multi-Tier Crystalline Storage Tower)
    const st1 = new THREE.Group();
    st1.position.set(3.2, 0.8, 0);
    const towerGeom = new THREE.CylinderGeometry(0.9, 1.1, 2.2, 8, 4);
    const towerMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      metalness: 0.7,
      roughness: 0.2,
      wireframe: false,
      emissive: 0x059669,
      emissiveIntensity: 0.45
    });
    const towerMesh = new THREE.Mesh(towerGeom, towerMat);
    towerMesh.name = CASE_STUDIES[1].title;
    (towerMesh as any).stationIndex = 1;
    st1.add(towerMesh);

    // Glowing DB Disk Rings
    for (let r = 0; r < 3; r++) {
      const ringGeom = new THREE.TorusGeometry(1.3 + r * 0.15, 0.02, 12, 40);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x34d399, transparent: true, opacity: 0.7 });
      const ring = new THREE.Mesh(ringGeom, ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = -0.6 + r * 0.6;
      st1.add(ring);
    }
    interactiveObjectsRef.current.push(towerMesh);
    scene.add(st1);
    stations.push(st1);

    // Station 2: OmniMesh (Spatial City / Digital Twin Lattice Grid)
    const st2 = new THREE.Group();
    st2.position.set(-3.0, -0.8, 0);
    const latticeGeom = new THREE.OctahedronGeometry(1.4, 2);
    const latticeMat = new THREE.MeshStandardMaterial({
      color: 0x8b5cf6,
      metalness: 0.8,
      roughness: 0.15,
      wireframe: true,
      emissive: 0x7c3aed,
      emissiveIntensity: 0.6
    });
    const latticeMesh = new THREE.Mesh(latticeGeom, latticeMat);
    latticeMesh.name = CASE_STUDIES[2].title;
    (latticeMesh as any).stationIndex = 2;
    st2.add(latticeMesh);

    // Center glowing core orb
    const centerOrb = new THREE.Mesh(
      new THREE.SphereGeometry(0.6, 24, 24),
      new THREE.MeshStandardMaterial({ color: 0xec4899, emissive: 0xdb2777, emissiveIntensity: 0.7 })
    );
    st2.add(centerOrb);
    interactiveObjectsRef.current.push(latticeMesh);
    scene.add(st2);
    stations.push(st2);

    // Station 3: Krypton AI Agent Gateway (Synaptic Matrix Sphere)
    const st3 = new THREE.Group();
    st3.position.set(3.0, -0.4, 0);
    const synGeom = new THREE.DodecahedronGeometry(1.3, 1);
    const synMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.9,
      roughness: 0.2,
      emissive: 0xd97706,
      emissiveIntensity: 0.5
    });
    const synMesh = new THREE.Mesh(synGeom, synMat);
    synMesh.name = CASE_STUDIES[3].title;
    (synMesh as any).stationIndex = 3;
    st3.add(synMesh);

    // Pulsing outer orbiters
    const orbiterGeom = new THREE.SphereGeometry(0.12, 12, 12);
    const orbiterMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });
    for (let k = 0; k < 6; k++) {
      const orbiter = new THREE.Mesh(orbiterGeom, orbiterMat);
      const angle = (k / 6) * Math.PI * 2;
      orbiter.position.set(Math.cos(angle) * 1.8, Math.sin(angle) * 1.8, (k % 2 === 0 ? 0.3 : -0.3));
      st3.add(orbiter);
    }
    interactiveObjectsRef.current.push(synMesh);
    scene.add(st3);
    stations.push(st3);

    stationsGroupRef.current = stations;

    // Handle Window Resize
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Tab Inactive Visibility Handler (Requirement 4: Tab Background Suspension)
    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (animFrameIdRef.current) {
          cancelAnimationFrame(animFrameIdRef.current);
          animFrameIdRef.current = null;
        }
      } else {
        if (!animFrameIdRef.current) {
          animFrameIdRef.current = requestAnimationFrame(animateLoop);
        }
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Main Render Loop
    let clock = new THREE.Clock();
    const animateLoop = () => {
      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Smooth mouse parallax lerp
      currentMouseParallax.current.x += (targetMouseParallax.current.x - currentMouseParallax.current.x) * 0.05;
      currentMouseParallax.current.y += (targetMouseParallax.current.y - currentMouseParallax.current.y) * 0.05;

      // Animate core polyhedron and rings
      if (corePolyhedronRef.current) {
        corePolyhedronRef.current.rotation.x += delta * 0.25;
        corePolyhedronRef.current.rotation.y += delta * 0.35;
      }
      if (coreRingsRef.current) {
        coreRingsRef.current.rotation.z += delta * 0.2;
        coreRingsRef.current.rotation.y -= delta * 0.15;
      }

      // Animate Particle Matrix
      if (particleMatrixRef.current) {
        particleMatrixRef.current.rotation.y = elapsed * 0.03;
      }

      // Animate Stations
      stations.forEach((st, idx) => {
        st.rotation.y += delta * (0.3 + idx * 0.1);
        st.position.y += Math.sin(elapsed * 1.5 + idx) * 0.001;
      });

      // Camera position interpolation based on activeStationIndex or scroll
      const targetPos = cameraPositions[activeStationIndex] || cameraPositions[0];
      const targetLook = cameraLookAts[activeStationIndex] || cameraLookAts[0];

      const lerpSpeed = reducedMotion ? 0.08 : 0.04;
      currentCamPos.current.lerp(targetPos, lerpSpeed);
      currentLookAt.current.lerp(targetLook, lerpSpeed);

      if (cameraRef.current) {
        cameraRef.current.position.set(
          currentCamPos.current.x + (reducedMotion ? 0 : currentMouseParallax.current.x * 0.6),
          currentCamPos.current.y + (reducedMotion ? 0 : currentMouseParallax.current.y * 0.4),
          currentCamPos.current.z
        );
        cameraRef.current.lookAt(currentLookAt.current);
      }

      // Raycasting for interactive hover feedback
      if (cameraRef.current && mouseRef.current.x !== -1000) {
        raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
        const intersects = raycasterRef.current.intersectObjects(interactiveObjectsRef.current, true);

        if (intersects.length > 0) {
          const topHit = intersects[0].object;
          if (hoveredObjectRef.current !== topHit) {
            // Reset previous
            if (hoveredObjectRef.current && (hoveredObjectRef.current as THREE.Mesh).material) {
              const mat = (hoveredObjectRef.current as THREE.Mesh).material as THREE.MeshStandardMaterial;
              if (mat.emissiveIntensity) mat.emissiveIntensity = 0.4;
            }
            // Highlight current
            hoveredObjectRef.current = topHit;
            const mat = (topHit as THREE.Mesh).material as THREE.MeshStandardMaterial;
            if (mat && mat.emissiveIntensity) mat.emissiveIntensity = 1.0;

            if (onObjectHover) onObjectHover(topHit.name || 'Station Component');
            if (containerRef.current) containerRef.current.style.cursor = 'pointer';
          }
        } else {
          if (hoveredObjectRef.current) {
            if ((hoveredObjectRef.current as THREE.Mesh).material) {
              const mat = (hoveredObjectRef.current as THREE.Mesh).material as THREE.MeshStandardMaterial;
              if (mat.emissiveIntensity) mat.emissiveIntensity = 0.4;
            }
            hoveredObjectRef.current = null;
            if (onObjectHover) onObjectHover(null);
            if (containerRef.current) containerRef.current.style.cursor = 'default';
          }
        }
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }

      animFrameIdRef.current = requestAnimationFrame(animateLoop);
    };

    animFrameIdRef.current = requestAnimationFrame(animateLoop);

    return () => {
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      renderer.dispose();
    };
  }, [hardwareTier, reducedMotion, activeStationIndex]);

  // Mouse move handler for parallax and hover raycast
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    mouseRef.current.set(x, y);
    targetMouseParallax.current = { x: x * 1.2, y: y * 0.8 };
  }, []);

  const handleMouseLeave = useCallback(() => {
    mouseRef.current.set(-1000, -1000);
    targetMouseParallax.current = { x: 0, y: 0 };
    if (onObjectHover) onObjectHover(null);
  }, [onObjectHover]);

  // Click on 3D objects
  const handleClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!cameraRef.current || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);
    const intersects = raycaster.intersectObjects(interactiveObjectsRef.current, true);

    if (intersects.length > 0) {
      const topObj = intersects[0].object as any;
      if (topObj.stationIndex !== undefined && onSelectStation) {
        onSelectStation(topObj.stationIndex + 1);
      }
    }
  }, [onSelectStation]);

  // Requirement 3: 1-finger mobile scroll pass-through; 2-finger touch orbit
  const touchStartRef = useRef<{ y: number; count: number }>({ y: 0, count: 0 });

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartRef.current = {
      y: e.touches[0].clientY,
      count: e.touches.length
    };
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      // 2-finger manipulation - rotate slightly
      const touchA = e.touches[0];
      const touchB = e.touches[1];
      const midX = (touchA.clientX + touchB.clientX) / 2;
      const rect = containerRef.current?.getBoundingClientRect();
      if (rect) {
        const normX = ((midX - rect.left) / rect.width) * 2 - 1;
        targetMouseParallax.current.x = normX * 2.0;
      }
    }
  };

  if (hardwareTier === 'low-battery') {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-slate-950/90 pointer-events-none z-0">
        <div className="relative w-full h-full opacity-40 flex items-center justify-center">
          <div className="w-72 h-72 rounded-full border border-cyan-500/30 border-dashed animate-spin" style={{ animationDuration: '40s' }} />
          <div className="absolute w-48 h-48 rounded-full border border-indigo-500/40" />
          <div className="absolute font-mono text-xs text-cyan-400/80 px-3 py-1 bg-slate-900/80 rounded border border-cyan-500/20">
            [Battery Saver Mode — Canvas Suspended (0% GPU)]
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      id="threejs-spatial-canvas-container"
      aria-hidden="true"
      role="presentation"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={handleClick}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      className="fixed inset-0 w-full h-full pointer-events-auto z-0 select-none touch-pan-y"
    />
  );
};
