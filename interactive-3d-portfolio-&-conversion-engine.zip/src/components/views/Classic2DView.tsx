import React, { useState } from 'react';
import { CaseStudy } from '../../types';
import { 
  ENGINEER_PROFILE, 
  CASE_STUDIES, 
  TECH_SKILLS, 
  WORK_EXPERIENCES, 
  TESTIMONIALS 
} from '../../data/portfolioData';
import { 
  Zap, 
  FileText, 
  Mail, 
  Calendar, 
  Github, 
  Linkedin, 
  ExternalLink, 
  ArrowRight, 
  CheckCircle2, 
  Share2, 
  TrendingUp, 
  Cpu, 
  Server, 
  Layers, 
  Box,
  Copy,
  Check,
  Search,
  Printer
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Classic2DViewProps {
  onSelectProject: (caseStudy: CaseStudy) => void;
  onOpenFreeRoam: (caseStudy: CaseStudy) => void;
  onOpenContact: () => void;
  onOpenResume: () => void;
  onShareLink: (sectionOrProject: string) => void;
  copiedUrl: boolean;
  onSwitchTo3D: () => void;
}

export const Classic2DView: React.FC<Classic2DViewProps> = ({
  onSelectProject,
  onOpenFreeRoam,
  onOpenContact,
  onOpenResume,
  onShareLink,
  copiedUrl,
  onSwitchTo3D
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copiedEmail, setCopiedEmail] = useState(false);

  const categories = ['All', 'Distributed Systems', 'Edge Cloud', 'Graphics & Web3D', 'AI Infrastructure'];

  const filteredCaseStudies = selectedCategory === 'All'
    ? CASE_STUDIES
    : CASE_STUDIES.filter(cs => cs.category === selectedCategory);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(ENGINEER_PROFILE.email);
    setCopiedEmail(true);
    try {
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.5 } });
    } catch {}
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  return (
    <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-8 pt-16 pb-32 space-y-16">
      
      {/* 1. RECRUITER 5-SECOND SCAN BANNER & EXECUTIVE SUMMARY */}
      <section className="bg-[#080808]/90 border border-[#222] rounded-2xl p-6 sm:p-10 shadow-2xl space-y-6">
        
        {/* Top Affirmation Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-[#1A1A1A]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse" />
            <span className="font-mono text-[10px] text-[#00FF41] font-bold uppercase tracking-widest">
              INSTANT 2D RECRUITER VIEW // ZERO GPU OVERHEAD
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onSwitchTo3D}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#111] hover:bg-[#1a1a1a] text-[#00D1FF] border border-[#333] hover:border-[#00D1FF] rounded text-[10px] font-mono uppercase tracking-wider transition-colors"
            >
              <Box className="w-3.5 h-3.5" />
              <span>Switch to 3D</span>
            </button>

            <button
              onClick={onOpenResume}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white text-black hover:bg-[#E0E0E0] rounded text-[10px] font-mono font-bold uppercase tracking-wider transition-colors shadow-sm"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Print Resume</span>
            </button>
          </div>
        </div>

        {/* Profile Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          <div className="lg:col-span-2 space-y-4">
            <div>
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
                Executive Profile
              </span>
              <h1 className="text-3xl sm:text-5xl font-light tracking-tight text-white mt-1">
                {ENGINEER_PROFILE.name}
              </h1>
              <div className="text-xs font-mono text-[#888] uppercase tracking-wider mt-1">
                {ENGINEER_PROFILE.title} <span className="text-[#00D1FF]">({ENGINEER_PROFILE.level})</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#999] leading-relaxed font-sans">
              {ENGINEER_PROFILE.tagline} {ENGINEER_PROFILE.bioParagraphs[0]}
            </p>

            {/* Direct Contact Links */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={handleCopyEmail}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-[#111] hover:bg-[#1a1a1a] text-white border border-[#222] rounded text-[10px] font-mono uppercase tracking-wider transition-colors"
              >
                {copiedEmail ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#00FF41]" />
                    <span className="text-[#00FF41]">Email Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-[#00D1FF]" />
                    <span>Copy Email: {ENGINEER_PROFILE.email}</span>
                  </>
                )}
              </button>

              <button
                onClick={onOpenContact}
                className="flex items-center gap-1.5 px-4 py-2 bg-white text-black hover:bg-[#E0E0E0] rounded text-[10px] font-mono font-bold uppercase tracking-widest transition-colors shadow-sm"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book 30-Min Intro Call</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 gap-3 p-4 bg-[#000] border border-[#1A1A1A] rounded-xl">
            {ENGINEER_PROFILE.coreMetrics.map((m, idx) => (
              <div key={idx} className="space-y-0.5">
                <div className="text-lg font-bold text-[#00D1FF] font-mono">{m.value}</div>
                <div className="text-[10px] uppercase tracking-wider text-[#E0E0E0]">{m.label}</div>
                <div className="text-[9px] text-[#666] font-mono">{m.detail}</div>
              </div>
            ))}
          </div>

        </div>

      </section>

      {/* 2. CASE STUDIES DIRECTORY WITH CATEGORY FILTER */}
      <section id="case-studies-container" aria-label="Case Studies Directory" className="space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
              Engineering Blueprints
            </span>
            <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
              Architectural Case Studies & <span className="italic font-serif font-normal">Impact.</span>
            </h2>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1 bg-[#000] border border-[#1A1A1A] p-1 rounded-lg">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded text-[10px] font-mono uppercase tracking-wider transition-colors ${
                  selectedCategory === cat
                    ? 'bg-white text-black font-bold'
                    : 'text-[#666] hover:text-white hover:bg-[#111]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column Dense Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredCaseStudies.map((cs) => (
            <article
              key={cs.id}
              id={`project-${cs.id}`}
              className="p-6 bg-[#080808]/90 border border-[#222] hover:border-[#00D1FF]/40 rounded-xl shadow-lg space-y-4 flex flex-col justify-between transition-all"
            >
              <div className="space-y-3">
                
                {/* Category & Deep Link Share */}
                <div className="flex items-center justify-between pb-2 border-b border-[#1A1A1A]">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF]">
                    {cs.category}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-[#555]">{cs.period}</span>
                    <button
                      onClick={() => onShareLink(`project-${cs.id}`)}
                      className="p-1 rounded text-[#555] hover:text-white"
                      title="Copy Deep Link"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Title & Tagline */}
                <div>
                  <h3 
                    onClick={() => onSelectProject(cs)}
                    className="text-xl font-light text-white hover:text-[#00D1FF] cursor-pointer transition-colors tracking-tight"
                  >
                    {cs.title}
                  </h3>
                  <p className="text-xs text-[#888] mt-1 leading-relaxed">{cs.tagline}</p>
                </div>

                {/* KPIs Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  {cs.keyOutcomes.map((kpi, idx) => (
                    <div key={idx} className="p-2.5 bg-[#000] border border-[#1A1A1A] rounded-lg">
                      <div className="text-base font-bold text-[#00D1FF] font-mono">{kpi.value}</div>
                      <div className="text-[9px] uppercase tracking-wider text-[#777]">{kpi.label}</div>
                    </div>
                  ))}
                </div>

                {/* Technical Highlights list */}
                <ul className="space-y-1 pt-1">
                  {cs.technicalHighlights.slice(0, 2).map((hl, idx) => (
                    <li key={idx} className="text-xs text-[#999] flex items-start gap-1.5 leading-relaxed">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#00D1FF] flex-shrink-0 mt-0.5" />
                      <span>{hl}</span>
                    </li>
                  ))}
                </ul>

                {/* Tech pills */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {cs.techStack.map((tech, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded bg-[#111] border border-[#222] font-mono text-[9px] text-[#aaa]">
                      {tech}
                    </span>
                  ))}
                </div>

              </div>

              {/* Bottom Card Actions */}
              <div className="pt-4 border-t border-[#1A1A1A] flex items-center justify-between gap-2">
                <button
                  onClick={() => onSelectProject(cs)}
                  className="flex items-center gap-1.5 text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF] hover:text-white transition-colors"
                >
                  <span>Read Deep Dive</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onOpenFreeRoam(cs)}
                  className="flex items-center gap-1 px-2.5 py-1 bg-[#111] hover:bg-[#1a1a1a] text-[#aaa] hover:text-white border border-[#222] rounded text-[10px] font-mono uppercase tracking-wider transition-colors"
                >
                  <Box className="w-3 h-3 text-[#00D1FF]" />
                  <span>3D Inspect</span>
                </button>
              </div>

            </article>
          ))}
        </div>
      </section>

      {/* 3. TECHNICAL RADAR & CORE STACK */}
      <section id="stack" aria-label="Technical Radar" className="space-y-6">
        <div className="space-y-1">
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
            Technical Competencies
          </span>
          <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
            Core Technical Capabilities
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {TECH_SKILLS.map((skill, idx) => (
            <div key={idx} className="p-4 bg-[#080808]/90 border border-[#1A1A1A] hover:border-[#333] rounded-xl space-y-2 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#00D1FF] font-bold uppercase tracking-wider">{skill.category}</span>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#111] text-[#666] border border-[#222]">
                  {skill.years} YRS
                </span>
              </div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wide">{skill.name}</h3>
              <p className="text-xs text-[#888] leading-relaxed">{skill.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. VERIFIED CAREER TIMELINE */}
      <section id="experience" aria-label="Employment Timeline" className="space-y-6">
        <div className="space-y-1">
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
            Work History
          </span>
          <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
            Career Timeline & Leadership
          </h2>
        </div>

        <div className="space-y-4">
          {WORK_EXPERIENCES.map((exp) => (
            <div key={exp.id} className="p-6 bg-[#080808]/90 border border-[#1A1A1A] hover:border-[#333] rounded-xl space-y-3 transition-colors">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <h3 className="text-sm sm:text-base font-bold text-white uppercase tracking-wider">
                  {exp.role} — <span className="text-[#00D1FF]">{exp.company}</span>
                </h3>
                <span className="font-mono text-[11px] text-[#666]">{exp.period}</span>
              </div>
              <div className="text-[11px] text-[#555] font-mono">{exp.team} • {exp.location}</div>
              <p className="text-xs sm:text-sm text-[#999] leading-relaxed">{exp.summary}</p>
              <ul className="space-y-1 pt-1">
                {exp.verifiedImpact.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-[#aaa] leading-relaxed">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00D1FF] flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
