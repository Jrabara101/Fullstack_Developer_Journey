import React from 'react';
import { CaseStudy, TechSkill } from '../../types';
import { 
  ENGINEER_PROFILE, 
  CASE_STUDIES, 
  TECH_SKILLS, 
  WORK_EXPERIENCES, 
  TESTIMONIALS 
} from '../../data/portfolioData';
import { 
  Box, 
  ExternalLink, 
  ArrowRight, 
  Cpu, 
  Layers, 
  TrendingUp, 
  CheckCircle2, 
  Share2, 
  Terminal, 
  Server, 
  Activity, 
  Sparkles,
  Calendar,
  Mail,
  FileText,
  Quote,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';

interface Immersive3DViewProps {
  onSelectProject: (caseStudy: CaseStudy) => void;
  onOpenFreeRoam: (caseStudy: CaseStudy) => void;
  onOpenContact: () => void;
  onOpenResume: () => void;
  onShareLink: (sectionOrProject: string) => void;
  copiedUrl: boolean;
  activeStationIndex: number;
  hoveredObjectName: string | null;
}

export const Immersive3DView: React.FC<Immersive3DViewProps> = ({
  onSelectProject,
  onOpenFreeRoam,
  onOpenContact,
  onOpenResume,
  onShareLink,
  copiedUrl,
  activeStationIndex,
  hoveredObjectName
}) => {
  return (
    <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-8 pt-16 pb-32 space-y-32">
      
      {/* 1. HERO SECTION (Waypoint 0) */}
      <section id="hero" aria-label="Hero Overview" className="min-h-[82vh] flex flex-col justify-center max-w-3xl">
        
        {/* Hover feedback tag if user hovers 3D object */}
        {hoveredObjectName && (
          <div className="mb-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#081824] border border-[#00D1FF]/40 text-[#00D1FF] text-[10px] font-mono animate-in fade-in">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00D1FF] animate-ping" />
            <span>NODE ACTIVE // {hoveredObjectName.toUpperCase()}</span>
          </div>
        )}

        <div className="space-y-2 mb-6">
          <span className="text-[10px] uppercase tracking-[0.3em] text-[#00D1FF] font-bold">
            Staff Systems & 3D Web Architect
          </span>
          <h1 className="text-5xl sm:text-7xl font-light tracking-tight text-white leading-[0.95]">
            CREATING DIGITAL <span className="italic font-serif font-normal text-white">GRAVITY.</span>
          </h1>
        </div>

        <p className="text-sm text-[#888] leading-relaxed max-w-[540px] font-sans">
          {ENGINEER_PROFILE.tagline} {ENGINEER_PROFILE.bioParagraphs[0]}
        </p>

        {/* Hero Call to Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 mt-8">
          <a
            href="#projects"
            className="bg-white text-black px-6 py-3 text-[11px] font-bold uppercase tracking-widest hover:bg-[#E0E0E0] transition-colors rounded-none sm:rounded-sm flex items-center gap-2 shadow-sm"
          >
            <span>Explore Work</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>

          <button
            onClick={onOpenResume}
            className="border border-[#333] text-white px-6 py-3 text-[11px] font-bold uppercase tracking-widest hover:border-white transition-colors rounded-none sm:rounded-sm flex items-center gap-2 bg-[#080808]"
          >
            <FileText className="w-3.5 h-3.5 text-[#00D1FF]" />
            <span>Resume</span>
          </button>

          <button
            onClick={onOpenContact}
            className="border border-[#333] text-[#00D1FF] px-6 py-3 text-[11px] font-bold uppercase tracking-widest hover:border-[#00D1FF] hover:bg-[#00D1FF]/10 transition-colors rounded-none sm:rounded-sm flex items-center gap-2 bg-[#080808]"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Get in Touch</span>
          </button>
        </div>

        {/* Core Metrics Banner */}
        <div className="mt-10 pt-8 border-t border-[#1A1A1A] flex flex-wrap gap-8 sm:gap-12">
          <div className="flex flex-col">
            <span className="text-[10px] text-[#555] uppercase tracking-wider mb-1">Experience</span>
            <span className="text-xl font-mono text-white font-bold">10+ YRS</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-[#555] uppercase tracking-wider mb-1">Peak Throughput</span>
            <span className="text-xl font-mono text-white font-bold">1.2M RPS</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-[#555] uppercase tracking-wider mb-1">Frame Budget</span>
            <span className="text-xl font-mono text-white font-bold">60 FPS</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-[#555] uppercase tracking-wider mb-1">Location</span>
            <span className="text-xl font-mono text-white font-bold">SAN FRANCISCO</span>
          </div>
        </div>

        <div className="flex items-center gap-2 mt-12 text-[#555] font-mono text-[10px] uppercase tracking-widest">
          <ChevronDown className="w-3.5 h-3.5 animate-bounce text-[#00D1FF]" />
          <span>Scroll to navigate through spatial stations</span>
        </div>
      </section>

      {/* 2. CHOREOGRAPHED 3D CASE STUDIES (Waypoints 1 - 4) */}
      <section id="projects" aria-label="Flagship Projects" className="space-y-24">
        <div className="max-w-2xl space-y-2">
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
            Waypoints #01 — #04
          </span>
          <h2 className="text-3xl sm:text-4xl font-light text-white tracking-tight">
            Production Case Studies & <span className="italic font-serif font-normal">Architectural Grid.</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#888] leading-relaxed">
            Each 3D station represents an active production system designed for extreme scale, low latency, and zero-jank frame budgets.
          </p>
        </div>

        {/* Case Studies Stations List */}
        <div id="case-studies-container" className="space-y-28">
          {CASE_STUDIES.map((cs, index) => {
            const isEven = index % 2 === 0;
            return (
              <article
                key={cs.id}
                id={`project-${cs.id}`}
                className={`relative flex flex-col lg:flex-row items-center gap-8 p-6 sm:p-8 rounded-2xl bg-[#080808]/90 border border-[#222] hover:border-[#00D1FF]/40 backdrop-blur-md shadow-[0_0_50px_rgba(0,209,255,0.04)] transition-all ${
                  activeStationIndex === index + 1 ? 'ring-1 ring-[#00D1FF] border-[#00D1FF]/60' : ''
                }`}
              >
                {/* Station Card Content */}
                <div className={`w-full lg:w-3/5 space-y-5 ${isEven ? 'order-1' : 'order-1 lg:order-2'}`}>
                  
                  {/* Category & Status */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#1A1A1A]">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-[#FF5F56]" />
                      <span className="text-[10px] text-[#555] font-mono uppercase tracking-wider">
                        NODE_00{index + 1} // ACTIVE
                      </span>
                      <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#00D1FF]">
                        {cs.category}
                      </span>
                    </div>

                    <button
                      onClick={() => onShareLink(`project-${cs.id}`)}
                      className="p-1 rounded text-[#555] hover:text-white transition-colors"
                      title="Copy deep link"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Title & Tagline */}
                  <div>
                    <h3 
                      onClick={() => onSelectProject(cs)}
                      className="text-2xl sm:text-3xl font-light text-white hover:text-[#00D1FF] cursor-pointer transition-colors tracking-tight"
                    >
                      {cs.title}
                    </h3>
                    <p className="text-xs text-[#888] mt-1 leading-relaxed font-sans">
                      {cs.tagline}
                    </p>
                  </div>

                  {/* Summary */}
                  <p className="text-xs text-[#999] leading-relaxed">
                    {cs.summary}
                  </p>

                  {/* Verified Outcomes Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                    {cs.keyOutcomes.map((kpi, kIdx) => (
                      <div key={kIdx} className="p-3 bg-[#000] border border-[#1A1A1A] rounded-lg">
                        <div className="text-base sm:text-lg font-mono font-bold text-[#00D1FF]">{kpi.value}</div>
                        <div className="text-[10px] uppercase text-[#666] tracking-wider mt-0.5">{kpi.label}</div>
                        <div className="text-[9px] font-mono text-[#00FF41] mt-0.5">{kpi.change}</div>
                      </div>
                    ))}
                  </div>

                  {/* Tech stack pills */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {cs.techStack.map((tech, tIdx) => (
                      <span key={tIdx} className="px-2.5 py-1 rounded bg-[#111] border border-[#222] font-mono text-[10px] text-[#aaa]">
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center gap-3 pt-3">
                    <button
                      onClick={() => onSelectProject(cs)}
                      className="bg-white text-black hover:bg-[#E0E0E0] px-4 py-2.5 text-[10px] font-bold uppercase tracking-widest transition-all rounded-sm flex items-center gap-1.5 shadow-sm"
                    >
                      <span>Read System Deep Dive</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onOpenFreeRoam(cs)}
                      className="border border-[#333] hover:border-white text-white px-4 py-2.5 text-[10px] font-bold uppercase tracking-widest transition-all rounded-sm flex items-center gap-1.5 bg-[#0A0A0A]"
                    >
                      <Box className="w-3.5 h-3.5 text-[#00D1FF]" />
                      <span>3D Inspect</span>
                    </button>
                  </div>

                </div>

                {/* Station Visual Preview Badge */}
                <div className={`w-full lg:w-2/5 flex flex-col items-center justify-center p-8 bg-[#000] border border-[#1A1A1A] rounded-xl ${isEven ? 'order-2' : 'order-2 lg:order-1'}`}>
                  <div className="text-center space-y-3">
                    <div className="w-16 h-16 rounded-xl bg-[#080808] border border-[#333] flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(0,209,255,0.1)]">
                      <Box className="w-7 h-7 text-[#00D1FF] animate-pulse-subtle" />
                    </div>
                    <div className="font-mono text-[11px] text-white font-bold uppercase tracking-widest">
                      Station #0{index + 1} Synchronized
                    </div>
                    <p className="text-[10px] text-[#666] max-w-xs leading-relaxed font-mono">
                      WebGL camera actively tracks this node in the spatial viewport.
                    </p>
                    <button
                      onClick={() => onOpenFreeRoam(cs)}
                      className="px-3 py-1.5 bg-[#0C0C0C] hover:bg-[#151515] text-[#00D1FF] border border-[#333] hover:border-[#00D1FF] rounded text-[10px] font-mono uppercase tracking-wider transition-colors"
                    >
                      Launch 360° Orbit
                    </button>
                  </div>
                </div>

              </article>
            );
          })}
        </div>
      </section>

      {/* 3. SYSTEM ARCHITECTURE KIOSK */}
      <section id="architecture" aria-label="System Architecture Patterns" className="space-y-8 max-w-5xl">
        <div className="space-y-1">
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
            Engineering Principles
          </span>
          <h2 className="text-3xl font-light text-white tracking-tight">
            Zero-Jank Graphics & <span className="italic font-serif font-normal">Distributed Consensus.</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#888] leading-relaxed">
            How I architect production software across browser compute shaders, distributed Raft consensus, and sub-100ms API gateways.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-6 bg-[#080808]/90 border border-[#1A1A1A] hover:border-[#333] rounded-xl space-y-3 transition-colors">
            <div className="w-9 h-9 rounded-lg bg-[#111] border border-[#222] flex items-center justify-center text-[#00D1FF] font-bold">
              <Activity className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">16.6ms GPU Budget</h3>
            <p className="text-xs text-[#888] leading-relaxed">
              Every frame is mathematically allocated: InstancedBufferGeometry batches 80k items into 1 draw call, while Web Workers handle BVH spatial indexing off the main thread.
            </p>
          </div>

          <div className="p-6 bg-[#080808]/90 border border-[#1A1A1A] hover:border-[#333] rounded-xl space-y-3 transition-colors">
            <div className="w-9 h-9 rounded-lg bg-[#111] border border-[#222] flex items-center justify-center text-[#00FF41] font-bold">
              <Server className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Zero-Copy Telemetry</h3>
            <p className="text-xs text-[#888] leading-relaxed">
              Replacing bulky JSON payloads with tight protobuf / flatbuffer binaries unpacked directly into WebGL ArrayBuffers via WebTransport datagrams.
            </p>
          </div>

          <div className="p-6 bg-[#080808]/90 border border-[#1A1A1A] hover:border-[#333] rounded-xl space-y-3 transition-colors">
            <div className="w-9 h-9 rounded-lg bg-[#111] border border-[#222] flex items-center justify-center text-purple-400 font-bold">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Graceful Degradation</h3>
            <p className="text-xs text-[#888] leading-relaxed">
              Adaptive hardware tiering automatically drops non-essential particle passes, throttles draw loops during inactive tabs, and falls back to clean 2D primitives.
            </p>
          </div>
        </div>
      </section>

      {/* 4. INTERACTIVE TECH MATRIX */}
      <section id="stack" aria-label="Technical Skills Matrix" className="space-y-8">
        <div className="space-y-1">
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
            Technical Competencies
          </span>
          <h2 className="text-3xl font-light text-white tracking-tight">
            Spatial Radar & <span className="italic font-serif font-normal">Systems Matrix.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {TECH_SKILLS.map((skill, idx) => (
            <div key={idx} className="p-4 bg-[#080808]/90 border border-[#1A1A1A] hover:border-[#333] rounded-xl space-y-2.5 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#00D1FF] font-bold uppercase tracking-wider">{skill.category}</span>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#111] text-[#666] border border-[#222]">
                  {skill.years} YRS
                </span>
              </div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wide">{skill.name}</h3>
              <p className="text-xs text-[#888] leading-relaxed">{skill.description}</p>
              <div className="pt-2 border-t border-[#1A1A1A] font-mono text-[10px] text-[#555]">
                Proven in: <span className="text-[#bbb]">{skill.featuredProject}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. CAREER TIMELINE & VERIFIED IMPACT */}
      <section id="experience" aria-label="Work Experience" className="space-y-8 max-w-4xl">
        <div className="space-y-1">
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
            Career Trajectory
          </span>
          <h2 className="text-3xl font-light text-white tracking-tight">
            Engineering Leadership & <span className="italic font-serif font-normal">Impact.</span>
          </h2>
        </div>

        <div className="space-y-4">
          {WORK_EXPERIENCES.map((exp) => (
            <div key={exp.id} className="p-6 bg-[#080808]/90 border border-[#1A1A1A] hover:border-[#333] rounded-xl space-y-3 transition-colors">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <h3 className="text-sm sm:text-base font-bold text-white uppercase tracking-wider">
                  {exp.role} <span className="text-[#00D1FF]">@ {exp.company}</span>
                </h3>
                <span className="font-mono text-[11px] text-[#666]">{exp.period}</span>
              </div>
              <div className="text-[11px] font-mono text-[#555]">{exp.team} • {exp.location}</div>
              <p className="text-xs text-[#999] leading-relaxed">{exp.summary}</p>
              <ul className="space-y-1 pt-1">
                {exp.verifiedImpact.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-[#aaa] leading-relaxed">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00D1FF] flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* 6. TESTIMONIALS */}
      <section aria-label="Executive Recommendations" className="space-y-8 max-w-4xl">
        <div className="space-y-1">
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#00D1FF] font-bold">
            Peer Endorsements
          </span>
          <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
            Executive <span className="italic font-serif font-normal">Perspectives.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {TESTIMONIALS.map((t) => (
            <div key={t.id} className="p-5 bg-[#080808]/90 border border-[#1A1A1A] rounded-xl flex flex-col justify-between space-y-4">
              <Quote className="w-5 h-5 text-[#00D1FF]/40" />
              <p className="text-xs text-[#888] leading-relaxed italic">
                &ldquo;{t.quote}&rdquo;
              </p>
              <div className="pt-2 border-t border-[#1A1A1A]">
                <div className="text-xs font-bold text-white">{t.author}</div>
                <div className="text-[10px] text-[#00D1FF] font-mono">{t.role}, {t.company}</div>
                <div className="text-[9px] text-[#555] font-mono">{t.relationship}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. CONVERSION / DIRECT CONTACT STATION (Waypoint 6) */}
      <section id="contact" aria-label="Direct Contact Station" className="p-8 sm:p-12 bg-[#080808] border border-[#222] rounded-2xl text-center max-w-3xl mx-auto space-y-6 shadow-[0_0_80px_rgba(0,209,255,0.06)]">
        <div className="w-10 h-10 rounded-lg bg-[#111] border border-[#333] flex items-center justify-center mx-auto text-[#00D1FF]">
          <Mail className="w-5 h-5" />
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
            Let&apos;s Build Systems That Define Your <span className="italic font-serif font-normal">Industry.</span>
          </h2>
          <p className="text-xs text-[#888] max-w-lg mx-auto leading-relaxed">
            Directly available for Staff / Principal Architecture roles, real-time 3D advisory, and high-throughput systems infrastructure.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={onOpenContact}
            className="bg-white text-black px-6 py-3 text-[11px] font-bold uppercase tracking-widest hover:bg-[#E0E0E0] transition-colors rounded-sm flex items-center gap-2 shadow-sm"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Open Direct Contact Desk</span>
          </button>

          <button
            onClick={onOpenResume}
            className="border border-[#333] hover:border-white text-white px-5 py-3 text-[11px] font-bold uppercase tracking-widest transition-colors rounded-sm flex items-center gap-2 bg-[#0A0A0A]"
          >
            <FileText className="w-3.5 h-3.5 text-[#00D1FF]" />
            <span>View Full Resume</span>
          </button>
        </div>

        <div className="font-mono text-xs text-[#666]">
          Direct: <span className="text-[#E0E0E0]">{ENGINEER_PROFILE.email}</span>
        </div>
      </section>

    </div>
  );
};
