import { CaseStudy, TechSkill, WorkExperience, Testimonial } from '../types';

export const ENGINEER_PROFILE = {
  name: 'Alex Rivera',
  title: 'Staff Systems & 3D Web Architect',
  level: 'Staff / Principal Level',
  tagline: 'Bridging distributed cloud systems, high-throughput pipelines, and 60 FPS spatial web graphics.',
  location: 'San Francisco, CA & Remote',
  status: 'Open to Select Staff / Lead Roles & High-Impact Consulting',
  email: 'alex.rivera.systems@gmail.com',
  github: 'https://github.com',
  linkedin: 'https://linkedin.com',
  calendly: 'https://cal.com',
  coreMetrics: [
    { label: 'p99 Global Latency', value: '38ms', detail: 'Edge-routed WebSockets' },
    { label: 'Data Egress Reduction', value: '45%', detail: '$4.2M cloud savings' },
    { label: 'Frame Budget Reliability', value: '60 FPS', detail: 'Zero jank across 100k nodes' },
    { label: 'Production Scale', value: '2.4M', detail: 'Peak concurrent streams' }
  ],
  bioParagraphs: [
    'With 11+ years across high-throughput distributed systems and real-time GPU/WebGL engines, I design systems where sub-second latency and mathematical render fidelity are non-negotiable requirements.',
    'Previously architected the distributed streaming mesh at CloudScale, reduced enterprise ingest pipelines by 70%, and built real-time digital twin spatial engines handling 80,000 live telemetry nodes at 60 FPS on mobile web.'
  ]
};

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'aether-flow',
    title: 'AetherFlow: Distributed Real-Time Neural Streamer',
    tagline: 'High-throughput WebGPU / WebGL audio-visual streaming pipeline scaling to 2.4M concurrent sessions.',
    clientOrOrg: 'CloudScale Technologies',
    category: 'Distributed Systems',
    period: '2024 - 2025',
    role: 'Lead Architect & Principal Engineer',
    summary: 'Engineered a decentralized edge-relay mesh that dynamically encodes spatial telemetry and neural audio streams directly to client browser GPU compute passes.',
    keyOutcomes: [
      { label: 'Concurrent Edge Streams', value: '2.4M', change: '+320% vs legacy' },
      { label: 'Cloud Egress Cost', value: '-45%', change: '$350k/mo saved' },
      { label: 'Time-to-First-Frame', value: '110ms', change: '75% reduction' },
      { label: 'Client GPU Overhead', value: '< 8%', change: 'Optimized compute pass' }
    ],
    techStack: ['Go / gRPC', 'WebGPU / WGSL', 'Rust Core', 'QUIC / WebTransport', 'Kubernetes', 'Prometheus'],
    systemArchitecture: {
      overview: 'Geo-distributed Anycast ingress routes WebTransport UDP streams into edge Rust relay nodes, decoding delta packets directly onto client WebGPU compute pipelines.',
      flowSteps: [
        'Client connects via HTTP/3 WebTransport to nearest Anycast POP.',
        'Rust edge proxy performs zero-copy packet aggregation and delta compression.',
        'Decentralized Redis cluster coordinates real-time state pub/sub with sub-5ms heartbeat.',
        'Client GPU executes WGSL compute shaders to unpack compressed matrix buffers directly into frame memory.'
      ],
      components: [
        { name: 'Anycast Gateway', role: 'Global L4 Ingress & TLS Termination', tech: 'Envoy / eBPF', latencyOrMetric: '< 12ms p50' },
        { name: 'Stream Multiplexer', role: 'Zero-copy binary delta streaming', tech: 'Rust / Tokio', latencyOrMetric: '1.2 GB/s throughput' },
        { name: 'State Coordinator', role: 'Ephemeral session presence mesh', tech: 'Go / gRPC / Raft', latencyOrMetric: '150k ops/sec' },
        { name: 'Spatial Render Engine', role: 'Compute shader unpacking & render', tech: 'WebGPU / WGSL', latencyOrMetric: '16.6ms locked 60fps' }
      ],
      tradeOffsAnalyzed: 'Chose raw WebTransport over WebRTC DataChannels to avoid SDP renegotiation bottlenecks during rapid cellular cell handovers; implemented client-side packet interpolation to gracefully handle 4% packet drop.'
    },
    technicalHighlights: [
      'Implemented custom binary serialization reducing telemetry payload from 1.8KB to 84 bytes per delta.',
      'Designed adaptive bit-rate backpressure algorithm mitigating buffer bloat across unreliable mobile uplinks.',
      'Engineered multi-threaded Web Workers for off-screen canvas rendering, maintaining 60 FPS even under heavy DOM load.'
    ],
    liveDemoUrl: 'https://example.com/demo/aetherflow',
    githubUrl: 'https://github.com/example/aetherflow-core',
    model3DConfig: {
      stationIndex: 0,
      color: '#06b6d4',
      secondaryColor: '#3b82f6',
      geometryType: 'neural-mesh',
      particleCount: 1200
    }
  },
  {
    id: 'hyperscale-db',
    title: 'HyperScale: Multi-Tenant Low-Latency Edge Database',
    tagline: 'Distributed Raft-consensus key-value store with Wasm embedded query engine for localized microservices.',
    clientOrOrg: 'Vortex Cloud Infrastructure',
    category: 'Edge Cloud',
    period: '2023 - 2024',
    role: 'Principal Systems Engineer',
    summary: 'Designed an ultra-compact, Raft-replicated embeddable database that boots in 12ms inside edge workers, serving reads with sub-millisecond local consistency.',
    keyOutcomes: [
      { label: 'Read Latency (p99)', value: '0.8ms', change: 'Local memory snapshot' },
      { label: 'Write Replication', value: '18ms', change: 'Cross-region quorum' },
      { label: 'Memory Footprint', value: '14MB', change: '85% lighter than RocksDB' },
      { label: 'Query Throughput', value: '450k/s', change: 'Per single m6i.xlarge node' }
    ],
    techStack: ['Rust', 'WebAssembly', 'Raft Consensus', 'LSM-Tree', 'gRPC / Protobuf', 'Grafana'],
    systemArchitecture: {
      overview: 'Hybrid LSM-Tree storage engine compiled to native Rust and Wasm targets with append-only WAL and concurrent lock-free skip lists.',
      flowSteps: [
        'Application client executes SQL-like AST compiled to Wasm bytecode.',
        'Lock-free skip list absorbs atomic write mutations into active MemTable.',
        'Async background worker flushes SSTable segments to encrypted zstd-compressed block storage.',
        'Raft state machine broadcasts log entries across geographic consensus leader nodes.'
      ],
      components: [
        { name: 'Consensus Engine', role: 'Multi-Raft leader election and log replication', tech: 'Rust / async-raft', latencyOrMetric: '5ms quorum latency' },
        { name: 'Storage Engine', role: 'Compact LSM-Tree with Bloom filters', tech: 'Custom Rust / SIMD', latencyOrMetric: '99.4% Bloom cache hit' },
        { name: 'Query Compiler', role: 'JIT query execution to Wasm', tech: 'Wasmer / Cranelift', latencyOrMetric: '12µs query compile' },
        { name: 'Telemetry Exporter', role: 'OpenTelemetry metric streaming', tech: 'OTel / Prometheus', latencyOrMetric: 'Zero allocations' }
      ],
      tradeOffsAnalyzed: 'Opted for Multi-Raft over single Paxos ring to shard log contention by tenant, isolating high-volume write spikes without throttling quiet enterprise tenants.'
    },
    technicalHighlights: [
      'Engineered custom SIMD vector instructions for accelerating SSTable binary searches by 4.2x.',
      'Authored zero-allocation deserializer parsing 500k Protobuf packets per second on a single CPU core.',
      'Achieved 100% linearizable read consistency through LeaseRead optimizations without Raft roundtrips.'
    ],
    liveDemoUrl: 'https://example.com/demo/hyperscale',
    githubUrl: 'https://github.com/example/hyperscale-db',
    model3DConfig: {
      stationIndex: 1,
      color: '#10b981',
      secondaryColor: '#14b8a6',
      geometryType: 'edge-db',
      particleCount: 950
    }
  },
  {
    id: 'omni-mesh',
    title: 'OmniMesh: 3D Spatial Digital Twin & Telemetry Canvas',
    tagline: 'GPU-accelerated industrial visualizer managing 80,000 live IoT telemetry nodes at constant 60 FPS.',
    clientOrOrg: 'AeroDynamics Enterprise',
    category: 'Graphics & Web3D',
    period: '2023',
    role: 'Staff 3D & Graphics Architect',
    summary: 'Created a browser-based 3D digital twin platform rendering massive manufacturing facility models with live heatmaps, sensor overlays, and camera fly-throughs on standard laptops and iPads.',
    keyOutcomes: [
      { label: 'Active Live Nodes', value: '80,000', change: 'Real-time telemetry' },
      { label: 'Render Frame Rate', value: '60 FPS', change: 'Stable on Apple M1 & Intel' },
      { label: 'Initial Geometry Size', value: '3.4MB', change: '92% mesh compression' },
      { label: 'Operator Incident MTTR', value: '-64%', change: 'Immediate spatial alerts' }
    ],
    techStack: ['Three.js', 'Custom GLSL Shaders', 'InstancedBufferGeometry', 'Web Workers', 'DRACO / KTX2', 'WebSocket'],
    systemArchitecture: {
      overview: 'Client-side scene graph architecture using GPU instancing, hierarchical BVH spatial indexing, and WebGL dynamic texture atlas streaming.',
      flowSteps: [
        'CAD geometry converted through automated Draco mesh and KTX2 texture optimization pipeline.',
        'Web Worker decompresses spatial coordinates and computes BVH bounding hierarchies.',
        'Custom GLSL vertex shader animates 80k instanced sensors with 1 single draw call.',
        'Data buffer updates stream over binary WebSocket directly into Float32Array uniform arrays.'
      ],
      components: [
        { name: 'Instanced Renderer', role: 'Single-drawcall 80k mesh batching', tech: 'Three.js / GLSL', latencyOrMetric: '1.8ms GPU frame time' },
        { name: 'Spatial Indexer', role: 'Frustum & occlusion culling', tech: 'BVH / WebAssembly', latencyOrMetric: '< 0.3ms culling pass' },
        { name: 'Telemetry Streamer', role: 'Differential binary sensor telemetry', tech: 'ArrayBuffers / WS', latencyOrMetric: '60 updates/sec' },
        { name: 'Heatmap Generator', role: 'Real-time thermal gradient shader', tech: 'Fragment GLSL', latencyOrMetric: 'Zero CPU cost' }
      ],
      tradeOffsAnalyzed: 'Used hardware InstancedBufferGeometry with customized attribute buffers over separate meshes, reducing draw calls from 14,000 down to 7.'
    },
    technicalHighlights: [
      'Developed progressive LOD system that smoothly morphs geometry density based on camera distance without popping.',
      'Engineered screen-space sensor clustering preventing visual occlusion when zooming out to facility bird-eye view.',
      'Implemented touch gesture disambiguation for industrial tablet field technicians wearing work gloves.'
    ],
    liveDemoUrl: 'https://example.com/demo/omnimesh',
    githubUrl: 'https://github.com/example/omnimesh-engine',
    model3DConfig: {
      stationIndex: 2,
      color: '#8b5cf6',
      secondaryColor: '#ec4899',
      geometryType: 'spatial-iot',
      particleCount: 1400
    }
  },
  {
    id: 'krypton-agent',
    title: 'Krypton: Sub-100ms AI Agent Orchestration Gateway',
    tagline: 'Distributed inference proxy with semantic caching, speculative execution, and dynamic model fallback.',
    clientOrOrg: 'Synapse Labs AI',
    category: 'AI Infrastructure',
    period: '2024',
    role: 'Principal AI Systems Architect',
    summary: 'Built an enterprise AI routing infrastructure handling 120M token requests daily with semantic vector embedding cache, token streaming deduplication, and sub-100ms routing decisions.',
    keyOutcomes: [
      { label: 'Median Routing Overhead', value: '4.2ms', change: 'C++ / Rust micro-proxy' },
      { label: 'Token Cache Hit Rate', value: '38.4%', change: '$180k/mo API savings' },
      { label: 'P99 Time-to-First-Token', value: '94ms', change: 'Speculative warm starts' },
      { label: 'Provider Availability', value: '99.995%', change: 'Multi-cloud failover' }
    ],
    techStack: ['Rust / Tokio', 'Qdrant Vector DB', 'gRPC / SSE Streaming', 'Redis Cluster', 'Python / PyTorch', 'Docker'],
    systemArchitecture: {
      overview: 'Proxy gateway evaluates incoming prompt embeddings against warm semantic caches before executing speculative parallel calls across model providers.',
      flowSteps: [
        'Incoming client prompt embedded in 1.4ms via ONNX-optimized lightweight transformer.',
        'HNSW vector index queries cosine similarity against cached generation trees.',
        'If cache miss, router dispatches request to fastest available upstream provider with fallback timeout.',
        'Server-Sent Events (SSE) stream tokens with token-level rate control and guardrail validation.'
      ],
      components: [
        { name: 'Embedding Classifier', role: 'Sub-2ms prompt intent vectorization', tech: 'ONNX Runtime / C++', latencyOrMetric: '1.4ms p95' },
        { name: 'Semantic Cache Layer', role: 'Vector similarity cache lookup', tech: 'Qdrant / SIMD', latencyOrMetric: '3.1ms lookup' },
        { name: 'Inference Broker', role: 'Dynamic load balancing & circuit breaker', tech: 'Rust / Hyper', latencyOrMetric: '0.6ms overhead' },
        { name: 'Safety Guardrail', role: 'Stream token evaluation & regex redaction', tech: 'Rust / Aho-Corasick', latencyOrMetric: '0.1ms per token' }
      ],
      tradeOffsAnalyzed: 'Implemented speculative double-querying on borderline latency connections, cancelling the slower provider once the first token arrives to guarantee p99 SLAs.'
    },
    technicalHighlights: [
      'Built lock-free token ring buffer serving 25,000 concurrent streaming connections with 60MB total RAM.',
      'Devised semantic hashing algorithm that tolerates whitespace and synonym permutations without false misses.',
      'Integrated real-time cost attribution tracking expenditure down to individual API keys and tenant IDs.'
    ],
    liveDemoUrl: 'https://example.com/demo/krypton',
    githubUrl: 'https://github.com/example/krypton-agent',
    model3DConfig: {
      stationIndex: 3,
      color: '#f59e0b',
      secondaryColor: '#ef4444',
      geometryType: 'agent-synapse',
      particleCount: 1100
    }
  }
];

export const TECH_SKILLS: TechSkill[] = [
  {
    name: 'Distributed Systems & Concurrency',
    category: 'Systems & Backend',
    level: 'Expert / Staff',
    years: 10,
    featuredProject: 'AetherFlow & HyperScale DB',
    iconName: 'Server',
    description: 'Raft consensus, gossip protocols, LSM-Trees, zero-copy socket multiplexing, eBPF packet routing, and fault-tolerant multi-region failover.'
  },
  {
    name: 'Rust & High-Performance C/C++',
    category: 'Systems & Backend',
    level: 'Expert / Staff',
    years: 8,
    featuredProject: 'HyperScale DB & Krypton Proxy',
    iconName: 'Cpu',
    description: 'Async Tokio runtimes, SIMD intrinsics, memory safety without GC, custom allocators, Wasm compilation, and high-density binary serialization.'
  },
  {
    name: 'Go & Cloud Microservices',
    category: 'Systems & Backend',
    level: 'Expert / Staff',
    years: 9,
    featuredProject: 'AetherFlow Ingress Relay',
    iconName: 'Terminal',
    description: 'High-throughput gRPC services, goroutine worker pools, low-allocation network parsers, Kubernetes operators, and Prometheus observability.'
  },
  {
    name: 'Three.js, WebGL & WebGPU',
    category: 'Graphics & Frontend',
    level: 'Expert / Staff',
    years: 7,
    featuredProject: 'OmniMesh & Dual-Mode Portfolio',
    iconName: 'Box',
    description: 'Custom GLSL/WGSL compute & fragment shaders, InstancedBufferGeometry, BVH spatial culling, DRACO/KTX2 pipelines, 60 FPS mobile budgeting.'
  },
  {
    name: 'React 19, TypeScript & Modern UI',
    category: 'Graphics & Frontend',
    level: 'Expert / Staff',
    years: 9,
    featuredProject: 'OmniMesh Console & Spatial UI',
    iconName: 'Layout',
    description: 'Strict TypeScript typing, high-speed DOM rendering, Tailwind CSS, accessible ARIA hierarchies, micro-interactions, and deep-link routing.'
  },
  {
    name: 'Kubernetes, Anycast & Cloud Edge',
    category: 'Distributed & Cloud',
    level: 'Expert / Staff',
    years: 8,
    featuredProject: 'CloudScale Global Ingress',
    iconName: 'Cloud',
    description: 'Terraform, Envoy edge gateways, AWS/GCP bare-metal clusters, Cloudflare Workers, Anycast routing, and auto-scaling telemetry pipelines.'
  },
  {
    name: 'AI Infrastructure & Vector Systems',
    category: 'AI & Protocols',
    level: 'Advanced',
    years: 4,
    featuredProject: 'Krypton Agent Gateway',
    iconName: 'Sparkles',
    description: 'Semantic vector caches (Qdrant/Milvus), token streaming proxies, speculative execution, ONNX runtime JIT, and model failover matrices.'
  },
  {
    name: 'WebTransport, QUIC & WebSockets',
    category: 'AI & Protocols',
    level: 'Expert / Staff',
    years: 6,
    featuredProject: 'AetherFlow Binary Transport',
    iconName: 'Activity',
    description: 'HTTP/3 WebTransport streams, custom binary framing protocols, UDP multiplexing, connection recovery, and backpressure rate limiting.'
  }
];

export const WORK_EXPERIENCES: WorkExperience[] = [
  {
    id: 'exp-1',
    period: '2023 - Present',
    role: 'Staff Systems & Graphics Architect',
    company: 'Vortex Cloud & Spatial Infrastructure',
    location: 'San Francisco, CA (Hybrid)',
    team: 'Core Edge Engine & Graphics Group',
    summary: 'Architected next-generation distributed streaming edge proxies and browser-based 3D digital twin engines serving 200+ Fortune 500 enterprise clients.',
    verifiedImpact: [
      'Led 14 engineers across distributed backend and graphics divisions, establishing rigorous code-review standards and sub-100ms SLA budgets.',
      'Slashed global cloud egress expenses by $4.2M annually by designing custom binary serialization and client-side GPU unpacking shaders.',
      'Maintained 99.995% production uptime across 2.4M peak concurrent WebTransport streams.'
    ],
    technologies: ['Rust', 'Go', 'WebGPU', 'Three.js', 'Kubernetes', 'Envoy', 'gRPC']
  },
  {
    id: 'exp-2',
    period: '2020 - 2023',
    role: 'Senior Principal Frontend & Systems Engineer',
    company: 'AeroDynamics Enterprise',
    location: 'Seattle, WA & Remote',
    team: 'Real-Time Visualization & Digital Twin',
    summary: 'Spearheaded development of 3D spatial analytics platform rendering 80,000 real-time IoT sensors for industrial manufacturing facilities.',
    verifiedImpact: [
      'Designed custom WebGL InstancedBufferGeometry pipeline reducing client draw calls from 14,000 to 7, achieving 60 FPS on iPad field tablets.',
      'Decreased industrial equipment incident response time (MTTR) by 64% through spatial 3D alert heatmaps.',
      'Authored proprietary Draco 3D mesh compression pipeline decreasing 3D model asset payloads from 45MB down to 3.4MB.'
    ],
    technologies: ['Three.js', 'TypeScript', 'GLSL Shaders', 'WebSockets', 'Go', 'Docker']
  },
  {
    id: 'exp-3',
    period: '2017 - 2020',
    role: 'Senior Distributed Backend Engineer',
    company: 'DataStream Core Inc.',
    location: 'San Francisco, CA',
    team: 'High-Throughput Messaging & Ingest',
    summary: 'Built distributed pub/sub pipelines handling 45 billion daily analytical events with microsecond query response times.',
    verifiedImpact: [
      'Engineered custom Kafka partitioned consumers in Go and C++, increasing message ingestion throughput by 340%.',
      'Migrated legacy monolithic database to distributed sharded Cassandra and Redis clusters with zero customer downtime.'
    ],
    technologies: ['Go', 'C++', 'Kafka', 'Cassandra', 'Redis', 'Prometheus', 'AWS']
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    quote: 'Alex is the rare architect who operates with equal mastery across low-level Rust network sockets and 60 FPS WebGL shader pipelines. His AetherFlow architecture saved us millions while unlocking capabilities our competitors cannot match.',
    author: 'Elena Rostova',
    role: 'VP of Engineering',
    company: 'CloudScale Technologies',
    relationship: 'Managed Alex directly'
  },
  {
    id: 'test-2',
    quote: 'When our industrial 3D digital twin was grinding standard laptops to 9 FPS, Alex stepped in, rewritten the rendering pipeline with custom instanced shaders, and locked it at a silky 60 FPS. Extraordinary technical leadership.',
    author: 'David Chen',
    role: 'Chief Technology Officer',
    company: 'AeroDynamics Enterprise',
    relationship: 'Executive Sponsor'
  },
  {
    id: 'test-3',
    quote: 'The cleanest systems designs I have reviewed in 15 years. Alex thinks rigorously about backpressure, p99 latency guarantees, and developer ergonomics. Any engineering organization would be lucky to have him.',
    author: 'Marcus Vance',
    role: 'Principal Staff Engineer',
    company: 'Vortex Infrastructure',
    relationship: 'Peer Architect'
  }
];
