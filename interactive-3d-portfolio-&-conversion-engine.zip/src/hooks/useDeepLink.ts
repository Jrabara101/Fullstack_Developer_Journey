import { useState, useEffect, useCallback } from 'react';

export function useDeepLink() {
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);

  // Parse initial hash on mount
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (!hash) {
        setActiveSection('hero');
        setActiveProjectId(null);
        return;
      }

      if (hash.startsWith('project-')) {
        const pId = hash.replace('project-', '');
        setActiveProjectId(pId);
        setActiveSection('projects');
      } else if (['hero', 'projects', 'stack', 'architecture', 'experience', 'contact'].includes(hash)) {
        setActiveSection(hash);
        setActiveProjectId(null);
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = useCallback((section: string, projectId?: string) => {
    setActiveSection(section);
    if (projectId) {
      setActiveProjectId(projectId);
      window.location.hash = `project-${projectId}`;
    } else {
      setActiveProjectId(null);
      window.location.hash = section;
    }
  }, []);

  const copyShareLink = useCallback((sectionOrProject: string) => {
    const url = `${window.location.origin}${window.location.pathname}#${sectionOrProject}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    });
  }, []);

  return {
    activeSection,
    activeProjectId,
    copiedUrl,
    navigateTo,
    copyShareLink,
    setActiveProjectId
  };
}
