import { useState, useEffect, useCallback, useRef } from 'react';
import { TelemetryData, ViewMode, HardwareTier } from '../types';

const STORAGE_KEY = 'portfolio_telemetry_v1';

const initialTelemetry: TelemetryData = {
  mode3DCount: 1,
  mode2DCount: 0,
  currentMode: '3d-immersive',
  projectClicks: {},
  contactConversions: 0,
  resumeDownloads: 0,
  deepLinkShares: 0,
  averageFps: 60,
  lowFpsFlag: false,
  timeIn3DSeconds: 0,
  timeIn2DSeconds: 0,
  hardwareTier: 'high',
  hasSeenTouchHint: false
};

export function useTelemetry() {
  const [telemetry, setTelemetry] = useState<TelemetryData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return { ...initialTelemetry, ...JSON.parse(saved) };
      }
    } catch {
      // fallback
    }
    return initialTelemetry;
  });

  const [currentFps, setCurrentFps] = useState(60);
  const [gpuInfo, setGpuInfo] = useState<string>('Detecting GPU...');
  const frameTimesRef = useRef<number[]>([]);
  const lastTimeRef = useRef<number>(performance.now());
  const rafIdRef = useRef<number | null>(null);

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(telemetry));
    } catch {
      // ignore
    }
  }, [telemetry]);

  // Track time in modes
  useEffect(() => {
    const timer = setInterval(() => {
      if (document.hidden) return; // Do not increment if tab inactive
      setTelemetry(prev => {
        if (prev.currentMode === '3d-immersive') {
          return { ...prev, timeIn3DSeconds: prev.timeIn3DSeconds + 1 };
        } else {
          return { ...prev, timeIn2DSeconds: prev.timeIn2DSeconds + 1 };
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Detect GPU / Hardware Tier
  useEffect(() => {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (gl) {
        const debugInfo = (gl as WebGLRenderingContext).getExtension('WEBGL_debug_renderer_info');
        if (debugInfo) {
          const renderer = (gl as WebGLRenderingContext).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
          setGpuInfo(renderer || 'Standard WebGL 2.0');
          // Auto detect lower tier on weak mobile/integrated
          if (/intel|mali|adreno 5|powerVR/i.test(renderer)) {
            setTelemetry(prev => ({ ...prev, hardwareTier: 'medium' }));
          }
        } else {
          setGpuInfo('Standard WebGL Engine');
        }
      } else {
        setGpuInfo('Software / CPU Rasterizer (WebGL Disabled)');
        setTelemetry(prev => ({ ...prev, hardwareTier: 'low-battery' }));
      }
    } catch {
      setGpuInfo('Generic WebGL Device');
    }
  }, []);

  // Measure active FPS
  useEffect(() => {
    let frameCount = 0;
    let lastFpsUpdate = performance.now();

    const checkLoop = (now: number) => {
      frameCount++;
      const delta = now - lastFpsUpdate;
      if (delta >= 500) {
        const fps = Math.round((frameCount * 1000) / delta);
        setCurrentFps(fps);
        frameCount = 0;
        lastFpsUpdate = now;

        setTelemetry(prev => {
          const isLow = fps < 30 && prev.currentMode === '3d-immersive';
          return {
            ...prev,
            averageFps: Math.round((prev.averageFps * 0.9) + (fps * 0.1)),
            lowFpsFlag: isLow
          };
        });
      }
      rafIdRef.current = requestAnimationFrame(checkLoop);
    };

    rafIdRef.current = requestAnimationFrame(checkLoop);
    return () => {
      if (rafIdRef.current) cancelAnimationFrame(rafIdRef.current);
    };
  }, []);

  const switchMode = useCallback((newMode: ViewMode) => {
    setTelemetry(prev => ({
      ...prev,
      currentMode: newMode,
      mode3DCount: newMode === '3d-immersive' ? prev.mode3DCount + 1 : prev.mode3DCount,
      mode2DCount: newMode === '2d-classic' ? prev.mode2DCount + 1 : prev.mode2DCount
    }));
  }, []);

  const trackProjectClick = useCallback((projectId: string) => {
    setTelemetry(prev => ({
      ...prev,
      projectClicks: {
        ...prev.projectClicks,
        [projectId]: (prev.projectClicks[projectId] || 0) + 1
      }
    }));
  }, []);

  const trackContactConversion = useCallback((type: 'email' | 'linkedin' | 'calendly') => {
    setTelemetry(prev => ({
      ...prev,
      contactConversions: prev.contactConversions + 1
    }));
  }, []);

  const trackResumeDownload = useCallback(() => {
    setTelemetry(prev => ({
      ...prev,
      resumeDownloads: prev.resumeDownloads + 1
    }));
  }, []);

  const trackDeepLinkShare = useCallback(() => {
    setTelemetry(prev => ({
      ...prev,
      deepLinkShares: prev.deepLinkShares + 1
    }));
  }, []);

  const setHardwareTier = useCallback((tier: HardwareTier) => {
    setTelemetry(prev => ({
      ...prev,
      hardwareTier: tier
    }));
  }, []);

  const dismissTouchHint = useCallback(() => {
    setTelemetry(prev => ({ ...prev, hasSeenTouchHint: true }));
  }, []);

  const resetTelemetry = useCallback(() => {
    setTelemetry({ ...initialTelemetry, currentMode: telemetry.currentMode });
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
  }, [telemetry.currentMode]);

  return {
    telemetry,
    currentFps,
    gpuInfo,
    switchMode,
    trackProjectClick,
    trackContactConversion,
    trackResumeDownload,
    trackDeepLinkShare,
    setHardwareTier,
    dismissTouchHint,
    resetTelemetry
  };
}
