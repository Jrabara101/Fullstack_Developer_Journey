export type ViewMode = '3d-immersive' | '2d-classic';

export type HardwareTier = 'high' | 'medium' | 'low-battery';

export interface KPIOutcome {
  label: string;
  value: string;
  change: string;
  isPositive?: boolean;
}

export interface ArchitectureComponent {
  name: string;
  role: string;
  tech: string;
  latencyOrMetric: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  tagline: string;
  clientOrOrg: string;
  category: 'Distributed Systems' | 'Graphics & Web3D' | 'AI Infrastructure' | 'Edge Cloud';
  period: string;
  role: string;
  summary: string;
  keyOutcomes: KPIOutcome[];
  techStack: string[];
  systemArchitecture: {
    overview: string;
    flowSteps: string[];
    components: ArchitectureComponent[];
    tradeOffsAnalyzed: string;
  };
  technicalHighlights: string[];
  liveDemoUrl?: string;
  githubUrl?: string;
  model3DConfig: {
    stationIndex: number;
    color: string;
    secondaryColor: string;
    geometryType: 'neural-mesh' | 'edge-db' | 'spatial-iot' | 'agent-synapse';
    particleCount: number;
  };
}

export interface TechSkill {
  name: string;
  category: 'Systems & Backend' | 'Graphics & Frontend' | 'Distributed & Cloud' | 'AI & Protocols';
  level: 'Expert / Staff' | 'Advanced' | 'Working Knowledge';
  years: number;
  featuredProject: string;
  iconName: string;
  description: string;
}

export interface WorkExperience {
  id: string;
  period: string;
  role: string;
  company: string;
  location: string;
  team: string;
  summary: string;
  verifiedImpact: string[];
  technologies: string[];
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  company: string;
  relationship: string;
}

export interface TelemetryData {
  mode3DCount: number;
  mode2DCount: number;
  currentMode: ViewMode;
  projectClicks: Record<string, number>;
  contactConversions: number;
  resumeDownloads: number;
  deepLinkShares: number;
  averageFps: number;
  lowFpsFlag: boolean;
  timeIn3DSeconds: number;
  timeIn2DSeconds: number;
  hardwareTier: HardwareTier;
  hasSeenTouchHint: boolean;
}
