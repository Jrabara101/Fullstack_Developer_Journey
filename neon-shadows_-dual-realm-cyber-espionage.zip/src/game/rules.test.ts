import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createInitialGameState,
  executeDualHack,
  resolveVaultDilemma,
  stepGameWorld,
  toggleActiveRealm,
} from './rules';

test('initial state spawns player on open path facing North in Sector 1', () => {
  const state = createInitialGameState(500);
  assert.equal(state.mode, 'title');
  assert.equal(state.sector, 1);
  assert.equal(state.bestScore, 500);
  assert.equal(state.player.x, 3.0);
  assert.equal(state.player.z, 5.4);
  assert.equal(state.gates[0].isOpen, false);
  assert.equal(state.nodes.length, 3);
});

test('dual hacking a firewall node opens linked physical gate and records Consequence Echo', () => {
  const state = createInitialGameState();
  state.mode = 'playing';

  const res = executeDualHack(state, 'ghost_bypass', 'node-fw-1');
  assert.equal(res.success, true);
  assert.equal(state.gates[0].isOpen, true);
  assert.equal(state.ghostEchoCount, 1);
  assert.equal(state.echoes.length, 1);
  assert.equal(state.echoes[0].polarity, 'ghost');
});

test('voltage surge hack damages nearby enemies and increments Surge Consequence Echoes', () => {
  const state = createInitialGameState();
  state.mode = 'playing';
  const initialHp = state.enemies[0].hp;

  const res = executeDualHack(state, 'voltage_surge', 'node-fw-1');
  assert.equal(res.success, true);
  assert.equal(state.surgeEchoCount, 1);
  assert.ok(state.enemies[0].hp < initialHp);
});

test('vault dilemma resolution unlocks extraction point and progresses sectors', () => {
  const state = createInitialGameState();
  state.mode = 'playing';

  // Move player to vault at (3, 1)
  state.player.x = 3.0;
  state.player.z = 1.1;
  const step1 = stepGameWorld(state, 0.016, { moveX: 0, moveZ: 0 });
  assert.equal(step1.vaultTriggered, true);
  assert.ok(state.activeDilemma !== null);

  const resolved = resolveVaultDilemma(state, 'ghost');
  assert.equal(resolved, true);
  assert.equal(state.extractionPoint.active, true);

  // Move player to extraction at (3, 0)
  state.player.x = 3.0;
  state.player.z = 0.2;
  const step2 = stepGameWorld(state, 0.016, { moveX: 0, moveZ: 0 });
  assert.equal(step2.sectorCleared, true);
  assert.equal(state.sector, 2);
});

test('toggleActiveRealm switches between physical and cyber layers', () => {
  const state = createInitialGameState();
  assert.equal(state.activeRealm, 'physical');
  toggleActiveRealm(state);
  assert.equal(state.activeRealm, 'cyber');
  toggleActiveRealm(state);
  assert.equal(state.activeRealm, 'physical');
});
