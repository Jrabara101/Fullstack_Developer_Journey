export type GameStateMode = 'title' | 'playing' | 'paused' | 'gameover';
export type GameOutcome = 'victory' | 'defeat' | null;
export type RealmType = 'physical' | 'cyber';
export type EchoPolarity = 'ghost' | 'surge';
export type HackMethod = 'ghost_bypass' | 'voltage_surge' | 'echo_detonate';
export type EnemyArchetype = 'swarmer' | 'kiter' | 'charger';

export interface EchoRecord {
  id: string;
  sector: number;
  title: string;
  polarity: EchoPolarity;
  effectSummary: string;
  timestamp: number;
}

export interface CyberNode {
  id: string;
  label: string;
  kind: 'firewall' | 'turret_link' | 'vault_cipher' | 'patrol_router';
  gx: number;
  gz: number;
  hacked: boolean;
  polarity: EchoPolarity | null;
  linkedGateId?: string;
  linkedVaultId?: string;
  pulseTimer: number;
}

export interface SecurityGate {
  id: string;
  gx: number;
  gz: number;
  isOpen: boolean;
}

export interface DataVault {
  id: string;
  label: string;
  gx: number;
  gz: number;
  unlocked: boolean;
  breached: boolean;
  dilemmaTitle: string;
  ghostChoiceLabel: string;
  ghostEchoTitle: string;
  ghostEffect: string;
  surgeChoiceLabel: string;
  surgeEchoTitle: string;
  surgeEffect: string;
}

export interface EnemyUnit {
  id: string;
  archetype: EnemyArchetype;
  name: string;
  x: number;
  z: number;
  vx: number;
  vz: number;
  facingAngle: number;
  hp: number;
  maxHp: number;
  shieldActive: boolean;
  state: 'patrol' | 'chase' | 'windup' | 'recover' | 'stunned' | 'hacked_ally' | 'ko';
  stateTimer: number;
  windupDuration: number;
  targetX: number;
  targetZ: number;
  hitFlashTimer: number;
  koTimer: number;
  patrolOriginX: number;
  patrolOriginZ: number;
  patrolPhase: number;
}

export interface ActiveDilemma {
  vaultId: string;
  title: string;
  ghostLabel: string;
  surgeLabel: string;
}

export interface RunSnapshot {
  score: number;
  bestScore: number;
  sectorReached: number;
  totalSectors: number;
  echoesCount: number;
  ghostCount: number;
  surgeCount: number;
  traceLevel: number;
  clearTimeSec: number;
  outcome: 'victory' | 'defeat';
  endingTitle: string;
  endingSummary: string;
}

export interface GameWorldState {
  mode: GameStateMode;
  outcome: GameOutcome;
  activeRealm: RealmType;
  sector: number;
  maxSectors: number;
  sectorName: string;
  score: number;
  bestScore: number;
  elapsedSec: number;
  hitstopTimer: number;
  cameraTrauma: number;
  selectedHackTool: HackMethod;

  // Player stats & kinematics (grid coordinates 0..6, centered at 3,3)
  player: {
    x: number;
    z: number;
    vx: number;
    vz: number;
    facingAngle: number;
    hp: number;
    maxHp: number;
    neuralEnergy: number;
    maxNeuralEnergy: number;
    cloakTimer: number;
    invulnTimer: number;
    hitFlashTimer: number;
    dashCooldown: number;
    stepBobPhase: number;
    squashX: number;
    squashY: number;
  };

  // Corporate Trace & Consequence Echoes
  traceLevel: number; // 0 to 100
  echoes: EchoRecord[];
  ghostEchoCount: number;
  surgeEchoCount: number;

  // Entities
  nodes: CyberNode[];
  gates: SecurityGate[];
  vaults: DataVault[];
  enemies: EnemyUnit[];
  extractionPoint: { gx: number; gz: number; active: boolean };
  obstacles: Array<{ gx: number; gz: number }>;

  // Narrative & Dilemma
  narrativeLog: string;
  npcStatus: string;
  activeDilemma: ActiveDilemma | null;
  runSnapshot: RunSnapshot | null;
}

export const GRID_SIZE = 7;
export const MAX_CONCURRENT_ATTACKERS = 3;

const SECTOR_CONFIGS = [
  {
    sector: 1,
    name: 'SECTOR 01 // AETHELGARD SUB-NET PLAZA',
    introLog:
      'ARIA-7 [COMM]: "You are jacked into both realms, Shade. Hack the upper Cyberspace Nodes to disable physical laser barriers and rewrite Enforcer routines."',
    obstacles: [
      { gx: 1, gz: 2 },
      { gx: 5, gz: 2 },
    ],
    gates: [{ id: 'gate-1', gx: 3, gz: 2, isOpen: false }],
    nodes: [
      {
        id: 'node-fw-1',
        label: 'FIREWALL RELAY ALPHA',
        kind: 'firewall' as const,
        gx: 1,
        gz: 4,
        linkedGateId: 'gate-1',
      },
      {
        id: 'node-vc-1',
        label: 'CIPHER CONDUIT BETA',
        kind: 'vault_cipher' as const,
        gx: 5,
        gz: 4,
        linkedVaultId: 'vault-1',
      },
      {
        id: 'node-pr-1',
        label: 'PATROL ROUTER GAMMA',
        kind: 'patrol_router' as const,
        gx: 3,
        gz: 3,
      },
    ],
    vaults: [
      {
        id: 'vault-1',
        label: 'NEURAL REGISTRY VAULT',
        gx: 3,
        gz: 1,
        dilemmaTitle: 'AETHELGARD CITIZEN IMPLANT LEDGER DETECTED',
        ghostChoiceLabel: 'ENCRYPT & LEAK TO UNDERGROUND [GHOST ECHO]',
        ghostEchoTitle: 'Whistleblower Cipher',
        ghostEffect: 'Aria-7 boosts Neural Regen +25%; Corp Trace -15%',
        surgeChoiceLabel: 'OVERLOAD EXECUTIVE CORTEX NET [SURGE ECHO]',
        surgeEchoTitle: 'Cortex Feedback Spike',
        surgeEffect: 'Surge Hack AoE damage +30%; Enemies start weakened',
      },
    ],
    enemies: [
      {
        id: 'en-1',
        archetype: 'swarmer' as const,
        name: 'Enforcer Hound Mk.II',
        x: 1.5,
        z: 3.2,
        hp: 45,
      },
      {
        id: 'en-2',
        archetype: 'kiter' as const,
        name: 'Suppressor Optic Unit',
        x: 5.0,
        z: 1.5,
        hp: 40,
      },
    ],
  },
  {
    sector: 2,
    name: 'SECTOR 02 // BLACK-ICE NEURAL ARCHIVE',
    introLog:
      'ARIA-7 [COMM]: "Consequence Echoes from Sector 01 are resonating across the grid! Watch for Aegis Shield Juggernauts ahead."',
    obstacles: [
      { gx: 2, gz: 3 },
      { gx: 4, gz: 3 },
    ],
    gates: [{ id: 'gate-2', gx: 3, gz: 2, isOpen: false }],
    nodes: [
      {
        id: 'node-fw-2',
        label: 'BLACK-ICE GATEWAY',
        kind: 'firewall' as const,
        gx: 1,
        gz: 3,
        linkedGateId: 'gate-2',
      },
      {
        id: 'node-vc-2',
        label: 'ARCHIVE DECRYPTOR',
        kind: 'vault_cipher' as const,
        gx: 5,
        gz: 3,
        linkedVaultId: 'vault-2',
      },
      {
        id: 'node-tl-2',
        label: 'AEGIS SHIELD DISRUPTOR',
        kind: 'turret_link' as const,
        gx: 3,
        gz: 4,
      },
    ],
    vaults: [
      {
        id: 'vault-2',
        label: 'BLACK-ICE MEMORY CORE',
        gx: 3,
        gz: 1,
        dilemmaTitle: 'SENTIENT AI CLONE PRISON DISCOVERED',
        ghostChoiceLabel: 'FREE AI CLONES INTO THE MESH [GHOST ECHO]',
        ghostEchoTitle: 'Liberated Ghost Mesh',
        ghostEffect: 'Unlocks Phase Cloak extensions & lowers Trace drift',
        surgeChoiceLabel: 'WEAPONIZE AI SWARM AGAINST CORP [SURGE ECHO]',
        surgeEchoTitle: 'Valkyrie Logic Bomb',
        surgeEffect: 'Hacked nodes emit lethal arc lightning to nearby patrols',
      },
    ],
    enemies: [
      {
        id: 'en-2a',
        archetype: 'swarmer' as const,
        name: 'Enforcer Hound Mk.III',
        x: 1.2,
        z: 2.2,
        hp: 55,
      },
      {
        id: 'en-2b',
        archetype: 'kiter' as const,
        name: 'Suppressor Sniper',
        x: 5.2,
        z: 2.0,
        hp: 50,
      },
      {
        id: 'en-2c',
        archetype: 'charger' as const,
        name: 'Aegis Heavy Juggernaut',
        x: 3.0,
        z: 2.5,
        hp: 85,
      },
    ],
  },
  {
    sector: 3,
    name: 'SECTOR 03 // PROJECT ECLIPSE APEX CORE',
    introLog:
      'ARIA-7 [COMM]: "This is the Apex Spire. Every Consequence Echo you forged converges here. Breach the Eclipse Core and reach Extraction!"',
    obstacles: [
      { gx: 1, gz: 2 },
      { gx: 5, gz: 2 },
    ],
    gates: [{ id: 'gate-3', gx: 3, gz: 1, isOpen: false }],
    nodes: [
      {
        id: 'node-fw-3',
        label: 'APEX FIREWALL PRIME',
        kind: 'firewall' as const,
        gx: 1,
        gz: 4,
        linkedGateId: 'gate-3',
      },
      {
        id: 'node-vc-3',
        label: 'ECLIPSE MASTER CIPHER',
        kind: 'vault_cipher' as const,
        gx: 5,
        gz: 4,
        linkedVaultId: 'vault-3',
      },
      {
        id: 'node-pr-3',
        label: 'OMEGA OVERRIDE NODE',
        kind: 'patrol_router' as const,
        gx: 3,
        gz: 3,
      },
    ],
    vaults: [
      {
        id: 'vault-3',
        label: 'PROJECT ECLIPSE NEXUS',
        gx: 3,
        gz: 1,
        dilemmaTitle: 'ORBITAL MIND-CONTROL UPLINK READY FOR OVERRIDE',
        ghostChoiceLabel: 'DISSOLVE CORPORATE LOCK & RESTORE FREE WILL [GHOST]',
        ghostEchoTitle: 'Zero-Trace Dawn',
        ghostEffect: 'Cloaks extraction route & neutralizes Corporate Trace',
        surgeChoiceLabel: 'REVERSE UPLINK TO SHATTER SYNDICATE BOARD [SURGE]',
        surgeEchoTitle: 'Neon Supernova',
        surgeEffect: 'Triggers massive EMP across all Apex Enforcers',
      },
    ],
    enemies: [
      {
        id: 'en-3a',
        archetype: 'swarmer' as const,
        name: 'Apex Stalker Drone',
        x: 1.4,
        z: 3.0,
        hp: 65,
      },
      {
        id: 'en-3b',
        archetype: 'kiter' as const,
        name: 'Apex Rail Suppressor',
        x: 5.2,
        z: 2.5,
        hp: 60,
      },
      {
        id: 'en-3c',
        archetype: 'charger' as const,
        name: 'Eclipse Aegis Prime',
        x: 3.0,
        z: 2.3,
        hp: 105,
      },
    ],
  },
];

export function createInitialGameState(bestScore = 0): GameWorldState {
  const state: GameWorldState = {
    mode: 'title',
    outcome: null,
    activeRealm: 'physical',
    sector: 1,
    maxSectors: SECTOR_CONFIGS.length,
    sectorName: SECTOR_CONFIGS[0].name,
    score: 0,
    bestScore,
    elapsedSec: 0,
    hitstopTimer: 0,
    cameraTrauma: 0,
    selectedHackTool: 'ghost_bypass',
    player: {
      x: 3.0,
      z: 5.4,
      vx: 0,
      vz: 0,
      facingAngle: 0, // Facing North (-Z)
      hp: 100,
      maxHp: 100,
      neuralEnergy: 100,
      maxNeuralEnergy: 100,
      cloakTimer: 0,
      invulnTimer: 0,
      hitFlashTimer: 0,
      dashCooldown: 0,
      stepBobPhase: 0,
      squashX: 1,
      squashY: 1,
    },
    traceLevel: 10,
    echoes: [],
    ghostEchoCount: 0,
    surgeEchoCount: 0,
    nodes: [],
    gates: [],
    vaults: [],
    enemies: [],
    extractionPoint: { gx: 3, gz: 0, active: false },
    obstacles: [],
    narrativeLog: SECTOR_CONFIGS[0].introLog,
    npcStatus: 'ARIA-7: LINK STABLE // GHOST CONDUITS STANDBY',
    activeDilemma: null,
    runSnapshot: null,
  };

  loadSectorIntoState(state, 1);
  return state;
}

export function loadSectorIntoState(state: GameWorldState, sectorNum: number): void {
  const idx = Math.max(0, Math.min(SECTOR_CONFIGS.length - 1, sectorNum - 1));
  const cfg = SECTOR_CONFIGS[idx];
  state.sector = cfg.sector;
  state.sectorName = cfg.name;
  state.narrativeLog = cfg.introLog;
  state.activeDilemma = null;

  // Spawn player on open path at bottom-center (3.0, 5.4) facing North (0, -1)
  state.player.x = 3.0;
  state.player.z = 5.4;
  state.player.vx = 0;
  state.player.vz = 0;
  state.player.facingAngle = 0;
  state.player.neuralEnergy = Math.min(
    state.player.maxNeuralEnergy,
    state.player.neuralEnergy + 35,
  );

  // Consequence Echo carryover bonuses
  if (state.ghostEchoCount > 0) {
    state.traceLevel = Math.max(0, state.traceLevel - state.ghostEchoCount * 8);
    state.player.cloakTimer = Math.max(state.player.cloakTimer, 1.5);
    state.npcStatus = `ARIA-7: GHOST RESONANCE x${state.ghostEchoCount} // STEALTH CLOAK ENGAGED`;
  } else if (state.surgeEchoCount > 0) {
    state.npcStatus = `ARIA-7: SURGE RESONANCE x${state.surgeEchoCount} // OVERCLOCK ARCS ACTIVE`;
  }

  state.obstacles = cfg.obstacles.map((o) => ({ ...o }));
  state.gates = cfg.gates.map((g) => ({ ...g }));
  state.nodes = cfg.nodes.map((n) => ({
    ...n,
    hacked: false,
    polarity: null,
    pulseTimer: 0,
  }));
  state.vaults = cfg.vaults.map((v) => ({
    ...v,
    unlocked: false,
    breached: false,
  }));

  // Apply Surge Echo carryover: weaken initial enemy HP slightly if Surge echoes exist
  const surgeHpFactor = Math.max(0.75, 1 - state.surgeEchoCount * 0.08);
  state.enemies = cfg.enemies.map((e) => ({
    id: e.id,
    archetype: e.archetype,
    name: e.name,
    x: e.x,
    z: e.z,
    vx: 0,
    vz: 0,
    facingAngle: Math.PI,
    hp: Math.round(e.hp * surgeHpFactor),
    maxHp: e.hp,
    shieldActive: e.archetype === 'charger',
    state: 'patrol',
    stateTimer: 0,
    windupDuration:
      e.archetype === 'swarmer' ? 0.45 : e.archetype === 'kiter' ? 0.65 : 0.7,
    targetX: e.x,
    targetZ: e.z,
    hitFlashTimer: 0,
    koTimer: 0,
    patrolOriginX: e.x,
    patrolOriginZ: e.z,
    patrolPhase: Math.random() * Math.PI * 2,
  }));

  state.extractionPoint = { gx: 3, gz: 0, active: false };
}

export function toggleActiveRealm(state: GameWorldState): RealmType {
  state.activeRealm = state.activeRealm === 'physical' ? 'cyber' : 'physical';
  return state.activeRealm;
}

export function recordConsequenceEcho(
  state: GameWorldState,
  title: string,
  polarity: EchoPolarity,
  effectSummary: string,
): EchoRecord {
  const rec: EchoRecord = {
    id: `echo-${state.echoes.length + 1}-${Date.now()}`,
    sector: state.sector,
    title,
    polarity,
    effectSummary,
    timestamp: state.elapsedSec,
  };
  state.echoes.push(rec);
  if (polarity === 'ghost') {
    state.ghostEchoCount += 1;
    state.traceLevel = Math.max(0, state.traceLevel - 12);
    state.npcStatus = `ARIA-7: GHOST ECHO [${title.toUpperCase()}] RESONATING`;
  } else {
    state.surgeEchoCount += 1;
    state.traceLevel = Math.min(100, state.traceLevel + 8);
    state.npcStatus = `CORP NET: SURGE ECHO [${title.toUpperCase()}] DETECTED`;
  }
  return rec;
}

/**
 * Executes a Dual-Realm Hack on a specific CyberNode (or nearest unhacked node).
 * Mutates both the Cyberspace layer and the Physical layer simultaneously.
 */
export function executeDualHack(
  state: GameWorldState,
  method?: HackMethod,
  targetNodeId?: string,
): {
  success: boolean;
  message: string;
  hackedNode?: CyberNode;
  affectedEnemies: number;
} {
  if (state.mode !== 'playing') {
    return { success: false, message: 'Simulation not active.', affectedEnemies: 0 };
  }

  const chosenMethod = method ?? state.selectedHackTool;

  // Handle Echo Detonate (global resonance pulse)
  if (chosenMethod === 'echo_detonate') {
    const energyCost = 30;
    if (state.player.neuralEnergy < energyCost) {
      return {
        success: false,
        message: 'INSUFFICIENT NEURAL ENERGY FOR ECHO DETONATION',
        affectedEnemies: 0,
      };
    }
    state.player.neuralEnergy -= energyCost;
    state.hitstopTimer = 0.055;
    state.cameraTrauma = Math.min(1, state.cameraTrauma + 0.55);

    const dominantPolarity: EchoPolarity =
      state.ghostEchoCount >= state.surgeEchoCount ? 'ghost' : 'surge';
    let affected = 0;

    if (dominantPolarity === 'ghost') {
      state.player.cloakTimer = 3.5 + state.ghostEchoCount * 0.6;
      state.traceLevel = Math.max(0, state.traceLevel - 22);
      for (const en of state.enemies) {
        if (en.state !== 'ko') {
          en.state = 'stunned';
          en.stateTimer = 2.0;
          affected++;
        }
      }
      state.narrativeLog =
        'CONSEQUENCE ECHO RESONANCE // GHOST VEIL CLOAKED REALITY & FROZE ENFORCER OPTICS!';
    } else {
      const surgeDmg = 28 + state.surgeEchoCount * 10;
      for (const en of state.enemies) {
        if (en.state !== 'ko') {
          en.shieldActive = false;
          en.hp -= surgeDmg;
          en.hitFlashTimer = 0.12;
          if (en.hp <= 0) {
            en.hp = 0;
            en.state = 'ko';
            en.koTimer = 0.45;
            state.score += 180;
          } else {
            en.state = 'stunned';
            en.stateTimer = 2.2;
          }
          affected++;
        }
      }
      state.narrativeLog = `CONSEQUENCE ECHO RESONANCE // SURGE EMP DETONATED (${surgeDmg} DMG TO ALL UNITS)!`;
    }
    state.score += 120;
    return {
      success: true,
      message: state.narrativeLog,
      affectedEnemies: affected,
    };
  }

  // Find target CyberNode (by ID or nearest unhacked, or nearest overall)
  let node: CyberNode | undefined;
  if (targetNodeId) {
    node = state.nodes.find((n) => n.id === targetNodeId);
  }
  if (!node) {
    let bestDist = Infinity;
    for (const candidate of state.nodes) {
      const d = Math.hypot(
        candidate.gx - state.player.x,
        candidate.gz - state.player.z,
      );
      const priorityBias = candidate.hacked ? 2.5 : 0;
      if (d + priorityBias < bestDist) {
        bestDist = d + priorityBias;
        node = candidate;
      }
    }
  }

  if (!node) {
    return { success: false, message: 'No CyberNode in range.', affectedEnemies: 0 };
  }

  const energyCost = chosenMethod === 'ghost_bypass' ? 18 : 22;
  if (state.player.neuralEnergy < energyCost) {
    return {
      success: false,
      message: 'LOW NEURAL ENERGY — EVADE OR COLLECT ENERGY',
      affectedEnemies: 0,
    };
  }

  state.player.neuralEnergy -= energyCost;
  const polarity: EchoPolarity =
    chosenMethod === 'ghost_bypass' ? 'ghost' : 'surge';
  const wasAlreadyHacked = node.hacked;
  node.hacked = true;
  node.polarity = polarity;
  node.pulseTimer = 1.2;

  // Unlock linked physical Security Gate
  if (node.linkedGateId) {
    const gate = state.gates.find((g) => g.id === node.linkedGateId);
    if (gate) gate.isOpen = true;
  }

  // Unlock linked physical Data Vault
  if (node.linkedVaultId) {
    const vault = state.vaults.find((v) => v.id === node.linkedVaultId);
    if (vault) vault.unlocked = true;
  }

  // Check if all primary nodes are hacked -> also unlock any remaining vault/gate
  const allNodesHacked = state.nodes.every((n) => n.hacked);
  if (allNodesHacked) {
    for (const g of state.gates) g.isOpen = true;
    for (const v of state.vaults) v.unlocked = true;
  }

  let affectedEnemies = 0;
  if (polarity === 'ghost') {
    state.hitstopTimer = 0.035;
    state.cameraTrauma = Math.min(1, state.cameraTrauma + 0.25);
    // Reprogram closest enemy within 3.2 tiles into a distracted/hacked state
    for (const en of state.enemies) {
      if (en.state === 'ko') continue;
      const dist = Math.hypot(en.x - node.gx, en.z - node.gz);
      if (dist <= 3.2) {
        en.shieldActive = false;
        en.state = 'hacked_ally';
        en.stateTimer = 4.5 + state.ghostEchoCount * 0.8;
        en.hitFlashTimer = 0.1;
        affectedEnemies++;
      }
    }
    if (!wasAlreadyHacked) {
      recordConsequenceEcho(
        state,
        `Ghost Subversion: ${node.label}`,
        'ghost',
        'Lowered Corp Trace & hijacked local Enforcer optics',
      );
    }
    state.score += 150;
    state.narrativeLog = `DUAL HACK [GHOST BYPASS] // ${node.label} SUBVERTED. Physical security altered!`;
  } else {
    state.hitstopTimer = 0.06;
    state.cameraTrauma = Math.min(1, state.cameraTrauma + 0.5);
    const dmg = 34 + state.surgeEchoCount * 9;
    for (const en of state.enemies) {
      if (en.state === 'ko') continue;
      const dist = Math.hypot(en.x - node.gx, en.z - node.gz);
      if (dist <= 2.8) {
        en.shieldActive = false;
        en.hp -= dmg;
        en.hitFlashTimer = 0.12;
        if (en.hp <= 0) {
          en.hp = 0;
          en.state = 'ko';
          en.koTimer = 0.45;
          state.score += 200;
        } else {
          en.state = 'stunned';
          en.stateTimer = 1.8;
        }
        affectedEnemies++;
      }
    }
    if (!wasAlreadyHacked) {
      recordConsequenceEcho(
        state,
        `Voltage Surge: ${node.label}`,
        'surge',
        `Overloaded physical grid (${dmg} EMP dmg) & shattered shields`,
      );
    }
    state.score += 175;
    state.narrativeLog = `DUAL HACK [VOLTAGE SURGE] // ${node.label} OVERLOADED! Physical EMP discharged!`;
  }

  return {
    success: true,
    message: state.narrativeLog,
    hackedNode: node,
    affectedEnemies,
  };
}

/**
 * Resolves a branching narrative dilemma when the player breaches a Data Vault.
 */
export function resolveVaultDilemma(
  state: GameWorldState,
  choicePolarity: EchoPolarity,
): boolean {
  if (!state.activeDilemma) return false;
  const vault = state.vaults.find((v) => v.id === state.activeDilemma?.vaultId);
  if (!vault) {
    state.activeDilemma = null;
    return false;
  }

  vault.breached = true;
  state.activeDilemma = null;

  if (choicePolarity === 'ghost') {
    recordConsequenceEcho(
      state,
      vault.ghostEchoTitle,
      'ghost',
      vault.ghostEffect,
    );
    state.player.hp = Math.min(state.player.maxHp, state.player.hp + 20);
    state.player.cloakTimer = 3.0;
    state.narrativeLog = `ECHO FORGED [${vault.ghostEchoTitle.toUpperCase()}] // Extraction Beacon is now ONLINE at North Plaza!`;
  } else {
    recordConsequenceEcho(
      state,
      vault.surgeEchoTitle,
      'surge',
      vault.surgeEffect,
    );
    // Deal surge damage to all active enemies
    for (const en of state.enemies) {
      if (en.state !== 'ko') {
        en.shieldActive = false;
        en.hp = Math.max(10, en.hp - 30);
        en.state = 'stunned';
        en.stateTimer = 2.0;
      }
    }
    state.narrativeLog = `ECHO FORGED [${vault.surgeEchoTitle.toUpperCase()}] // Extraction Beacon is now ONLINE at North Plaza!`;
  }

  state.score += 350;
  state.extractionPoint.active = true;
  for (const g of state.gates) g.isOpen = true;
  return true;
}

/**
 * Advances simulation by clamped dt.
 */
export function stepGameWorld(
  state: GameWorldState,
  rawDt: number,
  input: {
    moveX: number;
    moveZ: number;
    dashJustPressed?: boolean;
    hackJustPressed?: boolean;
  },
): {
  playerHit: boolean;
  enemyKilled: boolean;
  vaultTriggered: boolean;
  sectorCleared: boolean;
  gameEnded: boolean;
} {
  const events = {
    playerHit: false,
    enemyKilled: false,
    vaultTriggered: false,
    sectorCleared: false,
    gameEnded: false,
  };

  if (state.mode !== 'playing') return events;

  const dt = Math.min(Math.max(rawDt, 0), 0.05);
  state.elapsedSec += dt;

  // Decay camera trauma & hit flashes in real dt
  state.cameraTrauma = Math.max(0, state.cameraTrauma - dt * 1.8);
  state.player.hitFlashTimer = Math.max(0, state.player.hitFlashTimer - dt);
  state.player.squashX += (1 - state.player.squashX) * Math.min(1, dt * 14);
  state.player.squashY += (1 - state.player.squashY) * Math.min(1, dt * 14);

  for (const en of state.enemies) {
    en.hitFlashTimer = Math.max(0, en.hitFlashTimer - dt);
  }

  // Hitstop pauses simulation physics briefly on heavy impacts
  if (state.hitstopTimer > 0) {
    state.hitstopTimer = Math.max(0, state.hitstopTimer - dt);
    return events;
  }

  // Pause movement while player is choosing a narrative dilemma
  if (state.activeDilemma) {
    return events;
  }

  // Regenerate Neural Energy (boosted by Ghost Echoes)
  const regenRate = 9 + state.ghostEchoCount * 2.5;
  state.player.neuralEnergy = Math.min(
    state.player.maxNeuralEnergy,
    state.player.neuralEnergy + regenRate * dt,
  );

  state.player.cloakTimer = Math.max(0, state.player.cloakTimer - dt);
  state.player.invulnTimer = Math.max(0, state.player.invulnTimer - dt);
  state.player.dashCooldown = Math.max(0, state.player.dashCooldown - dt);

  // Handle Dash / Phase Step
  let speed = 3.1;
  if (input.dashJustPressed && state.player.dashCooldown <= 0) {
    state.player.dashCooldown = 1.1;
    state.player.invulnTimer = 0.28;
    state.player.squashX = 0.82;
    state.player.squashY = 1.2;
    speed = 8.5;
  }

  // Normalize movement vector
  const mag = Math.hypot(input.moveX, input.moveZ);
  const nx = mag > 0.01 ? input.moveX / mag : 0;
  const nz = mag > 0.01 ? input.moveZ / mag : 0;

  state.player.vx = nx * speed;
  state.player.vz = nz * speed;

  if (mag > 0.01) {
    state.player.facingAngle = Math.atan2(nx, -nz);
    state.player.stepBobPhase += mag * speed * dt * 3.5;
  }

  const nextX = Math.max(0.4, Math.min(GRID_SIZE - 0.4, state.player.x + state.player.vx * dt));
  const nextZ = Math.max(0.4, Math.min(GRID_SIZE - 0.4, state.player.z + state.player.vz * dt));

  // Check obstacle and closed-gate collisions
  if (!isBlockedAt(state, nextX, state.player.z)) {
    state.player.x = nextX;
  }
  if (!isBlockedAt(state, state.player.x, nextZ)) {
    state.player.z = nextZ;
  }

  // Edge-triggered hack action
  if (input.hackJustPressed) {
    executeDualHack(state);
  }

  // Check proximity to unlocked Data Vaults
  for (const vault of state.vaults) {
    if (!vault.breached) {
      const dist = Math.hypot(state.player.x - vault.gx, state.player.z - vault.gz);
      if (dist < 0.78) {
        if (!vault.unlocked) {
          // Auto-unlock if player reaches it with enough neural energy
          vault.unlocked = true;
        }
        state.activeDilemma = {
          vaultId: vault.id,
          title: vault.dilemmaTitle,
          ghostLabel: vault.ghostChoiceLabel,
          surgeLabel: vault.surgeChoiceLabel,
        };
        events.vaultTriggered = true;
        return events;
      }
    }
  }

  // Check proximity to Extraction Point
  if (state.extractionPoint.active) {
    const dist = Math.hypot(
      state.player.x - state.extractionPoint.gx,
      state.player.z - state.extractionPoint.gz,
    );
    if (dist < 0.85) {
      state.score += 500;
      if (state.sector < state.maxSectors) {
        loadSectorIntoState(state, state.sector + 1);
        events.sectorCleared = true;
      } else {
        finalizeRun(state, 'victory');
        events.gameEnded = true;
      }
      return events;
    }
  }

  // Surge Echo node arc damage: hacked surge nodes zap nearby enemies
  for (const node of state.nodes) {
    node.pulseTimer = Math.max(0, node.pulseTimer - dt);
    if (node.hacked && node.polarity === 'surge' && state.surgeEchoCount > 0) {
      for (const en of state.enemies) {
        if (en.state === 'ko') continue;
        const d = Math.hypot(en.x - node.gx, en.z - node.gz);
        if (d < 1.5) {
          en.hp -= (8 + state.surgeEchoCount * 3) * dt;
          if (en.hp <= 0) {
            en.hp = 0;
            en.state = 'ko';
            en.koTimer = 0.45;
            state.score += 150;
            events.enemyKilled = true;
          }
        }
      }
    }
  }

  // Update Enemies with Crowd Token Pool for windup telegraphs
  let activeWindups = state.enemies.filter((e) => e.state === 'windup').length;

  for (const en of state.enemies) {
    if (en.state === 'ko') {
      en.koTimer = Math.max(0, en.koTimer - dt);
      continue;
    }

    if (en.state === 'stunned' || en.state === 'hacked_ally') {
      en.stateTimer -= dt;
      if (en.stateTimer <= 0) {
        en.state = 'patrol';
      }
      continue;
    }

    if (en.state === 'recover') {
      en.stateTimer -= dt;
      if (en.stateTimer <= 0) {
        en.state = 'chase';
      }
      continue;
    }

    const dx = state.player.x - en.x;
    const dz = state.player.z - en.z;
    const distToPlayer = Math.hypot(dx, dz);
    const playerCloaked = state.player.cloakTimer > 0;

    if (en.state === 'windup') {
      en.stateTimer -= dt;
      if (en.stateTimer <= 0) {
        // Execute telegraphed attack!
        const hitRadius =
          en.archetype === 'swarmer' ? 1.05 : en.archetype === 'charger' ? 1.35 : 3.8;
        const currentDist = Math.hypot(
          state.player.x - en.targetX,
          state.player.z - en.targetZ,
        );

        if (
          !playerCloaked &&
          state.player.invulnTimer <= 0 &&
          (currentDist <= 1.15 || distToPlayer <= (en.archetype === 'swarmer' ? 1.0 : 0.85))
        ) {
          const dmg =
            en.archetype === 'swarmer' ? 16 : en.archetype === 'kiter' ? 18 : 24;
          state.player.hp = Math.max(0, state.player.hp - dmg);
          state.player.invulnTimer = 0.65;
          state.player.hitFlashTimer = 0.18;
          state.player.squashX = 1.25;
          state.player.squashY = 0.75;
          state.hitstopTimer = 0.05;
          state.cameraTrauma = Math.min(1, state.cameraTrauma + 0.65);
          state.traceLevel = Math.min(100, state.traceLevel + 6);
          events.playerHit = true;

          if (state.player.hp <= 0) {
            finalizeRun(state, 'defeat');
            events.gameEnded = true;
            return events;
          }
        }
        en.state = 'recover';
        en.stateTimer = 0.65;
      }
      continue;
    }

    // Distinct movement & decision policies per archetype
    if (playerCloaked || distToPlayer > 4.6) {
      en.state = 'patrol';
      en.patrolPhase += dt * 1.4;
      const tx = en.patrolOriginX + Math.cos(en.patrolPhase) * 0.9;
      const tz = en.patrolOriginZ + Math.sin(en.patrolPhase) * 0.6;
      const pdx = tx - en.x;
      const pdz = tz - en.z;
      en.x += pdx * dt * 1.5;
      en.z += pdz * dt * 1.5;
      en.facingAngle = Math.atan2(pdx, -pdz);
    } else {
      en.state = 'chase';
      en.facingAngle = Math.atan2(dx, -dz);

      if (en.archetype === 'swarmer') {
        // Policy 1: Direct aggressive pursuit + melee spin telegraph
        if (distToPlayer > 0.85) {
          en.x += (dx / distToPlayer) * 1.85 * dt;
          en.z += (dz / distToPlayer) * 1.85 * dt;
        } else if (activeWindups < MAX_CONCURRENT_ATTACKERS) {
          en.state = 'windup';
          en.stateTimer = en.windupDuration;
          en.targetX = state.player.x;
          en.targetZ = state.player.z;
          activeWindups++;
        }
      } else if (en.archetype === 'kiter') {
        // Policy 2: Kiter/Ranged maintains 2.2 - 3.4m distance & backs away if approached
        if (distToPlayer < 2.0) {
          en.x = Math.max(0.5, Math.min(GRID_SIZE - 0.5, en.x - (dx / distToPlayer) * 1.5 * dt));
          en.z = Math.max(0.5, Math.min(GRID_SIZE - 0.5, en.z - (dz / distToPlayer) * 1.5 * dt));
        } else if (distToPlayer > 3.4) {
          en.x += (dx / distToPlayer) * 1.3 * dt;
          en.z += (dz / distToPlayer) * 1.3 * dt;
        } else if (activeWindups < MAX_CONCURRENT_ATTACKERS) {
          en.state = 'windup';
          en.stateTimer = en.windupDuration;
          en.targetX = state.player.x;
          en.targetZ = state.player.z;
          activeWindups++;
        }
      } else if (en.archetype === 'charger') {
        // Policy 3: Line-of-sight heavy charger with frontal shield
        if (distToPlayer > 1.8) {
          en.x += (dx / distToPlayer) * 1.15 * dt;
          en.z += (dz / distToPlayer) * 1.15 * dt;
        }
        if (distToPlayer <= 2.3 && activeWindups < MAX_CONCURRENT_ATTACKERS) {
          en.state = 'windup';
          en.stateTimer = en.windupDuration;
          en.targetX = state.player.x;
          en.targetZ = state.player.z;
          activeWindups++;
        }
      }
    }
  }

  return events;
}

export function isBlockedAt(state: GameWorldState, x: number, z: number): boolean {
  for (const obs of state.obstacles) {
    if (Math.hypot(x - obs.gx, z - obs.gz) < 0.52) return true;
  }
  for (const gate of state.gates) {
    if (!gate.isOpen && Math.abs(z - gate.gz) < 0.38 && Math.abs(x - gate.gx) < 0.85) {
      return true;
    }
  }
  return false;
}

export function finalizeRun(
  state: GameWorldState,
  outcome: 'victory' | 'defeat',
): RunSnapshot {
  state.mode = 'gameover';
  state.outcome = outcome;
  state.bestScore = Math.max(state.bestScore, state.score);

  let endingTitle = 'SIGNAL SEVERED // NEURAL FLATLINE';
  let endingSummary =
    'Aethelgard Security traced your dual-deck signature before Project Eclipse could be dismantled.';

  if (outcome === 'victory') {
    if (state.ghostEchoCount > state.surgeEchoCount) {
      endingTitle = 'ENDING A // PHANTOM ARCHITECT OF NEON SHADOWS';
      endingSummary =
        'Your Ghost Consequence Echoes silently rewrote the megacorp sub-net, liberating citizen neural implants without triggering a single citywide blackout.';
    } else if (state.surgeEchoCount > state.ghostEchoCount) {
      endingTitle = 'ENDING B // SUPERNOVA SYNDICATE MELTDOWN';
      endingSummary =
        'Your Surge Consequence Echoes overloaded Project Eclipse in a cascading EMP storm, shattering Aethelgard Corp’s orbital control grid forever.';
    } else {
      endingTitle = 'ENDING C // DUAL-REALM EQUILIBRIUM';
      endingSummary =
        'Balancing stealth Ghost subversions with surgical Voltage Surges, you vanished between the physical and digital realms as a legend of the sprawl.';
    }
  }

  const snapshot: RunSnapshot = {
    score: Math.round(state.score),
    bestScore: Math.round(state.bestScore),
    sectorReached: state.sector,
    totalSectors: state.maxSectors,
    echoesCount: state.echoes.length,
    ghostCount: state.ghostEchoCount,
    surgeCount: state.surgeEchoCount,
    traceLevel: Math.round(state.traceLevel),
    clearTimeSec: Math.round(state.elapsedSec),
    outcome,
    endingTitle,
    endingSummary,
  };

  state.runSnapshot = snapshot;
  return snapshot;
}
