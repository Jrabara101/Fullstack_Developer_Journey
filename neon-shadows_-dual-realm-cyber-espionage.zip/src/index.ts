import * as xb from 'xrblocks';
import { NeonShadowsScript } from './xr/NeonShadowsScript';

document.addEventListener('DOMContentLoaded', () => {
  const options = new xb.Options();
  options.setAppTitle('Neon Shadows');
  options.setAppDescription(
    'Dual-Realm Cyber Espionage & Consequence Echo Tactics in XR Blocks',
  );
  xb.add(new NeonShadowsScript());
  void xb.init(options);
});
