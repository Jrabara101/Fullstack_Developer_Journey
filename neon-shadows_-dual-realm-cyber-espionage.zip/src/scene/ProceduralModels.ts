import * as THREE from 'three';
import { EnemyArchetype } from '../game/rules';

// Module-scoped reusable math helpers (Zero GC in update loops)
const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _color = new THREE.Color();

export function createCyberGridTextures(maxAnisotropy = 4): {
  albedoMap: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep obsidian-slate asphalt base
  ctx.fillStyle = '#090d18';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle tile subdivisions
  ctx.strokeStyle = '#16233d';
  ctx.lineWidth = 2;
  const step = 64;
  for (let i = 0; i <= 512; i += step) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 512);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(512, i);
    ctx.stroke();
  }

  // Cyan/Teal circuit traces & corner micro-marks
  ctx.strokeStyle = 'rgba(0, 240, 255, 0.28)';
  ctx.lineWidth = 2;
  for (let y = 0; y < 512; y += 128) {
    for (let x = 0; x < 512; x += 128) {
      ctx.strokeRect(x + 8, y + 8, 112, 112);
      ctx.fillStyle = 'rgba(0, 240, 255, 0.45)';
      ctx.fillRect(x + 6, y + 6, 6, 6);
      ctx.fillRect(x + 116, y + 116, 6, 6);
    }
  }

  const albedoMap = new THREE.CanvasTexture(canvas);
  albedoMap.colorSpace = THREE.SRGBColorSpace;
  albedoMap.wrapS = THREE.RepeatWrapping;
  albedoMap.wrapT = THREE.RepeatWrapping;
  albedoMap.repeat.set(3.5, 3.5);
  albedoMap.anisotropy = maxAnisotropy;

  // Grayscale bump map for surface micro-relief
  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = 256;
  bumpCanvas.height = 256;
  const bctx = bumpCanvas.getContext('2d')!;
  bctx.fillStyle = '#808080';
  bctx.fillRect(0, 0, 256, 256);
  bctx.strokeStyle = '#ffffff';
  bctx.lineWidth = 2;
  for (let i = 0; i <= 256; i += 32) {
    bctx.beginPath();
    bctx.moveTo(i, 0);
    bctx.lineTo(i, 256);
    bctx.stroke();
    bctx.beginPath();
    bctx.moveTo(0, i);
    bctx.lineTo(256, i);
    bctx.stroke();
  }

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.colorSpace = THREE.NoColorSpace;
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(3.5, 3.5);
  bumpMap.anisotropy = maxAnisotropy;

  return { albedoMap, bumpMap };
}

export function createRadialShadowMaterial(): THREE.MeshBasicMaterial {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.72)');
  grad.addColorStop(0.6, 'rgba(0, 8, 20, 0.35)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    depthWrite: false,
    opacity: 0.85,
  });
}

/**
 * Builds the 8-part Rogue Hacker Hero ("Shade") mesh group pivoted at y = 0.
 */
export function createRogueHackerModel(
  shadowMat: THREE.MeshBasicMaterial,
): {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  visorMat: THREE.MeshStandardMaterial;
  bladeMat: THREE.MeshStandardMaterial;
  cloakRing: THREE.Mesh;
} {
  const root = new THREE.Group();
  root.name = 'RogueHackerHero';

  // 1. Soft radial contact shadow flush with floor
  const shadowDisc = new THREE.Mesh(
    new THREE.CircleGeometry(0.068, 24),
    shadowMat,
  );
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.003;
  root.add(shadowDisc);

  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const coatMat = new THREE.MeshStandardMaterial({
    color: 0x101829,
    roughness: 0.78,
    metalness: 0.22,
  });
  const armorMat = new THREE.MeshStandardMaterial({
    color: 0x263859,
    roughness: 0.32,
    metalness: 0.82,
  });
  const visorMat = new THREE.MeshStandardMaterial({
    color: 0x00f2fe,
    emissive: 0x00d8ff,
    emissiveIntensity: 1.8,
    roughness: 0.12,
    metalness: 0.9,
  });
  const bladeMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x00f2fe,
    emissiveIntensity: 1.4,
    roughness: 0.2,
    metalness: 0.88,
  });

  // 2. Boots / Lower Stance (2 parts)
  const bootGeo = new THREE.CylinderGeometry(0.014, 0.018, 0.042, 12);
  const leftBoot = new THREE.Mesh(bootGeo, armorMat);
  leftBoot.position.set(-0.02, 0.021, 0);
  const rightBoot = new THREE.Mesh(bootGeo, armorMat);
  rightBoot.position.set(0.02, 0.021, 0);
  bodyGroup.add(leftBoot, rightBoot);

  // 3. Flared Cyberpunk Trench Coat Skirt (LatheGeometry silhouette)
  const coatPoints = [
    new THREE.Vector2(0.038, 0.03),
    new THREE.Vector2(0.032, 0.075),
    new THREE.Vector2(0.026, 0.115),
  ];
  const coatSkirt = new THREE.Mesh(
    new THREE.LatheGeometry(coatPoints, 16),
    coatMat,
  );
  bodyGroup.add(coatSkirt);

  // 4. Armored Cyber-Deck Torso
  const torso = new THREE.Mesh(
    new THREE.BoxGeometry(0.056, 0.062, 0.038),
    armorMat,
  );
  torso.position.y = 0.112;
  bodyGroup.add(torso);

  // 5. High Collar & Hooded Head
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.024, 16, 14),
    coatMat,
  );
  head.position.y = 0.162;
  bodyGroup.add(head);

  // 6. Glowing Cyan Wrap-Around Optic Visor
  const visor = new THREE.Mesh(
    new THREE.BoxGeometry(0.036, 0.011, 0.022),
    visorMat,
  );
  visor.position.set(0, 0.162, -0.016);
  bodyGroup.add(visor);

  // 7. Neural-Deck Forearm Gauntlets (Left & Right)
  const armGeo = new THREE.BoxGeometry(0.016, 0.052, 0.02);
  const leftArm = new THREE.Mesh(armGeo, coatMat);
  leftArm.position.set(-0.038, 0.108, -0.008);
  leftArm.rotation.x = 0.35;
  const rightArm = new THREE.Mesh(armGeo, coatMat);
  rightArm.position.set(0.038, 0.108, -0.008);
  rightArm.rotation.x = 0.35;
  bodyGroup.add(leftArm, rightArm);

  // 8. High-Frequency Data-Katana on Back/Hip
  const katana = new THREE.Mesh(
    new THREE.BoxGeometry(0.006, 0.11, 0.012),
    bladeMat,
  );
  katana.position.set(0.032, 0.125, 0.022);
  katana.rotation.set(-0.45, 0, -0.35);
  bodyGroup.add(katana);

  // 9. Phase-Cloak Hologram Ring
  const cloakRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.055, 0.0035, 10, 28),
    new THREE.MeshBasicMaterial({
      color: 0x00f2fe,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    }),
  );
  cloakRing.rotation.x = Math.PI / 2;
  cloakRing.position.y = 0.09;
  root.add(cloakRing);

  return { root, bodyGroup, visorMat, bladeMat, cloakRing };
}

/**
 * Builds a multi-part Corporate Enemy Unit with distinct silhouette & palette per archetype.
 */
export function createEnemyModel(
  archetype: EnemyArchetype,
  shadowMat: THREE.MeshBasicMaterial,
): {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  primaryMat: THREE.MeshStandardMaterial;
  accentMat: THREE.MeshStandardMaterial;
  shieldMesh: THREE.Mesh | null;
  telegraphRing: THREE.Mesh;
  telegraphBeam: THREE.Mesh;
} {
  const root = new THREE.Group();
  root.name = `Enemy_${archetype}`;

  // Contact shadow disc
  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.065, 20),
    shadowMat,
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.003;
  root.add(shadow);

  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const isSwarmer = archetype === 'swarmer';
  const isKiter = archetype === 'kiter';

  const primaryColor = isSwarmer ? 0x3b121e : isKiter ? 0x38260d : 0x281542;
  const accentColor = isSwarmer ? 0xff2a6d : isKiter ? 0xf59e0b : 0xa855f7;

  const primaryMat = new THREE.MeshStandardMaterial({
    color: primaryColor,
    roughness: 0.38,
    metalness: 0.78,
  });
  const secondaryMat = new THREE.MeshStandardMaterial({
    color: 0x161b26,
    roughness: 0.72,
    metalness: 0.35,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: accentColor,
    emissive: accentColor,
    emissiveIntensity: 1.5,
    roughness: 0.15,
    metalness: 0.9,
  });

  let shieldMesh: THREE.Mesh | null = null;

  if (isSwarmer) {
    // Archetype 1: Crimson Enforcer Hunter-Hound Drone (6 parts)
    const chassis = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.042, 1),
      primaryMat,
    );
    chassis.position.y = 0.095;
    chassis.scale.set(1.1, 0.75, 1.35);
    bodyGroup.add(chassis);

    const eye = new THREE.Mesh(
      new THREE.SphereGeometry(0.016, 12, 12),
      accentMat,
    );
    eye.position.set(0, 0.096, -0.045);
    bodyGroup.add(eye);

    const wingGeo = new THREE.BoxGeometry(0.095, 0.008, 0.032);
    const wings = new THREE.Mesh(wingGeo, secondaryMat);
    wings.position.set(0, 0.105, 0.005);
    bodyGroup.add(wings);

    const bladeL = new THREE.Mesh(
      new THREE.ConeGeometry(0.012, 0.055, 8),
      accentMat,
    );
    bladeL.rotation.x = -Math.PI / 2;
    bladeL.position.set(-0.042, 0.092, -0.035);
    const bladeR = bladeL.clone();
    bladeR.position.x = 0.042;
    bodyGroup.add(bladeL, bladeR);
  } else if (isKiter) {
    // Archetype 2: Amber Suppressor Sniper Mech (6 parts)
    const legGeo = new THREE.CylinderGeometry(0.01, 0.014, 0.08, 10);
    const legL = new THREE.Mesh(legGeo, secondaryMat);
    legL.position.set(-0.022, 0.04, 0);
    const legR = new THREE.Mesh(legGeo, secondaryMat);
    legR.position.set(0.022, 0.04, 0);
    bodyGroup.add(legL, legR);

    const pod = new THREE.Mesh(
      new THREE.CylinderGeometry(0.028, 0.034, 0.065, 12),
      primaryMat,
    );
    pod.position.y = 0.105;
    bodyGroup.add(pod);

    const railBarrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.007, 0.009, 0.095, 10),
      secondaryMat,
    );
    railBarrel.rotation.x = Math.PI / 2;
    railBarrel.position.set(0.026, 0.115, -0.042);
    bodyGroup.add(railBarrel);

    const optic = new THREE.Mesh(
      new THREE.BoxGeometry(0.032, 0.014, 0.02),
      accentMat,
    );
    optic.position.set(0, 0.122, -0.026);
    bodyGroup.add(optic);
  } else {
    // Archetype 3: Violet Aegis Heavy Juggernaut with Front Riot Shield (7 parts)
    const baseTread = new THREE.Mesh(
      new THREE.CylinderGeometry(0.046, 0.052, 0.05, 16),
      secondaryMat,
    );
    baseTread.position.y = 0.025;
    bodyGroup.add(baseTread);

    const hulkTorso = new THREE.Mesh(
      new THREE.BoxGeometry(0.078, 0.088, 0.062),
      primaryMat,
    );
    hulkTorso.position.y = 0.092;
    bodyGroup.add(hulkTorso);

    const pylonL = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.045, 0.035),
      accentMat,
    );
    pylonL.position.set(-0.044, 0.135, 0);
    const pylonR = pylonL.clone();
    pylonR.position.x = 0.044;
    bodyGroup.add(pylonL, pylonR);

    // Frontal Energy Riot Shield
    shieldMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(
        0.062,
        0.062,
        0.115,
        16,
        1,
        true,
        -Math.PI * 0.38,
        Math.PI * 0.76,
      ),
      new THREE.MeshStandardMaterial({
        color: 0xc084fc,
        emissive: 0x9333ea,
        emissiveIntensity: 1.2,
        transparent: true,
        opacity: 0.68,
        roughness: 0.15,
        metalness: 0.85,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
    shieldMesh.rotation.y = Math.PI;
    shieldMesh.position.set(0, 0.088, -0.01);
    bodyGroup.add(shieldMesh);
  }

  // Telegraph Ground Target Ring (expands/flashes during windup)
  const telegraphRing = new THREE.Mesh(
    new THREE.RingGeometry(0.052, 0.072, 24),
    new THREE.MeshBasicMaterial({
      color: accentColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    }),
  );
  telegraphRing.rotation.x = -Math.PI / 2;
  telegraphRing.position.y = 0.006;
  root.add(telegraphRing);

  // Telegraph Aim Sight Line (used for Kiter/Charger windups)
  const beamGeo = new THREE.PlaneGeometry(0.016, 0.35);
  beamGeo.translate(0, 0.175, 0);
  const telegraphBeam = new THREE.Mesh(
    beamGeo,
    new THREE.MeshBasicMaterial({
      color: accentColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    }),
  );
  telegraphBeam.rotation.x = -Math.PI / 2;
  telegraphBeam.position.y = 0.012;
  root.add(telegraphBeam);

  return {
    root,
    bodyGroup,
    primaryMat,
    accentMat,
    shieldMesh,
    telegraphRing,
    telegraphBeam,
  };
}

/**
 * Builds an interactive Cyberspace Net-Node floating in the upper holographic layer
 * with a vertical fiber-optic tether linking it to the physical realm below.
 */
export function createCyberNodeModel(kind: string): {
  root: THREE.Group;
  coreMesh: THREE.Mesh;
  outerRing: THREE.Mesh;
  coreMat: THREE.MeshStandardMaterial;
  beamMat: THREE.MeshBasicMaterial;
} {
  const root = new THREE.Group();

  const baseHue =
    kind === 'firewall'
      ? 0xff2a6d
      : kind === 'vault_cipher'
        ? 0xfbbf24
        : 0x00f2fe;

  const coreMat = new THREE.MeshStandardMaterial({
    color: baseHue,
    emissive: baseHue,
    emissiveIntensity: 1.6,
    roughness: 0.18,
    metalness: 0.85,
  });

  const frameMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.45,
    metalness: 0.8,
  });

  // 1. Octahedral Data Core
  const coreMesh = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.042, 0),
    coreMat,
  );
  root.add(coreMesh);

  // 2. Gyroscopic Outer Ring
  const outerRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.062, 0.0055, 10, 28),
    frameMat,
  );
  root.add(outerRing);

  // 3. Top & Bottom Cyber Pylons
  const capGeo = new THREE.ConeGeometry(0.018, 0.028, 6);
  const topCap = new THREE.Mesh(capGeo, frameMat);
  topCap.position.y = 0.065;
  const botCap = new THREE.Mesh(capGeo, frameMat);
  botCap.rotation.x = Math.PI;
  botCap.position.y = -0.065;
  root.add(topCap, botCap);

  // 4. Vertical Dual-Realm Laser Tether down to Physical Layer (-0.36m)
  const beamMat = new THREE.MeshBasicMaterial({
    color: baseHue,
    transparent: true,
    opacity: 0.35,
    depthWrite: false,
  });
  const tether = new THREE.Mesh(
    new THREE.CylinderGeometry(0.005, 0.014, 0.36, 10, 1, true),
    beamMat,
  );
  tether.position.y = -0.18;
  root.add(tether);

  return { root, coreMesh, outerRing, coreMat, beamMat };
}

/**
 * Pooled Zero-GC Particle System using a single THREE.InstancedMesh (64 particles).
 */
export class ParticleBurstPool {
  public readonly mesh: THREE.InstancedMesh;
  private readonly capacity = 64;
  private readonly active: Uint8Array;
  private readonly life: Float32Array;
  private readonly maxLife: Float32Array;
  private readonly px: Float32Array;
  private readonly py: Float32Array;
  private readonly pz: Float32Array;
  private readonly vx: Float32Array;
  private readonly vy: Float32Array;
  private readonly vz: Float32Array;
  private cursor = 0;

  constructor() {
    const geo = new THREE.OctahedronGeometry(0.014, 0);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.92,
    });
    this.mesh = new THREE.InstancedMesh(geo, mat, this.capacity);
    this.mesh.frustumCulled = false;

    this.active = new Uint8Array(this.capacity);
    this.life = new Float32Array(this.capacity);
    this.maxLife = new Float32Array(this.capacity);
    this.px = new Float32Array(this.capacity);
    this.py = new Float32Array(this.capacity);
    this.vz = new Float32Array(this.capacity);
    this.pz = new Float32Array(this.capacity);
    this.vx = new Float32Array(this.capacity);
    this.vy = new Float32Array(this.capacity);

    _scale.set(0, 0, 0);
    _mat4.makeScale(0, 0, 0);
    for (let i = 0; i < this.capacity; i++) {
      this.mesh.setMatrixAt(i, _mat4);
      this.mesh.setColorAt(i, _color.setHex(0x00f2fe));
    }
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  public emitBurst(
    x: number,
    y: number,
    z: number,
    hexColor: number,
    count = 14,
    speed = 0.65,
  ): void {
    _color.setHex(hexColor);
    for (let n = 0; n < count; n++) {
      const i = this.cursor;
      this.cursor = (this.cursor + 1) % this.capacity;

      this.active[i] = 1;
      this.maxLife[i] = 0.28 + Math.random() * 0.24;
      this.life[i] = this.maxLife[i];
      this.px[i] = x;
      this.py[i] = y;
      this.pz[i] = z;

      const theta = Math.random() * Math.PI * 2;
      const elev = (Math.random() - 0.15) * speed;
      const rad = (0.35 + Math.random() * 0.65) * speed;
      this.vx[i] = Math.cos(theta) * rad;
      this.vy[i] = Math.abs(elev) + 0.15;
      this.vz[i] = Math.sin(theta) * rad;

      this.mesh.setColorAt(i, _color);
    }
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  public update(dt: number): void {
    let anyUpdated = false;
    for (let i = 0; i < this.capacity; i++) {
      if (!this.active[i]) continue;
      anyUpdated = true;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        this.active[i] = 0;
        _mat4.makeScale(0, 0, 0);
        this.mesh.setMatrixAt(i, _mat4);
        continue;
      }

      this.vy[i] -= 1.8 * dt;
      this.px[i] += this.vx[i] * dt;
      this.py[i] += this.vy[i] * dt;
      this.pz[i] += this.vz[i] * dt;

      const s = Math.max(0.05, this.life[i] / this.maxLife[i]);
      _pos.set(this.px[i], this.py[i], this.pz[i]);
      _quat.identity();
      _scale.setScalar(s);
      _mat4.compose(_pos, _quat, _scale);
      this.mesh.setMatrixAt(i, _mat4);
    }
    if (anyUpdated) {
      this.mesh.instanceMatrix.needsUpdate = true;
    }
  }
}
