import {
  EchoPolarity,
  GameWorldState,
  HackMethod,
} from '../game/rules';

export interface GameShellCallbacks {
  onStartGame: () => void;
  onResumeGame: () => void;
  onPauseToggle: () => void;
  onRestartGame: () => void;
  onReturnTitle: () => void;
  onMuteToggle: () => boolean;
  onSelectHackTool: (tool: HackMethod) => void;
  onTriggerHack: (tool?: HackMethod) => void;
  onToggleRealm: () => void;
  onResolveDilemma: (polarity: EchoPolarity) => void;
}

export class GameShell {
  private root: HTMLElement;
  private callbacks: GameShellCallbacks;
  private dockCollapsed = false;
  private trailingEnergy = 100;
  private lastPipStateKey = '';
  private lastEchoCount = -1;
  private lastDilemmaVaultId: string | null = null;
  private lastModalStateKey = '';

  // DOM Element refs for zero-jank updates
  private titleScreenEl!: HTMLElement;
  private hudLayerEl!: HTMLElement;
  private modalLayerEl!: HTMLElement;
  private dilemmaLayerEl!: HTMLElement;
  private vignetteEl!: HTMLElement;

  private vitalityRowEl!: HTMLElement;
  private hpNumEl!: HTMLElement;
  private energyFillEl!: HTMLElement;
  private energyGhostEl!: HTMLElement;
  private energyNumEl!: HTMLElement;
  private traceNumEl!: HTMLElement;
  private scoreNumEl!: HTMLElement;
  private sectorBadgeEl!: HTMLElement;
  private realmBadgeEl!: HTMLElement;

  private muteBtnEl!: HTMLButtonElement;
  private dockWrapperEl!: HTMLElement;
  private dockToggleBtnEl!: HTMLButtonElement;
  private toolBtns: Record<HackMethod, HTMLButtonElement> = {} as Record<
    HackMethod,
    HTMLButtonElement
  >;
  private realmBtnEl!: HTMLButtonElement;
  private echoSummaryEl!: HTMLElement;
  private narrativeTextEl!: HTMLElement;
  private npcStatusTextEl!: HTMLElement;

  constructor(callbacks: GameShellCallbacks) {
    this.callbacks = callbacks;
    this.root = document.createElement('div');
    this.root.id = 'neon-shadows-shell';
    document.body.appendChild(this.root);

    this.buildDOM();
    this.syncBodyState('title');
  }

  public syncBodyState(state: 'title' | 'playing' | 'paused' | 'gameover'): void {
    document.body.dataset.state = state;
  }

  private buildDOM(): void {
    this.root.innerHTML = `
      <!-- Low-HP Peripheral Screen Vignette -->
      <div id="ns-vignette" class="ns-vignette"></div>

      <!-- TITLE SCREEN -->
      <section id="ns-title-screen" class="ns-title-screen" aria-label="Neon Shadows Title Screen">
        <div class="ns-title-panel">
          <div class="ns-svg-lockup">
            <svg viewBox="0 0 540 148" width="100%" style="width: 100%; height: auto; display: block;" role="img" aria-label="Neon Shadows: Dual-Realm Cyber Espionage">
              <defs>
                <pattern id="cyberGridPat" width="18" height="18" patternUnits="userSpaceOnUse">
                  <path d="M 18 0 L 0 0 0 18" fill="none" stroke="#00f2fe" stroke-width="0.6" stroke-opacity="0.22"/>
                </pattern>
              </defs>
              <!-- Diegetic Cyber-Plaque Backing -->
              <polygon points="12,8 528,8 536,24 536,136 516,144 8,144 8,20" fill="#060b16" fill-opacity="0.92" stroke="#00f2fe" stroke-width="2"/>
              <rect x="12" y="12" width="518" height="126" fill="url(#cyberGridPat)"/>
              <!-- Top Corner Structural Accents -->
              <polygon points="12,8 140,8 128,16 12,16" fill="#00f2fe"/>
              <polygon points="420,144 516,144 536,136 432,136" fill="#ff2a6d"/>
              <!-- Kicker Code Readout -->
              <text x="28" y="38" fill="#38bdf8" font-family="monospace" font-size="12" font-weight="700" letter-spacing="4">SYS.DUAL_DECK // AETHELGARD SPRAWL 2096</text>
              <!-- Main Lockup Lettering -->
              <text x="29" y="91" fill="#ff2a6d" font-family="'Google Sans', sans-serif" font-size="52" font-weight="900" letter-spacing="5" opacity="0.75">NEON SHADOWS</text>
              <text x="26" y="88" fill="#f8fafc" stroke="#00f2fe" stroke-width="1.2" font-family="'Google Sans', sans-serif" font-size="52" font-weight="900" letter-spacing="5">NEON SHADOWS</text>
              <!-- Subtitle Rule & Emblem -->
              <line x1="28" y1="104" x2="508" y2="104" stroke="#1e293b" stroke-width="2"/>
              <rect x="28" y="103" width="96" height="3" fill="#00f2fe"/>
              <text x="28" y="126" fill="#cbd5e1" font-family="monospace" font-size="13" font-weight="600" letter-spacing="2.5">DUAL-REALM HACKING &amp; CONSEQUENCE ECHO TACTICS</text>
            </svg>
          </div>

          <div class="ns-title-actions">
            <button type="button" id="ns-start-btn" class="ns-cta-primary" data-start="true" aria-label="Jack In and Start Mission">
              <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
                <polygon points="4,2 20,12 4,22" fill="#040812" stroke="#00f2fe" stroke-width="1.5"/>
                <polygon points="7,6 16,12 7,18" fill="#00f2fe"/>
              </svg>
              <span>JACK IN // START MISSION</span>
            </button>
          </div>
        </div>

        <div class="ns-title-control-hint">
          WASD / Arrows Move · Space / Click Dual-Hack · 1/2/3 Cyber Deck · Q Shift Realm · Esc Pause
        </div>
      </section>

      <!-- PLAYING HUD -->
      <section id="ns-hud-layer" class="ns-hud-layer" aria-label="Tactical Cyber Deck HUD">
        <!-- Top-Left Perimeter Status Cluster -->
        <div class="ns-hud-topleft">
          <div class="ns-hud-brand-row">
            <span id="ns-sector-badge" class="ns-sector-badge">SECTOR 01 // AETHELGARD SUB-NET PLAZA</span>
            <span id="ns-realm-badge" class="ns-realm-badge" data-realm="physical">REALM: PHYSICAL</span>
          </div>

          <div class="ns-vitals-grid">
            <!-- Integrity Vitality Pips -->
            <div class="ns-vital-block">
              <span class="ns-kicker">INTEGRITY</span>
              <div class="ns-vital-row">
                <div id="ns-vitality-pips" class="ns-pips-container" aria-label="Neural Integrity Pips"></div>
                <span id="ns-hp-num" class="ns-hero-num">100</span>
              </div>
            </div>

            <!-- Neural Energy Meter with Ghost Trail -->
            <div class="ns-vital-block">
              <div class="ns-kicker-split">
                <span class="ns-kicker">NEURAL ENERGY</span>
                <span id="ns-energy-num" class="ns-sub-num">100</span>
              </div>
              <div class="ns-bar-track">
                <div id="ns-energy-ghost" class="ns-bar-ghost" style="width: 100%"></div>
                <div id="ns-energy-fill" class="ns-bar-fill" style="width: 100%"></div>
              </div>
            </div>
          </div>

          <!-- Metrics Row: Corporate Trace & Score -->
          <div class="ns-metrics-row">
            <div class="ns-metric-chip">
              <span class="ns-kicker">CORP TRACE</span>
              <span id="ns-trace-num" class="ns-metric-val ns-trace-val">10%</span>
            </div>
            <div class="ns-metric-chip">
              <span class="ns-kicker">SCORE</span>
              <span id="ns-score-num" class="ns-metric-val">0</span>
            </div>
          </div>
        </div>

        <!-- Top-Right Utility Controls -->
        <div class="ns-hud-topright">
          <button type="button" id="ns-mute-btn" class="ns-util-btn" tabindex="-1" aria-label="Mute Audio [M]" title="Mute Audio [M]">
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <polygon points="3,9 7,9 12,4 12,20 7,15 3,15" fill="#0f172a" stroke="#00f2fe" stroke-width="1.8"/>
              <path id="ns-mute-wave" d="M16 8 C18 10, 18 14, 16 16 M19 5 C22 9, 22 15, 19 19" fill="none" stroke="#38bdf8" stroke-width="1.8" stroke-linecap="round"/>
            </svg>
            <span class="ns-util-key">M</span>
          </button>
          <button type="button" id="ns-pause-btn" class="ns-util-btn" tabindex="-1" aria-label="Pause Mission [P]" title="Pause Mission [P]">
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <rect x="6" y="4" width="4" height="16" fill="#0f172a" stroke="#00f2fe" stroke-width="1.8"/>
              <rect x="14" y="4" width="4" height="16" fill="#0f172a" stroke="#00f2fe" stroke-width="1.8"/>
            </svg>
            <span class="ns-util-key">P</span>
          </button>
          <button type="button" id="ns-restart-btn" class="ns-util-btn" tabindex="-1" aria-label="Restart Sector [R]" title="Restart Sector [R]">
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path d="M4 12 A8 8 0 1 1 12 20" fill="none" stroke="#00f2fe" stroke-width="1.8" stroke-linecap="round"/>
              <polygon points="4,7 4,13 10,13" fill="#38bdf8"/>
            </svg>
            <span class="ns-util-key">R</span>
          </button>
        </div>

        <!-- Bottom-Center Unified Collapsible Tactical Dock -->
        <div id="ns-bottom-dock" class="ns-bottom-dock">
          <button type="button" id="ns-dock-toggle" class="ns-dock-collapse-btn" tabindex="-1" aria-label="Toggle Tactical Controls [H]">
            ▾ Hide Controls [H]
          </button>

          <div class="ns-dock-body">
            <!-- Comm Ticker & Consequence Echo Resonance Bar -->
            <div class="ns-comm-strip">
              <div class="ns-comm-texts">
                <div id="ns-npc-status" class="ns-npc-status">ARIA-7: LINK STABLE</div>
                <div id="ns-narrative-log" class="ns-narrative-log">Hack upper Cyberspace Nodes to alter physical security systems.</div>
              </div>
              <div id="ns-echo-summary" class="ns-echo-badges" aria-label="Consequence Echo Resonance"></div>
            </div>

            <!-- Dual-Hack Deck Slots -->
            <div class="ns-deck-slots">
              <button type="button" id="ns-tool-ghost" class="ns-deck-slot active" tabindex="-1" aria-label="Ghost Bypass Hack [1]">
                <div class="ns-slot-top">
                  <span class="ns-slot-key">[1]</span>
                  <span class="ns-slot-cost">18 EN</span>
                </div>
                <div class="ns-slot-name">Ghost Bypass</div>
                <div class="ns-slot-desc">Stealth Subvert · -12% Trace</div>
              </button>

              <button type="button" id="ns-tool-surge" class="ns-deck-slot" tabindex="-1" aria-label="Voltage Surge Hack [2]">
                <div class="ns-slot-top">
                  <span class="ns-slot-key">[2]</span>
                  <span class="ns-slot-cost">22 EN</span>
                </div>
                <div class="ns-slot-name">Voltage Surge</div>
                <div class="ns-slot-desc">AoE EMP · Break Shields</div>
              </button>

              <button type="button" id="ns-tool-echo" class="ns-deck-slot" tabindex="-1" aria-label="Echo Detonate [3]">
                <div class="ns-slot-top">
                  <span class="ns-slot-key">[3]</span>
                  <span class="ns-slot-cost">30 EN</span>
                </div>
                <div class="ns-slot-name">Echo Detonate</div>
                <div class="ns-slot-desc">Resonance Shockwave</div>
              </button>

              <button type="button" id="ns-realm-btn" class="ns-deck-slot ns-realm-slot" tabindex="-1" aria-label="Shift Active Realm [Q]">
                <div class="ns-slot-top">
                  <span class="ns-slot-key">[Q]</span>
                  <span class="ns-slot-cost">DUAL VIEW</span>
                </div>
                <div class="ns-slot-name">Shift Realm</div>
                <div class="ns-slot-desc">Physical &lt;-&gt; Cyberspace</div>
              </button>
            </div>
          </div>
        </div>
      </section>

      <!-- DATA VAULT NARRATIVE DILEMMA OVERLAY -->
      <section id="ns-dilemma-layer" class="ns-modal-backdrop" style="display: none;" aria-label="Consequence Echo Dilemma">
        <div class="ns-modal-card ns-dilemma-card">
          <div class="ns-modal-kicker">DATA VAULT BREACHED // FORGE A CONSEQUENCE ECHO</div>
          <h2 id="ns-dilemma-title" class="ns-modal-title">VAULT DILEMMA</h2>
          <p class="ns-modal-desc">Every choice leaves a persistent Consequence Echo across both realms, altering future security countermeasures and Aria-7's neural link.</p>
          <div class="ns-dilemma-choices">
            <button type="button" id="ns-dilemma-ghost" class="ns-choice-btn ns-choice-ghost">
              <span class="ns-choice-key">[1] GHOST CONSEQUENCE ECHO</span>
              <span id="ns-dilemma-ghost-label" class="ns-choice-text">Encrypt &amp; Leak to Underground</span>
            </button>
            <button type="button" id="ns-dilemma-surge" class="ns-choice-btn ns-choice-surge">
              <span class="ns-choice-key">[2] SURGE CONSEQUENCE ECHO</span>
              <span id="ns-dilemma-surge-label" class="ns-choice-text">Overload Executive Cortex Net</span>
            </button>
          </div>
        </div>
      </section>

      <!-- PAUSE / VICTORY / GAME OVER MODAL -->
      <section id="ns-modal-layer" class="ns-modal-backdrop" style="display: none;" aria-label="Mission Status Modal">
        <div id="ns-modal-content" class="ns-modal-card"></div>
      </section>
    `;

    this.titleScreenEl = this.root.querySelector('#ns-title-screen')!;
    this.hudLayerEl = this.root.querySelector('#ns-hud-layer')!;
    this.modalLayerEl = this.root.querySelector('#ns-modal-layer')!;
    this.dilemmaLayerEl = this.root.querySelector('#ns-dilemma-layer')!;
    this.vignetteEl = this.root.querySelector('#ns-vignette')!;

    this.vitalityRowEl = this.root.querySelector('#ns-vitality-pips')!;
    this.hpNumEl = this.root.querySelector('#ns-hp-num')!;
    this.energyFillEl = this.root.querySelector('#ns-energy-fill')!;
    this.energyGhostEl = this.root.querySelector('#ns-energy-ghost')!;
    this.energyNumEl = this.root.querySelector('#ns-energy-num')!;
    this.traceNumEl = this.root.querySelector('#ns-trace-num')!;
    this.scoreNumEl = this.root.querySelector('#ns-score-num')!;
    this.sectorBadgeEl = this.root.querySelector('#ns-sector-badge')!;
    this.realmBadgeEl = this.root.querySelector('#ns-realm-badge')!;

    this.muteBtnEl = this.root.querySelector('#ns-mute-btn')!;
    this.dockWrapperEl = this.root.querySelector('#ns-bottom-dock')!;
    this.dockToggleBtnEl = this.root.querySelector('#ns-dock-toggle')!;
    this.toolBtns.ghost_bypass = this.root.querySelector('#ns-tool-ghost')!;
    this.toolBtns.voltage_surge = this.root.querySelector('#ns-tool-surge')!;
    this.toolBtns.echo_detonate = this.root.querySelector('#ns-tool-echo')!;
    this.realmBtnEl = this.root.querySelector('#ns-realm-btn')!;
    this.echoSummaryEl = this.root.querySelector('#ns-echo-summary')!;
    this.narrativeTextEl = this.root.querySelector('#ns-narrative-log')!;
    this.npcStatusTextEl = this.root.querySelector('#ns-npc-status')!;

    // Wire events
    const startBtn = this.root.querySelector('#ns-start-btn') as HTMLButtonElement;
    startBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onStartGame();
    });

    this.muteBtnEl.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      const muted = this.callbacks.onMuteToggle();
      this.updateMuteIcon(muted);
    });

    const pauseBtn = this.root.querySelector('#ns-pause-btn') as HTMLButtonElement;
    pauseBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onPauseToggle();
    });

    const restartBtn = this.root.querySelector('#ns-restart-btn') as HTMLButtonElement;
    restartBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onRestartGame();
    });

    this.dockToggleBtnEl.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.toggleDockCollapse();
    });

    this.toolBtns.ghost_bypass.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onSelectHackTool('ghost_bypass');
      this.callbacks.onTriggerHack('ghost_bypass');
    });

    this.toolBtns.voltage_surge.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onSelectHackTool('voltage_surge');
      this.callbacks.onTriggerHack('voltage_surge');
    });

    this.toolBtns.echo_detonate.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onSelectHackTool('echo_detonate');
      this.callbacks.onTriggerHack('echo_detonate');
    });

    this.realmBtnEl.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onToggleRealm();
    });

    const dilemmaGhost = this.root.querySelector('#ns-dilemma-ghost') as HTMLButtonElement;
    dilemmaGhost.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onResolveDilemma('ghost');
    });

    const dilemmaSurge = this.root.querySelector('#ns-dilemma-surge') as HTMLButtonElement;
    dilemmaSurge.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onResolveDilemma('surge');
    });
  }

  public toggleDockCollapse(): void {
    this.dockCollapsed = !this.dockCollapsed;
    this.dockWrapperEl.classList.toggle('collapsed', this.dockCollapsed);
    this.dockToggleBtnEl.textContent = this.dockCollapsed
      ? '▴ Show Controls [H]'
      : '▾ Hide Controls [H]';
  }

  public updateMuteIcon(muted: boolean): void {
    const wave = this.root.querySelector('#ns-mute-wave') as SVGPathElement | null;
    if (wave) {
      wave.style.opacity = muted ? '0.18' : '1';
    }
  }

  public update(state: GameWorldState, dt: number): void {
    this.syncBodyState(state.mode);

    this.titleScreenEl.style.display = state.mode === 'title' ? 'flex' : 'none';
    this.hudLayerEl.style.display = state.mode === 'playing' ? 'block' : 'none';

    // Critical low-HP peripheral vignette
    const lowHpAlpha =
      state.mode === 'playing' && state.player.hp <= 35
        ? Math.min(0.65, (35 - state.player.hp) / 40)
        : 0;
    this.vignetteEl.style.opacity = lowHpAlpha.toFixed(2);

    // Update Dilemma Modal
    if (state.mode === 'playing' && state.activeDilemma) {
      this.dilemmaLayerEl.style.display = 'flex';
      if (this.lastDilemmaVaultId !== state.activeDilemma.vaultId) {
        this.lastDilemmaVaultId = state.activeDilemma.vaultId;
        this.root.querySelector('#ns-dilemma-title')!.textContent =
          state.activeDilemma.title;
        this.root.querySelector('#ns-dilemma-ghost-label')!.textContent =
          state.activeDilemma.ghostLabel;
        this.root.querySelector('#ns-dilemma-surge-label')!.textContent =
          state.activeDilemma.surgeLabel;
      }
    } else {
      this.dilemmaLayerEl.style.display = 'none';
      this.lastDilemmaVaultId = null;
    }

    // Update Pause / Victory / Defeat Modal
    if (state.mode === 'paused' || state.mode === 'gameover') {
      this.modalLayerEl.style.display = 'flex';
      const modalKey = `${state.mode}-${state.outcome}-${Math.round(state.score)}-${state.echoes.length}`;
      if (this.lastModalStateKey !== modalKey) {
        this.lastModalStateKey = modalKey;
        this.renderStatusModal(state);
      }
    } else {
      this.modalLayerEl.style.display = 'none';
      this.lastModalStateKey = '';
    }

    if (state.mode !== 'playing') return;

    // 1. Update Vitality Pips (5 discrete 20-HP sockets: Full, Cracked, Hollow)
    const hp = Math.max(0, Math.round(state.player.hp));
    this.hpNumEl.textContent = String(hp);
    const pipStates: string[] = [];
    for (let i = 0; i < 5; i++) {
      const thresholdFull = (i + 1) * 20;
      const thresholdHalf = i * 20 + 8;
      if (hp >= thresholdFull) pipStates.push('full');
      else if (hp >= thresholdHalf) pipStates.push('cracked');
      else pipStates.push('empty');
    }
    const pipKey = pipStates.join('-');
    if (pipKey !== this.lastPipStateKey) {
      this.lastPipStateKey = pipKey;
      this.vitalityRowEl.innerHTML = pipStates
        .map((st) => this.renderVitalityPipSVG(st as 'full' | 'cracked' | 'empty'))
        .join('');
    }

    // 2. Update Neural Energy Bar + Trailing Ghost Bar
    const energy = Math.round(state.player.neuralEnergy);
    this.energyNumEl.textContent = String(energy);
    if (this.trailingEnergy > state.player.neuralEnergy) {
      this.trailingEnergy = Math.max(
        state.player.neuralEnergy,
        this.trailingEnergy - dt * 28,
      );
    } else {
      this.trailingEnergy = state.player.neuralEnergy;
    }
    this.energyFillEl.style.width = `${Math.max(0, Math.min(100, state.player.neuralEnergy))}%`;
    this.energyGhostEl.style.width = `${Math.max(0, Math.min(100, this.trailingEnergy))}%`;

    // 3. Update Trace, Score, Sector & Realm Badges
    const trace = Math.round(state.traceLevel);
    this.traceNumEl.textContent = `${trace}%`;
    this.traceNumEl.style.color =
      trace >= 70 ? '#ff2a6d' : trace >= 40 ? '#fbbf24' : '#00f2fe';
    this.scoreNumEl.textContent = String(Math.round(state.score));
    this.sectorBadgeEl.textContent = state.sectorName;

    this.realmBadgeEl.textContent =
      state.activeRealm === 'cyber' ? 'REALM: CYBERSPACE' : 'REALM: PHYSICAL';
    this.realmBadgeEl.dataset.realm = state.activeRealm;

    // 4. Update Active Hack Tool Highlight
    (Object.keys(this.toolBtns) as HackMethod[]).forEach((k) => {
      this.toolBtns[k].classList.toggle('active', state.selectedHackTool === k);
    });

    // 5. Update Narrative Comm Ticker & Consequence Echo Badges
    this.npcStatusTextEl.textContent = state.npcStatus;
    this.narrativeTextEl.textContent = state.narrativeLog;

    if (this.lastEchoCount !== state.echoes.length) {
      this.lastEchoCount = state.echoes.length;
      const latestEcho = state.echoes[state.echoes.length - 1];
      this.echoSummaryEl.innerHTML = `
        <span class="ns-echo-pill ns-echo-ghost">GHOST ECHOES: ${state.ghostEchoCount}</span>
        <span class="ns-echo-pill ns-echo-surge">SURGE ECHOES: ${state.surgeEchoCount}</span>
        ${
          latestEcho
            ? `<span class="ns-echo-latest">LATEST: ${latestEcho.title}</span>`
            : `<span class="ns-echo-latest">NO ECHOES FORGED YET</span>`
        }
      `;
    }
  }

  private renderVitalityPipSVG(state: 'full' | 'cracked' | 'empty'): string {
    if (state === 'full') {
      return `
        <svg viewBox="0 0 24 24" width="20" height="20" class="ns-pip">
          <polygon points="4,3 20,3 22,8 18,21 6,21 2,8" fill="#091526" stroke="#00f2fe" stroke-width="2"/>
          <polygon points="6,6 18,6 19,9 16,18 8,18 5,9" fill="#00f2fe"/>
          <line x1="7" y1="7" x2="17" y2="7" stroke="#e0f2fe" stroke-width="1.5"/>
        </svg>
      `;
    }
    if (state === 'cracked') {
      return `
        <svg viewBox="0 0 24 24" width="20" height="20" class="ns-pip">
          <polygon points="4,3 20,3 22,8 18,21 6,21 2,8" fill="#1f1608" stroke="#f59e0b" stroke-width="2"/>
          <polygon points="6,11 17,11 16,18 8,18" fill="#f59e0b"/>
          <polyline points="8,4 13,10 10,14 15,20" fill="none" stroke="#090d16" stroke-width="2"/>
        </svg>
      `;
    }
    return `
      <svg viewBox="0 0 24 24" width="20" height="20" class="ns-pip">
        <polygon points="4,3 20,3 22,8 18,21 6,21 2,8" fill="#060a12" stroke="#334155" stroke-width="1.8" stroke-dasharray="3 2"/>
      </svg>
    `;
  }

  private renderStatusModal(state: GameWorldState): void {
    const container = this.root.querySelector('#ns-modal-content')!;

    if (state.mode === 'paused') {
      container.innerHTML = `
        <div class="ns-modal-kicker">SYSTEM INTERRUPT // NEURAL LINK PAUSED</div>
        <h2 class="ns-modal-title">MISSION PAUSED</h2>
        <div class="ns-stat-grid">
          <div class="ns-stat-tile">
            <span class="ns-kicker">SECTOR</span>
            <span class="ns-stat-num">${state.sector} / ${state.maxSectors}</span>
          </div>
          <div class="ns-stat-tile">
            <span class="ns-kicker">SCORE</span>
            <span class="ns-stat-num">${Math.round(state.score)}</span>
          </div>
          <div class="ns-stat-tile">
            <span class="ns-kicker">ECHOES FORGED</span>
            <span class="ns-stat-num">${state.echoes.length}</span>
          </div>
        </div>
        <div class="ns-modal-actions">
          <button type="button" id="ns-modal-resume" class="ns-cta-primary">RESUME MISSION [ESC]</button>
          <button type="button" id="ns-modal-restart" class="ns-cta-secondary">RESTART RUN</button>
          <button type="button" id="ns-modal-title" class="ns-cta-secondary">RETURN TO TITLE</button>
        </div>
      `;

      container.querySelector('#ns-modal-resume')?.addEventListener('click', () => {
        this.callbacks.onResumeGame();
      });
      container.querySelector('#ns-modal-restart')?.addEventListener('click', () => {
        this.callbacks.onRestartGame();
      });
      container.querySelector('#ns-modal-title')?.addEventListener('click', () => {
        this.callbacks.onReturnTitle();
      });
      return;
    }

    const snap = state.runSnapshot;
    const isVictory = state.outcome === 'victory';

    container.innerHTML = `
      <div class="ns-modal-kicker">${
        isVictory
          ? 'CONSPIRACY EXPOSED // EXTRACTION COMPLETE'
          : 'NEURAL LINK TERMINATED // CORP COUNTER-INTRUSION'
      }</div>
      <h2 class="ns-modal-title" style="color: ${isVictory ? '#00f2fe' : '#ff2a6d'}">
        ${snap ? snap.endingTitle : isVictory ? 'MISSION ACCOMPLISHED' : 'SYSTEM FLATLINE'}
      </h2>
      <p class="ns-modal-desc">
        ${snap ? snap.endingSummary : ''}
      </p>
      <div class="ns-stat-grid">
        <div class="ns-stat-tile">
          <span class="ns-kicker">SCORE / BEST</span>
          <span class="ns-stat-num">${snap?.score ?? Math.round(state.score)} / ${snap?.bestScore ?? Math.round(state.bestScore)}</span>
        </div>
        <div class="ns-stat-tile">
          <span class="ns-kicker">GHOST / SURGE ECHOES</span>
          <span class="ns-stat-num">${snap?.ghostCount ?? state.ghostEchoCount}G · ${snap?.surgeCount ?? state.surgeEchoCount}S</span>
        </div>
        <div class="ns-stat-tile">
          <span class="ns-kicker">${isVictory ? 'CLEAR TIME' : 'SECTOR REACHED'}</span>
          <span class="ns-stat-num">${
            isVictory
              ? `${snap?.clearTimeSec ?? Math.round(state.elapsedSec)}s`
              : `${snap?.sectorReached ?? state.sector} / ${state.maxSectors}`
          }</span>
        </div>
      </div>
      <div class="ns-modal-actions">
        <button type="button" id="ns-modal-playagain" class="ns-cta-primary" data-start="true">
          ${isVictory ? 'NEW OPERATION // PLAY AGAIN' : 'REBOOT DECK // TRY AGAIN'}
        </button>
        <button type="button" id="ns-modal-title" class="ns-cta-secondary">TITLE SCREEN</button>
      </div>
    `;

    container.querySelector('#ns-modal-playagain')?.addEventListener('click', () => {
      this.callbacks.onRestartGame();
    });
    container.querySelector('#ns-modal-title')?.addEventListener('click', () => {
      this.callbacks.onReturnTitle();
    });
  }
}
