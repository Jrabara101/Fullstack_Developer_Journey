import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import * as xb from 'xrblocks';
import { SynthAudio } from '../audio/SynthAudio';
import {
  createInitialGameState,
  EchoPolarity,
  executeDualHack,
  GameWorldState,
  GRID_SIZE,
  HackMethod,
  loadSectorIntoState,
  resolveVaultDilemma,
  stepGameWorld,
  toggleActiveRealm,
} from '../game/rules';
import {
  createCyberGridTextures,
  createCyberNodeModel,
  createEnemyModel,
  createRadialShadowMaterial,
  createRogueHackerModel,
  ParticleBurstPool,
} from '../scene/ProceduralModels';
import { GameShell } from '../ui/GameShell';

const TILE_SCALE = 0.135; // 7x7 grid spans ~0.81m across the spatial tactical table
const CYBER_LAYER_Y = 0.36;

function gridToLocalX(gx: number): number {
  return (gx - (GRID_SIZE - 1) / 2) * TILE_SCALE;
}

function gridToLocalZ(gz: number): number {
  return (gz - (GRID_SIZE - 1) / 2) * TILE_SCALE;
}

export class NeonShadowsScript extends xb.Script {
  private state: GameWorldState;
  private audio: SynthAudio;
  private shell!: GameShell;
  private isSoftwareGl = false;

  // Input tracking
  private keysHeld = new Set<string>();
  private justPressed = new Set<string>();
  private stepSoundCooldown = 0;

  // 3D Scene Roots
  private dioramaRoot = new THREE.Group();
  private physicalLayerGroup = new THREE.Group();
  private cyberLayerGroup = new THREE.Group();
  private sectorPropsGroup = new THREE.Group();
  private particles!: ParticleBurstPool;
  private shadowMat!: THREE.MeshBasicMaterial;

  // Hero & Dynamic Entity Meshes
  private heroModel!: ReturnType<typeof createRogueHackerModel>;
  private nodeVisuals = new Map<
    string,
    ReturnType<typeof createCyberNodeModel>
  >();
  private gateVisuals = new Map<
    string,
    { root: THREE.Group; barrierMesh: THREE.Mesh; mat: THREE.MeshStandardMaterial }
  >();
  private vaultVisuals = new Map<
    string,
    { root: THREE.Group; prismMesh: THREE.Mesh; mat: THREE.MeshStandardMaterial }
  >();
  private enemyVisuals = new Map<
    string,
    ReturnType<typeof createEnemyModel>
  >();
  private extractionRing!: THREE.Mesh;
  private cyberGridPlane!: THREE.Mesh;
  private realmBlendFactor = 0;
  private renderedSector = -1;
  private uiValidated = false;

  // Spatial UI Card (XR Blocks built-in spatial surface)
  private spatialDeckCard!: xb.UICard;
  private spatialStatusText!: xb.UIText;
  private spatialEchoText!: xb.UIText;
  private spatialRealmText!: xb.UIText;

  // Camera Rig State
  private baseCamPos = new THREE.Vector3(0, 1.56, -0.32);
  private baseCamLook = new THREE.Vector3(0, 1.08, -1.22);
  private currentCamPos = new THREE.Vector3(0, 1.56, -0.32);
  private currentCamLook = new THREE.Vector3(0, 1.08, -1.22);

  constructor() {
    super();
    this.state = createInitialGameState(0);
    this.audio = new SynthAudio();
  }

  public init(): void {
    this.detectSoftwareWebGL();
    this.configureRendererAndEnvironment();
    this.setupLighting();
    this.buildDioramaStage();
    this.buildSpatialUICard();
    this.setupDOMGameShell();
    this.setupInputListeners();

    // Support ?autostart=1 query param for instant verification / jump-in
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      this.startNewOrResumeGame();
    }
  }

  private detectSoftwareWebGL(): void {
    try {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) {
        this.isSoftwareGl = true;
        return;
      }
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      this.isSoftwareGl =
        /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    } catch {
      this.isSoftwareGl = false;
    }
  }

  private configureRendererAndEnvironment(): void {
    const renderer = xb.core?.renderer as THREE.WebGLRenderer | undefined;
    const scene = xb.core?.scene;
    if (scene) {
      scene.background = new THREE.Color(0x040711);
      scene.fog = new THREE.FogExp2(0x040711, 0.14);
    }

    if (renderer && 'toneMapping' in renderer) {
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.15;
      renderer.setPixelRatio(
        this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
      );
      renderer.shadowMap.enabled = !this.isSoftwareGl;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      if (scene) {
        try {
          const pmrem = new THREE.PMREMGenerator(renderer);
          scene.environment = pmrem.fromScene(
            new RoomEnvironment(),
            0.04,
          ).texture;
          pmrem.dispose();
        } catch {
          // Fallback if PMREM fails in restricted contexts
        }
      }
    }
  }

  private setupLighting(): void {
    // Cool cyberpunk sky/ground HemisphereLight fill
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 2.2);
    this.add(hemiLight);

    // Warm neon-amber/magenta Directional Key Light
    const keyLight = new THREE.DirectionalLight(0xffd6a5, 2.6);
    keyLight.position.set(1.8, 3.4, 1.2);
    if (!this.isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.bias = -0.0005;
    }
    this.add(keyLight);

    // Cyan rim accent light behind the tactical hologram table
    const rimLight = new THREE.PointLight(0x00f2fe, 3.2, 3.5);
    rimLight.position.set(0, 1.55, -1.65);
    this.add(rimLight);
  }

  private buildDioramaStage(): void {
    this.dioramaRoot.position.set(0, 0.96, -1.22);
    this.add(this.dioramaRoot);

    this.shadowMat = createRadialShadowMaterial();
    const renderer = xb.core?.renderer as THREE.WebGLRenderer | undefined;
    const maxAniso = renderer?.capabilities?.getMaxAnisotropy?.() ?? 4;
    const { albedoMap, bumpMap } = createCyberGridTextures(maxAniso);

    // 1. Multi-part Cyber-Deck Tactical Table Plinth
    const plinthGroup = new THREE.Group();
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x0b1324,
      roughness: 0.45,
      metalness: 0.75,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: 0x00f2fe,
      emissive: 0x00a8cc,
      emissiveIntensity: 1.1,
      roughness: 0.2,
      metalness: 0.88,
    });

    const pedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.56, 0.64, 0.08, 8),
      baseMat,
    );
    pedestal.position.y = -0.045;
    plinthGroup.add(pedestal);

    const rimRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.6, 0.012, 8, 32),
      trimMat,
    );
    rimRing.rotation.x = Math.PI / 2;
    rimRing.position.y = -0.008;
    plinthGroup.add(rimRing);

    // Playfield Ground Surface
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: albedoMap,
      bumpMap,
      bumpScale: 0.008,
      roughness: 0.55,
      metalness: 0.35,
    });
    const floorMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.98, 0.02, 0.98),
      floorMat,
    );
    floorMesh.position.y = -0.01;
    floorMesh.receiveShadow = !this.isSoftwareGl;
    plinthGroup.add(floorMesh);
    this.dioramaRoot.add(plinthGroup);

    // 2. Distant Skyline Silhouette Vista along North/Flank Perimeter
    this.buildSkylineVista();

    // 3. Physical & Cyberspace Layers
    this.dioramaRoot.add(this.physicalLayerGroup);
    this.cyberLayerGroup.position.y = CYBER_LAYER_Y;
    this.dioramaRoot.add(this.cyberLayerGroup);
    this.physicalLayerGroup.add(this.sectorPropsGroup);

    // Translucent Holographic Cyberspace Matrix Plane
    const cyberPlaneMat = new THREE.MeshBasicMaterial({
      color: 0x00f2fe,
      wireframe: true,
      transparent: true,
      opacity: 0.14,
      depthWrite: false,
    });
    this.cyberGridPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(0.92, 0.92, 7, 7),
      cyberPlaneMat,
    );
    this.cyberGridPlane.rotation.x = -Math.PI / 2;
    this.cyberLayerGroup.add(this.cyberGridPlane);

    // 4. Rogue Hacker Hero Model
    this.heroModel = createRogueHackerModel(this.shadowMat);
    this.physicalLayerGroup.add(this.heroModel.root);

    // 5. Extraction Beacon Ring at North Plaza
    this.extractionRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.062, 0.007, 10, 28),
      new THREE.MeshStandardMaterial({
        color: 0x10b981,
        emissive: 0x10b981,
        emissiveIntensity: 1.8,
        roughness: 0.2,
        metalness: 0.8,
      }),
    );
    this.extractionRing.rotation.x = Math.PI / 2;
    this.extractionRing.position.y = 0.012;
    this.physicalLayerGroup.add(this.extractionRing);

    // 6. Pooled Particle Burst System
    this.particles = new ParticleBurstPool();
    this.physicalLayerGroup.add(this.particles.mesh);

    // Populate initial sector props
    this.rebuildSectorEntities();
  }

  private buildSkylineVista(): void {
    const vistaGroup = new THREE.Group();
    const towerMat = new THREE.MeshStandardMaterial({
      color: 0x091122,
      roughness: 0.5,
      metalness: 0.7,
    });
    const neonCyanMat = new THREE.MeshStandardMaterial({
      color: 0x00f2fe,
      emissive: 0x00f2fe,
      emissiveIntensity: 1.5,
      roughness: 0.2,
      metalness: 0.8,
    });
    const neonPinkMat = new THREE.MeshStandardMaterial({
      color: 0xff2a6d,
      emissive: 0xff2a6d,
      emissiveIntensity: 1.5,
      roughness: 0.2,
      metalness: 0.8,
    });

    const spireSpecs = [
      { x: -0.44, z: -0.58, w: 0.11, h: 0.52, accent: neonCyanMat },
      { x: -0.22, z: -0.62, w: 0.09, h: 0.38, accent: neonPinkMat },
      { x: 0.0, z: -0.66, w: 0.14, h: 0.68, accent: neonCyanMat }, // Center Apex Landmark
      { x: 0.24, z: -0.62, w: 0.09, h: 0.42, accent: neonPinkMat },
      { x: 0.44, z: -0.58, w: 0.11, h: 0.48, accent: neonCyanMat },
    ];

    for (const sp of spireSpecs) {
      const spire = new THREE.Group();
      spire.position.set(sp.x, 0, sp.z);

      const hull = new THREE.Mesh(
        new THREE.BoxGeometry(sp.w, sp.h, sp.w),
        towerMat,
      );
      hull.position.y = sp.h / 2;
      spire.add(hull);

      const crown = new THREE.Mesh(
        new THREE.BoxGeometry(sp.w * 0.72, 0.06, sp.w * 0.72),
        sp.accent,
      );
      crown.position.y = sp.h + 0.03;
      spire.add(crown);

      const antenna = new THREE.Mesh(
        new THREE.CylinderGeometry(0.003, 0.005, 0.14, 6),
        sp.accent,
      );
      antenna.position.y = sp.h + 0.1;
      spire.add(antenna);

      vistaGroup.add(spire);
    }

    this.dioramaRoot.add(vistaGroup);
  }

  private rebuildSectorEntities(): void {
    this.renderedSector = this.state.sector;

    // Clear previous sector meshes
    this.sectorPropsGroup.clear();
    for (const nv of this.nodeVisuals.values()) {
      nv.root.removeFromParent();
    }
    this.nodeVisuals.clear();
    this.gateVisuals.clear();
    this.vaultVisuals.clear();
    this.enemyVisuals.clear();

    // 1. Obstacles (Multi-part Cyber Server Pylons)
    const pylonMat = new THREE.MeshStandardMaterial({
      color: 0x162238,
      roughness: 0.42,
      metalness: 0.75,
    });
    const pylonTrimMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 1.1,
      roughness: 0.2,
      metalness: 0.85,
    });

    for (const obs of this.state.obstacles) {
      const grp = new THREE.Group();
      grp.position.set(gridToLocalX(obs.gx), 0, gridToLocalZ(obs.gz));

      const base = new THREE.Mesh(
        new THREE.BoxGeometry(0.095, 0.15, 0.095),
        pylonMat,
      );
      base.position.y = 0.075;
      const cap = new THREE.Mesh(
        new THREE.BoxGeometry(0.102, 0.016, 0.102),
        pylonTrimMat,
      );
      cap.position.y = 0.152;
      grp.add(base, cap);
      this.sectorPropsGroup.add(grp);
    }

    // 2. Security Gates (Dual Emitter Pillars + Retractable Laser Barrier)
    for (const gate of this.state.gates) {
      const grp = new THREE.Group();
      grp.position.set(gridToLocalX(gate.gx), 0, gridToLocalZ(gate.gz));

      const postGeo = new THREE.CylinderGeometry(0.012, 0.015, 0.14, 10);
      const postL = new THREE.Mesh(postGeo, pylonMat);
      postL.position.set(-0.08, 0.07, 0);
      const postR = new THREE.Mesh(postGeo, pylonMat);
      postR.position.set(0.08, 0.07, 0);

      const barrierMat = new THREE.MeshStandardMaterial({
        color: 0xff2a6d,
        emissive: 0xff2a6d,
        emissiveIntensity: 1.8,
        transparent: true,
        opacity: 0.75,
        depthWrite: false,
      });
      const barrierMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.15, 0.11, 0.012),
        barrierMat,
      );
      barrierMesh.position.y = 0.065;

      grp.add(postL, postR, barrierMesh);
      this.sectorPropsGroup.add(grp);
      this.gateVisuals.set(gate.id, { root: grp, barrierMesh, mat: barrierMat });
    }

    // 3. Data Vaults (Multi-part Pedestal + Floating Memory Prism)
    for (const vault of this.state.vaults) {
      const grp = new THREE.Group();
      grp.position.set(gridToLocalX(vault.gx), 0, gridToLocalZ(vault.gz));

      const plinth = new THREE.Mesh(
        new THREE.CylinderGeometry(0.045, 0.055, 0.04, 8),
        pylonMat,
      );
      plinth.position.y = 0.02;

      const prismMat = new THREE.MeshStandardMaterial({
        color: 0xfbbf24,
        emissive: 0xd97706,
        emissiveIntensity: 1.6,
        roughness: 0.15,
        metalness: 0.9,
      });
      const prismMesh = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.036, 0),
        prismMat,
      );
      prismMesh.position.y = 0.095;

      grp.add(plinth, prismMesh);
      this.sectorPropsGroup.add(grp);
      this.vaultVisuals.set(vault.id, { root: grp, prismMesh, mat: prismMat });
    }

    // 4. Cyberspace Net-Nodes in Upper Layer + Fiber-Optic Data Tubes
    for (const node of this.state.nodes) {
      const nv = createCyberNodeModel(node.kind);
      const nx = gridToLocalX(node.gx);
      const nz = gridToLocalZ(node.gz);
      nv.root.position.set(nx, 0, nz);
      nv.root.userData.nodeId = node.id;
      nv.coreMesh.userData.nodeId = node.id;
      nv.outerRing.userData.nodeId = node.id;
      this.cyberLayerGroup.add(nv.root);
      this.nodeVisuals.set(node.id, nv);

      // Draw a glowing fiber-optic conduit from this CyberNode to its linked physical Gate or Vault
      let targetGx: number | null = null;
      let targetGz: number | null = null;
      if (node.linkedGateId) {
        const g = this.state.gates.find((gt) => gt.id === node.linkedGateId);
        if (g) {
          targetGx = g.gx;
          targetGz = g.gz;
        }
      } else if (node.linkedVaultId) {
        const v = this.state.vaults.find((vt) => vt.id === node.linkedVaultId);
        if (v) {
          targetGx = v.gx;
          targetGz = v.gz;
        }
      }
      if (targetGx !== null && targetGz !== null) {
        const tx = gridToLocalX(targetGx);
        const tz = gridToLocalZ(targetGz);
        const curve = new THREE.CatmullRomCurve3([
          new THREE.Vector3(nx, CYBER_LAYER_Y, nz),
          new THREE.Vector3((nx + tx) * 0.5, CYBER_LAYER_Y * 0.55, (nz + tz) * 0.5),
          new THREE.Vector3(tx, 0.08, tz),
        ]);
        const tubeGeo = new THREE.TubeGeometry(curve, 12, 0.0035, 6, false);
        const tubeMesh = new THREE.Mesh(tubeGeo, nv.beamMat);
        this.sectorPropsGroup.add(tubeMesh);
      }
    }

    // 5. Corporate Enemy Models
    for (const en of this.state.enemies) {
      const ev = createEnemyModel(en.archetype, this.shadowMat);
      this.sectorPropsGroup.add(ev.root);
      this.enemyVisuals.set(en.id, ev);
    }
  }

  /**
   * Builds the XR Blocks world-space `UICard` so XR headset and desktop users
   * can also inspect and trigger Dual-Hack actions in 3D space.
   */
  private buildSpatialUICard(): void {
    this.spatialRealmText = new xb.UIText({
      text: 'REALM: PHYSICAL // SEC 01',
      style: { fontSize: 16, fontWeight: 'bold', color: '#00f2fe' },
    });

    this.spatialStatusText = new xb.UIText({
      text: 'ARIA-7: Jack in and hack upper Cyber-Nodes.',
      style: {
        fontSize: 14,
        lineHeight: 1.3,
        color: '#e2e8f0',
        whiteSpace: 'pre-line',
      },
    });

    this.spatialEchoText = new xb.UIText({
      text: 'ECHOES: 0 GHOST | 0 SURGE',
      style: { fontSize: 14, fontWeight: 'bold', color: '#fbbf24' },
    });

    const ghostBtn = new xb.UIButton({
      label: 'Ghost [1]',
      icon: 'security',
      style: { flexGrow: 1 },
      onClick: () => {
        this.state.selectedHackTool = 'ghost_bypass';
        this.triggerPlayerHack('ghost_bypass');
      },
    });

    const surgeBtn = new xb.UIButton({
      label: 'Surge [2]',
      icon: 'bolt',
      style: { flexGrow: 1 },
      onClick: () => {
        this.state.selectedHackTool = 'voltage_surge';
        this.triggerPlayerHack('voltage_surge');
      },
    });

    const echoBtn = new xb.UIButton({
      label: 'Echo [3]',
      icon: 'restart_alt',
      style: { flexGrow: 1 },
      onClick: () => {
        this.state.selectedHackTool = 'echo_detonate';
        this.triggerPlayerHack('echo_detonate');
      },
    });

    const realmBtn = new xb.UIButton({
      label: 'Realm [Q]',
      icon: 'layers',
      style: { flexGrow: 1 },
      onClick: () => {
        this.handleToggleRealm();
      },
    });

    this.spatialDeckCard = new xb.UICard({
      size: { width: 0.54, height: 'auto' },
      manipulation: true,
      edge: true,
      style: {
        flexDirection: 'column',
        gap: 10,
        padding: 16,
        backgroundColor: '#070d19',
        borderRadius: 18,
      },
      children: [
        new xb.UIText({
          text: 'NEURAL CYBER-DECK',
          style: { fontSize: 22, fontWeight: 'bold', color: '#ffffff' },
        }),
        this.spatialRealmText,
        this.spatialEchoText,
        this.spatialStatusText,
        new xb.UIPanel({
          style: { width: '100%', flexDirection: 'row', gap: 8 },
          children: [ghostBtn, surgeBtn],
        }),
        new xb.UIPanel({
          style: { width: '100%', flexDirection: 'row', gap: 8 },
          children: [echoBtn, realmBtn],
        }),
      ],
    });

    this.spatialDeckCard.position.set(0.68, 1.32, -1.12);
    this.spatialDeckCard.rotation.y = -0.28;
    this.add(this.spatialDeckCard);
  }

  private setupDOMGameShell(): void {
    this.shell = new GameShell({
      onStartGame: () => this.startNewOrResumeGame(),
      onResumeGame: () => {
        if (this.state.mode === 'paused') {
          this.state.mode = 'playing';
          this.keysHeld.clear();
          this.shell.syncBodyState('playing');
        }
      },
      onPauseToggle: () => this.togglePause(),
      onRestartGame: () => this.restartFullRun(),
      onReturnTitle: () => {
        this.state.mode = 'title';
        this.keysHeld.clear();
        this.shell.syncBodyState('title');
      },
      onMuteToggle: () => this.audio.toggleMute(),
      onSelectHackTool: (tool: HackMethod) => {
        this.state.selectedHackTool = tool;
      },
      onTriggerHack: (tool?: HackMethod) => {
        this.triggerPlayerHack(tool);
      },
      onToggleRealm: () => this.handleToggleRealm(),
      onResolveDilemma: (polarity: EchoPolarity) => {
        this.handleResolveDilemma(polarity);
      },
    });
  }

  private setupInputListeners(): void {
    window.addEventListener('keydown', (e) => {
      const code = e.code;

      // Title screen start handshake on Enter or Space
      if (
        this.state.mode === 'title' &&
        (code === 'Enter' || code === 'Space')
      ) {
        e.preventDefault();
        this.startNewOrResumeGame();
        return;
      }

      // Gameover restart handshake on Enter or Space
      if (
        this.state.mode === 'gameover' &&
        (code === 'Enter' || code === 'Space')
      ) {
        e.preventDefault();
        this.restartFullRun();
        return;
      }

      if (code === 'Escape' || code === 'KeyP') {
        e.preventDefault();
        this.togglePause();
        return;
      }

      if (code === 'KeyM') {
        const muted = this.audio.toggleMute();
        this.shell.updateMuteIcon(muted);
        return;
      }

      if (code === 'KeyH') {
        this.shell.toggleDockCollapse();
        return;
      }

      if (code === 'KeyR' && this.state.mode === 'playing') {
        this.restartFullRun();
        return;
      }

      // Narrative Dilemma keyboard shortcuts [1] / [2]
      if (this.state.mode === 'playing' && this.state.activeDilemma) {
        if (code === 'Digit1') {
          this.handleResolveDilemma('ghost');
          return;
        }
        if (code === 'Digit2') {
          this.handleResolveDilemma('surge');
          return;
        }
      }

      if (code === 'Digit1') {
        this.state.selectedHackTool = 'ghost_bypass';
        this.triggerPlayerHack('ghost_bypass');
      } else if (code === 'Digit2') {
        this.state.selectedHackTool = 'voltage_surge';
        this.triggerPlayerHack('voltage_surge');
      } else if (code === 'Digit3') {
        this.state.selectedHackTool = 'echo_detonate';
        this.triggerPlayerHack('echo_detonate');
      } else if (code === 'KeyQ') {
        this.handleToggleRealm();
      }

      if (!this.keysHeld.has(code)) {
        this.justPressed.add(code);
      }
      this.keysHeld.add(code);
    });

    window.addEventListener('keyup', (e) => {
      this.keysHeld.delete(e.code);
    });

    // Clear held inputs on blur or tab switch without forcing pause modal
    window.addEventListener('blur', () => {
      this.keysHeld.clear();
      this.justPressed.clear();
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.keysHeld.clear();
        this.justPressed.clear();
      }
    });
  }

  public startNewOrResumeGame(): void {
    if (this.state.mode === 'gameover') {
      this.restartFullRun();
      return;
    }
    this.state.mode = 'playing';
    this.keysHeld.clear();
    this.justPressed.clear();
    this.shell.syncBodyState('playing');
    this.audio.playGhostHack();
  }

  public restartFullRun(): void {
    const best = this.state.bestScore;
    this.state = createInitialGameState(best);
    this.state.mode = 'playing';
    this.keysHeld.clear();
    this.justPressed.clear();
    this.rebuildSectorEntities();
    this.shell.syncBodyState('playing');
    this.audio.playRealmShift(true);
  }

  public togglePause(): void {
    if (this.state.mode === 'playing') {
      this.state.mode = 'paused';
      this.keysHeld.clear();
      this.shell.syncBodyState('paused');
    } else if (this.state.mode === 'paused') {
      this.state.mode = 'playing';
      this.keysHeld.clear();
      this.shell.syncBodyState('playing');
    }
  }

  private handleToggleRealm(): void {
    if (this.state.mode !== 'playing') return;
    const nextRealm = toggleActiveRealm(this.state);
    this.audio.playRealmShift(nextRealm === 'cyber');
  }

  private handleResolveDilemma(polarity: EchoPolarity): void {
    const ok = resolveVaultDilemma(this.state, polarity);
    if (ok) {
      if (polarity === 'ghost') {
        this.audio.playGhostHack();
      } else {
        this.audio.playEchoDetonate();
      }
      this.particles.emitBurst(
        gridToLocalX(this.state.player.x),
        0.12,
        gridToLocalZ(this.state.player.z),
        polarity === 'ghost' ? 0x00f2fe : 0xff2a6d,
        22,
        0.85,
      );
    }
  }

  private triggerPlayerHack(method?: HackMethod, targetNodeId?: string): void {
    if (this.state.mode !== 'playing') return;
    const chosen = method ?? this.state.selectedHackTool;
    const res = executeDualHack(this.state, chosen, targetNodeId);
    if (!res.success) return;

    if (chosen === 'ghost_bypass') {
      this.audio.playGhostHack();
    } else if (chosen === 'voltage_surge') {
      this.audio.playVoltageSurge();
    } else {
      this.audio.playEchoDetonate();
    }

    const burstNode = res.hackedNode;
    const bx = burstNode
      ? gridToLocalX(burstNode.gx)
      : gridToLocalX(this.state.player.x);
    const bz = burstNode
      ? gridToLocalZ(burstNode.gz)
      : gridToLocalZ(this.state.player.z);
    const hex =
      chosen === 'ghost_bypass'
        ? 0x00f2fe
        : chosen === 'voltage_surge'
          ? 0xff2a6d
          : 0xfbbf24;

    this.particles.emitBurst(bx, 0.14, bz, hex, 18, 0.78);
  }

  /**
   * XR Blocks selection callback: clicking or pinching a 3D CyberNode in the scene
   * triggers a Dual-Realm Hack directly on that node!
   */
  public onSelectStart(event: xb.SelectEvent): void {
    if (this.state.mode !== 'playing') return;
    let obj: THREE.Object3D | null = (event.target as THREE.Object3D) ?? null;
    while (obj) {
      if (obj.userData?.nodeId) {
        this.triggerPlayerHack(undefined, obj.userData.nodeId as string);
        return;
      }
      obj = obj.parent;
    }
  }

  public update(): void {
    const rawDt = xb.getDeltaTime ? xb.getDeltaTime() : 0.016;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    // Validate built-in spatial UI layout once after first completed frame
    if (!this.uiValidated && this.spatialDeckCard) {
      const report = xb.ui.validate(this.spatialDeckCard);
      if (report.ready) {
        this.uiValidated = true;
      }
    }

    // Gather movement vector from WASD / Arrow keys
    let moveX = 0;
    let moveZ = 0;
    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) moveX -= 1;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) moveX += 1;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) moveZ -= 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) moveZ += 1;

    const dashJustPressed =
      this.justPressed.has('KeyE') || this.justPressed.has('ShiftLeft');
    const hackJustPressed = this.justPressed.has('Space');
    this.justPressed.clear();

    const stepEvents = stepGameWorld(this.state, dt, {
      moveX,
      moveZ,
      dashJustPressed,
      hackJustPressed,
    });

    // Rebuild sector meshes if player advanced to next sector
    if (stepEvents.sectorCleared || this.renderedSector !== this.state.sector) {
      this.rebuildSectorEntities();
      this.audio.playVictory();
    }

    if (stepEvents.playerHit) {
      this.audio.playDamageHit();
      this.particles.emitBurst(
        gridToLocalX(this.state.player.x),
        0.1,
        gridToLocalZ(this.state.player.z),
        0xff2a6d,
        16,
        0.75,
      );
    }

    if (stepEvents.gameEnded) {
      if (this.state.outcome === 'victory') {
        this.audio.playVictory();
      } else {
        this.audio.playDefeat();
      }
    }

    // Footstep synth cadence when moving
    if (this.state.mode === 'playing' && (moveX !== 0 || moveZ !== 0)) {
      this.stepSoundCooldown -= dt;
      if (this.stepSoundCooldown <= 0) {
        this.stepSoundCooldown = 0.28;
        this.audio.playStep();
      }
    }

    this.sync3DScene(dt);
    this.syncSpatialUICard();
    this.shell.update(this.state, dt);
  }

  private sync3DScene(dt: number): void {
    const t = performance.now() * 0.001;

    // 1. Update Hero Mesh Transform, Gait Bob & Squash/Stretch
    const px = gridToLocalX(this.state.player.x);
    const pz = gridToLocalZ(this.state.player.z);
    this.heroModel.root.position.set(px, 0, pz);
    this.heroModel.bodyGroup.rotation.y = this.state.player.facingAngle;

    const bobY = Math.abs(Math.sin(this.state.player.stepBobPhase)) * 0.012;
    this.heroModel.bodyGroup.position.y = bobY;
    this.heroModel.bodyGroup.scale.set(
      this.state.player.squashX,
      this.state.player.squashY,
      this.state.player.squashX,
    );

    // Hit flash or Phase Cloak visual feedback
    if (this.state.player.hitFlashTimer > 0) {
      this.heroModel.visorMat.emissive.setHex(0xff2a6d);
      this.heroModel.visorMat.emissiveIntensity = 3.0;
    } else {
      this.heroModel.visorMat.emissive.setHex(0x00f2fe);
      this.heroModel.visorMat.emissiveIntensity = 1.8;
    }

    const cloakMat = this.heroModel.cloakRing
      .material as THREE.MeshBasicMaterial;
    if (this.state.player.cloakTimer > 0) {
      cloakMat.opacity = 0.65 + Math.sin(t * 8) * 0.2;
      this.heroModel.cloakRing.rotation.z = t * 2.5;
    } else {
      cloakMat.opacity = 0;
    }

    // 2. Smoothly damp Cyberspace Net-Layer prominence when shifting realms
    const targetBlend = this.state.activeRealm === 'cyber' ? 1 : 0;
    this.realmBlendFactor +=
      (targetBlend - this.realmBlendFactor) * (1 - Math.exp(-8 * dt));
    this.cyberLayerGroup.position.y =
      CYBER_LAYER_Y - this.realmBlendFactor * 0.11;
    const planeMat = this.cyberGridPlane.material as THREE.MeshBasicMaterial;
    planeMat.opacity = 0.12 + this.realmBlendFactor * 0.26;

    // 3. Update Cyberspace Nodes
    for (const node of this.state.nodes) {
      const nv = this.nodeVisuals.get(node.id);
      if (!nv) continue;
      nv.coreMesh.rotation.y = t * 1.6;
      nv.outerRing.rotation.x = Math.sin(t * 1.2) * 0.6;
      nv.outerRing.rotation.z = t * 0.9;

      const scaleBoost = 1 + this.realmBlendFactor * 0.22 + (node.pulseTimer > 0 ? 0.25 : 0);
      nv.root.scale.setScalar(scaleBoost);

      if (node.hacked) {
        const col = node.polarity === 'ghost' ? 0x00f2fe : 0xe879f9;
        nv.coreMat.color.setHex(col);
        nv.coreMat.emissive.setHex(col);
        nv.beamMat.color.setHex(col);
        nv.beamMat.opacity = 0.58;
      }
    }

    // 4. Update Security Gates
    for (const gate of this.state.gates) {
      const gv = this.gateVisuals.get(gate.id);
      if (!gv) continue;
      const targetScaleY = gate.isOpen ? 0.02 : 1.0;
      gv.barrierMesh.scale.y +=
        (targetScaleY - gv.barrierMesh.scale.y) * (1 - Math.exp(-10 * dt));
      gv.barrierMesh.visible = gv.barrierMesh.scale.y > 0.05;
    }

    // 5. Update Data Vaults
    for (const vault of this.state.vaults) {
      const vv = this.vaultVisuals.get(vault.id);
      if (!vv) continue;
      vv.prismMesh.rotation.y = t * 2.0;
      vv.prismMesh.position.y = 0.095 + Math.sin(t * 3) * 0.01;
      if (vault.breached) {
        vv.mat.color.setHex(0x10b981);
        vv.mat.emissive.setHex(0x059669);
      } else if (vault.unlocked) {
        vv.mat.color.setHex(0x00f2fe);
        vv.mat.emissive.setHex(0x0284c7);
      }
    }

    // 6. Update Extraction Beacon
    this.extractionRing.position.set(
      gridToLocalX(this.state.extractionPoint.gx),
      0.012,
      gridToLocalZ(this.state.extractionPoint.gz),
    );
    this.extractionRing.visible = this.state.extractionPoint.active;
    if (this.state.extractionPoint.active) {
      this.extractionRing.scale.setScalar(1 + Math.sin(t * 5) * 0.12);
    }

    // 7. Update Enemy Meshes, Windup Telegraphs & KO Topple
    for (const en of this.state.enemies) {
      const ev = this.enemyVisuals.get(en.id);
      if (!ev) continue;

      ev.root.position.set(gridToLocalX(en.x), 0, gridToLocalZ(en.z));
      ev.bodyGroup.rotation.y = en.facingAngle;

      if (en.state === 'ko') {
        const koProgress = 1 - en.koTimer / 0.45;
        ev.bodyGroup.rotation.x = koProgress * (Math.PI / 2);
        ev.root.scale.setScalar(Math.max(0.01, 1 - koProgress * 0.85));
        ev.telegraphRing.visible = false;
        ev.telegraphBeam.visible = false;
        continue;
      }

      ev.bodyGroup.rotation.x = 0;
      ev.root.scale.setScalar(1);

      if (ev.shieldMesh) {
        ev.shieldMesh.visible = en.shieldActive;
      }

      if (en.hitFlashTimer > 0) {
        ev.primaryMat.emissive.setHex(0xffffff);
        ev.primaryMat.emissiveIntensity = 2.0;
      } else if (en.state === 'hacked_ally') {
        ev.primaryMat.emissive.setHex(0x00f2fe);
        ev.primaryMat.emissiveIntensity = 0.8;
      } else if (en.state === 'stunned') {
        ev.primaryMat.emissive.setHex(0xfbbf24);
        ev.primaryMat.emissiveIntensity = 0.7;
      } else {
        ev.primaryMat.emissive.setHex(0x000000);
        ev.primaryMat.emissiveIntensity = 0;
      }

      // Windup Telegraph Visuals
      if (en.state === 'windup') {
        const progress =
          1 - Math.max(0, en.stateTimer / Math.max(0.1, en.windupDuration));
        ev.telegraphRing.visible = true;
        ev.telegraphRing.scale.setScalar(0.7 + progress * 0.9);
        (ev.telegraphRing.material as THREE.MeshBasicMaterial).opacity =
          0.45 + progress * 0.5;

        if (en.archetype !== 'swarmer') {
          ev.telegraphBeam.visible = true;
          ev.telegraphBeam.rotation.z = -en.facingAngle;
          (ev.telegraphBeam.material as THREE.MeshBasicMaterial).opacity =
            0.35 + progress * 0.55;
        } else {
          ev.telegraphBeam.visible = false;
        }
      } else {
        ev.telegraphRing.visible = false;
        ev.telegraphBeam.visible = false;
      }
    }

    // 8. Update Pooled Particle Ring Buffer
    this.particles.update(dt);

    // 9. Update Camera Framing (Title Orbital Pan vs Damped Gameplay Follow + Shake)
    const cam = xb.core?.camera;
    if (cam && !xb.core?.renderer?.xr?.isPresenting) {
      if (this.state.mode === 'title') {
        const panAngle = Math.sin(t * 0.35) * 0.28;
        this.currentCamPos.set(
          Math.sin(panAngle) * 0.85,
          1.48 + Math.sin(t * 0.5) * 0.04,
          -0.28,
        );
        this.currentCamLook.set(-0.12, 1.12, -1.22);
      } else {
        const followX = px * 0.28;
        const followY = this.state.activeRealm === 'cyber' ? 1.62 : 1.54;
        const targetPos = this.baseCamPos.set(followX, followY, -0.30);
        const targetLook = this.baseCamLook.set(
          px * 0.35,
          this.state.activeRealm === 'cyber' ? 1.16 : 1.06,
          -1.22 + pz * 0.2,
        );

        const dampAlpha = 1 - Math.exp(-7 * dt);
        this.currentCamPos.lerp(targetPos, dampAlpha);
        this.currentCamLook.lerp(targetLook, dampAlpha);
      }

      // Apply decaying trauma * trauma shake
      const shake = this.state.cameraTrauma * this.state.cameraTrauma * 0.032;
      const sx = (Math.random() - 0.5) * 2 * shake;
      const sy = (Math.random() - 0.5) * 2 * shake;

      cam.position.set(
        this.currentCamPos.x + sx,
        this.currentCamPos.y + sy,
        this.currentCamPos.z,
      );
      cam.lookAt(this.currentCamLook);
    }
  }

  private syncSpatialUICard(): void {
    if (!this.spatialDeckCard) return;
    this.spatialRealmText.text = `REALM: ${this.state.activeRealm.toUpperCase()} // SEC 0${this.state.sector}`;
    this.spatialEchoText.text = `ECHOES: ${this.state.ghostEchoCount} GHOST | ${this.state.surgeEchoCount} SURGE | TRACE ${Math.round(this.state.traceLevel)}%`;
    this.spatialStatusText.text = this.state.narrativeLog;
  }
}
