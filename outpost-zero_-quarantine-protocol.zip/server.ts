import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  generateWaveComposition,
  getDailyUtcSeed,
  verifyRunTelemetry,
} from './src/game/rules';
import { LeaderboardEntry, TelemetrySubmissionPayload } from './src/types/game';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const LEADERBOARD_FILE = path.join(DATA_DIR, 'leaderboard.json');

function getInitialLeaderboard(dailySeed: string): LeaderboardEntry[] {
  return [
    {
      id: 'lb_1',
      playerName: 'Kestrel_Vanguard',
      runSeed: dailySeed,
      wavesCleared: 14,
      finalScore: 84200,
      scrapCollected: 2890,
      biomassHarvested: 112,
      durationMs: 742000,
      favoriteSynergy: 'Tesla M870 Trench Breacher',
      verifiedHash: 'QP-VERIFIED-9F4A2C1E',
      createdAt: new Date(Date.now() - 3600 * 1000 * 3).toISOString(),
    },
    {
      id: 'lb_2',
      playerName: 'Ash_Hound',
      runSeed: dailySeed,
      wavesCleared: 11,
      finalScore: 63950,
      scrapCollected: 2140,
      biomassHarvested: 88,
      durationMs: 598000,
      favoriteSynergy: 'Hellfire Valkyrie Marksman Rifle',
      verifiedHash: 'QP-VERIFIED-7B3E11D0',
      createdAt: new Date(Date.now() - 3600 * 1000 * 5).toISOString(),
    },
    {
      id: 'lb_3',
      playerName: 'Cipher_Nine',
      runSeed: dailySeed,
      wavesCleared: 9,
      finalScore: 49800,
      scrapCollected: 1680,
      biomassHarvested: 64,
      durationMs: 485000,
      favoriteSynergy: 'Cryo-Zero MK-IV Tactical Sidearm',
      verifiedHash: 'QP-VERIFIED-4E88A912',
      createdAt: new Date(Date.now() - 3600 * 1000 * 7).toISOString(),
    },
    {
      id: 'lb_4',
      playerName: 'Mire_Stalker',
      runSeed: 'QP-CUSTOM-OMEGA',
      wavesCleared: 8,
      finalScore: 41200,
      scrapCollected: 1420,
      biomassHarvested: 51,
      durationMs: 412000,
      favoriteSynergy: 'Tesla M870 Trench Breacher',
      verifiedHash: 'QP-VERIFIED-2C7D50F4',
      createdAt: new Date(Date.now() - 3600 * 1000 * 11).toISOString(),
    },
    {
      id: 'lb_5',
      playerName: 'Dr_Vance',
      runSeed: dailySeed,
      wavesCleared: 6,
      finalScore: 29450,
      scrapCollected: 980,
      biomassHarvested: 34,
      durationMs: 310000,
      favoriteSynergy: 'MK-IV Tactical Sidearm',
      verifiedHash: 'QP-VERIFIED-8A19C3B7',
      createdAt: new Date(Date.now() - 3600 * 1000 * 14).toISOString(),
    },
  ];
}

function loadLeaderboard(): LeaderboardEntry[] {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(LEADERBOARD_FILE)) {
      const initial = getInitialLeaderboard(getDailyUtcSeed());
      fs.writeFileSync(LEADERBOARD_FILE, JSON.stringify(initial, null, 2), 'utf-8');
      return initial;
    }
    const raw = fs.readFileSync(LEADERBOARD_FILE, 'utf-8');
    return JSON.parse(raw) as LeaderboardEntry[];
  } catch {
    return getInitialLeaderboard(getDailyUtcSeed());
  }
}

function saveLeaderboard(entries: LeaderboardEntry[]): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(LEADERBOARD_FILE, JSON.stringify(entries.slice(0, 50), null, 2), 'utf-8');
  } catch {
    // Ignore write failure in read-only environments
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '1mb' }));

  // 1. Daily Quarantine Seed & Wave Director endpoint
  app.get('/api/waves/daily', (_req, res) => {
    const dailySeed = getDailyUtcSeed();
    const previewWaves = Array.from({ length: 12 }, (_, idx) =>
      generateWaveComposition(dailySeed, idx + 1)
    );
    res.json({
      seed: dailySeed,
      utcDate: new Date().toISOString().slice(0, 10),
      protocolName: 'Operation Blackout Threshold',
      modifierSummary: 'Increased Nocturnal Sprinter packs on Wave 3+ · +15% Scrap Yield on Headshots',
      waves: previewWaves,
    });
  });

  // 2. Custom Difficulty Preset Wave Generator
  app.get('/api/waves/preset/:difficulty', (req, res) => {
    const difficulty = req.params.difficulty || 'standard';
    const customSeed = (req.query.seed as string) || `${getDailyUtcSeed()}-${difficulty.toUpperCase()}`;
    const bonus = difficulty === 'nightmare' ? 2 : difficulty === 'hardcore' ? 1 : 0;
    const waves = Array.from({ length: 12 }, (_, idx) =>
      generateWaveComposition(customSeed, idx + 1, bonus)
    );
    res.json({
      seed: customSeed,
      difficulty,
      waves,
    });
  });

  // 3. Global Quarantine Leaderboard
  app.get('/api/leaderboard', (req, res) => {
    const seedFilter = req.query.seed as string | undefined;
    const allEntries = loadLeaderboard();
    const filtered = seedFilter
      ? allEntries.filter((e) => e.runSeed === seedFilter)
      : allEntries;
    filtered.sort((a, b) => b.finalScore - a.finalScore);
    res.json({
      dailySeed: getDailyUtcSeed(),
      entries: filtered.slice(0, 25),
    });
  });

  // 4. Authoritative Combat Telemetry Recorder & Anti-Cheat Verification
  app.post('/api/telemetry/verify', (req, res) => {
    const payload = req.body as TelemetrySubmissionPayload;
    const verification = verifyRunTelemetry(payload);

    if (!verification.verified) {
      res.status(200).json({
        ...verification,
        recorded: false,
      });
      return;
    }

    const entries = loadLeaderboard();
    const newEntry: LeaderboardEntry = {
      id: `lb_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      playerName: (payload.playerName || 'Quarantine_Operative').slice(0, 24),
      runSeed: payload.runSeed,
      wavesCleared: payload.wavesCleared,
      finalScore: Math.round(payload.finalScore),
      scrapCollected: Math.round(payload.scrapCollected),
      biomassHarvested: Math.round(payload.biomassHarvested || 0),
      durationMs: Math.round(payload.durationMs),
      favoriteSynergy: payload.favoriteSynergy || 'MK-IV Tactical Sidearm',
      verifiedHash: verification.verificationHash,
      createdAt: new Date().toISOString(),
    };

    entries.push(newEntry);
    entries.sort((a, b) => b.finalScore - a.finalScore);
    saveLeaderboard(entries);

    const rank = entries.findIndex((e) => e.id === newEntry.id) + 1;

    res.json({
      ...verification,
      recorded: true,
      rank,
      entry: newEntry,
    });
  });

  // 5. Live Outpost Relay Feed
  app.get('/api/spectator/live', (_req, res) => {
    const dailySeed = getDailyUtcSeed();
    res.json({
      activeOperatives: 14,
      relays: [
        { handle: 'Kestrel_Vanguard', wave: 11, hp: 78, weapon: 'Tesla M870', seed: dailySeed },
        { handle: 'Ash_Hound', wave: 8, hp: 42, weapon: 'Hellfire Valkyrie', seed: dailySeed },
        { handle: 'Night_Watch_04', wave: 6, hp: 94, weapon: 'Cryo-Zero MK-IV', seed: dailySeed },
      ],
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Outpost Zero server running on http://localhost:${PORT}`);
  });
}

startServer();
