import { useState } from 'react';
import { CombatHudOverlay } from './components/CombatHudOverlay';
import { PauseSettingsModal } from './components/PauseSettingsModal';
import { PostMortemModal } from './components/PostMortemModal';
import { ScrapForgeDrawer } from './components/ScrapForgeDrawer';
import { TitleScreenOverlay } from './components/TitleScreenOverlay';
import { useZombieSurvivalEngine } from './hooks/useZombieSurvivalEngine';
import { AccessibilitySettings } from './types/game';

export default function App() {
  const [settings, setSettings] = useState<AccessibilitySettings>({
    masterVolume: 0.75,
    sfxVolume: 0.85,
    muted: false,
    screenShakeIntensity: 70,
    autoAimAssist: false,
    autoFire: false,
    crosshairColor: '#10B981',
    showTouchControls: false,
  });

  const [titleSettingsOpen, setTitleSettingsOpen] = useState(false);

  const {
    canvasMountRef,
    hudState,
    callouts,
    forgeOpen,
    setForgeOpen,
    startGame,
    pauseGame,
    resumeGame,
    returnToTitle,
    endRunForDebrief,
    selectWeapon,
    triggerReload,
    deployFloodlight,
    deployMine,
    repairBarricade,
    skipIntermission,
    applyForgeUpgrade,
    setVirtualInput,
    getTelemetryPayload,
  } = useZombieSurvivalEngine(settings);

  const isPlaying =
    hudState.status === 'WAVE_ACTIVE' ||
    hudState.status === 'WAVE_INTERMISSION' ||
    hudState.status === 'PAUSED';

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#070A0B] select-none">
      {/* Isolated Full-Bleed Three.js 3D WebGL Viewport Container */}
      <div
        ref={canvasMountRef}
        data-testid="survival-arena-canvas"
        className="fixed inset-0 w-full h-full z-0"
      />

      {/* Title Screen Stage Overlay */}
      {hudState.status === 'IDLE' && (
        <TitleScreenOverlay
          onStartGame={(seed, isDaily) => startGame(seed, isDaily)}
          onOpenSettings={() => setTitleSettingsOpen(true)}
        />
      )}

      {/* Active Combat & Intermission HUD Overlay */}
      {isPlaying && (
        <CombatHudOverlay
          state={hudState}
          callouts={callouts}
          settings={settings}
          forgeOpen={forgeOpen}
          onToggleForge={() => setForgeOpen((prev) => !prev)}
          onSelectWeapon={selectWeapon}
          onTriggerReload={triggerReload}
          onDeployFloodlight={deployFloodlight}
          onDeployMine={deployMine}
          onRepairBarricade={repairBarricade}
          onSkipIntermission={skipIntermission}
          onPause={pauseGame}
          onVirtualInput={setVirtualInput}
        />
      )}

      {/* Modular Scrap Forge Drawer */}
      <ScrapForgeDrawer
        open={forgeOpen && isPlaying}
        state={hudState}
        onClose={() => setForgeOpen(false)}
        onApplyUpgrade={applyForgeUpgrade}
      />

      {/* Pause & Accessibility Calibration Modal */}
      <PauseSettingsModal
        open={hudState.status === 'PAUSED' || titleSettingsOpen}
        isPlayingSession={hudState.status === 'PAUSED'}
        settings={settings}
        onUpdateSettings={setSettings}
        onResume={() => {
          if (hudState.status === 'PAUSED') resumeGame();
          setTitleSettingsOpen(false);
        }}
        onRestart={() => {
          setTitleSettingsOpen(false);
          startGame(hudState.seed, hudState.isDailyProtocol);
        }}
        onExtractDebrief={() => {
          setTitleSettingsOpen(false);
          endRunForDebrief();
        }}
        onReturnToTitle={() => {
          setTitleSettingsOpen(false);
          returnToTitle();
        }}
      />

      {/* Post-Mortem Quarantine Debrief & Anti-Cheat Telemetry Verification Modal */}
      <PostMortemModal
        open={hudState.status === 'GAME_OVER'}
        state={hudState}
        getTelemetryPayload={getTelemetryPayload}
        onPlayAgain={() => startGame(hudState.seed, hudState.isDailyProtocol)}
        onReturnToTitle={returnToTitle}
      />
    </main>
  );
}
