import React, { useRef, useState } from 'react';
import { soundEngine } from '../game/sound';
import { FloatingCallout } from '../hooks/useZombieSurvivalEngine';
import { AccessibilitySettings, ZombieSurvivalGameState } from '../types/game';

interface CombatHudOverlayProps {
  state: ZombieSurvivalGameState;
  callouts: FloatingCallout[];
  settings: AccessibilitySettings;
  forgeOpen: boolean;
  onToggleForge: () => void;
  onSelectWeapon: (idx: number) => void;
  onTriggerReload: () => void;
  onDeployFloodlight: () => void;
  onDeployMine: () => void;
  onRepairBarricade: () => void;
  onSkipIntermission: () => void;
  onPause: () => void;
  onVirtualInput: (
    moveX: number,
    moveY: number,
    aimX: number,
    aimY: number,
    firing: boolean
  ) => void;
}

export const CombatHudOverlay: React.FC<CombatHudOverlayProps> = ({
  state,
  callouts,
  settings,
  forgeOpen,
  onToggleForge,
  onSelectWeapon,
  onTriggerReload,
  onDeployFloodlight,
  onDeployMine,
  onRepairBarricade,
  onSkipIntermission,
  onPause,
  onVirtualInput,
}) => {
  const [isMuted, setIsMuted] = useState(soundEngine.isMuted());
  const moveStickRef = useRef<{ active: boolean; startX: number; startY: number; curX: number; curY: number }>({
    active: false,
    startX: 0,
    startY: 0,
    curX: 0,
    curY: 0,
  });
  const aimStickRef = useRef<{ active: boolean; startX: number; startY: number; curX: number; curY: number }>({
    active: false,
    startX: 0,
    startY: 0,
    curX: 0,
    curY: 0,
  });

  const activeWeapon = state.player.weapons[state.player.activeWeaponIndex] || state.player.weapons[0];
  const isCriticalHp = state.player.hp <= state.player.maxHp * 0.25;

  // Format elapsed clock MM:SS
  const totalSec = Math.floor(state.stats.timeSurvivedMs / 1000);
  const mins = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const secs = String(totalSec % 60).padStart(2, '0');

  const waveProgressPct =
    state.totalWaveEnemies > 0
      ? Math.max(0, Math.min(100, Math.round((state.enemiesRemaining / state.totalWaveEnemies) * 100)))
      : 0;

  const syncVirtualSticks = () => {
    const m = moveStickRef.current;
    const a = aimStickRef.current;
    const mx = m.active ? Math.max(-1, Math.min(1, (m.curX - m.startX) / 40)) : 0;
    const my = m.active ? Math.max(-1, Math.min(1, (m.curY - m.startY) / 40)) : 0;
    const ax = a.active ? Math.max(-1, Math.min(1, (a.curX - a.startX) / 40)) : 0;
    const ay = a.active ? Math.max(-1, Math.min(1, (a.curY - a.startY) / 40)) : 0;
    onVirtualInput(mx, my, ax, ay, a.active);
  };

  return (
    <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-between p-3 md:p-5 select-none">
      {/* Critical Health Vignette (<25% HP) */}
      {isCriticalHp && (
        <div
          className="fixed inset-0 pointer-events-none z-0"
          style={{
            boxShadow: 'inset 0 0 95px rgba(239, 68, 68, 0.52)',
          }}
        />
      )}

      {/* TOP FLOATING TELEMETRY CAPSULE */}
      <div className="w-full max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left Cluster: Wave & Hazard Status */}
        <div className="pointer-events-auto flex items-center gap-3 bg-[#0C1012]/92 border border-[#1E272B] rounded-md px-4 py-2 shadow-lg">
          <svg viewBox="0 0 24 24" className="w-6 h-6 text-[#F59E0B] shrink-0" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="8" r="3.5" />
            <circle cx="8.5" cy="14.5" r="3.5" />
            <circle cx="15.5" cy="14.5" r="3.5" />
          </svg>
          <div>
            <div className="text-[11px] font-mono-tech uppercase tracking-wider text-slate-400">
              HAZARD: <span className="text-[#F59E0B] font-semibold">{state.hazardLevel}</span>
              {state.isBlackout && (
                <span className="ml-2 text-[#EF4444] font-bold">· BLACKOUT</span>
              )}
            </div>
            <div className="text-lg md:text-xl font-display font-bold text-[#F8FAFC] tabular-nums leading-tight">
              WAVE {String(state.currentWave).padStart(2, '0')}
            </div>
          </div>
        </div>

        {/* Center Cluster: Hostiles Remaining Progress Runner or Intermission Banner */}
        <div className="pointer-events-auto flex-1 max-w-md bg-[#0C1012]/92 border border-[#1E272B] rounded-md px-4 py-2 shadow-lg">
          {state.status === 'WAVE_INTERMISSION' ? (
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-[11px] font-mono-tech uppercase text-[#10B981]">
                  WAVE INTERMISSION · FORGE OPEN
                </div>
                <div className="text-sm font-mono-tech font-bold text-[#F8FAFC] tabular-nums">
                  Next Swarm in {Math.ceil(state.intermissionTimerMs / 1000)}s
                </div>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.currentTarget.blur();
                  onSkipIntermission();
                }}
                className="px-3 py-1.5 bg-[#F59E0B] hover:bg-[#D97706] text-[#070A0B] font-bold text-xs rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Deploy Next Wave
              </button>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between text-xs font-mono-tech mb-1">
                <span className="text-slate-300 uppercase">Hostiles Remaining</span>
                <span className="text-[#F8FAFC] font-bold tabular-nums">
                  {state.enemiesRemaining}
                </span>
              </div>
              <div className="w-full h-2 bg-[#13191C] rounded-sm overflow-hidden border border-[#1E272B]">
                <div
                  className="h-full bg-[#EF4444] transition-all duration-150"
                  style={{ width: `${waveProgressPct}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Right Cluster: Scrap Tally, Score, Clock & Utility Square Buttons */}
        <div className="pointer-events-auto flex items-center gap-2.5 bg-[#0C1012]/92 border border-[#1E272B] rounded-md px-4 py-2 shadow-lg">
          <div className="pr-3 border-r border-[#1E272B]">
            <div className="text-[10px] font-mono-tech uppercase text-slate-400">SCRAP</div>
            <div className="text-base md:text-lg font-mono-tech font-bold text-[#F59E0B] tabular-nums">
              {state.player.scrap}
            </div>
          </div>

          <div className="pr-3 border-r border-[#1E272B]">
            <div className="text-[10px] font-mono-tech uppercase text-slate-400">SCORE</div>
            <div className="text-base md:text-lg font-mono-tech font-bold text-[#F8FAFC] tabular-nums">
              {state.stats.score}
            </div>
          </div>

          <div className="pr-2">
            <div className="text-[10px] font-mono-tech uppercase text-slate-400">TIME</div>
            <div className="text-base md:text-lg font-mono-tech font-bold text-slate-200 tabular-nums">
              {mins}:{secs}
            </div>
          </div>

          {/* Compact Utility Controls: Forge [E], Mute [M], Pause [P] */}
          <button
            type="button"
            tabIndex={-1}
            aria-label="Open Scrap Forge Workbench"
            onClick={(e) => {
              e.currentTarget.blur();
              onToggleForge();
            }}
            className={`px-2.5 py-2 rounded border text-xs font-mono-tech font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              forgeOpen
                ? 'bg-[#F59E0B] text-[#070A0B] border-[#F59E0B]'
                : 'bg-[#13191C] text-[#F59E0B] border-amber-500/40 hover:bg-[#1E272B]'
            }`}
          >
            Forge [E]
          </button>

          <button
            type="button"
            tabIndex={-1}
            aria-label={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            onClick={(e) => {
              e.currentTarget.blur();
              const next = soundEngine.toggleMute();
              setIsMuted(next);
            }}
            className="w-9 h-9 flex items-center justify-center rounded bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-slate-200 cursor-pointer shrink-0"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
              {isMuted ? (
                <path d="M11 5L6 9H2v6h4l5 4V5zM22 9l-6 6M16 9l6 6" />
              ) : (
                <path d="M11 5L6 9H2v6h4l5 4V5zM15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14" />
              )}
            </svg>
          </button>

          <button
            type="button"
            tabIndex={-1}
            aria-label="Pause Game"
            onClick={(e) => {
              e.currentTarget.blur();
              onPause();
            }}
            className="w-9 h-9 flex items-center justify-center rounded bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-slate-200 cursor-pointer shrink-0"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="6" y="4" width="4" height="16" />
              <rect x="14" y="4" width="4" height="16" />
            </svg>
          </button>
        </div>
      </div>

      {/* CENTER PLAYFIELD GAZE CUES & FLOATING CALLOUTS (Unobstructed >= 85% Viewport) */}
      <div className="relative flex-1 flex flex-col items-center justify-end pb-4 pointer-events-none">
        {/* Floating Combat Callouts */}
        <div className="flex flex-col items-center gap-1 mb-3">
          {callouts.slice(-3).map((co) => (
            <div
              key={co.id}
              className="text-xs md:text-sm font-mono-tech font-bold tracking-wider uppercase hud-text-stroke"
              style={{ color: co.color }}
            >
              {co.text}
            </div>
          ))}
        </div>

        {/* Active Reload Sweet-Spot Bar (Positioned in player's lower-center peripheral gaze) */}
        {state.reloadState.isReloading && (
          <div className="pointer-events-auto w-64 bg-[#0C1012]/95 border border-[#1E272B] rounded-md p-2.5 shadow-xl mb-2">
            <div className="flex items-center justify-between text-[11px] font-mono-tech mb-1">
              <span className="text-[#10B981] font-bold">PRESS [R] IN GREEN ZONE</span>
              <span className="text-slate-400 tabular-nums">
                {Math.round(state.reloadState.progress * 100)}%
              </span>
            </div>
            <div className="relative w-full h-3 bg-[#13191C] rounded overflow-hidden border border-[#1E272B]">
              {/* Sweet-Spot Window [42% - 68%] */}
              <div
                className="absolute top-0 bottom-0 bg-[#10B981]/45 border-x border-[#10B981]"
                style={{
                  left: `${state.reloadState.sweetSpotStart * 100}%`,
                  width: `${(state.reloadState.sweetSpotEnd - state.reloadState.sweetSpotStart) * 100}%`,
                }}
              />
              {/* Moving Reload Cursor */}
              <div
                className="absolute top-0 bottom-0 w-1.5 bg-[#F8FAFC]"
                style={{ left: `${Math.min(98, state.reloadState.progress * 100)}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* MOBILE VIRTUAL DUAL-THUMBSTICK OVERLAY */}
      {settings.showTouchControls && (
        <div className="fixed inset-x-0 bottom-28 z-20 flex items-center justify-between px-6 pointer-events-none md:hidden">
          {/* Left Virtual Move Joystick */}
          <div
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              moveStickRef.current = {
                active: true,
                startX: e.clientX,
                startY: e.clientY,
                curX: e.clientX,
                curY: e.clientY,
              };
              syncVirtualSticks();
            }}
            onPointerMove={(e) => {
              if (!moveStickRef.current.active) return;
              moveStickRef.current.curX = e.clientX;
              moveStickRef.current.curY = e.clientY;
              syncVirtualSticks();
            }}
            onPointerUp={() => {
              moveStickRef.current.active = false;
              syncVirtualSticks();
            }}
            className="pointer-events-auto w-28 h-28 rounded-full bg-[#0C1012]/80 border-2 border-[#1E272B] flex items-center justify-center touch-none"
          >
            <span className="text-[11px] font-mono-tech text-slate-400">MOVE</span>
          </div>

          {/* Right Virtual Aim & Fire Joystick + Rapid Reload */}
          <div className="pointer-events-auto flex items-center gap-3">
            <button
              type="button"
              onClick={onTriggerReload}
              className="w-14 h-14 rounded-full bg-[#13191C] border border-[#10B981] text-[#10B981] font-mono-tech text-xs font-bold"
            >
              RLD
            </button>
            <div
              onPointerDown={(e) => {
                e.currentTarget.setPointerCapture(e.pointerId);
                aimStickRef.current = {
                  active: true,
                  startX: e.clientX,
                  startY: e.clientY,
                  curX: e.clientX,
                  curY: e.clientY,
                };
                syncVirtualSticks();
              }}
              onPointerMove={(e) => {
                if (!aimStickRef.current.active) return;
                aimStickRef.current.curX = e.clientX;
                aimStickRef.current.curY = e.clientY;
                syncVirtualSticks();
              }}
              onPointerUp={() => {
                aimStickRef.current.active = false;
                syncVirtualSticks();
              }}
              className="w-28 h-28 rounded-full bg-[#0C1012]/80 border-2 border-[#F59E0B]/60 flex items-center justify-center touch-none"
            >
              <span className="text-[11px] font-mono-tech text-[#F59E0B]">AIM / FIRE</span>
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM TACTICAL DOCK */}
      <div className="w-full max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-3 items-end">
        {/* Left: Vital Status Capsule (Segmented Health + Trailing Ghost Bar + Armor) */}
        <div
          className={`pointer-events-auto lg:col-span-4 bg-[#0C1012]/92 border rounded-md p-3.5 shadow-lg ${
            isCriticalHp ? 'border-[#EF4444]' : 'border-[#1E272B]'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-mono-tech uppercase tracking-wider text-slate-400">
              VITALITY STATUS
            </span>
            <span
              className={`text-lg font-mono-tech font-bold tabular-nums ${
                isCriticalHp ? 'text-[#EF4444]' : 'text-[#10B981]'
              }`}
            >
              {state.player.hp} / {state.player.maxHp} HP
            </span>
          </div>

          {/* Continuous Health Bar with Delayed Trailing Damage Ghost Bar */}
          <div className="relative w-full h-3 bg-[#13191C] rounded-sm overflow-hidden border border-[#1E272B] mb-2.5">
            <div
              className="absolute top-0 left-0 bottom-0 bg-[#EF4444]/60 transition-all duration-300"
              style={{ width: `${(state.player.trailingHp / state.player.maxHp) * 100}%` }}
            />
            <div
              className={`absolute top-0 left-0 bottom-0 transition-all duration-75 ${
                isCriticalHp ? 'bg-[#EF4444]' : 'bg-[#10B981]'
              }`}
              style={{ width: `${(state.player.hp / state.player.maxHp) * 100}%` }}
            />
          </div>

          {/* Cryo-Cyan Ballistic Armor Bar */}
          <div className="flex items-center justify-between text-xs font-mono-tech mb-1">
            <span className="text-slate-400">BALLISTIC ARMOR</span>
            <span className="text-[#38BDF8] font-semibold tabular-nums">
              {state.player.armor} / {state.player.maxArmor}
            </span>
          </div>
          <div className="w-full h-2 bg-[#13191C] rounded-sm overflow-hidden border border-[#1E272B]">
            <div
              className="h-full bg-[#38BDF8] transition-all duration-150"
              style={{ width: `${(state.player.armor / state.player.maxArmor) * 100}%` }}
            />
          </div>
        </div>

        {/* Center: Ammunition Counter & Tactical Fortification Quick-Belt */}
        <div className="pointer-events-auto lg:col-span-4 bg-[#0C1012]/92 border border-[#1E272B] rounded-md p-3.5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-[#1E272B]">
            <div>
              <div className="text-[11px] font-mono-tech uppercase text-slate-400">
                MAGAZINE CAPACITY
                {state.reloadState.overchargeRemainingMs > 0 && (
                  <span className="ml-2 text-[#10B981] font-bold">· OVERCHARGED</span>
                )}
              </div>
              <div className="text-2xl font-mono-tech font-bold text-[#F8FAFC] tabular-nums">
                {activeWeapon.currentAmmo}{' '}
                <span className="text-sm text-slate-400">/ {activeWeapon.clipSize}</span>
              </div>
            </div>

            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onTriggerReload();
              }}
              className="px-3 py-2 rounded bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-xs font-mono-tech font-semibold text-[#10B981] cursor-pointer whitespace-nowrap shrink-0"
            >
              {state.reloadState.isReloading ? 'Sweet Spot [R]' : 'Reload [R]'}
            </button>
          </div>

          {/* Tactical Trap & Barricade Quick Buttons */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onRepairBarricade();
              }}
              className="p-2 rounded bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-left transition-colors cursor-pointer"
            >
              <div className="text-[10px] font-mono-tech text-[#F59E0B] font-bold">[B] BARRICADE</div>
              <div className="text-xs text-slate-200 font-medium truncate">30 Scrap</div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onDeployFloodlight();
              }}
              className="p-2 rounded bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-left transition-colors cursor-pointer"
            >
              <div className="text-[10px] font-mono-tech text-[#38BDF8] font-bold">[F] FLOODLIGHT</div>
              <div className="text-xs text-slate-200 font-mono-tech tabular-nums truncate">
                {state.player.floodlightCharges > 0
                  ? `${state.player.floodlightCharges} Ready`
                  : '50 Scrap'}
              </div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onDeployMine();
              }}
              className="p-2 rounded bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-left transition-colors cursor-pointer"
            >
              <div className="text-[10px] font-mono-tech text-[#EF4444] font-bold">[G] TRIPWIRE</div>
              <div className="text-xs text-slate-200 font-mono-tech tabular-nums truncate">
                {state.player.mineCharges > 0 ? `${state.player.mineCharges} Ready` : '40 Scrap'}
              </div>
            </button>
          </div>
        </div>

        {/* Right: 3-Slot Weapon Quick-Rack ([1], [2], [3]) */}
        <div className="pointer-events-auto lg:col-span-4 bg-[#0C1012]/92 border border-[#1E272B] rounded-md p-2.5 shadow-lg grid grid-cols-3 gap-2">
          {state.player.weapons.map((wpn, idx) => {
            const isSelected = idx === state.player.activeWeaponIndex;
            const elColor =
              wpn.elemental === 'shock'
                ? 'text-[#06B6D4]'
                : wpn.elemental === 'incendiary'
                  ? 'text-[#F59E0B]'
                  : wpn.elemental === 'cryo'
                    ? 'text-[#38BDF8]'
                    : 'text-slate-400';

            return (
              <button
                key={wpn.id}
                type="button"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  onSelectWeapon(idx);
                }}
                className={`p-2.5 rounded border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#13191C] border-[#F59E0B] shadow-md'
                    : 'bg-[#070A0B]/80 border-[#1E272B] hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] font-mono-tech mb-1">
                  <span className={isSelected ? 'text-[#F59E0B] font-bold' : 'text-slate-400'}>
                    [{idx + 1}] T{wpn.tier}
                  </span>
                  <span className={`uppercase font-semibold ${elColor}`}>
                    {wpn.elemental === 'none' ? 'STD' : wpn.elemental.slice(0, 4)}
                  </span>
                </div>
                <div className="text-xs font-bold text-[#F8FAFC] truncate">{wpn.name}</div>
                <div className="text-[10px] text-slate-400 truncate mb-0.5">{wpn.roleDesc}</div>
                <div className="text-[11px] font-mono-tech text-slate-300 tabular-nums">
                  {wpn.currentAmmo}/{wpn.clipSize} · {wpn.baseDamage} DMG
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
