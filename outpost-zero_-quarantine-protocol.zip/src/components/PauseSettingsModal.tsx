import React from 'react';
import { AccessibilitySettings } from '../types/game';

interface PauseSettingsModalProps {
  open: boolean;
  isPlayingSession: boolean;
  settings: AccessibilitySettings;
  onUpdateSettings: (next: AccessibilitySettings) => void;
  onResume: () => void;
  onRestart: () => void;
  onExtractDebrief: () => void;
  onReturnToTitle: () => void;
}

export const PauseSettingsModal: React.FC<PauseSettingsModalProps> = ({
  open,
  isPlayingSession,
  settings,
  onUpdateSettings,
  onResume,
  onRestart,
  onExtractDebrief,
  onReturnToTitle,
}) => {
  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Tactical Pause and Calibration Settings"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/80"
    >
      <div className="w-full max-w-lg bg-[#0C1012] border border-[#1E272B] rounded-lg p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-4 mb-5 border-b border-[#1E272B]">
          <div>
            <h2 className="text-xl font-display font-bold text-[#F8FAFC]">
              {isPlayingSession ? 'Quarantine Paused' : 'Tactical Calibration Settings'}
            </h2>
            <p className="text-xs text-slate-400">
              Configure audio levels, recoil trauma damping, and combat accessibility.
            </p>
          </div>
          <span className="text-xs font-mono-tech text-[#F59E0B]">ESC / P</span>
        </div>

        {/* Sliders & Accessibility Controls */}
        <div className="space-y-4 mb-6">
          <div>
            <div className="flex justify-between text-xs font-mono-tech mb-1">
              <label htmlFor="master-vol-slider" className="text-slate-300">
                Master Audio Output
              </label>
              <span className="text-[#F8FAFC] tabular-nums">
                {Math.round(settings.masterVolume * 100)}%
              </span>
            </div>
            <input
              id="master-vol-slider"
              type="range"
              min={0}
              max={100}
              value={Math.round(settings.masterVolume * 100)}
              onChange={(e) =>
                onUpdateSettings({ ...settings, masterVolume: Number(e.target.value) / 100 })
              }
              className="w-full accent-[#F59E0B]"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-mono-tech mb-1">
              <label htmlFor="shake-slider" className="text-slate-300">
                Camera Recoil &amp; Trauma Shake
              </label>
              <span className="text-[#F8FAFC] tabular-nums">{settings.screenShakeIntensity}%</span>
            </div>
            <input
              id="shake-slider"
              type="range"
              min={0}
              max={100}
              value={settings.screenShakeIntensity}
              onChange={(e) =>
                onUpdateSettings({ ...settings, screenShakeIntensity: Number(e.target.value) })
              }
              className="w-full accent-[#F59E0B]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({ ...settings, autoAimAssist: !settings.autoAimAssist })
              }
              className={`p-3 rounded border text-left transition-colors cursor-pointer ${
                settings.autoAimAssist
                  ? 'bg-[#13191C] border-[#10B981] text-[#10B981]'
                  : 'bg-[#070A0B] border-[#1E272B] text-slate-400'
              }`}
            >
              <div className="text-xs font-bold">Auto-Aim Snap Assist</div>
              <div className="text-[11px] font-mono-tech">
                {settings.autoAimAssist ? 'ENABLED' : 'MANUAL CURSOR'}
              </div>
            </button>

            <button
              type="button"
              onClick={() => onUpdateSettings({ ...settings, autoFire: !settings.autoFire })}
              className={`p-3 rounded border text-left transition-colors cursor-pointer ${
                settings.autoFire
                  ? 'bg-[#13191C] border-[#F59E0B] text-[#F59E0B]'
                  : 'bg-[#070A0B] border-[#1E272B] text-slate-400'
              }`}
            >
              <div className="text-xs font-bold">Continuous Auto-Fire</div>
              <div className="text-[11px] font-mono-tech">
                {settings.autoFire ? 'ENABLED' : 'MANUAL TRIGGER'}
              </div>
            </button>
          </div>

          {/* Mobile Touch Overlay Toggle */}
          <div className="flex items-center justify-between p-3 rounded bg-[#13191C] border border-[#1E272B]">
            <span className="text-xs font-medium text-slate-200">
              On-Screen Virtual Dual Thumbsticks
            </span>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({ ...settings, showTouchControls: !settings.showTouchControls })
              }
              className={`px-3 py-1 rounded text-xs font-mono-tech font-bold cursor-pointer ${
                settings.showTouchControls
                  ? 'bg-[#38BDF8] text-[#070A0B]'
                  : 'bg-[#070A0B] text-slate-400 border border-[#1E272B]'
              }`}
            >
              {settings.showTouchControls ? 'SHOWN' : 'AUTO / HIDDEN'}
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-[#1E272B]">
          <button
            type="button"
            onClick={onResume}
            className="flex-1 py-2.5 px-4 bg-[#F59E0B] hover:bg-[#D97706] text-[#070A0B] font-bold text-sm rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            {isPlayingSession ? 'Resume Combat' : 'Save & Close'}
          </button>

          {isPlayingSession && (
            <>
              <button
                type="button"
                onClick={onRestart}
                className="py-2.5 px-4 bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-slate-200 font-semibold text-sm rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Restart Wave 1
              </button>
              <button
                type="button"
                onClick={onExtractDebrief}
                className="py-2.5 px-4 bg-[#13191C] hover:bg-[#1E272B] border border-emerald-500/40 text-[#10B981] font-semibold text-sm rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Extract &amp; Debrief
              </button>
              <button
                type="button"
                onClick={onReturnToTitle}
                className="py-2.5 px-4 bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-slate-400 hover:text-slate-200 font-semibold text-sm rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Title Screen
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
