import React, { useEffect, useState } from 'react';
import { formatEmojiScorecard } from '../game/rules';
import {
  TelemetrySubmissionPayload,
  TelemetryVerificationResult,
  ZombieSurvivalGameState,
} from '../types/game';

interface PostMortemModalProps {
  open: boolean;
  state: ZombieSurvivalGameState;
  getTelemetryPayload: (playerName: string) => TelemetrySubmissionPayload;
  onPlayAgain: () => void;
  onReturnToTitle: () => void;
}

export const PostMortemModal: React.FC<PostMortemModalProps> = ({
  open,
  state,
  getTelemetryPayload,
  onPlayAgain,
  onReturnToTitle,
}) => {
  const [playerName, setPlayerName] = useState('Vanguard_09');
  const [verification, setVerification] = useState<
    (TelemetryVerificationResult & { recorded?: boolean }) | null
  >(null);
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);

  const accuracyPct =
    state.stats.shotsFired > 0
      ? Math.min(100, Math.round((state.stats.shotsHit / state.stats.shotsFired) * 100))
      : 0;

  const favoriteWeapon =
    state.player.weapons.reduce((best, cur) => (cur.tier > best.tier ? cur : best))?.name ||
    'MK-IV Tactical Sidearm';

  const submitTelemetry = async (handleName: string) => {
    setSubmitting(true);
    try {
      const payload = getTelemetryPayload(handleName);
      const res = await fetch('/api/telemetry/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        setVerification(data);
      }
    } catch {
      // Fallback local verification if offline
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    if (open) {
      setVerification(null);
      setCopied(false);
      submitTelemetry(playerName);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  if (!open) return null;

  const scorecardBadge = formatEmojiScorecard({
    seed: state.seed,
    wavesCleared: state.currentWave,
    scrapCollected: state.stats.scrapCollectedTotal,
    durationMs: state.stats.timeSurvivedMs,
    accuracyPct,
    favoriteSynergy: favoriteWeapon,
    verifiedHash: verification?.verificationHash,
  });

  const handleCopyBadge = () => {
    navigator.clipboard?.writeText(scorecardBadge).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Post-Mortem Quarantine Debrief"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/85"
    >
      <div className="w-full max-w-2xl bg-[#0C1012] border border-[#1E272B] rounded-lg p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-5 border-b border-[#1E272B]">
          <div>
            <div className="text-xs font-mono-tech uppercase text-[#EF4444] font-semibold">
              QUARANTINE DEBRIEF · SEED {state.seed}
            </div>
            <h2 className="text-2xl font-display font-bold text-[#F8FAFC]">
              {state.stats.causeOfDeath || `Overrun on Wave ${state.currentWave}`}
            </h2>
          </div>

          {verification && (
            <div className="px-3 py-1.5 rounded bg-[#13191C] border border-[#1E272B] text-right font-mono-tech">
              <div
                className={`text-xs font-bold ${
                  verification.verified ? 'text-[#10B981]' : 'text-[#EF4444]'
                }`}
              >
                {verification.verified
                  ? `LEDGER VERIFIED ${verification.rank ? `· RANK #${verification.rank}` : ''}`
                  : 'TELEMETRY FLAGGED'}
              </div>
              <div className="text-[11px] text-slate-400 tabular-nums">
                {verification.verificationHash}
              </div>
            </div>
          )}
        </div>

        {/* 3 Core Tabular-Nums Mastery / Progress Stat Tiles */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="p-3.5 rounded bg-[#13191C] border border-[#1E272B]">
            <div className="text-xs font-mono-tech text-slate-400">WAVE REACHED</div>
            <div className="text-2xl font-mono-tech font-bold text-[#F59E0B] tabular-nums">
              Wave {state.currentWave}
            </div>
          </div>

          <div className="p-3.5 rounded bg-[#13191C] border border-[#1E272B]">
            <div className="text-xs font-mono-tech text-slate-400">FINAL SCORE / BEST</div>
            <div className="text-2xl font-mono-tech font-bold text-[#F8FAFC] tabular-nums">
              {state.stats.score.toLocaleString()}
              <span className="text-xs text-slate-400 ml-1">
                / {state.stats.bestScore.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="p-3.5 rounded bg-[#13191C] border border-[#1E272B]">
            <div className="text-xs font-mono-tech text-slate-400">ACCURACY &amp; KILLS</div>
            <div className="text-2xl font-mono-tech font-bold text-[#10B981] tabular-nums">
              {accuracyPct}% · {state.stats.totalKills}
            </div>
          </div>
        </div>

        {/* Mutant Kills Breakdown */}
        <div className="p-4 rounded bg-[#13191C] border border-[#1E272B] mb-5">
          <div className="text-xs font-semibold text-slate-300 mb-2.5">
            Eliminations by Mutant Strain
          </div>
          <div className="grid grid-cols-5 gap-2 text-center font-mono-tech text-xs">
            {(
              [
                ['walker', 'Walkers'],
                ['sprinter', 'Sprinters'],
                ['spitter', 'Spitters'],
                ['brute', 'Brutes'],
                ['screamer', 'Screamers'],
              ] as const
            ).map(([k, label]) => (
              <div key={k} className="p-2 rounded bg-[#070A0B] border border-[#1E272B]">
                <div className="text-slate-400 text-[11px]">{label}</div>
                <div className="text-base font-bold text-[#F8FAFC] tabular-nums">
                  {state.stats.killsByType[k] || 0}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Shareable Emoji Scorecard Badge */}
        <div className="p-4 rounded bg-[#13191C] border border-[#1E272B] mb-5">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-slate-300">
              Shareable Quarantine Protocol Scorecard
            </span>
            <button
              type="button"
              onClick={handleCopyBadge}
              className="px-3 py-1 rounded bg-[#F59E0B] hover:bg-[#D97706] text-[#070A0B] font-bold text-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              {copied ? 'Copied Badge!' : 'Copy Emoji Scorecard'}
            </button>
          </div>
          <div className="p-2.5 rounded bg-[#070A0B] border border-[#1E272B] text-xs font-mono-tech text-slate-200 select-all break-all">
            {scorecardBadge}
          </div>
        </div>

        {/* Operative Callsign Leaderboard Update */}
        <div className="flex items-center gap-2 mb-6">
          <label htmlFor="debrief-callsign" className="text-xs text-slate-400 shrink-0">
            Operative Handle:
          </label>
          <input
            id="debrief-callsign"
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="flex-1 px-3 py-1.5 rounded bg-[#070A0B] border border-[#1E272B] text-xs font-mono-tech text-[#F8FAFC]"
          />
          <button
            type="button"
            disabled={submitting}
            onClick={() => submitTelemetry(playerName)}
            className="px-3 py-1.5 rounded bg-[#1E272B] hover:bg-slate-700 text-xs font-semibold text-slate-200 cursor-pointer whitespace-nowrap shrink-0"
          >
            {submitting ? 'Verifying...' : 'Sync Ledger'}
          </button>
        </div>

        {/* Primary Action CTAs */}
        <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-[#1E272B]">
          <button
            type="button"
            data-start="true"
            onClick={onPlayAgain}
            className="flex-1 py-3 px-6 bg-[#F59E0B] hover:bg-[#D97706] text-[#070A0B] font-display font-bold text-base rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Deploy Again (Same Seed)
          </button>

          <button
            type="button"
            onClick={onReturnToTitle}
            className="py-3 px-5 bg-[#13191C] hover:bg-[#1E272B] border border-[#1E272B] text-slate-200 font-semibold text-sm rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Return to Title
          </button>
        </div>
      </div>
    </div>
  );
};
