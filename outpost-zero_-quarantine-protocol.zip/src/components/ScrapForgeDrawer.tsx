import React, { useState } from 'react';
import { SCRAP_FORGE_CATALOG } from '../game/rules';
import { ForgeUpgradeOption, ZombieSurvivalGameState } from '../types/game';

interface ScrapForgeDrawerProps {
  open: boolean;
  state: ZombieSurvivalGameState;
  onClose: () => void;
  onApplyUpgrade: (upgrade: ForgeUpgradeOption) => boolean;
}

export const ScrapForgeDrawer: React.FC<ScrapForgeDrawerProps> = ({
  open,
  state,
  onClose,
  onApplyUpgrade,
}) => {
  const [filter, setFilter] = useState<'all' | 'elemental' | 'ballistics' | 'fortification'>('all');
  const [lastForgedId, setLastForgedId] = useState<string | null>(null);

  if (!open) return null;

  const filteredUpgrades = SCRAP_FORGE_CATALOG.filter((u) =>
    filter === 'all' ? true : u.category === filter
  );

  const handleForge = (upgrade: ForgeUpgradeOption) => {
    const ok = onApplyUpgrade(upgrade);
    if (ok) {
      setLastForgedId(upgrade.id);
      setTimeout(() => setLastForgedId(null), 900);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Scrap Forge Weapon Workbench"
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-black/75"
    >
      <div className="w-full max-w-4xl bg-[#0C1012] border border-[#1E272B] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Workbench Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 bg-[#13191C] border-b border-[#1E272B]">
          <div>
            <h2 className="text-xl font-display font-bold text-[#F8FAFC]">
              Scrap Forge &amp; Modular Armory
            </h2>
            <p className="text-xs text-slate-400">
              Combine industrial scrap and mutant biomass into elemental weapon evolutions and
              perimeter traps.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="px-3.5 py-1.5 rounded bg-[#070A0B] border border-[#1E272B] font-mono-tech">
              <span className="text-xs text-slate-400 mr-2">AVAILABLE SCRAP:</span>
              <span className="text-base font-bold text-[#F59E0B] tabular-nums">
                {state.player.scrap}
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-[#1E272B] hover:bg-slate-700 text-xs font-semibold text-[#F8FAFC] transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Close Workbench [E]
            </button>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="px-6 pt-4 pb-2 flex items-center justify-between flex-wrap gap-3 border-b border-[#1E272B]">
          <div className="flex items-center gap-1 p-1 bg-[#070A0B] border border-[#1E272B] rounded-md">
            {(
              [
                ['all', 'All Schematics'],
                ['elemental', 'Elemental Cores'],
                ['ballistics', 'Ballistic Receivers'],
                ['fortification', 'Fortifications'],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setFilter(key)}
                className={`px-3 py-1.5 text-xs font-semibold rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  filter === key
                    ? 'bg-[#13191C] text-[#F59E0B] border border-amber-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="text-xs font-mono-tech text-slate-400 tabular-nums">
            Biomass Harvested: <span className="text-[#10B981] font-bold">{state.player.biomass}</span>
          </div>
        </div>

        {/* Upgrade Cards Grid */}
        <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredUpgrades.map((up) => {
            const canAfford = state.player.scrap >= up.costScrap;
            const isForgedFlash = lastForgedId === up.id;

            const accentColor =
              up.elementalInfusion === 'shock'
                ? 'text-[#06B6D4]'
                : up.elementalInfusion === 'incendiary'
                  ? 'text-[#F59E0B]'
                  : up.elementalInfusion === 'cryo'
                    ? 'text-[#38BDF8]'
                    : 'text-[#10B981]';

            return (
              <div
                key={up.id}
                className={`p-4 rounded-md bg-[#13191C] border transition-all flex flex-col justify-between ${
                  isForgedFlash
                    ? 'border-[#F59E0B] ring-2 ring-amber-500/40'
                    : 'border-[#1E272B]'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="text-base font-bold text-[#F8FAFC]">{up.name}</h3>
                    <span className={`text-xs font-mono-tech font-semibold uppercase ${accentColor}`}>
                      {up.category}
                    </span>
                  </div>
                  <div className="text-xs font-mono-tech text-slate-400 mb-2">{up.subtitle}</div>
                  <p className="text-xs text-slate-300 leading-relaxed mb-4">{up.description}</p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#1E272B]">
                  <div className="font-mono-tech text-sm font-bold text-[#F59E0B] tabular-nums">
                    Cost: {up.costScrap} Scrap
                  </div>
                  <button
                    type="button"
                    disabled={!canAfford}
                    onClick={() => handleForge(up)}
                    className={`px-4 py-2 rounded text-xs font-bold transition-all whitespace-nowrap shrink-0 ${
                      canAfford
                        ? 'bg-[#F59E0B] hover:bg-[#D97706] text-[#070A0B] cursor-pointer'
                        : 'bg-[#070A0B] text-slate-500 border border-[#1E272B] cursor-not-allowed'
                    }`}
                  >
                    {isForgedFlash ? 'Forged!' : canAfford ? 'Forge Module' : 'Insufficient Scrap'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
