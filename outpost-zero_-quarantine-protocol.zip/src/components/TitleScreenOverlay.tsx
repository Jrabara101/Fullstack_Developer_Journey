import React, { useEffect, useState } from 'react';
import { getDailyUtcSeed } from '../game/rules';
import { LeaderboardEntry } from '../types/game';

interface DailyProtocolData {
  seed: string;
  utcDate: string;
  protocolName: string;
  modifierSummary: string;
}

interface LiveRelay {
  handle: string;
  wave: number;
  hp: number;
  weapon: string;
  seed: string;
}

interface TitleScreenOverlayProps {
  onStartGame: (seed: string, isDaily: boolean) => void;
  onOpenSettings: () => void;
}

export const TitleScreenOverlay: React.FC<TitleScreenOverlayProps> = ({
  onStartGame,
  onOpenSettings,
}) => {
  const [dailyData, setDailyData] = useState<DailyProtocolData>({
    seed: getDailyUtcSeed(),
    utcDate: new Date().toISOString().slice(0, 10),
    protocolName: 'Operation Blackout Threshold',
    modifierSummary: 'Nocturnal Sprinter packs on Wave 3+ · +15% Scrap Yield on Criticals',
  });
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [relays, setRelays] = useState<LiveRelay[]>([]);
  const [mode, setMode] = useState<'daily' | 'custom'>('daily');
  const [customSeedInput, setCustomSeedInput] = useState('OUTPOST-OMEGA-09');
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  useEffect(() => {
    fetch('/api/waves/daily')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data && data.seed) setDailyData(data);
      })
      .catch(() => {});

    fetch('/api/leaderboard')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data && Array.isArray(data.entries)) setLeaderboard(data.entries);
      })
      .catch(() => {});

    fetch('/api/spectator/live')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data && Array.isArray(data.relays)) setRelays(data.relays);
      })
      .catch(() => {});
  }, []);

  const activeSeed = mode === 'daily' ? dailyData.seed : customSeedInput.trim() || dailyData.seed;

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-6 md:p-10">
      {/* Top-Left / Center-Left Asymmetric Negative Space Title & Command Stage */}
      <div className="flex flex-col lg:flex-row items-start justify-between gap-8 w-full max-w-7xl mx-auto mt-2">
        <div className="pointer-events-auto max-w-xl bg-[#0C1012]/92 border border-[#1E272B] rounded-lg p-6 md:p-8 shadow-2xl">
          {/* Bespoke Inline SVG Title Emblem & Lockup */}
          <div className="mb-5">
            <svg
              viewBox="0 0 520 118"
              className="w-full max-w-[460px] h-auto"
              role="img"
              aria-label="Outpost Zero: Quarantine Protocol"
            >
              <defs>
                <linearGradient id="crestAmber" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#F59E0B" />
                  <stop offset="100%" stopColor="#D97706" />
                </linearGradient>
              </defs>
              {/* Tactical Octagonal Biohazard Shield Crest */}
              <polygon
                points="48,8 84,24 84,66 48,92 12,66 12,24"
                fill="#13191C"
                stroke="#F59E0B"
                strokeWidth="2.5"
              />
              <polygon
                points="48,16 76,29 76,61 48,82 20,61 20,29"
                fill="#070A0B"
                stroke="#1E272B"
                strokeWidth="1.5"
              />
              {/* Biohazard Geometric Rings */}
              <circle cx="48" cy="40" r="10" fill="none" stroke="url(#crestAmber)" strokeWidth="3" />
              <circle cx="39" cy="55" r="10" fill="none" stroke="url(#crestAmber)" strokeWidth="3" />
              <circle cx="57" cy="55" r="10" fill="none" stroke="url(#crestAmber)" strokeWidth="3" />
              <circle cx="48" cy="49" r="4.5" fill="#070A0B" stroke="#10B981" strokeWidth="2" />

              {/* Primary Display Lockup Typography */}
              <text
                x="104"
                y="54"
                fill="#F8FAFC"
                fontFamily="Outfit, sans-serif"
                fontWeight="800"
                fontSize="44"
                letterSpacing="2"
              >
                OUTPOST ZERO
              </text>
              <rect x="106" y="66" width="390" height="2" fill="#1E272B" />
              <rect x="106" y="66" width="118" height="2" fill="#F59E0B" />
              <text
                x="106"
                y="92"
                fill="#F59E0B"
                fontFamily="JetBrains Mono, monospace"
                fontWeight="700"
                fontSize="15"
                letterSpacing="3.5"
              >
                QUARANTINE PROTOCOL · SECTOR 09
              </text>
            </svg>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed mb-6">
            Hold the overrun urban intersection against adaptive mutant waves. Forge modular
            elemental weaponry from harvested scrap, reinforce breached window barricades, and
            pierce blackout zones with halogen floodlight traps.
          </p>

          {/* Protocol Seed Selector (Interactive Segmented Control) */}
          <div className="mb-6">
            <div className="flex items-center gap-1 p-1 bg-[#070A0B] border border-[#1E272B] rounded-md mb-3">
              <button
                type="button"
                onClick={() => setMode('daily')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 ${
                  mode === 'daily'
                    ? 'bg-[#13191C] text-[#F59E0B] border border-amber-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Daily Quarantine Seed ({dailyData.seed})
              </button>
              <button
                type="button"
                onClick={() => setMode('custom')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded transition-colors whitespace-nowrap shrink-0 ${
                  mode === 'custom'
                    ? 'bg-[#13191C] text-[#38BDF8] border border-sky-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Custom Outpost Seed
              </button>
            </div>

            {mode === 'daily' ? (
              <div className="p-3.5 rounded bg-[#13191C] border border-[#1E272B] text-xs space-y-1">
                <div className="flex items-center justify-between text-slate-200 font-medium">
                  <span>{dailyData.protocolName}</span>
                  <span className="font-mono-tech text-[#10B981] tabular-nums">
                    UTC {dailyData.utcDate}
                  </span>
                </div>
                <p className="text-slate-400">{dailyData.modifierSummary}</p>
              </div>
            ) : (
              <div className="p-3.5 rounded bg-[#13191C] border border-[#1E272B]">
                <label
                  htmlFor="custom-seed-input"
                  className="block text-xs font-medium text-slate-300 mb-1.5"
                >
                  Enter Deterministic PRNG Seed String
                </label>
                <input
                  id="custom-seed-input"
                  type="text"
                  value={customSeedInput}
                  onChange={(e) => setCustomSeedInput(e.target.value)}
                  className="w-full px-3 py-2 bg-[#070A0B] border border-[#1E272B] rounded text-sm font-mono-tech text-[#F8FAFC] focus:outline-none focus:border-amber-500"
                  placeholder="e.g. OUTPOST-OMEGA-09"
                />
              </div>
            )}
          </div>

          {/* Primary Start CTA & Secondary Actions (<= 3 Menu Actions) */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              data-start="true"
              onClick={() => onStartGame(activeSeed, mode === 'daily')}
              className="flex-1 min-w-[220px] py-3.5 px-6 bg-[#F59E0B] hover:bg-[#D97706] active:translate-y-0.5 text-[#070A0B] font-display font-bold text-base tracking-wide rounded-md shadow-lg transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              Deploy Into Quarantine
            </button>

            <button
              type="button"
              onClick={() => setShowLeaderboard((prev) => !prev)}
              className="py-3.5 px-4 bg-[#13191C] hover:bg-[#1E272B] text-slate-200 border border-[#1E272B] font-medium text-sm rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              {showLeaderboard ? 'Hide Ledger' : 'Combat Ledger'}
            </button>

            <button
              type="button"
              onClick={onOpenSettings}
              aria-label="Open Tactical Settings"
              className="py-3.5 px-4 bg-[#13191C] hover:bg-[#1E272B] text-slate-200 border border-[#1E272B] font-medium text-sm rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Settings
            </button>
          </div>
        </div>

        {/* Optional Combat Ledger & Live Relay Panel */}
        {showLeaderboard && (
          <div className="pointer-events-auto w-full lg:w-[420px] bg-[#0C1012]/94 border border-[#1E272B] rounded-lg p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#1E272B]">
              <h2 className="text-base font-bold text-[#F8FAFC]">
                Verified Quarantine Leaderboard
              </h2>
              <span className="text-xs font-mono-tech text-slate-400 tabular-nums">
                Anti-Cheat Ledger
              </span>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {leaderboard.slice(0, 6).map((entry, idx) => (
                <div
                  key={entry.id}
                  className="flex items-center justify-between p-2.5 rounded bg-[#13191C] border border-[#1E272B] text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-100 truncate">
                      {idx + 1}. {entry.playerName}
                    </div>
                    <div className="text-slate-400 truncate">
                      {entry.favoriteSynergy} · Wave {entry.wavesCleared}
                    </div>
                  </div>
                  <div className="text-right font-mono-tech shrink-0 ml-3">
                    <div className="text-[#F59E0B] font-semibold tabular-nums">
                      {entry.finalScore.toLocaleString()} pts
                    </div>
                    <div className="text-[11px] text-[#10B981] tabular-nums">
                      {entry.verifiedHash.slice(0, 16)}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {relays.length > 0 && (
              <div className="mt-4 pt-3 border-t border-[#1E272B]">
                <div className="text-xs font-semibold text-slate-300 mb-2">
                  Active Sector Relay Signals
                </div>
                <div className="space-y-1.5">
                  {relays.map((r) => (
                    <div
                      key={r.handle}
                      className="flex items-center justify-between text-xs text-slate-400 font-mono-tech"
                    >
                      <span className="text-slate-200">{r.handle}</span>
                      <span>
                        Wave {r.wave} · HP {r.hp}% · {r.weapon}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Single Flat Borderless Inline Control-Hint Line in Bottom Safe Margin */}
      <div className="w-full text-center pb-1">
        <p className="inline-block text-xs md:text-sm font-mono-tech text-slate-300 hud-text-stroke tracking-wide">
          WASD Move · Mouse Aim &amp; Fire · R Active Reload · E Scrap Forge · F Floodlight Trap · B
          Fortify Barricade · Esc Pause
        </p>
      </div>
    </div>
  );
};
