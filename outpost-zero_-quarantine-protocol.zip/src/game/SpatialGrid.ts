export interface SpatialEntity {
  id: string;
  x: number;
  y: number;
  radius: number;
}

/**
 * Zero-GC Spatial Hash Grid for real-time broadphase collision queries
 * across up to 400 simultaneous entities (Player, Swarm Zombies, Projectiles, Barricades, Pickups).
 */
export class SpatialHashGrid<T extends SpatialEntity> {
  private cellSize: number;
  private buckets: Map<number, T[]>;
  private pool: T[][];
  private queryResults: T[];

  constructor(cellSize = 4.0) {
    this.cellSize = cellSize;
    this.buckets = new Map<number, T[]>();
    this.pool = [];
    this.queryResults = [];
  }

  private hashCoords(cx: number, cy: number): number {
    // Pair two signed 16-bit cell integers into one 32-bit key
    return ((cx & 0xffff) << 16) | (cy & 0xffff);
  }

  public clear(): void {
    for (const bucket of this.buckets.values()) {
      bucket.length = 0;
      this.pool.push(bucket);
    }
    this.buckets.clear();
  }

  public insert(entity: T): void {
    const minCellX = Math.floor((entity.x - entity.radius) / this.cellSize);
    const maxCellX = Math.floor((entity.x + entity.radius) / this.cellSize);
    const minCellY = Math.floor((entity.y - entity.radius) / this.cellSize);
    const maxCellY = Math.floor((entity.y + entity.radius) / this.cellSize);

    for (let cx = minCellX; cx <= maxCellX; cx++) {
      for (let cy = minCellY; cy <= maxCellY; cy++) {
        const key = this.hashCoords(cx, cy);
        let bucket = this.buckets.get(key);
        if (!bucket) {
          bucket = this.pool.pop() || [];
          this.buckets.set(key, bucket);
        }
        bucket.push(entity);
      }
    }
  }

  /**
   * Returns entities whose bounding circles overlap (x, y, radius).
   * Reuses an internal buffer when `out` is not passed to avoid GC pressure.
   */
  public queryRadius(x: number, y: number, radius: number, out: T[] = this.queryResults): T[] {
    out.length = 0;
    const minCellX = Math.floor((x - radius) / this.cellSize);
    const maxCellX = Math.floor((x + radius) / this.cellSize);
    const minCellY = Math.floor((y - radius) / this.cellSize);
    const maxCellY = Math.floor((y + radius) / this.cellSize);

    for (let cx = minCellX; cx <= maxCellX; cx++) {
      for (let cy = minCellY; cy <= maxCellY; cy++) {
        const key = this.hashCoords(cx, cy);
        const bucket = this.buckets.get(key);
        if (!bucket) continue;
        for (let i = 0; i < bucket.length; i++) {
          const item = bucket[i];
          if (out.indexOf(item) !== -1) continue;
          const dx = item.x - x;
          const dy = item.y - y;
          const maxR = item.radius + radius;
          if (dx * dx + dy * dy <= maxR * maxR) {
            out.push(item);
          }
        }
      }
    }
    return out;
  }
}
