import * as THREE from 'three';
import { ZombieArchetype } from '../types/game';

/**
 * Detects software WebGL (SwiftShader, llvmpipe, softpipe, Basic Render)
 * from the unmasked renderer string.
 */
export function detectSoftwareGl(): boolean {
  if (typeof document === 'undefined') return true;
  const gl = document.createElement('canvas').getContext('webgl2');
  if (!gl) return true;
  const ext = gl.getExtension('WEBGL_debug_renderer_info');
  const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
  const gpu = String(gl.getParameter(param));
  gl.getExtension('WEBGL_lose_context')?.loseContext();
  return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
}

/**
 * Generates procedural asphalt + tactical grid CanvasTextures (Albedo + Bump)
 */
export function createOutpostGroundTextures(maxAnisotropy: number): {
  albedoMap: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const size = 512;
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const ctx = albedoCanvas.getContext('2d')!;

  // Deep obsidian asphalt base
  ctx.fillStyle = '#0c1114';
  ctx.fillRect(0, 0, size, size);

  // Subtle asphalt aggregate speckles (deterministic pattern)
  for (let i = 0; i < 3200; i++) {
    const x = (i * 73) % size;
    const y = (i * 137) % size;
    const shade = 14 + (i % 16);
    ctx.fillStyle = `rgb(${shade}, ${shade + 4}, ${shade + 7})`;
    ctx.fillRect(x, y, 2, 2);
  }

  // Tactical quarantine sector grid lines
  ctx.strokeStyle = 'rgba(30, 41, 48, 0.65)';
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(245, 158, 11, 0.12)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(size / 2, 0);
  ctx.lineTo(size / 2, size);
  ctx.moveTo(0, size / 2);
  ctx.lineTo(size, size / 2);
  ctx.stroke();

  const albedoMap = new THREE.CanvasTexture(albedoCanvas);
  albedoMap.colorSpace = THREE.SRGBColorSpace;
  albedoMap.wrapS = THREE.RepeatWrapping;
  albedoMap.wrapT = THREE.RepeatWrapping;
  albedoMap.repeat.set(28, 28);
  albedoMap.anisotropy = maxAnisotropy;

  // Grayscale bump map
  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = 256;
  bumpCanvas.height = 256;
  const bCtx = bumpCanvas.getContext('2d')!;
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 1800; i++) {
    const x = (i * 59) % 256;
    const y = (i * 101) % 256;
    const v = 100 + (i % 55);
    bCtx.fillStyle = `rgb(${v},${v},${v})`;
    bCtx.fillRect(x, y, 2, 2);
  }
  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(28, 28);
  bumpMap.anisotropy = maxAnisotropy;

  return { albedoMap, bumpMap };
}

/**
 * Shared radial contact shadow geometry and material to ground all 3D entities
 */
const sharedShadowGeo = new THREE.CircleGeometry(0.95, 20);
sharedShadowGeo.rotateX(-Math.PI / 2);
const sharedShadowMat = new THREE.MeshBasicMaterial({
  color: 0x000000,
  transparent: true,
  opacity: 0.44,
  depthWrite: false,
});

export function createContactShadow(scale = 1.0): THREE.Mesh {
  const mesh = new THREE.Mesh(sharedShadowGeo, sharedShadowMat);
  mesh.position.y = 0.018;
  mesh.scale.setScalar(scale);
  return mesh;
}

/**
 * Builds the outdoor Quarantined Outpost Intersection environment:
 * Extended terrain, tactical helipad markings, concrete Jersey barriers,
 * ruined highway pillars, perimeter rock outcrops, and a tall Radio Watchtower landmark.
 */
export function buildOutpostEnvironment(
  scene: THREE.Scene,
  maxAnisotropy: number
): {
  facilityLights: THREE.PointLight[];
  beaconMeshes: THREE.Mesh[];
} {
  const { albedoMap, bumpMap } = createOutpostGroundTextures(maxAnisotropy);

  // Extended outdoor ground plane (180x180m) so horizon blends into FogExp2
  const groundGeo = new THREE.PlaneGeometry(180, 180);
  groundGeo.rotateX(-Math.PI / 2);
  const groundMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: albedoMap,
    bumpMap,
    bumpScale: 0.04,
    roughness: 0.86,
    metalness: 0.12,
  });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.receiveShadow = true;
  scene.add(ground);

  // Central Quarantine Outpost Helipad Ring (offset +0.025 Y to prevent Z-fighting)
  const padRingGeo = new THREE.RingGeometry(4.8, 5.2, 48);
  padRingGeo.rotateX(-Math.PI / 2);
  const padRingMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.5,
    metalness: 0.3,
    transparent: true,
    opacity: 0.55,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const padRing = new THREE.Mesh(padRingGeo, padRingMat);
  padRing.position.y = 0.025;
  scene.add(padRing);

  const outerRingGeo = new THREE.RingGeometry(15.6, 15.85, 64);
  outerRingGeo.rotateX(-Math.PI / 2);
  const outerRingMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.6,
    metalness: 0.25,
  });
  const outerRing = new THREE.Mesh(outerRingGeo, outerRingMat);
  outerRing.position.y = 0.022;
  scene.add(outerRing);

  // Composite Landmark: Tall Quarantine Comms & Siren Watchtower at North horizon (0, 0, -24)
  const watchtower = new THREE.Group();
  watchtower.position.set(0, 0, -24);
  const legGeo = new THREE.CylinderGeometry(0.18, 0.28, 11, 8);
  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.42,
    metalness: 0.78,
  });
  const legOffsets = [
    [-1.4, -1.4],
    [1.4, -1.4],
    [-1.4, 1.4],
    [1.4, 1.4],
  ];
  legOffsets.forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(legGeo, steelMat);
    leg.position.set(lx, 5.5, lz);
    leg.castShadow = true;
    watchtower.add(leg);
  });
  const deckGeo = new THREE.BoxGeometry(4.2, 0.6, 4.2);
  const deckMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.72,
    metalness: 0.35,
  });
  const deck = new THREE.Mesh(deckGeo, deckMat);
  deck.position.y = 11.0;
  watchtower.add(deck);

  const cabinGeo = new THREE.BoxGeometry(3.1, 2.4, 3.1);
  const cabin = new THREE.Mesh(cabinGeo, steelMat);
  cabin.position.y = 12.5;
  watchtower.add(cabin);

  const antennaGeo = new THREE.CylinderGeometry(0.06, 0.12, 4.5, 8);
  const antenna = new THREE.Mesh(antennaGeo, steelMat);
  antenna.position.set(0.8, 15.8, -0.6);
  watchtower.add(antenna);

  const beaconGeo = new THREE.SphereGeometry(0.28, 12, 12);
  const beaconMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xef4444,
    emissiveIntensity: 2.2,
    roughness: 0.2,
  });
  const towerBeacon = new THREE.Mesh(beaconGeo, beaconMat);
  towerBeacon.position.set(0.8, 18.1, -0.6);
  watchtower.add(towerBeacon);
  scene.add(watchtower);

  // Concrete Jersey Barriers & Perimeter Outcrops (Composite 4-part segments)
  const barrierConcreteMat = new THREE.MeshStandardMaterial({
    color: 0x263038,
    roughness: 0.85,
    metalness: 0.1,
  });
  const hazardCapMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.45,
    metalness: 0.4,
  });

  const barrierPlacements = [
    { x: -20, z: -12, ry: 0.6 },
    { x: -22, z: 11, ry: -0.5 },
    { x: 20, z: -12, ry: -0.6 },
    { x: 22, z: 11, ry: 0.5 },
    { x: -6, z: -20, ry: 0.1 },
    { x: 6, z: -20, ry: -0.1 },
    { x: -6, z: 20, ry: -0.1 },
    { x: 6, z: 20, ry: 0.1 },
  ];

  barrierPlacements.forEach((b) => {
    const bGroup = new THREE.Group();
    bGroup.position.set(b.x, 0, b.z);
    bGroup.rotation.y = b.ry;

    const base = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.7, 1.1), barrierConcreteMat);
    base.position.y = 0.35;
    base.castShadow = true;
    base.receiveShadow = true;
    bGroup.add(base);

    const upper = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.75, 0.65), barrierConcreteMat);
    upper.position.y = 1.05;
    upper.castShadow = true;
    bGroup.add(upper);

    const stripe = new THREE.Mesh(new THREE.BoxGeometry(4.25, 0.16, 0.7), hazardCapMat);
    stripe.position.y = 1.25;
    bGroup.add(stripe);

    const rebar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.6, 6), steelMat);
    rebar.position.set(-1.5, 1.6, 0);
    bGroup.add(rebar);

    scene.add(bGroup);
  });

  // Outer wasteland rock / rubble outcrops using InstancedMesh (>20 instances)
  const rockGeo = new THREE.DodecahedronGeometry(1.4, 0);
  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x1b242a,
    roughness: 0.92,
    metalness: 0.08,
  });
  const rockCount = 36;
  const rockInstanced = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();
  for (let i = 0; i < rockCount; i++) {
    const angle = (i / rockCount) * Math.PI * 2;
    const dist = 27 + (i % 5) * 4.5;
    dummy.position.set(Math.cos(angle) * dist, 0.6, Math.sin(angle) * dist);
    dummy.rotation.set(i * 0.7, i * 1.3, 0);
    const s = 0.85 + (i % 4) * 0.25;
    dummy.scale.set(s * 1.2, s * 0.75, s);
    dummy.updateMatrix();
    rockInstanced.setMatrixAt(i, dummy.matrix);
    tint.setHSL(0.56, 0.18, 0.1 + (i % 3) * 0.03);
    rockInstanced.setColorAt(i, tint);
  }
  rockInstanced.instanceMatrix.needsUpdate = true;
  if (rockInstanced.instanceColor) rockInstanced.instanceColor.needsUpdate = true;
  rockInstanced.computeBoundingSphere();
  scene.add(rockInstanced);

  // 4 Outpost Facility Floodlight Pylons (controlled by Horde Director / Blackout Events)
  const facilityLights: THREE.PointLight[] = [];
  const beaconMeshes: THREE.Mesh[] = [towerBeacon];
  const pylonCoords = [
    [-10, -10],
    [10, -10],
    [-10, 10],
    [10, 10],
  ];

  pylonCoords.forEach(([px, pz]) => {
    const pGroup = new THREE.Group();
    pGroup.position.set(px, 0, pz);

    const basePedestal = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.7, 0.9), barrierConcreteMat);
    basePedestal.position.y = 0.35;
    pGroup.add(basePedestal);

    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 4.6, 8), steelMat);
    pole.position.y = 2.65;
    pGroup.add(pole);

    const crossArm = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.16, 0.3), steelMat);
    crossArm.position.y = 4.95;
    pGroup.add(crossArm);

    const bulbMat = new THREE.MeshStandardMaterial({
      color: 0xfef3c7,
      emissive: 0xf59e0b,
      emissiveIntensity: 1.4,
      roughness: 0.2,
    });
    const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.22, 0.36), bulbMat);
    bulb.position.y = 4.82;
    pGroup.add(bulb);
    beaconMeshes.push(bulb);

    const ptLight = new THREE.PointLight(0xffedd5, 9, 20, 1.7);
    ptLight.position.set(px, 4.6, pz);
    scene.add(ptLight);
    facilityLights.push(ptLight);

    scene.add(pGroup);
  });

  return { facilityLights, beaconMeshes };
}

/**
 * Builds the 9-part Player Quarantine Operative Group + Directional Flashlight Cone
 */
export function buildPlayerOperative(): {
  group: THREE.Group;
  muzzleLight: THREE.PointLight;
  muzzleMesh: THREE.Mesh;
  flashlight: THREE.SpotLight;
  flashlightTarget: THREE.Object3D;
  visionConeMesh: THREE.Mesh;
  weaponMesh: THREE.Mesh;
} {
  const group = new THREE.Group();
  group.add(createContactShadow(1.15));

  const armorMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.65,
    metalness: 0.45,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.85,
    metalness: 0.2,
  });
  const visorMat = new THREE.MeshStandardMaterial({
    color: 0x10b981,
    emissive: 0x10b981,
    emissiveIntensity: 1.6,
    roughness: 0.15,
    metalness: 0.8,
  });
  const gunMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.32,
    metalness: 0.85,
  });

  // 1 & 2. Tactical Boots & Greaves
  const leftLeg = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.65, 0.28), trimMat);
  leftLeg.position.set(-0.2, 0.325, 0);
  group.add(leftLeg);

  const rightLeg = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.65, 0.28), trimMat);
  rightLeg.position.set(0.2, 0.325, 0);
  group.add(rightLeg);

  // 3. Ballistic Chest Rig (Primary Silhouette)
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.82, 0.48), armorMat);
  torso.position.set(0, 1.02, 0);
  torso.castShadow = true;
  group.add(torso);

  // 4 & 5. Shoulder Pauldrons
  const leftShoulder = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.32, 0.42), armorMat);
  leftShoulder.position.set(-0.5, 1.24, 0);
  group.add(leftShoulder);

  const rightShoulder = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.32, 0.42), armorMat);
  rightShoulder.position.set(0.5, 1.24, 0);
  group.add(rightShoulder);

  // 6. Backpack Hazmat Power Cell
  const pack = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.58, 0.28), trimMat);
  pack.position.set(0, 1.06, -0.34);
  group.add(pack);

  // 7. Helmeted Head
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.48, 0.5), armorMat);
  head.position.set(0, 1.66, 0);
  head.castShadow = true;
  group.add(head);

  // 8. Bio-Emerald Tactical Visor
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.16, 0.12), visorMat);
  visor.position.set(0, 1.68, 0.24);
  group.add(visor);

  // 9. Equipped Weapon Receiver & Barrel
  const weaponMesh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.2, 0.95), gunMat);
  weaponMesh.position.set(0.36, 1.12, 0.48);
  weaponMesh.castShadow = true;
  group.add(weaponMesh);

  // Muzzle Flash Mesh & Light
  const muzzleMat = new THREE.MeshBasicMaterial({
    color: 0xfbbf24,
    transparent: true,
    opacity: 0,
  });
  const muzzleMesh = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 8), muzzleMat);
  muzzleMesh.position.set(0.36, 1.12, 1.05);
  group.add(muzzleMesh);

  const muzzleLight = new THREE.PointLight(0xf59e0b, 0, 10, 2);
  muzzleLight.position.set(0.36, 1.3, 1.1);
  group.add(muzzleLight);

  // Volumetric Ground Flashlight Cone Mesh (Visualizes 2D/3D Raycasted Vision Cone)
  const coneShape = new THREE.Shape();
  coneShape.moveTo(0, 0);
  const coneLength = 19;
  const halfAngle = 0.44; // ~50 deg total cone
  coneShape.absarc(0, 0, coneLength, -halfAngle + Math.PI / 2, halfAngle + Math.PI / 2, false);
  coneShape.lineTo(0, 0);

  const coneGeo = new THREE.ShapeGeometry(coneShape, 24);
  coneGeo.rotateX(Math.PI / 2);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0xe0f2fe,
    transparent: true,
    opacity: 0.13,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const visionConeMesh = new THREE.Mesh(coneGeo, coneMat);
  visionConeMesh.position.set(0, 0.04, 0.4);
  group.add(visionConeMesh);

  // Real 3D SpotLight for the player's weapon flashlight
  const flashlight = new THREE.SpotLight(0xe0f2fe, 26, 26, 0.52, 0.55, 1.3);
  flashlight.position.set(0.25, 1.35, 0.5);
  const flashlightTarget = new THREE.Object3D();
  flashlightTarget.position.set(0, 0.5, 12);
  group.add(flashlight);
  group.add(flashlightTarget);
  flashlight.target = flashlightTarget;

  return {
    group,
    muzzleLight,
    muzzleMesh,
    flashlight,
    flashlightTarget,
    visionConeMesh,
    weaponMesh,
  };
}

/**
 * Builds a composite 6-9 part Zombie Group with distinct archetype geometry,
 * silhouette scale, and glowing red eyes for Fog-of-War silhouette mode.
 */
export function buildZombieGroup(type: ZombieArchetype): {
  group: THREE.Group;
  bodyMaterials: THREE.MeshStandardMaterial[];
  eyeMesh: THREE.Mesh;
  telegraphRing: THREE.Mesh;
} {
  const group = new THREE.Group();

  const isBrute = type === 'brute';
  const isSprinter = type === 'sprinter';
  const isSpitter = type === 'spitter';
  const isScreamer = type === 'screamer';

  const scale = isBrute ? 1.52 : isSprinter ? 0.92 : isScreamer ? 1.12 : 1.0;
  group.add(createContactShadow(scale));

  const primaryColor = isBrute
    ? 0x3f2e21
    : isSpitter
      ? 0x14532d
      : isSprinter
        ? 0x451a1c
        : isScreamer
          ? 0x312e81
          : 0x334155;

  const secondaryColor = isBrute
    ? 0x78350f
    : isSpitter
      ? 0x10b981
      : isSprinter
        ? 0x7f1d1d
        : isScreamer
          ? 0x06b6d4
          : 0x1e293b;

  const hullMat = new THREE.MeshStandardMaterial({
    color: primaryColor,
    roughness: 0.78,
    metalness: 0.15,
  });
  const detailMat = new THREE.MeshStandardMaterial({
    color: secondaryColor,
    roughness: 0.38,
    metalness: isBrute ? 0.7 : 0.25,
    emissive: isSpitter ? 0x059669 : isScreamer ? 0x0891b2 : 0x000000,
    emissiveIntensity: isSpitter || isScreamer ? 0.8 : 0,
  });

  // 1 & 2. Legs
  const legL = new THREE.Mesh(new THREE.BoxGeometry(0.22 * scale, 0.58 * scale, 0.24 * scale), hullMat);
  legL.position.set(-0.18 * scale, 0.29 * scale, 0);
  group.add(legL);

  const legR = new THREE.Mesh(new THREE.BoxGeometry(0.22 * scale, 0.58 * scale, 0.24 * scale), hullMat);
  legR.position.set(0.18 * scale, 0.29 * scale, 0);
  group.add(legR);

  // 3. Torso
  const torso = new THREE.Mesh(
    new THREE.BoxGeometry(0.68 * scale, 0.78 * scale, 0.44 * scale),
    hullMat
  );
  torso.position.set(0, 0.95 * scale, 0);
  if (isSprinter) torso.rotation.x = 0.35; // Forward predator lean
  group.add(torso);

  // 4 & 5. Outstretched Arms
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.2 * scale, 0.22 * scale, 0.68 * scale), hullMat);
  armL.position.set(-0.44 * scale, 1.12 * scale, 0.25 * scale);
  group.add(armL);

  const armR = new THREE.Mesh(
    new THREE.BoxGeometry((isBrute ? 0.34 : 0.2) * scale, 0.24 * scale, 0.72 * scale),
    isBrute ? detailMat : hullMat
  );
  armR.position.set(0.44 * scale, 1.12 * scale, 0.25 * scale);
  group.add(armR);

  // 6. Head
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.44 * scale, 0.44 * scale, 0.44 * scale), hullMat);
  head.position.set(0, 1.54 * scale, isSprinter ? 0.14 : 0.04);
  group.add(head);

  // 7. Archetype-specific secondary silhouette feature
  if (isSpitter) {
    // Glowing bio-acid dorsal sac
    const sac = new THREE.Mesh(new THREE.SphereGeometry(0.34, 12, 12), detailMat);
    sac.position.set(0, 1.25, -0.24);
    group.add(sac);
  } else if (isBrute) {
    // Heavy riot steel shoulder crest
    const plate = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.42, 0.65), detailMat);
    plate.position.set(0, 1.9, 0);
    group.add(plate);
  } else if (isScreamer) {
    // Sonic resonator halo fins
    const fin = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.06, 8, 20), detailMat);
    fin.position.set(0, 1.65, -0.1);
    group.add(fin);
  }

  // 8. Glowing Crimson Eyes (Always visible even when silhouetted outside the flashlight cone!)
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
  const eyeMesh = new THREE.Mesh(new THREE.BoxGeometry(0.32 * scale, 0.09 * scale, 0.08 * scale), eyeMat);
  eyeMesh.position.set(0, 1.56 * scale, (isSprinter ? 0.14 : 0.04) + 0.23 * scale);
  group.add(eyeMesh);

  // 9. Ground Windup Telegraph Ring (Shown during heavy attack windup)
  const teleGeo = new THREE.RingGeometry(0.75 * scale, 0.98 * scale, 24);
  teleGeo.rotateX(-Math.PI / 2);
  const teleMat = new THREE.MeshBasicMaterial({
    color: isSpitter ? 0x10b981 : 0xef4444,
    transparent: true,
    opacity: 0,
    depthWrite: false,
  });
  const telegraphRing = new THREE.Mesh(teleGeo, teleMat);
  telegraphRing.position.y = 0.032;
  group.add(telegraphRing);

  return {
    group,
    bodyMaterials: [hullMat, detailMat],
    eyeMesh,
    telegraphRing,
  };
}

/**
 * Builds a 5-part Barricade Group for perimeter entryways
 */
export function buildBarricadeGroup(): {
  group: THREE.Group;
  planksMesh: THREE.Mesh;
  beaconMat: THREE.MeshStandardMaterial;
} {
  const group = new THREE.Group();

  const postMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.45,
    metalness: 0.75,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0xb45309,
    roughness: 0.82,
    metalness: 0.1,
  });
  const beaconMat = new THREE.MeshStandardMaterial({
    color: 0x10b981,
    emissive: 0x10b981,
    emissiveIntensity: 1.5,
    roughness: 0.2,
  });

  const postL = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 1.5, 8), postMat);
  postL.position.set(-1.3, 0.75, 0);
  group.add(postL);

  const postR = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 1.5, 8), postMat);
  postR.position.set(1.3, 0.75, 0);
  group.add(postR);

  const planksMesh = new THREE.Mesh(new THREE.BoxGeometry(2.7, 1.05, 0.28), woodMat);
  planksMesh.position.set(0, 0.68, 0);
  planksMesh.castShadow = true;
  group.add(planksMesh);

  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), beaconMat);
  beacon.position.set(0, 1.6, 0);
  group.add(beacon);

  return { group, planksMesh, beaconMat };
}

/**
 * Builds a Portable Halogen Floodlight Trap Group
 */
export function buildFloodlightTrapGroup(): THREE.Group {
  const group = new THREE.Group();

  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.4,
    metalness: 0.8,
  });
  const lampMat = new THREE.MeshStandardMaterial({
    color: 0xe0f2fe,
    emissive: 0x38bdf8,
    emissiveIntensity: 2.2,
    roughness: 0.15,
  });

  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 0.25, 10), metalMat);
  base.position.y = 0.125;
  group.add(base);

  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 1.7, 8), metalMat);
  mast.position.y = 0.95;
  group.add(mast);

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.35, 0.35), lampMat);
  head.position.y = 1.85;
  group.add(head);

  const discGeo = new THREE.CircleGeometry(6.2, 32);
  discGeo.rotateX(-Math.PI / 2);
  const discMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.16,
    depthWrite: false,
  });
  const disc = new THREE.Mesh(discGeo, discMat);
  disc.position.y = 0.03;
  group.add(disc);

  return group;
}

/**
 * Builds a Tripwire Blast Mine Group
 */
export function buildMineTrapGroup(): THREE.Group {
  const group = new THREE.Group();

  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.6,
    metalness: 0.6,
  });
  const coreMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.8,
    roughness: 0.2,
  });

  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.45, 0.18, 12), baseMat);
  body.position.y = 0.09;
  group.add(body);

  const core = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 10), coreMat);
  core.position.y = 0.2;
  group.add(core);

  const ringGeo = new THREE.RingGeometry(1.55, 1.65, 24);
  ringGeo.rotateX(-Math.PI / 2);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0xf59e0b,
    transparent: true,
    opacity: 0.32,
    depthWrite: false,
  });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.position.y = 0.028;
  group.add(ring);

  return group;
}
