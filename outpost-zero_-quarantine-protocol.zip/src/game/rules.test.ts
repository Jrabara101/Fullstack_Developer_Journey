import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyScrapForgeUpgradeToWeapon,
  createStarterWeapons,
  evaluateActiveReload,
  formatEmojiScorecard,
  generateWaveComposition,
  getDailyUtcSeed,
  hashSeedString,
  mulberry32,
  SCRAP_FORGE_CATALOG,
  verifyRunTelemetry,
} from './rules';
import { SpatialHashGrid } from './SpatialGrid';

test('Mulberry32 PRNG and seed hashing are strictly deterministic', () => {
  const seedA = hashSeedString('QP-2026-11-05');
  const seedB = hashSeedString('QP-2026-11-05');
  assert.equal(seedA, seedB);

  const rng1 = mulberry32(seedA);
  const rng2 = mulberry32(seedB);
  for (let i = 0; i < 10; i++) {
    assert.equal(rng1(), rng2());
  }
});

test('getDailyUtcSeed formats UTC date consistently', () => {
  const sampleDate = new Date(Date.UTC(2026, 10, 5, 18, 30, 0));
  assert.equal(getDailyUtcSeed(sampleDate), 'QP-2026-11-05');
});

test('generateWaveComposition scales hostiles and introduces mutant archetypes deterministically', () => {
  const wave1A = generateWaveComposition('QP-2026-11-05', 1);
  const wave1B = generateWaveComposition('QP-2026-11-05', 1);
  assert.deepEqual(wave1A, wave1B);
  assert.ok(wave1A.totalHostiles >= 12);

  const wave4 = generateWaveComposition('QP-2026-11-05', 4);
  assert.ok(wave4.totalHostiles > wave1A.totalHostiles);
  assert.ok(wave4.counts.spitter >= 1);
  assert.ok(wave4.counts.brute >= 1);
  assert.ok(wave4.counts.screamer >= 1);

  const wave3 = generateWaveComposition('QP-2026-11-05', 3);
  assert.equal(wave3.isBlackoutWave, true);
});

test('evaluateActiveReload rewards sweet-spot timing and penalizes early jams', () => {
  const sweet = evaluateActiveReload(0.55);
  assert.equal(sweet.outcome, 'sweet_spot');
  assert.equal(sweet.grantOvercharge, true);
  assert.ok(sweet.remainingTimeMultiplier < 0.25);

  const early = evaluateActiveReload(0.2);
  assert.equal(early.outcome, 'early_jam');
  assert.equal(early.grantOvercharge, false);
  assert.ok(early.remainingTimeMultiplier > 1.0);
});

test('applyScrapForgeUpgradeToWeapon evolves weapon tier, damage, and elemental infusion', () => {
  const weapons = createStarterWeapons();
  const shotgun = weapons[1];
  const teslaUpgrade = SCRAP_FORGE_CATALOG[0];

  const evolved = applyScrapForgeUpgradeToWeapon(shotgun, teslaUpgrade);
  assert.equal(evolved.tier, 2);
  assert.equal(evolved.elemental, 'shock');
  assert.ok(evolved.baseDamage > shotgun.baseDamage);
  assert.ok(evolved.name.includes('Tesla'));
});

test('verifyRunTelemetry validates legitimate runs and rejects fire-rate tampering', () => {
  const validPayload = {
    runSeed: 'QP-2026-11-05',
    playerName: 'Vanguard_01',
    favoriteSynergy: 'Tesla M870 Trench Breacher',
    durationMs: 180000,
    wavesCleared: 5,
    scrapCollected: 1240,
    biomassHarvested: 42,
    finalScore: 18400,
    killsByType: { walker: 45, sprinter: 20, spitter: 8, brute: 4, screamer: 2 },
    shotsFired: 210,
    shotsHit: 158,
    causeOfDeath: 'Overrun by Armored Brute',
    telemetry: [
      { timeMs: 1200, action: 'SHOT' as const, x: 0, y: 0, weaponId: 'wpn_breacher_shotgun', hitCount: 3, damageDealt: 66 },
      { timeMs: 2400, action: 'SHOT' as const, x: 1, y: -1, weaponId: 'wpn_breacher_shotgun', hitCount: 4, damageDealt: 88 },
      { timeMs: 35000, action: 'WAVE_CLEAR' as const, x: 0, y: 0, weaponId: 'wpn_breacher_shotgun', hitCount: 0 },
    ],
  };

  const validRes = verifyRunTelemetry(validPayload);
  assert.equal(validRes.verified, true);
  assert.ok(validRes.verificationHash.startsWith('QP-VERIFIED-'));
  assert.equal(validRes.accuracyPct, 75);

  // Tampered non-monotonic timestamps
  const tamperedRes = verifyRunTelemetry({
    ...validPayload,
    telemetry: [
      { timeMs: 5000, action: 'SHOT', x: 0, y: 0, weaponId: 'wpn_service_sidearm', hitCount: 1 },
      { timeMs: 2000, action: 'SHOT', x: 0, y: 0, weaponId: 'wpn_service_sidearm', hitCount: 1 },
    ],
  });
  assert.equal(tamperedRes.verified, false);
});

test('SpatialHashGrid accurately finds overlapping entities in broadphase', () => {
  const grid = new SpatialHashGrid<{ id: string; x: number; y: number; radius: number }>(4);
  grid.insert({ id: 'z1', x: 2, y: 2, radius: 0.6 });
  grid.insert({ id: 'z2', x: 3.2, y: 2.5, radius: 0.6 });
  grid.insert({ id: 'z3', x: -20, y: 15, radius: 0.8 });

  const hits = grid.queryRadius(2.5, 2.2, 1.5);
  const ids = hits.map((h) => h.id).sort();
  assert.deepEqual(ids, ['z1', 'z2']);
});

test('formatEmojiScorecard produces spoiler-free shareable badge', () => {
  const badge = formatEmojiScorecard({
    seed: 'QP-2026-11-05',
    wavesCleared: 19,
    scrapCollected: 2480,
    durationMs: 862000,
    accuracyPct: 78,
    favoriteSynergy: 'Tesla M870',
  });
  assert.ok(badge.includes('[Wave 19 // Scrap: 2,480 // 14m 22s]'));
});
