import {
  BarricadeEntity,
  ElementalType,
  ForgeUpgradeOption,
  TelemetrySubmissionPayload,
  TelemetryVerificationResult,
  WaveComposition,
  WeaponEntity,
  ZombieArchetype,
} from '../types/game';

/**
 * Deterministic string-to-uint32 hash (FNV-1a inspired)
 */
export function hashSeedString(seed: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/**
 * Mulberry32 deterministic PRNG returning floats in [0, 1)
 */
export function mulberry32(seedInt: number): () => number {
  let a = seedInt >>> 0;
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Generates the global daily Quarantine Protocol seed string from UTC date
 */
export function getDailyUtcSeed(date: Date = new Date()): string {
  const yyyy = date.getUTCFullYear();
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(date.getUTCDate()).padStart(2, '0');
  return `QP-${yyyy}-${mm}-${dd}`;
}

/**
 * Initial starter weapons for the Quarantine Operative
 */
export function createStarterWeapons(): WeaponEntity[] {
  return [
    {
      id: 'wpn_service_sidearm',
      name: 'MK-IV Tactical Sidearm',
      roleDesc: 'Balanced Semi-Auto · Fast Active Reload',
      baseDamage: 32,
      fireRateRps: 5.5,
      clipSize: 16,
      currentAmmo: 16,
      reloadTimeMs: 1150,
      piercingCount: 1,
      elemental: 'none',
      tier: 1,
      pellets: 1,
      spreadRad: 0.035,
      projectileSpeed: 42,
    },
    {
      id: 'wpn_breacher_shotgun',
      name: 'M870 Trench Breacher',
      roleDesc: '6-Pellet Buckshot · High Crowd Knockback',
      baseDamage: 22,
      fireRateRps: 1.8,
      clipSize: 8,
      currentAmmo: 8,
      reloadTimeMs: 1750,
      piercingCount: 1,
      elemental: 'none',
      tier: 1,
      pellets: 6,
      spreadRad: 0.24,
      projectileSpeed: 36,
    },
    {
      id: 'wpn_marksman_rifle',
      name: 'Valkyrie Marksman Rifle',
      roleDesc: 'High-Velocity Armor Piercer · Long Range',
      baseDamage: 85,
      fireRateRps: 2.4,
      clipSize: 10,
      currentAmmo: 10,
      reloadTimeMs: 1600,
      piercingCount: 3,
      elemental: 'none',
      tier: 1,
      pellets: 1,
      spreadRad: 0.012,
      projectileSpeed: 56,
    },
  ];
}

/**
 * Initial tactical perimeter barricades around the outpost intersection
 */
export function createInitialBarricades(): BarricadeEntity[] {
  return [
    { id: 'bar_north_west', label: 'North-West Breach', x: -12, y: -14, angle: 0.35, health: 220, maxHealth: 220 },
    { id: 'bar_north_east', label: 'North-East Breach', x: 12, y: -14, angle: -0.35, health: 220, maxHealth: 220 },
    { id: 'bar_east_alley', label: 'East Subway Gate', x: 18, y: 0, angle: Math.PI / 2, health: 240, maxHealth: 240 },
    { id: 'bar_west_alley', label: 'West Pharmacy Window', x: -18, y: 0, angle: Math.PI / 2, health: 240, maxHealth: 240 },
    { id: 'bar_south_west', label: 'South-West Checkpoint', x: -11, y: 14, angle: -0.35, health: 220, maxHealth: 220 },
    { id: 'bar_south_east', label: 'South-East Checkpoint', x: 11, y: 14, angle: 0.35, health: 220, maxHealth: 220 },
  ];
}

/**
 * Deterministic Wave Director: computes wave composition from seed + waveNumber
 */
export function generateWaveComposition(
  seed: string,
  waveNumber: number,
  adaptiveDominanceBonus = 0
): WaveComposition {
  const safeWave = Math.max(1, Math.floor(waveNumber));
  const prng = mulberry32(hashSeedString(`${seed}::WAVE_${safeWave}`));

  const baseHostiles = Math.round(8 + safeWave * 5.5 + Math.pow(safeWave, 1.35) + adaptiveDominanceBonus * 3);

  // Determine weights per archetype as waves progress
  const walkerWeight = Math.max(0.25, 0.72 - safeWave * 0.04);
  const sprinterWeight = safeWave >= 1 ? Math.min(0.32, 0.16 + safeWave * 0.025) : 0;
  const spitterWeight = safeWave >= 2 ? Math.min(0.22, 0.08 + (safeWave - 1) * 0.02 + adaptiveDominanceBonus * 0.03) : 0;
  const bruteWeight = safeWave >= 3 ? Math.min(0.18, 0.06 + (safeWave - 2) * 0.02 + adaptiveDominanceBonus * 0.03) : 0;
  const screamerWeight = safeWave >= 4 ? Math.min(0.12, 0.04 + (safeWave - 3) * 0.015) : 0;

  const totalWeight = walkerWeight + sprinterWeight + spitterWeight + bruteWeight + screamerWeight;

  const counts: Record<ZombieArchetype, number> = {
    walker: 0,
    sprinter: 0,
    spitter: 0,
    brute: 0,
    screamer: 0,
  };

  for (let i = 0; i < baseHostiles; i++) {
    const roll = prng() * totalWeight;
    if (roll < walkerWeight) {
      counts.walker++;
    } else if (roll < walkerWeight + sprinterWeight) {
      counts.sprinter++;
    } else if (roll < walkerWeight + sprinterWeight + spitterWeight) {
      counts.spitter++;
    } else if (roll < walkerWeight + sprinterWeight + spitterWeight + bruteWeight) {
      counts.brute++;
    } else {
      counts.screamer++;
    }
  }

  // Guarantee at least 1 special strain on milestone waves
  if (safeWave >= 2 && counts.spitter === 0) counts.spitter = 1;
  if (safeWave >= 3 && counts.brute === 0) counts.brute = 1;
  if (safeWave >= 4 && counts.screamer === 0) counts.screamer = 1;

  const totalHostiles =
    counts.walker + counts.sprinter + counts.spitter + counts.brute + counts.screamer;

  // Every 3rd wave or high dominance roll triggers a localized Blackout event
  const isBlackoutWave = safeWave % 3 === 0 || (safeWave >= 2 && prng() < 0.25 + adaptiveDominanceBonus * 0.15);

  let hazardLevel: WaveComposition['hazardLevel'] = 'MODERATE';
  if (safeWave >= 12) hazardLevel = 'EXTINCTION';
  else if (safeWave >= 8) hazardLevel = 'CRITICAL';
  else if (safeWave >= 5 || isBlackoutWave) hazardLevel = 'SEVERE';
  else if (safeWave >= 3) hazardLevel = 'ELEVATED';

  const spawnIntervalMs = Math.max(260, Math.round(1150 - safeWave * 65 - adaptiveDominanceBonus * 45));
  const scrapBonus = 90 + safeWave * 35;

  return {
    waveNumber: safeWave,
    hazardLevel,
    isBlackoutWave,
    totalHostiles,
    spawnIntervalMs,
    counts,
    scrapBonus,
  };
}

/**
 * Active Reload sweet-spot evaluator
 * Sweet spot is [0.42, 0.68]. Hitting inside speeds up reload by 40% and triggers overcharge.
 */
export function evaluateActiveReload(
  progress: number,
  sweetSpotStart = 0.42,
  sweetSpotEnd = 0.68
): {
  outcome: 'sweet_spot' | 'early_jam' | 'late_miss';
  remainingTimeMultiplier: number;
  grantOvercharge: boolean;
} {
  if (progress >= sweetSpotStart && progress <= sweetSpotEnd) {
    return {
      outcome: 'sweet_spot',
      remainingTimeMultiplier: 0.15, // Completes almost immediately (40%+ overall speed boost)
      grantOvercharge: true,
    };
  }
  if (progress < sweetSpotStart) {
    return {
      outcome: 'early_jam',
      remainingTimeMultiplier: 1.25,
      grantOvercharge: false,
    };
  }
  return {
    outcome: 'late_miss',
    remainingTimeMultiplier: 1.0,
    grantOvercharge: false,
  };
}

/**
 * Available Modular Scrap Forge upgrades
 */
export const SCRAP_FORGE_CATALOG: ForgeUpgradeOption[] = [
  {
    id: 'forge_tesla_shotgun',
    name: 'Tesla Arc-Scatter Core',
    subtitle: 'M870 Trench Breacher + Shock Module',
    description: 'Infuses buckshot pellets with high-voltage arc lightning that chains between nearby infected and stuns sprinters.',
    costScrap: 140,
    targetWeaponIndex: 1,
    category: 'elemental',
    elementalInfusion: 'shock',
    damageMultiplier: 1.28,
    fireRateMultiplier: 1.12,
  },
  {
    id: 'forge_napalm_rifle',
    name: 'Thermite Napalm Payload',
    subtitle: 'Valkyrie Marksman Rifle + Incendiary Core',
    description: 'High-caliber impacts ignite lingering napalm pools on targets and pierce through armored Juggernaut plates.',
    costScrap: 160,
    targetWeaponIndex: 2,
    category: 'elemental',
    elementalInfusion: 'incendiary',
    damageMultiplier: 1.32,
    piercingBonus: 2,
  },
  {
    id: 'forge_cryo_sidearm',
    name: 'Cryo-N2 Subzero Receiver',
    subtitle: 'MK-IV Tactical Sidearm + Cryo Module',
    description: 'Converts sidearm into a rapid-burst cryo carbine that flash-freezes hostiles and shatters brittle targets.',
    costScrap: 120,
    targetWeaponIndex: 0,
    category: 'elemental',
    elementalInfusion: 'cryo',
    damageMultiplier: 1.25,
    fireRateMultiplier: 1.25,
    clipBonus: 8,
  },
  {
    id: 'forge_overclock_receiver',
    name: 'Tungsten Flechette Cycling',
    subtitle: 'All Weapons · Ballistic Evolution',
    description: 'Upgrades firing pins and flechette sabot rounds across all equipped weapons (+22% Damage, +15% Fire Rate, +1 Piercing).',
    costScrap: 190,
    targetWeaponIndex: 'all',
    category: 'ballistics',
    damageMultiplier: 1.22,
    fireRateMultiplier: 1.15,
    piercingBonus: 1,
  },
  {
    id: 'forge_barricade_grid',
    name: 'Reinforce Perimeter Barricades',
    subtitle: 'Tactical Fortification · All 6 Breaches',
    description: 'Restores 100% structural integrity to all 6 perimeter window/gate barricades and increases max health by +60.',
    costScrap: 90,
    targetWeaponIndex: 'fortification',
    category: 'fortification',
    fortificationAction: 'repair_barricades',
  },
  {
    id: 'forge_halogen_pack',
    name: 'Halogen Floodlight & Mine Pack',
    subtitle: 'Tactical Fortification · +2 Floodlights & +2 Mines',
    description: 'Fabricates 2 portable Halogen Floodlight Traps (blinds nocturnal sprinters) and 2 Tripwire Blast Mines, plus +50 Armor.',
    costScrap: 100,
    targetWeaponIndex: 'fortification',
    category: 'fortification',
    fortificationAction: 'deploy_floodlight',
  },
];

/**
 * Pure helper to evolve a WeaponEntity with a Scrap Forge upgrade
 */
export function applyScrapForgeUpgradeToWeapon(
  weapon: WeaponEntity,
  upgrade: ForgeUpgradeOption
): WeaponEntity {
  const evolved: WeaponEntity = { ...weapon };
  evolved.tier += 1;
  if (upgrade.elementalInfusion && upgrade.elementalInfusion !== 'none') {
    evolved.elemental = upgrade.elementalInfusion;
    const prefixMap: Record<ElementalType, string> = {
      none: '',
      shock: 'Tesla ',
      incendiary: 'Hellfire ',
      cryo: 'Cryo-Zero ',
    };
    const prefix = prefixMap[upgrade.elementalInfusion];
    if (!evolved.name.startsWith(prefix)) {
      evolved.name = `${prefix}${evolved.name}`;
    }
  }
  if (upgrade.damageMultiplier) {
    evolved.baseDamage = Math.round(evolved.baseDamage * upgrade.damageMultiplier);
  }
  if (upgrade.fireRateMultiplier) {
    evolved.fireRateRps = Number((evolved.fireRateRps * upgrade.fireRateMultiplier).toFixed(2));
  }
  if (upgrade.piercingBonus) {
    evolved.piercingCount += upgrade.piercingBonus;
  }
  if (upgrade.clipBonus) {
    evolved.clipSize += upgrade.clipBonus;
    evolved.currentAmmo = evolved.clipSize;
  }
  return evolved;
}

/**
 * Authoritative Server/Client Combat Telemetry Verification & Anti-Cheat Check
 */
export function verifyRunTelemetry(
  payload: TelemetrySubmissionPayload
): TelemetryVerificationResult {
  if (!payload.runSeed || typeof payload.runSeed !== 'string') {
    return {
      verified: false,
      reason: 'Missing or invalid quarantine seed.',
      verificationHash: 'INVALID_SEED',
      effectiveDps: 0,
      accuracyPct: 0,
    };
  }

  if (payload.durationMs < 1500 || payload.wavesCleared < 0 || payload.finalScore < 0) {
    return {
      verified: false,
      reason: 'Run duration or score negative/impossible.',
      verificationHash: 'INVALID_BOUNDS',
      effectiveDps: 0,
      accuracyPct: 0,
    };
  }

  // Verify timestamp monotonicity and fire rate limits
  let lastTimeMs = -1;
  let totalShotEvents = 0;
  let totalDamageDealt = 0;

  for (const ev of payload.telemetry) {
    if (ev.timeMs < lastTimeMs) {
      return {
        verified: false,
        reason: 'Non-monotonic telemetry timestamps detected.',
        verificationHash: 'ERR_TIME_ORDER',
        effectiveDps: 0,
        accuracyPct: 0,
      };
    }
    lastTimeMs = ev.timeMs;
    if (ev.action === 'SHOT') {
      totalShotEvents++;
      totalDamageDealt += ev.damageDealt ?? 0;
    }
  }

  const durationSec = Math.max(1, payload.durationMs / 1000);
  const averageRps = totalShotEvents / durationSec;
  const effectiveDps = Math.round(totalDamageDealt / durationSec);

  // Max physically possible fire rate ceiling with overclocked weapons is ~18 RPS
  if (averageRps > 24) {
    return {
      verified: false,
      reason: `Fire rate ceiling exceeded (${averageRps.toFixed(1)} RPS > 24.0 RPS max).`,
      verificationHash: 'ERR_FIRERATE_CAP',
      effectiveDps,
      accuracyPct: 0,
    };
  }

  // Max score plausibility ceiling per wave + scrap
  const maxPlausibleScore = (payload.wavesCleared + 2) * 35000 + payload.scrapCollected * 50 + 25000;
  if (payload.finalScore > maxPlausibleScore) {
    return {
      verified: false,
      reason: 'Score exceeds deterministic wave biomass ceiling.',
      verificationHash: 'ERR_SCORE_CAP',
      effectiveDps,
      accuracyPct: 0,
    };
  }

  const accuracyPct =
    payload.shotsFired > 0
      ? Math.min(100, Math.round((payload.shotsHit / payload.shotsFired) * 100))
      : 0;

  const rawSig = `${payload.runSeed}|${payload.wavesCleared}|${payload.finalScore}|${payload.scrapCollected}|${totalShotEvents}`;
  const sigHex = hashSeedString(rawSig).toString(16).toUpperCase().padStart(8, '0');

  return {
    verified: true,
    verificationHash: `QP-VERIFIED-${sigHex}`,
    effectiveDps,
    accuracyPct,
  };
}

/**
 * Formats the spoiler-free shareable Quarantine Protocol emoji badge
 * Example: ☣️ 🩸 💀 [Wave 19 // Scrap: 2,480 // 14m 22s]
 */
export function formatEmojiScorecard(params: {
  seed: string;
  wavesCleared: number;
  scrapCollected: number;
  durationMs: number;
  accuracyPct: number;
  favoriteSynergy: string;
  verifiedHash?: string;
}): string {
  const totalSeconds = Math.max(1, Math.floor(params.durationMs / 1000));
  const mins = Math.floor(totalSeconds / 60);
  const secs = String(totalSeconds % 60).padStart(2, '0');
  const scrapStr = Math.round(params.scrapCollected).toLocaleString('en-US');
  const waveMedal = params.wavesCleared >= 10 ? '⚡' : params.wavesCleared >= 5 ? '🔥' : '💀';
  return `☣️ 🩸 ${waveMedal} [Wave ${params.wavesCleared} // Scrap: ${scrapStr} // ${mins}m ${secs}s] · Seed: ${params.seed} · Arms: ${params.favoriteSynergy} · Acc: ${params.accuracyPct}%`;
}
