import { ElementalType } from '../types/game';

/**
 * Procedural Web Audio API Synthesizer for Outpost Zero
 * Zero external audio files — generates weight-scaled mechanical gunshots,
 * elemental infusions, active reload chimes, brute impacts, and blackout sirens.
 */
class SoundEngine {
  private ctx: AudioContext | null = null;
  private muted = false;
  private masterVolume = 0.7;
  private sfxVolume = 0.85;

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setVolumes(master: number, sfx: number, muted: boolean): void {
    this.masterVolume = Math.max(0, Math.min(1, master));
    this.sfxVolume = Math.max(0, Math.min(1, sfx));
    this.muted = muted;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    return this.muted;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  private gainLevel(base: number): number {
    return base * this.masterVolume * this.sfxVolume;
  }

  private pitchJitter(baseFreq: number): number {
    // ±8% pitch variation as specified in gameplay craft rules
    return baseFreq * (0.92 + Math.random() * 0.16);
  }

  public playGunshot(weaponId: string, elemental: ElementalType): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    const isShotgun = weaponId.includes('shotgun');
    const isRifle = weaponId.includes('rifle');

    if (isShotgun) {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(this.pitchJitter(135), now);
      osc.frequency.exponentialRampToValueAtTime(32, now + 0.14);
      gain.gain.setValueAtTime(this.gainLevel(0.28), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    } else if (isRifle) {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(this.pitchJitter(240), now);
      osc.frequency.exponentialRampToValueAtTime(48, now + 0.11);
      gain.gain.setValueAtTime(this.gainLevel(0.24), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    } else {
      osc.type = 'square';
      osc.frequency.setValueAtTime(this.pitchJitter(310), now);
      osc.frequency.exponentialRampToValueAtTime(75, now + 0.075);
      gain.gain.setValueAtTime(this.gainLevel(0.16), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    }

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.16);

    // Elemental layer
    if (elemental !== 'none') {
      const elOsc = ctx.createOscillator();
      const elGain = ctx.createGain();
      if (elemental === 'shock') {
        elOsc.type = 'sawtooth';
        elOsc.frequency.setValueAtTime(this.pitchJitter(980), now);
        elOsc.frequency.exponentialRampToValueAtTime(420, now + 0.09);
      } else if (elemental === 'incendiary') {
        elOsc.type = 'triangle';
        elOsc.frequency.setValueAtTime(this.pitchJitter(180), now);
        elOsc.frequency.exponentialRampToValueAtTime(65, now + 0.13);
      } else {
        elOsc.type = 'sine';
        elOsc.frequency.setValueAtTime(this.pitchJitter(1250), now);
        elOsc.frequency.exponentialRampToValueAtTime(620, now + 0.08);
      }
      elGain.gain.setValueAtTime(this.gainLevel(0.11), now);
      elGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      elOsc.connect(elGain);
      elGain.connect(ctx.destination);
      elOsc.start(now);
      elOsc.stop(now + 0.13);
    }
  }

  public playActiveReload(success: boolean): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (success) {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.setValueAtTime(880, now + 0.055); // A5 metallic slide chime
      gain.gain.setValueAtTime(this.gainLevel(0.24), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.19);
    } else {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.linearRampToValueAtTime(95, now + 0.12);
      gain.gain.setValueAtTime(this.gainLevel(0.18), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.14);
    }
  }

  public playHitConfirm(isHeavyKill = false): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = isHeavyKill ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(this.pitchJitter(isHeavyKill ? 160 : 420), now);
    osc.frequency.exponentialRampToValueAtTime(isHeavyKill ? 42 : 180, now + (isHeavyKill ? 0.14 : 0.05));

    gain.gain.setValueAtTime(this.gainLevel(isHeavyKill ? 0.25 : 0.1), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isHeavyKill ? 0.15 : 0.055));

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + (isHeavyKill ? 0.16 : 0.06));
  }

  public playPickup(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(this.pitchJitter(680), now);
    osc.frequency.exponentialRampToValueAtTime(1020, now + 0.06);
    gain.gain.setValueAtTime(this.gainLevel(0.12), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.08);
  }

  public playPlayerHurt(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110, now);
    osc.frequency.exponentialRampToValueAtTime(38, now + 0.18);
    gain.gain.setValueAtTime(this.gainLevel(0.28), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.21);
  }

  public playForgeUpgrade(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const freqs = [440, 554.37, 659.25, 880];
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + idx * 0.045);
      gain.gain.setValueAtTime(this.gainLevel(0.16), now + idx * 0.045);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.045 + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.045);
      osc.stop(now + idx * 0.045 + 0.17);
    });
  }

  public playWaveTransition(isBlackout: boolean): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    if (isBlackout) {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(55, now + 0.45);
    } else {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(660, now + 0.32);
    }
    gain.gain.setValueAtTime(this.gainLevel(0.22), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.5);
  }
}

export const soundEngine = new SoundEngine();
