import { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  applyScrapForgeUpgradeToWeapon,
  createInitialBarricades,
  createStarterWeapons,
  evaluateActiveReload,
  generateWaveComposition,
  getDailyUtcSeed,
  hashSeedString,
  mulberry32,
} from '../game/rules';
import { soundEngine } from '../game/sound';
import { SpatialHashGrid } from '../game/SpatialGrid';
import {
  buildBarricadeGroup,
  buildFloodlightTrapGroup,
  buildMineTrapGroup,
  buildOutpostEnvironment,
  buildPlayerOperative,
  buildZombieGroup,
  detectSoftwareGl,
} from '../game/ThreeArenaBuilder';
import {
  AccessibilitySettings,
  BarricadeEntity,
  ElementalType,
  FloodlightTrapEntity,
  ForgeUpgradeOption,
  ScrapPickupEntity,
  TelemetryEvent,
  TelemetrySubmissionPayload,
  TripwireMineEntity,
  WeaponEntity,
  ZombieArchetype,
  ZombieEntity,
  ZombieSurvivalGameState,
} from '../types/game';

interface PooledProjectile {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  elemental: ElementalType;
  piercingLeft: number;
  ttlMs: number;
  hitIds: Set<string>;
}

interface PooledParticle {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  lifeMs: number;
  maxLifeMs: number;
  scale: number;
  colorHex: number;
}

export interface FloatingCallout {
  id: string;
  text: string;
  color: string;
  worldX: number;
  worldZ: number;
  ttlMs: number;
}

const MAX_PROJECTILES = 120;
const MAX_PARTICLES = 240;
const MAX_ZOMBIE_POOL = 90;
const ARENA_BOUND = 23.5;

// Pre-allocated scratch math helpers at module scope (Zero-GC render loop)
const _scratchMatrix = new THREE.Matrix4();
const _scratchPos = new THREE.Vector3();
const _scratchQuat = new THREE.Quaternion();
const _scratchScale = new THREE.Vector3();
const _scratchColor = new THREE.Color();
const _rayPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -1.0);
const _rayIntersect = new THREE.Vector3();

export function useZombieSurvivalEngine(settings: AccessibilitySettings) {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const settingsRef = useRef<AccessibilitySettings>(settings);
  settingsRef.current = settings;

  const initialSeed = getDailyUtcSeed();

  const [hudState, setHudState] = useState<ZombieSurvivalGameState>(() => ({
    status: 'IDLE',
    seed: initialSeed,
    isDailyProtocol: true,
    currentWave: 1,
    enemiesRemaining: 0,
    totalWaveEnemies: 0,
    hazardLevel: 'MODERATE',
    isBlackout: false,
    intermissionTimerMs: 0,
    reloadState: {
      isReloading: false,
      progress: 0,
      sweetSpotStart: 0.42,
      sweetSpotEnd: 0.68,
      activeReloadStatus: 'idle',
      overchargeRemainingMs: 0,
    },
    player: {
      x: 0,
      y: 0,
      hp: 100,
      maxHp: 100,
      trailingHp: 100,
      armor: 50,
      maxArmor: 100,
      scrap: 180,
      biomass: 0,
      weapons: createStarterWeapons(),
      activeWeaponIndex: 0,
      floodlightCharges: 2,
      mineCharges: 2,
    },
    barricades: createInitialBarricades(),
    floodlights: [],
    mines: [],
    stats: {
      totalKills: 0,
      killsByType: { walker: 0, sprinter: 0, spitter: 0, brute: 0, screamer: 0 },
      shotsFired: 0,
      shotsHit: 0,
      timeSurvivedMs: 0,
      scrapCollectedTotal: 180,
      score: 0,
      bestScore: 0,
      causeOfDeath: '',
    },
  }));

  const [callouts, setCallouts] = useState<FloatingCallout[]>([]);
  const [forgeOpen, setForgeOpen] = useState(false);

  // Mutable engine state ref — decoupled from React reconciliation
  const engineRef = useRef<{
    status: ZombieSurvivalGameState['status'];
    seed: string;
    isDailyProtocol: boolean;
    prng: () => number;
    currentWave: number;
    hazardLevel: ZombieSurvivalGameState['hazardLevel'];
    isBlackout: boolean;
    spawnQueue: ZombieArchetype[];
    spawnTimerMs: number;
    spawnIntervalMs: number;
    intermissionTimerMs: number;
    hitstopTimerMs: number;
    cameraTrauma: number;
    player: {
      x: number;
      y: number;
      vx: number;
      vy: number;
      aimAngle: number;
      aimWorldX: number;
      aimWorldY: number;
      hp: number;
      maxHp: number;
      trailingHp: number;
      armor: number;
      maxArmor: number;
      scrap: number;
      biomass: number;
      weapons: WeaponEntity[];
      activeWeaponIndex: number;
      fireCooldownMs: number;
      muzzleFlashMs: number;
      squashX: number;
      squashZ: number;
      walkPhase: number;
      floodlightCharges: number;
      mineCharges: number;
      invulnMs: number;
    };
    reload: {
      isReloading: boolean;
      elapsedMs: number;
      totalMs: number;
      attemptedSweetSpot: boolean;
      activeReloadStatus: 'idle' | 'success' | 'jammed';
      overchargeRemainingMs: number;
    };
    zombies: ZombieEntity[];
    barricades: BarricadeEntity[];
    floodlights: FloodlightTrapEntity[];
    mines: TripwireMineEntity[];
    scrapPickups: ScrapPickupEntity[];
    projectiles: PooledProjectile[];
    particles: PooledParticle[];
    callouts: FloatingCallout[];
    telemetry: TelemetryEvent[];
    stats: ZombieSurvivalGameState['stats'];
    input: {
      keysHeld: Set<string>;
      mouseDown: boolean;
      mouseNdcX: number;
      mouseNdcY: number;
      virtualMoveX: number;
      virtualMoveY: number;
      virtualAimX: number;
      virtualAimY: number;
      virtualFiring: boolean;
    };
    actionsRef: {
      startWave: (waveNum: number) => void;
      triggerReload: () => void;
      deployFloodlight: () => void;
      deployMine: () => void;
      repairNearestBarricade: () => void;
      syncHudNow: () => void;
    };
  } | null>(null);

  // Sync body dataset state for Ultra Mode / Playwright assertions
  const syncBodyState = useCallback((status: ZombieSurvivalGameState['status']) => {
    if (typeof document === 'undefined') return;
    if (status === 'IDLE') document.body.dataset.state = 'title';
    else if (status === 'PAUSED') document.body.dataset.state = 'paused';
    else if (status === 'GAME_OVER') document.body.dataset.state = 'gameover';
    else document.body.dataset.state = 'playing';
  }, []);

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const isSoftwareGl = detectSoftwareGl();
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(mount.clientWidth || window.innerWidth, mount.clientHeight || window.innerHeight);

    mount.innerHTML = '';
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070a0b);
    scene.fog = new THREE.FogExp2(0x070a0b, 0.018);

    // Studio PBR Environment Reflection (RoomEnvironment + PMREMGenerator)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      46,
      (mount.clientWidth || window.innerWidth) / (mount.clientHeight || window.innerHeight),
      0.5,
      140
    );
    camera.position.set(0, 22, 16);
    camera.lookAt(0, 0, 0);

    // Warm Key Light + Cool Hemisphere Fill
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 0.55);
    scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xffedd5, 1.35);
    dirLight.position.set(16, 28, 14);
    dirLight.castShadow = !isSoftwareGl;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    const d = 26;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.camera.near = 2;
    dirLight.shadow.camera.far = 65;
    dirLight.shadow.bias = -0.0005;
    dirLight.shadow.normalBias = 0.02;
    scene.add(dirLight);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const { facilityLights, beaconMeshes } = buildOutpostEnvironment(scene, maxAniso);

    // Build Player 3D Group
    const playerRig = buildPlayerOperative();
    scene.add(playerRig.group);

    // Build Barricade 3D Groups
    const initialBarricades = createInitialBarricades();
    const barricadeMeshes = new Map<
      string,
      { group: THREE.Group; planksMesh: THREE.Mesh; beaconMat: THREE.MeshStandardMaterial }
    >();
    initialBarricades.forEach((b) => {
      const rig = buildBarricadeGroup();
      rig.group.position.set(b.x, 0, b.y);
      rig.group.rotation.y = b.angle;
      scene.add(rig.group);
      barricadeMeshes.set(b.id, rig);
    });

    // Dynamic Floodlights & Mines Visual Containers
    const floodlightMeshes = new Map<string, THREE.Group>();
    const mineMeshes = new Map<string, THREE.Group>();
    const scrapMeshes = new Map<string, THREE.Mesh>();
    const scrapGeo = new THREE.OctahedronGeometry(0.32, 0);
    const scrapMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xd97706,
      emissiveIntensity: 0.9,
      roughness: 0.25,
      metalness: 0.85,
    });
    const biomassMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      emissive: 0x059669,
      emissiveIntensity: 1.1,
      roughness: 0.2,
      metalness: 0.5,
    });

    // Object Pool for Zombie 3D Actor Groups
    const zombieVisualMap = new Map<
      string,
      ReturnType<typeof buildZombieGroup> & { type: ZombieArchetype }
    >();

    // InstancedMesh for Projectiles (MAX_PROJECTILES = 120)
    const projGeo = new THREE.SphereGeometry(0.16, 8, 8);
    const projMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const projInstanced = new THREE.InstancedMesh(projGeo, projMat, MAX_PROJECTILES);
    projInstanced.frustumCulled = false;
    scene.add(projInstanced);

    // InstancedMesh for Pooled Particles (MAX_PARTICLES = 240)
    const partGeo = new THREE.BoxGeometry(0.18, 0.18, 0.18);
    const partMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const partInstanced = new THREE.InstancedMesh(partGeo, partMat, MAX_PARTICLES);
    partInstanced.frustumCulled = false;
    scene.add(partInstanced);

    // Initialize Projectile & Particle Ring Buffers
    const projectiles: PooledProjectile[] = Array.from({ length: MAX_PROJECTILES }, () => ({
      active: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      damage: 25,
      elemental: 'none',
      piercingLeft: 1,
      ttlMs: 0,
      hitIds: new Set<string>(),
    }));

    const particles: PooledParticle[] = Array.from({ length: MAX_PARTICLES }, () => ({
      active: false,
      x: 0,
      y: 0,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      lifeMs: 0,
      maxLifeMs: 400,
      scale: 1,
      colorHex: 0xef4444,
    }));

    const spatialGrid = new SpatialHashGrid<ZombieEntity>(4.0);
    const raycaster = new THREE.Raycaster();
    const mouseVec2 = new THREE.Vector2();

    let particleCursor = 0;
    function spawnParticles(
      x: number,
      z: number,
      count: number,
      colorHex: number,
      speed = 6,
      scale = 1.0
    ) {
      for (let i = 0; i < count; i++) {
        const p = particles[particleCursor];
        particleCursor = (particleCursor + 1) % MAX_PARTICLES;
        const angle = Math.random() * Math.PI * 2;
        const spd = (0.35 + Math.random() * 0.65) * speed;
        p.active = true;
        p.x = x;
        p.y = 0.6 + Math.random() * 0.7;
        p.z = z;
        p.vx = Math.cos(angle) * spd;
        p.vy = 2.2 + Math.random() * 3.5;
        p.vz = Math.sin(angle) * spd;
        p.maxLifeMs = 260 + Math.random() * 260;
        p.lifeMs = p.maxLifeMs;
        p.scale = scale * (0.7 + Math.random() * 0.6);
        p.colorHex = colorHex;
      }
    }

    function pushCallout(text: string, color: string, worldX: number, worldZ: number) {
      if (!engineRef.current) return;
      engineRef.current.callouts.push({
        id: `co_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
        text,
        color,
        worldX,
        worldZ,
        ttlMs: 850,
      });
      if (engineRef.current.callouts.length > 8) {
        engineRef.current.callouts.shift();
      }
    }

    // Initialize Engine State
    const seed = getDailyUtcSeed();
    const state: NonNullable<typeof engineRef.current> = {
      status: 'IDLE',
      seed,
      isDailyProtocol: true,
      prng: mulberry32(hashSeedString(seed)),
      currentWave: 1,
      hazardLevel: 'MODERATE',
      isBlackout: false,
      spawnQueue: [],
      spawnTimerMs: 0,
      spawnIntervalMs: 900,
      intermissionTimerMs: 0,
      hitstopTimerMs: 0,
      cameraTrauma: 0,
      player: {
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        aimAngle: 0,
        aimWorldX: 0,
        aimWorldY: 6,
        hp: 100,
        maxHp: 100,
        trailingHp: 100,
        armor: 50,
        maxArmor: 100,
        scrap: 180,
        biomass: 0,
        weapons: createStarterWeapons(),
        activeWeaponIndex: 0,
        fireCooldownMs: 0,
        muzzleFlashMs: 0,
        squashX: 1,
        squashZ: 1,
        walkPhase: 0,
        floodlightCharges: 2,
        mineCharges: 2,
        invulnMs: 0,
      },
      reload: {
        isReloading: false,
        elapsedMs: 0,
        totalMs: 1150,
        attemptedSweetSpot: false,
        activeReloadStatus: 'idle',
        overchargeRemainingMs: 0,
      },
      zombies: [],
      barricades: initialBarricades,
      floodlights: [],
      mines: [],
      scrapPickups: [],
      projectiles,
      particles,
      callouts: [],
      telemetry: [],
      stats: {
        totalKills: 0,
        killsByType: { walker: 0, sprinter: 0, spitter: 0, brute: 0, screamer: 0 },
        shotsFired: 0,
        shotsHit: 0,
        timeSurvivedMs: 0,
        scrapCollectedTotal: 180,
        score: 0,
        bestScore: Number(localStorage.getItem('outpost_zero_best') || '0'),
        causeOfDeath: '',
      },
      input: {
        keysHeld: new Set<string>(),
        mouseDown: false,
        mouseNdcX: 0,
        mouseNdcY: 0.2,
        virtualMoveX: 0,
        virtualMoveY: 0,
        virtualAimX: 0,
        virtualAimY: 0,
        virtualFiring: false,
      },
      actionsRef: {
        startWave: () => {},
        triggerReload: () => {},
        deployFloodlight: () => {},
        deployMine: () => {},
        repairNearestBarricade: () => {},
        syncHudNow: () => {},
      },
    };

    function spawnZombieEntity(type: ZombieArchetype, customDist?: number) {
      if (state.zombies.length >= MAX_ZOMBIE_POOL) return;
      const angle = state.prng() * Math.PI * 2;
      const spawnDist = customDist ?? (16.5 + state.prng() * 3.5);
      const zx = Math.cos(angle) * spawnDist;
      const zy = Math.sin(angle) * spawnDist;

      const waveScale = 1 + (state.currentWave - 1) * 0.14;
      let maxHp = Math.round(52 * waveScale);
      let speed = 3.2 + state.prng() * 0.5;
      let damage = 12;
      let radius = 0.62;

      if (type === 'sprinter') {
        maxHp = Math.round(38 * waveScale);
        speed = 5.6 + state.prng() * 0.6;
        damage = 10;
        radius = 0.55;
      } else if (type === 'spitter') {
        maxHp = Math.round(64 * waveScale);
        speed = 2.8;
        damage = 16;
        radius = 0.65;
      } else if (type === 'brute') {
        maxHp = Math.round(210 * waveScale);
        speed = 2.25;
        damage = 28;
        radius = 0.98;
      } else if (type === 'screamer') {
        maxHp = Math.round(78 * waveScale);
        speed = 3.6;
        damage = 14;
        radius = 0.65;
      }

      const id = `z_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const entity: ZombieEntity = {
        id,
        type,
        x: zx,
        y: zy,
        vx: 0,
        vy: 0,
        hp: maxHp,
        maxHp,
        speed,
        damage,
        radius,
        attackCooldownMs: 400,
        windupTimerMs: 0,
        isWindingUp: false,
        targetX: 0,
        targetY: 0,
        koTimerMs: 0,
        isIlluminated: true,
        blindedByFloodlight: false,
      };
      state.zombies.push(entity);

      const rig = buildZombieGroup(type);
      rig.group.position.set(zx, 0, zy);
      scene.add(rig.group);
      zombieVisualMap.set(id, { ...rig, type });
    }

    // Seed ambient idling zombies outside perimeter for Title Screen Tour
    function seedTitleScreenActors() {
      // Clear existing zombies
      for (const [, v] of zombieVisualMap.entries()) {
        scene.remove(v.group);
      }
      zombieVisualMap.clear();
      state.zombies.length = 0;

      const demoTypes: ZombieArchetype[] = [
        'walker',
        'sprinter',
        'brute',
        'spitter',
        'walker',
        'screamer',
        'sprinter',
        'walker',
      ];
      demoTypes.forEach((t, i) => {
        const ang = (i / demoTypes.length) * Math.PI * 2;
        const r = 12 + (i % 3) * 2.5;
        const id = `demo_z_${i}`;
        const zx = Math.cos(ang) * r;
        const zy = Math.sin(ang) * r;
        state.zombies.push({
          id,
          type: t,
          x: zx,
          y: zy,
          vx: 0,
          vy: 0,
          hp: 100,
          maxHp: 100,
          speed: 1.5,
          damage: 10,
          radius: 0.65,
          attackCooldownMs: 0,
          windupTimerMs: 0,
          isWindingUp: false,
          targetX: 0,
          targetY: 0,
          koTimerMs: 0,
          isIlluminated: true,
          blindedByFloodlight: false,
        });
        const rig = buildZombieGroup(t);
        rig.group.position.set(zx, 0, zy);
        scene.add(rig.group);
        zombieVisualMap.set(id, { ...rig, type: t });
      });
    }

    seedTitleScreenActors();

    function syncHudNow() {
      const activeZombies = state.zombies.filter((z) => z.koTimerMs === 0).length;
      const enemiesRemaining = state.spawnQueue.length + activeZombies;
      setHudState({
        status: state.status,
        seed: state.seed,
        isDailyProtocol: state.isDailyProtocol,
        currentWave: state.currentWave,
        enemiesRemaining,
        totalWaveEnemies: Math.max(enemiesRemaining, state.spawnQueue.length + state.zombies.length),
        hazardLevel: state.hazardLevel,
        isBlackout: state.isBlackout,
        intermissionTimerMs: Math.max(0, Math.round(state.intermissionTimerMs)),
        reloadState: {
          isReloading: state.reload.isReloading,
          progress:
            state.reload.totalMs > 0
              ? Math.min(1, state.reload.elapsedMs / state.reload.totalMs)
              : 0,
          sweetSpotStart: 0.42,
          sweetSpotEnd: 0.68,
          activeReloadStatus: state.reload.activeReloadStatus,
          overchargeRemainingMs: Math.round(state.reload.overchargeRemainingMs),
        },
        player: {
          x: state.player.x,
          y: state.player.y,
          hp: Math.max(0, Math.round(state.player.hp)),
          maxHp: state.player.maxHp,
          trailingHp: Math.max(0, Math.round(state.player.trailingHp)),
          armor: Math.max(0, Math.round(state.player.armor)),
          maxArmor: state.player.maxArmor,
          scrap: Math.round(state.player.scrap),
          biomass: Math.round(state.player.biomass),
          weapons: state.player.weapons.map((w) => ({ ...w })),
          activeWeaponIndex: state.player.activeWeaponIndex,
          floodlightCharges: state.player.floodlightCharges,
          mineCharges: state.player.mineCharges,
        },
        barricades: state.barricades.map((b) => ({ ...b })),
        floodlights: state.floodlights.map((f) => ({ ...f })),
        mines: state.mines.map((m) => ({ ...m })),
        stats: {
          ...state.stats,
          killsByType: { ...state.stats.killsByType },
        },
      });
      setCallouts([...state.callouts]);
    }

    function startWave(waveNum: number) {
      state.currentWave = waveNum;
      const dominanceBonus = state.player.hp > 85 && waveNum >= 2 ? 1 : 0;
      const comp = generateWaveComposition(state.seed, waveNum, dominanceBonus);
      state.hazardLevel = comp.hazardLevel;
      state.isBlackout = comp.isBlackoutWave;
      state.spawnIntervalMs = comp.spawnIntervalMs;
      state.spawnTimerMs = 250;

      // Build deterministic shuffled spawn queue
      const queue: ZombieArchetype[] = [];
      (Object.keys(comp.counts) as ZombieArchetype[]).forEach((arch) => {
        for (let i = 0; i < comp.counts[arch]; i++) {
          queue.push(arch);
        }
      });
      for (let i = queue.length - 1; i > 0; i--) {
        const j = Math.floor(state.prng() * (i + 1));
        const tmp = queue[i];
        queue[i] = queue[j];
        queue[j] = tmp;
      }
      state.spawnQueue = queue;
      state.status = 'WAVE_ACTIVE';
      syncBodyState('WAVE_ACTIVE');
      soundEngine.playWaveTransition(comp.isBlackoutWave);

      if (comp.isBlackoutWave) {
        pushCallout('BLACKOUT PROTOCOL ACTIVE!', '#EF4444', state.player.x, state.player.y - 2);
      } else {
        pushCallout(`WAVE ${String(waveNum).padStart(2, '0')} INCOMING`, '#F59E0B', state.player.x, state.player.y - 2);
      }

      // Spawn initial vanguard immediately within camera frustum so arena feels alive right away
      const initialBurst = Math.min(5, state.spawnQueue.length);
      for (let i = 0; i < initialBurst; i++) {
        const nextType = state.spawnQueue.pop();
        if (nextType) spawnZombieEntity(nextType, 10.5 + i * 0.8);
      }
      syncHudNow();
    }

    function triggerReload() {
      const wpn = state.player.weapons[state.player.activeWeaponIndex];
      if (!wpn) return;

      // If not currently reloading, start reload
      if (!state.reload.isReloading) {
        if (wpn.currentAmmo >= wpn.clipSize) return;
        state.reload.isReloading = true;
        state.reload.elapsedMs = 0;
        state.reload.totalMs = wpn.reloadTimeMs;
        state.reload.attemptedSweetSpot = false;
        state.reload.activeReloadStatus = 'idle';
        syncHudNow();
        return;
      }

      // Active Reload Sweet-Spot Check!
      if (!state.reload.attemptedSweetSpot) {
        state.reload.attemptedSweetSpot = true;
        const progress = state.reload.elapsedMs / Math.max(1, state.reload.totalMs);
        const res = evaluateActiveReload(progress);
        if (res.outcome === 'sweet_spot') {
          state.reload.activeReloadStatus = 'success';
          state.reload.overchargeRemainingMs = 5000;
          wpn.currentAmmo = wpn.clipSize;
          state.reload.isReloading = false;
          soundEngine.playActiveReload(true);
          pushCallout('ACTIVE RELOAD! +25% DMG', '#10B981', state.player.x, state.player.y);
        } else if (res.outcome === 'early_jam') {
          state.reload.activeReloadStatus = 'jammed';
          state.reload.totalMs = Math.round(state.reload.totalMs * res.remainingTimeMultiplier);
          soundEngine.playActiveReload(false);
          pushCallout('RELOAD JAMMED!', '#EF4444', state.player.x, state.player.y);
        } else {
          soundEngine.playActiveReload(false);
        }
        syncHudNow();
      }
    }

    function deployFloodlight() {
      if (state.status !== 'WAVE_ACTIVE' && state.status !== 'WAVE_INTERMISSION') return;
      if (state.player.floodlightCharges <= 0 && state.player.scrap < 50) {
        pushCallout('NEED 50 SCRAP FOR FLOODLIGHT', '#F59E0B', state.player.x, state.player.y);
        return;
      }
      if (state.player.floodlightCharges > 0) {
        state.player.floodlightCharges--;
      } else {
        state.player.scrap -= 50;
      }

      const fx = state.player.x + Math.sin(state.player.aimAngle) * 2.4;
      const fy = state.player.y + Math.cos(state.player.aimAngle) * 2.4;
      const id = `fl_${Date.now()}`;
      const entity: FloodlightTrapEntity = {
        id,
        x: fx,
        y: fy,
        radius: 6.2,
        batteryMs: 45000,
        maxBatteryMs: 45000,
      };
      state.floodlights.push(entity);
      const meshGroup = buildFloodlightTrapGroup();
      meshGroup.position.set(fx, 0, fy);
      scene.add(meshGroup);
      floodlightMeshes.set(id, meshGroup);

      state.telemetry.push({
        timeMs: Math.round(state.stats.timeSurvivedMs),
        action: 'TRAP_DEPLOY',
        x: fx,
        y: fy,
        weaponId: 'floodlight_trap',
        hitCount: 0,
      });
      soundEngine.playForgeUpgrade();
      pushCallout('HALOGEN FLOODLIGHT DEPLOYED', '#38BDF8', fx, fy);
      syncHudNow();
    }

    function deployMine() {
      if (state.status !== 'WAVE_ACTIVE' && state.status !== 'WAVE_INTERMISSION') return;
      if (state.player.mineCharges <= 0 && state.player.scrap < 40) {
        pushCallout('NEED 40 SCRAP FOR MINE', '#F59E0B', state.player.x, state.player.y);
        return;
      }
      if (state.player.mineCharges > 0) {
        state.player.mineCharges--;
      } else {
        state.player.scrap -= 40;
      }

      const mx = state.player.x + Math.sin(state.player.aimAngle) * 1.8;
      const my = state.player.y + Math.cos(state.player.aimAngle) * 1.8;
      const id = `mine_${Date.now()}`;
      const entity: TripwireMineEntity = {
        id,
        x: mx,
        y: my,
        triggerRadius: 1.65,
        blastRadius: 4.8,
        damage: 185,
        armed: true,
      };
      state.mines.push(entity);
      const meshGroup = buildMineTrapGroup();
      meshGroup.position.set(mx, 0, my);
      scene.add(meshGroup);
      mineMeshes.set(id, meshGroup);
      soundEngine.playPickup();
      pushCallout('TRIPWIRE MINE ARMED', '#F59E0B', mx, my);
      syncHudNow();
    }

    function repairNearestBarricade() {
      if (state.status !== 'WAVE_ACTIVE' && state.status !== 'WAVE_INTERMISSION') return;
      let nearest: BarricadeEntity | null = null;
      let minDist = Infinity;
      for (const b of state.barricades) {
        if (b.health < b.maxHealth) {
          const d = Math.hypot(b.x - state.player.x, b.y - state.player.y);
          if (d < minDist) {
            minDist = d;
            nearest = b;
          }
        }
      }
      if (!nearest) {
        pushCallout('ALL BARRICADES AT 100%', '#10B981', state.player.x, state.player.y);
        return;
      }
      if (state.player.scrap < 30) {
        pushCallout('NEED 30 SCRAP TO FORTIFY', '#F59E0B', state.player.x, state.player.y);
        return;
      }
      state.player.scrap -= 30;
      nearest.health = Math.min(nearest.maxHealth, nearest.health + 120);
      soundEngine.playForgeUpgrade();
      pushCallout(`FORTIFIED ${nearest.label.toUpperCase()}`, '#F59E0B', nearest.x, nearest.y);
      syncHudNow();
    }

    state.actionsRef = {
      startWave,
      triggerReload,
      deployFloodlight,
      deployMine,
      repairNearestBarricade,
      syncHudNow,
    };
    engineRef.current = state;

    // Pre-warm shaders on hardware GPUs
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Window & Input Listeners
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      const code = e.code;
      state.input.keysHeld.add(code);

      if (state.status === 'IDLE' && (code === 'Enter' || code === 'Space')) {
        e.preventDefault();
        startNewGame(state.seed, state.isDailyProtocol);
        return;
      }

      if (code === 'Escape' || code === 'KeyP') {
        if (state.status === 'WAVE_ACTIVE' || state.status === 'WAVE_INTERMISSION') {
          state.status = 'PAUSED';
          syncBodyState('PAUSED');
          syncHudNow();
        } else if (state.status === 'PAUSED') {
          state.status = state.intermissionTimerMs > 0 ? 'WAVE_INTERMISSION' : 'WAVE_ACTIVE';
          syncBodyState(state.status);
          syncHudNow();
        }
        return;
      }

      if (state.status !== 'WAVE_ACTIVE' && state.status !== 'WAVE_INTERMISSION') return;

      if (code === 'KeyR') {
        triggerReload();
      } else if (code === 'Digit1') {
        state.player.activeWeaponIndex = 0;
        state.reload.isReloading = false;
        syncHudNow();
      } else if (code === 'Digit2') {
        state.player.activeWeaponIndex = 1;
        state.reload.isReloading = false;
        syncHudNow();
      } else if (code === 'Digit3') {
        state.player.activeWeaponIndex = 2;
        state.reload.isReloading = false;
        syncHudNow();
      } else if (code === 'KeyE') {
        setForgeOpen((prev) => !prev);
      } else if (code === 'KeyF') {
        deployFloodlight();
      } else if (code === 'KeyG') {
        deployMine();
      } else if (code === 'KeyB') {
        repairNearestBarricade();
      } else if (code === 'KeyM') {
        soundEngine.toggleMute();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      state.input.keysHeld.delete(e.code);
    };

    const onBlur = () => {
      state.input.keysHeld.clear();
      state.input.mouseDown = false;
    };

    const onPointerMove = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      state.input.mouseNdcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      state.input.mouseNdcY = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      if (e.target === renderer.domElement) {
        state.input.mouseDown = true;
      }
    };

    const onPointerUp = () => {
      state.input.mouseDown = false;
    };

    const onResize = () => {
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('resize', onResize);

    // Check `?autostart=1` query parameter
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      startNewGame(state.seed, true);
    } else {
      syncBodyState('IDLE');
    }

    // Software WebGL afterDraw helper (prevents starving headless Chromium screenshots)
    let frameId = 0;
    let unmounted = false;
    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (unmounted) return;
        const syncState = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (syncState === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    let lastFrameTime = performance.now();
    let hudSyncAccumulatorMs = 0;
    let titleTourAngle = 0;

    function tick() {
      if (unmounted) return;
      const now = performance.now();
      const rawDt = (now - lastFrameTime) / 1000;
      lastFrameTime = now;

      // Clamp frame delta time to <= 0.05s
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
      const dtMs = dt * 1000;

      // Update Audio Volume settings
      soundEngine.setVolumes(
        settingsRef.current.masterVolume,
        settingsRef.current.sfxVolume,
        settingsRef.current.muted
      );

      if (state.status === 'IDLE') {
        // Live World Camera Tour around the Quarantine Outpost
        titleTourAngle += dt * 0.22;
        const camX = Math.sin(titleTourAngle) * 21;
        const camZ = Math.cos(titleTourAngle) * 21;
        camera.position.set(camX, 17.5, camZ);
        camera.lookAt(0, 1.0, 0);

        // Gently animate idling zombies outside the perimeter
        state.zombies.forEach((z, idx) => {
          const rig = zombieVisualMap.get(z.id);
          if (rig) {
            const wanderAng = titleTourAngle * 1.4 + idx;
            rig.group.rotation.y = wanderAng;
            rig.group.position.y = Math.abs(Math.sin(now * 0.004 + idx)) * 0.08;
          }
        });
      } else if (state.status === 'WAVE_ACTIVE' || state.status === 'WAVE_INTERMISSION') {
        // Tick Hitstop Timer
        const inHitstop = state.hitstopTimerMs > 0;
        if (inHitstop) {
          state.hitstopTimerMs = Math.max(0, state.hitstopTimerMs - dtMs);
        }
        const simDt = inHitstop ? 0 : dt;
        const simDtMs = simDt * 1000;

        state.stats.timeSurvivedMs += simDtMs;

        // Smoothly trail HP bar
        state.player.trailingHp = THREE.MathUtils.damp(
          state.player.trailingHp,
          state.player.hp,
          4.5,
          dt
        );

        if (state.player.invulnMs > 0) {
          state.player.invulnMs = Math.max(0, state.player.invulnMs - dtMs);
        }

        // Update Blackout Lighting Atmosphere
        const targetFacilityIntensity = state.isBlackout ? 0.15 : 9.0;
        facilityLights.forEach((fl) => {
          fl.intensity = THREE.MathUtils.damp(fl.intensity, targetFacilityIntensity, 4, dt);
        });
        hemiLight.intensity = THREE.MathUtils.damp(
          hemiLight.intensity,
          state.isBlackout ? 0.14 : 0.55,
          4,
          dt
        );
        dirLight.intensity = THREE.MathUtils.damp(
          dirLight.intensity,
          state.isBlackout ? 0.22 : 1.35,
          4,
          dt
        );
        beaconMeshes.forEach((bm) => {
          const mat = bm.material as THREE.MeshStandardMaterial;
          if (state.isBlackout) {
            mat.emissive.setHex(0xef4444);
            mat.emissiveIntensity = 1.2 + Math.sin(now * 0.01) * 0.8;
          } else {
            mat.emissive.setHex(0xf59e0b);
            mat.emissiveIntensity = 1.4;
          }
        });

        // 1. Player 8-Directional Movement with Acceleration & Damping
        let moveX = state.input.virtualMoveX;
        let moveY = state.input.virtualMoveY;
        const keys = state.input.keysHeld;
        if (keys.has('KeyW') || keys.has('ArrowUp')) moveY -= 1;
        if (keys.has('KeyS') || keys.has('ArrowDown')) moveY += 1;
        if (keys.has('KeyA') || keys.has('ArrowLeft')) moveX -= 1;
        if (keys.has('KeyD') || keys.has('ArrowRight')) moveX += 1;

        const moveLen = Math.hypot(moveX, moveY);
        if (moveLen > 1) {
          moveX /= moveLen;
          moveY /= moveLen;
        }

        const maxPlayerSpeed = 8.4;
        state.player.vx = THREE.MathUtils.damp(state.player.vx, moveX * maxPlayerSpeed, 14, simDt);
        state.player.vy = THREE.MathUtils.damp(state.player.vy, moveY * maxPlayerSpeed, 14, simDt);

        state.player.x = THREE.MathUtils.clamp(
          state.player.x + state.player.vx * simDt,
          -ARENA_BOUND,
          ARENA_BOUND
        );
        state.player.y = THREE.MathUtils.clamp(
          state.player.y + state.player.vy * simDt,
          -ARENA_BOUND,
          ARENA_BOUND
        );

        const speedMag = Math.hypot(state.player.vx, state.player.vy);
        state.player.walkPhase += speedMag * simDt * 2.4;
        state.player.squashX = THREE.MathUtils.damp(state.player.squashX, 1, 12, dt);
        state.player.squashZ = THREE.MathUtils.damp(state.player.squashZ, 1, 12, dt);

        // 2. Player Aiming (Raycast Mouse to Ground Plane or Auto-Aim Assist)
        mouseVec2.set(state.input.mouseNdcX, state.input.mouseNdcY);
        raycaster.setFromCamera(mouseVec2, camera);
        if (raycaster.ray.intersectPlane(_rayPlane, _rayIntersect)) {
          state.player.aimWorldX = _rayIntersect.x;
          state.player.aimWorldY = _rayIntersect.z;
        }

        if (
          Math.abs(state.input.virtualAimX) > 0.1 ||
          Math.abs(state.input.virtualAimY) > 0.1
        ) {
          state.player.aimAngle = Math.atan2(state.input.virtualAimX, state.input.virtualAimY);
        } else if (settingsRef.current.autoAimAssist && state.zombies.length > 0) {
          // Find closest living zombie within 16m
          let closestZ: ZombieEntity | null = null;
          let minD = 16.5;
          for (const z of state.zombies) {
            if (z.koTimerMs > 0) continue;
            const d = Math.hypot(z.x - state.player.x, z.y - state.player.y);
            if (d < minD) {
              minD = d;
              closestZ = z;
            }
          }
          if (closestZ) {
            const targetAng = Math.atan2(
              closestZ.x - state.player.x,
              closestZ.y - state.player.y
            );
            state.player.aimAngle = targetAng;
          } else {
            state.player.aimAngle = Math.atan2(
              state.player.aimWorldX - state.player.x,
              state.player.aimWorldY - state.player.y
            );
          }
        } else {
          state.player.aimAngle = Math.atan2(
            state.player.aimWorldX - state.player.x,
            state.player.aimWorldY - state.player.y
          );
        }

        // Update Player 3D Transform
        playerRig.group.position.set(
          state.player.x,
          Math.abs(Math.sin(state.player.walkPhase)) * 0.08,
          state.player.y
        );
        playerRig.group.rotation.y = state.player.aimAngle;
        playerRig.group.scale.set(state.player.squashX, 1, state.player.squashZ);

        // 3. Active Reload Progression
        const activeWeapon = state.player.weapons[state.player.activeWeaponIndex];
        if (state.reload.overchargeRemainingMs > 0) {
          state.reload.overchargeRemainingMs = Math.max(
            0,
            state.reload.overchargeRemainingMs - simDtMs
          );
        }

        if (state.reload.isReloading && activeWeapon) {
          state.reload.elapsedMs += simDtMs;
          if (state.reload.elapsedMs >= state.reload.totalMs) {
            activeWeapon.currentAmmo = activeWeapon.clipSize;
            state.reload.isReloading = false;
            state.reload.activeReloadStatus = 'idle';
            syncHudNow();
          }
        }

        // 4. Weapon Firing & Recoil
        if (state.player.fireCooldownMs > 0) {
          state.player.fireCooldownMs = Math.max(0, state.player.fireCooldownMs - simDtMs);
        }
        if (state.player.muzzleFlashMs > 0) {
          state.player.muzzleFlashMs = Math.max(0, state.player.muzzleFlashMs - dtMs);
          playerRig.muzzleLight.intensity = state.player.muzzleFlashMs > 0 ? 14 : 0;
          (playerRig.muzzleMesh.material as THREE.MeshBasicMaterial).opacity =
            state.player.muzzleFlashMs > 0 ? 0.9 : 0;
        } else {
          playerRig.muzzleLight.intensity = 0;
          (playerRig.muzzleMesh.material as THREE.MeshBasicMaterial).opacity = 0;
        }

        const wantsToFire =
          state.input.mouseDown ||
          state.input.virtualFiring ||
          state.input.keysHeld.has('Space') ||
          (settingsRef.current.autoFire && state.zombies.some((z) => z.koTimerMs === 0));

        if (
          wantsToFire &&
          !state.reload.isReloading &&
          state.player.fireCooldownMs <= 0 &&
          activeWeapon
        ) {
          if (activeWeapon.currentAmmo <= 0) {
            triggerReload();
          } else {
            activeWeapon.currentAmmo--;
            state.player.fireCooldownMs = 1000 / activeWeapon.fireRateRps;
            state.player.muzzleFlashMs = 38;
            state.stats.shotsFired++;

            // Subtle recoil punch & squash
            state.player.x -= Math.sin(state.player.aimAngle) * 0.08;
            state.player.y -= Math.cos(state.player.aimAngle) * 0.08;
            state.player.squashX = 1.14;
            state.player.squashZ = 0.88;
            state.cameraTrauma = Math.min(0.45, state.cameraTrauma + 0.12);

            soundEngine.playGunshot(activeWeapon.id, activeWeapon.elemental);

            const overchargeMult = state.reload.overchargeRemainingMs > 0 ? 1.25 : 1.0;
            const shotDmg = Math.round(activeWeapon.baseDamage * overchargeMult);

            for (let pIdx = 0; pIdx < activeWeapon.pellets; pIdx++) {
              const slot = projectiles.find((p) => !p.active);
              if (!slot) break;
              const spreadOffset = (Math.random() - 0.5) * activeWeapon.spreadRad;
              const ang = state.player.aimAngle + spreadOffset;
              slot.active = true;
              slot.x = state.player.x + Math.sin(ang) * 0.85;
              slot.y = state.player.y + Math.cos(ang) * 0.85;
              slot.vx = Math.sin(ang) * activeWeapon.projectileSpeed;
              slot.vy = Math.cos(ang) * activeWeapon.projectileSpeed;
              slot.damage = shotDmg;
              slot.elemental = activeWeapon.elemental;
              slot.piercingLeft = activeWeapon.piercingCount;
              slot.ttlMs = 1100;
              slot.hitIds.clear();
            }

            state.telemetry.push({
              timeMs: Math.round(state.stats.timeSurvivedMs),
              action: 'SHOT',
              x: Number(state.player.x.toFixed(2)),
              y: Number(state.player.y.toFixed(2)),
              weaponId: activeWeapon.id,
              hitCount: 0,
              damageDealt: 0,
            });

            if (activeWeapon.currentAmmo === 0) {
              triggerReload();
            }
          }
        }

        // 5. Wave Spawner & Intermission Progression
        if (state.status === 'WAVE_ACTIVE') {
          if (state.spawnQueue.length > 0) {
            state.spawnTimerMs -= simDtMs;
            if (state.spawnTimerMs <= 0) {
              state.spawnTimerMs = state.spawnIntervalMs;
              const nextArch = state.spawnQueue.pop();
              if (nextArch) spawnZombieEntity(nextArch);
            }
          } else if (state.zombies.length === 0) {
            // Wave Cleared!
            state.status = 'WAVE_INTERMISSION';
            state.intermissionTimerMs = 8000;
            state.isBlackout = false;
            state.player.scrap += 85 + state.currentWave * 25;
            state.stats.scrapCollectedTotal += 85 + state.currentWave * 25;
            state.stats.score += 1200 * state.currentWave;
            state.telemetry.push({
              timeMs: Math.round(state.stats.timeSurvivedMs),
              action: 'WAVE_CLEAR',
              x: state.player.x,
              y: state.player.y,
              weaponId: activeWeapon?.id || 'wpn_service_sidearm',
              hitCount: 0,
            });
            soundEngine.playWaveTransition(false);
            pushCallout(
              `WAVE ${state.currentWave} CLEARED! PRESS [E] FOR SCRAP FORGE`,
              '#10B981',
              state.player.x,
              state.player.y
            );
            syncHudNow();
          }
        } else if (state.status === 'WAVE_INTERMISSION') {
          state.intermissionTimerMs -= simDtMs;
          if (state.intermissionTimerMs <= 0) {
            setForgeOpen(false);
            startWave(state.currentWave + 1);
          }
        }

        // 6. Populate Spatial Hash Grid for Broadphase Collisions
        spatialGrid.clear();
        for (let i = 0; i < state.zombies.length; i++) {
          const z = state.zombies[i];
          if (z.koTimerMs === 0) {
            spatialGrid.insert(z);
          }
        }

        // 7. Update Floodlights & Mines
        for (let i = state.floodlights.length - 1; i >= 0; i--) {
          const fl = state.floodlights[i];
          fl.batteryMs -= simDtMs;
          if (fl.batteryMs <= 0) {
            const mGroup = floodlightMeshes.get(fl.id);
            if (mGroup) scene.remove(mGroup);
            floodlightMeshes.delete(fl.id);
            state.floodlights.splice(i, 1);
          }
        }

        for (let i = state.mines.length - 1; i >= 0; i--) {
          const mn = state.mines[i];
          if (!mn.armed) continue;
          const nearby = spatialGrid.queryRadius(mn.x, mn.y, mn.triggerRadius);
          if (nearby.length > 0) {
            mn.armed = false;
            const blastTargets = spatialGrid.queryRadius(mn.x, mn.y, mn.blastRadius);
            blastTargets.forEach((z) => {
              z.hp -= mn.damage;
              z.hitFlashMs = 90;
            });
            spawnParticles(mn.x, mn.y, 26, 0xf59e0b, 11, 1.5);
            state.cameraTrauma = Math.min(1, state.cameraTrauma + 0.55);
            state.hitstopTimerMs = 55;
            soundEngine.playHitConfirm(true);
            pushCallout('MINE DETONATION!', '#F59E0B', mn.x, mn.y);
            const mGroup = mineMeshes.get(mn.id);
            if (mGroup) scene.remove(mGroup);
            mineMeshes.delete(mn.id);
            state.mines.splice(i, 1);
          }
        }

        // 8. Update Zombies, Flashlight Fog-of-War Silhouette Check & Crowd Token Pool
        let activeWindupCount = 0;
        for (const z of state.zombies) {
          if (z.isWindingUp) activeWindupCount++;
        }

        const aimDirX = Math.sin(state.player.aimAngle);
        const aimDirY = Math.cos(state.player.aimAngle);

        for (let i = state.zombies.length - 1; i >= 0; i--) {
          const z = state.zombies[i];
          const rig = zombieVisualMap.get(z.id);

          // Check KO topple state
          if (z.hp <= 0 && z.koTimerMs === 0) {
            z.koTimerMs = 320;
            state.stats.totalKills++;
            state.stats.killsByType[z.type] = (state.stats.killsByType[z.type] || 0) + 1;
            const scoreGain =
              z.type === 'brute'
                ? 450
                : z.type === 'screamer'
                  ? 300
                  : z.type === 'spitter'
                    ? 220
                    : z.type === 'sprinter'
                      ? 160
                      : 100;
            state.stats.score += scoreGain;
            if (state.stats.score > state.stats.bestScore) {
              state.stats.bestScore = state.stats.score;
              localStorage.setItem('outpost_zero_best', String(state.stats.bestScore));
            }

            // Drop Scrap / Biomass pickup
            const dropId = `scrap_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
            const isBio = z.type === 'brute' || z.type === 'spitter' || z.type === 'screamer';
            const dropAmount = z.type === 'brute' ? 45 : isBio ? 28 : 16;
            state.scrapPickups.push({
              id: dropId,
              x: z.x,
              y: z.y,
              amount: dropAmount,
              isBiomass: isBio,
              ttlMs: 18000,
            });
            const sMesh = new THREE.Mesh(scrapGeo, isBio ? biomassMat : scrapMat);
            sMesh.position.set(z.x, 0.38, z.y);
            scene.add(sMesh);
            scrapMeshes.set(dropId, sMesh);

            spawnParticles(z.x, z.y, z.type === 'brute' ? 22 : 12, 0xef4444, 7.5, 1.2);
            if (z.type === 'brute') {
              state.hitstopTimerMs = 55;
              state.cameraTrauma = Math.min(1, state.cameraTrauma + 0.38);
              soundEngine.playHitConfirm(true);
            } else {
              soundEngine.playHitConfirm(false);
            }
          }

          if (z.koTimerMs > 0) {
            z.koTimerMs -= dtMs;
            if (rig) {
              rig.group.rotation.x = THREE.MathUtils.lerp(
                rig.group.rotation.x,
                -Math.PI / 2,
                0.22
              );
              rig.group.position.y = Math.max(-0.3, rig.group.position.y - dt * 1.2);
            }
            if (z.koTimerMs <= 0) {
              if (rig) scene.remove(rig.group);
              zombieVisualMap.delete(z.id);
              state.zombies.splice(i, 1);
            }
            continue;
          }

          // Elemental Status Effects (Burn & Cryo Freeze & Shock Stun)
          if (z.burnDurationMs && z.burnDurationMs > 0) {
            z.burnDurationMs -= simDtMs;
            z.hp -= 24 * simDt;
          }
          if (z.freezeTimerMs && z.freezeTimerMs > 0) {
            z.freezeTimerMs -= simDtMs;
            z.isFrozen = z.freezeTimerMs > 0;
          } else {
            z.isFrozen = false;
          }
          if (z.shockStunMs && z.shockStunMs > 0) {
            z.shockStunMs -= simDtMs;
          }

          // Raycasted Flashlight Cone & Floodlight Illumination Check
          const dxP = z.x - state.player.x;
          const dyP = z.y - state.player.y;
          const distP = Math.hypot(dxP, dyP) || 0.001;
          const dotCone = (dxP / distP) * aimDirX + (dyP / distP) * aimDirY;
          const inFlashlightCone = distP < 19.5 && dotCone > 0.72; // ~44 deg half-angle
          const nearPlayer = distP < 3.6;

          let inFloodlight = false;
          for (const fl of state.floodlights) {
            if (Math.hypot(z.x - fl.x, z.y - fl.y) <= fl.radius) {
              inFloodlight = true;
              break;
            }
          }

          z.blindedByFloodlight = inFloodlight && z.type === 'sprinter';
          z.isIlluminated = inFlashlightCone || inFloodlight || nearPlayer;

          // Distinct Archetype Movement Policies
          let speedMult = z.isFrozen ? 0.42 : 1.0;
          if (z.shockStunMs && z.shockStunMs > 0) speedMult *= 0.15;
          if (z.blindedByFloodlight) speedMult *= 0.45;

          const dirToPlayerX = -dxP / distP;
          const dirToPlayerY = -dyP / distP;

          if (z.type === 'spitter') {
            // Policy 2: Ranged Kiter — maintains 8-11m standoff distance and fires telegraphed acid globules
            if (distP > 11.0) {
              z.vx = dirToPlayerX * z.speed * speedMult;
              z.vy = dirToPlayerY * z.speed * speedMult;
            } else if (distP < 6.5) {
              z.vx = -dirToPlayerX * z.speed * 0.75 * speedMult;
              z.vy = -dirToPlayerY * z.speed * 0.75 * speedMult;
            } else {
              // Strafe perpendicular
              z.vx = -dirToPlayerY * z.speed * 0.65 * speedMult;
              z.vy = dirToPlayerX * z.speed * 0.65 * speedMult;
            }
          } else if (z.type === 'sprinter') {
            // Policy 3: Flanking Weave Swarmer
            const weave = Math.sin(now * 0.008 + i) * 0.55;
            const perpX = -dirToPlayerY * weave;
            const perpY = dirToPlayerX * weave;
            z.vx = (dirToPlayerX + perpX) * z.speed * speedMult;
            z.vy = (dirToPlayerY + perpY) * z.speed * speedMult;
          } else if (z.type === 'screamer') {
            // Policy 4: Orbiting Support Siren
            const orbitFactor = distP > 9 ? 0.8 : 0.25;
            z.vx = (dirToPlayerX * orbitFactor - dirToPlayerY * 0.75) * z.speed * speedMult;
            z.vy = (dirToPlayerY * orbitFactor + dirToPlayerX * 0.75) * z.speed * speedMult;
          } else {
            // Policy 1 & 5: Direct Seeker / Line-of-Sight Brute Charger
            const chargeBoost = z.type === 'brute' && z.isWindingUp ? 1.85 : 1.0;
            z.vx = dirToPlayerX * z.speed * speedMult * chargeBoost;
            z.vy = dirToPlayerY * z.speed * speedMult * chargeBoost;
          }

          // Check Barricade Collisions along path
          let blockedByBarricade = false;
          for (const b of state.barricades) {
            if (b.health <= 0) continue;
            const db = Math.hypot(z.x - b.x, z.y - b.y);
            if (db < z.radius + 1.35) {
              blockedByBarricade = true;
              b.health = Math.max(0, b.health - z.damage * 0.8 * simDt);
              // Push zombie slightly back from intact barricade
              const pushX = (z.x - b.x) / (db || 1);
              const pushY = (z.y - b.y) / (db || 1);
              z.x += pushX * simDt * 2.0;
              z.y += pushY * simDt * 2.0;
              break;
            }
          }

          if (!blockedByBarricade) {
            z.x += z.vx * simDt;
            z.y += z.vy * simDt;
          }

          // Attack Telegraph & Execution (Token-pooled so max 4 wind up simultaneously)
          if (z.attackCooldownMs > 0) {
            z.attackCooldownMs = Math.max(0, z.attackCooldownMs - simDtMs);
          }

          const attackRange = z.type === 'spitter' ? 11.5 : z.radius + 0.95;
          if (!z.isWindingUp && distP <= attackRange && z.attackCooldownMs <= 0 && activeWindupCount < 4) {
            z.isWindingUp = true;
            z.windupTimerMs = z.type === 'brute' ? 620 : z.type === 'spitter' ? 580 : 360;
            activeWindupCount++;
          }

          if (z.isWindingUp) {
            z.windupTimerMs -= simDtMs;
            if (z.windupTimerMs <= 0) {
              z.isWindingUp = false;
              z.attackCooldownMs = z.type === 'brute' ? 1600 : z.type === 'spitter' ? 2100 : 1100;

              // Check if player is still within strike distance (or spitter range)
              const currentDist = Math.hypot(z.x - state.player.x, z.y - state.player.y);
              const hitRange = z.type === 'spitter' ? 12.2 : z.radius + 1.45;
              if (currentDist <= hitRange && state.player.invulnMs <= 0) {
                let incomingDmg = z.damage;
                if (state.player.armor > 0) {
                  const absorbed = Math.min(state.player.armor, incomingDmg * 0.65);
                  state.player.armor -= absorbed;
                  incomingDmg -= absorbed;
                }
                state.player.hp = Math.max(0, state.player.hp - incomingDmg);
                state.player.invulnMs = 260;
                state.cameraTrauma = Math.min(1, state.cameraTrauma + 0.42);
                soundEngine.playPlayerHurt();
                spawnParticles(state.player.x, state.player.y, 10, 0xef4444, 6, 1.0);

                if (state.player.hp <= 0) {
                  const archetypeLabels: Record<ZombieArchetype, string> = {
                    walker: 'Infected Walker Swarm',
                    sprinter: 'Nocturnal Sprinter Pack',
                    spitter: 'Bio-Acid Spitter Barrage',
                    brute: 'Armored Juggernaut Maul',
                    screamer: 'Resonator Screamer Surge',
                  };
                  state.stats.causeOfDeath = `Overrun by ${archetypeLabels[z.type]} on Wave ${state.currentWave}`;
                  state.status = 'GAME_OVER';
                  syncBodyState('GAME_OVER');
                  syncHudNow();
                }
              }
            }
          }

          // Update Zombie 3D Visuals & Dynamic Fog-of-War Silhouette Material
          if (rig) {
            const gaitBob = Math.abs(Math.sin(now * 0.01 + i)) * 0.1;
            rig.group.position.set(z.x, gaitBob, z.y);
            rig.group.rotation.y = Math.atan2(dirToPlayerX, dirToPlayerY);

            // Telegraph ring visibility
            const teleMat = rig.telegraphRing.material as THREE.MeshBasicMaterial;
            if (z.isWindingUp) {
              teleMat.opacity = 0.65 + Math.sin(now * 0.03) * 0.25;
              const s = 1.0 + (1 - z.windupTimerMs / 600) * 0.35;
              rig.telegraphRing.scale.setScalar(s);
            } else {
              teleMat.opacity = 0;
            }

            // Hit Flash vs Fog-of-War Silhouette vs Illuminated PBR
            if (z.hitFlashMs && z.hitFlashMs > 0) {
              z.hitFlashMs -= dtMs;
              rig.bodyMaterials.forEach((m) => {
                m.emissive.setHex(0xffffff);
                m.emissiveIntensity = 1.8;
              });
            } else if (!z.isIlluminated) {
              // Outside flashlight cone -> shadowed silhouette with glowing crimson eyes!
              rig.bodyMaterials.forEach((m) => {
                m.color.setHex(0x090d10);
                m.emissive.setHex(0x000000);
                m.emissiveIntensity = 0;
              });
              rig.eyeMesh.scale.setScalar(1.45);
            } else {
              // Illuminated inside flashlight cone or floodlight zone
              const baseHex =
                z.type === 'brute'
                  ? 0x453222
                  : z.type === 'spitter'
                    ? 0x15803d
                    : z.type === 'sprinter'
                      ? 0x7f1d1d
                      : z.type === 'screamer'
                        ? 0x3730a3
                        : 0x334155;
              rig.bodyMaterials[0].color.setHex(z.isFrozen ? 0x38bdf8 : baseHex);
              rig.bodyMaterials[0].emissive.setHex(
                z.burnDurationMs && z.burnDurationMs > 0
                  ? 0xf59e0b
                  : z.shockStunMs && z.shockStunMs > 0
                    ? 0x06b6d4
                    : 0x000000
              );
              rig.bodyMaterials[0].emissiveIntensity =
                (z.burnDurationMs && z.burnDurationMs > 0) ||
                (z.shockStunMs && z.shockStunMs > 0)
                  ? 0.9
                  : 0;
              rig.eyeMesh.scale.setScalar(1.0);
            }
          }
        }

        // 9. Update Barricade Visual States
        state.barricades.forEach((b) => {
          const bRig = barricadeMeshes.get(b.id);
          if (!bRig) return;
          const ratio = b.health / b.maxHealth;
          bRig.planksMesh.visible = ratio > 0.02;
          bRig.planksMesh.scale.y = Math.max(0.1, ratio);
          if (ratio > 0.5) {
            bRig.beaconMat.color.setHex(0x10b981);
            bRig.beaconMat.emissive.setHex(0x10b981);
          } else if (ratio > 0.02) {
            bRig.beaconMat.color.setHex(0xf59e0b);
            bRig.beaconMat.emissive.setHex(0xf59e0b);
          } else {
            bRig.beaconMat.color.setHex(0xef4444);
            bRig.beaconMat.emissive.setHex(0xef4444);
          }
        });

        // 10. Update Pooled Projectiles & Spatial Grid Collision Resolution
        for (let i = 0; i < MAX_PROJECTILES; i++) {
          const p = projectiles[i];
          if (!p.active) continue;
          p.ttlMs -= simDtMs;
          if (p.ttlMs <= 0) {
            p.active = false;
            continue;
          }
          p.x += p.vx * simDt;
          p.y += p.vy * simDt;

          if (Math.abs(p.x) > ARENA_BOUND + 4 || Math.abs(p.y) > ARENA_BOUND + 4) {
            p.active = false;
            continue;
          }

          const hits = spatialGrid.queryRadius(p.x, p.y, 0.35);
          for (let h = 0; h < hits.length; h++) {
            const z = hits[h];
            if (p.hitIds.has(z.id)) continue;
            p.hitIds.add(z.id);

            z.hp -= p.damage;
            z.hitFlashMs = 60;
            // Knockback impulse
            const spd = Math.hypot(p.vx, p.vy) || 1;
            z.x += (p.vx / spd) * (z.type === 'brute' ? 0.14 : 0.32);
            z.y += (p.vy / spd) * (z.type === 'brute' ? 0.14 : 0.32);

            state.stats.shotsHit++;
            // Record hit in latest telemetry event
            if (state.telemetry.length > 0) {
              const lastEv = state.telemetry[state.telemetry.length - 1];
              if (lastEv.action === 'SHOT') {
                lastEv.hitCount++;
                lastEv.damageDealt = (lastEv.damageDealt || 0) + p.damage;
              }
            }

            // Elemental Infusion Effects
            if (p.elemental === 'incendiary') {
              z.burnDurationMs = 3200;
              spawnParticles(z.x, z.y, 6, 0xf59e0b, 4.5, 0.9);
            } else if (p.elemental === 'cryo') {
              z.freezeTimerMs = 2800;
              z.isFrozen = true;
              spawnParticles(z.x, z.y, 6, 0x38bdf8, 4.5, 0.9);
            } else if (p.elemental === 'shock') {
              z.shockStunMs = 450;
              spawnParticles(z.x, z.y, 7, 0x06b6d4, 6.5, 0.95);
              // Chain lightning to 1 nearby zombie
              const chainTargets = spatialGrid.queryRadius(z.x, z.y, 3.8);
              for (const ct of chainTargets) {
                if (ct.id !== z.id && ct.koTimerMs === 0) {
                  ct.hp -= Math.round(p.damage * 0.45);
                  ct.shockStunMs = 300;
                  ct.hitFlashMs = 50;
                  pushCallout('SHOCK CHAIN!', '#06B6D4', ct.x, ct.y);
                  break;
                }
              }
            } else {
              spawnParticles(z.x, z.y, 4, 0xef4444, 5, 0.85);
            }

            p.piercingLeft--;
            if (p.piercingLeft <= 0) {
              p.active = false;
              break;
            }
          }
        }

        // 11. Update Scrap & Biomass Pickups (Magnetize toward player within 4.2m)
        for (let i = state.scrapPickups.length - 1; i >= 0; i--) {
          const sp = state.scrapPickups[i];
          sp.ttlMs -= simDtMs;
          const sMesh = scrapMeshes.get(sp.id);
          if (sp.ttlMs <= 0) {
            if (sMesh) scene.remove(sMesh);
            scrapMeshes.delete(sp.id);
            state.scrapPickups.splice(i, 1);
            continue;
          }

          const dx = state.player.x - sp.x;
          const dy = state.player.y - sp.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 4.5) {
            sp.x += (dx / (dist || 1)) * 11.5 * simDt;
            sp.y += (dy / (dist || 1)) * 11.5 * simDt;
          }
          if (sMesh) {
            sMesh.position.set(sp.x, 0.35 + Math.sin(now * 0.006 + i) * 0.1, sp.y);
            sMesh.rotation.y += dt * 2.5;
          }
          if (dist < 1.15) {
            state.player.scrap += sp.amount;
            state.stats.scrapCollectedTotal += sp.amount;
            if (sp.isBiomass) {
              state.player.biomass += 1;
            }
            soundEngine.playPickup();
            pushCallout(`+${sp.amount} SCRAP`, '#F59E0B', sp.x, sp.y);
            if (sMesh) scene.remove(sMesh);
            scrapMeshes.delete(sp.id);
            state.scrapPickups.splice(i, 1);
          }
        }

        // 12. Update Floating Callouts TTL
        for (let i = state.callouts.length - 1; i >= 0; i--) {
          state.callouts[i].ttlMs -= dtMs;
          if (state.callouts[i].ttlMs <= 0) {
            state.callouts.splice(i, 1);
          }
        }

        // 13. Damped Top-Down Tactical Camera Follow + Trauma Shake
        state.cameraTrauma = Math.max(0, state.cameraTrauma - dt * 1.6);
        const shakeScale =
          state.cameraTrauma *
          state.cameraTrauma *
          (settingsRef.current.screenShakeIntensity / 100) *
          0.95;
        const shakeX = (Math.random() - 0.5) * 2 * shakeScale;
        const shakeZ = (Math.random() - 0.5) * 2 * shakeScale;

        const targetCamX = state.player.x * 0.72 + Math.sin(state.player.aimAngle) * 2.2;
        const targetCamZ = state.player.y * 0.72 + 13.8 + Math.cos(state.player.aimAngle) * 1.4;

        camera.position.x = THREE.MathUtils.damp(camera.position.x, targetCamX, 6.5, dt) + shakeX;
        camera.position.y = THREE.MathUtils.damp(camera.position.y, 20.5, 6.5, dt);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, targetCamZ, 6.5, dt) + shakeZ;
        camera.lookAt(
          state.player.x * 0.8 + shakeX * 0.5,
          0.5,
          state.player.y * 0.8 + shakeZ * 0.5
        );
      }

      // Update InstancedMesh Matrices for Projectiles & Particles
      for (let i = 0; i < MAX_PROJECTILES; i++) {
        const p = projectiles[i];
        if (p.active) {
          _scratchPos.set(p.x, 1.08, p.y);
          _scratchQuat.identity();
          _scratchScale.setScalar(1.0);
          _scratchMatrix.compose(_scratchPos, _scratchQuat, _scratchScale);
          projInstanced.setMatrixAt(i, _scratchMatrix);
          const hex =
            p.elemental === 'shock'
              ? 0x06b6d4
              : p.elemental === 'incendiary'
                ? 0xf59e0b
                : p.elemental === 'cryo'
                  ? 0x38bdf8
                  : 0xfef08a;
          projInstanced.setColorAt(i, _scratchColor.setHex(hex));
        } else {
          _scratchPos.set(0, -50, 0);
          _scratchScale.setScalar(0.001);
          _scratchMatrix.compose(_scratchPos, _scratchQuat, _scratchScale);
          projInstanced.setMatrixAt(i, _scratchMatrix);
        }
      }
      projInstanced.instanceMatrix.needsUpdate = true;
      if (projInstanced.instanceColor) projInstanced.instanceColor.needsUpdate = true;

      for (let i = 0; i < MAX_PARTICLES; i++) {
        const pt = particles[i];
        if (pt.active) {
          pt.lifeMs -= dtMs;
          if (pt.lifeMs <= 0) {
            pt.active = false;
            _scratchPos.set(0, -50, 0);
            _scratchScale.setScalar(0.001);
            _scratchMatrix.compose(_scratchPos, _scratchQuat, _scratchScale);
            partInstanced.setMatrixAt(i, _scratchMatrix);
            continue;
          }
          pt.x += pt.vx * dt;
          pt.y = Math.max(0.05, pt.y + pt.vy * dt);
          pt.vy -= 9.8 * dt;
          pt.z += pt.vz * dt;
          const lifeRatio = Math.max(0.1, pt.lifeMs / pt.maxLifeMs);
          _scratchPos.set(pt.x, pt.y, pt.z);
          _scratchScale.setScalar(pt.scale * lifeRatio);
          _scratchMatrix.compose(_scratchPos, _scratchQuat, _scratchScale);
          partInstanced.setMatrixAt(i, _scratchMatrix);
          partInstanced.setColorAt(i, _scratchColor.setHex(pt.colorHex));
        } else {
          _scratchPos.set(0, -50, 0);
          _scratchScale.setScalar(0.001);
          _scratchMatrix.compose(_scratchPos, _scratchQuat, _scratchScale);
          partInstanced.setMatrixAt(i, _scratchMatrix);
        }
      }
      partInstanced.instanceMatrix.needsUpdate = true;
      if (partInstanced.instanceColor) partInstanced.instanceColor.needsUpdate = true;

      // Render Scene
      renderer.render(scene, camera);

      // Throttled HUD state sync (~10Hz) so React never re-renders at 60Hz
      hudSyncAccumulatorMs += dtMs;
      if (hudSyncAccumulatorMs >= 95) {
        hudSyncAccumulatorMs = 0;
        if (state.status === 'WAVE_ACTIVE' || state.status === 'WAVE_INTERMISSION') {
          syncHudNow();
        }
      }

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    function startNewGame(customSeed?: string, isDaily = true) {
      const nextSeed = customSeed || getDailyUtcSeed();
      state.seed = nextSeed;
      state.isDailyProtocol = isDaily;
      state.prng = mulberry32(hashSeedString(nextSeed));

      // Clear old zombies, pickups, floodlights, mines
      for (const [, v] of zombieVisualMap.entries()) scene.remove(v.group);
      zombieVisualMap.clear();
      state.zombies.length = 0;

      for (const [, m] of floodlightMeshes.entries()) scene.remove(m);
      floodlightMeshes.clear();
      state.floodlights.length = 0;

      for (const [, m] of mineMeshes.entries()) scene.remove(m);
      mineMeshes.clear();
      state.mines.length = 0;

      for (const [, m] of scrapMeshes.entries()) scene.remove(m);
      scrapMeshes.clear();
      state.scrapPickups.length = 0;

      state.barricades = createInitialBarricades();
      state.player.x = 0;
      state.player.y = 0;
      state.player.vx = 0;
      state.player.vy = 0;
      state.player.hp = 100;
      state.player.maxHp = 100;
      state.player.trailingHp = 100;
      state.player.armor = 50;
      state.player.scrap = 180;
      state.player.biomass = 0;
      state.player.weapons = createStarterWeapons();
      state.player.activeWeaponIndex = 0;
      state.player.floodlightCharges = 2;
      state.player.mineCharges = 2;
      state.reload.isReloading = false;
      state.reload.overchargeRemainingMs = 0;
      state.telemetry = [];
      state.stats = {
        totalKills: 0,
        killsByType: { walker: 0, sprinter: 0, spitter: 0, brute: 0, screamer: 0 },
        shotsFired: 0,
        shotsHit: 0,
        timeSurvivedMs: 0,
        scrapCollectedTotal: 180,
        score: 0,
        bestScore: Number(localStorage.getItem('outpost_zero_best') || '0'),
        causeOfDeath: '',
      };

      setForgeOpen(false);
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      startWave(1);
    }

    // Expose startNewGame on actionsRef
    (state.actionsRef as unknown as { startNewGame: typeof startNewGame }).startNewGame =
      startNewGame;

    frameId = requestAnimationFrame(tick);

    return () => {
      unmounted = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
    };
  }, [syncBodyState]);

  // Public Imperative Handlers for UI Components
  const startGame = useCallback((customSeed?: string, isDaily = true) => {
    const st = engineRef.current;
    if (!st) return;
    const fn = (
      st.actionsRef as unknown as { startNewGame?: (s?: string, d?: boolean) => void }
    ).startNewGame;
    if (fn) fn(customSeed, isDaily);
  }, []);

  const pauseGame = useCallback(() => {
    const st = engineRef.current;
    if (!st) return;
    if (st.status === 'WAVE_ACTIVE' || st.status === 'WAVE_INTERMISSION') {
      st.status = 'PAUSED';
      syncBodyState('PAUSED');
      st.actionsRef.syncHudNow();
    }
  }, [syncBodyState]);

  const resumeGame = useCallback(() => {
    const st = engineRef.current;
    if (!st) return;
    if (st.status === 'PAUSED') {
      st.status = st.intermissionTimerMs > 0 ? 'WAVE_INTERMISSION' : 'WAVE_ACTIVE';
      syncBodyState(st.status);
      st.actionsRef.syncHudNow();
    }
  }, [syncBodyState]);

  const returnToTitle = useCallback(() => {
    const st = engineRef.current;
    if (!st) return;
    st.status = 'IDLE';
    syncBodyState('IDLE');
    setForgeOpen(false);
    st.actionsRef.syncHudNow();
  }, [syncBodyState]);

  const endRunForDebrief = useCallback(() => {
    const st = engineRef.current;
    if (!st) return;
    st.stats.causeOfDeath = `Emergency Extraction on Wave ${st.currentWave}`;
    st.status = 'GAME_OVER';
    syncBodyState('GAME_OVER');
    setForgeOpen(false);
    st.actionsRef.syncHudNow();
  }, [syncBodyState]);

  const selectWeapon = useCallback((index: number) => {
    const st = engineRef.current;
    if (!st) return;
    if (index >= 0 && index < st.player.weapons.length) {
      st.player.activeWeaponIndex = index;
      st.reload.isReloading = false;
      st.actionsRef.syncHudNow();
    }
  }, []);

  const triggerReload = useCallback(() => {
    engineRef.current?.actionsRef.triggerReload();
  }, []);

  const deployFloodlight = useCallback(() => {
    engineRef.current?.actionsRef.deployFloodlight();
  }, []);

  const deployMine = useCallback(() => {
    engineRef.current?.actionsRef.deployMine();
  }, []);

  const repairBarricade = useCallback(() => {
    engineRef.current?.actionsRef.repairNearestBarricade();
  }, []);

  const skipIntermission = useCallback(() => {
    const st = engineRef.current;
    if (!st || st.status !== 'WAVE_INTERMISSION') return;
    setForgeOpen(false);
    st.actionsRef.startWave(st.currentWave + 1);
  }, []);

  const applyForgeUpgrade = useCallback((upgrade: ForgeUpgradeOption): boolean => {
    const st = engineRef.current;
    if (!st) return false;
    if (st.player.scrap < upgrade.costScrap) return false;

    st.player.scrap -= upgrade.costScrap;

    if (upgrade.targetWeaponIndex === 'all') {
      st.player.weapons = st.player.weapons.map((w) =>
        applyScrapForgeUpgradeToWeapon(w, upgrade)
      );
    } else if (typeof upgrade.targetWeaponIndex === 'number') {
      const target = st.player.weapons[upgrade.targetWeaponIndex];
      if (target) {
        st.player.weapons[upgrade.targetWeaponIndex] = applyScrapForgeUpgradeToWeapon(
          target,
          upgrade
        );
      }
    } else if (upgrade.targetWeaponIndex === 'fortification') {
      if (upgrade.fortificationAction === 'repair_barricades') {
        st.barricades.forEach((b) => {
          b.maxHealth += 60;
          b.health = b.maxHealth;
        });
      } else if (upgrade.fortificationAction === 'deploy_floodlight') {
        st.player.floodlightCharges += 2;
        st.player.mineCharges += 2;
        st.player.armor = Math.min(st.player.maxArmor, st.player.armor + 50);
      }
    }

    st.telemetry.push({
      timeMs: Math.round(st.stats.timeSurvivedMs),
      action: 'FORGE_UPGRADE',
      x: st.player.x,
      y: st.player.y,
      weaponId: upgrade.id,
      hitCount: 0,
    });

    soundEngine.playForgeUpgrade();
    st.actionsRef.syncHudNow();
    return true;
  }, []);

  const setVirtualInput = useCallback(
    (moveX: number, moveY: number, aimX: number, aimY: number, firing: boolean) => {
      const st = engineRef.current;
      if (!st) return;
      st.input.virtualMoveX = moveX;
      st.input.virtualMoveY = moveY;
      st.input.virtualAimX = aimX;
      st.input.virtualAimY = aimY;
      st.input.virtualFiring = firing;
    },
    []
  );

  const getTelemetryPayload = useCallback(
    (playerName: string): TelemetrySubmissionPayload => {
      const st = engineRef.current;
      const wpn =
        st?.player.weapons.reduce((best, cur) => (cur.tier > best.tier ? cur : best)) ||
        createStarterWeapons()[0];
      return {
        runSeed: st?.seed || initialSeed,
        playerName: playerName.trim() || 'Quarantine_Operative',
        favoriteSynergy: wpn.name,
        durationMs: Math.max(2000, Math.round(st?.stats.timeSurvivedMs || 5000)),
        wavesCleared: Math.max(1, st?.currentWave || 1),
        scrapCollected: Math.round(st?.stats.scrapCollectedTotal || 180),
        biomassHarvested: Math.round(st?.player.biomass || 0),
        finalScore: Math.round(st?.stats.score || 0),
        killsByType: st?.stats.killsByType || {
          walker: 0,
          sprinter: 0,
          spitter: 0,
          brute: 0,
          screamer: 0,
        },
        shotsFired: st?.stats.shotsFired || 0,
        shotsHit: st?.stats.shotsHit || 0,
        causeOfDeath: st?.stats.causeOfDeath || 'Overrun in Quarantine Zone',
        telemetry: st?.telemetry || [],
      };
    },
    [initialSeed]
  );

  return {
    canvasMountRef,
    hudState,
    callouts,
    forgeOpen,
    setForgeOpen,
    startGame,
    pauseGame,
    resumeGame,
    returnToTitle,
    endRunForDebrief,
    selectWeapon,
    triggerReload,
    deployFloodlight,
    deployMine,
    repairBarricade,
    skipIntermission,
    applyForgeUpgrade,
    setVirtualInput,
    getTelemetryPayload,
  };
}
