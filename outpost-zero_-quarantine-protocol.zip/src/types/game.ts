export type ZombieArchetype = 'walker' | 'sprinter' | 'spitter' | 'brute' | 'screamer';
export type ElementalType = 'none' | 'incendiary' | 'cryo' | 'shock';

export interface WeaponEntity {
  id: string;
  name: string;
  roleDesc: string;
  baseDamage: number;
  fireRateRps: number;
  clipSize: number;
  currentAmmo: number;
  reloadTimeMs: number;
  piercingCount: number;
  elemental: ElementalType;
  tier: number;
  pellets: number;
  spreadRad: number;
  projectileSpeed: number;
}

export interface ZombieEntity {
  id: string;
  type: ZombieArchetype;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  radius: number;
  isFrozen?: boolean;
  freezeTimerMs?: number;
  burnDurationMs?: number;
  shockStunMs?: number;
  hitFlashMs?: number;
  attackCooldownMs: number;
  windupTimerMs: number;
  isWindingUp: boolean;
  targetX: number;
  targetY: number;
  koTimerMs: number; // > 0 when toppling/dying
  isIlluminated: boolean;
  blindedByFloodlight: boolean;
}

export interface BarricadeEntity {
  id: string;
  label: string;
  x: number;
  y: number;
  angle: number;
  health: number;
  maxHealth: number;
}

export interface FloodlightTrapEntity {
  id: string;
  x: number;
  y: number;
  radius: number;
  batteryMs: number;
  maxBatteryMs: number;
}

export interface TripwireMineEntity {
  id: string;
  x: number;
  y: number;
  triggerRadius: number;
  blastRadius: number;
  damage: number;
  armed: boolean;
}

export interface ScrapPickupEntity {
  id: string;
  x: number;
  y: number;
  amount: number;
  isBiomass: boolean;
  ttlMs: number;
}

export interface HazardZoneEntity {
  id: string;
  x: number;
  y: number;
  radius: number;
  type: 'napalm' | 'acid' | 'cryo_field';
  dps: number;
  remainingMs: number;
}

export interface TelemetryEvent {
  timeMs: number;
  action: 'SHOT' | 'WAVE_CLEAR' | 'FORGE_UPGRADE' | 'TRAP_DEPLOY' | 'BLACKOUT_SURVIVED';
  x: number;
  y: number;
  weaponId: string;
  hitCount: number;
  damageDealt?: number;
}

export interface TelemetrySubmissionPayload {
  runSeed: string;
  playerName: string;
  favoriteSynergy: string;
  durationMs: number;
  wavesCleared: number;
  scrapCollected: number;
  biomassHarvested: number;
  finalScore: number;
  killsByType: Record<ZombieArchetype, number>;
  shotsFired: number;
  shotsHit: number;
  causeOfDeath: string;
  telemetry: TelemetryEvent[];
}

export interface TelemetryVerificationResult {
  verified: boolean;
  reason?: string;
  verificationHash: string;
  rank?: number;
  effectiveDps: number;
  accuracyPct: number;
}

export interface LeaderboardEntry {
  id: string;
  playerName: string;
  runSeed: string;
  wavesCleared: number;
  finalScore: number;
  scrapCollected: number;
  biomassHarvested: number;
  durationMs: number;
  favoriteSynergy: string;
  verifiedHash: string;
  createdAt: string;
}

export interface WaveComposition {
  waveNumber: number;
  hazardLevel: 'MODERATE' | 'ELEVATED' | 'SEVERE' | 'CRITICAL' | 'EXTINCTION';
  isBlackoutWave: boolean;
  totalHostiles: number;
  spawnIntervalMs: number;
  counts: Record<ZombieArchetype, number>;
  scrapBonus: number;
}

export interface ForgeUpgradeOption {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  costScrap: number;
  targetWeaponIndex: number | 'all' | 'fortification';
  category: 'elemental' | 'ballistics' | 'fortification';
  elementalInfusion?: ElementalType;
  damageMultiplier?: number;
  fireRateMultiplier?: number;
  piercingBonus?: number;
  clipBonus?: number;
  fortificationAction?: 'repair_barricades' | 'deploy_floodlight' | 'deploy_mine' | 'armor_plate';
}

export interface AccessibilitySettings {
  masterVolume: number;
  sfxVolume: number;
  muted: boolean;
  screenShakeIntensity: number; // 0 to 100
  autoAimAssist: boolean;
  autoFire: boolean;
  crosshairColor: '#10B981' | '#F59E0B' | '#06B6D4' | '#EF4444';
  showTouchControls: boolean;
}

export interface ZombieSurvivalGameState {
  status: 'IDLE' | 'WAVE_ACTIVE' | 'WAVE_INTERMISSION' | 'PAUSED' | 'GAME_OVER';
  seed: string;
  isDailyProtocol: boolean;
  currentWave: number;
  enemiesRemaining: number;
  totalWaveEnemies: number;
  hazardLevel: WaveComposition['hazardLevel'];
  isBlackout: boolean;
  intermissionTimerMs: number;
  reloadState: {
    isReloading: boolean;
    progress: number; // 0 to 1
    sweetSpotStart: number;
    sweetSpotEnd: number;
    activeReloadStatus: 'idle' | 'success' | 'jammed';
    overchargeRemainingMs: number;
  };
  player: {
    x: number;
    y: number;
    hp: number;
    maxHp: number;
    trailingHp: number;
    armor: number;
    maxArmor: number;
    scrap: number;
    biomass: number;
    weapons: WeaponEntity[];
    activeWeaponIndex: number;
    floodlightCharges: number;
    mineCharges: number;
  };
  barricades: BarricadeEntity[];
  floodlights: FloodlightTrapEntity[];
  mines: TripwireMineEntity[];
  stats: {
    totalKills: number;
    killsByType: Record<ZombieArchetype, number>;
    shotsFired: number;
    shotsHit: number;
    timeSurvivedMs: number;
    scrapCollectedTotal: number;
    score: number;
    bestScore: number;
    causeOfDeath: string;
  };
}
