import express, { Request, Response } from 'express';
import http from 'http';
import path from 'path';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, Type } from '@google/genai';

dotenv.config();

const port = process.env.PORT || 3000;
const app = express();
const server = http.createServer(app);

app.use(express.json());

// Initialize GoogleGenAI SDK with standard User-Agent
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export interface HostPersonalityConfig {
  id: string;
  name: string;
  title: string;
  voice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr';
  avatar: string;
  accentColor: string;
  promptDescription: string;
  catchphrases: string[];
}

// ==========================================
// 1. Trivia Questions Generation API
// ==========================================
app.post('/api/trivia/generate', async (req: Request, res: Response) => {
  try {
    const {
      category = 'General Knowledge',
      difficulty = 'Medium',
      count = 5,
      groundWithSearch = false,
      hostName = 'The Host',
      hostPersona = 'Enthusiastic and witty game show host',
    } = req.body;

    if (groundWithSearch) {
      // Use gemini-3.5-flash with googleSearch tool as specified
      const searchPrompt = `You are generating a set of ${count} verified trivia questions about "${category}" at "${difficulty}" difficulty level.
Search Google for recent, accurate, and interesting real-world facts, events, or details about ${category}.
Provide the questions in strict JSON format:
An array of objects, each with:
- "id": string unique id
- "question": the trivia question text
- "options": array of 4 distinct answer choices
- "correctAnswer": exact matching string from options
- "explanation": a concise 1-2 sentence explanation of why it is correct
- "funFact": an interesting verified tidbit about this topic
- "category": "${category}"
- "difficulty": "${difficulty}"

Ensure the trivia is factually accurate and up-to-date. Do NOT include markdown code fences if possible, just output raw JSON.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: searchPrompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      const rawText = response.text || '';
      // Clean possible markdown code fences
      const cleanJson = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
      let questions = [];
      try {
        questions = JSON.parse(cleanJson);
      } catch (parseErr) {
        // Fallback extract array
        const start = cleanJson.indexOf('[');
        const end = cleanJson.lastIndexOf(']');
        if (start !== -1 && end !== -1) {
          questions = JSON.parse(cleanJson.substring(start, end + 1));
        } else {
          throw new Error('Failed to parse search grounded questions JSON');
        }
      }

      // Extract grounding metadata chunks and search queries
      const groundingChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const webSearchQueries =
        response.candidates?.[0]?.groundingMetadata?.webSearchQueries || [];

      const sources = groundingChunks
        // @ts-ignore
        .filter((chunk) => chunk.web?.uri)
        // @ts-ignore
        .map((chunk) => ({
          title: chunk.web?.title || 'Web Source',
          uri: chunk.web?.uri || '',
        }));

      return res.json({
        questions,
        grounded: true,
        sources,
        queries: webSearchQueries,
      });
    } else {
      // Standard Generation using gemini-3.8-flash with structured JSON responseSchema
      const prompt = `Generate ${count} engaging, varied trivia questions for the category "${category}" at "${difficulty}" difficulty.
The host is ${hostName} (${hostPersona}). Write questions that fit the vibe!
Provide 4 options for each question, mark the exact correctAnswer, provide a brief explanation and a fun host-flavored fact.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                question: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'Four multiple choice options',
                },
                correctAnswer: { type: Type.STRING },
                explanation: { type: Type.STRING },
                funFact: { type: Type.STRING },
                category: { type: Type.STRING },
                difficulty: { type: Type.STRING },
              },
              required: [
                'id',
                'question',
                'options',
                'correctAnswer',
                'explanation',
                'funFact',
              ],
            },
          },
        },
      });

      const parsed = JSON.parse(response.text || '[]');
      return res.json({ questions: parsed, grounded: false, sources: [] });
    }
  } catch (error: any) {
    console.error('Error generating trivia:', error);
    res.status(500).json({
      error: 'Failed to generate trivia questions',
      details: error.message,
    });
  }
});

// ==========================================
// 2. Host Reaction & Commentary API
// ==========================================
app.post('/api/trivia/host-reaction', async (req: Request, res: Response) => {
  try {
    const {
      hostName = 'Lord Reginald',
      hostPersona = 'Sarcastic aristocrat with dry wit',
      question = '',
      selectedAnswer = '',
      correctAnswer = '',
      isCorrect = false,
      streak = 0,
      score = 0,
    } = req.body;

    const prompt = `You are ${hostName}, a trivia show host with this personality: "${hostPersona}".
The player just answered a trivia question.
Question: "${question}"
Player answered: "${selectedAnswer}"
Correct answer was: "${correctAnswer}"
Result: ${isCorrect ? 'CORRECT' : 'INCORRECT'}
Current streak: ${streak}
Current score: ${score}

Give a 1 to 2 sentence in-character reaction to the player.
Be punchy, memorable, and stay completely in character!
Also output an emotion from: 'happy', 'roast', 'shocked', 'smug', 'encouraging', 'thinking'.

Return JSON:
{
  "reaction": "your in-character spoken line",
  "emotion": "one of the emotions above"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reaction: { type: Type.STRING },
            emotion: { type: Type.STRING },
          },
          required: ['reaction', 'emotion'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error generating host reaction:', error);
    res.status(500).json({
      reaction: 'An interesting choice indeed!',
      emotion: 'thinking',
    });
  }
});

// ==========================================
// 3. Ask the Host (Lifeline Clue)
// ==========================================
app.post('/api/trivia/ask-host', async (req: Request, res: Response) => {
  try {
    const {
      hostName = 'The Host',
      hostPersona = 'Witty trivia host',
      question = '',
      options = [],
      correctAnswer = '',
    } = req.body;

    const prompt = `You are ${hostName} (${hostPersona}).
The player used their "Ask the Host" lifeline on this trivia question:
Question: "${question}"
Options: ${JSON.stringify(options)}
The real answer is: "${correctAnswer}"

Give them a witty, clever 1-2 sentence hint or clue in your character's voice.
Do NOT give away the exact answer directly; nudge them toward it (or playfully tease them) as your personality dictates.

Return JSON:
{
  "clue": "your in-character hint"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            clue: { type: Type.STRING },
          },
          required: ['clue'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error asking host:', error);
    res.status(500).json({ clue: 'Look closely at the details, my friend!' });
  }
});

// ==========================================
// 4. Search Grounding Fact-Check Deep Dive
// ==========================================
app.post('/api/trivia/fact-check', async (req: Request, res: Response) => {
  try {
    const { question, correctAnswer, topic } = req.body;

    // Use gemini-3.5-flash with googleSearch tool
    const prompt = `Perform a live Google Search fact-check on this trivia question topic:
Question: "${question}"
Answer: "${correctAnswer}"
Topic: "${topic || ''}"

Provide an interesting, verified 2-3 sentence deep dive explaining the real history, science, or context behind this fact.
Include relevant details discovered from live search.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || '';
    const groundingChunks =
      response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const webSearchQueries =
      response.candidates?.[0]?.groundingMetadata?.webSearchQueries || [];

    const sources = groundingChunks
      // @ts-ignore
      .filter((chunk) => chunk.web?.uri)
      // @ts-ignore
      .map((chunk) => ({
        title: chunk.web?.title || 'Web Source',
        uri: chunk.web?.uri || '',
      }));

    return res.json({
      explanation: text,
      sources,
      queries: webSearchQueries,
    });
  } catch (error: any) {
    console.error('Error performing fact check:', error);
    res.status(500).json({
      error: 'Failed to perform fact check',
      details: error.message,
    });
  }
});

// ==========================================
// 5. Text-To-Speech API (gemini-3.1-flash-tts-preview)
// ==========================================
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const {
      text,
      voice = 'Puck',
      emotion = 'cheerful',
      hostName = 'The Host',
    } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'Text is required for TTS' });
    }

    // Voice options: 'Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'
    const validVoices = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'];
    const chosenVoice = validVoices.includes(voice) ? voice : 'Puck';

    // Direct instruction prompt for TTS model
    const speechPrompt = `Say with ${emotion} delivery as game show host ${hostName}: ${text}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-tts-preview',
      contents: [{ parts: [{ text: speechPrompt }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: chosenVoice },
          },
        },
      },
    });

    const inlineData =
      response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
    const base64Audio = inlineData?.data;
    const mimeType = inlineData?.mimeType || 'audio/pcm;rate=24000';

    if (!base64Audio) {
      return res.status(500).json({ error: 'No audio returned from TTS model' });
    }

    return res.json({
      audio: base64Audio,
      mimeType,
      sampleRate: 24000,
    });
  } catch (error: any) {
    console.error('Error generating TTS:', error);
    res.status(500).json({
      error: 'Failed to generate speech audio',
      details: error.message,
    });
  }
});

// ==========================================
// 6. Gemini Live API WebSocket (/api/live)
// Model: gemini-3.8-live
// ==========================================
const wss = new WebSocketServer({ server, path: '/api/live' });

wss.on('connection', async (clientWs: WebSocket, req) => {
  console.log('[Live API] Client connected to live voice showdown');
  let session: any = null;

  clientWs.on('message', async (rawMsg: Buffer) => {
    try {
      const data = JSON.parse(rawMsg.toString());

      // Start session with chosen host persona and voice
      if (data.type === 'start') {
        const {
          hostName = 'Sparky',
          hostPersona = 'High energy trivia show host',
          voice = 'Puck',
        } = data;

        const validVoices = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'];
        const chosenVoice = validVoices.includes(voice) ? voice : 'Puck';

        const systemInstruction = `You are ${hostName}, the live interactive AI Host of the game show "PersonaQuiz Live".
Your personality is: ${hostPersona}.
Rules for the show:
1. Speak in a low-latency, energetic, conversational style. Keep each response concise (1-3 spoken sentences).
2. Welcome the player warmly in your persona, introduce yourself, and immediately ask your first engaging trivia question!
3. Listen to the player's spoken answer. Evaluate if they got it right or wrong, banter or tease or praise them in character, tell them their current score, and immediately present the next trivia question.
4. Have natural back-and-forth conversation, react to their doubts, take playful jabs, and keep the trivia game moving at an exhilarating game show pace!`;

        try {
          session = await ai.live.connect({
            model: 'gemini-3.8-live',
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: chosenVoice } },
              },
              systemInstruction,
            },
            callbacks: {
              onmessage: (message: any) => {
                const audio =
                  message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                if (audio && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ type: 'audio', audio }));
                }
                if (
                  message.serverContent?.interrupted &&
                  clientWs.readyState === WebSocket.OPEN
                ) {
                  clientWs.send(JSON.stringify({ type: 'interrupted' }));
                }
              },
              onclose: () => {
                if (clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ type: 'session_closed' }));
                }
              },
              onerror: (err: any) => {
                console.error('[Live API Session Error]:', err);
                if (clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(
                    JSON.stringify({
                      type: 'error',
                      message: err.message || 'Live API error',
                    })
                  );
                }
              },
            },
          });

          clientWs.send(JSON.stringify({ type: 'ready' }));
        } catch (connErr: any) {
          console.error('[Live API Connect Error]:', connErr);
          clientWs.send(
            JSON.stringify({
              type: 'error',
              message: connErr.message || 'Failed to connect to Live API',
            })
          );
        }
        return;
      }

      // Stream mic audio to Live API session
      if (data.type === 'audio' && data.audio && session) {
        session.sendRealtimeInput({
          audio: { data: data.audio, mimeType: 'audio/pcm;rate=16000' },
        });
      }

      // Send text message (for user text fallback or cue)
      if (data.type === 'text' && data.text && session) {
        session.sendRealtimeInput({
          text: data.text,
        });
      }

      // Stop session
      if (data.type === 'stop' && session) {
        try {
          session.close();
        } catch (_) {}
        session = null;
      }
    } catch (e: any) {
      console.error('[Live API Message Parse Error]:', e);
    }
  });

  clientWs.on('close', () => {
    console.log('[Live API] Client disconnected');
    if (session) {
      try {
        session.close();
      } catch (_) {}
    }
  });
});

// ==========================================
// Vite Middleware & Static Serving Setup
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });
}

startServer();
