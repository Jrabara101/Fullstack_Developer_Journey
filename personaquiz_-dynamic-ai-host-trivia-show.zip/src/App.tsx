import React, { useState } from 'react';
import {
  HostPersonality,
  Question,
  GroundingSource,
  GameMode,
} from './types';
import { DEFAULT_PERSONALITIES, FALLBACK_QUESTIONS } from './data/personalities';
import { Navbar } from './components/Navbar';
import { Lobby } from './components/Lobby';
import { TriviaArena } from './components/TriviaArena';
import { LiveVoiceArena } from './components/LiveVoiceArena';
import { HostSelector } from './components/HostSelector';
import { RoundSummary } from './components/RoundSummary';
import { CustomHostModal } from './components/CustomHostModal';

export default function App() {
  const [hostsList, setHostsList] = useState<HostPersonality[]>(DEFAULT_PERSONALITIES);
  const [activeHost, setActiveHost] = useState<HostPersonality>(DEFAULT_PERSONALITIES[0]);
  const [currentMode, setCurrentMode] = useState<GameMode>('showdown');
  const [viewState, setViewState] = useState<'lobby' | 'playing' | 'summary' | 'host-select'>('lobby');

  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentCategory, setCurrentCategory] = useState('Pop Culture & 2025/2026 Trends');
  const [isGroundedWithSearch, setIsGroundedWithSearch] = useState(true);
  const [groundingSources, setGroundingSources] = useState<GroundingSource[]>([]);
  const [isLoadingQuestions, setIsLoadingQuestions] = useState(false);

  // Audio settings
  const [audioMuted, setAudioMuted] = useState(false);

  // Round summary stats
  const [finalScore, setFinalScore] = useState(0);
  const [accuracy, setAccuracy] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);

  // Custom Host Modal
  const [isCustomHostModalOpen, setIsCustomHostModalOpen] = useState(false);

  // Start standard or search grounded trivia showdown
  const handleStartGame = async (
    category: string,
    difficulty: 'Easy' | 'Medium' | 'Hard',
    count: number,
    groundWithSearch: boolean
  ) => {
    setIsLoadingQuestions(true);
    setCurrentCategory(category);
    setIsGroundedWithSearch(groundWithSearch);

    try {
      const res = await fetch('/api/trivia/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category,
          difficulty,
          count,
          groundWithSearch,
          hostName: activeHost.name,
          hostPersona: activeHost.personalityPrompt,
        }),
      });

      if (!res.ok) throw new Error('Failed to generate trivia');
      const data = await res.json();

      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
        setGroundingSources(data.sources || []);
      } else {
        throw new Error('Empty question list');
      }
    } catch (err) {
      console.warn('Using fallback questions due to error:', err);
      const fallback =
        FALLBACK_QUESTIONS[category] || FALLBACK_QUESTIONS['General Knowledge'];
      setQuestions(fallback);
      setGroundingSources([]);
    } finally {
      setIsLoadingQuestions(false);
      setViewState('playing');
    }
  };

  // Launch Search Grounded News & Trends Sprint
  const handleStartSearchSprint = () => {
    setCurrentMode('search-sprint');
    handleStartGame(
      'Pop Culture & 2025/2026 Trends',
      'Medium',
      5,
      true // forces gemini-3.5-flash with googleSearch
    );
  };

  const handleSelectMode = (mode: GameMode) => {
    setCurrentMode(mode);
    if (mode === 'live-voice') {
      setViewState('playing');
    } else if (mode === 'search-sprint') {
      handleStartSearchSprint();
    } else {
      setViewState('lobby');
    }
  };

  const handleRoundComplete = (score: number, acc: number, streak: number) => {
    setFinalScore(score);
    setAccuracy(acc);
    setMaxStreak(streak);
    setViewState('summary');
  };

  const handleSaveCustomHost = (newHost: HostPersonality) => {
    setHostsList((prev) => [newHost, ...prev]);
    setActiveHost(newHost);
    setViewState('lobby');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Navbar */}
      <Navbar
        currentMode={currentMode}
        onSelectMode={handleSelectMode}
        activeHost={activeHost}
        onOpenHostSelector={() => setViewState('host-select')}
        audioMuted={audioMuted}
        onToggleMute={() => setAudioMuted(!audioMuted)}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6 md:py-8 flex flex-col items-center justify-center">
        {/* View 1: Host Selection Screen */}
        {viewState === 'host-select' && (
          <div className="w-full space-y-4">
            <div className="flex justify-start">
              <button
                onClick={() => setViewState('lobby')}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 transition"
              >
                ← Back to Lobby
              </button>
            </div>
            <HostSelector
              hosts={hostsList}
              selectedHost={activeHost}
              onSelectHost={(host) => {
                setActiveHost(host);
                setViewState('lobby');
              }}
              onOpenCustomHostModal={() => setIsCustomHostModalOpen(true)}
            />
          </div>
        )}

        {/* View 2: Live Voice Showdown (Gemini Live API gemini-3.8-live) */}
        {currentMode === 'live-voice' && viewState === 'playing' && (
          <LiveVoiceArena
            host={activeHost}
            onExit={() => {
              setCurrentMode('showdown');
              setViewState('lobby');
            }}
          />
        )}

        {/* View 3: Standard / Search Grounded Trivia Arena */}
        {currentMode !== 'live-voice' && viewState === 'playing' && (
          <TriviaArena
            host={activeHost}
            questions={questions}
            category={currentCategory}
            isGroundedWithSearch={isGroundedWithSearch}
            groundingSources={groundingSources}
            audioMuted={audioMuted}
            onToggleMute={() => setAudioMuted(!audioMuted)}
            onRoundComplete={handleRoundComplete}
            onRestartRound={() =>
              handleStartGame(currentCategory, 'Medium', 5, isGroundedWithSearch)
            }
          />
        )}

        {/* View 4: Round Summary Scoreboard */}
        {viewState === 'summary' && (
          <RoundSummary
            host={activeHost}
            finalScore={finalScore}
            accuracy={accuracy}
            maxStreak={maxStreak}
            onPlayAgain={() =>
              handleStartGame(currentCategory, 'Medium', 5, isGroundedWithSearch)
            }
            onChangeHost={() => setViewState('host-select')}
            audioMuted={audioMuted}
          />
        )}

        {/* View 5: Lobby Screen */}
        {viewState === 'lobby' && (
          <Lobby
            host={activeHost}
            onStartGame={handleStartGame}
            onStartLiveVoice={() => {
              setCurrentMode('live-voice');
              setViewState('playing');
            }}
            onChangeHost={() => setViewState('host-select')}
            isLoading={isLoadingQuestions}
            audioMuted={audioMuted}
            onToggleMute={() => setAudioMuted(!audioMuted)}
          />
        )}
      </main>

      {/* Custom Host Studio Modal */}
      <CustomHostModal
        isOpen={isCustomHostModalOpen}
        onClose={() => setIsCustomHostModalOpen(false)}
        onSaveHost={handleSaveCustomHost}
      />

      {/* App Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <p>
          PersonaQuiz &bull; Powered by Google Gemini AI &bull; Live Voice (gemini-3.8-live) &bull; Search Grounding (gemini-3.5-flash) &bull; Speech (gemini-3.1-flash-tts-preview)
        </p>
      </footer>
    </div>
  );
}
