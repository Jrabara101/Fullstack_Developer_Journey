import React, { useState } from 'react';
import { HostPersonality, VoiceOption } from '../types';
import { X, Sparkles, Wand2, Volume2, Loader2, Check } from 'lucide-react';
import { playPcmBase64 } from '../utils/audioFx';

interface CustomHostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveHost: (newHost: HostPersonality) => void;
}

const EMOJI_OPTIONS = ['🎭', '🧙‍♂️', '🤖', '👑', '👽', '🤠', '🧛', '🦊', '🚀', '🔥', '🕶️', '⚡'];
const VOICE_OPTIONS: Array<{ id: VoiceOption; name: string; desc: string }> = [
  { id: 'Puck', name: 'Puck', desc: 'Energetic, playful & upbeat' },
  { id: 'Charon', name: 'Charon', desc: 'Deep, mysterious & resonant' },
  { id: 'Kore', name: 'Kore', desc: 'Warm, clear & expressive' },
  { id: 'Fenrir', name: 'Fenrir', desc: 'Authoritative, sharp & intense' },
  { id: 'Zephyr', name: 'Zephyr', desc: 'Calm, soothing & mindful' },
];

export const CustomHostModal: React.FC<CustomHostModalProps> = ({
  isOpen,
  onClose,
  onSaveHost,
}) => {
  const [name, setName] = useState('');
  const [title, setTitle] = useState('');
  const [avatarIcon, setAvatarIcon] = useState('🎭');
  const [voice, setVoice] = useState<VoiceOption>('Puck');
  const [personalityDesc, setPersonalityDesc] = useState('');
  const [greetingLine, setGreetingLine] = useState('');
  const [catchphrase, setCatchphrase] = useState('');
  const [snarkLevel, setSnarkLevel] = useState(50); // 0 (Friendly) to 100 (Ultra Roast)
  const [paceLevel, setPaceLevel] = useState(60); // 0 (Chill) to 100 (Hyper Speed)
  const [isTestingVoice, setIsTestingVoice] = useState(false);

  if (!isOpen) return null;

  const handleTestVoice = async () => {
    if (isTestingVoice) return;
    setIsTestingVoice(true);
    try {
      const lineToSay =
        greetingLine.trim() ||
        `Greetings contestant, I am ${name || 'your custom host'}! Prepare for the ultimate trivia challenge!`;

      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: lineToSay,
          voice,
          hostName: name || 'Custom Host',
          emotion: snarkLevel > 60 ? 'sarcastic' : 'cheerful',
        }),
      });

      if (!res.ok) throw new Error('TTS failed');
      const data = await res.json();
      if (data.audio) {
        await playPcmBase64(data.audio);
      }
    } catch (e) {
      console.error('Test voice error:', e);
    } finally {
      setIsTestingVoice(false);
    }
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const traitLabels: string[] = [];
    if (snarkLevel > 65) traitLabels.push('Sarcastic', 'Spicy');
    else if (snarkLevel < 35) traitLabels.push('Encouraging', 'Wholesome');
    else traitLabels.push('Witty');

    if (paceLevel > 70) traitLabels.push('High Energy');
    else if (paceLevel < 40) traitLabels.push('Philosophical');
    else traitLabels.push('Sharp');

    const newHost: HostPersonality = {
      id: `custom-${Date.now()}`,
      name: name.trim(),
      title: title.trim() || 'Custom Trivia Master',
      tagline: `Snark ${snarkLevel}% • Pace ${paceLevel}% • Powered by Gemini AI`,
      avatarIcon,
      avatarBg: 'bg-gradient-to-br from-indigo-900 to-purple-950 text-indigo-200 border-indigo-500/50',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
      voice,
      personalityPrompt: `You are ${name}. ${title ? `Your title is "${title}". ` : ''}${personalityDesc.trim() || 'You are an eccentric, memorable trivia host.'} Snark level: ${snarkLevel}/100. Energy and pacing level: ${paceLevel}/100. Catchphrase: "${catchphrase}".`,
      greetingLine:
        greetingLine.trim() ||
        `Welcome to the arena! I am ${name}, and today we test your mettle!`,
      correctReactions: [
        `Splendid answer! Exactly as I expected!`,
        `Bullseye! You nailed that one!`,
      ],
      wrongReactions: [
        snarkLevel > 50
          ? `Alas, that answer was a catastrophic blunder!`
          : `Not quite, but shake it off and let's conquer the next one!`,
      ],
      catchphrases: [catchphrase || 'Knowledge is power!'],
      traits: traitLabels,
      isCustom: true,
    };

    onSaveHost(newHost);
    onClose();
  };

  const applyPreset = (preset: 'pirate' | 'chef' | 'alien' | 'goth') => {
    if (preset === 'pirate') {
      setName('Captain Barnaby Flint');
      setTitle('The High-Seas Trivia Corsair');
      setAvatarIcon('🏴‍☠️');
      setVoice('Charon');
      setPersonalityDesc('A salty 18th-century pirate captain who bets doubloons on trivia and threatens to make players walk the plank when they answer poorly.');
      setGreetingLine('Ahoy, ye landlubbers! Prepare to surrender yer wits or walk the plank!');
      setCatchphrase('Shiver me timbers and lock in yer answer!');
      setSnarkLevel(75);
      setPaceLevel(80);
    } else if (preset === 'chef') {
      setName('Chef Marcello Sizzle');
      setTitle('The Fiery Gourmet Critic');
      setAvatarIcon('👨‍🍳');
      setVoice('Fenrir');
      setPersonalityDesc('An intense, perfectionist Michelin-starred chef who judges trivia answers like raw risotto and undercooked souffles.');
      setGreetingLine('The kitchen is OPEN! Do not serve me bland excuses today!');
      setCatchphrase('IT’S RAW! Your logic is underseasoned!');
      setSnarkLevel(85);
      setPaceLevel(90);
    } else if (preset === 'alien') {
      setName('Commander Xylar-9');
      setTitle('Galactic Ambassador from Nebula-7');
      setAvatarIcon('👽');
      setVoice('Zephyr');
      setPersonalityDesc('An intergalactic researcher studying human trivia habits to decide if Earth is worthy of admission to the Galactic Federation.');
      setGreetingLine('Earthlings! I transmit across lightyears to examine your primitive cognitive storage.');
      setCatchphrase('Fascinating terrestrial hypothesis.');
      setSnarkLevel(40);
      setPaceLevel(50);
    } else if (preset === 'goth') {
      setName('Ravenna Grim');
      setTitle('Mistress of Shadows & Lore');
      setAvatarIcon('🧛');
      setVoice('Kore');
      setPersonalityDesc('A dramatic gothic Victorian philosopher who views trivia as existential poetry and dark comedic absurdity.');
      setGreetingLine('Step into the twilight where only the curious dare wander.');
      setCatchphrase('The abyss smiles upon your intellect.');
      setSnarkLevel(60);
      setPaceLevel(40);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 md:p-8 text-white my-8 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 transition"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <Wand2 size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tight">AI Host Creator Studio</h2>
            <p className="text-xs text-slate-400">
              Craft a custom AI Host personality with dynamic voice, attitude, and dialogue styles.
            </p>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="my-4 p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
          <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
            <Sparkles size={14} className="text-amber-400" />
            <span>Need inspiration? Try a fun one-click archetype:</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => applyPreset('pirate')}
              className="px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/70 hover:bg-amber-600/30 hover:border-amber-500/40 border border-slate-700 text-slate-200 transition"
            >
              🏴‍☠️ Pirate Captain
            </button>
            <button
              type="button"
              onClick={() => applyPreset('chef')}
              className="px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/70 hover:bg-rose-600/30 hover:border-rose-500/40 border border-slate-700 text-slate-200 transition"
            >
              👨‍🍳 Fiery Chef
            </button>
            <button
              type="button"
              onClick={() => applyPreset('alien')}
              className="px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/70 hover:bg-cyan-600/30 hover:border-cyan-500/40 border border-slate-700 text-slate-200 transition"
            >
              👽 Alien Envoy
            </button>
            <button
              type="button"
              onClick={() => applyPreset('goth')}
              className="px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/70 hover:bg-purple-600/30 hover:border-purple-500/40 border border-slate-700 text-slate-200 transition"
            >
              🧛 Gothic Lorekeeper
            </button>
          </div>
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Host Name */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Host Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Professor Klaus, Madame Mystique..."
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
              />
            </div>

            {/* Avatar Icon */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Avatar Emoji
              </label>
              <div className="flex items-center gap-2">
                <div className="w-11 h-11 flex items-center justify-center text-2xl rounded-xl bg-slate-950 border border-slate-700">
                  {avatarIcon}
                </div>
                <div className="flex-1 flex flex-wrap gap-1">
                  {EMOJI_OPTIONS.slice(0, 6).map((em) => (
                    <button
                      key={em}
                      type="button"
                      onClick={() => setAvatarIcon(em)}
                      className={`w-7 h-7 rounded-lg text-sm flex items-center justify-center transition ${
                        avatarIcon === em
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {em}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Title / Role */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Title or Honorific
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., The Interdimensional Game Master"
              className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
            />
          </div>

          {/* Voice Selection */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                Gemini Host Voice
              </label>
              <span className="text-[11px] text-indigo-400 font-mono">
                Model: gemini-3.1-flash-tts-preview
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {VOICE_OPTIONS.map((v) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => setVoice(v.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    voice === v.id
                      ? 'bg-indigo-600/30 border-indigo-500 text-white ring-1 ring-indigo-500'
                      : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs text-white flex items-center justify-between">
                    <span>{v.name}</span>
                    {voice === v.id && <Check size={12} className="text-indigo-400" />}
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{v.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Personality & Lore Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Host Personality Lore & Behavioral Tone
            </label>
            <textarea
              rows={2}
              value={personalityDesc}
              onChange={(e) => setPersonalityDesc(e.target.value)}
              placeholder="Describe their quirks, manner of speaking, jokes, how they treat the player..."
              className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
            />
          </div>

          {/* Sliders: Snark & Energy */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 rounded-2xl bg-slate-950/50 border border-slate-800">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-300">Roast / Snark Level</span>
                <span className="font-mono text-indigo-400">{snarkLevel}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={snarkLevel}
                onChange={(e) => setSnarkLevel(Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                <span>Sweet & Supportive</span>
                <span>Mild Sarcasm</span>
                <span>Ruthless Burns</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-300">Energy & Hype Level</span>
                <span className="font-mono text-indigo-400">{paceLevel}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={paceLevel}
                onChange={(e) => setPaceLevel(Number(e.target.value))}
                className="w-full accent-indigo-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                <span>Zen & Serene</span>
                <span>Classic Host</span>
                <span>Pure Adrenaline</span>
              </div>
            </div>
          </div>

          {/* Greeting & Catchphrase */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Intro Greeting
              </label>
              <input
                type="text"
                value={greetingLine}
                onChange={(e) => setGreetingLine(e.target.value)}
                placeholder="What they say when round begins..."
                className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Signature Catchphrase
              </label>
              <input
                type="text"
                value={catchphrase}
                onChange={(e) => setCatchphrase(e.target.value)}
                placeholder="Their trademark line..."
                className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
              />
            </div>
          </div>

          {/* Test Voice & Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={handleTestVoice}
              disabled={isTestingVoice}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-indigo-500/40 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 font-semibold text-xs flex items-center justify-center gap-2 transition"
            >
              {isTestingVoice ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  <span>Synthesizing Sample...</span>
                </>
              ) : (
                <>
                  <Volume2 size={16} />
                  <span>Test Voice Sample (TTS)</span>
                </>
              )}
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!name.trim()}
                className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold text-xs shadow-lg shadow-indigo-500/25 transition disabled:opacity-50"
              >
                Activate AI Host
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
