import React from 'react';
import { HostPersonality, HostEmotion } from '../types';
import { Volume2, VolumeX, Sparkles, MessageSquare, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HostAvatarProps {
  host: HostPersonality;
  emotion?: HostEmotion;
  dialogue?: string;
  isSpeaking?: boolean;
  isLoadingAudio?: boolean;
  onPlaySpeech?: () => void;
  onStopSpeech?: () => void;
  audioMuted?: boolean;
  onToggleMute?: () => void;
  compact?: boolean;
}

export const HostAvatar: React.FC<HostAvatarProps> = ({
  host,
  emotion = 'neutral',
  dialogue,
  isSpeaking = false,
  isLoadingAudio = false,
  onPlaySpeech,
  onStopSpeech,
  audioMuted = false,
  onToggleMute,
  compact = false,
}) => {
  // Emotion indicator styling
  const emotionConfig = {
    neutral: { label: 'Neutral', bg: 'bg-slate-700/60 text-slate-300' },
    happy: { label: 'Pleased', bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
    roast: { label: 'Roasting', bg: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
    shocked: { label: 'Stunned', bg: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
    smug: { label: 'Smug', bg: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
    encouraging: { label: 'Cheering', bg: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
    thinking: { label: 'Pondering', bg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' },
  }[emotion] || { label: 'Neutral', bg: 'bg-slate-700/60 text-slate-300' };

  if (compact) {
    return (
      <div className="flex items-center gap-3">
        <div className={`relative flex items-center justify-center w-11 h-11 rounded-2xl border ${host.avatarBg} text-2xl shadow-lg`}>
          <span>{host.avatarIcon}</span>
          {isSpeaking && (
            <span className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
            </span>
          )}
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-white text-sm">{host.name}</span>
            <span className={`text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full border ${emotionConfig.bg}`}>
              {emotionConfig.label}
            </span>
          </div>
          <p className="text-xs text-slate-400 line-clamp-1">{host.title}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full rounded-2xl bg-slate-900/80 border border-slate-800/80 p-5 shadow-2xl backdrop-blur-xl">
      <div className="flex flex-col md:flex-row items-start md:items-center gap-5">
        {/* Avatar visual badge with speaking pulses */}
        <div className="relative group shrink-0">
          <motion.div
            animate={
              isSpeaking
                ? {
                    scale: [1, 1.05, 1],
                    boxShadow: [
                      '0 0 0px rgba(99, 102, 241, 0)',
                      '0 0 25px rgba(99, 102, 241, 0.5)',
                      '0 0 0px rgba(99, 102, 241, 0)',
                    ],
                  }
                : {}
            }
            transition={{ repeat: Infinity, duration: 1.4 }}
            className={`flex items-center justify-center w-20 h-20 md:w-24 md:h-24 rounded-3xl border-2 ${host.avatarBg} text-4xl md:text-5xl shadow-2xl relative overflow-hidden`}
          >
            <span>{host.avatarIcon}</span>

            {/* Speaking audio wave overlay */}
            {isSpeaking && (
              <div className="absolute inset-x-0 bottom-0 py-1 bg-black/40 backdrop-blur-xs flex items-center justify-center gap-1">
                {[4, 12, 18, 10, 16, 8, 14].map((h, i) => (
                  <motion.div
                    key={i}
                    animate={{ height: [4, h, 4] }}
                    transition={{
                      repeat: Infinity,
                      duration: 0.6 + i * 0.1,
                      ease: 'easeInOut',
                    }}
                    className="w-1 bg-emerald-400 rounded-full"
                  />
                ))}
              </div>
            )}
          </motion.div>

          {/* Voice model pill */}
          <div className="absolute -bottom-2 -right-1">
            <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 shadow">
              {host.voice} Voice
            </span>
          </div>
        </div>

        {/* Host Info & Speech Bubble */}
        <div className="flex-1 w-full min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg md:text-xl font-black text-white tracking-tight">
                  {host.name}
                </h3>
                <span className={`text-[11px] font-semibold tracking-wide uppercase px-2.5 py-0.5 rounded-full border ${emotionConfig.bg}`}>
                  {emotionConfig.label}
                </span>
                {host.isCustom && (
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    Custom Host
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 font-medium">{host.title}</p>
            </div>

            {/* Audio controls */}
            <div className="flex items-center gap-2">
              {onToggleMute && (
                <button
                  onClick={onToggleMute}
                  title={audioMuted ? 'Unmute host voice' : 'Mute host voice'}
                  className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all ${
                    audioMuted
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/30 hover:bg-rose-500/30'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  {audioMuted ? (
                    <>
                      <VolumeX size={15} />
                      <span className="hidden sm:inline">Voice Muted</span>
                    </>
                  ) : (
                    <>
                      <Volume2 size={15} />
                      <span className="hidden sm:inline">Voice Active</span>
                    </>
                  )}
                </button>
              )}

              {dialogue && onPlaySpeech && !audioMuted && (
                <button
                  onClick={isSpeaking ? onStopSpeech : onPlaySpeech}
                  disabled={isLoadingAudio}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                    isSpeaking
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                      : 'bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border-indigo-500/40'
                  }`}
                >
                  {isLoadingAudio ? (
                    <>
                      <Loader2 size={14} className="animate-spin" />
                      <span>Synthesizing...</span>
                    </>
                  ) : isSpeaking ? (
                    <>
                      <Volume2 size={14} />
                      <span>Speaking... (Click to stop)</span>
                    </>
                  ) : (
                    <>
                      <Volume2 size={14} />
                      <span>Replay Voice (TTS)</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Dialogue bubble */}
          <AnimatePresence mode="wait">
            <motion.div
              key={dialogue || host.greetingLine}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="relative p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-slate-200 text-sm md:text-base leading-relaxed"
            >
              <div className="flex items-start gap-2.5">
                <MessageSquare size={16} className="text-indigo-400 mt-1 shrink-0" />
                <p className="italic text-slate-200 font-medium">
                  &ldquo;{dialogue || host.greetingLine}&rdquo;
                </p>
              </div>

              {/* Trait tags */}
              <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] text-slate-400 font-semibold mr-1">Vibe:</span>
                {host.traits.map((t, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-slate-800/80 text-slate-300 border border-slate-700/50"
                  >
                    #{t}
                  </span>
                ))}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
