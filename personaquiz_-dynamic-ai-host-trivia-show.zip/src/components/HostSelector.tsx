import React, { useState } from 'react';
import { HostPersonality } from '../types';
import { Volume2, Wand2, Check, Sparkles, Loader2 } from 'lucide-react';
import { playPcmBase64 } from '../utils/audioFx';

interface HostSelectorProps {
  hosts: HostPersonality[];
  selectedHost: HostPersonality;
  onSelectHost: (host: HostPersonality) => void;
  onOpenCustomHostModal: () => void;
}

export const HostSelector: React.FC<HostSelectorProps> = ({
  hosts,
  selectedHost,
  onSelectHost,
  onOpenCustomHostModal,
}) => {
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);

  const handlePreviewVoice = async (e: React.MouseEvent, host: HostPersonality) => {
    e.stopPropagation();
    if (playingVoiceId) return;

    setPlayingVoiceId(host.id);
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: host.greetingLine,
          voice: host.voice,
          hostName: host.name,
          emotion: 'cheerful',
        }),
      });

      if (!res.ok) throw new Error('Voice preview failed');
      const data = await res.json();
      if (data.audio) {
        await playPcmBase64(data.audio);
      }
    } catch (err) {
      console.error('Preview voice error:', err);
    } finally {
      setPlayingVoiceId(null);
    }
  };

  return (
    <div className="w-full">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <span>Choose Your AI Trivia Host</span>
            <Sparkles size={20} className="text-amber-400" />
          </h2>
          <p className="text-xs md:text-sm text-slate-400">
            Each host brings a distinctive personality, voice cadence, burns, and reaction style.
          </p>
        </div>

        <button
          onClick={onOpenCustomHostModal}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/20 transition-all hover:scale-[1.02]"
        >
          <Wand2 size={15} />
          <span>+ Create Custom Host</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {hosts.map((host) => {
          const isSelected = selectedHost.id === host.id;
          const isPreviewing = playingVoiceId === host.id;

          return (
            <div
              key={host.id}
              onClick={() => onSelectHost(host)}
              className={`relative cursor-pointer rounded-2xl p-5 border transition-all duration-200 flex flex-col justify-between ${
                isSelected
                  ? 'bg-slate-900/90 border-indigo-500 ring-2 ring-indigo-500/50 shadow-xl shadow-indigo-500/10 scale-[1.01]'
                  : 'bg-slate-900/50 hover:bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Selected checkmark */}
              {isSelected && (
                <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow">
                  <Check size={14} strokeWidth={3} />
                </div>
              )}

              <div>
                <div className="flex items-center gap-3.5 mb-3">
                  <div
                    className={`w-14 h-14 rounded-2xl border flex items-center justify-center text-3xl shadow-md ${host.avatarBg}`}
                  >
                    <span>{host.avatarIcon}</span>
                  </div>
                  <div className="min-w-0 pr-8">
                    <h3 className="font-black text-white text-base leading-tight truncate">
                      {host.name}
                    </h3>
                    <p className="text-xs text-indigo-400 font-medium truncate mt-0.5">
                      {host.title}
                    </p>
                    <span className="inline-block mt-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      Voice: {host.voice}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 italic mb-3.5 leading-relaxed bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60">
                  &ldquo;{host.tagline}&rdquo;
                </p>

                {/* Traits */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {host.traits.map((t, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-800/90 text-slate-300 border border-slate-700/60"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom controls */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={(e) => handlePreviewVoice(e, host)}
                  disabled={isPreviewing}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition"
                >
                  {isPreviewing ? (
                    <>
                      <Loader2 size={13} className="animate-spin text-indigo-400" />
                      <span className="text-[11px]">Playing Sample...</span>
                    </>
                  ) : (
                    <>
                      <Volume2 size={13} />
                      <span className="text-[11px]">Preview Voice</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => onSelectHost(host)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    isSelected
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {isSelected ? 'Selected' : 'Select Host'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
