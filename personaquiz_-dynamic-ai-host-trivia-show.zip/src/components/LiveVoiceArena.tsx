import React, { useState, useEffect, useRef } from 'react';
import { HostPersonality } from '../types';
import { LiveAudioSession } from '../utils/liveClient';
import {
  Mic,
  MicOff,
  PhoneOff,
  Radio,
  Volume2,
  Sparkles,
  AlertCircle,
  Loader2,
  Send,
  MessageSquare,
} from 'lucide-react';
import { motion } from 'motion/react';

interface LiveVoiceArenaProps {
  host: HostPersonality;
  onExit: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'host' | 'user';
  text: string;
}

export const LiveVoiceArena: React.FC<LiveVoiceArenaProps> = ({ host, onExit }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [userVolume, setUserVolume] = useState(0);
  const [hostVolume, setHostVolume] = useState(0);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [textInput, setTextInput] = useState('');

  const sessionRef = useRef<LiveAudioSession | null>(null);

  useEffect(() => {
    // Initialize Live API Session
    const session = new LiveAudioSession({
      onReady: () => {
        setIsConnected(true);
        setIsConnecting(false);
        setErrorMessage(null);
        setMessages((prev) => [
          ...prev,
          {
            id: 'init-1',
            sender: 'host',
            text: `Connected to ${host.name} via Gemini 3.8 Live API! Speak into your microphone to start the trivia conversation.`,
          },
        ]);
      },
      onInterrupted: () => {
        setHostVolume(0);
      },
      onError: (err) => {
        setErrorMessage(err);
        setIsConnecting(false);
      },
      onClose: () => {
        setIsConnected(false);
      },
      onVolumeChange: (uVol, hVol) => {
        setUserVolume(uVol);
        setHostVolume(hVol);
      },
    });

    sessionRef.current = session;
    session.start(host.name, host.personalityPrompt, host.voice);

    return () => {
      session.cleanup();
      sessionRef.current = null;
    };
  }, [host]);

  const toggleMute = () => {
    if (sessionRef.current) {
      const nextMuted = !isMuted;
      setIsMuted(nextMuted);
      sessionRef.current.setMute(nextMuted);
    }
  };

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim() || !sessionRef.current) return;

    sessionRef.current.sendTextMessage(textInput.trim());
    setMessages((prev) => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        sender: 'user',
        text: textInput.trim(),
      },
    ]);
    setTextInput('');
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Live Status Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <span className="flex h-3 w-3">
              <span
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  isConnected ? 'bg-emerald-400' : 'bg-amber-400'
                }`}
              />
              <span
                className={`relative inline-flex rounded-full h-3 w-3 ${
                  isConnected ? 'bg-emerald-500' : 'bg-amber-500'
                }`}
              />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                <Radio size={16} className="text-emerald-400 animate-pulse" />
                <span>Live Voice Showdown</span>
              </h3>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-emerald-300 border border-emerald-500/30">
                gemini-3.8-live
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Bi-directional real-time audio conversation with {host.name}
            </p>
          </div>
        </div>

        <button
          onClick={onExit}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
        >
          <PhoneOff size={15} className="text-rose-400" />
          <span>Exit Live Show</span>
        </button>
      </div>

      {/* Error state if permission or connection issue */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3 text-rose-300 text-xs">
          <AlertCircle size={18} className="shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">Connection or Microphone Notice</p>
            <p className="mt-1">{errorMessage}</p>
            <p className="mt-2 text-slate-400">
              Tip: Allow microphone access in your browser or use the text prompt input below to converse directly.
            </p>
          </div>
        </div>
      )}

      {/* Visual Live Arena Stage */}
      <div className="relative rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-8 shadow-2xl overflow-hidden flex flex-col items-center justify-center min-h-[380px]">
        {/* Glow ambient background circles */}
        <div className="absolute -top-24 -left-24 w-80 h-80 rounded-full bg-indigo-600/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-80 h-80 rounded-full bg-purple-600/10 blur-3xl pointer-events-none" />

        {isConnecting ? (
          <div className="flex flex-col items-center justify-center text-center py-12">
            <Loader2 size={40} className="animate-spin text-indigo-400 mb-4" />
            <h4 className="text-lg font-bold text-white">
              Connecting with {host.name}...
            </h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm">
              Establishing a low-latency live audio stream with model <code className="text-indigo-300 font-mono">gemini-3.8-live</code>.
            </p>
          </div>
        ) : (
          <div className="w-full flex flex-col items-center">
            {/* Animated Visualizer Halo for Host */}
            <div className="relative flex items-center justify-center my-6">
              {/* Ripple concentric rings for Host speech */}
              <motion.div
                animate={{
                  scale: 1 + hostVolume * 0.8,
                  opacity: 0.15 + hostVolume * 0.6,
                }}
                transition={{ duration: 0.1 }}
                className="absolute w-44 h-44 rounded-full border-2 border-indigo-400/40 bg-indigo-500/10"
              />
              <motion.div
                animate={{
                  scale: 1 + hostVolume * 1.5,
                  opacity: 0.1 + hostVolume * 0.4,
                }}
                transition={{ duration: 0.15 }}
                className="absolute w-56 h-56 rounded-full border border-purple-400/30"
              />

              {/* Host Avatar Core */}
              <div
                className={`relative z-10 w-28 h-28 rounded-3xl border-2 flex items-center justify-center text-6xl shadow-2xl ${host.avatarBg}`}
              >
                <span>{host.avatarIcon}</span>
                {hostVolume > 0.05 && (
                  <span className="absolute -bottom-2 px-2.5 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-bold tracking-wide uppercase shadow">
                    Host Speaking
                  </span>
                )}
              </div>
            </div>

            {/* Host Name & Live Status */}
            <div className="text-center mt-2 mb-6">
              <h3 className="text-xl font-black text-white">{host.name}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{host.title}</p>
            </div>

            {/* Mic Meter & Controls */}
            <div className="w-full max-w-md p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col items-center gap-3">
              {/* User Voice Waveform Meter */}
              <div className="w-full flex items-center justify-between text-xs text-slate-400 px-2">
                <span className="flex items-center gap-1.5 font-semibold">
                  <Mic size={14} className={userVolume > 0.05 ? 'text-emerald-400' : 'text-slate-500'} />
                  <span>Your Microphone</span>
                </span>
                <span className="font-mono text-[11px]">
                  {isMuted
                    ? 'MUTED'
                    : userVolume > 0.05
                    ? 'DETECTING VOICE'
                    : 'LISTENING...'}
                </span>
              </div>

              {/* Voice Volume Level Bar */}
              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden relative">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-indigo-500 transition-all duration-75 rounded-full"
                  style={{ width: `${isMuted ? 0 : Math.min(100, userVolume * 100)}%` }}
                />
              </div>

              {/* Control Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={toggleMute}
                  className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
                    isMuted
                      ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30'
                  }`}
                >
                  {isMuted ? (
                    <>
                      <MicOff size={16} />
                      <span>Unmute Mic</span>
                    </>
                  ) : (
                    <>
                      <Mic size={16} />
                      <span>Microphone Active</span>
                    </>
                  )}
                </button>

                <div className="text-[11px] text-slate-400">
                  <span>Speak naturally into your mic; interrupt the host anytime!</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Text Message Fallback / Conversation Logs */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare size={16} className="text-indigo-400" />
            <h4 className="text-sm font-bold text-white">Live Session Logs</h4>
          </div>
          <span className="text-[11px] text-slate-400">
            Real-time audio sync active
          </span>
        </div>

        {/* Message Log */}
        <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`p-3 rounded-xl text-xs leading-relaxed ${
                m.sender === 'host'
                  ? 'bg-slate-950/70 text-slate-200 border border-slate-800'
                  : 'bg-indigo-950/50 text-indigo-200 border border-indigo-500/30 ml-8'
              }`}
            >
              <span className="font-bold block mb-1 text-[11px] uppercase tracking-wider text-slate-400">
                {m.sender === 'host' ? host.name : 'You'}
              </span>
              <p>{m.text}</p>
            </div>
          ))}
        </div>

        {/* Text prompt fallback form */}
        <form onSubmit={handleSendText} className="flex gap-2 pt-2 border-t border-slate-800">
          <input
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            placeholder="Type an answer or message to the host..."
            className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500"
          />
          <button
            type="submit"
            disabled={!textInput.trim() || !isConnected}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition disabled:opacity-40"
          >
            <Send size={14} />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
