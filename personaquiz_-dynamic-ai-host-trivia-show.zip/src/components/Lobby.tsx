import React, { useState } from 'react';
import { HostPersonality, GameMode } from '../types';
import { TRIVIA_CATEGORIES } from '../data/personalities';
import {
  Play,
  Radio,
  Search,
  Sparkles,
  Zap,
  Globe,
  Sliders,
  Flame,
  Award,
  BookOpen,
} from 'lucide-react';
import { HostAvatar } from './HostAvatar';

interface LobbyProps {
  host: HostPersonality;
  onStartGame: (
    category: string,
    difficulty: 'Easy' | 'Medium' | 'Hard',
    count: number,
    groundWithSearch: boolean
  ) => void;
  onStartLiveVoice: () => void;
  onChangeHost: () => void;
  isLoading: boolean;
  audioMuted: boolean;
  onToggleMute: () => void;
}

export const Lobby: React.FC<LobbyProps> = ({
  host,
  onStartGame,
  onStartLiveVoice,
  onChangeHost,
  isLoading,
  audioMuted,
  onToggleMute,
}) => {
  const [selectedCategory, setSelectedCategory] = useState(
    'Pop Culture & 2025/2026 Trends'
  );
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [questionCount, setQuestionCount] = useState(5);
  const [groundWithSearch, setGroundWithSearch] = useState(true);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Host Greeting Showcase */}
      <HostAvatar
        host={host}
        emotion="happy"
        dialogue={host.greetingLine}
        audioMuted={audioMuted}
        onToggleMute={onToggleMute}
      />

      {/* Hero Quick Launch / Mode Highlight */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Live Voice Showdown Promo */}
        <div
          onClick={onStartLiveVoice}
          className="relative group cursor-pointer overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-950 border border-emerald-500/30 p-6 shadow-xl hover:border-emerald-500/60 transition-all hover:scale-[1.01]"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              <Radio size={24} className="animate-pulse" />
            </div>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase">
              gemini-3.8-live
            </span>
          </div>

          <h3 className="text-xl font-black text-white group-hover:text-emerald-300 transition">
            Live Voice Showdown
          </h3>
          <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
            Put on your microphone and engage in a real-time, low-latency voice quiz with {host.name}! Speak naturally, interrupt anytime, and hear instant responses.
          </p>

          <div className="mt-4 flex items-center gap-2 text-xs font-bold text-emerald-400">
            <span>Launch Voice Mode</span>
            <span>→</span>
          </div>
        </div>

        {/* Live Search Grounding Highlights */}
        <div
          onClick={() => setGroundWithSearch(!groundWithSearch)}
          className={`cursor-pointer rounded-3xl border p-6 transition-all shadow-xl ${
            groundWithSearch
              ? 'bg-gradient-to-br from-blue-950/80 via-slate-900 to-slate-950 border-blue-500/50'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-2xl bg-blue-500/20 text-blue-300 border border-blue-500/30">
              <Globe size={24} />
            </div>
            <span
              className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border uppercase ${
                groundWithSearch
                  ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              gemini-3.5-flash
            </span>
          </div>

          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black text-white">Google Search Grounding</h3>
            <input
              type="checkbox"
              checked={groundWithSearch}
              onChange={(e) => setGroundWithSearch(e.target.checked)}
              className="w-5 h-5 accent-blue-500 rounded cursor-pointer"
            />
          </div>
          <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
            Grounds trivia questions against live Google Search data for cutting-edge events, verified answers, and real web source citations!
          </p>

          <div className="mt-4 flex items-center gap-2 text-xs font-semibold text-blue-400">
            <span>{groundWithSearch ? '✓ Search Grounding Enabled' : 'Click to Enable'}</span>
          </div>
        </div>
      </div>

      {/* Game Config: Category & Difficulty */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 md:p-8 shadow-2xl space-y-6">
        <div>
          <h3 className="text-lg font-black text-white tracking-tight flex items-center gap-2 mb-1">
            <BookOpen size={18} className="text-indigo-400" />
            <span>Select Trivia Category</span>
          </h3>
          <p className="text-xs text-slate-400">
            Choose a subject or let the AI host surprise you.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 mt-4">
            {TRIVIA_CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`p-3.5 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                    isSelected
                      ? 'bg-indigo-600/30 border-indigo-500 ring-2 ring-indigo-500/40 text-white font-bold'
                      : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-white bg-gradient-to-br ${cat.color} shrink-0 shadow`}
                  >
                    <Sparkles size={16} />
                  </div>
                  <span className="text-xs md:text-sm font-semibold truncate">
                    {cat.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Difficulty & Length Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
          {/* Difficulty */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Difficulty
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Easy', 'Medium', 'Hard'] as const).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setDifficulty(lvl)}
                  className={`py-2 rounded-xl text-xs font-bold border transition ${
                    difficulty === lvl
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Number of Questions */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Rounds / Questions
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[5, 8, 10].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setQuestionCount(num)}
                  className={`py-2 rounded-xl text-xs font-bold border transition ${
                    questionCount === num
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {num} Questions
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Start Game Action */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-800">
          <button
            type="button"
            onClick={onChangeHost}
            className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition"
          >
            Change AI Host ({host.name})
          </button>

          <button
            type="button"
            disabled={isLoading}
            onClick={() =>
              onStartGame(selectedCategory, difficulty, questionCount, groundWithSearch)
            }
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 hover:from-indigo-600 hover:to-pink-600 text-white font-black text-sm flex items-center justify-center gap-2.5 shadow-xl shadow-indigo-500/25 transition-all hover:scale-[1.02] disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Preparing Trivia Arena...</span>
              </>
            ) : (
              <>
                <Play size={18} fill="currentColor" />
                <span>Start Trivia Showdown</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
