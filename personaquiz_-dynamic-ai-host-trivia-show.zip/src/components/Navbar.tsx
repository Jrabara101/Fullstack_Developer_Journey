import React from 'react';
import { GameMode, HostPersonality } from '../types';
import { Sparkles, Radio, Search, Volume2, VolumeX, Flame } from 'lucide-react';

interface NavbarProps {
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  activeHost: HostPersonality;
  onOpenHostSelector: () => void;
  audioMuted: boolean;
  onToggleMute: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentMode,
  onSelectMode,
  activeHost,
  onOpenHostSelector,
  audioMuted,
  onToggleMute,
}) => {
  return (
    <header className="w-full border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Brand / Logo */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25 text-lg font-black">
            ⚡
          </div>
          <div>
            <h1 className="text-base font-black tracking-tight text-white flex items-center gap-1.5">
              <span>PersonaQuiz</span>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                AI Host
              </span>
            </h1>
            <p className="text-[10px] text-slate-400 font-medium hidden sm:block">
              Dynamic AI Personalities • Live Voice • Search Grounding
            </p>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold">
          <button
            onClick={() => onSelectMode('showdown')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              currentMode === 'showdown'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles size={13} />
            <span>Trivia Show</span>
          </button>

          <button
            onClick={() => onSelectMode('live-voice')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              currentMode === 'live-voice'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Radio size={13} className={currentMode === 'live-voice' ? 'animate-pulse' : ''} />
            <span>Live Voice (Live API)</span>
          </button>

          <button
            onClick={() => onSelectMode('search-sprint')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              currentMode === 'search-sprint'
                ? 'bg-blue-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Search size={13} />
            <span>Search Grounded</span>
          </button>
        </div>

        {/* Right side: Host Quick Pill & Sound Toggle */}
        <div className="flex items-center gap-2">
          {/* Active Host Pill */}
          <button
            onClick={onOpenHostSelector}
            title="Click to switch or customize host personality"
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-850 border border-slate-700/80 text-xs transition"
          >
            <span className="text-base">{activeHost.avatarIcon}</span>
            <div className="text-left hidden md:block">
              <span className="text-[10px] text-slate-400 block leading-tight">Host:</span>
              <span className="font-bold text-white leading-tight block truncate max-w-[110px]">
                {activeHost.name}
              </span>
            </div>
            <span className="text-[10px] text-indigo-400 font-bold ml-0.5">Switch</span>
          </button>

          {/* Sound Mute Toggle */}
          <button
            onClick={onToggleMute}
            title={audioMuted ? 'Unmute game audio & voices' : 'Mute all game audio'}
            className={`p-2 rounded-xl border text-xs transition ${
              audioMuted
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850'
            }`}
          >
            {audioMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
        </div>
      </div>
    </header>
  );
};
