import React, { useEffect, useState } from 'react';
import { HostPersonality } from '../types';
import { Award, Trophy, RotateCcw, Users, Flame, Volume2, Sparkles, Loader2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { playFanfareSound, playPcmBase64 } from '../utils/audioFx';

interface RoundSummaryProps {
  host: HostPersonality;
  finalScore: number;
  accuracy: number;
  maxStreak: number;
  onPlayAgain: () => void;
  onChangeHost: () => void;
  audioMuted: boolean;
}

export const RoundSummary: React.FC<RoundSummaryProps> = ({
  host,
  finalScore,
  accuracy,
  maxStreak,
  onPlayAgain,
  onChangeHost,
  audioMuted,
}) => {
  const [verdict, setVerdict] = useState<string>('');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [audioBase64, setAudioBase64] = useState<string | null>(null);

  useEffect(() => {
    // Confetti celebration if score > 0
    if (finalScore > 0) {
      playFanfareSound();
      confetti({
        particleCount: 120,
        spread: 70,
        origin: { y: 0.6 },
      });
    }

    // Determine personality verdict line
    let verdictText = '';
    if (accuracy >= 80) {
      verdictText =
        host.id === 'lord-reginald'
          ? "Good heavens, an actual display of intellectual prowess! I am grudgingly astonished by your acumen."
          : host.id === 'sparky-martinez'
          ? "KABOOM! You absolute superstar! That performance deserves a permanent spot in the Hall of Fame!"
          : host.id === 'master-zephyr'
          ? "The river of your insight flowed deep and true. You have walked the path of illumination today."
          : `Extraordinary performance, contestant! You scored ${finalScore} points with dazzling accuracy!`;
    } else if (accuracy >= 50) {
      verdictText =
        host.id === 'lord-reginald'
          ? "Decidedly pedestrian. A patchwork of lucky guesses and agonizing stumbles, but not entirely hopeless."
          : host.id === 'sparky-martinez'
          ? "Not too shabby! You got the wheels spinning, but next time let's kick it into overdrive!"
          : host.id === 'jack-malone'
          ? "You pieced together half the case, kid. But the real mastermind got away. Sharpen up for the next stakeout."
          : `A respectable finish! With a bit more practice, the grand championship is yours.`;
    } else {
      verdictText =
        host.id === 'lord-reginald'
          ? "An unmitigated catastrophe. I shall require an aspirin and a brisk constitutional to recover from this ordeal."
          : host.id === 'sparky-martinez'
          ? "Ouch town, population: you! But hey, every legendary champion takes a bump on the road! Dust off and reboot!"
          : host.id === 'glitch-9000'
          ? "ERROR 404: COMPETENCE CORRUPTED. Biological data dump completed. Recommend defragmenting your brain."
          : `A tough round! Dust yourself off and give it another spin!`;
    }

    setVerdict(verdictText);

    // Auto-generate TTS verdict if not muted
    if (!audioMuted) {
      setIsLoadingAudio(true);
      fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: verdictText,
          voice: host.voice,
          hostName: host.name,
          emotion: accuracy >= 70 ? 'cheerful' : 'sarcastic',
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.audio) {
            setAudioBase64(data.audio);
            setIsPlayingAudio(true);
            playPcmBase64(data.audio).finally(() => setIsPlayingAudio(false));
          }
        })
        .catch((err) => console.warn('TTS verdict error:', err))
        .finally(() => setIsLoadingAudio(false));
    }
  }, []);

  const handleReplayVerdict = async () => {
    if (audioBase64) {
      setIsPlayingAudio(true);
      await playPcmBase64(audioBase64);
      setIsPlayingAudio(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto rounded-3xl bg-slate-900 border border-slate-800 p-8 shadow-2xl text-center space-y-6">
      {/* Trophy Header */}
      <div className="flex flex-col items-center">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-white shadow-xl shadow-amber-500/20 mb-3">
          <Trophy size={42} strokeWidth={2.2} />
        </div>
        <h2 className="text-3xl font-black text-white tracking-tight">Round Completed!</h2>
        <p className="text-xs text-slate-400 mt-1">Here is how you stacked up against {host.name}</p>
      </div>

      {/* Host Final Verdict Dialogue */}
      <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 text-left">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{host.avatarIcon}</span>
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              {host.name}&rsquo;s Verdict
            </span>
          </div>

          {audioBase64 && (
            <button
              onClick={handleReplayVerdict}
              disabled={isPlayingAudio}
              className="px-2.5 py-1 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Volume2 size={13} />
              <span>{isPlayingAudio ? 'Speaking...' : 'Replay Verdict'}</span>
            </button>
          )}
        </div>

        <p className="text-sm md:text-base text-slate-200 italic font-medium leading-relaxed">
          &ldquo;{verdict}&rdquo;
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            Final Score
          </p>
          <p className="text-2xl md:text-3xl font-black text-amber-400">{finalScore}</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            Accuracy
          </p>
          <p className="text-2xl md:text-3xl font-black text-emerald-400">{accuracy}%</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            Best Streak
          </p>
          <p className="text-2xl md:text-3xl font-black text-rose-400 flex items-center justify-center gap-1">
            <Flame size={20} />
            <span>{maxStreak}</span>
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
        <button
          onClick={onChangeHost}
          className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition"
        >
          <Users size={16} />
          <span>Change AI Host</span>
        </button>

        <button
          onClick={onPlayAgain}
          className="w-full sm:w-auto px-7 py-3 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-indigo-500/25 transition hover:scale-[1.02]"
        >
          <RotateCcw size={16} />
          <span>Play Another Round</span>
        </button>
      </div>
    </div>
  );
};
