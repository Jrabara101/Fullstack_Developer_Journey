import React from 'react';
import { X, ExternalLink, Search, CheckCircle2, Globe, Sparkles } from 'lucide-react';
import { GroundingSource } from '../types';

interface SearchGroundingDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  questionText: string;
  correctAnswer: string;
  explanation: string;
  sources: GroundingSource[];
  searchQueries?: string[];
  isLoading?: boolean;
}

export const SearchGroundingDrawer: React.FC<SearchGroundingDrawerProps> = ({
  isOpen,
  onClose,
  questionText,
  correctAnswer,
  explanation,
  sources,
  searchQueries = [],
  isLoading = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-xl rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 md:p-8 text-white my-8 max-h-[85vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 transition"
        >
          <X size={20} />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
            <Search size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-black tracking-tight">Google Search Fact-Check</h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                Grounding Active
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Powered by gemini-3.5-flash with Google Search Grounding
            </p>
          </div>
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="py-12 flex flex-col items-center justify-center text-center">
            <div className="w-12 h-12 rounded-full border-4 border-blue-500/30 border-t-blue-500 animate-spin mb-4" />
            <p className="text-sm font-semibold text-slate-200">
              Querying live Google Search data...
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Verifying real-world records, sources, and latest updates
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Question Summary */}
            <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Question
              </span>
              <p className="text-sm font-semibold text-white mt-1 leading-snug">
                {questionText}
              </p>
              <div className="mt-2 flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400" />
                <span className="text-xs text-slate-300">Verified Answer:</span>
                <span className="text-xs font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-md border border-emerald-500/30">
                  {correctAnswer}
                </span>
              </div>
            </div>

            {/* Explanation Deep Dive */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-blue-950/40 border border-blue-500/30">
              <div className="flex items-center gap-2 mb-2 text-xs font-bold uppercase tracking-wider text-blue-300">
                <Sparkles size={14} />
                <span>Verified Historical & Contextual Detail</span>
              </div>
              <p className="text-sm text-slate-200 leading-relaxed font-normal whitespace-pre-wrap">
                {explanation || 'Fact check data retrieved successfully.'}
              </p>
            </div>

            {/* Search Queries Used */}
            {searchQueries.length > 0 && (
              <div className="p-3 rounded-2xl bg-slate-950/40 border border-slate-800">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                  Search Queries Executed
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {searchQueries.map((q, idx) => (
                    <span
                      key={idx}
                      className="text-xs font-mono px-2.5 py-1 rounded-lg bg-slate-800 text-blue-300 border border-slate-700/60 flex items-center gap-1"
                    >
                      <Search size={11} />
                      {q}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Grounding Source Links */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Globe size={14} className="text-blue-400" />
                  <span>Grounding Web Sources ({sources.length})</span>
                </span>
                <span className="text-[10px] text-slate-500">Live Web Citations</span>
              </div>

              {sources.length === 0 ? (
                <p className="text-xs text-slate-500 italic p-3 rounded-xl bg-slate-950/40 border border-slate-800">
                  Google Search grounding confirmed facts against live knowledge graph.
                </p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {sources.map((src, i) => (
                    <a
                      key={i}
                      href={src.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800 hover:border-blue-500/40 transition group"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-200 group-hover:text-blue-300 transition truncate">
                          {src.title || 'Source Citation'}
                        </p>
                        <p className="text-[10px] text-slate-500 font-mono truncate">
                          {src.uri}
                        </p>
                      </div>
                      <ExternalLink
                        size={14}
                        className="text-slate-500 group-hover:text-blue-400 shrink-0 transition"
                      />
                    </a>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={onClose}
              className="w-full mt-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition"
            >
              Close Fact-Check
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
