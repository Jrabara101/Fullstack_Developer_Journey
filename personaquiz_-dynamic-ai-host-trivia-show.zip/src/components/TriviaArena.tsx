import React, { useState, useEffect, useRef } from 'react';
import { HostPersonality, Question, GroundingSource, HostEmotion } from '../types';
import { HostAvatar } from './HostAvatar';
import {
  Sparkles,
  HelpCircle,
  Scissors,
  Search,
  Timer,
  Flame,
  Award,
  ArrowRight,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Lightbulb,
} from 'lucide-react';
import {
  playCorrectSound,
  playWrongSound,
  playTickSound,
  playLifelineSound,
  playPcmBase64,
  stopCurrentSpeech,
} from '../utils/audioFx';
import { SearchGroundingDrawer } from './SearchGroundingDrawer';

interface TriviaArenaProps {
  host: HostPersonality;
  questions: Question[];
  category: string;
  isGroundedWithSearch: boolean;
  groundingSources?: GroundingSource[];
  audioMuted: boolean;
  onToggleMute: () => void;
  onRoundComplete: (finalScore: number, accuracy: number, maxStreak: number) => void;
  onRestartRound: () => void;
}

export const TriviaArena: React.FC<TriviaArenaProps> = ({
  host,
  questions,
  category,
  isGroundedWithSearch,
  groundingSources = [],
  audioMuted,
  onToggleMute,
  onRoundComplete,
  onRestartRound,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  // Lifelines
  const [usedFiftyFifty, setUsedFiftyFifty] = useState(false);
  const [usedAskHost, setUsedAskHost] = useState(false);
  const [usedFactCheck, setUsedFactCheck] = useState(false);
  const [eliminatedOptions, setEliminatedOptions] = useState<string[]>([]);

  // Host dialogue & TTS audio state
  const [hostDialogue, setHostDialogue] = useState(host.greetingLine);
  const [hostEmotion, setHostEmotion] = useState<HostEmotion>('neutral');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [currentAudioBase64, setCurrentAudioBase64] = useState<string | null>(null);

  // Search Grounding Drawer
  const [isFactCheckOpen, setIsFactCheckOpen] = useState(false);
  const [factCheckData, setFactCheckData] = useState<{
    explanation: string;
    sources: GroundingSource[];
    queries: string[];
    isLoading: boolean;
  }>({
    explanation: '',
    sources: [],
    queries: [],
    isLoading: false,
  });

  // Timer
  const [timeLeft, setTimeLeft] = useState(25);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const currentQ = questions[currentIndex] || questions[0];

  // Helper to play TTS
  const triggerTts = async (text: string, emotion = 'cheerful') => {
    if (audioMuted) return;
    try {
      setIsLoadingAudio(true);
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voice: host.voice,
          hostName: host.name,
          emotion,
        }),
      });

      if (!res.ok) throw new Error('TTS fetch error');
      const data = await res.json();
      if (data.audio) {
        setCurrentAudioBase64(data.audio);
        setIsSpeaking(true);
        await playPcmBase64(data.audio);
      }
    } catch (err) {
      console.warn('TTS playback error:', err);
    } finally {
      setIsLoadingAudio(false);
      setIsSpeaking(false);
    }
  };

  // Start question and timer
  useEffect(() => {
    setTimeLeft(25);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setIsCorrect(null);
    setEliminatedOptions([]);

    // Question announcement dialogue
    const qIntro = `Question ${currentIndex + 1}: ${currentQ.question}`;
    setHostDialogue(qIntro);
    setHostEmotion('thinking');

    // Trigger TTS for question reading if enabled
    triggerTts(qIntro, 'cheerful');

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          handleTimeExpired();
          return 0;
        }
        if (prev <= 5) {
          playTickSound(true);
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      stopCurrentSpeech();
    };
  }, [currentIndex]);

  const handleTimeExpired = () => {
    if (isAnswered) return;
    setIsAnswered(true);
    setIsCorrect(false);
    setStreak(0);
    playWrongSound();

    const timeOutLine = "Time's up! The clock shows no mercy, and neither do I!";
    setHostDialogue(timeOutLine);
    setHostEmotion('roast');
    triggerTts(timeOutLine, 'sarcastic');
  };

  const handleSelectOption = async (option: string) => {
    if (isAnswered) return;
    if (timerRef.current) clearInterval(timerRef.current);

    setSelectedAnswer(option);
    setIsAnswered(true);

    const correct = option === currentQ.correctAnswer;
    setIsCorrect(correct);

    if (correct) {
      playCorrectSound();
      const points = 100 + streak * 25 + Math.floor(timeLeft * 2);
      const newStreak = streak + 1;
      setScore((prev) => prev + points);
      setStreak(newStreak);
      if (newStreak > maxStreak) setMaxStreak(newStreak);
    } else {
      playWrongSound();
      setStreak(0);
    }

    // Request AI Host reaction from backend
    try {
      const res = await fetch('/api/trivia/host-reaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hostName: host.name,
          hostPersona: host.personalityPrompt,
          question: currentQ.question,
          selectedAnswer: option,
          correctAnswer: currentQ.correctAnswer,
          isCorrect: correct,
          streak: correct ? streak + 1 : 0,
          score,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setHostDialogue(data.reaction);
        setHostEmotion((data.emotion as HostEmotion) || (correct ? 'happy' : 'roast'));
        triggerTts(data.reaction, correct ? 'cheerful' : 'sarcastic');
      } else {
        // Fallback reaction
        const fallbackList = correct ? host.correctReactions : host.wrongReactions;
        const fallbackLine = fallbackList[Math.floor(Math.random() * fallbackList.length)];
        setHostDialogue(fallbackLine);
        setHostEmotion(correct ? 'happy' : 'roast');
        triggerTts(fallbackLine);
      }
    } catch (e) {
      console.warn('Reaction error:', e);
    }
  };

  // 1. Lifeline: 50/50
  const handleFiftyFifty = () => {
    if (usedFiftyFifty || isAnswered) return;
    setUsedFiftyFifty(true);
    playLifelineSound();

    const wrongOptions = currentQ.options.filter((o) => o !== currentQ.correctAnswer);
    // Shuffle and pick 2 to eliminate
    const toEliminate = wrongOptions.sort(() => 0.5 - Math.random()).slice(0, 2);
    setEliminatedOptions(toEliminate);

    const line = "50/50 deployed! Two bogus options vaporized into thin air.";
    setHostDialogue(line);
    setHostEmotion('smug');
    triggerTts(line);
  };

  // 2. Lifeline: Ask the Host
  const handleAskHost = async () => {
    if (usedAskHost || isAnswered) return;
    setUsedAskHost(true);
    playLifelineSound();

    setHostDialogue("Consulting my superior cognitive faculties for a hint...");
    setHostEmotion('thinking');

    try {
      const res = await fetch('/api/trivia/ask-host', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hostName: host.name,
          hostPersona: host.personalityPrompt,
          question: currentQ.question,
          options: currentQ.options,
          correctAnswer: currentQ.correctAnswer,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setHostDialogue(`💡 Host Hint: "${data.clue}"`);
        setHostEmotion('encouraging');
        triggerTts(data.clue, 'cheerful');
      } else {
        setHostDialogue("💡 Hint: Think about which option sounds most historically plausible!");
      }
    } catch (e) {
      setHostDialogue("💡 Hint: Trust your first instinct, contestant!");
    }
  };

  // 3. Lifeline: Google Search Fact-Check
  const handleFactCheck = async () => {
    if (isFactCheckOpen) return;
    playLifelineSound();
    setUsedFactCheck(true);

    setIsFactCheckOpen(true);
    setFactCheckData((prev) => ({ ...prev, isLoading: true }));

    try {
      const res = await fetch('/api/trivia/fact-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: currentQ.question,
          correctAnswer: currentQ.correctAnswer,
          topic: category,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setFactCheckData({
          explanation: data.explanation || currentQ.explanation,
          sources: data.sources || groundingSources || [],
          queries: data.queries || [],
          isLoading: false,
        });
      } else {
        setFactCheckData({
          explanation: currentQ.explanation,
          sources: groundingSources || [],
          queries: [currentQ.question],
          isLoading: false,
        });
      }
    } catch (e) {
      setFactCheckData({
        explanation: currentQ.explanation,
        sources: groundingSources || [],
        queries: [currentQ.question],
        isLoading: false,
      });
    }
  };

  const handleNext = () => {
    stopCurrentSpeech();
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Completed round
      const accuracy = Math.round(
        ((score > 0 ? currentIndex + 1 : 0) / questions.length) * 100
      );
      onRoundComplete(score, accuracy, maxStreak);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Search Grounding Banner if mode active */}
      {isGroundedWithSearch && (
        <div className="px-4 py-2.5 rounded-2xl bg-blue-950/60 border border-blue-500/30 flex items-center justify-between text-xs text-blue-300">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 rounded-full bg-blue-400 animate-pulse" />
            <span className="font-semibold">Live Google Search Grounding Active</span>
            <span className="hidden sm:inline text-blue-400/80">
              — Questions verified against real-time web knowledge (gemini-3.5-flash)
            </span>
          </div>
          <button
            onClick={handleFactCheck}
            className="px-2.5 py-1 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-200 border border-blue-500/40 font-bold transition flex items-center gap-1"
          >
            <Search size={12} />
            <span>View Sources</span>
          </button>
        </div>
      )}

      {/* Host Avatar & Speech Card */}
      <HostAvatar
        host={host}
        emotion={hostEmotion}
        dialogue={hostDialogue}
        isSpeaking={isSpeaking}
        isLoadingAudio={isLoadingAudio}
        audioMuted={audioMuted}
        onToggleMute={onToggleMute}
        onPlaySpeech={() => {
          if (currentAudioBase64) {
            setIsSpeaking(true);
            playPcmBase64(currentAudioBase64).finally(() => setIsSpeaking(false));
          } else {
            triggerTts(hostDialogue);
          }
        }}
        onStopSpeech={stopCurrentSpeech}
      />

      {/* Game Bar: Score, Streak, Timer */}
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
        {/* Score */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
            <Award size={20} />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-400">Score</p>
            <p className="text-xl font-black text-white tracking-tight">{score}</p>
          </div>
        </div>

        {/* Streak */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400">
            <Flame size={20} />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-400">Streak</p>
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-black text-white tracking-tight">{streak}</span>
              {streak >= 2 && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300">
                  {streak >= 3 ? '3x' : '2x'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Timer */}
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <div
            className={`p-2 rounded-xl transition ${
              timeLeft <= 5
                ? 'bg-rose-500/30 text-rose-400 animate-pulse'
                : 'bg-indigo-500/20 text-indigo-400'
            }`}
          >
            <Timer size={20} />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-400">Timer</p>
            <p
              className={`text-xl font-black tracking-tight ${
                timeLeft <= 5 ? 'text-rose-400' : 'text-white'
              }`}
            >
              {timeLeft}s
            </p>
          </div>
        </div>

        {/* Round Progress */}
        <div className="hidden sm:flex p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 items-center justify-between">
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-400">Question</p>
            <p className="text-xl font-black text-white">
              {currentIndex + 1}
              <span className="text-sm font-normal text-slate-400">/{questions.length}</span>
            </p>
          </div>
          <span className="text-xs font-semibold px-2 py-1 rounded-lg bg-slate-800 text-slate-300">
            {currentQ.difficulty}
          </span>
        </div>
      </div>

      {/* Main Question Card */}
      <div className="relative rounded-3xl bg-slate-900 border border-slate-800 p-6 md:p-8 shadow-2xl">
        {/* Category tag & Lifelines bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
            {currentQ.category || category}
          </span>

          {/* Lifelines */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-slate-400 mr-1 hidden sm:inline">
              Lifelines:
            </span>

            {/* 50/50 */}
            <button
              onClick={handleFiftyFifty}
              disabled={usedFiftyFifty || isAnswered}
              title="50/50: Eliminate 2 wrong choices"
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition ${
                usedFiftyFifty
                  ? 'opacity-40 bg-slate-950 border-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700 hover:border-indigo-500/50'
              }`}
            >
              <Scissors size={13} />
              <span>50/50</span>
            </button>

            {/* Ask the Host */}
            <button
              onClick={handleAskHost}
              disabled={usedAskHost || isAnswered}
              title="Ask the Host for an in-character hint"
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition ${
                usedAskHost
                  ? 'opacity-40 bg-slate-950 border-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border-slate-700 hover:border-amber-500/50'
              }`}
            >
              <Lightbulb size={13} />
              <span>Ask Host</span>
            </button>

            {/* Google Search Fact Check */}
            <button
              onClick={handleFactCheck}
              title="Fact-check verified search grounding details"
              className="px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border bg-blue-950/60 hover:bg-blue-900/60 text-blue-300 border-blue-500/40 transition"
            >
              <Search size={13} />
              <span>Search Fact-Check</span>
            </button>
          </div>
        </div>

        {/* Question Text */}
        <h2 className="text-xl md:text-2xl font-black text-white tracking-tight leading-snug mb-8">
          {currentQ.question}
        </h2>

        {/* Multiple Choice Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {currentQ.options.map((opt, i) => {
            const letter = ['A', 'B', 'C', 'D'][i];
            const isEliminated = eliminatedOptions.includes(opt);
            const isSelected = selectedAnswer === opt;
            const isThisCorrect = opt === currentQ.correctAnswer;

            let buttonStyles =
              'bg-slate-950/80 hover:bg-slate-800/80 border-slate-800 hover:border-indigo-500/60 text-slate-200';

            if (isEliminated) {
              buttonStyles =
                'opacity-20 line-through bg-slate-950 border-slate-900 text-slate-600 pointer-events-none';
            } else if (isAnswered) {
              if (isThisCorrect) {
                buttonStyles =
                  'bg-emerald-950/70 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500/50 font-bold';
              } else if (isSelected) {
                buttonStyles =
                  'bg-rose-950/70 border-rose-500 text-rose-200 ring-2 ring-rose-500/50';
              } else {
                buttonStyles = 'opacity-40 bg-slate-950 border-slate-800 text-slate-500';
              }
            }

            return (
              <button
                key={i}
                disabled={isAnswered || isEliminated}
                onClick={() => handleSelectOption(opt)}
                className={`w-full p-4 rounded-2xl border text-left flex items-center gap-3.5 transition-all duration-150 ${buttonStyles}`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm shrink-0 border ${
                    isAnswered && isThisCorrect
                      ? 'bg-emerald-500 text-white border-emerald-400'
                      : isAnswered && isSelected
                      ? 'bg-rose-500 text-white border-rose-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  {letter}
                </div>
                <span className="text-sm md:text-base font-semibold flex-1">
                  {opt}
                </span>

                {isAnswered && isThisCorrect && (
                  <CheckCircle2 size={20} className="text-emerald-400 shrink-0" />
                )}
                {isAnswered && isSelected && !isThisCorrect && (
                  <XCircle size={20} className="text-rose-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Answer Explanation & Fact Detail (Shown after answering) */}
        {isAnswered && (
          <div className="mt-6 p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2 animate-fadeIn">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <HelpCircle size={14} className="text-indigo-400" />
                <span>The Explanation</span>
              </span>
              {currentQ.funFact && (
                <span className="text-[11px] font-semibold text-amber-400 flex items-center gap-1">
                  <Sparkles size={12} />
                  <span>Host Fun Fact</span>
                </span>
              )}
            </div>
            <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-medium">
              {currentQ.explanation}
            </p>
            {currentQ.funFact && (
              <p className="text-xs text-amber-200/90 italic pt-1 border-t border-slate-800/80">
                &ldquo;{currentQ.funFact}&rdquo;
              </p>
            )}

            {/* Next Question / Finish Button */}
            <div className="pt-3 flex justify-end">
              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/25 transition hover:scale-[1.02]"
              >
                <span>
                  {currentIndex + 1 < questions.length ? 'Next Question' : 'View Results'}
                </span>
                <ArrowRight size={15} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Google Search Grounding Drawer */}
      <SearchGroundingDrawer
        isOpen={isFactCheckOpen}
        onClose={() => setIsFactCheckOpen(false)}
        questionText={currentQ.question}
        correctAnswer={currentQ.correctAnswer}
        explanation={factCheckData.explanation}
        sources={factCheckData.sources}
        searchQueries={factCheckData.queries}
        isLoading={factCheckData.isLoading}
      />
    </div>
  );
};
