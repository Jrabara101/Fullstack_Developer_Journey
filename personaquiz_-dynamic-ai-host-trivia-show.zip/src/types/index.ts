export type VoiceOption = 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr';

export type HostEmotion = 'neutral' | 'happy' | 'roast' | 'shocked' | 'smug' | 'encouraging' | 'thinking';

export interface HostPersonality {
  id: string;
  name: string;
  title: string;
  tagline: string;
  avatarIcon: string; // Emoji or visual icon key
  avatarBg: string;
  badgeColor: string;
  voice: VoiceOption;
  personalityPrompt: string;
  greetingLine: string;
  correctReactions: string[];
  wrongReactions: string[];
  catchphrases: string[];
  traits: string[];
  isCustom?: boolean;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  funFact?: string;
  category: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface GroundingInfo {
  grounded: boolean;
  sources: GroundingSource[];
  queries?: string[];
  explanation?: string;
}

export type GameMode = 'showdown' | 'live-voice' | 'search-sprint';

export interface GameState {
  currentQuestionIndex: number;
  score: number;
  streak: number;
  maxStreak: number;
  selectedAnswer: string | null;
  isAnswered: boolean;
  isCorrect: boolean | null;
  lifelines: {
    fiftyFifty: boolean;
    askHost: boolean;
    searchFactCheck: boolean;
  };
  eliminatedOptions: string[];
  hostReaction: {
    text: string;
    emotion: HostEmotion;
    audioBase64?: string;
    isPlayingAudio?: boolean;
  } | null;
  history: Array<{
    question: Question;
    userAnswer: string;
    isCorrect: boolean;
    points: number;
  }>;
}
