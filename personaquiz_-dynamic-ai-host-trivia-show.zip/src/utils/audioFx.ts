// Web Audio API Sound Effects Synthesizer & Gemini Audio Player
let sharedAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
    const AudioContextClass =
      window.AudioContext || (window as any).webkitAudioContext;
    sharedAudioCtx = new AudioContextClass();
  }
  if (sharedAudioCtx.state === 'suspended') {
    sharedAudioCtx.resume();
  }
  return sharedAudioCtx;
}

// 1. Correct Answer Sound (Cheerful major ascending chords)
export function playCorrectSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + index * 0.08);

      gain.gain.setValueAtTime(0, now + index * 0.08);
      gain.gain.linearRampToValueAtTime(0.2, now + index * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + index * 0.08 + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + index * 0.08);
      osc.stop(now + index * 0.08 + 0.4);
    });
  } catch (err) {
    console.warn('Audio play error', err);
  }
}

// 2. Wrong Answer Sound (Retro game show low buzzer buzz)
export function playWrongSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sawtooth';
    osc2.type = 'square';

    osc1.frequency.setValueAtTime(146.83, now); // D3
    osc1.frequency.linearRampToValueAtTime(110.0, now + 0.35); // A2
    osc2.frequency.setValueAtTime(155.56, now); // Eb3 disharmony
    osc2.frequency.linearRampToValueAtTime(116.54, now + 0.35);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.linearRampToValueAtTime(0.2, now + 0.25);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.45);
    osc2.stop(now + 0.45);
  } catch (err) {
    console.warn('Audio play error', err);
  }
}

// 3. Countdown Tick (Crisp click for timer urgency)
export function playTickSound(isUrgent = false) {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = isUrgent ? 'sawtooth' : 'triangle';
    osc.frequency.setValueAtTime(isUrgent ? 880 : 440, now);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.06);
  } catch (err) {
    // Ignore audio autoplay restrictions
  }
}

// 4. Lifeline Used Sound (Sparkly ascending harp-like glissando)
export function playLifelineSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const freqs = [440, 554.37, 659.25, 880, 1108.73, 1318.51];
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.05);

      gain.gain.setValueAtTime(0, now + idx * 0.05);
      gain.gain.linearRampToValueAtTime(0.15, now + idx * 0.05 + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.05);
      osc.stop(now + idx * 0.05 + 0.3);
    });
  } catch (err) {
    console.warn('Audio play error', err);
  }
}

// 5. Victory Fanfare (Celebratory grand finish)
export function playFanfareSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const chords = [
      { t: 0, f: [523.25, 659.25, 783.99], dur: 0.15 },
      { t: 0.15, f: [523.25, 659.25, 783.99], dur: 0.15 },
      { t: 0.3, f: [523.25, 659.25, 783.99], dur: 0.15 },
      { t: 0.45, f: [698.46, 880.0, 1046.5], dur: 0.6 },
    ];

    chords.forEach((chord) => {
      chord.f.forEach((freq) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + chord.t);

        gain.gain.setValueAtTime(0.15, now + chord.t);
        gain.gain.exponentialRampToValueAtTime(
          0.001,
          now + chord.t + chord.dur
        );

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + chord.t);
        osc.stop(now + chord.t + chord.dur);
      });
    });
  } catch (err) {
    console.warn('Audio play error', err);
  }
}

// Global active source reference so we can stop TTS on skip or user action
let currentTtsSource: AudioBufferSourceNode | null = null;

export function stopCurrentSpeech() {
  if (currentTtsSource) {
    try {
      currentTtsSource.stop();
    } catch (_) {}
    currentTtsSource = null;
  }
}

/**
 * Play raw PCM (or standard RIFF WAV) base64 audio from gemini-3.1-flash-tts-preview
 */
export async function playPcmBase64(
  base64Data: string,
  sampleRate = 24000
): Promise<void> {
  stopCurrentSpeech();

  return new Promise((resolve, reject) => {
    try {
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const ctx = getAudioContext();

      // Check if standard WAV header ('RIFF')
      if (
        bytes[0] === 0x52 &&
        bytes[1] === 0x49 &&
        bytes[2] === 0x46 &&
        bytes[3] === 0x46
      ) {
        ctx.decodeAudioData(
          bytes.buffer.slice(0),
          (buffer) => {
            const source = ctx.createBufferSource();
            source.buffer = buffer;
            source.connect(ctx.destination);
            currentTtsSource = source;
            source.onended = () => {
              currentTtsSource = null;
              resolve();
            };
            source.start(0);
          },
          (err) => reject(err)
        );
        return;
      }

      // Convert raw 16-bit PCM (little-endian) to Float32 [-1, 1]
      const int16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(int16.length);
      for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / 32768.0;
      }

      const buffer = ctx.createBuffer(1, float32.length, sampleRate);
      buffer.copyToChannel(float32, 0);

      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      currentTtsSource = source;

      source.onended = () => {
        currentTtsSource = null;
        resolve();
      };
      source.start(0);
    } catch (err) {
      console.error('Failed to play PCM base64:', err);
      reject(err);
    }
  });
}
