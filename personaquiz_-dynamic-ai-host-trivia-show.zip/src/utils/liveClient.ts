/**
 * Client-side Live API audio streamer and WebSocket client
 * Connects with server.ts WebSocket -> ai.live.connect({ model: 'gemini-3.8-live' })
 */

export interface LiveClientCallbacks {
  onReady?: () => void;
  onInterrupted?: () => void;
  onError?: (err: string) => void;
  onClose?: () => void;
  onVolumeChange?: (userVol: number, hostVol: number) => void;
}

export class LiveAudioSession {
  private ws: WebSocket | null = null;
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private nextStartTime = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private callbacks: LiveClientCallbacks;
  private isMuted = false;

  constructor(callbacks: LiveClientCallbacks) {
    this.callbacks = callbacks;
  }

  public async start(hostName: string, hostPersona: string, voice: string) {
    // 1. Establish WebSocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/live`;
    this.ws = new WebSocket(wsUrl);

    this.ws.onopen = () => {
      // Send start handshake
      this.ws?.send(
        JSON.stringify({
          type: 'start',
          hostName,
          hostPersona,
          voice,
        })
      );
    };

    this.ws.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data);

        if (msg.type === 'ready') {
          this.callbacks.onReady?.();
          // Initialize mic stream once session is established
          await this.setupMicrophone();
        } else if (msg.type === 'audio' && msg.audio) {
          this.playAudioChunk(msg.audio);
        } else if (msg.type === 'interrupted') {
          this.handleInterrupted();
        } else if (msg.type === 'error') {
          this.callbacks.onError?.(msg.message || 'Live session error');
        } else if (msg.type === 'session_closed') {
          this.callbacks.onClose?.();
        }
      } catch (e: any) {
        console.error('Error handling live message:', e);
      }
    };

    this.ws.onerror = (err) => {
      console.error('Live WebSocket error:', err);
      this.callbacks.onError?.('Failed to connect to Live Voice server.');
    };

    this.ws.onclose = () => {
      this.callbacks.onClose?.();
      this.cleanup();
    };

    // Output AudioContext at 24kHz for model playback
    const AudioContextClass =
      window.AudioContext || (window as any).webkitAudioContext;
    this.outputAudioCtx = new AudioContextClass({ sampleRate: 24000 });
  }

  private async setupMicrophone() {
    try {
      const AudioContextClass =
        window.AudioContext || (window as any).webkitAudioContext;
      // 16kHz context for Live API input audio requirement
      this.inputAudioCtx = new AudioContextClass({ sampleRate: 16000 });

      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      const source = this.inputAudioCtx.createMediaStreamSource(this.micStream);
      // 4096 buffer size
      this.processor = this.inputAudioCtx.createScriptProcessor(4096, 1, 1);

      source.connect(this.processor);
      this.processor.connect(this.inputAudioCtx.destination);

      this.processor.onaudioprocess = (e) => {
        if (this.isMuted) return;
        const inputData = e.inputBuffer.getChannelData(0);

        // Simple volume calculation
        let sum = 0;
        for (let i = 0; i < inputData.length; i++) {
          sum += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sum / inputData.length);
        this.callbacks.onVolumeChange?.(Math.min(1, rms * 5), 0);

        // Convert Float32 to 16-bit PCM little-endian
        const pcm16 = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          const s = Math.max(-1, Math.min(1, inputData[i]));
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
        }

        // Convert to base64
        const bytes = new Uint8Array(pcm16.buffer);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const base64 = btoa(binary);

        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ type: 'audio', audio: base64 }));
        }
      };
    } catch (err: any) {
      console.error('Microphone access failed:', err);
      this.callbacks.onError?.(
        'Could not access microphone. Please ensure microphone permissions are granted.'
      );
    }
  }

  private playAudioChunk(base64Audio: string) {
    if (!this.outputAudioCtx) return;

    if (this.outputAudioCtx.state === 'suspended') {
      this.outputAudioCtx.resume();
    }

    try {
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert 16-bit PCM (24kHz) to Float32
      const int16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(int16.length);
      let sum = 0;
      for (let i = 0; i < int16.length; i++) {
        const val = int16[i] / 32768.0;
        float32[i] = val;
        sum += val * val;
      }
      const hostVolume = Math.min(1, Math.sqrt(sum / (int16.length || 1)) * 4);
      this.callbacks.onVolumeChange?.(0, hostVolume);

      const buffer = this.outputAudioCtx.createBuffer(1, float32.length, 24000);
      buffer.copyToChannel(float32, 0);

      const source = this.outputAudioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(this.outputAudioCtx.destination);

      // Schedule gapless playback:
      const currentTime = this.outputAudioCtx.currentTime;
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime;
      }

      source.start(this.nextStartTime);
      this.nextStartTime += buffer.duration;

      this.activeSources.push(source);
      source.onended = () => {
        const idx = this.activeSources.indexOf(source);
        if (idx !== -1) this.activeSources.splice(idx, 1);
        if (this.activeSources.length === 0) {
          this.callbacks.onVolumeChange?.(0, 0);
        }
      };
    } catch (err) {
      console.error('Error scheduling audio chunk:', err);
    }
  }

  public handleInterrupted() {
    this.callbacks.onInterrupted?.();
    this.activeSources.forEach((src) => {
      try {
        src.stop();
      } catch (_) {}
    });
    this.activeSources = [];
    if (this.outputAudioCtx) {
      this.nextStartTime = this.outputAudioCtx.currentTime;
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
  }

  public sendTextMessage(text: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'text', text }));
    }
  }

  public cleanup() {
    this.handleInterrupted();

    if (this.processor) {
      try {
        this.processor.disconnect();
      } catch (_) {}
      this.processor = null;
    }

    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }

    if (this.inputAudioCtx) {
      try {
        this.inputAudioCtx.close();
      } catch (_) {}
      this.inputAudioCtx = null;
    }

    if (this.outputAudioCtx) {
      try {
        this.outputAudioCtx.close();
      } catch (_) {}
      this.outputAudioCtx = null;
    }

    if (this.ws) {
      if (this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'stop' }));
        this.ws.close();
      }
      this.ws = null;
    }
  }
}
