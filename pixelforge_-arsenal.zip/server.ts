/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json({ limit: '10mb' }));

// Initialize the official Gemini SDK
// User-Agent: 'aistudio-build' is required for analytics
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
} else {
  console.warn('Warning: GEMINI_API_KEY check failed or holds default template value. Running in fallback/procedural-override mode.');
}

// API Routes FIRST
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: !!apiKey && apiKey !== 'MY_GEMINI_API_KEY',
    time: new Date().toISOString(),
  });
});

app.post('/api/generate', async (req, res) => {
  try {
    const {
      prompt,
      category,
      pov,
      grid_size, // [width, height]
      shading,
      palette_count,
      seed,
      existing_weapon, // reference weapon if some parts are locked
    } = req.body;

    const [width, height] = grid_size || [32, 16];

    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API not initialized',
        message: 'No active GEMINI_API_KEY found in server secrets. Please toggle to Offline Procedural Mode or add a secret first.',
      });
    }

    const systemInstruction = `
You are PixelForge-AI, a high-fidelity 2D retro retro-game sprites grid engine.
Your sole job is to generate pixel art guns matching a desired visual category, perspective POV, and grid resolution bounds.

Visual category rules & guidelines to adhere to strictly:
1. 'old': Muskets, archaic lock mechanism blunderbusses, flintlocks, cannons — muted brass, aged iron, dark brown wood grain textures.
2. 'modern': Heavy military rifles, polymer service pistols, pump shotguns — sleek metallic greys, tactical dark blacks, matte polymer finishes.
3. 'jungle': Forest blowguns, vine-wrapped grips, bone/wood bayonets, thorny barrels — earthy forest greens, bone ivory, toxic neon orchids.
4. 'alien': Bioluminescent crystal energy emitters, organic curved flesh silhouettes, plasma tubes — dark violet core, neon purples, glowing cyan emitters, anti-gravity floating panels.
5. 'high-tech': Railguns, focused energy prisms, nano-accelerated rifles — shiny silver chromes, electric laser blues, floating holographic sights.

Grid & perspective guidance:
- You are generating a 2D horizontal projection.
- POV is '${pov}'.
- Width of grid is ${width} and Height is ${height}.
- Pixels should form a compact, distinct weapon silhouette. Avoid scattered rogue pixels.
- The color palette index 0 MUST represent 'transparent' background space.
- The color palette index 1 MUST be a dark edge outline appropriate for the setting:
  - 'old': Dark warm brown (#3A2212)
  - 'modern': Pure tactical black (#000000)
  - 'jungle': Dark deep green (#122B18)
  - 'alien': Glow aura deep indigo/void purple (#1E0533)
  - 'high-tech': Shiny chrome outline or dark navy (#0B1021)
- Map remaining indices to beautifully coordinates representing stock, receiver chamber/body, handle grasp/grip, triggering mechanism, and firing barrel tip.

Lock system constraints (if applicable):
${existing_weapon ? `The user has locked parts of the design. You must align your coordinate output with original values where possible. Alternatively, our backend merges locked coordinates seamlessly.` : `No locks applied.`}
`;

    const userPrompt = `
Generate a beautiful pixel gun weapon design.
Category: "${category}"
POV viewpoint: "${pov}"
Grid specs: ${width}x${height}
Color Count: ${palette_count || 12}
Shading styling: "${shading}"
Seed: ${seed || 42}
Additional Descriptors: "${prompt || 'custom tactical rifle SPRITE'}"

Respond *only* with valid JSON adhering strictly to the responseSchema rules.
`;

    // Query official Gemini LLM
    const modelName = 'gemini-3.5-flash';
    const response = await ai.models.generateContent({
      model: modelName,
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.8,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            weapon: { type: Type.STRING, description: 'The custom retro name of the generated gun' },
            category: { type: Type.STRING, description: 'The visual category used' },
            pov: { type: Type.STRING, description: 'The POV orientation code' },
            grid_size: {
              type: Type.ARRAY,
              items: { type: Type.INTEGER },
              description: 'Array of two integers indicating [Width, Height]'
            },
            palette: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Array of hex colors starting with transparent at index 0, outline color at index 1, and core shading slots."
            },
            pixels: {
              type: Type.ARRAY,
              items: {
                type: Type.ARRAY,
                items: { type: Type.INTEGER }
              },
              description: '2D array of pixel palette indexes'
            },
            meta: {
              type: Type.OBJECT,
              properties: {
                dominant_colors: { type: Type.ARRAY, items: { type: Type.STRING } },
                weapon_class: { type: Type.STRING },
                era: { type: Type.STRING },
                lore_blurb: { type: Type.STRING }
              },
              required: ['dominant_colors', 'weapon_class', 'era', 'lore_blurb']
            }
          },
          required: ['weapon', 'category', 'pov', 'grid_size', 'palette', 'pixels', 'meta']
        }
      }
    });

    const bodyText = response.text;
    if (!bodyText) {
      return res.status(502).json({
        error: 'Engine Output Failure',
        message: 'The visual designer returned empty grid state. Please try another prompt.',
      });
    }

    const data = JSON.parse(bodyText.trim());
    return res.json(data);

  } catch (error: any) {
    console.error('Gemini call error:', error);
    res.status(500).json({
      error: 'Generation Failed',
      message: error.message || 'An error occurred while calling Google Gemini AI servers.',
    });
  }
});

// Vite Middleware & Client Static Routing
async function registerViteRouting() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('Mounted Vite dev server middleware.');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Serving production static outputs from /dist.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PixelForge server running successfully at http://0.0.0.0:${PORT}`);
  });
}

registerViteRouting();
