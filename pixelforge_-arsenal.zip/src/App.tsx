/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Volume2, 
  VolumeX, 
  HelpCircle, 
  Shuffle, 
  Lock, 
  Unlock, 
  Download, 
  Play, 
  Pause, 
  Sparkles, 
  Globe, 
  WifiOff, 
  Copy, 
  Trash2, 
  Settings, 
  AlertCircle 
} from 'lucide-react';
import { WeaponCategory, Pov, ShadingStyle, WeaponModel, CATEGORIES, POVS } from './types';
import { generateProceduralWeapon, generateRandomSeed, generateWeaponName } from './utils/procedural';
import { triggerSvgDownload, triggerMetadataDownload } from './utils/svgSerializer';

export default function App() {
  // --- STATE ---
  const [category, setCategory] = useState<WeaponCategory>('alien');
  const [pov, setPov] = useState<Pov>('side_left');
  
  // Grid and limits
  const [gridWidth, setGridWidth] = useState<number>(32);
  const [gridHeight, setGridHeight] = useState<number>(16);
  const [colorCount, setColorCount] = useState<number>(12);
  const [shading, setShading] = useState<ShadingStyle>('dithered');
  
  // Custom seed
  const [seed, setSeed] = useState<number>(45811);
  const [prompt, setPrompt] = useState<string>('unstable void laser rifle with crystalline barrel');
  
  // active working structure
  const [activeWeapon, setActiveWeapon] = useState<WeaponModel | null>(null);
  const [historyList, setHistoryList] = useState<WeaponModel[]>([]);
  const [editedPalette, setEditedPalette] = useState<string[]>([]);
  const [hoveredHistoryId, setHoveredHistoryId] = useState<string | null>(null);
  
  // Locks State (applied to new generations)
  const [locks, setLocks] = useState({
    barrel: false,
    body: false,
    stock: false,
    grip: false,
  });

  // UI status elements
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isOffline, setIsOffline] = useState<boolean>(true); // Fallback-positive by default
  const [hasApiKey, setHasApiKey] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [showGridLines, setShowGridLines] = useState<boolean>(false);
  const [isLoopingAnimation, setIsLoopingAnimation] = useState<boolean>(true);
  const [isMuzzleFlashing, setIsMuzzleFlashing] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
  const [showCustomSeedInput, setShowCustomSeedInput] = useState<boolean>(false);
  const [generationError, setGenerationError] = useState<string | null>(null);

  // References
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameId = useRef<number | null>(null);
  const bobAngle = useRef<number>(0);
  const canvasContainerRef = useRef<HTMLDivElement | null>(null);

  // Sound Synth Generator (retro web audio implementation)
  const playSfx = (type: 'click' | 'generate' | 'export' | 'powerup' | 'lock') => {
    if (!soundEnabled) return;
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      
      if (type === 'click') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(140, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(70, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.08);
      } else if (type === 'generate') {
         // Custom 8-bit digital synth build up
         const now = ctx.currentTime;
         const osc = ctx.createOscillator();
         const gain = ctx.createGain();
         osc.type = 'sawtooth';
         osc.frequency.setValueAtTime(150, now);
         osc.frequency.exponentialRampToValueAtTime(1200, now + 0.35);
         gain.gain.setValueAtTime(0.12, now);
         gain.gain.exponentialRampToValueAtTime(0.005, now + 0.4);
         osc.connect(gain);
         gain.connect(ctx.destination);
         osc.start();
         osc.stop(now + 0.4);
      } else if (type === 'export') {
        // High pitched computer chirps (retro success noise)
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.07); // A5
        osc.frequency.setValueAtTime(1174.66, now + 0.14); // D6
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 0.35);
      } else if (type === 'lock') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(320, ctx.currentTime);
        osc.frequency.setValueAtTime(540, ctx.currentTime + 0.06);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.12);
      } else if (type === 'powerup') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
      }
    } catch (e) {
      // Browser audio context blocked
    }
  };

  // --- API INITIALIZATION & HEALTH CHECK ---
  useEffect(() => {
    async function checkBackend() {
      try {
        const response = await fetch('/api/health');
        if (response.ok) {
          const result = await response.json();
          setHasApiKey(result.hasApiKey);
          if (result.hasApiKey) {
            setIsOffline(false); // Enable server AI rendering automatically if key is active!
          }
        }
      } catch (err) {
        // Fallback robustly
        console.warn('API health check error. Running local procedural generation only.', err);
      }
    }
    checkBackend();
  }, []);

  // --- INITIAL DATA SEEDING & SHARING ---
  useEffect(() => {
    // Populate default history list from localStorage if present
    try {
      const saved = localStorage.getItem('pixelforge_history_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setHistoryList(parsed);
          setActiveWeapon(parsed[0]);
          setEditedPalette([...parsed[0].palette]);
          return;
        }
      }
    } catch (e) {
      console.warn('Error reading from history cache:', e);
    }

    // Check shared variables from location hash
    const hash = window.location.hash;
    if (hash && hash.length > 3) {
      try {
        const params = new URLSearchParams(hash.substring(1));
        const hashCategory = params.get('category') as WeaponCategory;
        const hashSeed = parseInt(params.get('seed') || '');
        const hashPov = params.get('pov') as Pov;
        const hashShade = params.get('shade') as ShadingStyle;
        const hashPrompt = params.get('prompt');
        const hashLockStr = params.get('locks');

        if (hashCategory && !isNaN(hashSeed)) {
          setCategory(hashCategory);
          setSeed(hashSeed);
          if (hashPov) setPov(hashPov);
          if (hashShade) setShading(hashShade);
          if (hashPrompt) setPrompt(hashPrompt);
          if (hashLockStr) {
            const lArr = hashLockStr.split(',');
            setLocks({
              barrel: lArr.includes('barrel'),
              body: lArr.includes('body'),
              stock: lArr.includes('stock'),
              grip: lArr.includes('grip')
            });
          }

          // Trigger immediate generation with shared parameters
          const sharedWeapon = generateProceduralWeapon(
            hashCategory,
            hashPov || 'side_left',
            32,
            16,
            hashSeed,
            hashPrompt || '',
            hashShade || 'dithered',
            12
          );
          setActiveWeapon(sharedWeapon);
          setEditedPalette([...sharedWeapon.palette]);
          return;
        }
      } catch (err) {
        console.warn('Error loading shared state from URL:', err);
      }
    }

    // Default startup generation
    triggerRender(45811, 'alien', 'side_left', 'dithered', 32, 16, 12, 'unstable void laser rifle with crystalline barrel', true);
  }, []);

  // --- CANVAS BOBBING LOOP ANIMATION ---
  useEffect(() => {
    let activeId: number;
    
    const tick = () => {
      // Loop rendering tick
      if (canvasRef.current && activeWeapon) {
        const offsetY = isLoopingAnimation ? Math.sin(bobAngle.current) * 4.5 : 0;
        bobAngle.current += 0.045;
        
        renderCanvasPixels(canvasRef.current, activeWeapon, offsetY);
      }
      activeId = requestAnimationFrame(tick);
    };

    activeId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(activeId);
  }, [activeWeapon, isLoopingAnimation, showGridLines, isMuzzleFlashing]);

  // Sync edits in palette
  useEffect(() => {
    if (activeWeapon) {
      setEditedPalette([...activeWeapon.palette]);
    }
  }, [activeWeapon?.id]);

  // --- ACTION GENERATE / TRIGGER ---
  const handleGenerate = () => {
    playSfx('generate');
    const newSeed = seed === 45811 ? generateRandomSeed() : seed; // rotate seed if default is untouched and user pressed generate
    setSeed(newSeed);
    triggerRender(newSeed, category, pov, shading, gridWidth, gridHeight, colorCount, prompt, false);
  };

  const handleRandomize = () => {
    playSfx('powerup');
    const randomKeys: WeaponCategory[] = ['old', 'modern', 'jungle', 'alien', 'high-tech'];
    const chosenCategory = randomKeys[Math.floor(Math.random() * randomKeys.length)];
    const chosenSeed = generateRandomSeed();
    const generatorName = generateWeaponName(chosenCategory, chosenSeed);
    
    setCategory(chosenCategory);
    setSeed(chosenSeed);
    setPrompt(generatorName.toLowerCase() + ' with custom chamber');
    
    triggerRender(chosenSeed, chosenCategory, pov, shading, gridWidth, gridHeight, colorCount, generatorName, false);
  };

  const triggerRender = async (
    targetSeed: number,
    targetCategory: WeaponCategory,
    targetPov: Pov,
    targetShading: ShadingStyle,
    targetW: number,
    targetH: number,
    targetColorLimit: number,
    targetPrompt: string,
    isStartup: boolean
  ) => {
    setIsGenerating(true);
    setGenerationError(null);

    // Build locked configuration block
    const lockConfig = {
      barrel: locks.barrel,
      body: locks.body,
      stock: locks.stock,
      grip: locks.grip,
    };

    try {
      if (!isOffline && hasApiKey) {
        // Run full-stack AI generation route
        const payload = {
          prompt: targetPrompt,
          category: targetCategory,
          pov: targetPov,
          grid_size: [targetW, targetH],
          shading: targetShading,
          palette_count: targetColorLimit,
          seed: targetSeed,
          existing_weapon: activeWeapon ? {
            pixels: activeWeapon.pixels,
            palette: activeWeapon.palette,
            grid_size: activeWeapon.grid_size,
            locked_parts: lockConfig
          } : null
        };

        const res = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (res.ok) {
          const aiWeapon = await res.json();
          // Inject locks values and missing ids back
          const processedWeapon: WeaponModel = {
            id: aiWeapon.id || `ai_${targetCategory}_${Date.now()}`,
            weapon: aiWeapon.weapon || generateWeaponName(targetCategory, targetSeed),
            category: targetCategory,
            pov: targetPov,
            grid_size: aiWeapon.grid_size || [targetW, targetH],
            palette: aiWeapon.palette || [],
            pixels: aiWeapon.pixels || [],
            meta: aiWeapon.meta || {
              dominant_colors: [],
              weapon_class: 'AI Special',
              era: 'Unknown Era',
              lore_blurb: aiWeapon.weapon
            },
            seed: targetSeed,
            prompt: targetPrompt,
            pixel_size: targetW,
            palette_count: targetColorLimit,
            shading: targetShading,
            locked_parts: lockConfig
          };

          // Handle client-side lock stitching over the AI returned pixel array bounds
          if (activeWeapon && (activeWeapon.grid_size[0] === targetW) && (activeWeapon.grid_size[1] === targetH)) {
            for (let y = 0; y < targetH; y++) {
              for (let x = 0; x < targetW; x++) {
                // Determine part category of current coordinates
                const pType = getPartFromCoords(x, y, targetW, targetH, targetPov);
                let checkLocked = false;
                if (pType === 'barrel' && locks.barrel) checkLocked = true;
                if (pType === 'body' && locks.body) checkLocked = true;
                if (pType === 'stock' && locks.stock) checkLocked = true;
                if (pType === 'grip' && locks.grip) checkLocked = true;

                if (checkLocked) {
                  processedWeapon.pixels[y][x] = activeWeapon.pixels[y]?.[x] ?? 0;
                }
              }
            }
          }

          saveToActive(processedWeapon, isStartup);
          setIsGenerating(false);
          return;
        } else {
          const errData = await res.json();
          console.error('AI API Route warning, falling back to local engine:', errData);
          setGenerationError('Gemini API query rejected. Generating immediately using procedural core fallback.');
        }
      }
    } catch (e: any) {
      console.warn('Network issue during AI trigger. Proceeding with procedural engine.', e);
      setGenerationError('Network timeout. Processing model locally.');
    }

    // Procedural fallback generation
    const localWeapon = generateProceduralWeapon(
      targetCategory,
      targetPov,
      targetW,
      targetH,
      targetSeed,
      targetPrompt,
      targetShading,
      targetColorLimit,
      activeWeapon ? {
        ...activeWeapon,
        locked_parts: lockConfig
      } : null
    );

    saveToActive(localWeapon, isStartup);
    setIsGenerating(false);
  };

  const saveToActive = (weapon: WeaponModel, isStartup: boolean) => {
    setActiveWeapon(weapon);
    setEditedPalette([...weapon.palette]);

    if (!isStartup) {
      setHistoryList(prev => {
        // Limit history to 12 items max
        const filtered = prev.filter(w => w.weapon !== weapon.weapon);
        const updated = [weapon, ...filtered].slice(0, 12);
        try {
          localStorage.setItem('pixelforge_history_v2', JSON.stringify(updated));
        } catch (e) {
          console.warn('LocalStorage save warning:', e);
        }
        return updated;
      });
    }
  };

  const getPartFromCoords = (x: number, y: number, W: number, H: number, targetPov: Pov): 'barrel' | 'body' | 'stock' | 'grip' => {
    const isRightPointing = targetPov === 'side_right';
    
    if (targetPov === 'top_down') {
      if (x < W * 0.35) return 'barrel';
      if (x >= W * 0.75) return 'stock';
      if (x >= W * 0.45 && x <= W * 0.65 && (y < H * 0.3 || y > H * 0.7)) return 'grip';
      return 'body';
    }
    
    if (targetPov === 'diagonal_iso') {
      const offset = x + y;
      const maxOffset = W + H;
      if (offset < maxOffset * 0.35) return 'barrel';
      if (offset > maxOffset * 0.75) return 'stock';
      if (x > W * 0.4 && y > H * 0.5) return 'grip';
      return 'body';
    }

    if (isRightPointing) {
      if (x < W * 0.28) return 'stock';
      if (x > W * 0.65) return 'barrel';
      if (y >= H * 0.5 && x >= W * 0.28 && x <= W * 0.52) return 'grip';
      return 'body';
    } else {
      if (x < W * 0.35) return 'barrel';
      if (x > W * 0.72) return 'stock';
      if (y >= H * 0.5 && x >= W * 0.48 && x <= W * 0.72) return 'grip';
      return 'body';
    }
  };

  // --- RENDERING CANVAS FUNCTION ---
  const renderCanvasPixels = (canvas: HTMLCanvasElement, weapon: WeaponModel, offsetY: number) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const [cols, rows] = weapon.grid_size;
    const palette = weapon.palette;
    const pixels = weapon.pixels;

    // Clear previous view
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const pxWidth = canvas.width / cols;
    const pxHeight = canvas.height / rows;

    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        const val = pixels[y]?.[x] ?? 0;
        if (val === 0) continue; // transparent pixel

        const drawX = x * pxWidth;
        const drawY = y * pxHeight + offsetY;

        // Apply grid overlays
        let pixelColor = palette[val] || '#000000';
        
        ctx.fillStyle = pixelColor;
        ctx.fillRect(drawX, drawY, pxWidth, pxHeight);

        // Grid highlight bounds
        if (showGridLines) {
          ctx.strokeStyle = 'rgba(0, 255, 65, 0.15)';
          ctx.lineWidth = 1;
          ctx.strokeRect(drawX, drawY, pxWidth, pxHeight);
        }

        // Shading Dither layer
        if (weapon.shading === 'dithered' && val > 1) {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.22)';
          if ((x + y) % 2 === 0) {
            ctx.fillRect(drawX, drawY, pxWidth / 2, pxHeight / 2);
            ctx.fillRect(drawX + pxWidth / 2, drawY + pxHeight / 2, pxWidth / 2, pxHeight / 2);
          }
        }
      }
    }

    // Interactive locks boundary visualization on hover state
    // Highlight bounding boxes if requested

    // Fire laser muzzle flash loop
    if (isMuzzleFlashing) {
      ctx.fillStyle = targetCategoryColor(weapon.category);
      const isRight = weapon.pov === 'side_right';
      const isIso = weapon.pov === 'diagonal_iso';
      const isTop = weapon.pov === 'top_down';

      let flashCol = 0;
      let flashRow = Math.floor(rows / 2);

      if (isTop) {
        flashCol = Math.floor(cols * 0.05);
      } else if (isIso) {
        flashCol = Math.floor(cols * 0.1);
        flashRow = Math.floor(rows * 0.1);
      } else {
        flashCol = isRight ? cols - 1 : 0;
      }

      const flashX = flashCol * pxWidth + pxWidth / 2;
      const flashY = flashRow * pxHeight + pxHeight / 2 + offsetY;
      const flashRadius = pxWidth * 2.8;

      // Draw starburst
      ctx.beginPath();
      ctx.moveTo(flashX, flashY - flashRadius);
      ctx.lineTo(flashX + flashRadius * 0.35, flashY - flashRadius * 0.35);
      ctx.lineTo(flashX + flashRadius, flashY);
      ctx.lineTo(flashX + flashRadius * 0.35, flashY + flashRadius * 0.35);
      ctx.lineTo(flashX, flashY + flashRadius);
      ctx.lineTo(flashX - flashRadius * 0.35, flashY + flashRadius * 0.35);
      ctx.lineTo(flashX - flashRadius, flashY);
      ctx.lineTo(flashX - flashRadius * 0.35, flashY - flashRadius * 0.35);
      ctx.closePath();
      ctx.fill();

      // Core glow
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(flashX, flashY, flashRadius * 0.42, 0, 2 * Math.PI);
      ctx.fill();
    }
  };

  const targetCategoryColor = (cat: WeaponCategory): string => {
    switch (cat) {
      case 'old': return '#ffd700';
      case 'modern': return '#f87171';
      case 'jungle': return '#22c55e';
      case 'alien': return '#ec4899';
      case 'high-tech': return '#06b6d4';
    }
  };

  // --- INTERMEDIATE TRIGGER GUN ACTION ---
  const handleFireMuzzle = () => {
    if (!activeWeapon) return;
    playSfx('generate');
    setIsMuzzleFlashing(true);
    setTimeout(() => {
      setIsMuzzleFlashing(false);
    }, 180);
  };

  // --- PALETTE COLOR MODIFICATION BLOCK ---
  const handleSwapColor = (index: number, newColor: string) => {
    if (!activeWeapon) return;
    const updatedPalette = [...editedPalette];
    updatedPalette[index] = newColor;
    setEditedPalette(updatedPalette);

    // Dynamic state replacement update without full regeneration
    const updatedWeaponStructure: WeaponModel = {
      ...activeWeapon,
      palette: updatedPalette
    };
    setActiveWeapon(updatedWeaponStructure);
  };

  const handleResetPalette = () => {
    if (!activeWeapon) return;
    playSfx('lock');
    // Regenerate procedural default config palette of category key
    const refRandom = () => 0.5;
    const cleanPalette = buildPaletteForActiveCategory(activeWeapon.category, activeWeapon.palette_count || 12);
    setEditedPalette(cleanPalette);
    setActiveWeapon({
      ...activeWeapon,
      palette: cleanPalette
    });
  };

  const buildPaletteForActiveCategory = (cat: WeaponCategory, count: number): string[] => {
    // Basic static builder fallback mimicking procedural.ts
    const palette: string[] = ['transparent'];
    let outlineColor = '#000000';
    let bodyColor = '#555555';
    let bodyHighlight = '#aaaaaa';
    let accessoryColor = '#777777';
    let gripColor = '#333333';
    let energyColor = '#ff0000';
    let energyGlow = '#ff7777';

    if (cat === 'old') {
      outlineColor = '#3d2516';
      bodyColor = '#8b5a2b';
      bodyHighlight = '#cd853f';
      accessoryColor = '#c0c0c0';
      gripColor = '#4a2f13';
      energyColor = '#ffd700';
      energyGlow = '#ffe4b5';
    } else if (cat === 'modern') {
      outlineColor = '#111111';
      bodyColor = '#333b49';
      bodyHighlight = '#5a6b7c';
      accessoryColor = '#1e2530';
      gripColor = '#151a22';
      energyColor = '#22c55e';
      energyGlow = '#86efac';
    } else if (cat === 'jungle') {
      outlineColor = '#14301d';
      bodyColor = '#2d6a4f';
      bodyHighlight = '#74c69d';
      accessoryColor = '#e9d8a6';
      gripColor = '#402e21';
      energyColor = '#ec4899';
      energyGlow = '#fbcfe8';
    } else if (cat === 'alien') {
      outlineColor = '#120421';
      bodyColor = '#6b21a8';
      bodyHighlight = '#a855f7';
      accessoryColor = '#111827';
      gripColor = '#1e1b4b';
      energyColor = '#a855f7';
      energyGlow = '#f472b6';
    } else if (cat === 'high-tech') {
      outlineColor = '#0b132b';
      bodyColor = '#0066cc';
      bodyHighlight = '#33ccff';
      accessoryColor = '#1c2541';
      gripColor = '#0b0c10';
      energyColor = '#00ffff';
      energyGlow = '#ffffff';
    }

    palette.push(outlineColor, bodyColor, bodyHighlight, accessoryColor, gripColor, energyColor, energyGlow);
    while (palette.length < count) {
      palette.push('#a9a9a9');
    }
    return palette.slice(0, count);
  };

  // --- DOWNLOAD ENGINE IMPLEMENTATIONS ---
  const handlePngDownload = (multiplier: number) => {
    if (!activeWeapon || !canvasRef.current) return;
    playSfx('export');

    const [cols, rows] = activeWeapon.grid_size;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = cols * multiplier;
    tempCanvas.height = rows * multiplier;
    const tempCtx = tempCanvas.getContext('2d');
    
    if (tempCtx) {
      tempCtx.imageSmoothingEnabled = false; // Disable blurring smoothing
      
      const pixels = activeWeapon.pixels;
      const palette = activeWeapon.palette;
      
      for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
          const val = pixels[y]?.[x] ?? 0;
          if (val === 0) continue;
          
          const drawX = x * multiplier;
          const drawY = y * multiplier;
          
          tempCtx.fillStyle = palette[val];
          tempCtx.fillRect(drawX, drawY, multiplier, multiplier);

          // Apply shading
          if (activeWeapon.shading === 'dithered' && val > 1) {
            tempCtx.fillStyle = 'rgba(0, 0, 0, 0.15)';
            if ((x + y) % 2 === 0) {
              tempCtx.fillRect(drawX, drawY, multiplier / 2, multiplier / 2);
              tempCtx.fillRect(drawX + multiplier / 2, drawY + multiplier / 2, multiplier / 2, multiplier / 2);
            }
          }
        }
      }

      const imageUrl = tempCanvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.href = imageUrl;
      downloadLink.download = `${activeWeapon.weapon.replace(/\s+/g, '_')}_${activeWeapon.pov}_${multiplier}x.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  };

  const handleExportSvg = () => {
    if (!activeWeapon) return;
    playSfx('export');
    const outlineStyle = CATEGORIES[activeWeapon.category].outline;
    triggerSvgDownload(activeWeapon, outlineStyle);
  };

  // Download a full Spritesheet (Tiled rendering of all 4 perspectives)
  const downloadSpritesheet = () => {
    if (!activeWeapon) return;
    playSfx('export');

    const [cols, rows] = activeWeapon.grid_size;
    const blockScale = 8; // Size multiplier for sheet blocks
    
    // 2x2 grid layout compilation
    const spriteW = cols * blockScale;
    const spriteH = rows * blockScale;
    
    const sheetCanvas = document.createElement('canvas');
    sheetCanvas.width = spriteW * 2;
    sheetCanvas.height = spriteH * 2;
    const sCtx = sheetCanvas.getContext('2d');

    if (!sCtx) return;
    sCtx.imageSmoothingEnabled = false;

    const angleViews: Pov[] = ['side_left', 'side_right', 'top_down', 'diagonal_iso'];
    const positions = [
      { x: 0, y: 0 },
      { x: spriteW, y: 0 },
      { x: 0, y: spriteH },
      { x: spriteW, y: spriteH }
    ];

    angleViews.forEach((view, idx) => {
      // Procedurally generate or mirror grid pixels for each angle matching the weapon style
      const tempModel = generateProceduralWeapon(
        activeWeapon.category,
        view,
        cols,
        rows,
        activeWeapon.seed,
        activeWeapon.prompt || '',
        activeWeapon.shading,
        activeWeapon.palette_count,
        null // ignore main locks on raw overview
      );

      const offsetPos = positions[idx];
      sCtx.save();
      sCtx.translate(offsetPos.x, offsetPos.y);

      // Draw model pixels
      for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
          const val = tempModel.pixels[y]?.[x] ?? 0;
          if (val === 0) continue;

          const pxX = x * blockScale;
          const pxY = y * blockScale;

          sCtx.fillStyle = activeWeapon.palette[val] || '#000000';
          sCtx.fillRect(pxX, pxY, blockScale, blockScale);

          // Apply shading
          if (activeWeapon.shading === 'dithered' && val > 1) {
            sCtx.fillStyle = 'rgba(0, 0, 0, 0.15)';
            if ((x + y) % 2 === 0) {
              sCtx.fillRect(pxX, pxY, blockScale / 2, blockScale / 2);
              sCtx.fillRect(pxX + blockScale / 2, pxY + blockScale / 2, blockScale / 2, blockScale / 2);
            }
          }
        }
      }

      // Small subtitle watermark
      sCtx.fillStyle = 'rgba(0,255,65,0.7)';
      sCtx.font = '7px monospace';
      sCtx.fillText(view.toUpperCase(), 4, 10);
      sCtx.restore();
    });

    const sheetUrl = sheetCanvas.toDataURL('image/png');
    const downloadLink = document.createElement('a');
    downloadLink.href = sheetUrl;
    downloadLink.download = `${activeWeapon.weapon.replace(/\s+/g, '_')}_spritesheet.png`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);

    // Also download spritesheet JSON metadata
    triggerMetadataDownload(activeWeapon);
  };

  // --- SHARE COPILOT LINK ---
  const copyShareLink = () => {
    if (!activeWeapon) return;
    playSfx('export');

    const lockStr = Object.entries(locks)
      .filter(([_, locked]) => locked)
      .map(([name]) => name)
      .join(',');

    const queryParams = new URLSearchParams({
      category: activeWeapon.category,
      seed: activeWeapon.seed.toString(),
      pov: activeWeapon.pov,
      shade: activeWeapon.shading,
      prompt: activeWeapon.prompt || '',
    });

    if (lockStr) {
      queryParams.set('locks', lockStr);
    }

    const shareUrl = `${window.location.origin}${window.location.pathname}#${queryParams.toString()}`;
    
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    });
  };

  const handleClearHistory = () => {
    playSfx('lock');
    setHistoryList([]);
    localStorage.removeItem('pixelforge_history_v2');
  };

  // --- UTILITY DISPLAY RETAINERS ---
  const handleDimensionChange = (w: number, h: number) => {
    playSfx('click');
    setGridWidth(w);
    setGridHeight(h);
    // Auto-scaling limit tweaks depending on grid density sizes
    if (w < 16) {
      setColorCount(6);
    } else if (w < 32) {
      setColorCount(10);
    } else {
      setColorCount(16);
    }
  };

  return (
    <div id="pixel-app" className="w-[1024px] h-[768px] bg-[#050505] text-[#00FF41] font-mono flex flex-col overflow-hidden border-4 border-[#00FF41] select-none mx-auto my-auto relative">
      
      {/* HEADER SECTION */}
      <header id="header-bar" className="h-16 border-b-2 border-[#00FF41] flex items-center justify-between px-6 bg-[#0A0A0A] shrink-0 z-20">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-[#00FF41] rounded-sm flex items-center justify-center relative shadow-[0_0_10px_rgba(0,255,65,0.4)]">
            <div className="w-4 h-4 bg-black flex items-center justify-center text-[10px] font-black">⚒</div>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tighter flex items-center gap-2">
              PIXELFORGE: ARSENAL 
              <span className="text-[10px] tracking-normal font-normal opacity-50 px-1 border border-[#00FF41]/40 rounded">v2.4.0</span>
            </h1>
            <p className="text-[8px] opacity-60 tracking-wider">HYPER-DENSE AI WEAPON CONSOLE</p>
          </div>
        </div>

        <div className="flex gap-4 text-xs items-center">
          {/* OFFLINE / ONLINE TOGGLE */}
          <div className="flex items-center gap-2 px-3 py-1 bg-black border border-[#00FF41]/30 rounded">
            <span className="text-[10px] opacity-75">ENGINE:</span>
            <button 
              id="online-toggle"
              onClick={() => {
                if (!hasApiKey) {
                  // Prompt user or warn
                  setGenerationError("Missing Gemini Secret key. Toggle is locked to local procedural synthesis.");
                  playSfx('lock');
                  return;
                }
                playSfx('click');
                setIsOffline(!isOffline);
              }}
              className={`text-[9px] px-1.5 py-0.5 rounded font-bold transition-all ${
                isOffline 
                  ? 'bg-amber-900/30 text-amber-400 border border-amber-500/40' 
                  : 'bg-emerald-950 text-emerald-400 border border-emerald-500/50'
              }`}
              title={hasApiKey ? "Click to switch generator algorithm types" : "Gemini API key is not configured"}
            >
              {isOffline ? 'OFFLINE PROC' : 'ONLINE GEMINI'}
            </button>
          </div>

          <div className="h-4 w-px bg-[#00FF41]/20"></div>

          {/* AUDIO SYNTH CONTROLS */}
          <button 
            id="synth-sound-toggle"
            onClick={() => {
              setSoundEnabled(!soundEnabled);
              if (!soundEnabled) {
                // play high chime upon activation
                setTimeout(() => playSfx('powerup'), 50);
              }
            }}
            className="hover:bg-[#00FF41] hover:text-black p-1.5 border border-[#00FF41]/40 rounded-sm transition-colors cursor-pointer"
            title="Toggle synthetic 8-bit digital sound signals"
          >
            {soundEnabled ? <Volume2 size={13} /> : <VolumeX size={13} className="opacity-50" />}
          </button>

          {/* HELP COMPONENT */}
          <button 
            id="help-guide-toggle"
            onClick={() => {
              playSfx('click');
              setShowHelpModal(true);
            }}
            className="hover:bg-[#00FF41] hover:text-black p-1.5 border border-[#00FF41]/40 rounded-sm transition-colors cursor-pointer"
            title="Read system manual / help file"
          >
            <HelpCircle size={13} />
          </button>
        </div>
      </header>

      {/* DETAILED WORKING CORE PORTAL */}
      <main className="flex-1 flex overflow-hidden min-h-0 relative">
        
        {/* WEAKNESS/FAIL ALERTS PANEL */}
        {generationError && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-amber-950/90 border-2 border-amber-600 text-amber-200 text-xs px-4 py-2 z-50 flex items-center gap-2 rounded shadow-lg max-w-md">
            <AlertCircle size={14} className="shrink-0 text-amber-400" />
            <span className="flex-1 font-mono text-[10px] leading-relaxed">{generationError}</span>
            <button 
              onClick={() => setGenerationError(null)}
              className="text-amber-400 font-bold hover:text-white ml-2 text-[10px]"
            >
              [X]
            </button>
          </div>
        )}

        {/* LEFT CONTROL SIDEBAR PANEL */}
        <aside id="side-controls" className="w-60 border-r-2 border-[#00FF41] flex flex-col p-4 gap-5 bg-[#080808] overflow-y-auto shrink-0 select-none">
          
          {/* WEAPON CATEGORY SELECTION */}
          <div>
            <h2 className="text-[10px] uppercase tracking-[0.2em] mb-2.5 opacity-70 border-b border-[#00FF41]/20 pb-1">WEAPON FAMILIES</h2>
            <div className="flex flex-col gap-1.5">
              {(Object.keys(CATEGORIES) as WeaponCategory[]).map((catKey, i) => {
                const config = CATEGORIES[catKey];
                const isActive = category === catKey;
                return (
                  <button
                    id={`family-${catKey}`}
                    key={catKey}
                    onClick={() => {
                      playSfx('click');
                      setCategory(catKey);
                      // Custom presets matching rules
                      setColorCount(config.palette_max);
                      setShading(config.dithering ? 'dithered' : 'flat');
                    }}
                    className={`text-left text-xs px-2.5 py-2 border transition-all flex justify-between items-center ${
                      isActive 
                        ? 'border-[#00FF41] bg-[#00FF41]/10 font-bold text-white' 
                        : 'border-transparent hover:border-[#00FF41]/40 opacity-70 hover:opacity-100 bg-[#0c0c0c]'
                    }`}
                  >
                    <span>{config.name.toUpperCase()}</span>
                    <span className="text-[9px] opacity-40 font-mono">[{`0${i + 1}`}]</span>
                  </button>
                );
              })}
            </div>
            <p className="text-[9px] opacity-40 mt-1.5 leading-snug italic font-mono px-1">
              * {CATEGORIES[category].description}
            </p>
          </div>

          {/* GRID RESOLUTION BLOCK */}
          <div>
            <h2 className="text-[10px] uppercase tracking-[0.2em] mb-2 opacity-70 border-b border-[#00FF41]/20 pb-1">RESOLUTION SPECS</h2>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { label: '8 x 8 (Micro)', w: 8, h: 8 },
                { label: '16 x 8 (Stub)', w: 16, h: 8 },
                { label: '32 x 16 (Standard)', w: 32, h: 16 },
                { label: '64 x 32 (HD Retro)', w: 64, h: 32 },
              ].map((resOption) => {
                const isSelected = gridWidth === resOption.w && gridHeight === resOption.h;
                return (
                  <button
                    id={`res-${resOption.w}x${resOption.h}`}
                    key={`${resOption.w}-${resOption.h}`}
                    onClick={() => handleDimensionChange(resOption.w, resOption.h)}
                    className={`text-[9px] py-1 px-1.5 border text-center transition-all truncate ${
                      isSelected 
                        ? 'border-[#00FF41] bg-[#00FF41]/20 font-bold' 
                        : 'border-[#00FF41]/20 opacity-60 hover:opacity-100 hover:border-[#00FF41]/40'
                    }`}
                  >
                    {resOption.w}x{resOption.h}
                  </button>
                );
              })}
            </div>
          </div>

          {/* PALETTE DEPTH SLIDER */}
          <div>
            <div className="flex justify-between items-center text-[10px] mb-1.5">
              <span className="opacity-70 tracking-widest">COLOR QUANTITY</span>
              <span className="font-bold text-white">{colorCount} COLORS</span>
            </div>
            <div className="flex items-center gap-3 bg-black/40 border border-[#00FF41]/20 p-2 rounded">
              <input 
                id="palette-size-range"
                type="range" 
                min={2} 
                max={32} 
                value={colorCount} 
                onChange={(e) => {
                  setColorCount(parseInt(e.target.value));
                }}
                className="flex-1 accent-[#00FF41] h-1 bg-[#1A1A1A] cursor-pointer" 
              />
            </div>
            <p className="text-[8px] opacity-45 mt-1 leading-normal font-mono px-1">
              Target maximum colors allowed in generated output index list. Includes transparent space index.
            </p>
          </div>

          {/* SHADING TYPE SELECTOR */}
          <div>
            <h2 className="text-[10px] uppercase tracking-[0.2em] mb-2 opacity-70 border-b border-[#00FF41]/20 pb-1">RENDERING ENGINE</h2>
            <div className="flex flex-col gap-1">
              {[
                { key: 'flat', label: 'FLAT MATTE PIXELS' },
                { key: 'dithered', label: 'CHESSBOARD DITHER' },
                { key: 'outlined', label: 'HARD BODY OUTLINES' },
              ].map((styleOpt) => {
                const isActive = shading === styleOpt.key;
                return (
                  <button
                    id={`shading-${styleOpt.key}`}
                    key={styleOpt.key}
                    onClick={() => {
                      playSfx('click');
                      setShading(styleOpt.key as ShadingStyle);
                    }}
                    className={`text-left text-[9px] px-2.5 py-1.5 border transition-all ${
                      isActive 
                        ? 'border-[#00FF41] bg-[#00FF41]/5 text-[#00FF41] font-bold' 
                        : 'border-transparent opacity-60 hover:opacity-90 hover:bg-black/20'
                    }`}
                  >
                    🚀 {styleOpt.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* LIVE SEED SWAPPER VALUE */}
          <div>
            <div className="flex justify-between items-center text-[10px] mb-1">
              <span className="opacity-70 tracking-widest">COMPILE SEED</span>
              <button 
                id="change-seed-view"
                onClick={() => {
                  playSfx('click');
                  setShowCustomSeedInput(!showCustomSeedInput);
                }}
                className="text-[8px] border border-[#00FF41]/40 px-1 py-0.5 rounded hover:bg-[#00FF41] hover:text-black"
              >
                {showCustomSeedInput ? '[ LOCK ]' : '[ EDIT ]'}
              </button>
            </div>

            {showCustomSeedInput ? (
              <div className="flex gap-1">
                <input 
                  id="seed-manual-input"
                  type="number" 
                  value={seed}
                  onChange={(e) => {
                    const parsed = parseInt(e.target.value);
                    setSeed(isNaN(parsed) ? 1 : parsed);
                  }}
                  className="bg-black border border-[#00FF41] text-[10px] py-1 px-2 text-[#00FF41] font-mono outline-none w-full"
                />
              </div>
            ) : (
              <div className="bg-black border border-[#00FF41]/30 p-2 text-center text-xs tracking-widest text-[#00FF41] font-bold select-text rounded">
                #{seed.toString(16).toUpperCase().padStart(8, '0')}
              </div>
            )}
          </div>

          {/* DYNAMIC SHUFFLE ACTION */}
          <div className="mt-auto pt-2">
            <button
              id="btn-randomize"
              onClick={handleRandomize}
              className="w-full border-2 border-[#00FF41] py-2.5 font-bold hover:bg-[#00FF41] hover:text-black transition-all cursor-pointer shadow-[0_0_15px_rgba(0,255,65,0.15)] hover:shadow-[0_0_25px_rgba(0,255,65,0.4)] text-xs flex justify-center items-center gap-2 rounded-sm"
            >
              <Shuffle size={14} />
              RANDOMIZE SEED
            </button>
          </div>

        </aside>

        {/* CENTER PRIMARY VIEWPORT PANEL */}
        <section id="center-viewport" className="flex-1 flex flex-col p-6 bg-black relative overflow-y-auto select-none">
          
          {/* DIGITAL SCAN GRID BACKGROUND OVERLAY */}
          <div className="absolute inset-0 opacity-8 pointer-events-none z-0" style={{ backgroundImage: 'radial-gradient(#00FF41 1.2px, transparent 0)', backgroundColor: '#050505', backgroundSize: '16px 16px' }}></div>
          
          {/* CRT LINE SCANNER SIMULATION BAR */}
          <div className="absolute top-0 left-0 w-full h-px bg-[#00FF41]/25 opacity-40 animate-pulse pointer-events-none z-10" />

          {/* MAIN RETRO CANVAS WINDOW FRAME */}
          <div className="w-full flex-1 flex items-center justify-center relative z-10 py-2">
            
            <div 
              ref={canvasContainerRef}
              className="w-full max-w-2xl aspect-[2/1] border-2 border-[#00FF41]/40 bg-[#0A0A0A] relative flex flex-col items-center justify-center group shadow-[0_0_40px_rgba(0,255,65,0.08)] rounded"
            >
              {/* Scale canvas resolution */}
              <canvas 
                id="weapon-render-canvas"
                ref={canvasRef}
                width={512}
                height={256}
                className="w-[480px] h-[240px] image-render-pixelated cursor-crosshair drop-shadow-[0_0_15px_rgba(0,255,65,0.25)] transition-all"
                style={{ imageRendering: 'pixelated' }}
                onClick={handleFireMuzzle}
                title="Click on gun to test-fire muzzle flash laser blast!"
              />

              {/* Status information watermarks overlay inside viewport bounds */}
              <div className="absolute top-3 left-4 text-[9px] text-[#00FF41]/60 font-mono tracking-widest bg-black/60 px-1.5 py-0.5 rounded border border-[#00FF41]/10">
                RESOLUTION: {gridWidth} x {gridHeight} PX
              </div>

              <div className="absolute top-3 right-4 text-[9px] text-[#00FF41]/60 font-mono text-right bg-black/60 px-1.5 py-0.5 rounded border border-[#00FF41]/10">
                SHADING: {shading.toUpperCase()} RENDERER
              </div>

              <div className="absolute bottom-3 left-4 text-[9px] text-[#00FF41]/50 font-mono bg-black/60 px-1.5 py-0.5 rounded border border-[#00FF41]/10">
                CLASS: {activeWeapon?.meta.weapon_class || 'Procedural Gun'}
              </div>

              <div className="absolute bottom-3 right-4 text-[9px] text-[#00FF41]/50 font-mono text-right bg-black/60 px-1.5 py-0.5 rounded border border-[#00FF41]/10">
                ERA: {activeWeapon?.meta.era || 'Custom Timeline'}
              </div>

              {/* Loading display block */}
              {isGenerating && (
                <div id="loader-overlay" className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center gap-3 backdrop-blur-xs">
                  <div className="w-10 h-10 border-4 border-[#00FF41] border-t-transparent animate-spin rounded-full"></div>
                  <div className="text-xs font-bold animate-pulse tracking-widest text-[#00FF41]">
                    RE-ALIGNING QUANTUM PIXEL MATRICES ...
                  </div>
                </div>
              )}
            </div>

          </div>

          <div id="central-control-deck" className="flex flex-col gap-4 relative z-10 mt-2">
            
            {/* POV PERSPECTIVE VIEW SELECTOR TABS */}
            <div className="flex justify-center gap-1.5">
              {(Object.keys(POVS) as Pov[]).map((povKey) => {
                const config = POVS[povKey];
                const isSelected = pov === povKey;
                return (
                  <button
                    id={`pov-${povKey}`}
                    key={povKey}
                    onClick={() => {
                      playSfx('click');
                      setPov(povKey);
                      // Instantly trigger re-rendering for that angle matching parameters
                      triggerRender(seed, category, povKey, shading, gridWidth, gridHeight, colorCount, prompt, false);
                    }}
                    className={`px-3 py-1.5 text-[10px] font-bold border transition-all cursor-pointer ${
                      isSelected 
                        ? 'bg-[#00FF41] text-black border-[#00FF41] scale-[1.02] shadow-[0_0_10px_rgba(0,255,65,0.3)]' 
                        : 'border-[#00FF41]/30 text-[#00FF41] bg-black/45 hover:bg-[#00FF41]/10 hover:border-[#00FF41]/60'
                    }`}
                  >
                    {config.label}
                  </button>
                );
              })}
            </div>

            {/* PALETTE SWAPPER STRETCH GOAL INTEGRATION */}
            {activeWeapon && (
              <div id="skin-customizer" className="bg-[#0A0A0A] border-2 border-[#00FF41]/30 p-2.5 rounded">
                <div className="flex justify-between items-center mb-1.5 text-[9px] opacity-75">
                  <span className="tracking-widest font-black text-white">🎨 REAL-TIME PALETTE SWAPPER & COLOR CUSTOMIZER</span>
                  <button 
                    id="btn-reset-palette"
                    onClick={handleResetPalette}
                    className="text-[8px] underline border border-[#00FF41]/40 px-1 rounded hover:bg-[#00FF41] hover:text-black"
                  >
                    RESET PALETTE
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 items-center justify-start">
                  {editedPalette.map((color, idx) => {
                    if (idx === 0) return null; // skip transparent slot visually
                    return (
                      <div 
                        key={`${activeWeapon.id}-${idx}-${color}`} 
                        className="flex flex-col items-center gap-1 group relative bg-black/30 p-1 border border-[#00FF41]/15 rounded"
                      >
                        <div className="relative">
                          {/* Circle skin color display */}
                          <div 
                            className="w-5 h-5 rounded-xs border border-[#00FF41]/40 hover:scale-110 active:scale-95 cursor-pointer transition-transform shadow-xs"
                            style={{ backgroundColor: color }}
                            onClick={() => {
                              const input = document.getElementById(`color-picker-${idx}`);
                              if (input) input.click();
                            }}
                          >
                            {/* Short indexing indicator */}
                            <span className="absolute -top-1 -right-1 text-[7px] bg-black text-[#00FF41] font-mono w-2.5 h-2.5 rounded-full flex items-center justify-center border border-[#00FF41]/20">
                              {idx}
                            </span>
                          </div>
                          
                          <input 
                            id={`color-picker-${idx}`}
                            type="color" 
                            value={color.startsWith('#') ? color : '#777777'}
                            onChange={(e) => handleSwapColor(idx, e.target.value)}
                            className="absolute opacity-0 pointer-events-none w-0 h-0"
                          />
                        </div>
                        <span className="text-[7px] opacity-60 uppercase tracking-tighter" style={{ color: color }}>
                          {color}
                        </span>
                      </div>
                    );
                  })}
                  <div className="text-[8px] opacity-45 italic ml-auto leading-tight max-w-[120px]">
                    * Click any color block above to edit color live!
                  </div>
                </div>
              </div>
            )}

            {/* PROMPT BOX & GENERATE ACTION CONTAINS BAR */}
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <input
                  id="describe-gun-input"
                  type="text"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="DESCRIBE YOUR PIXEL WEAPON ARTIFACT SHAPE..."
                  className="w-full bg-black border-2 border-[#00FF41] text-[#00FF41] placeholder:text-[#00FF41]/30 text-xs px-4 py-3.5 outline-none focus:bg-[#00FF41]/5 select-text font-mono rounded-sm"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleGenerate();
                  }}
                />
                {prompt && (
                  <button 
                    id="clear-prompt-btn"
                    onClick={() => {
                      playSfx('click');
                      setPrompt('');
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#00FF41]/40 hover:text-[#00FF41]"
                  >
                    [CLEAR]
                  </button>
                )}
              </div>

              <button
                id="btn-generate"
                disabled={isGenerating}
                onClick={handleGenerate}
                className="bg-[#00FF41] text-black px-6 py-3.5 font-black text-xs tracking-widest hover:brightness-110 active:scale-95 transition-all cursor-pointer shadow-[0_0_15px_rgba(0,255,65,0.3)] disabled:opacity-50 select-none flex items-center gap-1.5 shrink-0 rounded-sm"
              >
                <Sparkles size={13} />
                GENERATE
              </button>
            </div>

            {/* SEED/LOCK MECHANICS PARTS PANEL */}
            <div id="locks-control-deck" className="bg-[#080808] border border-[#00FF41]/30 p-2.5 rounded flex items-center justify-between gap-4">
              <div className="flex flex-col gap-0.5">
                <div className="text-[9px] font-black text-white tracking-wider flex items-center gap-1">
                  <span>🔒 PIXEL COMPONENT LOCK ARCHITECTURE FOR SEEDING</span>
                </div>
                <p className="text-[8px] opacity-50 font-mono">
                  Locked components are retained across mutations when re-generating matching resolutions!
                </p>
              </div>

              <div className="flex gap-1.5">
                {(['barrel', 'body', 'stock', 'grip'] as const).map((part) => {
                  const isLocked = locks[part];
                  return (
                    <button
                      id={`lock-part-${part}`}
                      key={part}
                      onClick={() => {
                        playSfx('lock');
                        setLocks(prev => ({
                          ...prev,
                          [part]: !prev[part]
                        }));
                      }}
                      className={`px-2 py-1.5 border text-[9px] flex items-center gap-1 font-bold transition-all ${
                        isLocked 
                          ? 'border-[#00FF41] bg-[#00FF41]/10 text-white shadow-[0_0_8px_rgba(0,255,65,0.2)]' 
                          : 'border-transparent text-[#00FF41]/60 hover:border-[#00FF41]/30 bg-black/40'
                      }`}
                    >
                      {isLocked ? <Lock size={9} className="text-[#00FF41]" /> : <Unlock size={9} className="opacity-40" />}
                      {part.toUpperCase()}
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

        </section>

        {/* RIGHT GALLERY SIDEBAR HISTORY PANEL */}
        <aside id="history-sidebar" className="w-48 border-l-2 border-[#00FF41] p-3 flex flex-col gap-3 bg-[#080808] shrink-0 select-none min-h-0">
          
          <div className="flex justify-between items-center border-b border-[#00FF41]/20 pb-1 shrink-0">
            <h2 className="text-[9.5px] uppercase tracking-[0.15em] opacity-60">GALLERY ({historyList.length})</h2>
            {historyList.length > 0 && (
              <button 
                id="btn-clear-inventory"
                onClick={handleClearHistory}
                className="text-[8px] border border-[#00FF41]/30 hover:bg-red-950 hover:text-red-400 px-1 py-0.5 transition-colors rounded-xs"
                title="Wipe database history saved list"
              >
                RESET
              </button>
            )}
          </div>

          <div id="history-grid-container" className="flex-1 space-y-2.5 overflow-y-auto pr-1 min-h-0">
            {historyList.length === 0 ? (
              <div className="h-40 border border-dashed border-[#00FF41]/15 flex flex-col items-center justify-center p-3 text-center rounded bg-black/20">
                <p className="text-[9px] opacity-40 leading-relaxed font-mono">
                  No weapon prints compiled inside inventory memory bank yet.
                </p>
                <p className="text-[8px] text-[#00FF41]/30 mt-2 font-mono">
                  [ 🧩 Standby ]
                </p>
              </div>
            ) : (
              historyList.map((histWeapon) => {
                const isCurrent = activeWeapon?.id === histWeapon.id;
                return (
                  <div
                    id={`history-item-${histWeapon.id}`}
                    key={histWeapon.id}
                    onClick={() => {
                      playSfx('powerup');
                      setActiveWeapon(histWeapon);
                      setEditedPalette([...histWeapon.palette]);
                    }}
                    onMouseEnter={() => setHoveredHistoryId(histWeapon.id)}
                    onMouseLeave={() => setHoveredHistoryId(null)}
                    className={`border p-2 bg-black select-none cursor-pointer transition-all flex flex-col relative rounded ${
                      isCurrent 
                        ? 'border-[#00FF41] shadow-[inset_0_0_10px_rgba(0,255,65,0.12)]' 
                        : 'border-[#00FF41]/25 hover:border-[#00FF41]/60'
                    }`}
                  >
                    {/* Tiny representation of weapon palette colors in horizontal block */}
                    <div className="flex gap-0.5 mb-1 opacity-80">
                      {histWeapon.palette.filter((_, idx)=> idx > 0 && idx < 6).map((col, cIdx) => (
                        <div key={cIdx} className="w-1.5 h-1.5 rounded-full border border-black/50" style={{ backgroundColor: col }} />
                      ))}
                    </div>

                    <div className="text-[10px] uppercase font-bold tracking-tight truncate text-white">
                      {histWeapon.weapon}
                    </div>

                    {/* Metadata specs badge */}
                    <div className="flex justify-between items-center text-[7.5px] opacity-45 font-mono mt-0.5">
                      <span>{histWeapon.category.toUpperCase()}</span>
                      <span>{histWeapon.grid_size[0]}x{histWeapon.grid_size[1]}</span>
                    </div>

                    <span className="text-[7px] text-[#00FF41]/35 block truncate tracking-tighter mt-1 italic select-none">
                      "{histWeapon.prompt || 'custom layout'}"
                    </span>

                    {/* Trash Delete hover node action */}
                    {hoveredHistoryId === histWeapon.id && (
                      <button
                        id={`delete-history-${histWeapon.id}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          playSfx('lock');
                          const updated = historyList.filter(item => item.id !== histWeapon.id);
                          setHistoryList(updated);
                          localStorage.setItem('pixelforge_history_v2', JSON.stringify(updated));
                        }}
                        className="absolute top-1.5 right-1.5 text-[#00FF41]/50 hover:text-red-500 bg-[#0c0c0c] hover:border-red-500 border border-transparent p-0.5 rounded cursor-pointer transition-all"
                        title="Delete weapon form history entry"
                      >
                        <Trash2 size={9} />
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* UTILITY QUICK GRID METRICS */}
          <div className="mt-auto pt-2 border-t border-[#00FF41]/15 shrink-0">
            <div className="flex justify-between items-center text-[9px] mb-1">
              <span className="opacity-55">GRID OUTLINES:</span>
              <button
                id="toggle-outlines"
                onClick={() => {
                  playSfx('click');
                  setShowGridLines(!showGridLines);
                }}
                className={`text-[8px] px-1 py-0.5 rounded border transition-all ${
                  showGridLines 
                    ? 'border-[#00FF41] text-black bg-[#00FF41] font-bold' 
                    : 'border-[#00FF41]/35 text-[#00FF41]/65 hover:bg-[#00FF41]/10'
                }`}
              >
                {showGridLines ? 'SHOWN' : 'HIDDEN'}
              </button>
            </div>

            <div className="flex justify-between items-center text-[9px]">
              <span className="opacity-55">BOB ANIMATION:</span>
              <button
                id="toggle-loop-anim"
                onClick={() => {
                  playSfx('click');
                  setIsLoopingAnimation(!isLoopingAnimation);
                }}
                className={`text-[8px] px-1 py-0.5 rounded border transition-all ${
                  isLoopingAnimation 
                    ? 'border-[#00FF41] text-black bg-[#00FF41] font-bold' 
                    : 'border-[#00FF41]/35 text-[#00FF41]/65 hover:bg-[#00FF41]/10'
                }`}
              >
                {isLoopingAnimation ? 'ACTIVE' : 'PAUSED'}
              </button>
            </div>
          </div>

        </aside>

      </main>

      {/* FOOTER ACTIONS BAR */}
      <footer id="export-deck" className="h-14 border-t-2 border-[#00FF41] bg-[#0A0A0A] flex items-center px-6 justify-between select-none shrink-0 z-20">
        
        {/* EXPORT OPTIONS PILE */}
        <div className="flex gap-2 items-center">
          <span className="text-xxs font-bold opacity-75 tracking-wider">EXPORT RE-PRINTS:</span>
          
          <button 
            id="export-png-1x"
            onClick={() => handlePngDownload(1)}
            disabled={!activeWeapon}
            className="text-[9px] uppercase border border-[#00FF41]/40 px-2 py-1 hover:bg-[#00FF41] hover:text-black hover:font-bold disabled:opacity-40 transition-colors cursor-pointer"
            title="Download crisp 1:1 scale PNG sprite"
          >
            PNG 1x
          </button>

          <button 
            id="export-png-4x"
            style={{ contentVisibility: 'auto' }}
            onClick={() => handlePngDownload(8)} // 8x resolution fits games better!
            disabled={!activeWeapon}
            className="text-[9px] uppercase border border-[#00FF41]/40 px-2 py-1 hover:bg-[#00FF41] hover:text-black hover:font-bold disabled:opacity-40 transition-colors cursor-pointer"
            title="Download magnified upscale (high fidelity 16x pixels) PNG for presentations"
          >
            PNG 8x
          </button>

          <button 
            id="export-svg"
            onClick={handleExportSvg}
            disabled={!activeWeapon}
            className="text-[9px] uppercase border border-[#00FF41]/40 px-2 py-1 hover:bg-[#00FF41] hover:text-black hover:font-bold disabled:opacity-40 transition-colors cursor-pointer"
            title="Download crisp math-perfect SVG vector rect code representing each pixel"
          >
            SVG VECTOR
          </button>

          <button 
            id="export-spritesheet"
            onClick={downloadSpritesheet}
            disabled={!activeWeapon}
            className="text-[9px] uppercase border border-[#00FF41]/40 px-2.5 py-1 hover:bg-[#00FF41] hover:text-black hover:font-bold bg-[#00FF41]/10 disabled:opacity-40 transition-colors cursor-pointer"
            title="Generate tiled spritesheet PNG compilation of all 4 viewpoint perspectives"
          >
            SPRITESHEET
          </button>

          <button 
            id="btn-copy-address"
            onClick={copyShareLink}
            disabled={!activeWeapon}
            className="text-[9px] uppercase border border-amber-600/60 text-amber-400 px-2.5 py-1 hover:bg-amber-500 hover:text-black transition-colors cursor-pointer rounded-xs"
            title="Copy shared URL encoding gun seeds for collaboration"
          >
            {copiedLink ? 'COPIED!' : 'SHARE LINK'}
          </button>
        </div>

        {/* LORE MARQUEE TICKER SCREENS */}
        <div className="flex-1 ml-8 overflow-hidden relative h-5 border border-[#00FF41]/20 rounded-xs bg-[#050505] flex items-center justify-start">
          <div className="absolute left-0 top-0 h-full w-10 bg-gradient-to-r from-[#050505] to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 h-full w-10 bg-gradient-to-l from-[#050505] to-transparent z-10 pointer-events-none" />
          
          <div className="whitespace-nowrap flex items-center animate-marquee select-text">
            <span className="text-[#8800ff] font-extrabold text-[9px] uppercase px-1.5 bg-purple-950/40 rounded border border-purple-800/25 mr-2">
              LORE DECK
            </span>
            <span className="text-[10px] italic opacity-85 leading-none pr-10">
              "{activeWeapon?.meta.lore_blurb || 'Connecting pixel compiler system...'}"
            </span>
            <span className="text-[#00FF41] font-bold text-[8px] uppercase tracking-widest pl-10 pr-4">
              [ SYSTEM STABLE ]
            </span>
            <span className="text-[10px] italic opacity-85 leading-none pr-10">
              * Custom lock configurations enable precise seed generation parameters. Swap color hexagons dynamically to customize items.
            </span>
          </div>
        </div>

      </footer>

      {/* COMPACT MANUAL / HELP DIALOGS MODAL */}
      {showHelpModal && (
        <div id="help-modal" className="absolute inset-0 bg-black/90 z-50 flex items-center justify-center p-8 backdrop-blur-xs select-text">
          <div className="border-4 border-[#00FF41] bg-[#0A0A0A] max-w-lg p-6 font-mono text-xs text-[#00FF41] relative flex flex-col gap-4 rounded">
            <h3 className="text-base font-black border-b-2 border-[#00FF41] pb-2 tracking-widest">
              ⚒ PIXELFORGE OPERATIONAL MANUAL
            </h3>

            <div className="space-y-3.5 leading-relaxed overflow-y-auto max-h-[380px] pr-2">
              <p>
                <strong className="text-white">1. Weapon Families:</strong> Select a theme in the left dock to define the weapon category styling (metallic hues, organic structures, plasma tubes, crystals, etc).
              </p>
              <p>
                <strong className="text-white">2. POV selector:</strong> Render side views, top-down profiles, or 45-degree pseudo-3D diagonal models.
              </p>
              <p>
                <strong className="text-white">3. Seeding Locks:</strong> Lock a segment of the weapon (e.g. muzzle barrel or stock) and hit execute to rotate adjacent grids without losing your styling structure!
              </p>
              <p>
                <strong className="text-white">4. Palette Swapping (Hex editing):</strong> Hover and click on any custom colored hexagon block inside the active palette swapper bar to choose your customized colors. Re-renders instantly without regeneration.
              </p>
              <p>
                <strong className="text-white">5. Sound Effects:</strong> Toggle synthesizer signals on the top-right header configuration bar.
              </p>
              <p>
                <strong className="text-white">6. Sharing structures:</strong> Press "Share Link" to generate unique bookmark URLs enclosing all seed variables and locked traits.
              </p>
            </div>

            <button 
              id="close-help-modal"
              onClick={() => {
                playSfx('lock');
                setShowHelpModal(false);
              }}
              className="mt-2 w-full bg-[#00FF41] text-black py-2.5 font-bold tracking-widest text-[10px] hover:brightness-110 select-none cursor-pointer rounded-xs"
            >
              CLOSE MANUAL
            </button>
          </div>
        </div>
      )}

      {/* ENCLOSED LOCAL STYLES FOR THE ROTATING TICKER MARQUEE */}
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(10%); }
          100% { transform: translateX(-100%); }
        }
        .animate-marquee {
          animation: marquee 25s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
        .image-render-pixelated {
          image-rendering: pixelated;
          image-rendering: crisp-edges;
        }
        /* Custom ranges styling */
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none;
          background: #00FF41;
          height: 12px;
          width: 12px;
          border-radius: 2px;
          box-shadow: 0 0 10px #00FF41;
        }
      `}</style>
    </div>
  );
}
