/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WeaponCategory = 'old' | 'modern' | 'jungle' | 'alien' | 'high-tech';

export type Pov = 'side_left' | 'side_right' | 'top_down' | 'diagonal_iso';

export type ShadingStyle = 'flat' | 'dithered' | 'outlined';

export interface WeaponMeta {
  dominant_colors: string[];
  weapon_class: string;
  era: string;
  lore_blurb: string;
}

export interface WeaponModel {
  id: string;
  weapon: string;
  category: WeaponCategory;
  pov: Pov;
  grid_size: [number, number]; // [width, height]
  palette: string[]; // list of hex or color strings (including "transparent")
  pixels: number[][]; // 2D array of palette indices [y][x]
  meta: WeaponMeta;
  seed: number;
  prompt?: string;
  pixel_size: number; // grid size e.g. 16, 24, 32, 64
  palette_count: number;
  shading: ShadingStyle;
  // Locked sections indicator
  locked_parts: {
    barrel: boolean;
    body: boolean;
    stock: boolean;
    grip: boolean;
  };
}

export interface CategoryConfig {
  name: string;
  description: string;
  palette_max: number;
  dithering: boolean;
  outline: 'dark_brown' | 'black' | 'dark_green' | 'glow_effect' | 'chrome_edge';
  accentColor: string;
  bgGradient: string;
}

export const CATEGORIES: Record<WeaponCategory, CategoryConfig> = {
  'old': {
    name: 'Old Weapons',
    description: 'Muskets, flintlocks, cannons — muted browns, aged metal, wood grain pixel texture',
    palette_max: 8,
    dithering: true,
    outline: 'dark_brown',
    accentColor: '#8B4513',
    bgGradient: 'from-amber-950 to-orange-950',
  },
  'modern': {
    name: 'Modern Weapons',
    description: 'Assault rifles, pistols, shotguns — gunmetal grays, tactical blacks, polymer blacks',
    palette_max: 12,
    dithering: false,
    outline: 'black',
    accentColor: '#4A5568',
    bgGradient: 'from-slate-900 to-zinc-900',
  },
  'jungle': {
    name: 'Jungle Weapons',
    description: 'Blowguns, machetes, booby-trap guns — earthy greens, bone, vine-wrapped stocks',
    palette_max: 10,
    dithering: true,
    outline: 'dark_green',
    accentColor: '#2F855A',
    bgGradient: 'from-emerald-950 to-stone-900',
  },
  'alien': {
    name: 'Alien Weapons',
    description: 'Bio-organic, crystalline, plasma — neon purples, bioluminescent greens, anti-gravity silhouettes',
    palette_max: 16,
    dithering: false,
    outline: 'glow_effect',
    accentColor: '#9F7AEA',
    bgGradient: 'from-fuchsia-950 to-indigo-950',
  },
  'high-tech': {
    name: 'High-Tech Weapons',
    description: 'Railguns, energy cannons, nano-rifles — chrome, electric blue, holographic overlays',
    palette_max: 20,
    dithering: false,
    outline: 'chrome_edge',
    accentColor: '#3182CE',
    bgGradient: 'from-cyan-950 to-slate-950',
  },
};

export const POVS: Record<Pov, { name: string; label: string; icon: string }> = {
  'side_left': {
    name: 'Side View (Left)',
    label: '◀ Side L',
    icon: 'ArrowLeftRight',
  },
  'side_right': {
    name: 'Side View (Right)',
    label: '▶ Side R',
    icon: 'ArrowRightLeft',
  },
  'top_down': {
    name: 'Top-Down View',
    label: '↓ Top',
    icon: 'ArrowDown',
  },
  'diagonal_iso': {
    name: 'Diagonal / Iso View',
    label: '◢ Iso',
    icon: 'Orbit',
  },
};
