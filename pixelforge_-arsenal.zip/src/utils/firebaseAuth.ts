/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User,
  signOut
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { WeaponModel } from '../types';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Required Google Drive scopes
provider.addScope('https://www.googleapis.com/auth/drive');

// Cache the access token in memory
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Initialize auth state listener
export const initAuth = (
  onAuthSuccess: (user: User, token: string) => void,
  onAuthFailure: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // Safe check or wait
        onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      onAuthFailure();
    }
  });
};

// Start popup sign in flow
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to retrieve Google Drive access token.');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

// Clear session
export const logout = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

export const getAccessToken = (): string | null => {
  return cachedAccessToken;
};

// --- GOOGLE DRIVE API OPERATIONS ---

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  createdTime: string;
}

/**
 * Lists weapon configurations stored in the user's Google Drive.
 * Files are matched by having name prefixed with 'pixelforge_weapon_' or containing the 'PixelForge' tag.
 */
export const listDriveWeapons = async (token: string): Promise<DriveFile[]> => {
  const q = "name contains 'pixelforge_' and mimeType = 'application/json' and trashed = false";
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name,mimeType,createdTime)&orderBy=createdTime%20desc`;
  
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!response.ok) {
    throw new Error(`Google Drive list failed: ${response.statusText}`);
  }

  const data = await response.json();
  return data.files || [];
};

/**
 * Saves/Uploads a WeaponModel JSON to Google Drive
 */
export const saveWeaponToDrive = async (
  token: string,
  weapon: WeaponModel
): Promise<{ id: string; name: string }> => {
  const fileName = `pixelforge_${weapon.weapon.toLowerCase().replace(/\s+/g, '_')}_${weapon.seed}.json`;
  
  // 1. Create File Metadata
  const metadataUrl = 'https://www.googleapis.com/drive/v3/files';
  const metadataResponse = await fetch(metadataUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: fileName,
      mimeType: 'application/json',
      description: `PixelForge AI Retro Gun Weapon Spec. Seed: ${weapon.seed}, Category: ${weapon.category}.`
    })
  });

  if (!metadataResponse.ok) {
    throw new Error(`Failed to create file metadata: ${metadataResponse.statusText}`);
  }

  const metadata = await metadataResponse.json();
  const fileId = metadata.id;

  // 2. Upload JSON Content (PATCH with media content)
  const mediaUrl = `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`;
  const mediaResponse = await fetch(mediaUrl, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(weapon)
  });

  if (!mediaResponse.ok) {
    throw new Error(`Failed to write file content to Drive: ${mediaResponse.statusText}`);
  }

  return { id: fileId, name: fileName };
};

/**
 * Loads a WeaponModel JSON from Google Drive
 */
export const loadWeaponFromDrive = async (
  token: string,
  fileId: string
): Promise<WeaponModel> => {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch file content: ${response.statusText}`);
  }

  const weaponData = await response.json();
  return weaponData as WeaponModel;
};

/**
 * Deletes a file from Google Drive (Trashes it)
 */
export const deleteWeaponFromDrive = async (
  token: string,
  fileId: string
): Promise<void> => {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}`;
  
  const response = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      trashed: true
    })
  });

  if (!response.ok) {
    throw new Error(`Failed to delete file: ${response.statusText}`);
  }
};
