/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeaponCategory, Pov, ShadingStyle, WeaponModel, WeaponMeta } from '../types';

// Simple deterministic random generator based on a seed
export function createRandom(seed: number) {
  let s = Math.abs(seed | 0) || 1;
  return function() {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

// Generate a random seed
export function generateRandomSeed(): number {
  return Math.floor(Math.random() * 1000000) + 1;
}

// Identify which weapon part a pixel belongs to (centered for side_left)
// Parts: 'barrel', 'body', 'stock', 'grip'
export function getPixelPart(
  x: number,
  y: number,
  W: number,
  H: number,
  pov: Pov
): 'barrel' | 'body' | 'stock' | 'grip' {
  // Flip division depending on orientation
  const isRightPointing = pov === 'side_right';
  
  if (pov === 'top_down') {
    // Symmetrical top-down gun: Stock at far-right side, Barrel at far-left, Body in center, handle wings as grippy elements
    if (x < W * 0.35) return 'barrel';
    if (x >= W * 0.75) return 'stock';
    // Symmetric wings
    if (x >= W * 0.45 && x <= W * 0.65 && (y < H * 0.3 || y > H * 0.7)) return 'grip';
    return 'body';
  }
  
  if (pov === 'diagonal_iso') {
    // Diagonally angled (e.g., bottom-left to top-right)
    // We can partition by diagonal boundaries
    const offset = x + y;
    const maxOffset = W + H;
    if (offset < maxOffset * 0.35) return 'barrel';
    if (offset > maxOffset * 0.75) return 'stock';
    // Lower right grip area
    if (x > W * 0.4 && y > H * 0.5) return 'grip';
    return 'body';
  }

  // Horizontal side views
  if (isRightPointing) {
    // Side view right pointing right: Barrel is on right, Stock on left
    if (x < W * 0.28) return 'stock';
    if (x > W * 0.65) return 'barrel';
    if (y >= H * 0.5 && x >= W * 0.28 && x <= W * 0.52) return 'grip';
    return 'body';
  } else {
    // Side view left pointing left (default): Barrel is on left, Stock on right
    if (x < W * 0.35) return 'barrel';
    if (x > W * 0.72) return 'stock';
    if (y >= H * 0.5 && x >= W * 0.48 && x <= W * 0.72) return 'grip';
    return 'body';
  }
}

// Map weapon names list for random generation
const WEAPON_NAMES: Record<WeaponCategory, { prefixes: string[]; bases: string[]; suffixes: string[] }> = {
  'old': {
    prefixes: ['Gilded', 'Rusty', 'Imperial', 'Aged', 'Antique', 'Flint', 'Scurvy'],
    bases: ['Musket', 'Pistol', 'Blunderbuss', 'Carbine', 'Arquebus', 'Hand Cannon'],
    suffixes: ['of the Gallows', 'of Concord', 'from 1776', 'Forge-Crafted', 'Privateer Special']
  },
  'modern': {
    prefixes: ['Tactical', 'Spec-Ops', 'Stealth', 'Subcom', 'Shadow', 'Operator', 'Rupture'],
    bases: ['Assault Rifle', 'Magnum', 'Pump Shotgun', 'SMG', 'Sniper Rifle', 'Carbine'],
    suffixes: ['Mk-IV', 'Socom', 'Interceptor', 'Elite', 'Enforcer', 'Specter']
  },
  'jungle': {
    prefixes: ['Voodoo', 'Poison-Dart', 'Totem', 'Shamanic', 'Overgrown', 'Feral', 'Swamp'],
    bases: ['Blowpin Rifle', 'Bone Machete', 'Barb Launcher', 'Vine Bow', 'Thorn Cannon'],
    suffixes: ['of the Viper', 'Deep Forest', 'Wasp Nest', 'Root-Bound', 'Tribe Defender']
  },
  'alien': {
    prefixes: ['Chrono', 'Astral', 'Nebula', 'Biolume', 'Abyssal', 'Cosmic', 'Warp'],
    bases: ['Plasma Discharger', 'Bio-Rifle', 'Void Ray', 'Crystal Spiker', 'Quantum Obliterator'],
    suffixes: ['of Elpis', 'Alpha-V', 'Singularity', 'Wormhole Conduit', 'Genesis']
  },
  'high-tech': {
    prefixes: ['Nano', 'Holographic', 'Rail', 'Strobe', 'Vector', 'Photon', 'Cryo'],
    bases: ['Energy Rifle', 'Railgun', 'Heavy Laser', 'Fusion Pistol', 'Pulse Shotgun'],
    suffixes: ['Hyperion', 'Zero-Kelvin', 'Pulse-V2', 'Matrix', 'Apex', 'Titan']
  }
};

const STATS_CLASS: Record<WeaponCategory, string[]> = {
  'old': ['Kinetic / Powder', 'Ballistic / Fire'],
  'modern': ['Ballistic / Heavy', 'Kinetic / Armor-Piercing'],
  'jungle': ['Toxic / Bio', 'Poison / Slashing'],
  'alien': ['Plasma / Dark Energy', 'Disintegration / Crystal'],
  'high-tech': ['Voltaic / Hologram', 'Laser / Quantum Beam']
};

const ERAS: Record<WeaponCategory, string[]> = {
  'old': ['Pre-Industrial (17th Century)', 'Guild & Sails Era', 'Aged Imperial'],
  'modern': ['Late 20th Century', 'Active Military Standard', 'Modern PMCs'],
  'jungle': ['Ancient Herbalist Tribe', 'Primordial Forest Era', 'Primal Overgrowth'],
  'alien': ['Intergalactic Empire Cycle 4', 'Vael-9 Nebula Age', 'Post-Singularity Alien Biospheres'],
  'high-tech': ['Neo-Tokyo Cycle-8', '2240 Solar Federation', 'Deep Space Colony Defense Force']
};

const LORE_BLURBS: Record<WeaponCategory, string[]> = {
  'old': [
    'A sturdy piece of history, retaining the aromatic oak oil from decades spent in ship cargo bays.',
    'Forged with brittle cast iron, this rifle yields immense stopping power accompanied by dense smoke plumes.',
    'Decorated with brass engraving from the privateer wars of old. Smells faintly of salt water.'
  ],
  'modern': [
    'Utilizes a lightweight poly-carbon frame, prized by urban intervention forces for its dampening grips.',
    'A staple of tactical defense, customizable with silencer barrels and long-range high-magnification scopes.',
    'Constructed of anodized gunmetal gray alloy. Highly secure, clean recoil, incredibly reliable.'
  ],
  'jungle': [
    'Carved from the ultra-dense center of ironwood trees and cured of rot with rare forest toad mucus.',
    'Shoots toxic spores that target organic cellular tissue. Adorned with binding ropes and leather strips.',
    'Weapon framework wrapped with living bioluminescent ivy that responds to the user’s pulse.'
  ],
  'alien': [
    'Constructed around a floating dark matter crystal that resonates to synthesize superheated charged particles.',
    'A symbiotic arm tool grown rather than manufactured. Features pulsating skin membranes and biolume tubes.',
    'Bends magnetic fields into standard containment lenses, discharging unstable plasma orbs with high accuracy.'
  ],
  'high-tech': [
    'A high-frequency rail accelerator designed to slide cold chromium slugs through titanium sheets without heat waste.',
    'Contains a liquid nitrogen cooling sleeve that sustains sub-zero holographic laser containment prisms.',
    'Fires condensed light-waves guided by micro-thruster computer cores. Silent, neon, perfectly optimized.'
  ]
};

// Generate randomized info cards
export function generateWeaponMeta(
  category: WeaponCategory,
  name: string,
  random: () => number
): WeaponMeta {
  const cStats = STATS_CLASS[category];
  const cEras = ERAS[category];
  const cLore = LORE_BLURBS[category];
  
  const rcStat = cStats[Math.floor(random() * cStats.length)];
  const rcEra = cEras[Math.floor(random() * cEras.length)];
  const rcLore = cLore[Math.floor(random() * cLore.length)];

  // Generate an elegant palette selection
  let domColors: string[] = [];
  if (category === 'old') domColors = ['#8B4513', '#D2B48C'];
  else if (category === 'modern') domColors = ['#1A202C', '#718096'];
  else if (category === 'jungle') domColors = ['#276749', '#E2E8F0'];
  else if (category === 'alien') domColors = ['#805AD5', '#319795'];
  else if (category === 'high-tech') domColors = ['#1A365D', '#319795'];

  return {
    dominant_colors: domColors,
    weapon_class: rcStat,
    era: rcEra,
    lore_blurb: `${name}: ${rcLore}`
  };
}

// Generate Palette based on category and slider palette count
export function buildPaletteForCategory(
  category: WeaponCategory,
  count: number,
  random: () => number
): string[] {
  const palette: string[] = ['transparent']; // index 0 is always transparent
  
  // Base colors
  let outlineColor = '#000000';
  let bodyColor = '#555555';
  let bodyHighlight = '#aaaaaa';
  let accessoryColor = '#777777';
  let gripColor = '#333333';
  let energyColor = '#ff0000';
  let energyGlow = '#ff7777';

  if (category === 'old') {
    outlineColor = '#3d2516'; // dark brown
    bodyColor = '#8b5a2b'; // wood brown
    bodyHighlight = '#cd853f'; // peru wood grain
    accessoryColor = '#c0c0c0'; // steel
    gripColor = '#4a2f13'; // dark leather grip
    energyColor = '#ffd700'; // gold inlay
    energyGlow = '#ffe4b5'; // moccasin
  } else if (category === 'modern') {
    outlineColor = '#111111';
    bodyColor = '#333b49'; // slate grey
    bodyHighlight = '#5a6b7c'; // cool gray
    accessoryColor = '#1e2530'; // tactical black
    gripColor = '#151a22'; // carbon black
    energyColor = '#22c55e'; // laser sight green
    energyGlow = '#86efac'; 
  } else if (category === 'jungle') {
    outlineColor = '#14301d'; // very dark forest green
    bodyColor = '#2d6a4f'; // jungle green
    bodyHighlight = '#74c69d'; // light leaf green
    accessoryColor = '#e9d8a6'; // bone gold
    gripColor = '#402e21'; // vine wrap / bark brown
    energyColor = '#ec4899'; // poison orchid pink
    energyGlow = '#fbcfe8';
  } else if (category === 'alien') {
    outlineColor = '#120421'; // void purple
    bodyColor = '#6b21a8'; // deep magenta/purple
    bodyHighlight = '#a855f7'; // crystal violet
    accessoryColor = '#111827'; // obsidian black
    gripColor = '#1e1b4b'; // dark bio-leather
    energyColor = '#a855f7'; // plasma core purple/glow
    energyGlow = '#f472b6'; // hot bioluminescent core
  } else if (category === 'high-tech') {
    outlineColor = '#0b132b'; // deep space navy
    bodyColor = '#0066cc'; // glossy electric blue
    bodyHighlight = '#33ccff'; // holographic cyan
    accessoryColor = '#1c2541'; // cobalt steel
    gripColor = '#0b0c10'; // matte black armor
    energyColor = '#00ffff'; // laser neon
    energyGlow = '#ffffff'; // blazing core
  }

  // Populate palette with custom gradients/variations up to count
  palette.push(outlineColor); // index 1 is outline
  palette.push(bodyColor); // index 2
  palette.push(bodyHighlight); // index 3
  palette.push(accessoryColor); // index 4
  palette.push(gripColor); // index 5
  palette.push(energyColor); // index 6
  palette.push(energyGlow); // index 7

  // Fill up remaining indices up to count
  const remainingCount = Math.max(8, count);
  while (palette.length < remainingCount) {
    // interpolation between body, highlights, and energy
    const ratio = random();
    if (ratio < 0.4) {
      // Darker shading of body
      palette.push(adjustHexBrightness(bodyColor, -0.2));
    } else if (ratio < 0.7) {
      // Lighter highlights of energy
      palette.push(adjustHexBrightness(energyColor, 0.2));
    } else {
      // Intermediate steel/cyber highlight
      palette.push(adjustHexBrightness(accessoryColor, 0.1));
    }
  }

  // Limit to exactly `count` or keep elements
  return palette.slice(0, count);
}

// Helper to dim/brighten colors deterministic for pixel variation
function adjustHexBrightness(hex: string, percent: number): string {
  try {
    let R = parseInt(hex.substring(1, 3), 16);
    let G = parseInt(hex.substring(3, 5), 16);
    let B = parseInt(hex.substring(5, 7), 16);

    R = Math.min(255, Math.max(0, Math.floor(R * (1 + percent))));
    G = Math.min(255, Math.max(0, Math.floor(G * (1 + percent))));
    B = Math.min(255, Math.max(0, Math.floor(B * (1 + percent))));

    const rHex = R.toString(16).padStart(2, '0');
    const gHex = G.toString(16).padStart(2, '0');
    const bHex = B.toString(16).padStart(2, '0');

    return `#${rHex}${gHex}${bHex}`;
  } catch {
    return hex;
  }
}

// Generate base name for seed / weapon type
export function generateWeaponName(category: WeaponCategory, seed: number): string {
  const random = createRandom(seed);
  const words = WEAPON_NAMES[category];
  
  const prefix = words.prefixes[Math.floor(random() * words.prefixes.length)];
  const base = words.bases[Math.floor(random() * words.bases.length)];
  const suffix = words.suffixes[Math.floor(random() * words.suffixes.length)];
  
  return `${prefix} ${base} ${suffix}`;
}

// Primary Procedural Generator Engine for Gun Designs
export function generateProceduralWeapon(
  category: WeaponCategory,
  pov: Pov,
  gridWidth: number,
  gridHeight: number,
  seed: number,
  promptText: string,
  shading: ShadingStyle = 'dithered',
  paletteCount: number = 10,
  oldWeapon: WeaponModel | null = null
): WeaponModel {
  const random = createRandom(seed);
  const name = generateWeaponName(category, seed);
  const meta = generateWeaponMeta(category, name, random);

  // 1. Build beautiful custom palette
  const palette = buildPaletteForCategory(category, paletteCount, random);

  // 2. Initialize pixel grid
  const cols = gridWidth;
  const rows = gridHeight;
  const grid: number[][] = Array.from({ length: rows }, () => Array(cols).fill(0));

  // Determine key horizontal line on y axis (center height)
  const centerLine = Math.floor(rows / 2);

  // Generate pixels deterministic per coordinates
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      // Find what part this pixel coordinates map to
      const partType = getPixelPart(x, y, cols, rows, pov);

      // Check lock parts system:
      // If we have an matching oldWeapon with same grid size, we can seamlessly merge locked parts
      if (oldWeapon && oldWeapon.grid_size[0] === cols && oldWeapon.grid_size[1] === rows) {
        let isPartLocked = false;
        if (partType === 'barrel' && oldWeapon.locked_parts.barrel) isPartLocked = true;
        if (partType === 'body' && oldWeapon.locked_parts.body) isPartLocked = true;
        if (partType === 'stock' && oldWeapon.locked_parts.stock) isPartLocked = true;
        if (partType === 'grip' && oldWeapon.locked_parts.grip) isPartLocked = true;

        if (isPartLocked) {
          // Keep pixel from old weapon
          grid[y][x] = oldWeapon.pixels[y]?.[x] ?? 0;
          continue;
        }
      }

      // Generate unlocked pixels procedurally depending on POV
      if (pov === 'top_down') {
        const distFromCenter = Math.abs(y - centerLine);
        
        if (partType === 'barrel') {
          // Symmetrical thin barrel pointing left
          if (distFromCenter <= 1 && x > cols * 0.05) {
            // Shiny index or nozzle
            grid[y][x] = x === Math.floor(cols * 0.05) ? 6 : (distFromCenter === 0 ? 3 : 2);
          }
        } else if (partType === 'body') {
          // Broad central housing
          const bodyThickness = Math.floor(rows * 0.18) + 1;
          if (distFromCenter <= bodyThickness) {
            const index = Math.floor(random() * 3) + 2; // mix indices [2..4]
            grid[y][x] = index;
            // Add charging neon cores down the center
            if (distFromCenter === 0 && x > cols * 0.45 && x < cols * 0.65) {
              grid[y][x] = 6; // bright energetic core
            }
          }
        } else if (partType === 'stock') {
          // Symmetrical stock on right
          const stockThickness = Math.floor(rows * 0.12) + 1;
          if (distFromCenter <= stockThickness) {
            grid[y][x] = 5; // auxiliary color
          }
        } else if (partType === 'grip') {
          // Symmetric grip triggers extending outwards on y axis
          if (distFromCenter > 2 && distFromCenter < rows * 0.45) {
            grid[y][x] = 4; // Grip brown/leather
          }
        }
      }
      
      else if (pov === 'diagonal_iso') {
        // Angled barrel pointing up-left, grip on bottom-right, body center
        // Let's model a 3/4 perspective diagonal weapon drawing
        // Line equation x + y near middle-left to bottom-right
        const diagDist = Math.abs((x * 0.6 + y * 1.0) - (cols * 0.45));
        const thickness = partType === 'barrel' ? 1.5 : (partType === 'body' ? 3.5 : 2.5);

        if (diagDist <= thickness) {
          if (partType === 'barrel') {
            grid[y][x] = random() > 0.3 ? 2 : 3;
            // Laser core at nozzle
            if (x === 0 || y === 0) grid[y][x] = 6;
          } else if (partType === 'body') {
            grid[y][x] = random() > 0.5 ? 4 : 2;
            // Hologram display overlay
            if (x > cols * 0.4 && x < cols * 0.55 && y > rows * 0.25 && y < rows * 0.45) {
              grid[y][x] = 6;
            }
          } else if (partType === 'stock') {
            grid[y][x] = 5;
          }
        }
        
        // Handle trigger separate projection in iso
        if (partType === 'grip') {
          const gripDist = Math.abs((x * 0.35 + y * 1.5) - (cols * 0.9));
          if (gripDist <= 2.2 && x > cols * 0.45 && y > rows * 0.5) {
            grid[y][x] = 4;
          }
        }
      } 
      
      else {
        // Horizontal side views (classic profiles)
        const isRightPointing = pov === 'side_right';
        
        if (partType === 'barrel') {
          const barrelTop = Math.floor(rows * 0.38);
          const barrelBottom = Math.floor(rows * 0.48);
          
          if (y >= barrelTop && y <= barrelBottom) {
            // Draw barrel
            grid[y][x] = 2; // Metal/Body
            
            // Render muzzle flash or shiny steel tips
            const nozzleTip = isRightPointing ? (x === cols - 1) : (x === 0);
            if (nozzleTip) {
              grid[y][x] = 6; // Neon plasma/steel glare tip
            }

            // High-tech overlays / Underbarrel lasers 
            if (category === 'high-tech' && y === barrelBottom) {
              grid[y][x] = 6; // glowing energy edge ribbon
            }
            if (category === 'jungle' && y === barrelBottom && x % 4 === 0) {
              grid[y][x] = 3; // Leafy nodules
            }
          }
        } 
        
        else if (partType === 'body') {
          const bodyTop = Math.floor(rows * 0.28);
          const bodyBottom = Math.floor(rows * 0.58);
          
          if (y >= bodyTop && y <= bodyBottom) {
            grid[y][x] = 3; // Body highlight color
            
            // Add chamber/plasma core in the deep center
            if (category === 'alien' && y >= bodyTop + 2 && y <= bodyBottom - 2 && x > cols * 0.4 && x < cols * 0.6) {
              grid[y][x] = 6; // bioluminescent bulb
            }
            if (category === 'high-tech' && y === bodyTop + 1 && x > cols * 0.38 && x < cols * 0.58) {
              grid[y][x] = 7; // cyber core hologram
            }
            
            // Differentiate frame design slightly
            if (y === bodyBottom && random() > 0.6) {
              grid[y][x] = 1; // trigger slot shading
            }
          }
          
          // Scope/Iron sight attachments
          const hasScope = random() > 0.4;
          if (hasScope && y === bodyTop - 1 && x > cols * 0.4 && x < cols * 0.55) {
            grid[y][x] = 4; // scope housing
            if (x === Math.floor(cols * 0.48)) grid[y][x] = 6; // glass sight crosshair
          }
        } 
        
        else if (partType === 'stock') {
          // Stock fills backward vertical block representing support
          const stockTop = Math.floor(rows * 0.25);
          const stockBottom = Math.floor(rows * 0.62);
          
          if (y >= stockTop && y <= stockBottom) {
            // Cutouts / gaps in stock for futuristic silhouettes
            let shouldCarve = false;
            if (category === 'alien' && x > cols * 0.8 && y > rows * 0.35 && y < rows * 0.5) {
              shouldCarve = true; // crystal holes in alien weapon
            }
            if (category === 'high-tech' && x > cols * 0.82 && x < cols * 0.92 && y > rows * 0.38 && y < rows * 0.52) {
              shouldCarve = true; // anti-gravity gap stock
            }
            if (!shouldCarve) {
              grid[y][x] = 5; // Secondary stock color (wood / polymer)
            }
          }
        } 
        
        else if (partType === 'grip') {
          // Handle angled grip extending downwards
          const gripAngleOffset = Math.floor((y - rows * 0.5) * 0.5);
          const gripX = isRightPointing 
            ? Math.floor(cols * 0.35) + gripAngleOffset 
            : Math.floor(cols * 0.55) - gripAngleOffset;
            
          if (Math.abs(x - gripX) <= 1 && y >= rows * 0.45 && y < rows * 0.85) {
            grid[y][x] = 4; // grip
            if (category === 'jungle' && y % 2 === 0) {
              grid[y][x] = 3; // green vines wrapped
            }
          }
        }
      }
    }
  }

  // 3. Post-process: Enforce outlines & shading (dithering is drawn on Canvas, outline pixels generated here or canvas)
  // Ensure we add an outline pixel to make it look clean and tight!
  // This procedural layout has raw geometry, we add dark lines (index 1) to all pixels adjacent to transparent
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (grid[y][x] > 1) {
        // check neighbors: if any is transparent (0) or edge of grid, mark outline sometimes
        const isEdge = x === 0 || x === cols - 1 || y === 0 || y === rows - 1;
        let neighborsTransparent = false;
        
        const dxs = [-1, 1, 0, 0];
        const dys = [0, 0, -1, 1];
        for (let i = 0; i < 4; i++) {
          const nx = x + dxs[i];
          const ny = y + dys[i];
          if (nx < 0 || nx >= cols || ny < 0 || ny >= rows || grid[ny][nx] === 0) {
            neighborsTransparent = true;
            break;
          }
        }
        
        if (isEdge || neighborsTransparent) {
          // Only change if it wasn't solid core
          if (random() > 0.25) {
            // Keep body intact but shield outline edges with index 1
            // Except for highlight/laser tips
            if (grid[y][x] !== 6 && grid[y][x] !== 7) {
              grid[y][x] = 1; // Mark outline!
            }
          }
        }
      }
    }
  }

  // Unique identifier for saves
  const id = `weapon_${category}_${pov}_${seed}_${Date.now()}`;

  return {
    id,
    weapon: name,
    category,
    pov,
    grid_size: [cols, rows],
    palette,
    pixels: grid,
    meta,
    seed,
    prompt: promptText,
    pixel_size: gridWidth,
    palette_count: paletteCount,
    shading,
    locked_parts: oldWeapon ? oldWeapon.locked_parts : {
      barrel: false,
      body: false,
      stock: false,
      grip: false,
    }
  };
}
