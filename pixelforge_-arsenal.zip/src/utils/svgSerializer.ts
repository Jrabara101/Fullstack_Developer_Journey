/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeaponModel, POVS, Pov } from '../types';

/**
 * Converts a weapon's pixel grid into a clean, standalone, vector-perfect SVG string.
 * Each solid pixel becomes a <rect> element, maintaining pixel precision without blurring.
 */
export function serializeWeaponToSvg(
  weapon: WeaponModel, 
  outlineStyle: 'dark_brown' | 'black' | 'dark_green' | 'glow_effect' | 'chrome_edge'
): string {
  const [cols, rows] = weapon.grid_size;
  const palette = weapon.palette;
  const pixels = weapon.pixels;

  // Set grid rendering dimensions
  const pixelWidth = 10;
  const pixelHeight = 10;
  const svgWidth = cols * pixelWidth;
  const svgHeight = rows * pixelHeight;

  // Map outline style properties
  let outlineFilter = '';
  if (outlineStyle === 'glow_effect') {
    outlineFilter = `
    <defs>
      <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="1.5" result="blur" />
        <feComponentTransfer in="blur" result="glow1">
          <feFuncA type="linear" slope="1.5" />
        </feComponentTransfer>
        <feMerge>
          <feMergeNode in="glow1" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>
    `;
  } else if (outlineStyle === 'chrome_edge') {
    outlineFilter = `
    <defs>
      <linearGradient id="chrome-grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.9" />
        <stop offset="100%" stop-color="#3b82f6" stop-opacity="0.4" />
      </linearGradient>
    </defs>
    `;
  }

  let rectsHtml = '';

  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const idx = pixels[y]?.[x] ?? 0;
      if (idx === 0) continue; // Skip transparency

      const color = palette[idx] || '#000000';
      const px = x * pixelWidth;
      const py = y * pixelHeight;

      // Handle custom outline or shading visual styles inside individual SVG tags
      let styleAttr = '';
      if (idx === 1) { // Outline index
        if (outlineStyle === 'glow_effect') {
          styleAttr = ' filter="url(#glow)"';
        } else if (outlineStyle === 'chrome_edge') {
          // metallic shimmer stroke or fill
          styleAttr = ' fill="url(#chrome-grad)"';
        }
      }

      const rectFill = styleAttr ? '' : ` fill="${color}"`;
      rectsHtml += `  <rect x="${px}" y="${py}" width="${pixelWidth}" height="${pixelHeight}"${rectFill}${styleAttr} shape-rendering="crispEdges" />\n`;
    }
  }

  // Construct complete clean XML structure
  return `<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${svgWidth} ${svgHeight}" width="${svgWidth}" height="${svgHeight}">
  <style>
    rect { stroke-width: 0px; }
  </style>
${outlineFilter}
  <!-- PixelForge: Arsenal - Procedural Retro Art Generator -->
  <!-- Weapon Name: ${weapon.weapon} | Category: ${weapon.category} | POV: ${weapon.pov} -->
  <!-- Generated Seed: ${weapon.seed} -->
${rectsHtml}</svg>`;
}

/**
 * Downloads a generated SVG file from browser memory.
 */
export function triggerSvgDownload(
  weapon: WeaponModel, 
  outlineStyle: 'dark_brown' | 'black' | 'dark_green' | 'glow_effect' | 'chrome_edge'
) {
  const svgContent = serializeWeaponToSvg(weapon, outlineStyle);
  const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `${weapon.weapon.replace(/\s+/g, '_')}_${weapon.pov}.svg`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Packs Spritesheet metadata and renders tiled grids.
 */
export interface SpritesheetMetadata {
  weapon_name: string;
  category: string;
  grid_size: [number, number];
  frames: Record<Pov, { x: number; y: number; w: number; h: number }>;
}

export function generateSpritesheetMetadata(weapon: WeaponModel): string {
  const [w, h] = weapon.grid_size;
  const metadata: SpritesheetMetadata = {
    weapon_name: weapon.weapon,
    category: weapon.category,
    grid_size: weapon.grid_size,
    frames: {
      side_left: { x: 0, y: 0, w, h },
      side_right: { x: w, y: 0, w, h },
      top_down: { x: 0, y: h, w, h },
      diagonal_iso: { x: w, y: h, w, h },
    }
  };
  return JSON.stringify(metadata, null, 2);
}

/**
 * Download Spritesheet JSON metadata layout.
 */
export function triggerMetadataDownload(weapon: WeaponModel) {
  const jsonContent = generateSpritesheetMetadata(weapon);
  const blob = new Blob([jsonContent], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `${weapon.weapon.replace(/\s+/g, '_')}_spritesheet_meta.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
