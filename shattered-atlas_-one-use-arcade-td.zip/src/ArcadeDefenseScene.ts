import * as THREE from 'three';
import * as xb from 'xrblocks';
import { ArcadeSynth } from './audio/ArcadeSynth';
import { TOWER_SPECS } from './constants';
import {
  createInitialSimulationState,
  createRunSnapshot,
  deploySingleUseTower,
  getCollectedMapCount,
  stepSimulationTick,
  triggerSingleUseEmp,
} from './game/rules';
import { ParticlePool } from './scene/ParticlePool';
import {
  ArenaEnvironmentRig,
  createEnemyModel,
  createMapFragmentModel,
  createPlayerTrackballModel,
  createRetroArcadeArena,
  createSingleUseTowerModel,
  EnemyRig,
  PlayerOrbRig,
} from './scene/ProceduralModels';
import { ArcadeTextureSet, createArcadeTextureSet } from './scene/ProceduralTextures';
import {
  GameSimulationState,
  RunSnapshot,
  ShatterEvent,
  TowerType,
} from './types';
import { GameShellUI } from './ui/GameShellUI';

interface TransientBeam {
  mesh: THREE.Mesh;
  age: number;
  maxLife: number;
}

const _raycaster = new THREE.Raycaster();
const _ndcPointer = new THREE.Vector2();
const _playfieldPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const _hitPoint = new THREE.Vector3();
const _camTargetPos = new THREE.Vector3();
const _camLookAt = new THREE.Vector3();
const _currentLookAt = new THREE.Vector3(0, 0.5, 0);

export class ArcadeDefenseScene extends xb.Script {
  private isSoftwareGl: boolean;
  private state: GameSimulationState;
  private snapshot: RunSnapshot | null = null;
  private synth = new ArcadeSynth();
  private shellUI!: GameShellUI;

  private textures!: ArcadeTextureSet;
  private arenaRig!: ArenaEnvironmentRig;
  private playerRig!: PlayerOrbRig;
  private particles!: ParticlePool;

  private mapFragmentMeshes = new Map<number, THREE.Group>();
  private towerMeshes = new Map<number, THREE.Group>();
  private enemyRigs = new Map<number, EnemyRig>();
  private tokenMeshes = new Map<number, THREE.Mesh>();
  private activeBeams: TransientBeam[] = [];

  private tokenGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.08, 16);
  private tokenMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    emissive: 0xd97706,
    emissiveIntensity: 0.75,
    metalness: 0.85,
    roughness: 0.2,
  });

  // XR Blocks Spatial UI Card mounted on the North Arcade Marquee Arch
  private spatialMarqueeCard!: xb.UICard;
  private spatialStatusText!: xb.UIText;
  private spatialShatterText!: xb.UIText;
  private validatedSpatialUI = false;

  // Input & Simulation Feel
  private keysHeld = new Set<string>();
  private pointerWorldTarget: { x: number; z: number } | null = null;
  private pointerThrustActive = false;
  private hitstopTimer = 0;
  private cameraTrauma = 0;
  private titleTourTime = 0;

  private onKeyDownBound = (e: KeyboardEvent) => this.handleKeyDown(e);
  private onKeyUpBound = (e: KeyboardEvent) => this.handleKeyUp(e);
  private onBlurBound = () => this.clearHeldInputs();
  private onPointerDownBound = (e: PointerEvent) => this.handlePointerDown(e);
  private onPointerMoveBound = (e: PointerEvent) => this.handlePointerMove(e);
  private onPointerUpBound = () => this.handlePointerUp();

  constructor(isSoftwareGl = false) {
    super();
    this.isSoftwareGl = isSoftwareGl;
    this.state = createInitialSimulationState(0);
  }

  public init(): void {
    const renderer = xb.core.renderer as THREE.WebGLRenderer | undefined;
    const maxAniso = renderer?.capabilities?.getMaxAnisotropy?.() ?? 4;

    // 1. Scene Atmosphere & Studio 3-Point Lighting Rig
    xb.core.scene.background = new THREE.Color(0x05070e);
    xb.core.scene.fog = new THREE.FogExp2(0x05070e, 0.016);

    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x1e1b4b, 1.95);
    this.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff3d6, 2.6);
    keyLight.position.set(8, 16, 10);
    if (!this.isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.camera.near = 2;
      keyLight.shadow.camera.far = 36;
      const d = 11.5;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    this.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xf43f5e, 1.15);
    rimLight.position.set(-9, 10, -12);
    this.add(rimLight);

    const corePointLight = new THREE.PointLight(0x06b6d4, 3.2, 9);
    corePointLight.position.set(0, 1.8, 6.4);
    this.add(corePointLight);

    const marqueePointLight = new THREE.PointLight(0xf59e0b, 3.0, 11);
    marqueePointLight.position.set(0, 3.6, -8.5);
    this.add(marqueePointLight);

    // 2. Procedural Textures & 3D Composite Models
    this.textures = createArcadeTextureSet(maxAniso);
    this.arenaRig = createRetroArcadeArena(this.textures);
    this.add(this.arenaRig.root);

    this.playerRig = createPlayerTrackballModel(this.textures);
    this.add(this.playerRig.root);

    this.particles = new ParticlePool();
    this.add(this.particles.mesh);

    // Build initial 6 Torn Map Fragments
    this.rebuildMapFragmentMeshes();

    // 3. Built-in XR Blocks Spatial UI Card on the North Arcade Marquee Arch
    this.buildSpatialMarqueeUI();

    // 4. Mount 2D DOM Game Shell UI
    const shellMount = document.getElementById('game-shell') || document.body;
    this.shellUI = new GameShellUI(shellMount, {
      onStartGame: () => this.startNewRun(),
      onResumeGame: () => this.resumeGame(),
      onPauseGame: () => this.pauseGame(),
      onRestartGame: () => this.startNewRun(),
      onReturnTitle: () => this.returnToTitle(),
      onDeployTower: (type) => this.handleDeployTowerAction(type),
      onTriggerEmp: () => this.handleTriggerEmpAction(),
      onToggleMute: () => this.synth.toggleMute(),
    });

    // 5. Connect Desktop & XR Input Listeners
    xb.core.input?.mouseController?.connect?.();
    window.addEventListener('keydown', this.onKeyDownBound);
    window.addEventListener('keyup', this.onKeyUpBound);
    window.addEventListener('blur', this.onBlurBound);
    document.addEventListener('visibilitychange', this.onBlurBound);

    const canvas = xb.core.renderer?.domElement;
    if (canvas) {
      canvas.setAttribute('data-testid', 'arcade-webgl-canvas');
      canvas.addEventListener('pointerdown', this.onPointerDownBound);
      canvas.addEventListener('pointermove', this.onPointerMoveBound);
      window.addEventListener('pointerup', this.onPointerUpBound);
    }

    // Check for ?autostart=1 query param
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      this.startNewRun();
    } else {
      const cam = xb.core.camera;
      if (cam) {
        cam.position.set(2.8, 10.6, 12.6);
        _currentLookAt.set(-2.4, 0.4, -0.2);
        cam.lookAt(_currentLookAt);
      }
      this.syncVisualsFromState(0.016);
      this.shellUI.sync(this.state, this.snapshot);
    }
  }

  private buildSpatialMarqueeUI(): void {
    this.spatialStatusText = new xb.UIText({
      text: 'MAP SHARDS: 0/6 · TOKENS: 95 · WAVE 1',
      pointerEvents: 'none',
      style: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#fef08a',
        textAlign: 'center',
      },
    });

    this.spatialShatterText = new xb.UIText({
      text: 'EVERY DEPLOYED ITEM SHATTERS AFTER 1 USE',
      pointerEvents: 'none',
      style: {
        fontSize: 16,
        color: '#38bdf8',
        textAlign: 'center',
      },
    });

    const quickDeployRow = new xb.UIPanel({
      style: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'center',
        gap: 10,
      },
      children: [
        new xb.UIButton({
          label: 'Pulse [1]',
          onClick: () => this.handleDeployTowerAction(TowerType.PULSE_LASER),
          style: { flexGrow: 1 },
        }),
        new xb.UIButton({
          label: 'Cryo [2]',
          onClick: () => this.handleDeployTowerAction(TowerType.CRYO_CAPACITOR),
          style: { flexGrow: 1 },
        }),
        new xb.UIButton({
          label: 'Tesla [3]',
          onClick: () => this.handleDeployTowerAction(TowerType.TESLA_COIL),
          style: { flexGrow: 1 },
        }),
      ],
    });

    this.spatialMarqueeCard = new xb.UICard({
      size: { width: 1.45, height: 'auto' },
      style: {
        flexDirection: 'column',
        gap: 10,
        padding: 18,
        backgroundColor: 'rgba(11, 16, 34, 0.92)',
        borderRadius: 18,
      },
      children: [this.spatialStatusText, this.spatialShatterText, quickDeployRow],
    });
    this.spatialMarqueeCard.name = 'Arcade Holo-Marquee Card';
    this.spatialMarqueeCard.scale.setScalar(2.6);
    this.spatialMarqueeCard.position.set(0, 2.75, -8.45);
    this.add(this.spatialMarqueeCard);
  }

  private rebuildMapFragmentMeshes(): void {
    for (const mesh of this.mapFragmentMeshes.values()) {
      this.remove(mesh);
    }
    this.mapFragmentMeshes.clear();

    for (const frag of this.state.mapFragments) {
      const model = createMapFragmentModel(frag.index, this.textures);
      model.position.set(frag.x, 0, frag.z);
      this.add(model);
      this.mapFragmentMeshes.set(frag.id, model);
    }
  }

  public startNewRun(): void {
    const prevBest = this.state.bestScore;
    this.clearDynamicMeshes();
    this.state = createInitialSimulationState(prevBest);
    this.state.phase = 'playing';
    this.snapshot = null;
    this.hitstopTimer = 0;
    this.cameraTrauma = 0.15;
    this.clearHeldInputs();
    this.rebuildMapFragmentMeshes();

    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    document.body.dataset.state = 'playing';

    // Snap camera close to gameplay framing on start so transition is crisp
    const cam = xb.core.camera;
    if (cam) {
      cam.position.set(0, 12.2, 13.8);
      _currentLookAt.set(0, 0.2, 0.2);
      cam.lookAt(_currentLookAt);
    }

    this.synth.playCoinInsert();
    this.syncVisualsFromState(0.016);
    this.shellUI.sync(this.state, this.snapshot);
  }

  public pauseGame(): void {
    if (this.state.phase !== 'playing') return;
    this.state.phase = 'paused';
    this.clearHeldInputs();
    document.exitPointerLock?.();
    this.shellUI.sync(this.state, this.snapshot);
  }

  public resumeGame(): void {
    if (this.state.phase !== 'paused') return;
    this.state.phase = 'playing';
    this.clearHeldInputs();
    this.shellUI.sync(this.state, this.snapshot);
  }

  public returnToTitle(): void {
    const prevBest = this.state.bestScore;
    this.clearDynamicMeshes();
    this.state = createInitialSimulationState(prevBest);
    this.state.phase = 'title';
    this.snapshot = null;
    this.clearHeldInputs();
    document.exitPointerLock?.();
    this.rebuildMapFragmentMeshes();
    const cam = xb.core.camera;
    if (cam) {
      cam.position.set(2.8, 10.6, 12.6);
      _currentLookAt.set(-2.4, 0.4, -0.2);
      cam.lookAt(_currentLookAt);
    }
    this.syncVisualsFromState(0.016);
    this.shellUI.sync(this.state, this.snapshot);
  }

  private clearDynamicMeshes(): void {
    for (const m of this.towerMeshes.values()) this.remove(m);
    this.towerMeshes.clear();

    for (const r of this.enemyRigs.values()) this.remove(r.root);
    this.enemyRigs.clear();

    for (const t of this.tokenMeshes.values()) this.remove(t);
    this.tokenMeshes.clear();

    for (const b of this.activeBeams) {
      this.remove(b.mesh);
      b.mesh.geometry.dispose();
      (b.mesh.material as THREE.Material).dispose();
    }
    this.activeBeams = [];
  }

  private clearHeldInputs(): void {
    this.keysHeld.clear();
    this.pointerThrustActive = false;
    this.pointerWorldTarget = null;
  }

  private handleKeyDown(e: KeyboardEvent): void {
    const code = e.code;

    if (this.state.phase === 'title') {
      if (code === 'Enter' || code === 'Space') {
        e.preventDefault();
        this.startNewRun();
      }
      return;
    }

    if (this.state.phase === 'gameover') {
      if (code === 'Enter' || code === 'Space') {
        e.preventDefault();
        this.startNewRun();
      }
      return;
    }

    if (code === 'Escape' || code === 'KeyP') {
      if (!e.repeat) {
        e.preventDefault();
        if (this.state.phase === 'playing') this.pauseGame();
        else if (this.state.phase === 'paused') this.resumeGame();
      }
      return;
    }

    if (this.state.phase !== 'playing') return;

    this.keysHeld.add(code);

    if (e.repeat) return;

    if (code === 'Digit1' || code === 'Numpad1') {
      this.handleDeployTowerAction(TowerType.PULSE_LASER);
    } else if (code === 'Digit2' || code === 'Numpad2') {
      this.handleDeployTowerAction(TowerType.CRYO_CAPACITOR);
    } else if (code === 'Digit3' || code === 'Numpad3') {
      this.handleDeployTowerAction(TowerType.TESLA_COIL);
    } else if (code === 'Digit4' || code === 'Space') {
      e.preventDefault();
      this.handleTriggerEmpAction();
    } else if (code === 'KeyH') {
      this.shellUI.toggleDockCollapsed();
    } else if (code === 'KeyM') {
      const muted = this.synth.toggleMute();
      this.shellUI.updateMuteIcon(muted);
    } else if (code === 'KeyR') {
      this.startNewRun();
    }
  }

  private handleKeyUp(e: KeyboardEvent): void {
    this.keysHeld.delete(e.code);
  }

  private screenToPlayfield(clientX: number, clientY: number): { x: number; z: number } | null {
    const canvas = xb.core.renderer?.domElement;
    const camera = xb.core.camera;
    if (!canvas || !camera) return null;
    const rect = canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return null;

    _ndcPointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    _ndcPointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    _raycaster.setFromCamera(_ndcPointer, camera);

    if (_raycaster.ray.intersectPlane(_playfieldPlane, _hitPoint)) {
      return { x: _hitPoint.x, z: _hitPoint.z };
    }
    return null;
  }

  private handlePointerDown(e: PointerEvent): void {
    xb.core.input?.mouseController?.updateMousePositionFromEvent?.(e);
    xb.core.input?.mouseController?.callSelectStart?.();

    if (this.state.phase !== 'playing') return;
    const hit = this.screenToPlayfield(e.clientX, e.clientY);
    if (!hit) return;

    // Check if the user clicked directly on an open Socket Pad to deploy selected tower
    for (const pad of this.state.pads) {
      if (pad.towerId === null && pad.shatterCooldown <= 0) {
        const dx = hit.x - pad.x;
        const dz = hit.z - pad.z;
        if (dx * dx + dz * dz <= 0.85 * 0.85) {
          this.handleDeployTowerAction(this.state.selectedTowerType, pad.id);
          return;
        }
      }
    }

    // Otherwise apply momentum thrust toward clicked playfield point
    this.pointerThrustActive = true;
    this.pointerWorldTarget = hit;
  }

  private handlePointerMove(e: PointerEvent): void {
    xb.core.input?.mouseController?.updateMousePositionFromEvent?.(e);
    if (!this.pointerThrustActive || this.state.phase !== 'playing') return;
    const hit = this.screenToPlayfield(e.clientX, e.clientY);
    if (hit) {
      this.pointerWorldTarget = hit;
    }
  }

  private handlePointerUp(): void {
    if (xb.core.input?.mouseController?.userData?.selected) {
      xb.core.input.mouseController.callSelectEnd();
    }
    this.pointerThrustActive = false;
    this.pointerWorldTarget = null;
  }

  public onSelectStart(event: xb.SelectEvent): void {
    if (this.state.phase !== 'playing') return;
    const intersection = event.intersection;
    if (intersection?.point) {
      this.pointerWorldTarget = { x: intersection.point.x, z: intersection.point.z };
      this.pointerThrustActive = true;
    }
  }

  public onSelectEnd(): void {
    this.pointerThrustActive = false;
    this.pointerWorldTarget = null;
  }

  private handleDeployTowerAction(type: TowerType, specificPadId?: number): void {
    if (this.state.phase !== 'playing') return;
    this.state.selectedTowerType = type;
    const res = deploySingleUseTower(this.state, type, specificPadId);
    if (res.ok && res.tower) {
      this.synth.playDeployTower();
      this.particles.emitBurst(
        res.tower.x,
        0.35,
        res.tower.z,
        TOWER_SPECS[type].colorHex,
        14,
        3.2,
        0.85,
      );
      this.shellUI.sync(this.state, this.snapshot);
    }
  }

  private handleTriggerEmpAction(): void {
    if (this.state.phase !== 'playing') return;
    const res = triggerSingleUseEmp(this.state);
    if (res.ok && res.shatterEvent) {
      this.synth.playItemShatter();
      this.hitstopTimer = 0.045;
      this.cameraTrauma = Math.min(1.0, this.cameraTrauma + 0.45);
      this.emitShatterVisuals(res.shatterEvent);
      this.shellUI.sync(this.state, this.snapshot);
    }
  }

  private emitShatterVisuals(ev: ShatterEvent): void {
    // Shatter burst at the item's location
    this.particles.emitBurst(ev.x, 0.55, ev.z, ev.colorHex, 24, 5.2, 1.15);

    // Spawn 3D energy discharge beams to every affected target
    for (const target of ev.targetPositions) {
      const dx = target.x - ev.x;
      const dz = target.z - ev.z;
      const dist = Math.max(0.1, Math.hypot(dx, dz));
      const beamGeo = new THREE.CylinderGeometry(0.055, 0.055, dist, 8);
      beamGeo.rotateX(Math.PI / 2);
      const beamMat = new THREE.MeshBasicMaterial({
        color: ev.colorHex,
        transparent: true,
        opacity: 0.92,
      });
      const beamMesh = new THREE.Mesh(beamGeo, beamMat);
      beamMesh.position.set((ev.x + target.x) * 0.5, 0.52, (ev.z + target.z) * 0.5);
      beamMesh.rotation.y = Math.atan2(dx, dz);
      beamMesh.xb = { pointerEvents: 'none' };
      this.add(beamMesh);
      this.activeBeams.push({ mesh: beamMesh, age: 0, maxLife: 0.24 });

      this.particles.emitBurst(target.x, 0.45, target.z, ev.colorHex, 10, 3.6, 0.8);
    }
  }

  private readThrustInput(): { tx: number; tz: number } {
    let tx = 0;
    let tz = 0;

    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) tx -= 1;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) tx += 1;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) tz -= 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) tz += 1;

    if (tx === 0 && tz === 0 && this.pointerThrustActive && this.pointerWorldTarget) {
      const dx = this.pointerWorldTarget.x - this.state.player.x;
      const dz = this.pointerWorldTarget.z - this.state.player.z;
      const len = Math.hypot(dx, dz);
      if (len > 0.25) {
        tx = dx / len;
        tz = dz / len;
      }
    }

    return { tx, tz };
  }

  public update(): void {
    const rawDt = xb.getDeltaTime();
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (!this.validatedSpatialUI && this.spatialMarqueeCard) {
      const report = xb.ui.validate(this.spatialMarqueeCard);
      if (report.ready) {
        this.validatedSpatialUI = true;
      }
    }

    if (this.state.phase === 'title') {
      this.titleTourTime += dt;
      // Gentle idle figure-8 motion of the Trackball Courier on the title screen
      this.state.player.x = Math.sin(this.titleTourTime * 0.9) * 2.8;
      this.state.player.z = 2.6 + Math.sin(this.titleTourTime * 1.8) * 1.1;
      this.state.player.heading = Math.cos(this.titleTourTime * 0.9) * 1.2;
      this.state.player.distanceTraveled += dt * 2.4;
      this.syncVisualsFromState(dt);
      this.updateCameraRig(dt);
      return;
    }

    if (this.state.phase === 'playing') {
      if (this.hitstopTimer > 0) {
        this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      } else {
        const { tx, tz } = this.readThrustInput();
        const tick = stepSimulationTick(this.state, tx, tz, dt);

        if (tick.wallBounced) {
          this.synth.playWallTap();
        }
        if (tick.bumperBounced) {
          this.synth.playBumperBounce();
          this.cameraTrauma = Math.min(1.0, this.cameraTrauma + 0.28);
        }
        if (tick.windupStarted) {
          this.synth.playEnemyWindup();
        }
        if (tick.collectedFragmentIds.length > 0) {
          const count = getCollectedMapCount(this.state);
          this.synth.playMapPieceCollected(count);
          this.hitstopTimer = 0.055;
          this.cameraTrauma = Math.min(1.0, this.cameraTrauma + 0.35);
          for (const id of tick.collectedFragmentIds) {
            const frag = this.state.mapFragments.find((f) => f.id === id);
            if (frag) {
              this.particles.emitBurst(frag.x, 0.6, frag.z, 0xfbbf24, 28, 5.5, 1.2);
            }
          }
        }
        for (const sh of tick.shatterEvents) {
          this.synth.playItemShatter();
          this.emitShatterVisuals(sh);
        }
        if (tick.heavyHitOccurred) {
          this.hitstopTimer = Math.max(this.hitstopTimer, 0.04);
          this.cameraTrauma = Math.min(1.0, this.cameraTrauma + 0.32);
        }
        if (tick.coreDamaged || tick.playerDamaged) {
          this.synth.playDamageAlert();
          this.cameraTrauma = Math.min(1.0, this.cameraTrauma + 0.52);
        }
        for (const koPos of tick.enemiesKilled) {
          this.particles.emitBurst(koPos.x, 0.45, koPos.z, 0xf43f5e, 18, 4.4, 1.0);
        }
        if (tick.outcomeChanged !== 'none') {
          this.snapshot = createRunSnapshot(this.state);
          this.synth.playOutcomeFanfare(tick.outcomeChanged === 'victory');
        }
      }
    }

    this.particles.update(dt);
    this.updateTransientBeams(dt);
    this.syncVisualsFromState(dt);
    this.updateCameraRig(dt);
    this.shellUI.sync(this.state, this.snapshot);
  }

  private updateTransientBeams(dt: number): void {
    for (let i = this.activeBeams.length - 1; i >= 0; i--) {
      const b = this.activeBeams[i];
      b.age += dt;
      if (b.age >= b.maxLife) {
        this.remove(b.mesh);
        b.mesh.geometry.dispose();
        (b.mesh.material as THREE.Material).dispose();
        this.activeBeams.splice(i, 1);
      } else {
        const mat = b.mesh.material as THREE.MeshBasicMaterial;
        mat.opacity = 1 - b.age / b.maxLife;
      }
    }
  }

  private syncVisualsFromState(dt: number): void {
    const t = this.state.elapsedSeconds + this.titleTourTime;

    // 1. Update Player Trackball Courier
    const p = this.state.player;
    this.playerRig.root.position.set(p.x, 0, p.z);
    this.playerRig.bodyGroup.scale.set(p.squashX, p.squashY, p.squashX);
    this.playerRig.bodyGroup.rotation.z = -p.vx * 0.045;
    this.playerRig.bodyGroup.rotation.x = p.vz * 0.045;
    this.playerRig.outerRing.rotation.z = p.distanceTraveled * 1.4;
    this.playerRig.innerRing.rotation.x = -p.distanceTraveled * 2.1;
    this.playerRig.tailFin.rotation.y = p.heading;
    this.playerRig.coreCrystal.rotation.y = t * 2.8;

    const haloMat = this.playerRig.shieldHalo.material as THREE.MeshBasicMaterial;
    haloMat.opacity = p.invulnTimer > 0 ? 0.65 : 0.0;

    // 2. Update Central Core Vault & 5 HP Pylons
    this.arenaRig.coreCrystal.rotation.y = t * 1.2;
    this.arenaRig.coreCrystal.position.y = 0.95 + Math.sin(t * 2.5) * 0.07;
    this.arenaRig.coreRings[0].rotation.x = t * 0.9;
    this.arenaRig.coreRings[1].rotation.y = -t * 1.1;

    for (let i = 0; i < this.arenaRig.corePylons.length; i++) {
      const pylon = this.arenaRig.corePylons[i];
      const active = i < this.state.coreHp;
      pylon.visible = active;
    }

    // 3. Update Socket Pad Rings
    for (let i = 0; i < this.state.pads.length; i++) {
      const pad = this.state.pads[i];
      const ringMesh = this.arenaRig.padRingMeshes[i];
      if (!ringMesh) continue;
      const mat = ringMesh.material as THREE.MeshBasicMaterial;
      if (pad.shatterCooldown > 0) {
        mat.color.setHex(0xf43f5e);
        mat.opacity = 0.35;
      } else if (pad.towerId !== null) {
        mat.color.setHex(0xf59e0b);
        mat.opacity = 0.85;
      } else {
        mat.color.setHex(0x06b6d4);
        mat.opacity = 0.65;
      }
    }

    // 4. Update Single-Use Arcade Bumpers
    for (let i = 0; i < this.state.bumpers.length; i++) {
      const b = this.state.bumpers[i];
      const bMesh = this.arenaRig.bumperMeshes[i];
      if (!bMesh) continue;
      bMesh.visible = !b.shattered;
      const s = b.hitTimer > 0 ? 1.22 : 1.0;
      bMesh.scale.setScalar(s);
    }

    // 5. Update 6 Torn Map Fragments
    for (const frag of this.state.mapFragments) {
      const mesh = this.mapFragmentMeshes.get(frag.id);
      if (!mesh) continue;
      if (frag.collected) {
        if (frag.collectAnimTimer > 0) {
          const prog = frag.collectAnimTimer / 0.6;
          mesh.scale.setScalar(prog * 1.35);
          mesh.position.y = (1 - prog) * 1.6;
          mesh.rotation.y += dt * 12;
        } else {
          mesh.visible = false;
        }
      } else {
        mesh.visible = true;
        mesh.scale.setScalar(1);
        mesh.position.set(frag.x, 0, frag.z);
        const floatRoot = mesh.getObjectByName('floatRoot');
        if (floatRoot) {
          floatRoot.position.y = 0.48 + Math.sin(t * 2.8 + frag.index) * 0.1;
          floatRoot.rotation.y = t * 1.35 + frag.index * 0.8;
        }
      }
    }

    // 6. Sync Single-Use Towers
    const activeTowerIds = new Set<number>();
    for (const tower of this.state.towers) {
      activeTowerIds.add(tower.id);
      let mesh = this.towerMeshes.get(tower.id);
      if (!mesh) {
        mesh = createSingleUseTowerModel(tower.type, this.textures);
        mesh.position.set(tower.x, 0, tower.z);
        this.add(mesh);
        this.towerMeshes.set(tower.id, mesh);
      }

      const head = mesh.getObjectByName('turretHead');
      if (head) {
        head.rotation.y = tower.aimAngle;
      }

      if (tower.shattered) {
        const prog = Math.max(0, tower.shatterAnimTimer / 0.42);
        mesh.scale.set(1 + (1 - prog) * 0.45, prog, 1 + (1 - prog) * 0.45);
        mesh.rotation.z = (1 - prog) * 0.6;
      } else {
        mesh.scale.setScalar(1);
        mesh.rotation.set(0, 0, 0);
      }
    }

    for (const [id, mesh] of this.towerMeshes.entries()) {
      if (!activeTowerIds.has(id)) {
        this.remove(mesh);
        this.towerMeshes.delete(id);
      }
    }

    // 7. Sync Enemies & Windup Telegraphs
    const activeEnemyIds = new Set<number>();
    for (const enemy of this.state.enemies) {
      activeEnemyIds.add(enemy.id);
      let rig = this.enemyRigs.get(enemy.id);
      if (!rig) {
        rig = createEnemyModel(enemy.archetype, this.textures);
        this.add(rig.root);
        this.enemyRigs.set(enemy.id, rig);
      }

      rig.root.position.set(enemy.x, 0, enemy.z);
      if (Math.hypot(enemy.vx, enemy.vz) > 0.05) {
        rig.bodyGroup.rotation.y = Math.atan2(enemy.vx, enemy.vz);
      }

      // Hit flash
      const specColor = enemy.hitFlashTimer > 0 ? 0xffffff : undefined;
      for (const mat of rig.primaryMaterials) {
        if (specColor !== undefined) {
          mat.emissive.setHex(0xffffff);
          mat.emissiveIntensity = 1.8;
        } else {
          mat.emissiveIntensity = enemy.isWindingUp ? 1.1 : 0.25;
        }
      }

      // Windup Telegraph Ring & Sight Line
      rig.telegraphRing.visible = enemy.isWindingUp;
      rig.telegraphLine.visible = enemy.isWindingUp && enemy.archetype === 'LANCER';
      if (enemy.isWindingUp) {
        const pulse = 0.85 + Math.sin(t * 24) * 0.25;
        rig.telegraphRing.scale.setScalar(pulse);
        rig.telegraphLine.rotation.y = Math.atan2(enemy.dashDirX, enemy.dashDirZ);
        rig.bodyGroup.position.y = -0.08;
      } else {
        rig.bodyGroup.position.y = Math.abs(Math.sin(t * 7 + enemy.id)) * 0.06;
      }

      // KO topple transition
      if (enemy.isKo) {
        const koProg = Math.max(0, enemy.koTimer / 0.35);
        rig.bodyGroup.rotation.x = (1 - koProg) * 1.4;
        rig.bodyGroup.scale.setScalar(koProg);
      } else {
        rig.bodyGroup.rotation.x = 0;
        rig.bodyGroup.scale.setScalar(1);
      }
    }

    for (const [id, rig] of this.enemyRigs.entries()) {
      if (!activeEnemyIds.has(id)) {
        this.remove(rig.root);
        this.enemyRigs.delete(id);
      }
    }

    // 8. Sync Token Drops
    const activeTokenIds = new Set<number>();
    for (const drop of this.state.tokenDrops) {
      activeTokenIds.add(drop.id);
      let mesh = this.tokenMeshes.get(drop.id);
      if (!mesh) {
        mesh = new THREE.Mesh(this.tokenGeo, this.tokenMat);
        mesh.rotation.x = Math.PI / 2;
        this.add(mesh);
        this.tokenMeshes.set(drop.id, mesh);
      }
      mesh.position.set(drop.x, 0.32 + Math.sin(t * 4 + drop.id) * 0.06, drop.z);
      mesh.rotation.z = t * 3.2 + drop.id;
    }

    for (const [id, mesh] of this.tokenMeshes.entries()) {
      if (!activeTokenIds.has(id)) {
        this.remove(mesh);
        this.tokenMeshes.delete(id);
      }
    }

    // 9. Update Spatial Marquee UICard Text
    const mapCount = getCollectedMapCount(this.state);
    this.spatialStatusText.text = `MAP SHARDS: ${mapCount}/6 · TOKENS: ${Math.round(this.state.tokens)} · WAVE ${this.state.wave}`;
    this.spatialShatterText.text = `${this.state.lastShatterBanner} (BROKEN: ${this.state.itemsShattered})`;
  }

  private updateCameraRig(dt: number): void {
    const cam = xb.core.camera;
    if (!cam || xb.core.renderer?.xr?.isPresenting) return;

    if (this.state.phase === 'title') {
      // Live World Camera Tour Orbiting the Illuminated Arcade Cabinet Arena
      const angle = this.titleTourTime * 0.25;
      _camTargetPos.set(
        2.8 + Math.sin(angle) * 4.5,
        10.4 + Math.sin(this.titleTourTime * 0.45) * 0.8,
        12.4 + Math.cos(angle) * 1.8,
      );
      _camLookAt.set(-2.4, 0.4, -0.2);
    } else {
      // Tactical Tabletop Follow Camera with exponential damping
      const px = this.state.player.x;
      const pz = this.state.player.z;
      _camTargetPos.set(px * 0.36, 12.0, 13.4 + pz * 0.24);
      _camLookAt.set(px * 0.24, 0.2, pz * 0.2 - 0.35);
    }

    const damp = 1 - Math.exp(-5.5 * dt);
    cam.position.lerp(_camTargetPos, damp);
    _currentLookAt.lerp(_camLookAt, damp);

    // Apply decaying trauma * trauma camera shake
    if (this.cameraTrauma > 0) {
      this.cameraTrauma = Math.max(0, this.cameraTrauma - 1.9 * dt);
      const shake = this.cameraTrauma * this.cameraTrauma * 0.36;
      const t = performance.now() * 0.04;
      cam.position.x += Math.sin(t * 1.7) * shake;
      cam.position.y += Math.cos(t * 2.3) * shake;
    }

    cam.lookAt(_currentLookAt);
  }

  public dispose(): void {
    window.removeEventListener('keydown', this.onKeyDownBound);
    window.removeEventListener('keyup', this.onKeyUpBound);
    window.removeEventListener('blur', this.onBlurBound);
    document.removeEventListener('visibilitychange', this.onBlurBound);
    window.removeEventListener('pointerup', this.onPointerUpBound);
    const canvas = xb.core.renderer?.domElement;
    if (canvas) {
      canvas.removeEventListener('pointerdown', this.onPointerDownBound);
      canvas.removeEventListener('pointermove', this.onPointerMoveBound);
    }
    this.clearDynamicMeshes();
    this.particles.dispose();
    this.arenaRig.dispose();
    this.textures.dispose();
    this.tokenGeo.dispose();
    this.tokenMat.dispose();
  }
}
