import {
  BumperNode,
  EnemyArchetype,
  EnemySpec,
  MapFragmentState,
  SocketPadState,
  TowerSpec,
  TowerType,
  Vec2,
} from './types';

export const ARENA_BOUNDS = {
  minX: -9.5,
  maxX: 9.5,
  minZ: -8.5,
  maxZ: 8.5,
};

export const CORE_POSITION: Vec2 = { x: 0, z: 6.4 };
export const PLAYER_SPAWN: Vec2 = { x: 0, z: 3.2 };

export const MOMENTUM_PHYSICS = {
  thrustAccel: 22.0,
  boostImpulse: 11.5,
  dragPerSecond: 1.85,
  maxSpeed: 11.5,
  wallRestitution: 0.78,
  bumperImpulse: 10.5,
  playerRadius: 0.58,
  fragmentPickupRadius: 1.25,
  tokenPickupRadius: 1.2,
  padDeployRadius: 3.4,
};

export const TOWER_SPECS: Record<TowerType, TowerSpec> = {
  [TowerType.PULSE_LASER]: {
    type: TowerType.PULSE_LASER,
    keyBinding: '1',
    name: 'Pulse Rail Turret',
    shortRole: 'High-Damage Snipe · Breaks in 1 Shot',
    cost: 25,
    range: 5.6,
    damage: 130,
    colorHex: 0x06b6d4,
    accentCss: '#06b6d4',
    maxUses: 1,
  },
  [TowerType.CRYO_CAPACITOR]: {
    type: TowerType.CRYO_CAPACITOR,
    keyBinding: '2',
    name: 'Cryo Nova Cell',
    shortRole: 'AoE Freeze Blast · Breaks in 1 Use',
    cost: 35,
    range: 4.6,
    damage: 65,
    colorHex: 0x38bdf8,
    accentCss: '#38bdf8',
    maxUses: 1,
  },
  [TowerType.TESLA_COIL]: {
    type: TowerType.TESLA_COIL,
    keyBinding: '3',
    name: 'Tesla Arc Pylon',
    shortRole: '4-Target Chain Zap · Breaks in 1 Use',
    cost: 45,
    range: 5.4,
    damage: 85,
    colorHex: 0xf59e0b,
    accentCss: '#f59e0b',
    maxUses: 1,
  },
};

export const ENEMY_SPECS: Record<EnemyArchetype, EnemySpec> = {
  [EnemyArchetype.SWARMER]: {
    archetype: EnemyArchetype.SWARMER,
    name: 'Bit-Mite Swarmer',
    maxHp: 75,
    speed: 2.55,
    rewardTokens: 15,
    coreDamage: 1,
    colorHex: 0xf43f5e,
    radius: 0.45,
  },
  [EnemyArchetype.LANCER]: {
    archetype: EnemyArchetype.LANCER,
    name: 'Vector Lancer',
    maxHp: 110,
    speed: 2.15,
    rewardTokens: 22,
    coreDamage: 1,
    colorHex: 0xa855f7,
    radius: 0.52,
  },
  [EnemyArchetype.JUGGERNAUT]: {
    archetype: EnemyArchetype.JUGGERNAUT,
    name: 'Cabinet Juggernaut',
    maxHp: 210,
    speed: 1.45,
    rewardTokens: 35,
    coreDamage: 2,
    colorHex: 0xf97316,
    radius: 0.68,
  },
};

export const LANE_WAYPOINTS: Vec2[][] = [
  // Left Neon Circuit Lane
  [
    { x: -6.8, z: -7.6 },
    { x: -6.8, z: -3.2 },
    { x: -3.4, z: -1.2 },
    { x: -3.4, z: 2.6 },
    { x: 0.0, z: 6.4 },
  ],
  // Center Vector Spine Lane
  [
    { x: 0.0, z: -7.8 },
    { x: -1.8, z: -4.2 },
    { x: 1.8, z: -0.6 },
    { x: 0.0, z: 2.8 },
    { x: 0.0, z: 6.4 },
  ],
  // Right Neon Circuit Lane
  [
    { x: 6.8, z: -7.6 },
    { x: 6.8, z: -3.2 },
    { x: 3.4, z: -1.2 },
    { x: 3.4, z: 2.6 },
    { x: 0.0, z: 6.4 },
  ],
];

export const INITIAL_SOCKET_PADS: Omit<SocketPadState, 'towerId' | 'shatterCooldown'>[] = [
  { id: 0, x: -2.2, z: 3.8 },
  { id: 1, x: 2.2, z: 3.8 },
  { id: 2, x: -5.0, z: 1.2 },
  { id: 3, x: 0.0, z: 1.1 },
  { id: 4, x: 5.0, z: 1.2 },
  { id: 5, x: -4.8, z: -2.2 },
  { id: 6, x: 0.0, z: -2.4 },
  { id: 7, x: 4.8, z: -2.2 },
  { id: 8, x: -3.6, z: -5.2 },
  { id: 9, x: 3.6, z: -5.2 },
];

export const INITIAL_MAP_FRAGMENTS: Omit<MapFragmentState, 'collected' | 'collectAnimTimer'>[] = [
  {
    id: 1,
    index: 0,
    label: 'Fragment I: Coin-Door Key',
    sectorName: 'SW Circuit Bend',
    x: -5.8,
    z: 3.6,
  },
  {
    id: 2,
    index: 1,
    label: 'Fragment II: CRT Raster Grid',
    sectorName: 'SE Capacitor Bay',
    x: 5.8,
    z: 3.6,
  },
  {
    id: 3,
    index: 2,
    label: 'Fragment III: Vector Bus',
    sectorName: 'West Bumper Alley',
    x: -7.4,
    z: -0.8,
  },
  {
    id: 4,
    index: 3,
    label: 'Fragment IV: Dip-Switch Map',
    sectorName: 'East Bumper Alley',
    x: 7.4,
    z: -0.8,
  },
  {
    id: 5,
    index: 4,
    label: 'Fragment V: ROM Checksum',
    sectorName: 'NW Spawner Gate',
    x: -5.4,
    z: -6.2,
  },
  {
    id: 6,
    index: 5,
    label: 'Fragment VI: Master High-Score Seal',
    sectorName: 'NE Spawner Gate',
    x: 5.4,
    z: -6.2,
  },
];

export const INITIAL_BUMPERS: Omit<BumperNode, 'hitTimer' | 'usesRemaining' | 'shattered' | 'respawnTimer'>[] = [
  { id: 0, x: -3.2, z: 0.6, radius: 0.72 },
  { id: 1, x: 3.2, z: 0.6, radius: 0.72 },
  { id: 2, x: -2.6, z: -3.8, radius: 0.72 },
  { id: 3, x: 2.6, z: -3.8, radius: 0.72 },
];
