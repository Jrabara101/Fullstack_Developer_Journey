import assert from 'node:assert/strict';
import test from 'node:test';
import {
  createInitialSimulationState,
  createRunSnapshot,
  deploySingleUseTower,
  getCollectedMapCount,
  spawnEnemyForWave,
  stepPlayerMomentum,
  stepSingleUseTowers,
  stepSimulationTick,
  triggerSingleUseEmp,
} from './rules';
import { EnemyArchetype, TowerType } from '../types';

test('momentum steering accelerates player orb and glides with inertia when thrust stops', () => {
  const state = createInitialSimulationState();
  state.phase = 'playing';
  const startZ = state.player.z;

  // Apply north thrust (-Z)
  stepPlayerMomentum(state, 0, -1, 0.05);
  assert.ok(state.player.vz < 0, 'Orb should gain negative Z velocity when thrusting north');
  const midZ = state.player.z;
  assert.ok(midZ < startZ, 'Orb Z position should move north');

  // Release thrust (0, 0) and verify momentum continues moving the orb
  stepPlayerMomentum(state, 0, 0, 0.05);
  assert.ok(state.player.z < midZ, 'Orb should continue gliding via momentum alone with zero input');
});

test('every deployed tower breaks immediately after 1 use and frees its socket pad', () => {
  const state = createInitialSimulationState();
  state.phase = 'playing';
  // Clear starter towers to test isolated deployment
  state.towers = [];
  for (const pad of state.pads) pad.towerId = null;

  const deployRes = deploySingleUseTower(state, TowerType.PULSE_LASER, 3);
  assert.equal(deployRes.ok, true);
  assert.ok(deployRes.tower);
  assert.equal(deployRes.tower.usesRemaining, 1);
  assert.equal(deployRes.tower.shattered, false);

  // Spawn an enemy directly in range of pad 3
  const pad3 = state.pads.find((p) => p.id === 3)!;
  const enemy = spawnEnemyForWave(state, EnemyArchetype.SWARMER, 1);
  enemy.x = pad3.x;
  enemy.z = pad3.z - 1.5;

  const prevShatteredCount = state.itemsShattered;
  const shatters = stepSingleUseTowers(state, 0.016);

  assert.equal(shatters.length, 1, 'Tower should fire once and emit 1 shatter event');
  assert.equal(deployRes.tower.usesRemaining, 0, 'Tower usesRemaining must drop to 0 after 1 use');
  assert.equal(deployRes.tower.shattered, true, 'Tower must be marked shattered after 1 use');
  assert.equal(state.itemsShattered, prevShatteredCount + 1, 'Global itemsShattered counter must increment');
  assert.equal(pad3.towerId, null, 'Socket pad must be freed when tower breaks');
});

test('single-use EMP cartridge breaks after 1 use and damages nearby enemies', () => {
  const state = createInitialSimulationState();
  state.phase = 'playing';
  const enemy = spawnEnemyForWave(state, EnemyArchetype.SWARMER, 1);
  enemy.x = state.player.x + 1.0;
  enemy.z = state.player.z - 1.0;

  const initialEmp = state.empCharges;
  const initialBroken = state.itemsShattered;
  const res = triggerSingleUseEmp(state);

  assert.equal(res.ok, true);
  assert.equal(res.enemiesHit, 1);
  assert.equal(state.empCharges, initialEmp - 1);
  assert.equal(state.itemsShattered, initialBroken + 1);
  assert.ok(res.shatterEvent?.label.includes('SHATTERED'));
});

test('arcade bumper bounces momentum orb and breaks after 1 use', () => {
  const state = createInitialSimulationState();
  state.phase = 'playing';
  const bumper = state.bumpers[0];
  state.player.x = bumper.x + 0.3;
  state.player.z = bumper.z;

  const res = stepPlayerMomentum(state, 0, 0, 0.016);
  assert.equal(res.bumperBounced, true);
  assert.equal(bumper.shattered, true);
  assert.equal(bumper.usesRemaining, 0);
  assert.ok(res.bumperShatter);
});

test('collecting all 6 pieces of the torn map triggers victory and creates accurate snapshot', () => {
  const state = createInitialSimulationState(500);
  state.phase = 'playing';

  // Mark first 5 fragments collected, place player on the 6th fragment
  for (let i = 0; i < 5; i++) {
    state.mapFragments[i].collected = true;
  }
  const lastFrag = state.mapFragments[5];
  state.player.x = lastFrag.x;
  state.player.z = lastFrag.z;

  const tick = stepSimulationTick(state, 0, 0, 0.016);
  assert.equal(getCollectedMapCount(state), 6);
  assert.equal(tick.outcomeChanged, 'victory');
  assert.equal(state.outcome, 'victory');
  assert.equal(state.phase, 'gameover');

  const snap = createRunSnapshot(state);
  assert.equal(snap.outcome, 'victory');
  assert.equal(snap.mapCollected, 6);
  assert.equal(snap.mapTotal, 6);
});

test('3 enemy archetypes execute distinct movement and windup behaviors', () => {
  const state = createInitialSimulationState();
  state.phase = 'playing';
  state.towers = [];

  const swarmer = spawnEnemyForWave(state, EnemyArchetype.SWARMER, 0);
  const lancer = spawnEnemyForWave(state, EnemyArchetype.LANCER, 1);
  // Place lancer close to player to trigger windup telegraph
  lancer.x = state.player.x;
  lancer.z = state.player.z - 2.5;

  const tick = stepSimulationTick(state, 0, 0, 0.03);
  assert.equal(lancer.isWindingUp, true, 'Lancer should enter windup telegraph when near player');
  assert.equal(tick.windupStarted, true);
  assert.ok(Math.abs(swarmer.vx) > 0, 'Swarmer should weave laterally along its lane');
});
