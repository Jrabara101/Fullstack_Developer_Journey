import {
  ARENA_BOUNDS,
  CORE_POSITION,
  ENEMY_SPECS,
  INITIAL_BUMPERS,
  INITIAL_MAP_FRAGMENTS,
  INITIAL_SOCKET_PADS,
  LANE_WAYPOINTS,
  MOMENTUM_PHYSICS,
  PLAYER_SPAWN,
  TOWER_SPECS,
} from '../constants';
import {
  EnemyArchetype,
  EnemyInstanceState,
  GameOutcome,
  GameSimulationState,
  RunSnapshot,
  ShatterEvent,
  SocketPadState,
  TowerInstanceState,
  TowerType,
  Vec2,
} from '../types';

export interface StepTickResult {
  shatterEvents: ShatterEvent[];
  collectedFragmentIds: number[];
  collectedTokensAmount: number;
  enemiesKilled: Vec2[];
  heavyHitOccurred: boolean;
  bumperBounced: boolean;
  wallBounced: boolean;
  windupStarted: boolean;
  coreDamaged: boolean;
  playerDamaged: boolean;
  outcomeChanged: GameOutcome;
}

export function createInitialSimulationState(bestScore = 0): GameSimulationState {
  const pads: SocketPadState[] = INITIAL_SOCKET_PADS.map((p) => ({
    ...p,
    towerId: null,
    shatterCooldown: 0,
  }));

  const state: GameSimulationState = {
    phase: 'title',
    outcome: 'none',
    defeatReason: '',
    elapsedSeconds: 0,
    wave: 1,
    waveTimer: 0,
    spawnTimer: 1.5,
    score: 0,
    bestScore,
    tokens: 95,
    coreHp: 5,
    maxCoreHp: 5,
    empCharges: 2,
    selectedTowerType: TowerType.PULSE_LASER,
    itemsShattered: 0,
    enemiesDefeated: 0,
    lastShatterBanner: 'ALL ITEMS & TOWERS BREAK AFTER 1 USE',
    lastShatterBannerTimer: 0,
    player: {
      x: PLAYER_SPAWN.x,
      z: PLAYER_SPAWN.z,
      vx: 0,
      vz: 0,
      heading: Math.PI, // Facing north into the open arena
      radius: MOMENTUM_PHYSICS.playerRadius,
      hp: 5,
      maxHp: 5,
      invulnTimer: 0,
      boostCooldown: 0,
      squashX: 1,
      squashY: 1,
      distanceTraveled: 0,
    },
    pads,
    towers: [],
    enemies: [],
    mapFragments: INITIAL_MAP_FRAGMENTS.map((f) => ({
      ...f,
      collected: false,
      collectAnimTimer: 0,
    })),
    bumpers: INITIAL_BUMPERS.map((b) => ({
      ...b,
      hitTimer: 0,
      usesRemaining: 1,
      shattered: false,
      respawnTimer: 0,
    })),
    tokenDrops: [],
    nextEntityId: 100,
  };

  // Pre-place 2 starter single-use defense turrets on the south guard pads
  // so the player immediately sees single-use defense in action and is safe on opening seconds.
  const starterLeft = createTowerOnPad(state, pads[0], TowerType.PULSE_LASER);
  const starterRight = createTowerOnPad(state, pads[1], TowerType.CRYO_CAPACITOR);
  state.towers.push(starterLeft, starterRight);

  return state;
}

function createTowerOnPad(
  state: GameSimulationState,
  pad: SocketPadState,
  type: TowerType,
): TowerInstanceState {
  const id = state.nextEntityId++;
  pad.towerId = id;
  return {
    id,
    padId: pad.id,
    type,
    x: pad.x,
    z: pad.z,
    usesRemaining: 1,
    maxUses: 1,
    shattered: false,
    shatterAnimTimer: 0,
    aimAngle: Math.PI,
    deployedAt: state.elapsedSeconds,
  };
}

export function getCollectedMapCount(state: GameSimulationState): number {
  let count = 0;
  for (let i = 0; i < state.mapFragments.length; i++) {
    if (state.mapFragments[i].collected) count++;
  }
  return count;
}

export function findBestDeployPad(
  state: GameSimulationState,
  preferNearPlayer = true,
): SocketPadState | null {
  let bestPad: SocketPadState | null = null;
  let bestDistSq = Infinity;

  for (let i = 0; i < state.pads.length; i++) {
    const pad = state.pads[i];
    if (pad.towerId !== null || pad.shatterCooldown > 0) continue;
    const dx = pad.x - state.player.x;
    const dz = pad.z - state.player.z;
    const distSq = dx * dx + dz * dz;
    if (preferNearPlayer) {
      if (distSq < bestDistSq) {
        bestDistSq = distSq;
        bestPad = pad;
      }
    } else if (!bestPad) {
      bestPad = pad;
    }
  }
  return bestPad;
}

export function deploySingleUseTower(
  state: GameSimulationState,
  type: TowerType,
  specificPadId?: number,
): { ok: boolean; reason?: string; tower?: TowerInstanceState } {
  const spec = TOWER_SPECS[type];
  if (state.tokens < spec.cost) {
    return { ok: false, reason: 'INSUFFICIENT TOKENS' };
  }

  let pad: SocketPadState | null = null;
  if (typeof specificPadId === 'number') {
    const candidate = state.pads.find((p) => p.id === specificPadId) ?? null;
    if (candidate && candidate.towerId === null && candidate.shatterCooldown <= 0) {
      pad = candidate;
    }
  } else {
    pad = findBestDeployPad(state, true);
  }

  if (!pad) {
    return { ok: false, reason: 'NO OPEN SOCKET PAD' };
  }

  state.tokens -= spec.cost;
  const tower = createTowerOnPad(state, pad, type);
  state.towers.push(tower);
  state.lastShatterBanner = `DEPLOYED ${spec.name.toUpperCase()} (1 USE ONLY)`;
  state.lastShatterBannerTimer = 2.2;
  return { ok: true, tower };
}

export function triggerSingleUseEmp(
  state: GameSimulationState,
): { ok: boolean; shatterEvent?: ShatterEvent; enemiesHit: number } {
  if (state.empCharges <= 0) {
    return { ok: false, enemiesHit: 0 };
  }

  state.empCharges -= 1;
  state.itemsShattered += 1;
  state.player.invulnTimer = Math.max(state.player.invulnTimer, 1.1);
  state.player.boostCooldown = 0.6;

  // Apply momentum impulse along current heading or velocity
  const speed = Math.hypot(state.player.vx, state.player.vz);
  let dirX = Math.sin(state.player.heading);
  let dirZ = Math.cos(state.player.heading);
  if (speed > 0.25) {
    dirX = state.player.vx / speed;
    dirZ = state.player.vz / speed;
  }
  state.player.vx += dirX * MOMENTUM_PHYSICS.boostImpulse;
  state.player.vz += dirZ * MOMENTUM_PHYSICS.boostImpulse;
  clampPlayerSpeed(state);

  state.player.squashX = 0.8;
  state.player.squashY = 1.24;

  const targetPositions: Vec2[] = [];
  let enemiesHit = 0;
  const empRadiusSq = 5.4 * 5.4;

  for (let i = 0; i < state.enemies.length; i++) {
    const enemy = state.enemies[i];
    if (enemy.isKo) continue;
    const dx = enemy.x - state.player.x;
    const dz = enemy.z - state.player.z;
    const distSq = dx * dx + dz * dz;
    if (distSq <= empRadiusSq) {
      enemy.hp -= 85;
      enemy.slowTimer = Math.max(enemy.slowTimer, 3.0);
      enemy.hitFlashTimer = 0.12;
      enemy.isWindingUp = false;
      enemy.windupTimer = 0;
      targetPositions.push({ x: enemy.x, z: enemy.z });
      enemiesHit++;
      if (enemy.hp <= 0) {
        markEnemyKo(state, enemy);
      }
    }
  }

  const label = 'EMP CARTRIDGE SHATTERED AFTER 1 USE!';
  state.lastShatterBanner = label;
  state.lastShatterBannerTimer = 2.6;

  return {
    ok: true,
    enemiesHit,
    shatterEvent: {
      x: state.player.x,
      z: state.player.z,
      colorHex: 0xa855f7,
      label,
      targetPositions,
    },
  };
}

function clampPlayerSpeed(state: GameSimulationState): void {
  const speed = Math.hypot(state.player.vx, state.player.vz);
  if (speed > MOMENTUM_PHYSICS.maxSpeed) {
    const scale = MOMENTUM_PHYSICS.maxSpeed / speed;
    state.player.vx *= scale;
    state.player.vz *= scale;
  }
}

function markEnemyKo(state: GameSimulationState, enemy: EnemyInstanceState): void {
  if (enemy.isKo) return;
  enemy.isKo = true;
  enemy.koTimer = 0.35;
  state.enemiesDefeated += 1;
  const spec = ENEMY_SPECS[enemy.archetype];
  state.score += spec.rewardTokens * 10;
  state.tokens += Math.round(spec.rewardTokens * 0.6);
  state.tokenDrops.push({
    id: state.nextEntityId++,
    x: enemy.x,
    z: enemy.z,
    amount: Math.ceil(spec.rewardTokens * 0.5),
    collected: false,
    age: 0,
  });
}

export function stepPlayerMomentum(
  state: GameSimulationState,
  thrustX: number,
  thrustZ: number,
  dt: number,
): { wallBounced: boolean; bumperBounced: boolean; bumperShatter?: ShatterEvent } {
  const p = state.player;

  // Normalize thrust vector if diagonal
  const mag = Math.hypot(thrustX, thrustZ);
  const nx = mag > 1 ? thrustX / mag : thrustX;
  const nz = mag > 1 ? thrustZ / mag : thrustZ;

  // Momentum acceleration
  p.vx += nx * MOMENTUM_PHYSICS.thrustAccel * dt;
  p.vz += nz * MOMENTUM_PHYSICS.thrustAccel * dt;

  // Low surface friction exponential decay (pure momentum glide)
  const dragFactor = Math.exp(-MOMENTUM_PHYSICS.dragPerSecond * dt);
  p.vx *= dragFactor;
  p.vz *= dragFactor;

  clampPlayerSpeed(state);

  // Advance position
  p.x += p.vx * dt;
  p.z += p.vz * dt;

  const stepDist = Math.hypot(p.vx * dt, p.vz * dt);
  p.distanceTraveled += stepDist;

  if (stepDist > 0.002) {
    p.heading = Math.atan2(p.vx, p.vz);
  }

  // Smoothly damp squash & stretch back to 1
  const damp = 1 - Math.exp(-12 * dt);
  p.squashX += (1 - p.squashX) * damp;
  p.squashY += (1 - p.squashY) * damp;

  if (p.invulnTimer > 0) p.invulnTimer = Math.max(0, p.invulnTimer - dt);
  if (p.boostCooldown > 0) p.boostCooldown = Math.max(0, p.boostCooldown - dt);

  let wallBounced = false;
  const minX = ARENA_BOUNDS.minX + p.radius;
  const maxX = ARENA_BOUNDS.maxX - p.radius;
  const minZ = ARENA_BOUNDS.minZ + p.radius;
  const maxZ = ARENA_BOUNDS.maxZ - p.radius;

  if (p.x < minX) {
    p.x = minX;
    p.vx = Math.abs(p.vx) * MOMENTUM_PHYSICS.wallRestitution;
    wallBounced = true;
  } else if (p.x > maxX) {
    p.x = maxX;
    p.vx = -Math.abs(p.vx) * MOMENTUM_PHYSICS.wallRestitution;
    wallBounced = true;
  }

  if (p.z < minZ) {
    p.z = minZ;
    p.vz = Math.abs(p.vz) * MOMENTUM_PHYSICS.wallRestitution;
    wallBounced = true;
  } else if (p.z > maxZ) {
    p.z = maxZ;
    p.vz = -Math.abs(p.vz) * MOMENTUM_PHYSICS.wallRestitution;
    wallBounced = true;
  }

  if (wallBounced) {
    p.squashX = 1.2;
    p.squashY = 0.82;
  }

  // Check collisions with single-use Arcade Pinball Bumpers
  let bumperBounced = false;
  let bumperShatter: ShatterEvent | undefined;

  for (let i = 0; i < state.bumpers.length; i++) {
    const b = state.bumpers[i];
    if (b.hitTimer > 0) b.hitTimer = Math.max(0, b.hitTimer - dt);
    if (b.shattered) {
      b.respawnTimer -= dt;
      if (b.respawnTimer <= 0) {
        b.shattered = false;
        b.usesRemaining = 1;
      }
      continue;
    }

    const dx = p.x - b.x;
    const dz = p.z - b.z;
    const minDist = p.radius + b.radius;
    const distSq = dx * dx + dz * dz;
    if (distSq < minDist * minDist) {
      const dist = Math.max(0.001, Math.sqrt(distSq));
      const normalX = dx / dist;
      const normalZ = dz / dist;
      p.x = b.x + normalX * (minDist + 0.04);
      p.z = b.z + normalZ * (minDist + 0.04);
      p.vx = normalX * MOMENTUM_PHYSICS.bumperImpulse;
      p.vz = normalZ * MOMENTUM_PHYSICS.bumperImpulse;
      p.squashX = 1.25;
      p.squashY = 0.76;

      // Every bumper also breaks after 1 use before recharging!
      b.hitTimer = 0.35;
      b.usesRemaining = 0;
      b.shattered = true;
      b.respawnTimer = 6.0;
      state.itemsShattered += 1;
      state.score += 50;
      bumperBounced = true;
      const label = 'KINETIC BUMPER SHATTERED (1/1 USE)';
      state.lastShatterBanner = label;
      state.lastShatterBannerTimer = 2.0;
      bumperShatter = {
        x: b.x,
        z: b.z,
        colorHex: 0xf43f5e,
        label,
        targetPositions: [{ x: p.x, z: p.z }],
      };
    }
  }

  return { wallBounced, bumperBounced, bumperShatter };
}

export function stepSingleUseTowers(
  state: GameSimulationState,
  dt: number,
): ShatterEvent[] {
  const shatterEvents: ShatterEvent[] = [];

  for (let i = 0; i < state.pads.length; i++) {
    if (state.pads[i].shatterCooldown > 0) {
      state.pads[i].shatterCooldown = Math.max(0, state.pads[i].shatterCooldown - dt);
    }
  }

  for (let i = state.towers.length - 1; i >= 0; i--) {
    const tower = state.towers[i];
    if (tower.shattered) {
      tower.shatterAnimTimer -= dt;
      if (tower.shatterAnimTimer <= 0) {
        state.towers.splice(i, 1);
      }
      continue;
    }

    const spec = TOWER_SPECS[tower.type];
    const rangeSq = spec.range * spec.range;

    // Find living enemies within range
    const inRange: { enemy: EnemyInstanceState; distSq: number }[] = [];
    for (let j = 0; j < state.enemies.length; j++) {
      const enemy = state.enemies[j];
      if (enemy.isKo) continue;
      const dx = enemy.x - tower.x;
      const dz = enemy.z - tower.z;
      const distSq = dx * dx + dz * dz;
      if (distSq <= rangeSq) {
        inRange.push({ enemy, distSq });
      }
    }

    if (inRange.length === 0) continue;

    // Sort by closest to the Central Core (highest Z) so towers prioritize biggest threats
    inRange.sort((a, b) => b.enemy.z - a.enemy.z);
    const primaryTarget = inRange[0].enemy;
    tower.aimAngle = Math.atan2(primaryTarget.x - tower.x, primaryTarget.z - tower.z);

    const targetPositions: Vec2[] = [];

    if (tower.type === TowerType.PULSE_LASER) {
      primaryTarget.hp -= spec.damage;
      primaryTarget.hitFlashTimer = 0.12;
      targetPositions.push({ x: primaryTarget.x, z: primaryTarget.z });
      if (primaryTarget.hp <= 0) {
        markEnemyKo(state, primaryTarget);
      }
    } else if (tower.type === TowerType.CRYO_CAPACITOR) {
      for (let k = 0; k < inRange.length; k++) {
        const target = inRange[k].enemy;
        target.hp -= spec.damage;
        target.slowTimer = Math.max(target.slowTimer, 3.8);
        target.hitFlashTimer = 0.12;
        targetPositions.push({ x: target.x, z: target.z });
        if (target.hp <= 0) {
          markEnemyKo(state, target);
        }
      }
    } else if (tower.type === TowerType.TESLA_COIL) {
      const maxChain = Math.min(4, inRange.length);
      for (let k = 0; k < maxChain; k++) {
        const target = inRange[k].enemy;
        target.hp -= spec.damage;
        target.hitFlashTimer = 0.12;
        targetPositions.push({ x: target.x, z: target.z });
        if (target.hp <= 0) {
          markEnemyKo(state, target);
        }
      }
    }

    // ONE-USE RULE: Every tower breaks immediately after its single activation!
    tower.usesRemaining = 0;
    tower.shattered = true;
    tower.shatterAnimTimer = 0.42;
    state.itemsShattered += 1;

    const pad = state.pads.find((p) => p.id === tower.padId);
    if (pad) {
      pad.towerId = null;
      pad.shatterCooldown = 1.0;
    }

    const label = `${spec.name.toUpperCase()} SHATTERED (1/1 USE)`;
    state.lastShatterBanner = label;
    state.lastShatterBannerTimer = 2.4;

    shatterEvents.push({
      x: tower.x,
      z: tower.z,
      colorHex: spec.colorHex,
      label,
      targetPositions,
    });
  }

  return shatterEvents;
}

export function spawnEnemyForWave(
  state: GameSimulationState,
  forcedArchetype?: EnemyArchetype,
  forcedLane?: number,
): EnemyInstanceState {
  const laneIndex =
    typeof forcedLane === 'number'
      ? forcedLane % LANE_WAYPOINTS.length
      : (state.nextEntityId + state.wave) % LANE_WAYPOINTS.length;

  let archetype = forcedArchetype;
  if (!archetype) {
    const roll = (state.nextEntityId * 37 + state.wave * 13) % 100;
    if (state.wave === 1) {
      archetype = roll < 75 ? EnemyArchetype.SWARMER : EnemyArchetype.LANCER;
    } else if (state.wave === 2) {
      if (roll < 45) archetype = EnemyArchetype.SWARMER;
      else if (roll < 82) archetype = EnemyArchetype.LANCER;
      else archetype = EnemyArchetype.JUGGERNAUT;
    } else {
      if (roll < 35) archetype = EnemyArchetype.SWARMER;
      else if (roll < 70) archetype = EnemyArchetype.LANCER;
      else archetype = EnemyArchetype.JUGGERNAUT;
    }
  }

  const spec = ENEMY_SPECS[archetype];
  const startWp = LANE_WAYPOINTS[laneIndex][0];
  const hpMultiplier = 1 + (state.wave - 1) * 0.14;

  const enemy: EnemyInstanceState = {
    id: state.nextEntityId++,
    archetype,
    laneIndex,
    waypointIndex: 1,
    x: startWp.x,
    z: startWp.z,
    vx: 0,
    vz: spec.speed,
    hp: Math.round(spec.maxHp * hpMultiplier),
    maxHp: Math.round(spec.maxHp * hpMultiplier),
    speed: spec.speed * (1 + Math.min(0.25, (state.wave - 1) * 0.05)),
    radius: spec.radius,
    slowTimer: 0,
    hitFlashTimer: 0,
    windupTimer: 0,
    windupDuration: archetype === EnemyArchetype.JUGGERNAUT ? 0.65 : 0.55,
    isWindingUp: false,
    dashTimer: 0,
    dashDirX: 0,
    dashDirZ: 1,
    weavePhase: (state.nextEntityId % 6) * 0.9,
    koTimer: 0,
    isKo: false,
  };

  state.enemies.push(enemy);
  return enemy;
}

export function stepSimulationTick(
  state: GameSimulationState,
  thrustX: number,
  thrustZ: number,
  dt: number,
): StepTickResult {
  const clampedDt = Math.min(Math.max(dt, 0), 0.05);
  const result: StepTickResult = {
    shatterEvents: [],
    collectedFragmentIds: [],
    collectedTokensAmount: 0,
    enemiesKilled: [],
    heavyHitOccurred: false,
    bumperBounced: false,
    wallBounced: false,
    windupStarted: false,
    coreDamaged: false,
    playerDamaged: false,
    outcomeChanged: 'none',
  };

  if (state.phase !== 'playing' || state.outcome !== 'none') {
    return result;
  }

  state.elapsedSeconds += clampedDt;
  if (state.lastShatterBannerTimer > 0) {
    state.lastShatterBannerTimer = Math.max(0, state.lastShatterBannerTimer - clampedDt);
  }

  // 1. Step momentum-driven player orb
  const mom = stepPlayerMomentum(state, thrustX, thrustZ, clampedDt);
  result.wallBounced = mom.wallBounced;
  result.bumperBounced = mom.bumperBounced;
  if (mom.bumperShatter) {
    result.shatterEvents.push(mom.bumperShatter);
  }

  // 2. Collect Torn Map Fragments
  const pickupRadSq = MOMENTUM_PHYSICS.fragmentPickupRadius * MOMENTUM_PHYSICS.fragmentPickupRadius;
  for (let i = 0; i < state.mapFragments.length; i++) {
    const frag = state.mapFragments[i];
    if (frag.collected) {
      if (frag.collectAnimTimer > 0) {
        frag.collectAnimTimer = Math.max(0, frag.collectAnimTimer - clampedDt);
      }
      continue;
    }
    const dx = frag.x - state.player.x;
    const dz = frag.z - state.player.z;
    if (dx * dx + dz * dz <= pickupRadSq) {
      frag.collected = true;
      frag.collectAnimTimer = 0.6;
      state.score += 300;
      state.tokens += 35;
      state.empCharges += 1;
      result.collectedFragmentIds.push(frag.id);
      result.heavyHitOccurred = true;
      state.lastShatterBanner = `COLLECTED ${frag.label.toUpperCase()} (+35 TOKENS, +1 EMP)`;
      state.lastShatterBannerTimer = 2.8;
    }
  }

  // Check if all 6 torn map fragments have been collected -> VICTORY!
  const collectedCount = getCollectedMapCount(state);
  if (collectedCount >= state.mapFragments.length) {
    state.outcome = 'victory';
    state.phase = 'gameover';
    state.score += state.coreHp * 150 + state.player.hp * 100;
    state.bestScore = Math.max(state.bestScore, state.score);
    result.outcomeChanged = 'victory';
    return result;
  }

  // 3. Collect Token Drops
  const tokenRadSq = MOMENTUM_PHYSICS.tokenPickupRadius * MOMENTUM_PHYSICS.tokenPickupRadius;
  for (let i = state.tokenDrops.length - 1; i >= 0; i--) {
    const drop = state.tokenDrops[i];
    drop.age += clampedDt;
    const dx = drop.x - state.player.x;
    const dz = drop.z - state.player.z;
    if (dx * dx + dz * dz <= tokenRadSq) {
      state.tokens += drop.amount;
      state.score += drop.amount * 5;
      result.collectedTokensAmount += drop.amount;
      state.tokenDrops.splice(i, 1);
    } else if (drop.age > 18) {
      state.tokenDrops.splice(i, 1);
    }
  }

  // 4. Wave progression & enemy spawning
  state.waveTimer += clampedDt;
  if (state.waveTimer >= 22) {
    state.waveTimer = 0;
    state.wave += 1;
    state.tokens += 20;
  }

  state.spawnTimer -= clampedDt;
  const maxActiveEnemies = Math.min(10, 4 + state.wave * 2);
  if (state.spawnTimer <= 0 && state.enemies.length < maxActiveEnemies) {
    spawnEnemyForWave(state);
    const baseInterval = Math.max(1.6, 3.6 - (state.wave - 1) * 0.35);
    state.spawnTimer = baseInterval;
  }

  // 5. Step Single-Use Towers
  const towerShatters = stepSingleUseTowers(state, clampedDt);
  if (towerShatters.length > 0) {
    result.shatterEvents.push(...towerShatters);
    result.heavyHitOccurred = true;
  }

  // 6. Step Enemies (3 distinct movement & windup policies + kinetic ramming)
  let concurrentWindups = 0;
  for (let i = 0; i < state.enemies.length; i++) {
    if (state.enemies[i].isWindingUp) concurrentWindups++;
  }

  const playerSpeed = Math.hypot(state.player.vx, state.player.vz);

  for (let i = state.enemies.length - 1; i >= 0; i--) {
    const enemy = state.enemies[i];
    if (enemy.hitFlashTimer > 0) {
      enemy.hitFlashTimer = Math.max(0, enemy.hitFlashTimer - clampedDt);
    }

    if (enemy.isKo) {
      enemy.koTimer -= clampedDt;
      if (enemy.koTimer <= 0) {
        result.enemiesKilled.push({ x: enemy.x, z: enemy.z });
        state.enemies.splice(i, 1);
      }
      continue;
    }

    if (enemy.slowTimer > 0) {
      enemy.slowTimer = Math.max(0, enemy.slowTimer - clampedDt);
    }
    const slowMult = enemy.slowTimer > 0 ? 0.45 : 1.0;

    // Distinct Archetype Movement & Windup Policies
    const lane = LANE_WAYPOINTS[enemy.laneIndex];
    const targetWp = lane[Math.min(enemy.waypointIndex, lane.length - 1)];
    const toWpX = targetWp.x - enemy.x;
    const toWpZ = targetWp.z - enemy.z;
    const distToWp = Math.hypot(toWpX, toWpZ);

    if (distToWp < 0.45 && enemy.waypointIndex < lane.length - 1) {
      enemy.waypointIndex += 1;
    }

    const dirX = distToWp > 0.001 ? toWpX / distToWp : 0;
    const dirZ = distToWp > 0.001 ? toWpZ / distToWp : 1;

    if (enemy.archetype === EnemyArchetype.SWARMER) {
      // Policy 1: High-frequency sinusoidal lateral weave along the circuit lane
      enemy.weavePhase += clampedDt * 5.2;
      const perpX = -dirZ;
      const perpZ = dirX;
      const weaveOffset = Math.cos(enemy.weavePhase) * 1.35;
      enemy.vx = (dirX * enemy.speed + perpX * weaveOffset) * slowMult;
      enemy.vz = (dirZ * enemy.speed + perpZ * weaveOffset) * slowMult;
      enemy.x += enemy.vx * clampedDt;
      enemy.z += enemy.vz * clampedDt;
    } else if (enemy.archetype === EnemyArchetype.LANCER) {
      // Policy 2: Vector Lancer pauses for a 0.55s visible windup telegraph before dashing!
      const dxPlayer = state.player.x - enemy.x;
      const dzPlayer = state.player.z - enemy.z;
      const distPlayer = Math.hypot(dxPlayer, dzPlayer);

      if (enemy.dashTimer > 0) {
        enemy.dashTimer -= clampedDt;
        enemy.vx = enemy.dashDirX * enemy.speed * 2.8 * slowMult;
        enemy.vz = enemy.dashDirZ * enemy.speed * 2.8 * slowMult;
        enemy.x += enemy.vx * clampedDt;
        enemy.z += enemy.vz * clampedDt;
      } else if (enemy.isWindingUp) {
        enemy.vx = 0;
        enemy.vz = 0;
        enemy.windupTimer += clampedDt;
        if (enemy.windupTimer >= enemy.windupDuration) {
          enemy.isWindingUp = false;
          enemy.windupTimer = 0;
          enemy.dashTimer = 0.38;
        }
      } else if (distPlayer < 3.8 && concurrentWindups < 3) {
        enemy.isWindingUp = true;
        enemy.windupTimer = 0;
        enemy.dashDirX = dxPlayer / Math.max(0.01, distPlayer);
        enemy.dashDirZ = dzPlayer / Math.max(0.01, distPlayer);
        concurrentWindups++;
        result.windupStarted = true;
      } else {
        enemy.vx = dirX * enemy.speed * slowMult;
        enemy.vz = dirZ * enemy.speed * slowMult;
        enemy.x += enemy.vx * clampedDt;
        enemy.z += enemy.vz * clampedDt;
      }
    } else {
      // Policy 3: Juggernaut heavy armored march with 0.65s Core-Slam windup telegraph near Core
      const distCore = Math.hypot(CORE_POSITION.x - enemy.x, CORE_POSITION.z - enemy.z);
      if (enemy.isWindingUp) {
        enemy.vx = 0;
        enemy.vz = 0;
        enemy.windupTimer += clampedDt;
        if (enemy.windupTimer >= enemy.windupDuration) {
          enemy.isWindingUp = false;
          enemy.windupTimer = 0;
          // Heavy slam lunge into Core
          enemy.x += dirX * 0.9;
          enemy.z += dirZ * 0.9;
        }
      } else if (distCore < 2.2 && concurrentWindups < 3) {
        enemy.isWindingUp = true;
        enemy.windupTimer = 0;
        concurrentWindups++;
        result.windupStarted = true;
      } else {
        enemy.vx = dirX * enemy.speed * slowMult;
        enemy.vz = dirZ * enemy.speed * slowMult;
        enemy.x += enemy.vx * clampedDt;
        enemy.z += enemy.vz * clampedDt;
      }
    }

    // Check collision with Player Momentum Orb
    const dxP = state.player.x - enemy.x;
    const dzP = state.player.z - enemy.z;
    const minDistP = state.player.radius + enemy.radius;
    if (dxP * dxP + dzP * dzP < minDistP * minDistP) {
      const distP = Math.max(0.01, Math.hypot(dxP, dzP));
      const nx = dxP / distP;
      const nz = dzP / distP;

      if (playerSpeed >= 5.2 || state.player.invulnTimer > 0) {
        // High-momentum kinetic slam damages enemy and bounces orb!
        enemy.hp -= 95;
        enemy.hitFlashTimer = 0.14;
        state.player.vx = nx * 6.5;
        state.player.vz = nz * 6.5;
        state.player.squashX = 1.24;
        state.player.squashY = 0.78;
        result.heavyHitOccurred = true;
        if (enemy.hp <= 0) {
          markEnemyKo(state, enemy);
          continue;
        }
      } else if (state.player.invulnTimer <= 0) {
        // Enemy damages player orb if orb is moving slowly and not invulnerable
        state.player.hp = Math.max(0, state.player.hp - 1);
        state.player.invulnTimer = 1.25;
        state.player.vx = nx * 7.0;
        state.player.vz = nz * 7.0;
        result.playerDamaged = true;
        result.heavyHitOccurred = true;
      }
    }

    // Check if Enemy reached Central Arcade Core
    const dxC = CORE_POSITION.x - enemy.x;
    const dzC = CORE_POSITION.z - enemy.z;
    if (dxC * dxC + dzC * dzC <= 1.25 * 1.25) {
      const spec = ENEMY_SPECS[enemy.archetype];
      state.coreHp = Math.max(0, state.coreHp - spec.coreDamage);
      result.coreDamaged = true;
      result.heavyHitOccurred = true;
      state.enemies.splice(i, 1);
    }
  }

  // 7. Check Loss Conditions (Core destroyed or Player Hull depleted)
  if (state.coreHp <= 0) {
    state.outcome = 'defeat';
    state.phase = 'gameover';
    state.defeatReason = 'CENTRAL ARCADE CORE BREACHED';
    state.bestScore = Math.max(state.bestScore, state.score);
    result.outcomeChanged = 'defeat';
  } else if (state.player.hp <= 0) {
    state.outcome = 'defeat';
    state.phase = 'gameover';
    state.defeatReason = 'TRACKBALL COURIER SHATTERED';
    state.bestScore = Math.max(state.bestScore, state.score);
    result.outcomeChanged = 'defeat';
  }

  return result;
}

export function createRunSnapshot(state: GameSimulationState): RunSnapshot {
  return {
    outcome: state.outcome === 'victory' ? 'victory' : 'defeat',
    reason:
      state.outcome === 'victory'
        ? 'SHATTERED ATLAS RESTORED (6/6 FRAGMENTS)'
        : state.defeatReason || 'ARCADE CABINET OVERRUN',
    score: Math.round(state.score),
    bestScore: Math.round(Math.max(state.bestScore, state.score)),
    mapCollected: getCollectedMapCount(state),
    mapTotal: state.mapFragments.length,
    waveReached: state.wave,
    itemsShattered: state.itemsShattered,
    enemiesDefeated: state.enemiesDefeated,
    clearTimeSeconds: Math.round(state.elapsedSeconds),
    coreHpRemaining: state.coreHp,
  };
}
