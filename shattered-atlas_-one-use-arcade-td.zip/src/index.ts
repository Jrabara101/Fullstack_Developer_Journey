import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import * as xb from 'xrblocks';
import { ArcadeDefenseScene } from './ArcadeDefenseScene';

/**
 * Detect software WebGL (SwiftShader, llvmpipe, softpipe, WARP) from the GPU renderer string.
 */
const isSoftwareGl = (() => {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
})();

async function bootstrap(): Promise<void> {
  const options = new xb.Options();
  options.antialias = !isSoftwareGl;
  options.enableSimulator = false;
  options.xrButton.enabled = false;
  options.setAppTitle('Shattered Atlas: One-Use Arcade TD');
  options.setAppDescription(
    'Steer your momentum-driven trackball courier to collect all 6 pieces of a torn map while every deployed tower and item breaks after one use.',
  );

  const gameScene = new ArcadeDefenseScene(isSoftwareGl);
  xb.add(gameScene);
  await xb.init(options);

  const renderer = xb.core.renderer as THREE.WebGLRenderer | undefined;
  if (renderer) {
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Generate zero-dependency Studio RoomEnvironment reflection map
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    xb.core.scene.environment = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04,
    ).texture;
    pmremGenerator.dispose();

    // On software WebGL (SwiftShader), pace the continuous loop with afterDraw(tick)
    // so CPU WebGL rendering never starves the main thread or browser automation.
    if (isSoftwareGl) {
      xb.core.pause();
      renderer.setAnimationLoop(null);
      const gl = renderer.getContext() as WebGL2RenderingContext;

      const afterDraw = (cb: () => void) => {
        if (!gl || typeof gl.fenceSync !== 'function') {
          window.setTimeout(cb, 80);
          return;
        }
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            window.setTimeout(cb, 80);
          }
        };
        window.setTimeout(poll, 5);
      };

      const tick = () => {
        xb.core.stepFrame(33.3);
        afterDraw(tick);
      };
      tick();
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  void bootstrap();
});
