import * as THREE from 'three';

const MAX_PARTICLES = 240;
const _dummyMat = new THREE.Matrix4();
const _dummyPos = new THREE.Vector3();
const _dummyQuat = new THREE.Quaternion();
const _dummyScale = new THREE.Vector3();
const _dummyEuler = new THREE.Euler();
const _dummyColor = new THREE.Color();

/**
 * Zero-GC pooled particle system using a single THREE.InstancedMesh.
 * Used for shattered single-use item debris, laser impacts, bumper sparks, and map collection bursts.
 */
export class ParticlePool {
  public readonly mesh: THREE.InstancedMesh;
  private readonly geometry: THREE.BufferGeometry;
  private readonly material: THREE.MeshStandardMaterial;

  private readonly posX = new Float32Array(MAX_PARTICLES);
  private readonly posY = new Float32Array(MAX_PARTICLES);
  private readonly posZ = new Float32Array(MAX_PARTICLES);
  private readonly velX = new Float32Array(MAX_PARTICLES);
  private readonly velY = new Float32Array(MAX_PARTICLES);
  private readonly velZ = new Float32Array(MAX_PARTICLES);
  private readonly rotSpeed = new Float32Array(MAX_PARTICLES);
  private readonly age = new Float32Array(MAX_PARTICLES);
  private readonly maxLife = new Float32Array(MAX_PARTICLES);
  private readonly baseScale = new Float32Array(MAX_PARTICLES);
  private head = 0;

  constructor() {
    this.geometry = new THREE.OctahedronGeometry(0.11, 0);
    this.material = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.25,
      metalness: 0.7,
      emissive: 0x222222,
    });
    this.mesh = new THREE.InstancedMesh(this.geometry, this.material, MAX_PARTICLES);
    this.mesh.frustumCulled = false;
    this.mesh.xb = { pointerEvents: 'none' };

    _dummyScale.setScalar(0);
    _dummyMat.makeScale(0, 0, 0);
    for (let i = 0; i < MAX_PARTICLES; i++) {
      this.maxLife[i] = 0;
      this.mesh.setMatrixAt(i, _dummyMat);
      this.mesh.setColorAt(i, _dummyColor.setHex(0xffffff));
    }
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  public emitBurst(
    x: number,
    y: number,
    z: number,
    colorHex: number,
    count = 18,
    speed = 4.2,
    scale = 1.0,
  ): void {
    _dummyColor.setHex(colorHex);
    for (let i = 0; i < count; i++) {
      const idx = this.head;
      this.head = (this.head + 1) % MAX_PARTICLES;

      const angle = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
      const horizSpeed = speed * (0.45 + Math.random() * 0.75);

      this.posX[idx] = x + (Math.random() - 0.5) * 0.2;
      this.posY[idx] = y + Math.random() * 0.25;
      this.posZ[idx] = z + (Math.random() - 0.5) * 0.2;

      this.velX[idx] = Math.cos(angle) * horizSpeed;
      this.velY[idx] = 2.0 + Math.random() * 3.6;
      this.velZ[idx] = Math.sin(angle) * horizSpeed;

      this.rotSpeed[idx] = (Math.random() - 0.5) * 12;
      this.age[idx] = 0;
      this.maxLife[idx] = 0.35 + Math.random() * 0.35;
      this.baseScale[idx] = scale * (0.7 + Math.random() * 0.65);

      this.mesh.setColorAt(idx, _dummyColor);
    }
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  public update(dt: number): void {
    let anyUpdated = false;
    for (let i = 0; i < MAX_PARTICLES; i++) {
      const life = this.maxLife[i];
      if (life <= 0) continue;

      anyUpdated = true;
      this.age[i] += dt;
      if (this.age[i] >= life) {
        this.maxLife[i] = 0;
        _dummyMat.makeScale(0, 0, 0);
        this.mesh.setMatrixAt(i, _dummyMat);
        continue;
      }

      this.velY[i] -= 11.5 * dt; // Gravity
      this.posX[i] += this.velX[i] * dt;
      this.posY[i] = Math.max(0.05, this.posY[i] + this.velY[i] * dt);
      this.posZ[i] += this.velZ[i] * dt;

      const t = 1 - this.age[i] / life;
      const s = this.baseScale[i] * t;

      _dummyPos.set(this.posX[i], this.posY[i], this.posZ[i]);
      const r = this.age[i] * this.rotSpeed[i];
      _dummyEuler.set(r, r * 0.7, r * 1.3);
      _dummyQuat.setFromEuler(_dummyEuler);
      _dummyScale.setScalar(s);
      _dummyMat.compose(_dummyPos, _dummyQuat, _dummyScale);
      this.mesh.setMatrixAt(i, _dummyMat);
    }

    if (anyUpdated) {
      this.mesh.instanceMatrix.needsUpdate = true;
    }
  }

  public dispose(): void {
    this.geometry.dispose();
    this.material.dispose();
  }
}
