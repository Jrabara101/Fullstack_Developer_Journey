import * as THREE from 'three';
import {
  ARENA_BOUNDS,
  CORE_POSITION,
  ENEMY_SPECS,
  INITIAL_BUMPERS,
  INITIAL_SOCKET_PADS,
  LANE_WAYPOINTS,
  TOWER_SPECS,
} from '../constants';
import { EnemyArchetype, TowerType } from '../types';
import { ArcadeTextureSet } from './ProceduralTextures';

/**
 * Creates a soft radial contact shadow disc grounded at y = 0.015 to prevent Z-fighting.
 */
export function createContactShadowDisc(
  radius: number,
  shadowTex: THREE.Texture,
  opacity = 0.48,
): THREE.Mesh {
  const geo = new THREE.CircleGeometry(radius, 20);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    opacity,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.015;
  mesh.xb = { pointerEvents: 'none' };
  return mesh;
}

/**
 * 1. KINETIC TRACKBALL COURIER (Player Orb) - 6-part composite THREE.Group
 * Pivoted at bottom-center (y = 0) with varied roughness & metalness across parts.
 */
export interface PlayerOrbRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  outerRing: THREE.Mesh;
  innerRing: THREE.Mesh;
  tailFin: THREE.Mesh;
  coreCrystal: THREE.Mesh;
  shieldHalo: THREE.Mesh;
}

export function createPlayerTrackballModel(textures: ArcadeTextureSet): PlayerOrbRig {
  const root = new THREE.Group();
  root.name = 'KineticTrackballPlayer';

  // Contact shadow flush on playfield
  root.add(createContactShadowDisc(0.76, textures.contactShadowTex, 0.55));

  const bodyGroup = new THREE.Group();
  bodyGroup.position.y = 0.52;
  root.add(bodyGroup);

  // Part 1: Primary silhouette - LatheGeometry brushed titanium lower hemisphere bowl
  const lathePoints: THREE.Vector2[] = [];
  for (let i = 0; i <= 8; i++) {
    const angle = (i / 8) * (Math.PI * 0.55);
    lathePoints.push(new THREE.Vector2(Math.sin(angle) * 0.46, -Math.cos(angle) * 0.42));
  }
  const hullGeo = new THREE.LatheGeometry(lathePoints, 24);
  const hullMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    metalness: 0.88,
    roughness: 0.22,
    roughnessMap: textures.brushedMetalRoughness,
  });
  const hullMesh = new THREE.Mesh(hullGeo, hullMat);
  bodyGroup.add(hullMesh);

  // Part 2: Secondary read - Glossy smoked-glass upper canopy dome (roughness delta >= 0.25)
  const domeGeo = new THREE.SphereGeometry(0.42, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.52);
  const domeMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    metalness: 0.15,
    roughness: 0.08,
    transparent: true,
    opacity: 0.68,
    depthWrite: false,
  });
  const domeMesh = new THREE.Mesh(domeGeo, domeMat);
  domeMesh.renderOrder = 2;
  bodyGroup.add(domeMesh);

  // Part 3: Outer Equatorial Gimbal Ring
  const outerRingGeo = new THREE.TorusGeometry(0.52, 0.045, 12, 32);
  outerRingGeo.rotateX(Math.PI / 2);
  const outerRingMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    metalness: 0.78,
    roughness: 0.35,
    emissive: 0x451a03,
  });
  const outerRing = new THREE.Mesh(outerRingGeo, outerRingMat);
  bodyGroup.add(outerRing);

  // Part 4: Inner Counter-Rotating Gyro Ring
  const innerRingGeo = new THREE.TorusGeometry(0.36, 0.03, 10, 24);
  const innerRingMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    metalness: 0.5,
    roughness: 0.48,
    emissive: 0x083344,
  });
  const innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
  bodyGroup.add(innerRing);

  // Part 5: ExtrudeGeometry Beveled Directional Vector Tail Fin
  const finShape = new THREE.Shape();
  finShape.moveTo(0, -0.1);
  finShape.lineTo(0.28, -0.05);
  finShape.lineTo(0.42, 0.22);
  finShape.lineTo(0.08, 0.18);
  finShape.closePath();
  const finGeo = new THREE.ExtrudeGeometry(finShape, {
    depth: 0.06,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 1,
    bevelSize: 0.015,
    bevelThickness: 0.015,
  });
  finGeo.center();
  finGeo.rotateY(Math.PI / 2);
  const finMat = new THREE.MeshStandardMaterial({
    color: 0xf43f5e,
    metalness: 0.4,
    roughness: 0.55,
    emissive: 0x4c0519,
  });
  const tailFin = new THREE.Mesh(finGeo, finMat);
  tailFin.position.set(0, 0.12, -0.44);
  bodyGroup.add(tailFin);

  // Part 6: Glowing Central Gyro Core Crystal
  const coreGeo = new THREE.OctahedronGeometry(0.19, 0);
  const coreMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.4,
    roughness: 0.18,
    metalness: 0.2,
  });
  const coreCrystal = new THREE.Mesh(coreGeo, coreMat);
  bodyGroup.add(coreCrystal);

  // Shield / Overdrive Halo Ring
  const haloGeo = new THREE.RingGeometry(0.58, 0.68, 28);
  haloGeo.rotateX(-Math.PI / 2);
  const haloMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.0,
    depthWrite: false,
  });
  const shieldHalo = new THREE.Mesh(haloGeo, haloMat);
  shieldHalo.position.y = 0.05;
  root.add(shieldHalo);

  return {
    root,
    bodyGroup,
    outerRing,
    innerRing,
    tailFin,
    coreCrystal,
    shieldHalo,
  };
}

/**
 * 2. TORN MAP FRAGMENT PICKUP (5-part composite THREE.Group with jagged ExtrudeGeometry)
 */
export function createMapFragmentModel(
  pieceIndex: number,
  textures: ArcadeTextureSet,
): THREE.Group {
  const group = new THREE.Group();
  group.name = `TornMapFragment_${pieceIndex + 1}`;
  group.add(createContactShadowDisc(0.65, textures.contactShadowTex, 0.48));

  const floatRoot = new THREE.Group();
  floatRoot.name = 'floatRoot';
  floatRoot.position.y = 0.48;
  group.add(floatRoot);

  // Part 1: Jagged Torn Map Parchment Shard (ExtrudeGeometry with unique jagged tear per piece)
  const shardShape = new THREE.Shape();
  const seed = (pieceIndex + 1) * 1.37;
  const pts = [
    [-0.36, -0.28],
    [-0.08 + Math.sin(seed) * 0.08, -0.34],
    [0.34, -0.22 + Math.cos(seed) * 0.06],
    [0.38, 0.14],
    [0.12, 0.34 - Math.sin(seed * 2) * 0.07],
    [-0.32, 0.26],
    [-0.42 + Math.cos(seed * 1.5) * 0.06, -0.02],
  ];
  shardShape.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) {
    shardShape.lineTo(pts[i][0], pts[i][1]);
  }
  shardShape.closePath();

  const shardGeo = new THREE.ExtrudeGeometry(shardShape, {
    depth: 0.05,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 1,
    bevelSize: 0.02,
    bevelThickness: 0.02,
  });
  shardGeo.center();
  shardGeo.rotateX(-Math.PI * 0.25);

  const shardMat = new THREE.MeshStandardMaterial({
    color: 0xfef3c7,
    emissive: 0xd97706,
    emissiveIntensity: 0.45,
    roughness: 0.65,
    metalness: 0.15,
  });
  const shardMesh = new THREE.Mesh(shardGeo, shardMat);
  floatRoot.add(shardMesh);

  // Part 2: Raised Metallic Compass Rose Ring on the shard face
  const ringGeo = new THREE.TorusGeometry(0.18, 0.022, 10, 24);
  ringGeo.rotateX(-Math.PI * 0.25);
  const ringMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    emissive: 0x0891b2,
    emissiveIntensity: 0.8,
    metalness: 0.85,
    roughness: 0.2,
  });
  const ringMesh = new THREE.Mesh(ringGeo, ringMat);
  ringMesh.position.set(0, 0.04, 0.03);
  floatRoot.add(ringMesh);

  // Part 3: Compass Crosshair Bar
  const barGeo = new THREE.BoxGeometry(0.32, 0.025, 0.035);
  const barMesh = new THREE.Mesh(barGeo, ringMat);
  barMesh.position.set(0, 0.05, 0.04);
  floatRoot.add(barMesh);

  // Part 4: Overhead Beacon Diamond
  const beaconGeo = new THREE.OctahedronGeometry(0.11, 0);
  const beaconMat = new THREE.MeshStandardMaterial({
    color: 0x34d399,
    emissive: 0x10b981,
    emissiveIntensity: 1.3,
    roughness: 0.15,
    metalness: 0.3,
  });
  const beaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
  beaconMesh.position.set(0, 0.42, 0);
  floatRoot.add(beaconMesh);

  // Part 5: Base Holo Collector Ring on floor
  const baseRingGeo = new THREE.RingGeometry(0.48, 0.56, 24);
  baseRingGeo.rotateX(-Math.PI / 2);
  const baseRingMat = new THREE.MeshBasicMaterial({
    color: 0xf59e0b,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.7,
    depthWrite: false,
  });
  const baseRing = new THREE.Mesh(baseRingGeo, baseRingMat);
  baseRing.position.y = 0.025;
  group.add(baseRing);

  return group;
}

/**
 * 3. SINGLE-USE DEFENSE TOWERS (5-7 part composite THREE.Group per type)
 * Every tower features a fragile glass/crystal 1-Use Capacitor Cell that shatters on activation.
 */
export function createSingleUseTowerModel(
  type: TowerType,
  textures: ArcadeTextureSet,
): THREE.Group {
  const spec = TOWER_SPECS[type];
  const group = new THREE.Group();
  group.name = `SingleUseTower_${type}`;
  group.add(createContactShadowDisc(0.68, textures.contactShadowTex, 0.5));

  // Part 1: Beveled Hexagonal Plinth Base (matte structural metal, roughness 0.72)
  const baseGeo = new THREE.CylinderGeometry(0.46, 0.54, 0.18, 6);
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.72,
    metalness: 0.45,
  });
  const baseMesh = new THREE.Mesh(baseGeo, baseMat);
  baseMesh.position.y = 0.09;
  group.add(baseMesh);

  // Part 2: Fragile 1-Use Glass Capacitor Collar (glossy roughness 0.12)
  const collarGeo = new THREE.CylinderGeometry(0.32, 0.36, 0.24, 16);
  const collarMat = new THREE.MeshStandardMaterial({
    color: spec.colorHex,
    emissive: spec.colorHex,
    emissiveIntensity: 0.65,
    roughness: 0.12,
    metalness: 0.2,
    transparent: true,
    opacity: 0.82,
  });
  const collarMesh = new THREE.Mesh(collarGeo, collarMat);
  collarMesh.position.y = 0.3;
  group.add(collarMesh);

  // Turret head group (rotates to aim)
  const turretHead = new THREE.Group();
  turretHead.name = 'turretHead';
  turretHead.position.y = 0.52;
  group.add(turretHead);

  const accentMat = new THREE.MeshStandardMaterial({
    color: spec.colorHex,
    metalness: 0.82,
    roughness: 0.24,
  });
  const darkTrimMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    metalness: 0.6,
    roughness: 0.58,
  });

  if (type === TowerType.PULSE_LASER) {
    // Yoke mount
    const yoke = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.22, 0.44), darkTrimMat);
    turretHead.add(yoke);
    // Twin rail barrels
    const barrelGeo = new THREE.CylinderGeometry(0.06, 0.075, 0.68, 12);
    barrelGeo.rotateX(Math.PI / 2);
    const leftBarrel = new THREE.Mesh(barrelGeo, accentMat);
    leftBarrel.position.set(-0.12, 0.04, 0.24);
    const rightBarrel = new THREE.Mesh(barrelGeo, accentMat);
    rightBarrel.position.set(0.12, 0.04, 0.24);
    turretHead.add(leftBarrel, rightBarrel);
    //Fragile 1-Shot Crystal Core on top
    const bulb = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 0), collarMat);
    bulb.position.set(0, 0.24, 0);
    turretHead.add(bulb);
  } else if (type === TowerType.CRYO_CAPACITOR) {
    // Ribbed cooling torus rings
    const ringGeo = new THREE.TorusGeometry(0.34, 0.05, 10, 24);
    ringGeo.rotateX(Math.PI / 2);
    const ring1 = new THREE.Mesh(ringGeo, accentMat);
    ring1.position.y = -0.06;
    const ring2 = new THREE.Mesh(ringGeo, darkTrimMat);
    ring2.position.y = 0.1;
    // Central cryo sphere
    const sphere = new THREE.Mesh(new THREE.IcosahedronGeometry(0.24, 1), collarMat);
    sphere.position.y = 0.22;
    turretHead.add(ring1, ring2, sphere);
  } else {
    // Tesla Arc Pylon: Insulator stack + top toroid crown + spark electrodes
    const column = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.2, 0.48, 16), darkTrimMat);
    column.position.y = 0.12;
    const crownGeo = new THREE.TorusGeometry(0.28, 0.065, 12, 24);
    crownGeo.rotateX(Math.PI / 2);
    const crown = new THREE.Mesh(crownGeo, accentMat);
    crown.position.y = 0.36;
    const sparkTip = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.28, 8), collarMat);
    sparkTip.position.y = 0.56;
    turretHead.add(column, crown, sparkTip);
  }

  return group;
}

/**
 * 4. ENEMY ARCHETYPE MODELS (5-6 part composite THREE.Group per archetype + Windup Telegraph Ring)
 */
export interface EnemyRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  telegraphRing: THREE.Mesh;
  telegraphLine: THREE.Mesh;
  primaryMaterials: THREE.MeshStandardMaterial[];
}

export function createEnemyModel(
  archetype: EnemyArchetype,
  textures: ArcadeTextureSet,
): EnemyRig {
  const spec = ENEMY_SPECS[archetype];
  const root = new THREE.Group();
  root.name = `Enemy_${archetype}`;
  root.add(createContactShadowDisc(spec.radius * 1.25, textures.contactShadowTex, 0.52));

  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const hullMat = new THREE.MeshStandardMaterial({
    color: spec.colorHex,
    roughness: 0.32,
    metalness: 0.68,
    emissive: spec.colorHex,
    emissiveIntensity: 0.25,
  });
  const armorMat = new THREE.MeshStandardMaterial({
    color: 0x1e1b4b,
    roughness: 0.68,
    metalness: 0.35,
  });
  const eyeMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0xfef08a,
    emissiveIntensity: 1.5,
    roughness: 0.15,
  });

  if (archetype === EnemyArchetype.SWARMER) {
    // 5-part Bit-Mite Swarmer
    const carapace = new THREE.Mesh(new THREE.OctahedronGeometry(0.36, 0), hullMat);
    carapace.position.y = 0.38;
    carapace.scale.set(1.0, 0.75, 1.35);
    bodyGroup.add(carapace);

    const dorsalFin = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.26, 0.42), armorMat);
    dorsalFin.position.set(0, 0.54, -0.05);
    bodyGroup.add(dorsalFin);

    const leftMandible = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 6), eyeMat);
    leftMandible.rotation.x = Math.PI / 2;
    leftMandible.position.set(-0.16, 0.32, 0.38);
    const rightMandible = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 6), eyeMat);
    rightMandible.rotation.x = Math.PI / 2;
    rightMandible.position.set(0.16, 0.32, 0.38);
    bodyGroup.add(leftMandible, rightMandible);
  } else if (archetype === EnemyArchetype.LANCER) {
    // 5-part Vector Lancer (sleek dart chassis + side wings + visor)
    const fuselageGeo = new THREE.ConeGeometry(0.32, 0.92, 6);
    fuselageGeo.rotateX(Math.PI / 2);
    const fuselage = new THREE.Mesh(fuselageGeo, hullMat);
    fuselage.position.y = 0.48;
    bodyGroup.add(fuselage);

    const wingGeo = new THREE.BoxGeometry(0.88, 0.06, 0.34);
    const wings = new THREE.Mesh(wingGeo, armorMat);
    wings.position.set(0, 0.46, -0.12);
    bodyGroup.add(wings);

    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.12, 0.24), eyeMat);
    visor.position.set(0, 0.56, 0.22);
    bodyGroup.add(visor);

    const thruster = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 0.2, 10), armorMat);
    thruster.rotation.x = Math.PI / 2;
    thruster.position.set(0, 0.48, -0.46);
    bodyGroup.add(thruster);
  } else {
    // 6-part Cabinet Juggernaut (heavy tank hull + twin treads + frontal energy shield + turret)
    const tankHull = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.48, 0.84), hullMat);
    tankHull.position.y = 0.42;
    bodyGroup.add(tankHull);

    const treadGeo = new THREE.BoxGeometry(0.18, 0.28, 0.96);
    const leftTread = new THREE.Mesh(treadGeo, armorMat);
    leftTread.position.set(-0.44, 0.22, 0);
    const rightTread = new THREE.Mesh(treadGeo, armorMat);
    rightTread.position.set(0.44, 0.22, 0);
    bodyGroup.add(leftTread, rightTread);

    const shieldGeo = new THREE.CylinderGeometry(0.58, 0.58, 0.52, 12, 1, true, -0.9, 1.8);
    const shieldMat = new THREE.MeshStandardMaterial({
      color: 0xfdba74,
      emissive: 0xf97316,
      emissiveIntensity: 0.7,
      transparent: true,
      opacity: 0.65,
      side: THREE.DoubleSide,
      roughness: 0.15,
    });
    const frontShield = new THREE.Mesh(shieldGeo, shieldMat);
    frontShield.position.set(0, 0.42, 0.12);
    bodyGroup.add(frontShield);

    const coreEye = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), eyeMat);
    coreEye.position.set(0, 0.72, 0.1);
    bodyGroup.add(coreEye);
  }

  // Visible Windup Telegraph Ground Ring & Sight-Line (for >=10% HP hazard telegraphs)
  const telRingGeo = new THREE.RingGeometry(spec.radius * 1.1, spec.radius * 1.65, 24);
  telRingGeo.rotateX(-Math.PI / 2);
  const telMat = new THREE.MeshBasicMaterial({
    color: 0xfef08a,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.85,
    depthWrite: false,
  });
  const telegraphRing = new THREE.Mesh(telRingGeo, telMat);
  telegraphRing.position.y = 0.03;
  telegraphRing.visible = false;
  root.add(telegraphRing);

  const lineGeo = new THREE.PlaneGeometry(0.14, 3.2);
  lineGeo.translate(0, 1.6, 0);
  lineGeo.rotateX(-Math.PI / 2);
  const telegraphLine = new THREE.Mesh(lineGeo, telMat);
  telegraphLine.position.y = 0.035;
  telegraphLine.visible = false;
  root.add(telegraphLine);

  return {
    root,
    bodyGroup,
    telegraphRing,
    telegraphLine,
    primaryMaterials: [hullMat],
  };
}

/**
 * 5. RETRO ARCADE CABINET ARENA & CENTRAL CPU VAULT
 * Builds the tabletop arcade playfield, bevel rails, coin-door, marquee arch,
 * socket pads, single-use pinball bumpers, and background arcade hall InstancedMesh stars/cabinets.
 */
export interface ArenaEnvironmentRig {
  root: THREE.Group;
  coreCrystal: THREE.Mesh;
  coreRings: THREE.Mesh[];
  corePylons: THREE.Mesh[];
  padRingMeshes: THREE.Mesh[];
  bumperMeshes: THREE.Group[];
  dispose: () => void;
}

export function createRetroArcadeArena(textures: ArcadeTextureSet): ArenaEnvironmentRig {
  const root = new THREE.Group();
  root.name = 'RetroArcadeCabinetArena';

  const width = ARENA_BOUNDS.maxX - ARENA_BOUNDS.minX;
  const depth = ARENA_BOUNDS.maxZ - ARENA_BOUNDS.minZ;

  // 1. Playfield Deck Floor (y = 0)
  const floorGeo = new THREE.PlaneGeometry(width, depth);
  floorGeo.rotateX(-Math.PI / 2);
  const floorMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.playfieldAlbedo,
    bumpMap: textures.playfieldBump,
    bumpScale: 0.03,
    roughness: 0.42,
    metalness: 0.22,
  });
  const floorMesh = new THREE.Mesh(floorGeo, floorMat);
  floorMesh.receiveShadow = true;
  root.add(floorMesh);

  // 2. Surrounding Arcade Hall Floor Extension (blends seamlessly into fog with zero horizon seam)
  const hallFloorGeo = new THREE.PlaneGeometry(160, 160);
  hallFloorGeo.rotateX(-Math.PI / 2);
  const hallFloorMat = new THREE.MeshStandardMaterial({
    color: 0x05070e,
    roughness: 0.96,
    metalness: 0.05,
  });
  const hallFloor = new THREE.Mesh(hallFloorGeo, hallFloorMat);
  hallFloor.position.y = -0.35;
  root.add(hallFloor);

  // 3. Composite Arcade Cabinet Side Rails, Coin-Door Front & North Marquee Arch
  const railMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.cabinetWoodAlbedo,
    roughness: 0.55,
    metalness: 0.25,
  });
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xcbd5e1,
    roughness: 0.22,
    metalness: 0.88,
    roughnessMap: textures.brushedMetalRoughness,
  });
  const neonCyanMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    emissive: 0x06b6d4,
    emissiveIntensity: 1.1,
    roughness: 0.2,
  });
  const neonAmberMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.1,
    roughness: 0.2,
  });

  // Left & Right Cabinet Walls
  const sideWallGeo = new THREE.BoxGeometry(0.65, 0.85, depth + 1.2);
  const leftWall = new THREE.Mesh(sideWallGeo, railMat);
  leftWall.position.set(ARENA_BOUNDS.minX - 0.32, 0.25, 0);
  const rightWall = new THREE.Mesh(sideWallGeo, railMat);
  rightWall.position.set(ARENA_BOUNDS.maxX + 0.32, 0.25, 0);
  root.add(leftWall, rightWall);

  // Chrome T-Molding Top Trim on Side Rails
  const trimGeo = new THREE.BoxGeometry(0.22, 0.08, depth + 1.2);
  const leftTrim = new THREE.Mesh(trimGeo, chromeMat);
  leftTrim.position.set(ARENA_BOUNDS.minX - 0.15, 0.7, 0);
  const rightTrim = new THREE.Mesh(trimGeo, chromeMat);
  rightTrim.position.set(ARENA_BOUNDS.maxX + 0.15, 0.7, 0);
  root.add(leftTrim, rightTrim);

  // North & South Bumper Rails
  const endWallGeo = new THREE.BoxGeometry(width + 1.3, 0.75, 0.65);
  const northWall = new THREE.Mesh(endWallGeo, railMat);
  northWall.position.set(0, 0.22, ARENA_BOUNDS.minZ - 0.32);
  const southWall = new THREE.Mesh(endWallGeo, railMat);
  southWall.position.set(0, 0.18, ARENA_BOUNDS.maxZ + 0.32);
  root.add(northWall, southWall);

  // Tall North Arcade Marquee Arch (Spawn Vista Landmark!)
  const pillarGeo = new THREE.CylinderGeometry(0.32, 0.42, 4.8, 12);
  const leftArchPillar = new THREE.Mesh(pillarGeo, chromeMat);
  leftArchPillar.position.set(-7.6, 2.4, ARENA_BOUNDS.minZ - 0.55);
  const rightArchPillar = new THREE.Mesh(pillarGeo, chromeMat);
  rightArchPillar.position.set(7.6, 2.4, ARENA_BOUNDS.minZ - 0.55);
  const archHeader = new THREE.Mesh(new THREE.BoxGeometry(16.2, 0.9, 0.75), railMat);
  archHeader.position.set(0, 4.75, ARENA_BOUNDS.minZ - 0.55);
  const archNeon = new THREE.Mesh(new THREE.BoxGeometry(15.6, 0.16, 0.82), neonAmberMat);
  archNeon.position.set(0, 4.35, ARENA_BOUNDS.minZ - 0.55);
  root.add(leftArchPillar, rightArchPillar, archHeader, archNeon);

  // 8 Flanking Upright 1984 Retro Arcade Cabinets framing the Arcade Hall
  const cabBodyGeo = new THREE.BoxGeometry(1.6, 3.2, 1.4);
  const cabTopGeo = new THREE.BoxGeometry(1.64, 0.55, 1.55);
  const cabScreenGeo = new THREE.PlaneGeometry(1.25, 1.05);
  const cabSpots = [
    { x: -11.4, z: -6.5, rotY: 0.45, color: 0x06b6d4 },
    { x: -11.8, z: -2.0, rotY: 0.35, color: 0xf43f5e },
    { x: -11.8, z: 2.5, rotY: 0.25, color: 0xf59e0b },
    { x: -11.4, z: 6.8, rotY: 0.15, color: 0xa855f7 },
    { x: 11.4, z: -6.5, rotY: -0.45, color: 0xf59e0b },
    { x: 11.8, z: -2.0, rotY: -0.35, color: 0x06b6d4 },
    { x: 11.8, z: 2.5, rotY: -0.25, color: 0xa855f7 },
    { x: 11.4, z: 6.8, rotY: -0.15, color: 0xf43f5e },
  ];
  for (const spot of cabSpots) {
    const cabGroup = new THREE.Group();
    cabGroup.position.set(spot.x, -0.35, spot.z);
    cabGroup.rotation.y = spot.rotY;
    const body = new THREE.Mesh(cabBodyGeo, railMat);
    body.position.y = 1.6;
    const marquee = new THREE.Mesh(
      cabTopGeo,
      new THREE.MeshStandardMaterial({
        color: spot.color,
        emissive: spot.color,
        emissiveIntensity: 0.75,
        roughness: 0.25,
      }),
    );
    marquee.position.set(0, 3.35, 0.08);
    const crt = new THREE.Mesh(
      cabScreenGeo,
      new THREE.MeshStandardMaterial({
        color: spot.color,
        emissive: spot.color,
        emissiveIntensity: 0.5,
        roughness: 0.12,
      }),
    );
    crt.position.set(0, 2.05, 0.72);
    crt.rotation.x = -0.18;
    cabGroup.add(body, marquee, crt);
    cabGroup.xb = { pointerEvents: 'none' };
    root.add(cabGroup);
  }

  // 3 Spawner Gate Portals along the North Wall
  for (let l = 0; l < LANE_WAYPOINTS.length; l++) {
    const startPt = LANE_WAYPOINTS[l][0];
    const gateGroup = new THREE.Group();
    gateGroup.position.set(startPt.x, 0, startPt.z);
    const gateRingGeo = new THREE.TorusGeometry(0.85, 0.09, 10, 24, Math.PI);
    const gateRing = new THREE.Mesh(gateRingGeo, neonAmberMat);
    gateRing.position.y = 0.1;
    gateGroup.add(gateRing);
    root.add(gateGroup);
  }

  // 4. Circuit Lane Conduits (offset y = 0.02 to prevent Z-fighting)
  const laneRibbonMat = new THREE.MeshStandardMaterial({
    color: 0x0ea5e9,
    emissive: 0x0284c7,
    emissiveIntensity: 0.45,
    roughness: 0.35,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  for (let l = 0; l < LANE_WAYPOINTS.length; l++) {
    const pts = LANE_WAYPOINTS[l];
    for (let s = 0; s < pts.length - 1; s++) {
      const a = pts[s];
      const b = pts[s + 1];
      const len = Math.hypot(b.x - a.x, b.z - a.z);
      const segGeo = new THREE.PlaneGeometry(0.55, len + 0.35);
      segGeo.rotateX(-Math.PI / 2);
      const segMesh = new THREE.Mesh(segGeo, laneRibbonMat);
      segMesh.position.set((a.x + b.x) * 0.5, 0.02, (a.z + b.z) * 0.5);
      segMesh.rotation.y = Math.atan2(b.x - a.x, b.z - a.z);
      segMesh.xb = { pointerEvents: 'none' };
      root.add(segMesh);
    }
  }

  // 5. Socket Pads (10 Tactical Deployment Sockets)
  const padRingMeshes: THREE.Mesh[] = [];
  const padBaseGeo = new THREE.CylinderGeometry(0.66, 0.74, 0.06, 6);
  const padBaseMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.7,
    roughness: 0.45,
  });
  const padRingGeo = new THREE.RingGeometry(0.52, 0.64, 6);
  padRingGeo.rotateX(-Math.PI / 2);

  for (let i = 0; i < INITIAL_SOCKET_PADS.length; i++) {
    const pad = INITIAL_SOCKET_PADS[i];
    const padMesh = new THREE.Mesh(padBaseGeo, padBaseMat);
    padMesh.position.set(pad.x, 0.03, pad.z);
    padMesh.userData = { padId: pad.id };
    root.add(padMesh);

    const rMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
    });
    const rMesh = new THREE.Mesh(padRingGeo, rMat);
    rMesh.position.set(pad.x, 0.065, pad.z);
    padRingMeshes.push(rMesh);
    root.add(rMesh);
  }

  // 6. Four Single-Use Arcade Pinball Bumpers
  const bumperMeshes: THREE.Group[] = [];
  for (let i = 0; i < INITIAL_BUMPERS.length; i++) {
    const b = INITIAL_BUMPERS[i];
    const bGroup = new THREE.Group();
    bGroup.position.set(b.x, 0, b.z);
    bGroup.add(createContactShadowDisc(b.radius * 1.25, textures.contactShadowTex, 0.45));

    const stem = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.38, 0.36, 16),
      chromeMat,
    );
    stem.position.y = 0.18;
    const cap = new THREE.Mesh(
      new THREE.CylinderGeometry(b.radius, b.radius * 0.88, 0.22, 20),
      new THREE.MeshStandardMaterial({
        color: 0xf43f5e,
        emissive: 0xe11d48,
        emissiveIntensity: 0.75,
        roughness: 0.2,
        metalness: 0.4,
      }),
    );
    cap.position.y = 0.42;
    const crownRing = new THREE.Mesh(
      new THREE.TorusGeometry(b.radius * 0.65, 0.045, 10, 20).rotateX(Math.PI / 2),
      neonAmberMat,
    );
    crownRing.position.y = 0.55;
    bGroup.add(stem, cap, crownRing);
    bumperMeshes.push(bGroup);
    root.add(bGroup);
  }

  // 7. Central Arcade Core (CPU Vault) - 8-part monument at South End
  const coreGroup = new THREE.Group();
  coreGroup.position.set(CORE_POSITION.x, 0, CORE_POSITION.z);
  root.add(coreGroup);

  const vaultPedestal = new THREE.Mesh(
    new THREE.CylinderGeometry(1.15, 1.35, 0.28, 8),
    chromeMat,
  );
  vaultPedestal.position.y = 0.14;
  coreGroup.add(vaultPedestal);

  const coreCrystal = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.52, 0),
    neonCyanMat,
  );
  coreCrystal.position.y = 0.95;
  coreGroup.add(coreCrystal);

  const ring1 = new THREE.Mesh(
    new THREE.TorusGeometry(0.78, 0.05, 12, 28),
    neonAmberMat,
  );
  ring1.position.y = 0.95;
  const ring2 = new THREE.Mesh(
    new THREE.TorusGeometry(0.95, 0.04, 12, 28),
    chromeMat,
  );
  ring2.position.y = 0.95;
  coreGroup.add(ring1, ring2);

  // 5 Physical Core HP Integrity Pylons around the Vault
  const corePylons: THREE.Mesh[] = [];
  for (let p = 0; p < 5; p++) {
    const angle = -Math.PI * 0.8 + (p / 4) * (Math.PI * 0.6);
    const pylonMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      emissive: 0x10b981,
      emissiveIntensity: 1.0,
      roughness: 0.25,
    });
    const pylon = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.14, 0.65, 8),
      pylonMat,
    );
    pylon.position.set(Math.sin(angle) * 1.22, 0.42, Math.cos(angle) * 1.22);
    coreGroup.add(pylon);
    corePylons.push(pylon);
  }

  // 8. InstancedMesh (>20 instances): 48 Surrounding Arcade Carpet Neon Stars & LED Studs
  const starCount = 48;
  const starGeo = new THREE.OctahedronGeometry(0.16, 0);
  const starMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0x38bdf8,
    emissiveIntensity: 0.7,
    roughness: 0.3,
  });
  const starInstanced = new THREE.InstancedMesh(starGeo, starMat, starCount);
  const mat4 = new THREE.Matrix4();
  const pos = new THREE.Vector3();
  const quat = new THREE.Quaternion();
  const scl = new THREE.Vector3();
  const col = new THREE.Color();
  const palette = [0x06b6d4, 0xf59e0b, 0xf43f5e, 0xa855f7];

  for (let i = 0; i < starCount; i++) {
    const angle = (i / starCount) * Math.PI * 2;
    const dist = 12.2 + (i % 3) * 2.4;
    pos.set(Math.cos(angle) * dist, 0.2 + (i % 4) * 0.35, Math.sin(angle) * dist);
    const s = 0.85 + ((i * 7) % 5) * 0.08;
    scl.setScalar(s);
    mat4.compose(pos, quat, scl);
    starInstanced.setMatrixAt(i, mat4);
    col.setHex(palette[i % palette.length]);
    starInstanced.setColorAt(i, col);
  }
  starInstanced.instanceMatrix.needsUpdate = true;
  if (starInstanced.instanceColor) starInstanced.instanceColor.needsUpdate = true;
  starInstanced.computeBoundingSphere();
  starInstanced.xb = { pointerEvents: 'none' };
  root.add(starInstanced);

  return {
    root,
    coreCrystal,
    coreRings: [ring1, ring2],
    corePylons,
    padRingMeshes,
    bumperMeshes,
    dispose: () => {
      floorGeo.dispose();
      floorMat.dispose();
      hallFloorGeo.dispose();
      hallFloorMat.dispose();
      starGeo.dispose();
      starMat.dispose();
    },
  };
}
