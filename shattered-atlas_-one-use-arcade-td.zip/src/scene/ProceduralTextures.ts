import * as THREE from 'three';

export interface ArcadeTextureSet {
  playfieldAlbedo: THREE.CanvasTexture;
  playfieldBump: THREE.CanvasTexture;
  cabinetWoodAlbedo: THREE.CanvasTexture;
  brushedMetalRoughness: THREE.CanvasTexture;
  contactShadowTex: THREE.CanvasTexture;
  dispose: () => void;
}

export function createArcadeTextureSet(maxAnisotropy = 4): ArcadeTextureSet {
  // 1. Playfield Retro Circuit & Vector Grid Albedo (SRGBColorSpace)
  const pfCanvas = document.createElement('canvas');
  pfCanvas.width = 512;
  pfCanvas.height = 512;
  const pfCtx = pfCanvas.getContext('2d')!;
  pfCtx.fillStyle = '#090d1a';
  pfCtx.fillRect(0, 0, 512, 512);

  // Subtle circuit traces
  pfCtx.strokeStyle = 'rgba(6, 182, 212, 0.22)';
  pfCtx.lineWidth = 2;
  for (let i = 0; i <= 512; i += 64) {
    pfCtx.beginPath();
    pfCtx.moveTo(i, 0);
    pfCtx.lineTo(i, 512);
    pfCtx.stroke();

    pfCtx.beginPath();
    pfCtx.moveTo(0, i);
    pfCtx.lineTo(512, i);
    pfCtx.stroke();
  }

  // Fine sub-grid
  pfCtx.strokeStyle = 'rgba(245, 158, 11, 0.09)';
  pfCtx.lineWidth = 1;
  for (let i = 32; i < 512; i += 64) {
    pfCtx.beginPath();
    pfCtx.moveTo(i, 0);
    pfCtx.lineTo(i, 512);
    pfCtx.stroke();
    pfCtx.beginPath();
    pfCtx.moveTo(0, i);
    pfCtx.lineTo(512, i);
    pfCtx.stroke();
  }

  // Solder pads at intersections
  pfCtx.fillStyle = 'rgba(56, 189, 248, 0.35)';
  for (let x = 64; x < 512; x += 64) {
    for (let y = 64; y < 512; y += 64) {
      pfCtx.beginPath();
      pfCtx.arc(x, y, 4, 0, Math.PI * 2);
      pfCtx.fill();
    }
  }

  const playfieldAlbedo = new THREE.CanvasTexture(pfCanvas);
  playfieldAlbedo.colorSpace = THREE.SRGBColorSpace;
  playfieldAlbedo.wrapS = THREE.RepeatWrapping;
  playfieldAlbedo.wrapT = THREE.RepeatWrapping;
  playfieldAlbedo.repeat.set(4, 4);
  playfieldAlbedo.anisotropy = maxAnisotropy;

  // 2. Playfield Micro-Relief Bump Map (NoColorSpace)
  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = 256;
  bumpCanvas.height = 256;
  const bCtx = bumpCanvas.getContext('2d')!;
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 256, 256);
  bCtx.strokeStyle = '#b0b0b0';
  bCtx.lineWidth = 2;
  for (let i = 0; i <= 256; i += 32) {
    bCtx.beginPath();
    bCtx.moveTo(i, 0);
    bCtx.lineTo(i, 256);
    bCtx.stroke();
    bCtx.beginPath();
    bCtx.moveTo(0, i);
    bCtx.lineTo(256, i);
    bCtx.stroke();
  }
  const playfieldBump = new THREE.CanvasTexture(bumpCanvas);
  playfieldBump.colorSpace = THREE.NoColorSpace;
  playfieldBump.wrapS = THREE.RepeatWrapping;
  playfieldBump.wrapT = THREE.RepeatWrapping;
  playfieldBump.repeat.set(4, 4);
  playfieldBump.anisotropy = maxAnisotropy;

  // 3. Cabinet Side Trim Albedo (SRGBColorSpace)
  const woodCanvas = document.createElement('canvas');
  woodCanvas.width = 256;
  woodCanvas.height = 256;
  const wCtx = woodCanvas.getContext('2d')!;
  wCtx.fillStyle = '#181424';
  wCtx.fillRect(0, 0, 256, 256);
  // 1984 geometric vector racing stripe
  wCtx.fillStyle = '#f59e0b';
  wCtx.fillRect(0, 96, 256, 16);
  wCtx.fillStyle = '#f43f5e';
  wCtx.fillRect(0, 118, 256, 10);
  wCtx.fillStyle = '#06b6d4';
  wCtx.fillRect(0, 134, 256, 8);
  const cabinetWoodAlbedo = new THREE.CanvasTexture(woodCanvas);
  cabinetWoodAlbedo.colorSpace = THREE.SRGBColorSpace;
  cabinetWoodAlbedo.wrapS = THREE.RepeatWrapping;
  cabinetWoodAlbedo.wrapT = THREE.RepeatWrapping;
  cabinetWoodAlbedo.anisotropy = maxAnisotropy;

  // 4. Brushed Metal Roughness Map (NoColorSpace)
  const metalCanvas = document.createElement('canvas');
  metalCanvas.width = 128;
  metalCanvas.height = 128;
  const mCtx = metalCanvas.getContext('2d')!;
  mCtx.fillStyle = '#555555';
  mCtx.fillRect(0, 0, 128, 128);
  for (let y = 0; y < 128; y += 2) {
    const shade = 65 + ((y * 17) % 45);
    mCtx.fillStyle = `rgb(${shade},${shade},${shade})`;
    mCtx.fillRect(0, y, 128, 1);
  }
  const brushedMetalRoughness = new THREE.CanvasTexture(metalCanvas);
  brushedMetalRoughness.colorSpace = THREE.NoColorSpace;
  brushedMetalRoughness.wrapS = THREE.RepeatWrapping;
  brushedMetalRoughness.wrapT = THREE.RepeatWrapping;

  // 5. Soft Radial Contact Shadow Disc Texture
  const shCanvas = document.createElement('canvas');
  shCanvas.width = 128;
  shCanvas.height = 128;
  const sCtx = shCanvas.getContext('2d')!;
  const grad = sCtx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.72)');
  grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.32)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0.0)');
  sCtx.fillStyle = grad;
  sCtx.fillRect(0, 0, 128, 128);
  const contactShadowTex = new THREE.CanvasTexture(shCanvas);
  contactShadowTex.colorSpace = THREE.SRGBColorSpace;

  return {
    playfieldAlbedo,
    playfieldBump,
    cabinetWoodAlbedo,
    brushedMetalRoughness,
    contactShadowTex,
    dispose: () => {
      playfieldAlbedo.dispose();
      playfieldBump.dispose();
      cabinetWoodAlbedo.dispose();
      brushedMetalRoughness.dispose();
      contactShadowTex.dispose();
    },
  };
}
