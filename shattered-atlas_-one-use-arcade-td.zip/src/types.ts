export type GamePhase = 'title' | 'playing' | 'paused' | 'gameover';

export type GameOutcome = 'none' | 'victory' | 'defeat';

export enum TowerType {
  PULSE_LASER = 'PULSE_LASER',
  CRYO_CAPACITOR = 'CRYO_CAPACITOR',
  TESLA_COIL = 'TESLA_COIL',
}

export enum EnemyArchetype {
  SWARMER = 'SWARMER',
  LANCER = 'LANCER',
  JUGGERNAUT = 'JUGGERNAUT',
}

export interface Vec2 {
  x: number;
  z: number;
}

export interface TowerSpec {
  type: TowerType;
  keyBinding: string;
  name: string;
  shortRole: string;
  cost: number;
  range: number;
  damage: number;
  colorHex: number;
  accentCss: string;
  maxUses: 1;
}

export interface EnemySpec {
  archetype: EnemyArchetype;
  name: string;
  maxHp: number;
  speed: number;
  rewardTokens: number;
  coreDamage: number;
  colorHex: number;
  radius: number;
}

export interface PlayerOrbState {
  x: number;
  z: number;
  vx: number;
  vz: number;
  heading: number;
  radius: number;
  hp: number;
  maxHp: number;
  invulnTimer: number;
  boostCooldown: number;
  squashX: number;
  squashY: number;
  distanceTraveled: number;
}

export interface SocketPadState {
  id: number;
  x: number;
  z: number;
  towerId: number | null;
  shatterCooldown: number;
}

export interface TowerInstanceState {
  id: number;
  padId: number;
  type: TowerType;
  x: number;
  z: number;
  usesRemaining: number;
  maxUses: 1;
  shattered: boolean;
  shatterAnimTimer: number;
  aimAngle: number;
  deployedAt: number;
}

export interface EnemyInstanceState {
  id: number;
  archetype: EnemyArchetype;
  laneIndex: number;
  waypointIndex: number;
  x: number;
  z: number;
  vx: number;
  vz: number;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  slowTimer: number;
  hitFlashTimer: number;
  windupTimer: number;
  windupDuration: number;
  isWindingUp: boolean;
  dashTimer: number;
  dashDirX: number;
  dashDirZ: number;
  weavePhase: number;
  koTimer: number;
  isKo: boolean;
}

export interface MapFragmentState {
  id: number;
  index: number;
  label: string;
  sectorName: string;
  x: number;
  z: number;
  collected: boolean;
  collectAnimTimer: number;
}

export interface BumperNode {
  id: number;
  x: number;
  z: number;
  radius: number;
  hitTimer: number;
  usesRemaining: number;
  shattered: boolean;
  respawnTimer: number;
}

export interface TokenDropState {
  id: number;
  x: number;
  z: number;
  amount: number;
  collected: boolean;
  age: number;
}

export interface ShatterEvent {
  x: number;
  z: number;
  colorHex: number;
  label: string;
  targetPositions: Vec2[];
}

export interface RunSnapshot {
  outcome: 'victory' | 'defeat';
  reason: string;
  score: number;
  bestScore: number;
  mapCollected: number;
  mapTotal: number;
  waveReached: number;
  itemsShattered: number;
  enemiesDefeated: number;
  clearTimeSeconds: number;
  coreHpRemaining: number;
}

export interface GameSimulationState {
  phase: GamePhase;
  outcome: GameOutcome;
  defeatReason: string;
  elapsedSeconds: number;
  wave: number;
  waveTimer: number;
  spawnTimer: number;
  score: number;
  bestScore: number;
  tokens: number;
  coreHp: number;
  maxCoreHp: number;
  empCharges: number;
  selectedTowerType: TowerType;
  itemsShattered: number;
  enemiesDefeated: number;
  lastShatterBanner: string;
  lastShatterBannerTimer: number;
  player: PlayerOrbState;
  pads: SocketPadState[];
  towers: TowerInstanceState[];
  enemies: EnemyInstanceState[];
  mapFragments: MapFragmentState[];
  bumpers: BumperNode[];
  tokenDrops: TokenDropState[];
  nextEntityId: number;
}
