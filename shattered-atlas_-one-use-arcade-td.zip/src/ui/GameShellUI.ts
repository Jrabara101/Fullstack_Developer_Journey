import { TOWER_SPECS } from '../constants';
import { getCollectedMapCount } from '../game/rules';
import {
  GameSimulationState,
  MapFragmentState,
  RunSnapshot,
  TowerType,
} from '../types';

export interface GameShellCallbacks {
  onStartGame: () => void;
  onResumeGame: () => void;
  onPauseGame: () => void;
  onRestartGame: () => void;
  onReturnTitle: () => void;
  onDeployTower: (type: TowerType) => void;
  onTriggerEmp: () => void;
  onToggleMute: () => boolean;
}

/**
 * World-matched 2D DOM Game Shell:
 * - Title Screen with bespoke inline SVG emblem lockup, [data-start="true"] CTA, and single flat control-hint line
 * - Playing HUD (>= 85% clear viewport) with 3-state SVG vitality pips, 6-piece Torn Map SVG matrix,
 *   top-right square SVG utility buttons, and collapsible bottom 1-Use Loadout Dock
 * - Pause, Victory, and Game Over modal cards with tabular-nums mastery/progress metrics
 */
export class GameShellUI {
  private container: HTMLElement;
  private callbacks: GameShellCallbacks;

  private titleEl!: HTMLElement;
  private hudEl!: HTMLElement;
  private pauseModalEl!: HTMLElement;
  private outcomeModalEl!: HTMLElement;
  private vignetteEl!: HTMLElement;

  // Retained DOM references for zero-thrash updates
  private corePipsEl!: HTMLElement;
  private hullPipsEl!: HTMLElement;
  private mapCountEl!: HTMLElement;
  private mapSvgEl!: SVGSVGElement;
  private waveEl!: HTMLElement;
  private scoreEl!: HTMLElement;
  private brokenEl!: HTMLElement;
  private tokensEl!: HTMLElement;
  private shatterCalloutEl!: HTMLElement;
  private dockWrapperEl!: HTMLElement;
  private dockCollapseBtn!: HTMLButtonElement;
  private muteBtn!: HTMLButtonElement;

  private slotButtons = new Map<TowerType, HTMLButtonElement>();
  private empButton!: HTMLButtonElement;
  private empCountSpan!: HTMLElement;

  private lastCoreHp = -1;
  private lastHullHp = -1;
  private lastMapMask = -1;
  private lastWave = -1;
  private lastScore = -1;
  private lastBroken = -1;
  private lastTokens = -1;
  private lastEmp = -1;
  private lastBanner = '';
  private dockCollapsed = false;

  constructor(container: HTMLElement, callbacks: GameShellCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.buildDOM();
  }

  private buildDOM(): void {
    this.container.innerHTML = '';

    // 1. Peripheral Critical Low-HP Vignette
    this.vignetteEl = document.createElement('div');
    this.vignetteEl.className = 'danger-vignette';
    this.container.appendChild(this.vignetteEl);

    // 2. Title Screen Overlay
    this.titleEl = document.createElement('section');
    this.titleEl.className = 'title-screen';
    this.titleEl.setAttribute('aria-label', 'Title Screen');
    this.titleEl.innerHTML = `
      <div class="title-main-column">
        <svg class="title-svg-lockup" viewBox="0 0 560 165" role="img" aria-label="Shattered Atlas: One-Use Arcade Tower Defense">
          <defs>
            <linearGradient id="amberGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#fef08a" />
              <stop offset="55%" stop-color="#f59e0b" />
              <stop offset="100%" stop-color="#d97706" />
            </linearGradient>
            <linearGradient id="cyanVector" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#38bdf8" />
              <stop offset="100%" stop-color="#06b6d4" />
            </linearGradient>
          </defs>
          <!-- Outer Arcade Marquee Bezel Plaque -->
          <polygon points="8,12 532,12 552,32 552,148 28,148 8,128" fill="#0b1022" stroke="#38bdf8" stroke-width="2.5" />
          <polygon points="16,20 526,20 542,36 542,140 32,140 16,124" fill="none" stroke="rgba(245, 158, 11, 0.45)" stroke-width="1.2" stroke-dasharray="10 5" />
          <!-- Torn Map Shard & Trackball Crest Emblem (Left) -->
          <g transform="translate(30, 34)">
            <polygon points="0,14 28,0 56,12 64,44 42,78 8,68" fill="#1e293b" stroke="#f59e0b" stroke-width="2.5" />
            <path d="M 10 24 L 34 38 L 24 62 M 34 38 L 54 28" stroke="#38bdf8" stroke-width="2" fill="none" stroke-dasharray="3 3" />
            <circle cx="34" cy="38" r="11" fill="#06b6d4" stroke="#fef08a" stroke-width="2" />
            <circle cx="31" cy="35" r="3.5" fill="#ffffff" />
          </g>
          <!-- Main Display Typography -->
          <text x="110" y="68" font-family="'Chakra Petch', sans-serif" font-size="39" font-weight="700" fill="url(#amberGold)" letter-spacing="1.4">
            SHATTERED ATLAS
          </text>
          <text x="112" y="101" font-family="'Chakra Petch', sans-serif" font-size="16.5" font-weight="700" fill="url(#cyanVector)" letter-spacing="2.1">
            MOMENTUM COURIER · 1-USE ARCADE TD
          </text>
          <line x1="112" y1="113" x2="524" y2="113" stroke="rgba(148, 163, 184, 0.3)" stroke-width="1.5" />
          <text x="112" y="131" font-family="'JetBrains Mono', monospace" font-size="11" font-weight="700" fill="#f43f5e" letter-spacing="0.8">
            CABINET #04 · EVERY ITEM SHATTERS AFTER 1 USE
          </text>
        </svg>

        <p class="title-tagline">
          Bank your momentum-driven Trackball Courier across the vector circuit board to recover all 6 pieces of the torn map before glitch-waves breach the Central CPU Vault.
        </p>

        <div class="title-rules-strip">
          <span><strong>Momentum Only</strong> Inertia &amp; Bumper Banks</span>
          <span aria-hidden="true">·</span>
          <span><strong>6 Map Shards</strong> Complete the Atlas</span>
          <span aria-hidden="true">·</span>
          <span><strong>Fragile Arsenal</strong> 1 Use Per Item</span>
        </div>

        <div class="title-cta-row">
          <button type="button" class="btn-primary-arcade" data-start="true" id="btn-title-start">
            <span>Insert Coin · Start Run</span>
          </button>
        </div>
      </div>

      <p class="title-control-hint">
        WASD / Arrows Momentum Thrust · 1-3 Deploy 1-Use Tower · 4 / Space EMP Boost · H Hide Dock · Esc Pause
      </p>
    `;
    this.container.appendChild(this.titleEl);

    const startBtn = this.titleEl.querySelector('#btn-title-start') as HTMLButtonElement;
    startBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onStartGame();
    });

    // 3. Playing HUD Layer
    this.hudEl = document.createElement('div');
    this.hudEl.className = 'hud-layer';
    this.hudEl.hidden = true;

    this.hudEl.innerHTML = `
      <div class="hud-top-row">
        <!-- Top-Left World-Matched Status Cluster -->
        <div class="hud-cluster-left" role="region" aria-label="Mission Status">
          <div class="hud-stat-block">
            <span class="hud-kicker">CPU VAULT HP</span>
            <div class="pip-row" id="hud-core-pips" aria-label="Core Integrity Pips"></div>
          </div>

          <div class="hud-stat-block">
            <span class="hud-kicker">ORB HULL</span>
            <div class="pip-row" id="hud-hull-pips" aria-label="Player Orb Hull Pips"></div>
          </div>

          <div class="hud-stat-block">
            <span class="hud-kicker">TORN MAP SHARDS</span>
            <div class="map-matrix-wrap">
              <span class="hud-hero-num amber" id="hud-map-count">0 / 6</span>
              <svg class="map-matrix-svg" id="hud-map-svg" viewBox="0 0 74 46" aria-label="Torn Map Assembly Grid"></svg>
            </div>
          </div>

          <div class="hud-stat-block">
            <span class="hud-kicker">WAVE</span>
            <span class="hud-hero-num cyan" id="hud-wave">1</span>
          </div>

          <div class="hud-stat-block">
            <span class="hud-kicker">SCORE</span>
            <span class="hud-hero-num" id="hud-score">0</span>
          </div>

          <div class="hud-stat-block">
            <span class="hud-kicker">1-USE BROKEN</span>
            <span class="hud-hero-num rose" id="hud-broken">0</span>
          </div>
        </div>

        <!-- Center One-Use Shatter Telemetry Banner -->
        <div class="shatter-callout" id="hud-shatter-callout" role="status">
          ALL ITEMS &amp; TOWERS BREAK AFTER 1 USE
        </div>

        <!-- Top-Right Utility Controls -->
        <div class="hud-utility-bar" role="toolbar" aria-label="Game Controls">
          <button type="button" class="hud-icon-btn" id="btn-hud-mute" tabindex="-1" aria-label="Mute Audio (M)" title="Mute Audio [M]">
            ${this.renderSoundSvg(false)}
          </button>
          <button type="button" class="hud-icon-btn" id="btn-hud-restart" tabindex="-1" aria-label="Restart Run (R)" title="Restart Run [R]">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
              <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
              <path d="M3 3v5h5" />
            </svg>
          </button>
          <button type="button" class="hud-icon-btn" id="btn-hud-pause" tabindex="-1" aria-label="Pause Game (P)" title="Pause Game [P / Esc]">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
              <rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" />
              <rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" />
            </svg>
          </button>
        </div>
      </div>

      <!-- Unified Collapsible Bottom Perimeter Dock -->
      <div class="bottom-dock-wrapper" id="hud-dock-wrapper" role="region" aria-label="Single-Use Arsenal Dock">
        <button type="button" class="dock-collapse-tab" id="btn-dock-collapse" tabindex="-1" aria-expanded="true" aria-label="Toggle Arsenal Controls Dock (H)">
          ▾ Hide Arsenal Dock [H]
        </button>
        <div class="bottom-dock-panel">
          <div class="dock-wallet">
            <span class="hud-kicker">ARCADE TOKENS</span>
            <span class="hud-hero-num amber" id="hud-tokens">95</span>
          </div>
          <div class="dock-slots-grid" id="hud-dock-slots"></div>
        </div>
      </div>
    `;
    this.container.appendChild(this.hudEl);

    this.corePipsEl = this.hudEl.querySelector('#hud-core-pips') as HTMLElement;
    this.hullPipsEl = this.hudEl.querySelector('#hud-hull-pips') as HTMLElement;
    this.mapCountEl = this.hudEl.querySelector('#hud-map-count') as HTMLElement;
    this.mapSvgEl = this.hudEl.querySelector('#hud-map-svg') as SVGSVGElement;
    this.waveEl = this.hudEl.querySelector('#hud-wave') as HTMLElement;
    this.scoreEl = this.hudEl.querySelector('#hud-score') as HTMLElement;
    this.brokenEl = this.hudEl.querySelector('#hud-broken') as HTMLElement;
    this.tokensEl = this.hudEl.querySelector('#hud-tokens') as HTMLElement;
    this.shatterCalloutEl = this.hudEl.querySelector('#hud-shatter-callout') as HTMLElement;
    this.dockWrapperEl = this.hudEl.querySelector('#hud-dock-wrapper') as HTMLElement;
    this.dockCollapseBtn = this.hudEl.querySelector('#btn-dock-collapse') as HTMLButtonElement;
    this.muteBtn = this.hudEl.querySelector('#btn-hud-mute') as HTMLButtonElement;

    this.muteBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      const muted = this.callbacks.onToggleMute();
      this.updateMuteIcon(muted);
    });

    const restartBtn = this.hudEl.querySelector('#btn-hud-restart') as HTMLButtonElement;
    restartBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onRestartGame();
    });

    const pauseBtn = this.hudEl.querySelector('#btn-hud-pause') as HTMLButtonElement;
    pauseBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onPauseGame();
    });

    this.dockCollapseBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.toggleDockCollapsed();
    });

    this.buildDockSlots();

    // 4. Pause Modal Card
    this.pauseModalEl = document.createElement('div');
    this.pauseModalEl.className = 'modal-scrim';
    this.pauseModalEl.hidden = true;
    this.pauseModalEl.innerHTML = `
      <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="pause-modal-title">
        <div>
          <h2 class="modal-title" id="pause-modal-title">CABINET PAUSED</h2>
          <p class="modal-subtitle">Momentum Courier on standby. Every deployed turret and cartridge breaks after 1 activation.</p>
        </div>
        <div class="modal-stats-grid">
          <div class="modal-stat-tile">
            <span class="hud-kicker">MAP SHARDS</span>
            <span class="hud-hero-num amber" id="pause-stat-map">0 / 6</span>
          </div>
          <div class="modal-stat-tile">
            <span class="hud-kicker">1-USE BROKEN</span>
            <span class="hud-hero-num rose" id="pause-stat-broken">0</span>
          </div>
          <div class="modal-stat-tile">
            <span class="hud-kicker">SCORE</span>
            <span class="hud-hero-num cyan" id="pause-stat-score">0</span>
          </div>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn-secondary-arcade" id="btn-pause-title">Title Screen</button>
          <button type="button" class="btn-secondary-arcade" id="btn-pause-restart">Restart Run</button>
          <button type="button" class="btn-primary-arcade" id="btn-pause-resume">Resume Play</button>
        </div>
      </div>
    `;
    this.container.appendChild(this.pauseModalEl);

    (this.pauseModalEl.querySelector('#btn-pause-resume') as HTMLButtonElement).addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onResumeGame();
    });
    (this.pauseModalEl.querySelector('#btn-pause-restart') as HTMLButtonElement).addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onRestartGame();
    });
    (this.pauseModalEl.querySelector('#btn-pause-title') as HTMLButtonElement).addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onReturnTitle();
    });

    // 5. Outcome Modal Card (Victory / Game Over)
    this.outcomeModalEl = document.createElement('div');
    this.outcomeModalEl.className = 'modal-scrim';
    this.outcomeModalEl.hidden = true;
    this.container.appendChild(this.outcomeModalEl);
  }

  private buildDockSlots(): void {
    const slotsContainer = this.hudEl.querySelector('#hud-dock-slots') as HTMLElement;
    slotsContainer.innerHTML = '';

    const towerOrder: TowerType[] = [
      TowerType.PULSE_LASER,
      TowerType.CRYO_CAPACITOR,
      TowerType.TESLA_COIL,
    ];

    for (const type of towerOrder) {
      const spec = TOWER_SPECS[type];
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'dock-slot-btn';
      btn.tabIndex = -1;
      btn.setAttribute('aria-label', `Deploy ${spec.name} (${spec.cost} Tokens, Key ${spec.keyBinding})`);
      btn.innerHTML = `
        <div class="slot-icon-wrap">${this.renderTowerSlotSvg(type)}</div>
        <div class="slot-meta">
          <div class="slot-title-line">
            <span class="slot-name">${spec.name}</span>
            <span class="slot-key-cost">[${spec.keyBinding}] ${spec.cost}T</span>
          </div>
          <span class="slot-role">${spec.shortRole}</span>
        </div>
      `;
      btn.addEventListener('click', (e) => {
        (e.currentTarget as HTMLElement).blur();
        this.callbacks.onDeployTower(type);
      });
      slotsContainer.appendChild(btn);
      this.slotButtons.set(type, btn);
    }

    // 4th Slot: Single-Use Overdrive EMP Cartridge
    this.empButton = document.createElement('button');
    this.empButton.type = 'button';
    this.empButton.className = 'dock-slot-btn';
    this.empButton.tabIndex = -1;
    this.empButton.setAttribute('aria-label', 'Trigger Single-Use EMP Boost Cartridge (Key 4 or Space)');
    this.empButton.innerHTML = `
      <div class="slot-icon-wrap">
        <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
          <polygon points="12,2 22,7 22,17 12,22 2,17 2,7" fill="#1e1b4b" stroke="#a855f7" stroke-width="2" />
          <polygon points="13,5 7,13 12,13 11,19 17,11 12,11" fill="#e879f9" stroke="#ffffff" stroke-width="0.8" />
        </svg>
      </div>
      <div class="slot-meta">
        <div class="slot-title-line">
          <span class="slot-name">EMP Boost Cell</span>
          <span class="slot-key-cost" id="hud-emp-stock">[4/Spc] x2</span>
        </div>
        <span class="slot-role">Impulse + Stun · Breaks in 1 Use</span>
      </div>
    `;
    this.empButton.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onTriggerEmp();
    });
    slotsContainer.appendChild(this.empButton);
    this.empCountSpan = this.empButton.querySelector('#hud-emp-stock') as HTMLElement;
  }

  public toggleDockCollapsed(): void {
    this.dockCollapsed = !this.dockCollapsed;
    this.dockWrapperEl.classList.toggle('collapsed', this.dockCollapsed);
    this.dockCollapseBtn.setAttribute('aria-expanded', String(!this.dockCollapsed));
    this.dockCollapseBtn.textContent = this.dockCollapsed
      ? '▴ Show Arsenal Dock [H]'
      : '▾ Hide Arsenal Dock [H]';
  }

  public updateMuteIcon(muted: boolean): void {
    this.muteBtn.innerHTML = this.renderSoundSvg(muted);
  }

  private renderSoundSvg(muted: boolean): string {
    if (muted) {
      return `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fb7185" stroke-width="2.2">
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="rgba(251, 113, 133, 0.25)" />
          <line x1="23" y1="9" x2="17" y2="15" />
          <line x1="17" y1="9" x2="23" y2="15" />
        </svg>
      `;
    }
    return `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="rgba(56, 189, 248, 0.25)" />
        <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
        <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
      </svg>
    `;
  }

  private renderTowerSlotSvg(type: TowerType): string {
    if (type === TowerType.PULSE_LASER) {
      return `
        <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
          <polygon points="4,19 20,19 17,14 7,14" fill="#0f172a" stroke="#06b6d4" stroke-width="1.8" />
          <rect x="8" y="4" width="3" height="10" rx="1" fill="#38bdf8" stroke="#083344" stroke-width="1" />
          <rect x="13" y="4" width="3" height="10" rx="1" fill="#38bdf8" stroke="#083344" stroke-width="1" />
          <circle cx="12" cy="14" r="3" fill="#fef08a" />
        </svg>
      `;
    }
    if (type === TowerType.CRYO_CAPACITOR) {
      return `
        <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="12" cy="12" r="9" fill="#0c4a6e" stroke="#38bdf8" stroke-width="2" />
          <polygon points="12,5 17,12 12,19 7,12" fill="#bae6fd" stroke="#0284c7" stroke-width="1.2" />
          <circle cx="12" cy="12" r="2.2" fill="#ffffff" />
        </svg>
      `;
    }
    return `
      <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
        <polygon points="6,20 18,20 15,10 9,10" fill="#1e293b" stroke="#f59e0b" stroke-width="1.8" />
        <ellipse cx="12" cy="9" rx="6" ry="2.6" fill="#fbbf24" stroke="#78350f" stroke-width="1.2" />
        <polygon points="12,2 15,7 9,7" fill="#fef08a" />
      </svg>
    `;
  }

  /**
   * Renders 3-state discrete SVG vitality sockets (Full, Damaged/Cracked, Empty Hollow Socket).
   */
  private renderVitalityPips(current: number, max: number, activeColor: string): string {
    let html = '';
    for (let i = 0; i < max; i++) {
      if (i < current - 1 || (i === current - 1 && current === max)) {
        // State 1: Full Socket
        html += `
          <svg width="16" height="20" viewBox="0 0 16 20" aria-hidden="true">
            <polygon points="8,1 15,5 15,15 8,19 1,15 1,5" fill="${activeColor}" stroke="#0f172a" stroke-width="1.5" />
            <polygon points="8,3.5 12.5,6 8,8.5 3.5,6" fill="rgba(255,255,255,0.45)" />
          </svg>
        `;
      } else if (i === current - 1) {
        // State 2: Damaged/Cracked Frontier Socket
        html += `
          <svg width="16" height="20" viewBox="0 0 16 20" aria-hidden="true">
            <polygon points="8,1 15,5 15,15 8,19 1,15 1,5" fill="${activeColor}" stroke="#fef08a" stroke-width="1.5" />
            <path d="M 4 5 L 9 10 L 6 14 L 11 17" stroke="#0f172a" stroke-width="1.8" fill="none" />
          </svg>
        `;
      } else {
        // State 3: Empty Hollow Socket
        html += `
          <svg width="16" height="20" viewBox="0 0 16 20" aria-hidden="true">
            <polygon points="8,1 15,5 15,15 8,19 1,15 1,5" fill="rgba(15, 23, 42, 0.8)" stroke="rgba(148, 163, 184, 0.35)" stroke-width="1.4" stroke-dasharray="2 2" />
          </svg>
        `;
      }
    }
    return html;
  }

  /**
   * Renders the 6-piece Torn Map SVG assembly grid showing collected vs missing shards.
   */
  private renderTornMapSvg(fragments: MapFragmentState[]): string {
    const shardPaths = [
      'M 2,2 L 24,2 L 21,21 L 2,19 Z',
      'M 26,2 L 48,2 L 50,19 L 23,21 Z',
      'M 50,2 L 72,2 L 72,21 L 52,19 Z',
      'M 2,23 L 21,25 L 24,44 L 2,44 Z',
      'M 23,25 L 50,23 L 48,44 L 26,44 Z',
      'M 52,23 L 72,25 L 72,44 L 50,44 Z',
    ];
    let svg = '';
    for (let i = 0; i < 6; i++) {
      const collected = fragments[i]?.collected ?? false;
      const fill = collected ? '#f59e0b' : 'rgba(15, 23, 42, 0.85)';
      const stroke = collected ? '#fef08a' : 'rgba(56, 189, 248, 0.35)';
      svg += `<path d="${shardPaths[i]}" fill="${fill}" stroke="${stroke}" stroke-width="1.4" />`;
      if (collected) {
        const cx = 13 + (i % 3) * 24;
        const cy = i < 3 ? 11 : 34;
        svg += `<circle cx="${cx}" cy="${cy}" r="2.2" fill="#070913" />`;
      }
    }
    return svg;
  }

  public sync(state: GameSimulationState, snapshot: RunSnapshot | null): void {
    document.body.dataset.state = state.phase;

    this.titleEl.hidden = state.phase !== 'title';
    this.hudEl.hidden = state.phase === 'title';
    this.pauseModalEl.hidden = state.phase !== 'paused';
    this.outcomeModalEl.hidden = state.phase !== 'gameover';

    const isCritical =
      state.phase === 'playing' && (state.coreHp <= 2 || state.player.hp <= 2);
    this.vignetteEl.classList.toggle('critical', isCritical);

    // Update vitality pips only on change
    if (this.lastCoreHp !== state.coreHp) {
      this.lastCoreHp = state.coreHp;
      this.corePipsEl.innerHTML = this.renderVitalityPips(
        state.coreHp,
        state.maxCoreHp,
        '#38bdf8',
      );
    }

    if (this.lastHullHp !== state.player.hp) {
      this.lastHullHp = state.player.hp;
      this.hullPipsEl.innerHTML = this.renderVitalityPips(
        state.player.hp,
        state.player.maxHp,
        '#10b981',
      );
    }

    // Update Torn Map SVG matrix & counter only when mask changes
    let mapMask = 0;
    for (let i = 0; i < state.mapFragments.length; i++) {
      if (state.mapFragments[i].collected) mapMask |= 1 << i;
    }
    if (this.lastMapMask !== mapMask) {
      this.lastMapMask = mapMask;
      const count = getCollectedMapCount(state);
      this.mapCountEl.textContent = `${count} / ${state.mapFragments.length}`;
      this.mapSvgEl.innerHTML = this.renderTornMapSvg(state.mapFragments);
    }

    if (this.lastWave !== state.wave) {
      this.lastWave = state.wave;
      this.waveEl.textContent = String(state.wave);
    }

    const roundedScore = Math.round(state.score);
    if (this.lastScore !== roundedScore) {
      this.lastScore = roundedScore;
      this.scoreEl.textContent = String(roundedScore);
    }

    if (this.lastBroken !== state.itemsShattered) {
      this.lastBroken = state.itemsShattered;
      this.brokenEl.textContent = String(state.itemsShattered);
    }

    const roundedTokens = Math.round(state.tokens);
    if (this.lastTokens !== roundedTokens) {
      this.lastTokens = roundedTokens;
      this.tokensEl.textContent = String(roundedTokens);
      for (const [type, btn] of this.slotButtons.entries()) {
        const cost = TOWER_SPECS[type].cost;
        btn.disabled = roundedTokens < cost;
      }
    }

    if (this.lastEmp !== state.empCharges) {
      this.lastEmp = state.empCharges;
      this.empCountSpan.textContent = `[4/Spc] x${state.empCharges}`;
      this.empButton.disabled = state.empCharges <= 0;
    }

    if (this.lastBanner !== state.lastShatterBanner) {
      this.lastBanner = state.lastShatterBanner;
      this.shatterCalloutEl.textContent = state.lastShatterBanner;
    }

    if (state.phase === 'paused') {
      const pMap = this.pauseModalEl.querySelector('#pause-stat-map');
      const pBroken = this.pauseModalEl.querySelector('#pause-stat-broken');
      const pScore = this.pauseModalEl.querySelector('#pause-stat-score');
      if (pMap) pMap.textContent = `${getCollectedMapCount(state)} / ${state.mapFragments.length}`;
      if (pBroken) pBroken.textContent = String(state.itemsShattered);
      if (pScore) pScore.textContent = String(roundedScore);
    }

    if (state.phase === 'gameover' && snapshot) {
      this.renderOutcomeModal(snapshot);
    }
  }

  private renderOutcomeModal(snap: RunSnapshot): void {
    const isVictory = snap.outcome === 'victory';
    this.outcomeModalEl.innerHTML = `
      <div class="modal-card ${isVictory ? 'victory' : 'defeat'}" role="dialog" aria-modal="true" aria-labelledby="outcome-modal-title">
        <div>
          <h2 class="modal-title" id="outcome-modal-title">
            ${isVictory ? 'ATLAS RESTORED · VICTORY' : 'CABINET OVERRUN · DEFEAT'}
          </h2>
          <p class="modal-subtitle">${snap.reason}</p>
        </div>

        <div class="modal-stats-grid">
          <div class="modal-stat-tile">
            <span class="hud-kicker">MAP RECOVERED</span>
            <span class="hud-hero-num amber">${snap.mapCollected} / ${snap.mapTotal}</span>
          </div>
          <div class="modal-stat-tile">
            <span class="hud-kicker">1-USE ITEMS BROKEN</span>
            <span class="hud-hero-num rose">${snap.itemsShattered}</span>
          </div>
          <div class="modal-stat-tile">
            <span class="hud-kicker">${isVictory ? 'CLEAR TIME' : 'WAVE REACHED'}</span>
            <span class="hud-hero-num cyan">${isVictory ? `${snap.clearTimeSeconds}s` : `Wave ${snap.waveReached}`}</span>
          </div>
          <div class="modal-stat-tile">
            <span class="hud-kicker">FINAL SCORE</span>
            <span class="hud-hero-num">${snap.score}</span>
          </div>
          <div class="modal-stat-tile">
            <span class="hud-kicker">HIGH SCORE</span>
            <span class="hud-hero-num amber">${snap.bestScore}</span>
          </div>
          <div class="modal-stat-tile">
            <span class="hud-kicker">CORE VAULT HP</span>
            <span class="hud-hero-num cyan">${snap.coreHpRemaining} / 5</span>
          </div>
        </div>

        <div class="modal-actions">
          <button type="button" class="btn-secondary-arcade" id="btn-outcome-title">Title Screen</button>
          <button type="button" class="btn-primary-arcade" data-start="true" id="btn-outcome-retry">
            ${isVictory ? 'Play Next Shift' : 'Insert Coin · Try Again'}
          </button>
        </div>
      </div>
    `;

    const retryBtn = this.outcomeModalEl.querySelector('#btn-outcome-retry') as HTMLButtonElement;
    retryBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onStartGame();
    });

    const titleBtn = this.outcomeModalEl.querySelector('#btn-outcome-title') as HTMLButtonElement;
    titleBtn.addEventListener('click', (e) => {
      (e.currentTarget as HTMLElement).blur();
      this.callbacks.onReturnTitle();
    });
  }
}
