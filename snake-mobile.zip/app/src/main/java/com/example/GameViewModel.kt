package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.HighScoreRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class Direction {
    UP, DOWN, LEFT, RIGHT
}

enum class GameStatus {
    IDLE, PLAYING, PAUSED, GAME_OVER
}

data class Point(val x: Int, val y: Int)

enum class GameMode {
    CLASSIC,  // Hit wall = Die
    PORTAL    // Hit wall = Wrap around
}

data class GameState(
    val snake: List<Point> = listOf(Point(7, 10), Point(7, 11), Point(7, 12)),
    val direction: Direction = Direction.UP,
    val food: Point = Point(7, 4),
    val status: GameStatus = GameStatus.IDLE,
    val score: Int = 0,
    val bestScore: Int = 0,
    val speedMs: Long = 300L,
    val mode: GameMode = GameMode.CLASSIC,
    val isMuted: Boolean = false
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repository = HighScoreRepository(db.highScoreDao())

    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    private var gameJob: Job? = null
    val gridSize = 15

    init {
        // Observe best score from database
        viewModelScope.launch {
            repository.highScoreFlow.collectLatest { highScore ->
                _state.update { it.copy(bestScore = highScore?.score ?: 0) }
            }
        }
    }

    fun setMode(mode: GameMode) {
        _state.update { it.copy(mode = mode) }
    }

    fun toggleMuted() {
        _state.update { it.copy(isMuted = !it.isMuted) }
    }

    fun startGame() {
        // Reset state for new game
        _state.update {
            it.copy(
                snake = listOf(Point(7, 10), Point(7, 11), Point(7, 12)),
                direction = Direction.UP,
                status = GameStatus.PLAYING,
                score = 0,
                speedMs = 300L
            )
        }
        spawnFood()
        startGameLoop()
    }

    fun resumeGame() {
        if (_state.value.status != GameStatus.PAUSED) return
        _state.update { it.copy(status = GameStatus.PLAYING) }
        startGameLoop()
    }

    fun pauseGame() {
        if (_state.value.status != GameStatus.PLAYING) return
        _state.update { it.copy(status = GameStatus.PAUSED) }
        gameJob?.cancel()
    }

    fun changeDirection(newDir: Direction) {
        val currentDir = _state.value.direction
        // Prevent reverse direction collapses (e.g. moving UP, cannot press DOWN)
        val isValid = when (newDir) {
            Direction.UP -> currentDir != Direction.DOWN
            Direction.DOWN -> currentDir != Direction.UP
            Direction.LEFT -> currentDir != Direction.RIGHT
            Direction.RIGHT -> currentDir != Direction.LEFT
        }
        if (isValid && _state.value.status == GameStatus.PLAYING) {
            _state.update { it.copy(direction = newDir) }
        }
    }

    private fun startGameLoop() {
        gameJob?.cancel()
        gameJob = viewModelScope.launch {
            while (_state.value.status == GameStatus.PLAYING) {
                delay(_state.value.speedMs)
                moveSnake()
            }
        }
    }

    private fun moveSnake() {
        val currentState = _state.value
        val snake = currentState.snake
        val head = snake.first()
        val dir = currentState.direction

        // Calculate next head position
        var nextX = head.x
        var nextY = head.y

        when (dir) {
            Direction.UP -> nextY -= 1
            Direction.DOWN -> nextY += 1
            Direction.LEFT -> nextX -= 1
            Direction.RIGHT -> nextX += 1
        }

        // Check bounds logic
        val outOfBounds = nextX < 0 || nextX >= gridSize || nextY < 0 || nextY >= gridSize

        if (outOfBounds) {
            if (currentState.mode == GameMode.PORTAL) {
                // Wrap around logic
                nextX = (nextX + gridSize) % gridSize
                nextY = (nextY + gridSize) % gridSize
            } else {
                handleGameOver()
                return
            }
        }

        val nextHead = Point(nextX, nextY)

        // Check self-collision
        if (snake.dropLast(1).contains(nextHead)) {
            handleGameOver()
            return
        }

        // Create new snake list
        val newSnake = mutableListOf<Point>()
        newSnake.add(nextHead)

        // Check if eating food
        if (nextHead == currentState.food) {
            // Add all existing body parts (snake grows)
            newSnake.addAll(snake)
            val newScore = currentState.score + 10
            
            // Adjust speed down (faster) by 10ms for every eaten food (minimum speed 100ms)
            val newSpeed = (300L - (newScore / 10) * 10L).coerceAtLeast(100L)

            _state.update {
                it.copy(
                    snake = newSnake,
                    score = newScore,
                    speedMs = newSpeed
                )
            }
            spawnFood()
        } else {
            // Keep all but the last segment
            newSnake.addAll(snake.dropLast(1))
            _state.update { it.copy(snake = newSnake) }
        }
    }

    private fun spawnFood() {
        val snake = _state.value.snake
        var randomPoint: Point
        do {
            randomPoint = Point(Random.nextInt(gridSize), Random.nextInt(gridSize))
        } while (snake.contains(randomPoint))

        _state.update { it.copy(food = randomPoint) }
    }

    private fun handleGameOver() {
        gameJob?.cancel()
        val finalScore = _state.value.score
        
        _state.update { it.copy(status = GameStatus.GAME_OVER) }
        
        // Persist high score
        viewModelScope.launch {
            repository.saveHighScore(finalScore)
        }
    }

    override fun onCleared() {
        super.onCleared()
        gameJob?.cancel()
    }
}
