package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "high_scores")
data class HighScore(
    @PrimaryKey val id: Int = 1,
    val score: Int
)

@Dao
interface HighScoreDao {
    @Query("SELECT * FROM high_scores WHERE id = 1 LIMIT 1")
    fun getHighScoreFlow(): Flow<HighScore?>

    @Query("SELECT * FROM high_scores WHERE id = 1 LIMIT 1")
    suspend fun getHighScoreSync(): HighScore?

    @Query("INSERT OR REPLACE INTO high_scores (id, score) VALUES (1, :score)")
    suspend fun setHighScore(score: Int)
}

@Database(entities = [HighScore::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun highScoreDao(): HighScoreDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "snake_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class HighScoreRepository(private val highScoreDao: HighScoreDao) {
    val highScoreFlow: Flow<HighScore?> = highScoreDao.getHighScoreFlow()

    suspend fun saveHighScore(score: Int) {
        val current = highScoreDao.getHighScoreSync()
        if (current == null || score > current.score) {
            highScoreDao.setHighScore(score)
        }
    }
}
