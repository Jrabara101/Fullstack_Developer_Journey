package com.example.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.Direction
import com.example.GameMode
import com.example.GameState
import com.example.GameStatus
import com.example.GameViewModel
import com.example.Point
import com.example.ui.theme.VibrantBackground
import com.example.ui.theme.VibrantContainerSoft
import com.example.ui.theme.VibrantContainerSoftActive
import com.example.ui.theme.VibrantFoodRed
import com.example.ui.theme.VibrantGridBg
import com.example.ui.theme.VibrantNeutralDark
import com.example.ui.theme.VibrantPrimary
import com.example.ui.theme.VibrantPrimaryDark
import com.example.ui.theme.VibrantTextDark
import com.example.ui.theme.VibrantTextMuted
import com.example.ui.theme.VibrantTextMutedDark

@Composable
fun SnakeGameScreen(
    viewModel: GameViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current

    // Trigger subtle haptic when snake eats food (score increases)
    LaunchedEffect(state.score) {
        if (state.score > 0) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    // Trigger strong haptic when game over hits
    LaunchedEffect(state.status) {
        if (state.status == GameStatus.GAME_OVER) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VibrantBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .align(Alignment.Center)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. HEADER SECTION
            HeaderSection(
                score = state.score,
                bestScore = state.bestScore
            )

            // 2. GAME BOARD
            GameBoardSection(
                state = state,
                gridSize = viewModel.gridSize,
                onTapBoard = {
                    if (state.status == GameStatus.IDLE || state.status == GameStatus.GAME_OVER) {
                        viewModel.startGame()
                    } else if (state.status == GameStatus.PLAYING) {
                        viewModel.pauseGame()
                    } else if (state.status == GameStatus.PAUSED) {
                        viewModel.resumeGame()
                    }
                }
            )

            // 3. CONTROLS AREA
            ControlsSection(
                status = state.status,
                onDirectionChange = { dir ->
                    viewModel.changeDirection(dir)
                    haptic.performHapticFeedback(HapticFeedbackType.TextDoubleTap)
                }
            )

            // 4. BOTTOM ACTIONS BAR
            BottomActionsSection(
                state = state,
                onToggleMode = {
                    val nextMode = if (state.mode == GameMode.CLASSIC) GameMode.PORTAL else GameMode.CLASSIC
                    viewModel.setMode(nextMode)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                },
                onPrimaryAction = {
                    when (state.status) {
                        GameStatus.IDLE, GameStatus.GAME_OVER -> viewModel.startGame()
                        GameStatus.PLAYING -> viewModel.pauseGame()
                        GameStatus.PAUSED -> viewModel.resumeGame()
                    }
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                },
                onRestart = {
                    viewModel.startGame()
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
            )
        }
    }
}

@Composable
fun HeaderSection(score: Int, bestScore: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "CURRENT SCORE",
                fontSize = 11.sp,
                color = VibrantTextMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            // Tabular number rendering to prevent score jitter
            Text(
                text = String.format("%,04d", score),
                fontSize = 38.sp,
                color = VibrantTextDark,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.testTag("current_score")
            )
        }

        Box(
            modifier = Modifier
                .shadow(2.dp, RoundedCornerShape(16.dp))
                .background(VibrantContainerSoft, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "BEST",
                    fontSize = 11.sp,
                    color = VibrantTextMutedDark,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = String.format("%,04d", bestScore),
                    fontSize = 20.sp,
                    color = VibrantNeutralDark,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.testTag("best_score")
                )
            }
        }
    }
}

@Composable
fun GameBoardSection(
    state: GameState,
    gridSize: Int,
    onTapBoard: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .shadow(4.dp, RoundedCornerShape(32.dp))
            .background(VibrantGridBg, RoundedCornerShape(32.dp))
            .clip(RoundedCornerShape(32.dp))
            .pointerInput(Unit) {
                detectTapGestures { onTapBoard() }
            }
            .testTag("game_board"),
        contentAlignment = Alignment.Center
    ) {
        // Red glowing pulsating circle animation for food item
        val infiniteTransition = rememberInfiniteTransition(label = "food_glow")
        val glowScale by infiniteTransition.animateFloat(
            initialValue = 0.8f,
            targetValue = 1.4f,
            animationSpec = infiniteRepeatable(
                animation = tween(800),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulsate"
        )

        // Draw the main grid, snake body, snake eyes, and the juicy food glow
        Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            val cellWidth = size.width / gridSize
            val cellHeight = size.height / gridSize

            // 1. Draw dot background grid (LCD dot matrix appearance)
            for (c in 0 until gridSize) {
                for (r in 0 until gridSize) {
                    val cx = (c + 0.5f) * cellWidth
                    val cy = (r + 0.5f) * cellHeight
                    drawCircle(
                        color = VibrantNeutralDark,
                        radius = 2.dp.toPx(),
                        center = Offset(cx, cy),
                        alpha = 0.08f
                    )
                }
            }

            // 2. Draw Food item with dual layer radiant glow
            val food = state.food
            val fx = (food.x + 0.5f) * cellWidth
            val fy = (food.y + 0.5f) * cellHeight
            val foodRadius = (cellWidth / 2.6f)

            // Ambient glowing shadow
            drawCircle(
                color = VibrantFoodRed,
                radius = foodRadius * 1.8f * glowScale,
                center = Offset(fx, fy),
                alpha = 0.15f
            )
            // Solid center cap
            drawCircle(
                color = VibrantFoodRed,
                radius = foodRadius,
                center = Offset(fx, fy)
            )

            // 3. Draw Snake Segment bodies
            state.snake.forEachIndexed { index, point ->
                val px = point.x * cellWidth
                val py = point.y * cellHeight
                val padX = cellWidth * 0.1f
                val padY = cellHeight * 0.1f

                if (index == 0) {
                    // Head: colored distinct dark grey/black
                    drawRoundRect(
                        color = VibrantNeutralDark,
                        topLeft = Offset(px + padX, py + padY),
                        size = Size(cellWidth - padX * 2, cellHeight - padY * 2),
                        cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                    )

                    // Draw eyes on the snake head based on direction!
                    val headCenter = Offset(px + cellWidth / 2f, py + cellHeight / 2f)
                    val eyeRadius = cellWidth * 0.09f
                    val eyeDist = cellWidth * 0.22f

                    when (state.direction) {
                        Direction.UP -> {
                            // Eyes on standard top spots
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x - eyeDist, headCenter.y - eyeDist))
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x + eyeDist, headCenter.y - eyeDist))
                        }
                        Direction.DOWN -> {
                            // Eyes on bottom spots
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x - eyeDist, headCenter.y + eyeDist))
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x + eyeDist, headCenter.y + eyeDist))
                        }
                        Direction.LEFT -> {
                            // Eyes on left side
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x - eyeDist, headCenter.y - eyeDist))
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x - eyeDist, headCenter.y + eyeDist))
                        }
                        Direction.RIGHT -> {
                            // Eyes on right side
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x + eyeDist, headCenter.y - eyeDist))
                            drawCircle(Color.White, eyeRadius, Offset(headCenter.x + eyeDist, headCenter.y + eyeDist))
                        }
                    }
                } else {
                    // Body: colored premium garden green (#386B1F) slightly padded
                    drawRoundRect(
                        color = VibrantPrimary,
                        topLeft = Offset(px + padX, py + padY),
                        size = Size(cellWidth - padX * 2, cellHeight - padY * 2),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                }
            }
        }

        // Overlay states (Idle, Paused, Game Over) to keep HUD feedback pristine
        when (state.status) {
            GameStatus.IDLE -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xE6E0E4DB)), // Matching grid base high opacity
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = "SNAKE REBORN",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = VibrantNeutralDark,
                            letterSpacing = 1.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Classic arcade modernized",
                            fontSize = 13.sp,
                            color = VibrantTextMuted,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(28.dp))
                        Text(
                            text = "TAP BOARD TO PLAY",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = VibrantPrimary,
                            letterSpacing = 2.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(VibrantContainerSoft, RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Walls: ",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VibrantTextMutedDark
                            )
                            Text(
                                text = state.mode.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = VibrantPrimary
                            )
                        }
                    }
                }
            }
            GameStatus.PAUSED -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xB3E0E4DB)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "GAME PAUSED",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = VibrantNeutralDark,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Tap board to resume",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = VibrantTextMuted
                        )
                    }
                }
            }
            GameStatus.GAME_OVER -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xF2E0E4DB)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = "CRASH!",
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            color = VibrantFoodRed,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "GAME OVER",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = VibrantNeutralDark,
                            letterSpacing = 3.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "SCORE ACQUIRED",
                            fontSize = 10.sp,
                            color = VibrantTextMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${state.score}",
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Black,
                            color = VibrantNeutralDark,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "TAP HERE TO RESTART",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = VibrantPrimary,
                            letterSpacing = 1.5.sp
                        )
                    }
                }
            }
            else -> {}
        }
    }
}

@Composable
fun ControlsSection(
    status: GameStatus,
    onDirectionChange: (Direction) -> Unit
) {
    Box(
        modifier = Modifier
            .padding(vertical = 14.dp)
            .fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: UP BUTTON ONLY
            Row {
                DirectionButton(
                    direction = Direction.UP,
                    onClick = { onDirectionChange(Direction.UP) },
                    enabled = status == GameStatus.PLAYING,
                    modifier = Modifier.testTag("up_button")
                )
            }

            // Row 2: LEFT, DOWN, RIGHT BUTTONS
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DirectionButton(
                    direction = Direction.LEFT,
                    onClick = { onDirectionChange(Direction.LEFT) },
                    enabled = status == GameStatus.PLAYING,
                    modifier = Modifier.testTag("left_button")
                )
                DirectionButton(
                    direction = Direction.DOWN,
                    onClick = { onDirectionChange(Direction.DOWN) },
                    enabled = status == GameStatus.PLAYING,
                    modifier = Modifier.testTag("down_button")
                )
                DirectionButton(
                    direction = Direction.RIGHT,
                    onClick = { onDirectionChange(Direction.RIGHT) },
                    enabled = status == GameStatus.PLAYING,
                    modifier = Modifier.testTag("right_button")
                )
            }
        }
    }
}

@Composable
fun DirectionButton(
    direction: Direction,
    onClick: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Smooth press scaling reaction for natural hand feel (HTML active:scale-95)
    val scale = if (isPressed && enabled) 0.94f else 1.0f

    val baseBgColor = if (enabled) {
        if (isPressed) VibrantContainerSoftActive else VibrantContainerSoft
    } else {
        VibrantContainerSoft.copy(alpha = 0.5f)
    }

    Box(
        modifier = modifier
            .size(64.dp)
            .scale(scale)
            .shadow(
                valOfShadow(enabled && !isPressed),
                RoundedCornerShape(20.dp)
            )
            .background(baseBgColor, RoundedCornerShape(20.dp))
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null, // Disable default standard ripple as we handle scale/color manually
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        ChevronIcon(
            direction = direction,
            color = if (enabled) VibrantNeutralDark else VibrantNeutralDark.copy(alpha = 0.25f)
        )
    }
}

private fun valOfShadow(visible: Boolean) = if (visible) 1.5.dp else 0.dp

@Composable
fun ChevronIcon(direction: Direction, color: Color) {
    Canvas(modifier = Modifier.size(24.dp)) {
        val path = Path()
        val w = size.width
        val h = size.height

        when (direction) {
            Direction.UP -> {
                // m18 15 -6 -6 -6 6 -> proportional arrow coords in normalized stroke
                path.moveTo(w * 0.75f, h * 0.625f)
                path.lineTo(w * 0.5f, h * 0.375f)
                path.lineTo(w * 0.25f, h * 0.625f)
            }
            Direction.LEFT -> {
                // m15 18 -6 -6 6 -6
                path.moveTo(w * 0.625f, h * 0.75f)
                path.lineTo(w * 0.375f, h * 0.5f)
                path.lineTo(w * 0.625f, h * 0.25f)
            }
            Direction.DOWN -> {
                // m6 9 6 6 6 -6
                path.moveTo(w * 0.25f, h * 0.375f)
                path.lineTo(w * 0.5f, h * 0.625f)
                path.lineTo(w * 0.75f, h * 0.375f)
            }
            Direction.RIGHT -> {
                // m9 18 6 -6 -6 -6
                path.moveTo(w * 0.375f, h * 0.75f)
                path.lineTo(w * 0.625f, h * 0.5f)
                path.lineTo(w * 0.375f, h * 0.25f)
            }
        }

        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 2.5.dp.toPx(),
                cap = androidx.compose.ui.graphics.StrokeCap.Round,
                join = androidx.compose.ui.graphics.StrokeJoin.Round
            )
        )
    }
}

@Composable
fun BottomActionsSection(
    state: GameState,
    onToggleMode: () -> Unit,
    onPrimaryAction: () -> Unit,
    onRestart: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Toggle walls mode (Classic vs Portal)
        Box(
            modifier = Modifier
                .size(48.dp)
                .shadow(1.dp, CircleShape)
                .background(VibrantGridBg, CircleShape)
                .clickable { onToggleMode() }
                .testTag("mode_toggle_button"),
            contentAlignment = Alignment.Center
        ) {
            ModeIcon(mode = state.mode)
        }

        // Play/Pause Action Bar - Large dynamic capsule button
        val primaryLabel = when (state.status) {
            GameStatus.PLAYING -> "PAUSE"
            GameStatus.PAUSED -> "RESUME"
            GameStatus.IDLE, GameStatus.GAME_OVER -> "START GAME"
        }

        Row(
            modifier = Modifier
                .height(54.dp)
                .shadow(4.dp, RoundedCornerShape(27.dp))
                .background(VibrantPrimary, RoundedCornerShape(27.dp))
                .clip(RoundedCornerShape(27.dp))
                .clickable { onPrimaryAction() }
                .padding(horizontal = 24.dp)
                .testTag("play_pause_button"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            PlayPauseIcon(status = state.status)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = primaryLabel,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                letterSpacing = 1.sp
            )
        }

        // Restart game button
        Box(
            modifier = Modifier
                .size(48.dp)
                .shadow(1.dp, CircleShape)
                .background(VibrantGridBg, CircleShape)
                .clickable { onRestart() }
                .testTag("restart_button"),
            contentAlignment = Alignment.Center
        ) {
            RestartIcon()
        }
    }
}

@Composable
fun PlayPauseIcon(status: GameStatus) {
    Canvas(modifier = Modifier.size(16.dp)) {
        val w = size.width
        val h = size.height

        if (status == GameStatus.PLAYING) {
            // Draw Pause Icon bars
            drawRect(Color.White, topLeft = Offset(0f, 0f), size = Size(w * 0.35f, h))
            drawRect(Color.White, topLeft = Offset(w * 0.65f, 0f), size = Size(w * 0.35f, h))
        } else {
            // Draw Play Triangle
            val path = Path().apply {
                moveTo(w * 0.15f, 0f)
                lineTo(w * 0.95f, h / 2f)
                lineTo(w * 0.15f, h)
                close()
            }
            drawPath(path, Color.White)
        }
    }
}

@Composable
fun RestartIcon() {
    Canvas(modifier = Modifier.size(20.dp)) {
        val d = size.width
        val r = d / 2f

        // Draw 3/4 circle stroke
        drawArc(
            color = VibrantTextMuted,
            startAngle = 45f,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(d * 0.1f, d * 0.1f),
            size = Size(d * 0.8f, d * 0.8f),
            style = Stroke(width = 2.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )

        // Draw arrowhead at end of loop (top right-ish)
        val path = Path().apply {
            moveTo(d * 0.45f, d * 0.05f)
            lineTo(d * 0.78f, d * 0.22f)
            lineTo(d * 0.62f, d * 0.52f)
        }
        drawPath(path, color = VibrantTextMuted)
    }
}

@Composable
fun ModeIcon(mode: GameMode) {
    Canvas(modifier = Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height

        if (mode == GameMode.CLASSIC) {
            // Solid barrier square pattern representing classic deadly walls
            drawRect(
                color = VibrantTextMuted,
                topLeft = Offset(0f, 0f),
                size = size,
                style = Stroke(width = 2.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
            // Plus/cross marks inside
            drawLine(VibrantTextMuted, Offset(w * 0.35f, h * 0.5f), Offset(w * 0.65f, h * 0.5f), strokeWidth = 2.dp.toPx())
            drawLine(VibrantTextMuted, Offset(w * 0.5f, h * 0.35f), Offset(w * 0.5f, h * 0.65f), strokeWidth = 2.dp.toPx())
        } else {
            // Dotted infinite portals representing wrap-around portal mode
            drawArc(
                color = VibrantTextMuted,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(5f, 5f))
                )
            )
            // Core singularity circle
            drawCircle(VibrantTextMuted, radius = w * 0.2f, center = Offset(w / 2f, h / 2f))
        }
    }
}
