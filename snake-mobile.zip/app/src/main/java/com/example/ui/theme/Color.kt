package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Vibrant Palette - Custom Colors
val VibrantBackground = Color(0xFFF3F6F1)
val VibrantTextDark = Color(0xFF1A1C19)
val VibrantNeutralDark = Color(0xFF191C19)
val VibrantPrimary = Color(0xFF386B1F)
val VibrantPrimaryDark = Color(0xFF2D5519)
val VibrantContainerSoft = Color(0xFFD7E8CD)
val VibrantContainerSoftActive = Color(0xFFB7CCAD)
val VibrantGridBg = Color(0xFFE0E4DB)
val VibrantTextMuted = Color(0xFF424940)
val VibrantTextMutedDark = Color(0xFF3F493A)
val VibrantFoodRed = Color(0xFFBA1A1A)
