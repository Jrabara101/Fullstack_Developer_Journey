package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.data.StitchRepository
import com.example.model.ScreenTab
import com.example.ui.components.StitchBottomBar
import com.example.ui.components.StitchTopBar
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.FocusScreen
import com.example.ui.screens.GraphScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.theme.StitchTheme

class MainActivity : ComponentActivity() {

    private val repository = StitchRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StitchTheme {
                StitchApp(repository = repository)
            }
        }
    }
}

@Composable
fun StitchApp(repository: StitchRepository) {
    var currentTab by remember { mutableStateOf(ScreenTab.EDITOR) }

    val activeNote by repository.activeNote.collectAsState()
    val notes by repository.notes.collectAsState()
    val objectives by repository.objectives.collectAsState()
    val backlinks by repository.backlinks.collectAsState()
    val unlinkedMentions by repository.unlinkedMentions.collectAsState()
    val folders by repository.folders.collectAsState()
    val tags by repository.tags.collectAsState()
    val graphNodes by repository.graphNodes.collectAsState()
    val graphEdges by repository.graphEdges.collectAsState()
    val focalNodeId by repository.focalNodeId.collectAsState()
    val ambientSoundActive by repository.ambientSoundActive.collectAsState()
    val sessionWordsAdded by repository.sessionWordsAdded.collectAsState()
    val selectedWorkspace by repository.selectedWorkspace.collectAsState()

    // Handle back button when on sub-screens
    BackHandler(enabled = currentTab != ScreenTab.EDITOR) {
        currentTab = ScreenTab.EDITOR
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.systemBars,
        topBar = {
            StitchTopBar(
                currentTab = currentTab,
                selectedWorkspace = selectedWorkspace,
                workspaces = repository.workspaces,
                onSelectWorkspace = { repository.selectWorkspace(it) },
                onSearchClick = { currentTab = ScreenTab.VAULT }
            )
        },
        bottomBar = {
            StitchBottomBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                ScreenTab.EDITOR -> {
                    EditorScreen(
                        note = activeNote,
                        objectives = objectives,
                        onToggleObjective = { repository.toggleObjective(it) },
                        onTitleChange = { repository.updateActiveNoteTitle(it) }
                    )
                }
                ScreenTab.VAULT -> {
                    VaultScreen(
                        notes = notes,
                        folders = folders,
                        tags = tags,
                        onNoteClick = { note ->
                            repository.selectNote(note)
                            currentTab = ScreenTab.EDITOR
                        },
                        onToggleFolder = { repository.toggleFolder(it) },
                        onToggleAllFolders = { repository.setAllFoldersExpanded(it) },
                        onCreateNote = { title ->
                            val created = repository.createNote(title)
                            repository.selectNote(created)
                            currentTab = ScreenTab.EDITOR
                        },
                        onOpenGraph = { currentTab = ScreenTab.GRAPH }
                    )
                }
                ScreenTab.GRAPH -> {
                    GraphScreen(
                        nodes = graphNodes,
                        edges = graphEdges,
                        backlinks = backlinks,
                        unlinkedMentions = unlinkedMentions,
                        focalNodeId = focalNodeId,
                        onSelectNode = { nodeId ->
                            repository.selectFocalNode(nodeId)
                        },
                        onLinkMention = { mentionId ->
                            repository.linkMention(mentionId)
                        },
                        onOpenNote = { title ->
                            val found = notes.find { it.title.equals(title, ignoreCase = true) }
                            if (found != null) {
                                repository.selectNote(found)
                            }
                            currentTab = ScreenTab.EDITOR
                        }
                    )
                }
                ScreenTab.FOCUS -> {
                    FocusScreen(
                        note = activeNote,
                        ambientSoundActive = ambientSoundActive,
                        sessionWordsAdded = sessionWordsAdded,
                        onToggleAmbientSound = { repository.toggleAmbientSound() },
                        onExitFocus = { currentTab = ScreenTab.EDITOR }
                    )
                }
            }
        }
    }
}
