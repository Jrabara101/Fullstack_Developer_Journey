package com.example.data

import com.example.model.BacklinkItem
import com.example.model.FolderItem
import com.example.model.GraphEdge
import com.example.model.GraphNode
import com.example.model.NoteItem
import com.example.model.ObjectiveItem
import com.example.model.SubfolderItem
import com.example.model.TagItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class StitchRepository {

    private val _notes = MutableStateFlow<List<NoteItem>>(initialNotes())
    val notes: StateFlow<List<NoteItem>> = _notes.asStateFlow()

    private val _activeNote = MutableStateFlow<NoteItem>(initialNotes().first())
    val activeNote: StateFlow<NoteItem> = _activeNote.asStateFlow()

    private val _objectives = MutableStateFlow<List<ObjectiveItem>>(initialObjectives())
    val objectives: StateFlow<List<ObjectiveItem>> = _objectives.asStateFlow()

    private val _backlinks = MutableStateFlow<List<BacklinkItem>>(initialBacklinks())
    val backlinks: StateFlow<List<BacklinkItem>> = _backlinks.asStateFlow()

    private val _unlinkedMentions = MutableStateFlow<List<BacklinkItem>>(initialUnlinkedMentions())
    val unlinkedMentions: StateFlow<List<BacklinkItem>> = _unlinkedMentions.asStateFlow()

    private val _folders = MutableStateFlow<List<FolderItem>>(initialFolders())
    val folders: StateFlow<List<FolderItem>> = _folders.asStateFlow()

    private val _tags = MutableStateFlow<List<TagItem>>(initialTags())
    val tags: StateFlow<List<TagItem>> = _tags.asStateFlow()

    private val _graphNodes = MutableStateFlow<List<GraphNode>>(initialGraphNodes())
    val graphNodes: StateFlow<List<GraphNode>> = _graphNodes.asStateFlow()

    private val _graphEdges = MutableStateFlow<List<GraphEdge>>(initialGraphEdges())
    val graphEdges: StateFlow<List<GraphEdge>> = _graphEdges.asStateFlow()

    private val _focalNodeId = MutableStateFlow("focal-1")
    val focalNodeId: StateFlow<String> = _focalNodeId.asStateFlow()

    private val _ambientSoundActive = MutableStateFlow(true)
    val ambientSoundActive: StateFlow<Boolean> = _ambientSoundActive.asStateFlow()

    private val _sessionWordsAdded = MutableStateFlow(342)
    val sessionWordsAdded: StateFlow<Int> = _sessionWordsAdded.asStateFlow()

    private val _workspaces = listOf("Research", "Philosophy", "Personal", "Engineering")
    val workspaces: List<String> = _workspaces

    private val _selectedWorkspace = MutableStateFlow("Research")
    val selectedWorkspace: StateFlow<String> = _selectedWorkspace.asStateFlow()

    fun selectWorkspace(workspace: String) {
        _selectedWorkspace.value = workspace
    }

    fun toggleObjective(id: String) {
        _objectives.value = _objectives.value.map {
            if (it.id == id) it.copy(isCompleted = !it.isCompleted) else it
        }
    }

    fun toggleFolder(folderId: String) {
        _folders.value = _folders.value.map {
            if (it.id == folderId) it.copy(isExpanded = !it.isExpanded) else it
        }
    }

    fun setAllFoldersExpanded(expanded: Boolean) {
        _folders.value = _folders.value.map { it.copy(isExpanded = expanded) }
    }

    fun toggleAmbientSound() {
        _ambientSoundActive.value = !_ambientSoundActive.value
    }

    fun selectFocalNode(id: String) {
        _focalNodeId.value = id
        val matchNote = _notes.value.find { it.title.equals(id, ignoreCase = true) || it.id == id }
        if (matchNote != null) {
            _activeNote.value = matchNote
        }
    }

    fun selectNote(note: NoteItem) {
        _activeNote.value = note
    }

    fun updateActiveNoteTitle(newTitle: String) {
        val updated = _activeNote.value.copy(title = newTitle)
        _activeNote.value = updated
        _notes.value = _notes.value.map { if (it.id == updated.id) updated else it }
    }

    fun linkMention(mentionId: String) {
        val mention = _unlinkedMentions.value.find { it.id == mentionId } ?: return
        _unlinkedMentions.value = _unlinkedMentions.value.filter { it.id != mentionId }
        val newBacklink = mention.copy(isLinked = true)
        _backlinks.value = _backlinks.value + newBacklink
    }

    fun createNote(title: String, tag: String = "pkm"): NoteItem {
        val newNote = NoteItem(
            id = "note-${System.currentTimeMillis()}",
            title = title.ifBlank { "Untitled Note" },
            folder = "01_Daily Notes",
            path = "/daily/${System.currentTimeMillis()}",
            preview = "New thought in organic knowledge stream...",
            content = "Begin typing your next premise with atomic wiki-links...",
            tags = listOf(tag),
            linksCount = 1,
            wordsCount = 12,
            updatedAt = "Just now",
            isPinned = false,
            readingTimeMin = 0.5
        )
        _notes.value = listOf(newNote) + _notes.value
        _activeNote.value = newNote
        return newNote
    }

    companion object {
        fun initialNotes(): List<NoteItem> = listOf(
            NoteItem(
                id = "arch-thought",
                title = "The Architecture of Networked Thought",
                folder = "02_Literature Notes",
                path = "/literature/philosophy",
                preview = "Ideas flourish when liberated from rigid hierarchical taxonomies into associative meshes. We treat notes not as immutable terminal archives, but as dynamic conversational nodes in a living memory ecosystem...",
                content = """
                    Linear outlines presuppose that consciousness exists in rigid hierarchies. When ideas branch out organically, our cognitive cartography demands [[Associative Indexing]] rather than siloed folders. Vannevar Bush anticipated this tactile web in his early exposition of the [[Memex Concept]].
                """.trimIndent(),
                tags = listOf("pkm", "second-brain", "bi-directional", "notetaking"),
                linksCount = 14,
                wordsCount = 842,
                updatedAt = "Today, 14:22",
                isPinned = true,
                readingTimeMin = 3.5
            ),
            NoteItem(
                id = "memex-bush",
                title = "Memex & Vannevar Bush Trails",
                folder = "02_Literature Notes",
                path = "/essays/1945",
                preview = "Associative trails that mimic the human mind's non-linear navigation. When two items are tied together, the user can instantly traverse between disparate branches of inquiry without ontological drag...",
                content = "Associative trails that mimic the human mind's non-linear navigation...",
                tags = listOf("history", "hypertext"),
                linksCount = 6,
                wordsCount = 890,
                updatedAt = "Yesterday",
                isPinned = false,
                readingTimeMin = 3.8
            ),
            NoteItem(
                id = "zettelkasten-prin",
                title = "Zettelkasten Atomic Note Principles",
                folder = "03_Permanent Notes",
                path = "/permanent/systems",
                preview = "One thought per index card, densely interconnected through bidirectional pointers. Luhmann's breakthrough stemmed not from indexing density, but from allowing arbitrary branching between clusters...",
                content = "One thought per index card, densely interconnected through bidirectional pointers...",
                tags = listOf("epistemology", "systems"),
                linksCount = 21,
                wordsCount = 640,
                updatedAt = "3 days ago",
                isPinned = false,
                readingTimeMin = 2.7
            ),
            NoteItem(
                id = "local-first-crdt",
                title = "Local-First Architecture with CRDTs",
                folder = "02_Literature Notes",
                path = "/engineering/crdt",
                preview = "Why browser IndexedDB + Yjs ensures absolute data sovereignty without compromising collaborative synchronization. The disk remains authoritative; the network is simply a fast ephemeral bus...",
                content = "Why browser IndexedDB + Yjs ensures absolute data sovereignty...",
                tags = listOf("engineering", "crdt"),
                linksCount = 9,
                wordsCount = 1120,
                updatedAt = "May 12",
                isPinned = false,
                readingTimeMin = 4.8
            )
        )

        fun initialObjectives(): List<ObjectiveItem> = listOf(
            ObjectiveItem("obj-1", "Draft core hypothesis on associative trails", true),
            ObjectiveItem("obj-2", "Map bi-directional link density with D3 graph", false),
            ObjectiveItem("obj-3", "Export vault snapshot to zip", false)
        )

        fun initialBacklinks(): List<BacklinkItem> = listOf(
            BacklinkItem(
                id = "bl-1",
                noteTitle = "Memex & Vannevar Bush Trails",
                path = "/essays/1945",
                snippet = "“...directly influenced by [[The Architecture of Networked Thought]], particularly the historical transition from rigid tree filing cabinets to associative linked memex trails.”",
                line = 42,
                contextScore = 98,
                isLinked = true
            ),
            BacklinkItem(
                id = "bl-2",
                noteTitle = "Weekly Synthesis (Week 19)",
                path = "/journals/2024",
                snippet = "“Refined our core working thesis around [[The Architecture of Networked Thought]] during research on decentralized thinking, second-brain models, and node cohesion.”",
                line = 18,
                contextScore = 92,
                isLinked = true
            )
        )

        fun initialUnlinkedMentions(): List<BacklinkItem> = listOf(
            BacklinkItem(
                id = "um-1",
                noteTitle = "Zettelkasten Structural Notes",
                path = "/inbox",
                snippet = "“Luhmann argues that notes exist only in relational dialogue, anticipating the architecture of networked thought in modern tools.”",
                line = 24,
                contextScore = 85,
                isLinked = false
            )
        )

        fun initialFolders(): List<FolderItem> = listOf(
            FolderItem(
                id = "f-daily",
                name = "01_Daily Notes",
                count = 14,
                isExpanded = false
            ),
            FolderItem(
                id = "f-lit",
                name = "02_Literature Notes",
                count = 22,
                subfolders = listOf(
                    SubfolderItem("Philosophy & Cognition", 13),
                    SubfolderItem("Systems Design", 9)
                ),
                isExpanded = true
            ),
            FolderItem(
                id = "f-perm",
                name = "03_Permanent Notes",
                count = 12,
                isExpanded = false
            )
        )

        fun initialTags(): List<TagItem> = listOf(
            TagItem("pkm", 18),
            TagItem("ai-ux", 9),
            TagItem("epistemology", 7),
            TagItem("systems", 15)
        )

        fun initialGraphNodes(): List<GraphNode> = listOf(
            // Focal node (Center)
            GraphNode("focal-1", "The Architecture of Networked Thought", 14, 0, 0.50f, 0.44f, "core"),

            // 1st-degree satellites
            GraphNode("deg1-1", "Associative Indexing", 4, 1, 0.22f, 0.20f, "pkm"),
            GraphNode("deg1-2", "Memex Concept", 6, 1, 0.78f, 0.22f, "history"),
            GraphNode("deg1-3", "Zettelkasten Principles", 9, 1, 0.23f, 0.69f, "systems"),
            GraphNode("deg1-4", "Hypertext Origins", 3, 1, 0.76f, 0.67f, "web"),

            // 2nd-degree satellites
            GraphNode("deg2-1", "CRDT Sync", 2, 2, 0.13f, 0.09f, "engineering"),
            GraphNode("deg2-2", "Typora WYSIWYG", 2, 2, 0.34f, 0.08f, "editor"),
            GraphNode("deg2-3", "Semantic Trails", 3, 2, 0.88f, 0.11f, "history"),
            GraphNode("deg2-4", "PKM Theory", 2, 2, 0.92f, 0.27f, "pkm"),
            GraphNode("deg2-5", "Transclusion", 2, 2, 0.12f, 0.80f, "systems"),
            GraphNode("deg2-6", "Force Vectors", 2, 2, 0.91f, 0.77f, "physics"),
            GraphNode("deg2-7", "Rhizomes", 1, 2, 0.89f, 0.58f, "philosophy")
        )

        fun initialGraphEdges(): List<GraphEdge> = listOf(
            // 1st-degree edges
            GraphEdge("focal-1", "deg1-1", 1),
            GraphEdge("focal-1", "deg1-2", 1),
            GraphEdge("focal-1", "deg1-3", 1),
            GraphEdge("focal-1", "deg1-4", 1),

            // 2nd-degree edges
            GraphEdge("deg1-1", "deg2-1", 2),
            GraphEdge("deg1-1", "deg2-2", 2),
            GraphEdge("deg1-2", "deg2-3", 2),
            GraphEdge("deg1-2", "deg2-4", 2),
            GraphEdge("deg1-3", "deg2-5", 2),
            GraphEdge("deg1-4", "deg2-6", 2),
            GraphEdge("deg1-4", "deg2-7", 2)
        )
    }
}
