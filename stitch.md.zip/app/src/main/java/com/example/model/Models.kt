package com.example.model

data class NoteItem(
    val id: String,
    val title: String,
    val folder: String,
    val path: String,
    val preview: String,
    val content: String,
    val tags: List<String>,
    val linksCount: Int,
    val wordsCount: Int,
    val updatedAt: String,
    val isPinned: Boolean = false,
    val isFleeting: Boolean = false,
    val readingTimeMin: Double = 3.5
)

data class BacklinkItem(
    val id: String,
    val noteTitle: String,
    val path: String,
    val snippet: String,
    val line: Int,
    val contextScore: Int,
    val isLinked: Boolean = true
)

data class ObjectiveItem(
    val id: String,
    val text: String,
    val isCompleted: Boolean
)

data class GraphNode(
    val id: String,
    val label: String,
    val linksCount: Int,
    val degree: Int, // 0 = focal, 1 = 1st degree, 2 = 2nd degree
    val xNorm: Float, // 0..1
    val yNorm: Float, // 0..1
    val group: String
)

data class GraphEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val degree: Int // 1 = primary solid, 2 = secondary dashed
)

data class FolderItem(
    val id: String,
    val name: String,
    val count: Int,
    val subfolders: List<SubfolderItem> = emptyList(),
    val isExpanded: Boolean = false
)

data class SubfolderItem(
    val name: String,
    val count: Int
)

data class TagItem(
    val name: String,
    val count: Int
)

enum class ScreenTab {
    EDITOR,
    VAULT,
    GRAPH,
    FOCUS
}
