package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ScreenTab
import com.example.ui.theme.StitchAmber
import com.example.ui.theme.StitchPrimary
import com.example.ui.theme.StitchPrimaryContainer

@Composable
fun StitchMonogram(modifier: Modifier = Modifier, size: Int = 32) {
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size * 0.28).dp))
            .background(Color(0xFF1A1C1B)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size((size * 0.75).dp)) {
            val strokeW = size * 0.16f
            val w = this.size.width
            val h = this.size.height
            val center = Offset(w / 2f, h / 2f)

            // 4 Spokes (Diagonal)
            val spokeLen = w * 0.28f
            val startOff = w * 0.12f

            val diagDirs = listOf(
                Offset(-1f, -1f),
                Offset(1f, -1f),
                Offset(-1f, 1f),
                Offset(1f, 1f)
            )

            diagDirs.forEach { dir ->
                val normDir = Offset(dir.x * 0.7071f, dir.y * 0.7071f)
                val p1 = center + normDir * startOff
                val p2 = center + normDir * (startOff + spokeLen)
                drawLine(
                    color = StitchAmber,
                    start = p1,
                    end = p2,
                    strokeWidth = strokeW,
                    cap = StrokeCap.Round
                )
            }

            // Central White Circle
            drawCircle(
                color = Color.White,
                radius = size * 0.11f,
                center = center
            )
        }
    }
}

@Composable
fun StitchTopBar(
    currentTab: ScreenTab,
    selectedWorkspace: String,
    workspaces: List<String>,
    onSelectWorkspace: (String) -> Unit,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var workspaceDropdownExpanded by remember { mutableStateOf(false) }

    val subtitle = when (currentTab) {
        ScreenTab.EDITOR -> "Editor"
        ScreenTab.VAULT -> "Vault"
        ScreenTab.GRAPH -> "Graph View"
        ScreenTab.FOCUS -> "Zen Focus"
    }

    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        modifier = modifier
            .fillMaxWidth()
            .shadow(2.dp),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Logo + Breadcrumb
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                StitchMonogram(size = 32)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Stitch.md",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = " / $subtitle",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 1.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(StitchPrimary)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Saved • cloud synced",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 10.5.sp
                            )
                        )
                    }
                }
            }

            // Right: Search + Workspace Switcher + Avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("top_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Search workspace",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { workspaceDropdownExpanded = true }
                            .padding(horizontal = 6.dp, vertical = 6.dp)
                            .testTag("workspace_switcher")
                    ) {
                        Text(
                            text = selectedWorkspace,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Icon(
                            imageVector = Icons.Default.UnfoldMore,
                            contentDescription = "Workspace switcher",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = workspaceDropdownExpanded,
                        onDismissRequest = { workspaceDropdownExpanded = false }
                    ) {
                        workspaces.forEach { ws ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = ws,
                                        fontWeight = if (ws == selectedWorkspace) FontWeight.Bold else FontWeight.Normal,
                                        color = if (ws == selectedWorkspace) StitchPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                onClick = {
                                    onSelectWorkspace(ws)
                                    workspaceDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(StitchPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User profile",
                        tint = Color.White,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StitchBottomBar(
    currentTab: ScreenTab,
    onTabSelected: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .shadow(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = { Icon(Icons.AutoMirrored.Outlined.Notes, contentDescription = "Editor", modifier = Modifier.size(22.dp)) },
                label = "Editor",
                selected = currentTab == ScreenTab.EDITOR,
                onClick = { onTabSelected(ScreenTab.EDITOR) },
                testTag = "nav_editor"
            )
            BottomNavItem(
                icon = { Icon(Icons.Outlined.Inventory2, contentDescription = "Vault", modifier = Modifier.size(22.dp)) },
                label = "Vault",
                selected = currentTab == ScreenTab.VAULT,
                onClick = { onTabSelected(ScreenTab.VAULT) },
                testTag = "nav_vault"
            )
            BottomNavItem(
                icon = { Icon(Icons.Outlined.Hub, contentDescription = "Graph", modifier = Modifier.size(22.dp)) },
                label = "Graph",
                selected = currentTab == ScreenTab.GRAPH,
                onClick = { onTabSelected(ScreenTab.GRAPH) },
                testTag = "nav_graph"
            )
            BottomNavItem(
                icon = { Icon(Icons.Outlined.CenterFocusStrong, contentDescription = "Focus", modifier = Modifier.size(22.dp)) },
                label = "Focus",
                selected = currentTab == ScreenTab.FOCUS,
                onClick = { onTabSelected(ScreenTab.FOCUS) },
                testTag = "nav_focus"
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: @Composable () -> Unit,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val activeColor = StitchPrimary
    val inactiveColor = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(bottom = 2.dp)
        ) {
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.material3.LocalContentColor provides if (selected) activeColor else inactiveColor
            ) {
                icon()
            }
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) activeColor else inactiveColor,
                fontSize = 11.sp
            )
        )
    }
}
