package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.CheckBoxOutlineBlank
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.NoteItem
import com.example.model.ObjectiveItem
import com.example.ui.theme.StitchAmber
import com.example.ui.theme.StitchPrimary
import com.example.ui.theme.StitchPrimaryContainer
import com.example.ui.theme.StitchSurfaceContainer
import com.example.ui.theme.StitchSurfaceContainerHigh
import com.example.ui.theme.StitchSurfaceContainerLow
import com.example.ui.theme.StitchSurfaceContainerLowest
import kotlinx.coroutines.delay

private const val EDITOR_HERO_IMAGE_URL =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuDxryt9AEytmfeAQ0NmB9CZEYHj64rjgwqPRVKZBZfs3miDitynAlPZ6GS-gB2LwItrYdsOJMWsVRN1WXuZx2WyVpUwz8j09hNYY_PaoTm7Gd_2xEEchPm9sY4aU-RHpxzSIt-6iGUXUrkKSs6Xj2m7O7rXcFv-B_mh5wDVxr9EC3lrgZI4F8bdqyLrsZdjVEZOOfQOSLkfgqGhz4RHQY2J8R3MKGd7F762UyVNOQ-S3DY0XXX0DqFE"

@Composable
fun EditorScreen(
    note: NoteItem,
    objectives: List<ObjectiveItem>,
    onToggleObjective: (String) -> Unit,
    onTitleChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var previewWikiTitle by remember { mutableStateOf<String?>(null) }
    var backlinksExpanded by remember { mutableStateOf(false) }
    var slashMenuVisible by remember { mutableStateOf(false) }
    var toastFeedback by remember { mutableStateOf<String?>(null) }
    var codeCopied by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current

    val completedCount = objectives.count { it.isCompleted }

    LaunchedEffect(toastFeedback) {
        if (toastFeedback != null) {
            delay(1200)
            toastFeedback = null
        }
    }

    LaunchedEffect(codeCopied) {
        if (codeCopied) {
            delay(1600)
            codeCopied = false
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                // Breadcrumbs & Synced Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "PHILOSOPHY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 1.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Text(
                            text = "  /  ",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                        )
                        Text(
                            text = "EPISTEMOLOGY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 1.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(StitchSurfaceContainer)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(StitchPrimary)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Synced",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }

            // Editable Document Title
            item {
                BasicTextField(
                    value = note.title,
                    onValueChange = onTitleChange,
                    textStyle = MaterialTheme.typography.headlineLarge.copy(
                        fontFamily = FontFamily.Serif,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 32.sp
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_title_input")
                )
            }

            // Dense Metadata Bar
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "History",
                        modifier = Modifier.size(13.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "2m ago",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = "•",
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                    Text(
                        text = "${note.wordsCount} words",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = "•",
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                    Text(
                        text = "${note.readingTimeMin} min read",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = "•",
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                    Text(
                        text = "Local IndexedDB & Cloud",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = StitchPrimary
                        ),
                        maxLines = 1
                    )
                }
            }

            // Stationery Tags Strip
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(note.tags) { tag ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(StitchSurfaceContainer)
                                .clickable { toastFeedback = "#$tag selected" }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "#",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.5.sp,
                                    color = StitchPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = tag,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }
            }

            // Visual Anchor Hero Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(StitchSurfaceContainer)
                ) {
                    AsyncImage(
                        model = EDITOR_HERO_IMAGE_URL,
                        contentDescription = "Canon Sheet Folio Edition 04",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.55f)
                                    )
                                )
                            )
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoStories,
                            contentDescription = "Book icon",
                            tint = StitchAmber,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Canon Sheet • Folio Edition 04",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            // Primary Editorial Body with WikiLinks
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Linear outlines presuppose that consciousness exists in rigid hierarchies. When ideas branch out organically, our cognitive cartography demands ",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = FontFamily.Serif,
                            lineHeight = 25.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // WikiLink 1: Associative Indexing
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StitchPrimaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier
                                .clickable {
                                    previewWikiTitle = if (previewWikiTitle == "Associative Indexing") null else "Associative Indexing"
                                }
                                .testTag("wikilink_associative_indexing")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "[[ ",
                                    color = StitchPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "Associative Indexing",
                                    color = StitchPrimary,
                                    style = TextStyle(textDecoration = TextDecoration.Underline),
                                    fontWeight = FontWeight.Medium,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = " ]]",
                                    color = StitchPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Text(
                            text = "rather than silos,",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Serif,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "as anticipated in",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Serif,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )

                        // WikiLink 2: Memex Concept
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StitchPrimaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier
                                .clickable {
                                    previewWikiTitle = if (previewWikiTitle == "Memex Concept") null else "Memex Concept"
                                }
                                .testTag("wikilink_memex_concept")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "[[ ",
                                    color = StitchPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "Memex Concept",
                                    color = StitchPrimary,
                                    style = TextStyle(textDecoration = TextDecoration.Underline),
                                    fontWeight = FontWeight.Medium,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = " ]]",
                                    color = StitchPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // Interactive WikiLink Preview Card
            item {
                AnimatedVisibility(
                    visible = previewWikiTitle != null,
                    enter = fadeIn() + slideInVertically(),
                    exit = fadeOut() + slideOutVertically()
                ) {
                    if (previewWikiTitle != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = StitchSurfaceContainerLowest,
                            shadowElevation = 4.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, StitchPrimaryContainer, RoundedCornerShape(12.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Link,
                                            contentDescription = "Link",
                                            tint = StitchPrimary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = previewWikiTitle!!,
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                color = StitchPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                    IconButton(
                                        onClick = { previewWikiTitle = null },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Dismiss preview",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = if (previewWikiTitle == "Associative Indexing") {
                                        "\"A mental mechanism whereby any item may be caused at will to select immediately and automatically another, mirroring the associative trails of the human brain...\""
                                    } else {
                                        "\"An intimate desktop device permitting an individual to browse books, records, and communications with mechanical rapidity and extreme elasticity...\""
                                    },
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontStyle = FontStyle.Italic,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(top = 2.dp)
                                ) {
                                    Text(
                                        text = "3 references",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = StitchPrimary
                                        )
                                    )
                                    Text(text = "•", color = MaterialTheme.colorScheme.outlineVariant)
                                    Text(
                                        text = "Updated yesterday",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Stylized Blockquote
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp))
                        .background(StitchPrimaryContainer.copy(alpha = 0.25f))
                        .padding(start = 14.dp, end = 12.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .width(3.5.dp)
                            .height(60.dp)
                            .background(StitchPrimary, RoundedCornerShape(2.dp))
                    )
                    Column(
                        modifier = Modifier.padding(start = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "“We are not building a container for thoughts; we are tending an organic orchard of concepts.”",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "— NOTE ON EPISTEMIC GARDENING, § 12",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 1.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }

            // Working Objectives Checklist
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StitchSurfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "WORKING OBJECTIVES",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Text(
                                text = "$completedCount of ${objectives.size} complete",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = StitchPrimary
                                )
                            )
                        }

                        objectives.forEach { obj ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { onToggleObjective(obj.id) }
                                    .padding(vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (obj.isCompleted) StitchPrimary else StitchSurfaceContainer)
                                        .border(
                                            width = 1.dp,
                                            color = if (obj.isCompleted) StitchPrimary else MaterialTheme.colorScheme.outlineVariant,
                                            shape = RoundedCornerShape(4.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (obj.isCompleted) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Completed",
                                            tint = Color.White,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Text(
                                    text = obj.text,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = if (obj.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                        textDecoration = if (obj.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Syntax Highlighted Code Block
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E201E),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        // Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF141614))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(StitchAmber)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "graph-parser.ts",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.5.sp,
                                        color = Color.White
                                    )
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (codeCopied) StitchPrimary else Color(0xFF282A28))
                                    .clickable {
                                        clipboardManager.setText(
                                            AnnotatedString(
                                                "export function extractBacklinks(content: string): LinkEdge[] {\n" +
                                                        "  const regex = /\\[\\[(.*?)\\]\\]/g;\n" +
                                                        "  const matches = [...content.matchAll(regex)];\n" +
                                                        "  return matches.map(m => ({ target: m[1], weight: 1 }));\n" +
                                                        "}"
                                            )
                                        )
                                        codeCopied = true
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = if (codeCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                                    contentDescription = "Copy code",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (codeCopied) "Copied!" else "Copy",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.White,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }

                        // Code content
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Row {
                                Text("export function ", color = Color(0xFFC8C5CC), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("extractBacklinks", color = Color(0xFFFFB77D), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("(content: ", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("string", color = StitchAmber, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("): ", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("LinkEdge", color = StitchAmber, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("[] {", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            Row {
                                Text("  const regex = ", color = Color(0xFFC8C5CC), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("/\\[\\[(.*?)\\]\\]/g", color = Color(0xFF81C784), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text(";", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            Row {
                                Text("  const matches = [...content.", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("matchAll", color = Color(0xFFFFB77D), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("(regex)];", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            Row {
                                Text("  return matches.", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("map", color = Color(0xFFFFB77D), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text("(m => ({ target: m[1], weight: 1 }));", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            Text("}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Mathematical Formalism Card
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StitchSurfaceContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "INFORMATION ENTROPY OF SUBGRAPH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 1.2.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ℋ(𝒯) = − ∑ p_i log₂ p_i",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Serif,
                                color = MaterialTheme.colorScheme.onSurface,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Shannon graph divergence score: 0.842 bit/edge",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }

            // Expandable Backlinks Section
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StitchSurfaceContainerHigh,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { backlinksExpanded = !backlinksExpanded }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(StitchPrimary.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Hub,
                                        contentDescription = "Hub",
                                        tint = StitchPrimary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "2 Backlinks referencing this note",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                            Icon(
                                imageVector = if (backlinksExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Toggle backlinks",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (backlinksExpanded) {
                            Column(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Snippet 1
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StitchSurfaceContainerLow,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "[[Zettelkasten Method]]",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = StitchPrimary
                                                )
                                            )
                                            Text(
                                                text = "Line 42",
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            )
                                        }
                                        Text(
                                            text = "\"...contrast this with The Architecture of Networked Thought where link topology replaces numerical index cards...\"",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontFamily = FontFamily.Serif,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }

                                // Snippet 2
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StitchSurfaceContainerLow,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "[[Index - Epistemic Gardens]]",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = StitchPrimary
                                                )
                                            )
                                            Text(
                                                text = "Line 8",
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            )
                                        }
                                        Text(
                                            text = "\"Key readings: Bush, Nelson, Engelbart, and modern structural analysis in The Architecture of Networked Thought.\"",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontFamily = FontFamily.Serif,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }

        // Floating Accessory Formatting Bar at the bottom
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp, start = 16.dp, end = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Slash Menu Dropdown
            AnimatedVisibility(
                visible = slashMenuVisible,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 })
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StitchSurfaceContainerLowest,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .padding(bottom = 8.dp)
                        .border(1.dp, StitchSurfaceContainer, RoundedCornerShape(12.dp))
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(StitchSurfaceContainer)
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "INSERT BLOCK",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Text(
                                text = "esc",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }

                        SlashMenuItem(
                            icon = Icons.Default.Title,
                            title = "Heading 1",
                            shortcut = "#",
                            onClick = {
                                slashMenuVisible = false
                                toastFeedback = "Heading 1"
                            }
                        )
                        SlashMenuItem(
                            icon = Icons.Outlined.CheckBox,
                            title = "To-do Checkbox",
                            shortcut = "[]",
                            onClick = {
                                slashMenuVisible = false
                                toastFeedback = "To-do Checkbox"
                            }
                        )
                        SlashMenuItem(
                            icon = Icons.Default.Link,
                            title = "Wiki-Link [[ ]]",
                            shortcut = "[[",
                            onClick = {
                                slashMenuVisible = false
                                toastFeedback = "Wiki-Link [[ ]]"
                            }
                        )
                        SlashMenuItem(
                            icon = Icons.Default.Lightbulb,
                            title = "Callout Box",
                            shortcut = ">!",
                            onClick = {
                                slashMenuVisible = false
                                toastFeedback = "Callout Box"
                            }
                        )
                    }
                }
            }

            // Formatting Pill Dock
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = StitchSurfaceContainerLowest.copy(alpha = 0.96f),
                shadowElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StitchSurfaceContainer, RoundedCornerShape(24.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        AccessoryButton("H1") { toastFeedback = "H1" }
                        AccessoryButton("H2") { toastFeedback = "H2" }
                        AccessoryButton("B", isBold = true) { toastFeedback = "**Bold**" }
                        AccessoryButton("I", isItalic = true) { toastFeedback = "*Italic*" }
                        AccessoryButton("[[ ]]", isPrimary = true) { toastFeedback = "[[" }
                        IconButton(
                            onClick = { toastFeedback = "• Bullet" },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.FormatListBulleted,
                                contentDescription = "Bulleted list",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        IconButton(
                            onClick = { toastFeedback = "[ ] Checkbox" },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CheckBoxOutlineBlank,
                                contentDescription = "Checkbox",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .height(20.dp)
                            .width(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    )

                    // Slash Button
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(StitchPrimary)
                            .clickable { slashMenuVisible = !slashMenuVisible }
                            .testTag("slash_menu_trigger"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "/",
                            color = Color.White,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        // Transient Toast Pill Feedback
        AnimatedVisibility(
            visible = toastFeedback != null,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 74.dp)
        ) {
            if (toastFeedback != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.onSurface,
                    shadowElevation = 6.dp
                ) {
                    Text(
                        text = toastFeedback!!,
                        color = MaterialTheme.colorScheme.surface,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SlashMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    shortcut: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = StitchPrimary,
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
        }
        Text(
            text = shortcut,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
    }
}

@Composable
private fun AccessoryButton(
    label: String,
    isBold: Boolean = false,
    isItalic: Boolean = false,
    isPrimary: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
                fontStyle = if (isItalic) FontStyle.Italic else FontStyle.Normal,
                fontFamily = if (isPrimary || label.contains("H")) FontFamily.Monospace else FontFamily.Serif,
                color = if (isPrimary) StitchPrimary else MaterialTheme.colorScheme.onSurface,
                fontSize = 12.sp
            )
        )
    }
}
