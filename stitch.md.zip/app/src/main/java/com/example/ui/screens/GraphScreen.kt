package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Drafts
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BacklinkItem
import com.example.model.GraphEdge
import com.example.model.GraphNode
import com.example.ui.theme.StitchAmber
import com.example.ui.theme.StitchAmberGlow
import com.example.ui.theme.StitchPrimary
import com.example.ui.theme.StitchPrimaryContainer
import com.example.ui.theme.StitchSecondaryContainer
import com.example.ui.theme.StitchSurfaceContainer
import com.example.ui.theme.StitchSurfaceContainerHigh
import com.example.ui.theme.StitchSurfaceContainerLow
import com.example.ui.theme.StitchSurfaceContainerLowest

enum class InspectorTab {
    LINKED_REFERENCES,
    UNLINKED_MENTIONS,
    LOCAL_GRAPH
}

@Composable
fun GraphScreen(
    nodes: List<GraphNode>,
    edges: List<GraphEdge>,
    backlinks: List<BacklinkItem>,
    unlinkedMentions: List<BacklinkItem>,
    focalNodeId: String,
    onSelectNode: (String) -> Unit,
    onLinkMention: (String) -> Unit,
    onOpenNote: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1.0f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var depthState by remember { mutableIntStateOf(1) } // 1 or 2
    var activeFilter by remember { mutableStateOf("#tag") } // #tag, folder, density
    var activeInspectorTab by remember { mutableStateOf(InspectorTab.LINKED_REFERENCES) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 28f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val textMeasurer = rememberTextMeasurer()
    val focalNode = nodes.find { it.id == focalNodeId } ?: nodes.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Interactive Graph Canvas Section
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(390.dp)
                    .background(StitchSurfaceContainerLow)
            ) {
                // Background subtle crosshair grid
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val step = 32f
                    for (x in 0..(size.width / step).toInt()) {
                        for (y in 0..(size.height / step).toInt()) {
                            drawCircle(
                                color = Color(0xFF1A1C1B).copy(alpha = 0.04f),
                                radius = 1.2f,
                                center = Offset(x * step, y * step)
                            )
                        }
                    }
                }

                // Interactive Pan & Drag Gesture Canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                panOffset += dragAmount
                            }
                        }
                        .pointerInput(nodes) {
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val down = event.changes.firstOrNull { it.pressed }
                                    if (down != null) {
                                        val tapPos = down.position
                                        // Find clicked node
                                        nodes.forEach { node ->
                                            val w = size.width.toFloat()
                                            val h = size.height.toFloat()
                                            val nx = (node.xNorm * w * scale) + panOffset.x
                                            val ny = (node.yNorm * h * scale) + panOffset.y
                                            val dist = (tapPos - Offset(nx, ny)).getDistance()
                                            if (dist < 36f) {
                                                onSelectNode(node.id)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height

                    // 1. Draw Edges
                    edges.forEach { edge ->
                        val fromNode = nodes.find { it.id == edge.fromNodeId }
                        val toNode = nodes.find { it.id == edge.toNodeId }

                        if (fromNode != null && toNode != null) {
                            val shouldDraw = if (edge.degree == 2) depthState == 2 else true
                            if (shouldDraw) {
                                val p1 = Offset(
                                    (fromNode.xNorm * w * scale) + panOffset.x,
                                    (fromNode.yNorm * h * scale) + panOffset.y
                                )
                                val p2 = Offset(
                                    (toNode.xNorm * w * scale) + panOffset.x,
                                    (toNode.yNorm * h * scale) + panOffset.y
                                )

                                if (edge.degree == 1) {
                                    drawLine(
                                        color = StitchPrimary,
                                        start = p1,
                                        end = p2,
                                        strokeWidth = 2.4f,
                                        cap = StrokeCap.Round
                                    )
                                } else {
                                    drawLine(
                                        color = Color(0xFFC8C5CC).copy(alpha = if (depthState == 2) 0.85f else 0.2f),
                                        start = p1,
                                        end = p2,
                                        strokeWidth = 1.4f,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                                    )
                                }
                            }
                        }
                    }

                    // 2. Draw 2nd-degree Nodes
                    nodes.filter { it.degree == 2 }.forEach { node ->
                        val alpha = if (depthState == 2) 1.0f else 0.25f
                        val center = Offset(
                            (node.xNorm * w * scale) + panOffset.x,
                            (node.yNorm * h * scale) + panOffset.y
                        )
                        drawCircle(
                            color = Color(0xFFE4E3DA).copy(alpha = alpha),
                            radius = 9f,
                            center = center
                        )
                        // Node label text
                        val textLayout = textMeasurer.measure(
                            text = node.label,
                            style = TextStyle(
                                fontFamily = FontFamily.Serif,
                                fontSize = 10.sp,
                                color = Color(0xFF554336).copy(alpha = alpha)
                            )
                        )
                        drawText(
                            textLayoutResult = textLayout,
                            topLeft = Offset(center.x - textLayout.size.width / 2f, center.y + 11f)
                        )
                    }

                    // 3. Draw 1st-degree Nodes
                    nodes.filter { it.degree == 1 }.forEach { node ->
                        val center = Offset(
                            (node.xNorm * w * scale) + panOffset.x,
                            (node.yNorm * h * scale) + panOffset.y
                        )
                        // Outer peach ring
                        drawCircle(
                            color = StitchPrimaryContainer,
                            radius = 18f,
                            center = center
                        )
                        // Inner amber core
                        drawCircle(
                            color = StitchPrimary,
                            radius = 9f,
                            center = center
                        )

                        // Label
                        val titleLayout = textMeasurer.measure(
                            text = node.label,
                            style = TextStyle(
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.sp,
                                color = Color(0xFF1A1C1B)
                            )
                        )
                        drawText(
                            textLayoutResult = titleLayout,
                            topLeft = Offset(center.x - titleLayout.size.width / 2f, center.y + 20f)
                        )

                        val subLayout = textMeasurer.measure(
                            text = "${node.linksCount} links",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                color = StitchPrimary
                            )
                        )
                        drawText(
                            textLayoutResult = subLayout,
                            topLeft = Offset(center.x - subLayout.size.width / 2f, center.y + 33f)
                        )
                    }

                    // 4. Draw Focal Node (Center)
                    val focalCenter = Offset(
                        (focalNode.xNorm * w * scale) + panOffset.x,
                        (focalNode.yNorm * h * scale) + panOffset.y
                    )

                    // Outer pulse ring
                    drawCircle(
                        color = StitchPrimaryContainer.copy(alpha = pulseAlpha),
                        radius = pulseRadius,
                        center = focalCenter
                    )
                    // Accent halo
                    drawCircle(
                        color = StitchAmber.copy(alpha = 0.6f),
                        radius = 22f,
                        center = focalCenter
                    )
                    // Core amber
                    drawCircle(
                        color = StitchPrimary,
                        radius = 15f,
                        center = focalCenter
                    )
                    // White center nucleus dot
                    drawCircle(
                        color = Color.White,
                        radius = 5.5f,
                        center = focalCenter
                    )

                    // Node Callout Badge rectangle
                    val badgeLayout = textMeasurer.measure(
                        text = focalNode.label,
                        style = TextStyle(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            color = Color.White
                        )
                    )
                    val badgeW = badgeLayout.size.width + 20f
                    val badgeH = 26f
                    val badgeTopLeft = Offset(focalCenter.x - badgeW / 2f, focalCenter.y + 26f)

                    drawRoundRect(
                        color = Color(0xFF1A1C1B).copy(alpha = 0.92f),
                        topLeft = badgeTopLeft,
                        size = androidx.compose.ui.geometry.Size(badgeW, badgeH),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                    )
                    drawText(
                        textLayoutResult = badgeLayout,
                        topLeft = Offset(focalCenter.x - badgeLayout.size.width / 2f, badgeTopLeft.y + 4f)
                    )
                }

                // Top Left Filter Pills
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 12.dp, top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = StitchSurfaceContainerLowest.copy(alpha = 0.92f),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Color:",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            listOf("#tag", "folder", "density").forEach { filter ->
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (activeFilter == filter) StitchPrimary else StitchSurfaceContainer,
                                    modifier = Modifier.clickable { activeFilter = filter }
                                ) {
                                    Text(
                                        text = filter,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (activeFilter == filter) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Top Right: Live Force Pill
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StitchSurfaceContainerLowest.copy(alpha = 0.92f),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 12.dp, top = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(StitchPrimary)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Live Force",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // Bottom Left: Density Gauge
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StitchSurfaceContainerLowest.copy(alpha = 0.92f),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hub,
                            contentDescription = "Hub",
                            tint = StitchPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${nodes.size} nodes • 112 links • 0 orphans",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }

                // Floating Right Utility Controls
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 12.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = StitchSurfaceContainerLowest.copy(alpha = 0.95f),
                        shadowElevation = 4.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            IconButton(
                                onClick = { scale = (scale + 0.15f).coerceAtMost(2.0f) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Zoom In",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                            IconButton(
                                onClick = { scale = (scale - 0.15f).coerceAtLeast(0.6f) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Remove,
                                    contentDescription = "Zoom Out",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .width(22.dp)
                                    .height(1.dp)
                                    .background(StitchSurfaceContainerHigh)
                            )
                            IconButton(
                                onClick = {
                                    scale = 1.0f
                                    panOffset = Offset.Zero
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FilterCenterFocus,
                                    contentDescription = "Center node",
                                    tint = StitchPrimary,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }

                    // Depth Toggle Pill
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = StitchSurfaceContainerLowest.copy(alpha = 0.95f),
                        shadowElevation = 4.dp,
                        modifier = Modifier.clickable {
                            depthState = if (depthState == 1) 2 else 1
                        }
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${depthState}°",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = StitchPrimary,
                                    fontSize = 11.5.sp
                                )
                            )
                            Text(
                                text = "DEPTH",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 7.5.sp,
                                    letterSpacing = 0.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }
            }
        }

        // Active Inspector Drawer
        item {
            Surface(
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    // Tactile Notch
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(38.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(StitchSecondaryContainer)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Inspector Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = "Inspector",
                                tint = StitchPrimary,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ACTIVE INSPECTOR",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    letterSpacing = 1.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StitchPrimary
                                )
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(StitchPrimary)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Synced to Canvas",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Focal Node Headline Banner
                    Text(
                        text = focalNode.label,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontFamily = FontFamily.Serif,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 24.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("epistemology", "hypertext").forEach { tag ->
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = StitchSurfaceContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "#",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = StitchPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = tag,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }
                        Text(
                            text = "Modified 2h ago",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Tabbed Link Context Switcher
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StitchSurfaceContainerLow,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { activeInspectorTab = InspectorTab.LINKED_REFERENCES }
                                    .padding(vertical = 4.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "Linked References",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (activeInspectorTab == InspectorTab.LINKED_REFERENCES) FontWeight.Bold else FontWeight.Medium,
                                        color = if (activeInspectorTab == InspectorTab.LINKED_REFERENCES) StitchPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(
                                    shape = CircleShape,
                                    color = if (activeInspectorTab == InspectorTab.LINKED_REFERENCES) StitchPrimaryContainer else StitchSurfaceContainer
                                ) {
                                    Text(
                                        text = "${backlinks.size}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.5.sp,
                                            color = if (activeInspectorTab == InspectorTab.LINKED_REFERENCES) StitchPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { activeInspectorTab = InspectorTab.UNLINKED_MENTIONS }
                                    .padding(vertical = 4.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "Unlinked Mentions",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (activeInspectorTab == InspectorTab.UNLINKED_MENTIONS) FontWeight.Bold else FontWeight.Medium,
                                        color = if (activeInspectorTab == InspectorTab.UNLINKED_MENTIONS) StitchPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(
                                    shape = CircleShape,
                                    color = if (activeInspectorTab == InspectorTab.UNLINKED_MENTIONS) StitchPrimaryContainer else StitchSurfaceContainer
                                ) {
                                    Text(
                                        text = "${unlinkedMentions.size}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                    )
                                }
                            }

                            Text(
                                text = "Local Graph",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (activeInspectorTab == InspectorTab.LOCAL_GRAPH) StitchPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (activeInspectorTab == InspectorTab.LOCAL_GRAPH) FontWeight.Bold else FontWeight.Medium
                                ),
                                modifier = Modifier
                                    .clickable { activeInspectorTab = InspectorTab.LOCAL_GRAPH }
                                    .padding(vertical = 4.dp, horizontal = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Backlinks Content Stream
        items(backlinks.size) { index ->
            val bl = backlinks[index]
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = StitchSurfaceContainerLowest,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 5.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (bl.path.contains("journal")) Icons.Default.CalendarToday else Icons.Default.Description,
                                contentDescription = bl.noteTitle,
                                tint = StitchPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = bl.noteTitle,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                        Text(
                            text = bl.path,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }

                    Text(
                        text = bl.snippet,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontSize = 13.5.sp,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Matched via line ${bl.line} • Context score ${bl.contextScore}%",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable { onOpenNote(bl.noteTitle) }
                                .padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = "Open Note",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StitchPrimary
                                )
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.ArrowForward,
                                contentDescription = "Open",
                                tint = StitchPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }
        }

        // Unlinked Mentions Discovered
        item {
            if (unlinkedMentions.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${unlinkedMentions.size} UNLINKED MENTION DISCOVERED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Text(
                            text = "Link all",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = StitchPrimary,
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier.clickable {
                                unlinkedMentions.forEach { onLinkMention(it.id) }
                            }
                        )
                    }

                    unlinkedMentions.forEach { mention ->
                        var isLinkedLocally by remember { mutableStateOf(false) }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = StitchSurfaceContainerLow,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Drafts,
                                            contentDescription = mention.noteTitle,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = mention.noteTitle,
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontFamily = FontFamily.Serif,
                                                fontWeight = FontWeight.Medium,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                    }
                                    Text(
                                        text = mention.path,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }

                                Text(
                                    text = mention.snippet,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Serif,
                                        fontSize = 13.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Exact string match",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isLinkedLocally) StitchPrimaryContainer else StitchPrimary,
                                        modifier = Modifier
                                            .clickable {
                                                isLinkedLocally = true
                                                onLinkMention(mention.id)
                                            }
                                            .testTag("btn_link_mention")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = if (isLinkedLocally) Icons.Default.Check else Icons.Default.AddLink,
                                                contentDescription = "Link mention",
                                                tint = if (isLinkedLocally) StitchPrimary else Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isLinkedLocally) "Linked!" else "Link Mention",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isLinkedLocally) StitchPrimary else Color.White
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}
