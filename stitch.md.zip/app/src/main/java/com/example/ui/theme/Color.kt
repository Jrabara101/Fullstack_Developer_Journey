package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Stitch.md Archival Stationery Palette
val StitchPrimary = Color(0xFF8D4B00)
val StitchOnPrimary = Color(0xFFFFFFFF)
val StitchPrimaryContainer = Color(0xFFFFDCC3)
val StitchOnPrimaryContainer = Color(0xFF2F1500)
val StitchPrimaryFixedDim = Color(0xFFFFB77D)

val StitchSecondary = Color(0xFF5F5F58)
val StitchOnSecondary = Color(0xFFFFFFFF)
val StitchSecondaryContainer = Color(0xFFE4E3DA)
val StitchOnSecondaryContainer = Color(0xFF65655E)

val StitchBackground = Color(0xFFF9F9F7)
val StitchOnBackground = Color(0xFF1A1C1B)

val StitchSurface = Color(0xFFF9F9F7)
val StitchOnSurface = Color(0xFF1A1C1B)
val StitchSurfaceVariant = Color(0xFFE2E3E1)
val StitchOnSurfaceVariant = Color(0xFF554336)

val StitchSurfaceContainerLowest = Color(0xFFFFFFFF)
val StitchSurfaceContainerLow = Color(0xFFF4F4F2)
val StitchSurfaceContainer = Color(0xFFEEEEEC)
val StitchSurfaceContainerHigh = Color(0xFFE8E8E6)
val StitchSurfaceContainerHighest = Color(0xFFE2E3E1)

val StitchOutline = Color(0xFF887364)
val StitchOutlineVariant = Color(0xFFDBC2B0)

val StitchAmber = Color(0xFFD97706)
val StitchAmberGlow = Color(0xFFFFE0B2)
val StitchDarkCard = Color(0xFF2F3130)
val StitchGreenDot = Color(0xFF2E7D32)
