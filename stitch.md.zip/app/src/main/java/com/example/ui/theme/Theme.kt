package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = StitchPrimary,
    onPrimary = StitchOnPrimary,
    primaryContainer = StitchPrimaryContainer,
    onPrimaryContainer = StitchOnPrimaryContainer,
    secondary = StitchSecondary,
    onSecondary = StitchOnSecondary,
    secondaryContainer = StitchSecondaryContainer,
    onSecondaryContainer = StitchOnSecondaryContainer,
    background = StitchBackground,
    onBackground = StitchOnBackground,
    surface = StitchSurface,
    onSurface = StitchOnSurface,
    surfaceVariant = StitchSurfaceVariant,
    onSurfaceVariant = StitchOnSurfaceVariant,
    surfaceContainer = StitchSurfaceContainer,
    surfaceContainerLow = StitchSurfaceContainerLow,
    surfaceContainerLowest = StitchSurfaceContainerLowest,
    surfaceContainerHigh = StitchSurfaceContainerHigh,
    surfaceContainerHighest = StitchSurfaceContainerHighest,
    outline = StitchOutline,
    outlineVariant = StitchOutlineVariant
)

private val DarkColorScheme = darkColorScheme(
    primary = StitchPrimaryFixedDim,
    onPrimary = StitchOnPrimaryContainer,
    primaryContainer = StitchPrimary,
    onPrimaryContainer = StitchPrimaryContainer,
    secondary = StitchSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF333330),
    onSecondaryContainer = Color(0xFFC8C7BE),
    background = Color(0xFF141413),
    onBackground = Color(0xFFF1F1EF),
    surface = Color(0xFF1A1C1B),
    onSurface = Color(0xFFF1F1EF),
    surfaceVariant = Color(0xFF282826),
    onSurfaceVariant = Color(0xFFC8C5CC),
    surfaceContainer = Color(0xFF242422),
    surfaceContainerLow = Color(0xFF1F1F1E),
    surfaceContainerLowest = Color(0xFF161615),
    surfaceContainerHigh = Color(0xFF2B2B29),
    surfaceContainerHighest = Color(0xFF353533)
)

@Composable
fun StitchTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
