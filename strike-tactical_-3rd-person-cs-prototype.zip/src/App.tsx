import React, { useEffect, useRef, useState } from 'react';
import { GameEngine } from './game/gameEngine';
import { HUD } from './components/HUD';
import { BuyMenu } from './components/BuyMenu';
import { Scoreboard } from './components/Scoreboard';
import { TacticalDevPanel } from './components/TacticalDevPanel';
import { Crosshair, Play, Settings, Shield, Terminal, Volume2 } from 'lucide-react';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // UI Overlays State
  const [isPointerLocked, setIsPointerLocked] = useState(false);
  const [showBuyMenu, setShowBuyMenu] = useState(false);
  const [showScoreboard, setShowScoreboard] = useState(false);
  const [showDevPanel, setShowDevPanel] = useState(false);
  const [, setTick] = useState(0);

  // Input mapping
  const inputState = useRef({
    moveForward: false,
    moveBackward: false,
    moveLeft: false,
    moveRight: false,
    jump: false,
    crouch: false,
    walk: false,
  });

  const mouseSensitivity = useRef(0.0022);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize Game Engine
    const engine = new GameEngine(canvasRef.current);
    engineRef.current = engine;

    // Register state tick update to sync React UI with engine 60fps loop
    let lastUiUpdate = 0;
    engine.onStateUpdate = () => {
      const now = performance.now();
      if (now - lastUiUpdate > 33) {
        // ~30 fps UI refresh for optimal React render performance
        lastUiUpdate = now;
        setTick((t) => (t + 1) % 10000);
      }
    };

    // --- GAME LOOP ---
    let animationFrameId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      const delta = Math.min(0.1, (time - lastTime) / 1000);
      lastTime = time;

      engine.update(delta, inputState.current);

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);

    // --- RESIZE LISTENER ---
    const handleResize = () => {
      if (!canvasRef.current || !engine) return;
      const width = canvasRef.current.clientWidth;
      const height = canvasRef.current.clientHeight;
      engine.camera.aspect = width / height;
      engine.camera.updateProjectionMatrix();
      engine.renderer.setSize(width, height, false);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // --- POINTER LOCK & MOUSE LOOK EVENT HANDLERS ---
  useEffect(() => {
    const handlePointerLockChange = () => {
      const locked = document.pointerLockElement === canvasRef.current;
      setIsPointerLocked(locked);
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvasRef.current || !engineRef.current) return;

      const engine = engineRef.current;
      const sens = mouseSensitivity.current;

      // Invert horizontal yaw for smooth CS mouse feel
      engine.playerYaw -= e.movementX * sens;
      // Clamp vertical pitch [-80 deg, +80 deg]
      engine.playerPitch = Math.max(
        -1.35,
        Math.min(1.35, engine.playerPitch - e.movementY * sens)
      );
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (!engineRef.current) return;

      if (e.button === 0) {
        // Left Click: Shoot or Plant
        engineRef.current.isShooting = true;
        engineRef.current.handlePrimaryFire();
      } else if (e.button === 1) {
        // Middle Click (Mouse 3): Shoulder Swap
        e.preventDefault();
        engineRef.current.toggleShoulderSwap();
      } else if (e.button === 2) {
        // Right Click: Defuse or secondary fire
        e.preventDefault();
        if (engineRef.current.bombPlanted) {
          engineRef.current.startDefusingBomb();
        }
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (!engineRef.current) return;
      if (e.button === 0) {
        engineRef.current.isShooting = false;
        engineRef.current.stopPlantingBomb();
      } else if (e.button === 2) {
        engineRef.current.stopDefusingBomb();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      const engine = engineRef.current;
      if (!engine) return;

      // Ignore repeat events
      if (e.repeat) return;

      if (code === 'KeyW') inputState.current.moveForward = true;
      if (code === 'KeyS') inputState.current.moveBackward = true;
      if (code === 'KeyA') inputState.current.moveLeft = true;
      if (code === 'KeyD') inputState.current.moveRight = true;
      if (code === 'Space') inputState.current.jump = true;
      if (code === 'ControlLeft' || code === 'ControlRight') inputState.current.crouch = true;
      if (code === 'ShiftLeft' || code === 'ShiftRight') inputState.current.walk = true;

      // Tactical Action Keys
      if (code === 'KeyV') {
        // Shoulder swap
        engine.toggleShoulderSwap();
      } else if (code === 'KeyR') {
        // Reload
        engine.reload();
      } else if (code === 'Digit1') {
        // Primary weapon
        engine.selectWeaponSlot(1);
      } else if (code === 'Digit2') {
        // Secondary pistol
        engine.selectWeaponSlot(2);
      } else if (code === 'Digit3') {
        // Combat knife
        engine.selectWeaponSlot(3);
      } else if (code === 'Digit5') {
        // C4 Bomb
        engine.selectWeaponSlot(5);
      } else if (code === 'KeyE') {
        // Interact (Plant or Defuse)
        if (engine.bombPlanted) {
          engine.startDefusingBomb();
        } else if (engine.activeWeapon.id === 'c4' || engine.playerTeam === 'T') {
          engine.startPlantingBomb();
        }
      } else if (code === 'KeyB') {
        // Buy menu toggle
        setShowBuyMenu((prev) => !prev);
      } else if (code === 'Tab') {
        // Scoreboard hold
        e.preventDefault();
        setShowScoreboard(true);
      } else if (code === 'Backquote' || code === 'F1') {
        // Dev Panel toggle
        setShowDevPanel((prev) => !prev);
      } else if (code === 'Escape') {
        setShowBuyMenu(false);
        setShowDevPanel(false);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const code = e.code;
      const engine = engineRef.current;

      if (code === 'KeyW') inputState.current.moveForward = false;
      if (code === 'KeyS') inputState.current.moveBackward = false;
      if (code === 'KeyA') inputState.current.moveLeft = false;
      if (code === 'KeyD') inputState.current.moveRight = false;
      if (code === 'Space') inputState.current.jump = false;
      if (code === 'ControlLeft' || code === 'ControlRight') inputState.current.crouch = false;
      if (code === 'ShiftLeft' || code === 'ShiftRight') inputState.current.walk = false;

      if (code === 'KeyE') {
        if (engine) {
          engine.stopPlantingBomb();
          engine.stopDefusingBomb();
        }
      }

      if (code === 'Tab') {
        setShowScoreboard(false);
      }
    };

    const handleWheel = (e: WheelEvent) => {
      const engine = engineRef.current;
      if (!engine) return;
      // Cycle slots 1 -> 2 -> 3 -> 5
      const slots: (1 | 2 | 3 | 5)[] = [1, 2, 3];
      if (engine.playerInventory.c4) slots.push(5);

      const currentIdx = slots.indexOf(engine.playerInventory.activeSlot);
      if (e.deltaY > 0) {
        const nextIdx = (currentIdx + 1) % slots.length;
        engine.selectWeaponSlot(slots[nextIdx]);
      } else {
        const prevIdx = (currentIdx - 1 + slots.length) % slots.length;
        engine.selectWeaponSlot(slots[prevIdx]);
      }
    };

    document.addEventListener('pointerlockchange', handlePointerLockChange);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('wheel', handleWheel);

    return () => {
      document.removeEventListener('pointerlockchange', handlePointerLockChange);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('wheel', handleWheel);
    };
  }, []);

  const requestPointerLock = () => {
    if (canvasRef.current) {
      canvasRef.current.requestPointerLock();
    }
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-slate-950 select-none">
      {/* 1. Main 3D Canvas */}
      <canvas
        ref={canvasRef}
        className="h-full w-full block cursor-crosshair"
        onClick={requestPointerLock}
      />

      {/* 2. Interactive In-Game HUD */}
      {engineRef.current && <HUD engine={engineRef.current} />}

      {/* 3. Buy Menu Overlay (Press B) */}
      {showBuyMenu && engineRef.current && (
        <BuyMenu engine={engineRef.current} onClose={() => setShowBuyMenu(false)} />
      )}

      {/* 4. Scoreboard Overlay (Hold Tab) */}
      {showScoreboard && engineRef.current && (
        <Scoreboard engine={engineRef.current} />
      )}

      {/* 5. Technical Designer Dev Suite (Press ~ / F1 or Click Button) */}
      {showDevPanel && engineRef.current && (
        <TacticalDevPanel engine={engineRef.current} onClose={() => setShowDevPanel(false)} />
      )}

      {/* 6. Click to Play / Pointer Lock Prompt Overlay */}
      {!isPointerLocked && !showBuyMenu && (
        <div
          onClick={requestPointerLock}
          className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-950/75 backdrop-blur-md cursor-pointer font-mono"
        >
          <div className="w-full max-w-xl rounded-2xl border border-slate-700/80 bg-slate-900/95 p-8 text-center shadow-2xl">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 mb-4">
              <Crosshair className="h-7 w-7 animate-pulse" />
            </div>

            <h1 className="text-2xl font-black text-slate-100 tracking-wider">
              STRIKE TACTICAL: 3RD-PERSON CS
            </h1>
            <p className="mt-2 text-xs text-slate-400 leading-relaxed">
              Tactical round-based MVP prototype featuring CS 1.6 counter-strafing, dynamic spray patterns, parallax-corrected hitscan, positional 3D audio, and bot combat.
            </p>

            {/* Quick Controls Cheat Sheet */}
            <div className="my-6 grid grid-cols-2 gap-2.5 text-left text-[11px] text-slate-300">
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 flex items-center justify-between">
                <span className="text-slate-400">WASD Movement</span>
                <span className="font-bold text-amber-400">Counter-Strafe</span>
              </div>
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 flex items-center justify-between">
                <span className="text-slate-400">Shoulder Swap</span>
                <span className="font-bold text-sky-400">[V] or [M3]</span>
              </div>
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 flex items-center justify-between">
                <span className="text-slate-400">Silent Walk / Crouch</span>
                <span className="font-bold text-slate-200">[Shift] / [Ctrl]</span>
              </div>
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 flex items-center justify-between">
                <span className="text-slate-400">Buy Armory</span>
                <span className="font-bold text-emerald-400">[B]</span>
              </div>
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 flex items-center justify-between">
                <span className="text-slate-400">Plant / Defuse C4</span>
                <span className="font-bold text-rose-400">Hold [E]</span>
              </div>
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 flex items-center justify-between">
                <span className="text-slate-400">Tech Dev Suite</span>
                <span className="font-bold text-amber-400">[~] or [F1]</span>
              </div>
            </div>

            <button className="w-full rounded-xl bg-amber-500 hover:bg-amber-400 py-3.5 text-xs font-black uppercase tracking-widest text-slate-950 shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2">
              <Play className="h-4 w-4 fill-current" /> CLICK TO ENGAGE (CAPTURE MOUSE)
            </button>
          </div>
        </div>
      )}

      {/* 7. Bottom Dev Suite Trigger Button */}
      <div className="absolute bottom-4 right-4 z-20 flex items-center gap-2">
        <button
          onClick={() => setShowDevPanel((p) => !p)}
          className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/90 hover:bg-slate-800 px-3 py-1.5 text-xs font-bold text-amber-400 shadow-xl backdrop-blur-md transition-colors"
        >
          <Terminal className="h-3.5 w-3.5" />
          <span>Tech Dev Suite [~]</span>
        </button>
      </div>
    </div>
  );
}
