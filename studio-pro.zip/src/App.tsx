import React, { useState, useEffect } from "react";
import { TopNav } from "./components/TopNav";
import { GenerationSidebar } from "./components/GenerationSidebar";
import { CanvasViewport } from "./components/CanvasViewport";
import { CommunityModal } from "./components/CommunityModal";
import { PricingModal } from "./components/PricingModal";
import { RecipeInspectorModal } from "./components/RecipeInspectorModal";
import { AllHistoryModal } from "./components/AllHistoryModal";
import { ToastContainer } from "./components/ToastContainer";
import { AVAILABLE_MODELS, STYLE_OPTIONS, INITIAL_GENERATIONS } from "./data/presets";
import { AspectRatioKey, GeneratedImage, ModelOption, StyleOption, ToastMessage } from "./types";

export default function App() {
  // Credits State (Defaults to 45 Credits matching the screenshot)
  const [credits, setCredits] = useState<number>(() => {
    const saved = localStorage.getItem("studio_pro_credits");
    return saved ? parseInt(saved, 10) : 45;
  });

  useEffect(() => {
    localStorage.setItem("studio_pro_credits", credits.toString());
  }, [credits]);

  // Generation History State (pre-populated with high-fidelity items matching screenshot)
  const [history, setHistory] = useState<GeneratedImage[]>(() => {
    const saved = localStorage.getItem("studio_pro_history");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error("Failed to parse history from localStorage", e);
      }
    }
    return INITIAL_GENERATIONS;
  });

  useEffect(() => {
    localStorage.setItem("studio_pro_history", JSON.stringify(history));
  }, [history]);

  // Active Image in Viewport (Default: Neon Cityscape)
  const [currentImage, setCurrentImage] = useState<GeneratedImage | null>(() => {
    return history.length > 0 ? history[0] : INITIAL_GENERATIONS[0];
  });

  // Generation Form State
  const [prompt, setPrompt] = useState<string>("");
  const [negativePrompt, setNegativePrompt] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<ModelOption>(AVAILABLE_MODELS[0]); // Flux Pro Ultra (1.1)
  const [selectedStyle, setSelectedStyle] = useState<StyleOption>(STYLE_OPTIONS[0]); // Cinematic (matching screenshot)
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatioKey>("16:9"); // 16:9 (matching screenshot)
  const [seed, setSeed] = useState<number>(() => Math.floor(Math.random() * 100000000));
  const [steps, setSteps] = useState<number>(30);
  const [guidanceScale, setGuidanceScale] = useState<number>(7.5);
  const [sampler, setSampler] = useState<string>("Euler a");
  const [isPrivate, setIsPrivate] = useState<boolean>(false);

  // Async Execution & Feedback States
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationProgress, setGenerationProgress] = useState<number>(0);
  const [generationStatusText, setGenerationStatusText] = useState<string>("");
  const [isEnhancing, setIsEnhancing] = useState<boolean>(false);

  // Modals & Drawers
  const [isCommunityOpen, setIsCommunityOpen] = useState<boolean>(false);
  const [isPricingOpen, setIsPricingOpen] = useState<boolean>(false);
  const [isRecipeOpen, setIsRecipeOpen] = useState<boolean>(false);
  const [inspectingImage, setInspectingImage] = useState<GeneratedImage | null>(null);
  const [isAllHistoryOpen, setIsAllHistoryOpen] = useState<boolean>(false);
  const [communityItems, setCommunityItems] = useState<GeneratedImage[]>(INITIAL_GENERATIONS);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (toast: Omit<ToastMessage, "id">) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    const newToast: ToastMessage = { ...toast, id };
    setToasts((prev) => [...prev, newToast]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Fetch initial community feed items from backend
  useEffect(() => {
    fetch("/api/community")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && Array.isArray(data.items)) {
          setCommunityItems(data.items);
        }
      })
      .catch((err) => console.warn("Failed to load community feed:", err));
  }, []);

  // 1. One-Click Prompt Enhancement Handler
  const handleEnhancePrompt = async () => {
    if (!prompt.trim() || isEnhancing) return;
    setIsEnhancing(true);

    try {
      const res = await fetch("/api/prompt/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          style: selectedStyle.name,
          model: selectedModel.name,
        }),
      });

      const data = await res.json();
      if (data.success && data.enhancedPrompt) {
        setPrompt(data.enhancedPrompt);
        if (data.suggestedNegative && !negativePrompt) {
          setNegativePrompt(data.suggestedNegative);
        }
        addToast({
          type: "success",
          title: "Prompt Enhanced",
          message: `Atmospheric lighting & detail keywords added via ${data.source || "AI Studio engine"}.`,
        });
      } else {
        throw new Error(data.error || "Failed to enhance prompt");
      }
    } catch (error: any) {
      addToast({
        type: "error",
        title: "Prompt Enhancement Error",
        message: error.message || "Could not reach enhancement server.",
      });
    } finally {
      setIsEnhancing(false);
    }
  };

  // 2. High-Performance Generation Handler
  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    const cost = selectedModel.creditCost;

    // Check credits
    if (credits < cost) {
      addToast({
        type: "warning",
        title: "Insufficient Compute Credits",
        message: `You need ${cost} credits to run ${selectedModel.name}. Please top-up to continue.`,
      });
      setIsPricingOpen(true);
      return;
    }

    // Optimistic Credit Reservation
    setCredits((c) => Math.max(0, c - cost));
    setIsGenerating(true);
    setGenerationProgress(10);
    setGenerationStatusText("Validating moderation & safety filters...");

    // Progressive stage simulation
    const stageTimer1 = setTimeout(() => {
      setGenerationProgress(35);
      setGenerationStatusText("Mixing digital pigments & artistic styles...");
    }, 600);

    const stageTimer2 = setTimeout(() => {
      setGenerationProgress(65);
      setGenerationStatusText("Aligning multi-step diffusion latents across GPU nodes...");
    }, 1300);

    const stageTimer3 = setTimeout(() => {
      setGenerationProgress(88);
      setGenerationStatusText("Upscaling high-frequency details & rendering 8K pass...");
    }, 2000);

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          negativePrompt,
          model: selectedModel.name,
          style: selectedStyle.name,
          aspectRatio: selectedAspectRatio,
          seed,
          steps,
          guidanceScale,
          sampler,
          isPrivate,
        }),
      });

      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);
      clearTimeout(stageTimer3);

      const data = await response.json();

      if (data.success && data.image) {
        setGenerationProgress(100);
        setGenerationStatusText("Generation Complete!");

        // Add to history and set as active image
        setHistory((prev) => [data.image, ...prev]);
        setCurrentImage(data.image);

        // Randomize seed for next generation
        setSeed(Math.floor(Math.random() * 100000000));

        addToast({
          type: "success",
          title: "Render Completed",
          message: `${data.image.title} generated in ${((data.image.generationTimeMs || 2200) / 1000).toFixed(1)}s (-${cost} credits).`,
        });
      } else {
        // Refusal / Safety failure -> Refund credits immediately
        if (data.refundCredits) {
          setCredits((c) => c + cost);
        }
        addToast({
          type: "error",
          title: data.refusal ? "Content Safety Filter" : "Generation Failed",
          message: data.message || data.error || "Unable to generate image. Your credits were refunded.",
          refunded: true,
        });
      }
    } catch (err: any) {
      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);
      clearTimeout(stageTimer3);
      // Auto-refund on unexpected network exception
      setCredits((c) => c + cost);
      addToast({
        type: "error",
        title: "Network Exception",
        message: "Failed to connect to image generation endpoint. Credits refunded.",
        refunded: true,
      });
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
      setGenerationStatusText("");
    }
  };

  // 3. Fork & Remix (1-Click recipe clone)
  const handleForkAndRemix = (img: GeneratedImage) => {
    setPrompt(img.prompt);
    if (img.negativePrompt) setNegativePrompt(img.negativePrompt);
    setSeed(img.seed);
    setSteps(img.steps);
    setGuidanceScale(img.guidanceScale);
    setSampler(img.sampler);
    setSelectedAspectRatio(img.aspectRatio);

    // Find and set model
    const foundModel = AVAILABLE_MODELS.find((m) => m.name === img.model) || AVAILABLE_MODELS[0];
    setSelectedModel(foundModel);

    // Find and set style
    const foundStyle = STYLE_OPTIONS.find((s) => s.name.toLowerCase() === img.style.toLowerCase()) || STYLE_OPTIONS[0];
    setSelectedStyle(foundStyle);

    // Track remix on server
    fetch("/api/community/remix", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: img.id }),
    }).catch(() => {});

    addToast({
      type: "info",
      title: "Recipe Forked",
      message: `Loaded exact seed (${img.seed}), CFG (${img.guidanceScale}), and parameters into studio!`,
    });
  };

  // 4. Like Community Item
  const handleLikeItem = (id: string) => {
    setCommunityItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, likes: item.likes + 1 } : item))
    );
    fetch("/api/community/like", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    }).catch(() => {});
  };

  // 5. Inspect Recipe
  const handleInspectRecipe = (img: GeneratedImage) => {
    setInspectingImage(img);
    setIsRecipeOpen(true);
  };

  // 6. Add Credits
  const handleAddCredits = (amount: number, packageName: string) => {
    setCredits((prev) => prev + amount);
    addToast({
      type: "success",
      title: "Compute Credits Loaded",
      message: `+${amount.toLocaleString()} credits added to your account via ${packageName}!`,
    });
    setIsPricingOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#0b0c10] text-zinc-100 flex flex-col antialiased selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Top Navigation Bar */}
      <TopNav
        credits={credits}
        onOpenPricing={() => setIsPricingOpen(true)}
        onOpenCommunity={() => setIsCommunityOpen(true)}
      />

      {/* Main Studio Layout: Left Controls + Right Canvas */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left Generation Sidebar Panel */}
        <GenerationSidebar
          prompt={prompt}
          setPrompt={setPrompt}
          negativePrompt={negativePrompt}
          setNegativePrompt={setNegativePrompt}
          selectedModel={selectedModel}
          setSelectedModel={setSelectedModel}
          selectedStyle={selectedStyle}
          setSelectedStyle={setSelectedStyle}
          selectedAspectRatio={selectedAspectRatio}
          setSelectedAspectRatio={setSelectedAspectRatio}
          seed={seed}
          setSeed={setSeed}
          steps={steps}
          setSteps={setSteps}
          guidanceScale={guidanceScale}
          setGuidanceScale={setGuidanceScale}
          sampler={sampler}
          setSampler={setSampler}
          isPrivate={isPrivate}
          setIsPrivate={setIsPrivate}
          onGenerate={handleGenerate}
          isGenerating={isGenerating}
          onEnhancePrompt={handleEnhancePrompt}
          isEnhancing={isEnhancing}
        />

        {/* Right Canvas & History Viewport */}
        <CanvasViewport
          currentImage={currentImage}
          history={history}
          onSelectImage={(img) => setCurrentImage(img)}
          onForkAndRemix={handleForkAndRemix}
          onInspectRecipe={handleInspectRecipe}
          onOpenAllHistory={() => setIsAllHistoryOpen(true)}
          isGenerating={isGenerating}
          generationProgress={generationProgress}
          generationStatusText={generationStatusText}
        />
      </div>

      {/* Modals & Overlays */}
      <CommunityModal
        isOpen={isCommunityOpen}
        onClose={() => setIsCommunityOpen(false)}
        items={communityItems}
        onForkAndRemix={handleForkAndRemix}
        onLikeItem={handleLikeItem}
      />

      <PricingModal
        isOpen={isPricingOpen}
        onClose={() => setIsPricingOpen(false)}
        currentCredits={credits}
        onAddCredits={handleAddCredits}
      />

      <RecipeInspectorModal
        isOpen={isRecipeOpen}
        onClose={() => setIsRecipeOpen(false)}
        image={inspectingImage}
        onForkAndRemix={handleForkAndRemix}
      />

      <AllHistoryModal
        isOpen={isAllHistoryOpen}
        onClose={() => setIsAllHistoryOpen(false)}
        history={history}
        onSelectImage={(img) => setCurrentImage(img)}
        onForkAndRemix={handleForkAndRemix}
        onInspectRecipe={handleInspectRecipe}
      />

      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
