import React, { useState } from "react";
import { 
  X, 
  Search, 
  Download, 
  Trash2, 
  GitFork, 
  Info, 
  Sparkles,
  Layers
} from "lucide-react";
import { GeneratedImage } from "../types";

interface AllHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: GeneratedImage[];
  onSelectImage: (img: GeneratedImage) => void;
  onForkAndRemix: (img: GeneratedImage) => void;
  onInspectRecipe: (img: GeneratedImage) => void;
}

export const AllHistoryModal: React.FC<AllHistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  onSelectImage,
  onForkAndRemix,
  onInspectRecipe,
}) => {
  const [searchTerm, setSearchTerm] = useState("");

  if (!isOpen) return null;

  const filtered = history.filter(
    (h) =>
      h.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.prompt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.model.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in-50 duration-200">
      <div className="w-full max-w-5xl max-h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div>
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-zinc-100">Generation History & Sessions</h2>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Browse all your local and cloud renders, inspect recipes, and export high-res artwork.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-4 border-b border-zinc-800/80 bg-zinc-950/80">
          <div className="relative w-full max-w-md">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter generation history by prompt, title, model..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-xl bg-zinc-900 border border-zinc-800 pl-9 pr-3 py-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Grid */}
        <div className="flex-1 overflow-y-auto p-5 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 transition-all overflow-hidden flex flex-col group"
            >
              <div 
                onClick={() => {
                  onSelectImage(item);
                  onClose();
                }}
                className="relative aspect-video bg-black cursor-pointer overflow-hidden"
              >
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-zinc-300 border border-zinc-700/60">
                  {item.model}
                </div>
              </div>

              <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2">
                <div>
                  <h4 className="text-xs font-semibold text-zinc-200 truncate">{item.title}</h4>
                  <p className="text-[11px] text-zinc-400 line-clamp-2 mt-1 leading-snug">{item.prompt}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-zinc-800/80 text-xs">
                  <span className="text-[10px] text-zinc-500 font-mono">{item.aspectRatio}</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onInspectRecipe(item)}
                      className="p-1 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded cursor-pointer"
                      title="Inspect recipe"
                    >
                      <Info className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        onForkAndRemix(item);
                        onClose();
                      }}
                      className="p-1 text-indigo-400 hover:text-indigo-300 hover:bg-indigo-950/40 rounded cursor-pointer"
                      title="Fork into studio"
                    >
                      <GitFork className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
