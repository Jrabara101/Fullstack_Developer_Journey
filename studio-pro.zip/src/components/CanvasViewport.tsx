import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles, 
  Search, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Settings, 
  Maximize2, 
  Download, 
  Copy, 
  GitFork, 
  Info, 
  Check, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw,
  ShieldCheck,
  Zap,
  MoreHorizontal
} from "lucide-react";
import { GeneratedImage } from "../types";

interface CanvasViewportProps {
  currentImage: GeneratedImage | null;
  history: GeneratedImage[];
  onSelectImage: (img: GeneratedImage) => void;
  onForkAndRemix: (img: GeneratedImage) => void;
  onInspectRecipe: (img: GeneratedImage) => void;
  onOpenAllHistory: () => void;
  isGenerating: boolean;
  generationProgress: number;
  generationStatusText: string;
}

export const CanvasViewport: React.FC<CanvasViewportProps> = ({
  currentImage,
  history,
  onSelectImage,
  onForkAndRemix,
  onInspectRecipe,
  onOpenAllHistory,
  isGenerating,
  generationProgress,
  generationStatusText,
}) => {
  const [isPlayingMotion, setIsPlayingMotion] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [copied, setCopied] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Auto-reset zoom when image changes
  useEffect(() => {
    setZoomLevel(1);
  }, [currentImage?.id]);

  const handleCopyPrompt = () => {
    if (!currentImage) return;
    navigator.clipboard.writeText(currentImage.prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!currentImage) return;
    // Create download link
    const a = document.createElement("a");
    a.href = currentImage.imageUrl;
    a.download = `StudioPro_${currentImage.title.replace(/\s+/g, "_")}_seed${currentImage.seed}.png`;
    a.target = "_blank";
    a.rel = "noreferrer";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <main className="flex-1 bg-[#0b0c10] flex flex-col h-[calc(100vh-4rem)] overflow-y-auto p-4 md:p-6 lg:p-7 space-y-6">
      {/* Main High-Tech Monitor Frame matching screenshot */}
      <div 
        ref={containerRef}
        className="w-full rounded-2xl bg-zinc-950 border border-zinc-800/90 shadow-2xl overflow-hidden flex flex-col relative group"
      >
        {/* Top Bezel / Header matching screenshot */}
        <div className="h-10 bg-zinc-900/95 border-b border-zinc-800/80 px-4 flex items-center justify-between text-xs text-zinc-300 select-none">
          {/* Left: GENERATION STUDIO logo */}
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-300">
              <Sparkles className="w-3 h-3" />
            </div>
            <span className="font-semibold tracking-wider text-[11px] text-zinc-300 uppercase">
              Generation Studio
            </span>
          </div>

          {/* Center: Image Title in uppercase matching screenshot */}
          <div className="hidden sm:flex items-center gap-2 font-mono text-[11px] font-bold text-zinc-200 tracking-wider">
            <span>{currentImage?.title || "NEON CITYSCAPE"}</span>
          </div>

          {/* Right: User Avatar & Search icon matching screenshot */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => currentImage && onInspectRecipe(currentImage)}
              className="hover:text-indigo-400 text-zinc-400 transition-colors cursor-pointer flex items-center gap-1 text-[11px]"
              title="Inspect image recipe & generation parameters"
            >
              <Info className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Inspect Recipe</span>
            </button>
            <div className="w-6 h-6 rounded-full overflow-hidden border border-zinc-700">
              <img
                src={currentImage?.authorAvatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"}
                alt="Creator Avatar"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-5 h-5 flex items-center justify-center text-zinc-400 hover:text-zinc-200 cursor-pointer">
              <Search className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* Central Display Viewport */}
        <div 
          className="relative w-full aspect-video min-h-[360px] md:min-h-[460px] lg:min-h-[520px] bg-black/95 flex items-center justify-center overflow-hidden select-none"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {isGenerating ? (
            /* Progressive AI Generation Stage Feedback */
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-20 bg-zinc-950/90 backdrop-blur-md animate-shimmer">
              <div className="w-20 h-20 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 mb-5 relative shadow-lg shadow-indigo-500/10">
                <Sparkles className="w-10 h-10 animate-pulse text-indigo-300" />
                <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 opacity-30 blur-sm animate-spin" />
              </div>

              <h3 className="text-lg font-bold text-zinc-100 mb-1">
                {generationStatusText || "Generating Neural Latents..."}
              </h3>
              <p className="text-xs text-zinc-400 max-w-md mb-6">
                Executing multi-step diffusion sampler across high-throughput GPU cluster. Optimistic credit reservation active.
              </p>

              {/* Progress Bar */}
              <div className="w-full max-w-sm bg-zinc-900 border border-zinc-800 rounded-full h-2.5 overflow-hidden mb-3">
                <div 
                  className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 h-full rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${Math.max(8, Math.min(100, generationProgress))}%` }}
                />
              </div>

              <div className="flex items-center gap-4 text-[11px] text-zinc-500">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Auto-Refund on Error
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  Optimistic Hold
                </span>
              </div>
            </div>
          ) : currentImage ? (
            /* Active Image Display */
            <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
              <img
                src={currentImage.imageUrl}
                alt={currentImage.title}
                referrerPolicy="no-referrer"
                className={`w-full h-full object-contain transition-transform duration-700 ease-out ${
                  isPlayingMotion ? "scale-110 translate-y-1" : ""
                }`}
                style={{
                  transform: `scale(${zoomLevel}) ${isPlayingMotion ? "scale(1.08)" : ""}`,
                  transition: isPlayingMotion ? "transform 8s cubic-bezier(0.25, 1, 0.5, 1)" : "transform 0.3s ease-out",
                }}
              />

              {/* Floating Quick Action Overlay on Hover */}
              <div 
                className={`absolute top-4 right-4 flex items-center gap-2 bg-zinc-950/85 backdrop-blur-md border border-zinc-800/90 rounded-xl p-1.5 shadow-2xl transition-opacity duration-200 z-10 ${
                  isHovered ? "opacity-100" : "opacity-0 md:opacity-80"
                }`}
              >
                <button
                  id="canvas-fork-btn"
                  onClick={() => onForkAndRemix(currentImage)}
                  className="px-2.5 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  title="Fork & Remix parameters into Generation Studio"
                >
                  <GitFork className="w-3.5 h-3.5" />
                  <span>Fork & Remix</span>
                </button>

                <button
                  id="canvas-copy-prompt-btn"
                  onClick={handleCopyPrompt}
                  className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-zinc-100 transition-colors cursor-pointer"
                  title="Copy Prompt"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>

                <button
                  id="canvas-inspect-btn"
                  onClick={() => onInspectRecipe(currentImage)}
                  className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-zinc-100 transition-colors cursor-pointer"
                  title="Inspect Metadata & Seed"
                >
                  <Info className="w-4 h-4" />
                </button>

                <button
                  id="canvas-download-btn"
                  onClick={handleDownload}
                  className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-zinc-100 transition-colors cursor-pointer"
                  title="Download Image"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>

              {/* Bottom Left Zoom Controls Overlay */}
              <div 
                className={`absolute bottom-4 left-4 flex items-center gap-1 bg-zinc-950/80 backdrop-blur-md border border-zinc-800/80 rounded-lg p-1 text-zinc-400 z-10 transition-opacity duration-200 ${
                  isHovered ? "opacity-100" : "opacity-0"
                }`}
              >
                <button
                  onClick={() => setZoomLevel((z) => Math.min(3, z + 0.25))}
                  className="p-1 hover:text-zinc-100 hover:bg-zinc-800 rounded cursor-pointer"
                  title="Zoom in"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <span className="text-[10px] font-mono px-1">{Math.round(zoomLevel * 100)}%</span>
                <button
                  onClick={() => setZoomLevel((z) => Math.max(0.5, z - 0.25))}
                  className="p-1 hover:text-zinc-100 hover:bg-zinc-800 rounded cursor-pointer"
                  title="Zoom out"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setZoomLevel(1)}
                  className="p-1 hover:text-zinc-100 hover:bg-zinc-800 rounded cursor-pointer"
                  title="Reset zoom"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>
            </div>
          ) : (
            <div className="text-zinc-500 text-sm">Select or generate an image</div>
          )}
        </div>

        {/* Bottom Video / Cinematic Monitor Player Bar matching screenshot */}
        <div className="h-11 bg-zinc-900/95 border-t border-zinc-800/80 px-4 flex items-center justify-between text-xs text-zinc-400 select-none">
          {/* Left: Timestamp counter matching screenshot */}
          <div className="font-mono text-[11px] text-zinc-400 flex items-center gap-1.5">
            <span>01:45:25</span>
            <span className="text-zinc-600">/</span>
            <span className="text-zinc-500">03:12:00</span>
          </div>

          {/* Center: Playback / Motion controls matching screenshot */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => {
                if (history.length > 1) {
                  const idx = history.findIndex((h) => h.id === currentImage?.id);
                  const prevIdx = idx > 0 ? idx - 1 : history.length - 1;
                  onSelectImage(history[prevIdx]);
                }
              }}
              className="p-1 text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
              title="Previous generation"
            >
              <SkipBack className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setIsPlayingMotion(!isPlayingMotion)}
              className="w-7 h-7 rounded-full bg-zinc-800 hover:bg-indigo-600/40 hover:text-indigo-300 text-zinc-200 flex items-center justify-center transition-all cursor-pointer"
              title={isPlayingMotion ? "Pause cinematic motion" : "Play cinematic motion parallax"}
            >
              {isPlayingMotion ? (
                <Pause className="w-3.5 h-3.5" />
              ) : (
                <Play className="w-3.5 h-3.5 ml-0.5" />
              )}
            </button>

            <button 
              onClick={() => {
                if (history.length > 1) {
                  const idx = history.findIndex((h) => h.id === currentImage?.id);
                  const nextIdx = idx < history.length - 1 ? idx + 1 : 0;
                  onSelectImage(history[nextIdx]);
                }
              }}
              className="p-1 text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
              title="Next generation"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Right: 8K | HDR | 60fps & Settings / Fullscreen matching screenshot */}
          <div className="flex items-center gap-3">
            <div className="font-mono text-[10px] text-zinc-400 bg-zinc-800/80 px-2 py-0.5 rounded border border-zinc-700/60 flex items-center gap-1.5 font-medium">
              <span>8K</span>
              <span className="text-zinc-600">|</span>
              <span>HDR</span>
              <span className="text-zinc-600">|</span>
              <span>60fps</span>
            </div>

            <button
              onClick={() => currentImage && onInspectRecipe(currentImage)}
              className="p-1 text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
              title="Engine Parameters"
            >
              <Settings className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={toggleFullscreen}
              className="p-1 text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
              title="Toggle Fullscreen"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* RECENT HISTORY Strip matching screenshot */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold tracking-wider text-zinc-400 uppercase">
            Recent History
          </h2>
          <button
            id="view-all-history-link"
            onClick={onOpenAllHistory}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium transition-colors cursor-pointer"
          >
            View All ({history.length})
          </button>
        </div>

        <div className="flex items-center gap-3.5 overflow-x-auto pb-2 scrollbar-none">
          {history.slice(0, 5).map((item) => {
            const isSelected = currentImage?.id === item.id;
            return (
              <div
                key={item.id}
                id={`history-thumb-${item.id}`}
                onClick={() => onSelectImage(item)}
                className={`relative w-20 h-20 md:w-24 md:h-24 rounded-2xl overflow-hidden shrink-0 border cursor-pointer transition-all duration-200 group ${
                  isSelected
                    ? "border-indigo-500 glow-active-ring scale-105"
                    : "border-zinc-800 hover:border-zinc-600 opacity-80 hover:opacity-100"
                }`}
                title={`${item.title} - ${item.style}`}
              >
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-1.5">
                  <span className="text-[10px] text-zinc-200 font-medium truncate w-full">
                    {item.title}
                  </span>
                </div>
              </div>
            );
          })}

          {/* "..." Button opening full history drawer matching screenshot */}
          <button
            id="history-more-btn"
            onClick={onOpenAllHistory}
            className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800/80 flex items-center justify-center text-zinc-400 hover:text-zinc-200 transition-all shrink-0 cursor-pointer"
            title="Browse full generation library"
          >
            <MoreHorizontal className="w-6 h-6" />
          </button>
        </div>
      </div>
    </main>
  );
};
