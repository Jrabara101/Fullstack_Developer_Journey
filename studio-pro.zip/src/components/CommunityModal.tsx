import React, { useState } from "react";
import { 
  X, 
  Search, 
  GitFork, 
  Heart, 
  Sparkles, 
  Layers, 
  Copy, 
  Check, 
  ExternalLink,
  ShieldCheck
} from "lucide-react";
import { GeneratedImage } from "../types";

interface CommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: GeneratedImage[];
  onForkAndRemix: (item: GeneratedImage) => void;
  onLikeItem: (id: string) => void;
}

export const CommunityModal: React.FC<CommunityModalProps> = ({
  isOpen,
  onClose,
  items,
  onForkAndRemix,
  onLikeItem,
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStyleFilter, setSelectedStyleFilter] = useState("All");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const styles = ["All", "Cyberpunk", "Macro", "Cinematic", "Abstract", "3D Render", "Anime"];

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.prompt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStyle = selectedStyleFilter === "All" || item.style.toLowerCase() === selectedStyleFilter.toLowerCase();
    return matchesSearch && matchesStyle;
  });

  const handleCopyPrompt = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in-50 duration-200">
      <div className="w-full max-w-5xl max-h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-zinc-100">Community Explore & Remix</h2>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Inspect generation recipes, seeds, CFG parameters and 1-click Fork into your studio.
            </p>
          </div>
          <button
            id="close-community-modal-btn"
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Style Filter Bar */}
        <div className="p-4 border-b border-zinc-800/80 bg-zinc-950/80 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search prompts, seeds, creators..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-xl bg-zinc-900 border border-zinc-800 pl-9 pr-3 py-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {styles.map((st) => (
              <button
                key={st}
                onClick={() => setSelectedStyleFilter(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all shrink-0 cursor-pointer ${
                  selectedStyleFilter === st
                    ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/50"
                    : "bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-zinc-200"
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Community Grid */}
        <div className="flex-1 overflow-y-auto p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 transition-all duration-200 overflow-hidden flex flex-col group shadow-lg"
            >
              {/* Image Preview */}
              <div className="relative aspect-video bg-black overflow-hidden">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-zinc-300 border border-zinc-700/60">
                  {item.model}
                </div>
                <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[10px] text-zinc-300 border border-zinc-700/60 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Commercial
                </div>
              </div>

              {/* Recipe & Details Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <img
                        src={item.authorAvatar}
                        alt={item.author}
                        referrerPolicy="no-referrer"
                        className="w-5 h-5 rounded-full object-cover"
                      />
                      <span className="text-xs font-semibold text-zinc-200">{item.author}</span>
                    </div>
                    <span className="text-[10px] text-zinc-500 font-mono">Seed: {item.seed}</span>
                  </div>

                  <p className="text-xs text-zinc-300 line-clamp-2 leading-relaxed">
                    {item.prompt}
                  </p>
                </div>

                {/* Recipe Parameter Pills */}
                <div className="flex flex-wrap gap-1.5 text-[10px] font-mono text-zinc-400">
                  <span className="bg-zinc-800/80 px-2 py-0.5 rounded border border-zinc-700/40">
                    CFG: {item.guidanceScale}
                  </span>
                  <span className="bg-zinc-800/80 px-2 py-0.5 rounded border border-zinc-700/40">
                    Steps: {item.steps}
                  </span>
                  <span className="bg-zinc-800/80 px-2 py-0.5 rounded border border-zinc-700/40">
                    {item.aspectRatio}
                  </span>
                  <span className="bg-zinc-800/80 px-2 py-0.5 rounded border border-zinc-700/40">
                    {item.style}
                  </span>
                </div>

                {/* Actions Footer */}
                <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-3 text-xs text-zinc-400">
                    <button
                      onClick={() => onLikeItem(item.id)}
                      className="flex items-center gap-1 hover:text-pink-400 transition-colors cursor-pointer"
                    >
                      <Heart className="w-3.5 h-3.5 fill-pink-500/20 text-pink-400" />
                      <span>{item.likes}</span>
                    </button>
                    <button
                      onClick={() => handleCopyPrompt(item.id, item.prompt)}
                      className="flex items-center gap-1 hover:text-zinc-200 transition-colors cursor-pointer"
                      title="Copy exact prompt"
                    >
                      {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      onForkAndRemix(item);
                      onClose();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white border border-indigo-500/50 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <GitFork className="w-3.5 h-3.5" />
                    <span>Fork & Remix</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
