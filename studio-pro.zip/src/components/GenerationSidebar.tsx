import React, { useState } from "react";
import { 
  Sparkles, 
  Sliders, 
  Layers, 
  Square, 
  RectangleHorizontal, 
  RectangleVertical, 
  Lock, 
  Unlock, 
  Shuffle, 
  ChevronDown, 
  ChevronUp, 
  Loader2,
  HelpCircle,
  Cpu,
  Palette,
  Maximize2
} from "lucide-react";
import { ActiveTab, AspectRatioKey, ModelOption, StyleOption } from "../types";
import { AVAILABLE_MODELS, STYLE_OPTIONS, ASPECT_RATIOS } from "../data/presets";

interface GenerationSidebarProps {
  prompt: string;
  setPrompt: (p: string) => void;
  negativePrompt: string;
  setNegativePrompt: (np: string) => void;
  selectedModel: ModelOption;
  setSelectedModel: (m: ModelOption) => void;
  selectedStyle: StyleOption;
  setSelectedStyle: (s: StyleOption) => void;
  selectedAspectRatio: AspectRatioKey;
  setSelectedAspectRatio: (ar: AspectRatioKey) => void;
  seed: number;
  setSeed: (s: number) => void;
  steps: number;
  setSteps: (st: number) => void;
  guidanceScale: number;
  setGuidanceScale: (gs: number) => void;
  sampler: string;
  setSampler: (sm: string) => void;
  isPrivate: boolean;
  setIsPrivate: (ip: boolean) => void;
  onGenerate: () => void;
  isGenerating: boolean;
  onEnhancePrompt: () => void;
  isEnhancing: boolean;
}

export const GenerationSidebar: React.FC<GenerationSidebarProps> = ({
  prompt,
  setPrompt,
  negativePrompt,
  setNegativePrompt,
  selectedModel,
  setSelectedModel,
  selectedStyle,
  setSelectedStyle,
  selectedAspectRatio,
  setSelectedAspectRatio,
  seed,
  setSeed,
  steps,
  setSteps,
  guidanceScale,
  setGuidanceScale,
  sampler,
  setSampler,
  isPrivate,
  setIsPrivate,
  onGenerate,
  isGenerating,
  onEnhancePrompt,
  isEnhancing,
}) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>("Models");
  const [showAdvanced, setShowAdvanced] = useState(false);

  const randomizeSeed = () => {
    setSeed(Math.floor(Math.random() * 100000000));
  };

  return (
    <aside className="w-full lg:w-96 xl:w-[410px] bg-[#0d0e12] border-r border-zinc-800/80 flex flex-col h-[calc(100vh-4rem)] overflow-y-auto shrink-0 select-none">
      <div className="p-5 flex-1 space-y-5">
        {/* Header matching screenshot */}
        <div>
          <h1 className="text-xl font-bold text-zinc-100 tracking-tight flex items-center justify-between">
            Generation Studio
          </h1>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse ring-4 ring-emerald-500/20" />
            <span className="text-xs font-medium text-zinc-400">AI Engine Active</span>
          </div>
        </div>

        {/* Tab Navigation Pill Group matching screenshot */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-zinc-900/90 rounded-xl border border-zinc-800/80">
          <button
            id="tab-models-btn"
            onClick={() => setActiveTab("Models")}
            className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              activeTab === "Models"
                ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40"
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Models</span>
          </button>
          <button
            id="tab-styles-btn"
            onClick={() => setActiveTab("Styles")}
            className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              activeTab === "Styles"
                ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40"
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Styles</span>
          </button>
          <button
            id="tab-layout-btn"
            onClick={() => setActiveTab("Layout")}
            className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              activeTab === "Layout"
                ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 shadow-sm"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40"
            }`}
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span>Layout</span>
          </button>
        </div>

        {/* Tab specific context banner if Models or Layout selected */}
        {activeTab === "Models" && (
          <div className="p-2.5 rounded-lg bg-zinc-900/60 border border-zinc-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-400" />
              <span className="font-medium text-zinc-200">{selectedModel.name}</span>
            </div>
            <span className="text-[11px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              ⚡ {selectedModel.creditCost} Credits
            </span>
          </div>
        )}

        {/* PROMPT section matching screenshot */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label htmlFor="prompt-input" className="text-xs font-semibold tracking-wider text-zinc-400 uppercase">
              Prompt
            </label>
            <button
              id="prompt-enhance-btn"
              onClick={onEnhancePrompt}
              disabled={isEnhancing || !prompt.trim()}
              className={`flex items-center gap-1 text-xs font-medium transition-colors cursor-pointer ${
                isEnhancing
                  ? "text-indigo-400 animate-pulse"
                  : prompt.trim()
                  ? "text-indigo-400 hover:text-indigo-300"
                  : "text-zinc-600 cursor-not-allowed"
              }`}
              title="Enhance prompt with Gemini LLM (adds lighting, cinematic camera & detail keywords)"
            >
              {isEnhancing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Enhancing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Enhance</span>
                </>
              )}
            </button>
          </div>
          <div className="relative">
            <textarea
              id="prompt-input"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                  e.preventDefault();
                  if (!isGenerating && prompt.trim()) {
                    onGenerate();
                  }
                }
              }}
              placeholder="Describe the image you want to create in vivid detail..."
              rows={4}
              className="w-full rounded-xl bg-zinc-900/90 border border-zinc-800 px-3.5 py-3 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-indigo-500/80 focus:ring-1 focus:ring-indigo-500/50 resize-none transition-all"
            />
          </div>
        </div>

        {/* NEGATIVE PROMPT section matching screenshot */}
        <div className="space-y-2">
          <label htmlFor="negative-prompt-input" className="text-xs font-semibold tracking-wider text-zinc-400 uppercase">
            Negative Prompt
          </label>
          <textarea
            id="negative-prompt-input"
            value={negativePrompt}
            onChange={(e) => setNegativePrompt(e.target.value)}
            placeholder="Elements to exclude..."
            rows={2}
            className="w-full rounded-xl bg-zinc-900/90 border border-zinc-800 px-3.5 py-2.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500/80 focus:ring-1 focus:ring-indigo-500/50 resize-none transition-all"
          />
        </div>

        {/* STYLE AESTHETIC pills matching screenshot */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold tracking-wider text-zinc-400 uppercase">
              Style Aesthetic
            </label>
            <span className="text-[11px] text-zinc-500">{selectedStyle.name}</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {STYLE_OPTIONS.map((style) => {
              const isSelected = selectedStyle.id === style.id;
              return (
                <button
                  key={style.id}
                  id={`style-pill-${style.id}`}
                  onClick={() => setSelectedStyle(style)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer select-none ${
                    isSelected
                      ? "bg-zinc-800 text-zinc-100 border border-indigo-500/80 shadow-sm shadow-indigo-500/10 ring-1 ring-indigo-500/50"
                      : "bg-zinc-900/90 text-zinc-400 border border-zinc-800/90 hover:text-zinc-200 hover:border-zinc-700"
                  }`}
                >
                  {style.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* ASPECT RATIO buttons matching screenshot */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold tracking-wider text-zinc-400 uppercase">
              Aspect Ratio
            </label>
            <span className="text-[11px] text-zinc-500">
              {ASPECT_RATIOS.find((r) => r.key === selectedAspectRatio)?.ratio}
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {ASPECT_RATIOS.map((item) => {
              const isSelected = selectedAspectRatio === item.key;
              return (
                <button
                  key={item.key}
                  id={`aspect-ratio-btn-${item.key.replace(":", "-")}`}
                  onClick={() => setSelectedAspectRatio(item.key)}
                  className={`flex flex-col items-center justify-center p-2 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? "bg-indigo-600/20 border-indigo-500/90 text-indigo-300 ring-1 ring-indigo-500/40 shadow-sm"
                      : "bg-zinc-900/90 border-zinc-800/90 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700"
                  }`}
                >
                  {/* Geometric visual icon representing exact ratio */}
                  <div className="h-6 flex items-center justify-center mb-1">
                    {item.key === "1:1" && (
                      <div className={`w-4 h-4 rounded-xs border-2 ${isSelected ? "border-indigo-400" : "border-zinc-500"}`} />
                    )}
                    {item.key === "4:3" && (
                      <div className={`w-5 h-3.5 rounded-xs border-2 ${isSelected ? "border-indigo-400" : "border-zinc-500"}`} />
                    )}
                    {item.key === "3:2" && (
                      <div className={`w-5 h-3.2 rounded-xs border-2 ${isSelected ? "border-indigo-400" : "border-zinc-500"}`} />
                    )}
                    {item.key === "16:9" && (
                      <div className={`w-6 h-3 rounded-xs border-2 ${isSelected ? "border-indigo-400" : "border-zinc-500"}`} />
                    )}
                    {item.key === "9:16" && (
                      <div className={`w-3 h-5.5 rounded-xs border-2 ${isSelected ? "border-indigo-400" : "border-zinc-500"}`} />
                    )}
                  </div>
                  <span className="text-[11px] font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Advanced Accordion (Model Selector, Seed, Steps, Guidance Scale) */}
        <div className="pt-2 border-t border-zinc-800/80">
          <button
            id="toggle-advanced-accordion"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full flex items-center justify-between text-xs font-semibold text-zinc-400 hover:text-zinc-200 transition-colors py-1 cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5" />
              Advanced Parameters
            </span>
            {showAdvanced ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {showAdvanced && (
            <div className="space-y-4 pt-3 mt-2 text-xs animate-in fade-in-50 duration-200">
              {/* Model Selector Dropdown */}
              <div className="space-y-1.5">
                <label className="text-zinc-400 font-medium flex items-center justify-between">
                  <span>AI Diffusion Engine</span>
                  <span className="text-[11px] text-indigo-400">{selectedModel.badge}</span>
                </label>
                <select
                  id="model-selector-dropdown"
                  value={selectedModel.id}
                  onChange={(e) => {
                    const found = AVAILABLE_MODELS.find((m) => m.id === e.target.value);
                    if (found) setSelectedModel(found);
                  }}
                  className="w-full rounded-xl bg-zinc-900 border border-zinc-800 px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
                >
                  {AVAILABLE_MODELS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} (⚡ {m.creditCost} Credits)
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-zinc-500">{selectedModel.description}</p>
              </div>

              {/* Seed Control */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-400 font-medium">Seed</label>
                  <button
                    onClick={randomizeSeed}
                    className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                  >
                    <Shuffle className="w-3 h-3" />
                    Randomize
                  </button>
                </div>
                <input
                  type="number"
                  value={seed}
                  onChange={(e) => setSeed(parseInt(e.target.value) || 0)}
                  className="w-full rounded-xl bg-zinc-900 border border-zinc-800 px-3 py-1.5 text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* CFG Guidance Scale Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-400 font-medium">Guidance Scale (CFG)</label>
                  <span className="text-zinc-200 font-mono">{guidanceScale.toFixed(1)}</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={20}
                  step={0.5}
                  value={guidanceScale}
                  onChange={(e) => setGuidanceScale(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>Creative (3.0)</span>
                  <span>Balanced (7.5)</span>
                  <span>Strict (15.0)</span>
                </div>
              </div>

              {/* Inference Steps Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-400 font-medium">Inference Steps</label>
                  <span className="text-zinc-200 font-mono">{steps}</span>
                </div>
                <input
                  type="range"
                  min={20}
                  max={50}
                  step={1}
                  value={steps}
                  onChange={(e) => setSteps(parseInt(e.target.value))}
                  className="w-full accent-indigo-500 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
                />
              </div>

              {/* Sampler Selector */}
              <div className="space-y-1.5">
                <label className="text-zinc-400 font-medium">Sampler Scheduler</label>
                <select
                  value={sampler}
                  onChange={(e) => setSampler(e.target.value)}
                  className="w-full rounded-xl bg-zinc-900 border border-zinc-800 px-3 py-1.5 text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="Euler a">Euler a (Ancestral)</option>
                  <option value="DPM++ 2M Karras">DPM++ 2M Karras</option>
                  <option value="DPM++ SDE">DPM++ SDE</option>
                  <option value="DDIM">DDIM</option>
                  <option value="Euler">Euler</option>
                </select>
              </div>

              {/* Private Generation Toggle */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  {isPrivate ? <Lock className="w-3.5 h-3.5 text-indigo-400" /> : <Unlock className="w-3.5 h-3.5 text-zinc-500" />}
                  <div>
                    <p className="text-xs font-medium text-zinc-200">Private Generation</p>
                    <p className="text-[10px] text-zinc-500">Hide from community explore feed</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={isPrivate}
                  onChange={(e) => setIsPrivate(e.target.checked)}
                  className="w-4 h-4 accent-indigo-600 rounded bg-zinc-900 border-zinc-700 cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Big CTA Generate Button matching screenshot */}
      <div className="p-4 border-t border-zinc-800/80 bg-[#0d0e12] sticky bottom-0 z-10">
        <button
          id="generate-button"
          onClick={onGenerate}
          disabled={isGenerating || !prompt.trim()}
          className={`w-full py-3.5 px-4 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg cursor-pointer ${
            isGenerating
              ? "bg-indigo-600/50 text-indigo-200 animate-pulse cursor-wait"
              : prompt.trim()
              ? "bg-gradient-to-r from-indigo-500 via-indigo-600 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white shadow-indigo-900/40 hover:shadow-indigo-600/30 hover:scale-[1.01] active:scale-[0.99]"
              : "bg-zinc-800 text-zinc-500 cursor-not-allowed"
          }`}
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Generating Neural Latents...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-indigo-200 fill-indigo-200/40" />
              <span>Generate ({selectedModel.creditCost} Credits)</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
};
