import React from "react";
import { 
  X, 
  Zap, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  HelpCircle,
  TrendingUp,
  Cpu,
  Layers
} from "lucide-react";
import confetti from "canvas-confetti";
import { CREDIT_PACKAGES } from "../data/presets";
import { CreditPackage } from "../types";

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCredits: number;
  onAddCredits: (amount: number, packageName: string) => void;
}

export const PricingModal: React.FC<PricingModalProps> = ({
  isOpen,
  onClose,
  currentCredits,
  onAddCredits,
}) => {
  if (!isOpen) return null;

  const handlePurchase = (pkg: CreditPackage) => {
    // Trigger celebratory confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#6366f1", "#a855f7", "#38bdf8", "#fbbf24"],
    });

    onAddCredits(pkg.credits, pkg.name);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in-50 duration-200">
      <div className="w-full max-w-4xl max-h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400 fill-amber-400" />
              <h2 className="text-xl font-bold text-zinc-100">Studio Pro Compute & Pricing</h2>
            </div>
            <p className="text-xs text-zinc-400 mt-1">
              Transparent credit-based compute abstraction. Zero rate limits, priority GPU queue.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
              Current: ⚡ {currentCredits} Credits
            </div>
            <button
              id="close-pricing-modal-btn"
              onClick={onClose}
              className="p-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Blueprint Unit Economics Card */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-950/40 via-purple-950/30 to-zinc-900 border border-indigo-500/20 text-xs">
            <div className="flex items-center gap-2 text-indigo-300 font-semibold mb-2">
              <TrendingUp className="w-4 h-4" />
              <span>Token Economics & Transparent Cost Structure</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-zinc-300">
              <div className="p-2.5 rounded-lg bg-zinc-900/80 border border-zinc-800/80">
                <span className="text-zinc-500 block text-[10px] uppercase font-mono">1 Credit</span>
                <span className="font-semibold text-zinc-200">SDXL & Fast Models</span>
                <p className="text-[11px] text-zinc-400 mt-0.5">High throughput open weights</p>
              </div>
              <div className="p-2.5 rounded-lg bg-zinc-900/80 border border-zinc-800/80">
                <span className="text-zinc-500 block text-[10px] uppercase font-mono">2 Credits</span>
                <span className="font-semibold text-zinc-200">Flux Dev & Imagen 3</span>
                <p className="text-[11px] text-zinc-400 mt-0.5">Deep photorealism & prompt lock</p>
              </div>
              <div className="p-2.5 rounded-lg bg-zinc-900/80 border border-zinc-800/80">
                <span className="text-zinc-500 block text-[10px] uppercase font-mono">3 Credits</span>
                <span className="font-semibold text-zinc-200">Flux Pro Ultra (1.1)</span>
                <p className="text-[11px] text-zinc-400 mt-0.5">Unmatched 4K HDR fidelity</p>
              </div>
            </div>
          </div>

          {/* Pricing Tiers Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {CREDIT_PACKAGES.map((pkg) => (
              <div
                key={pkg.id}
                className={`rounded-2xl p-5 border flex flex-col justify-between relative transition-all duration-200 ${
                  pkg.popular
                    ? "bg-zinc-900 border-indigo-500 ring-1 ring-indigo-500/50 shadow-xl shadow-indigo-950/30"
                    : "bg-zinc-900/70 border-zinc-800 hover:border-zinc-700"
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-0.5 rounded-full shadow-md">
                    {pkg.discountBadge}
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-base font-bold text-zinc-100">{pkg.name}</h3>
                    {!pkg.popular && pkg.discountBadge && (
                      <span className="text-[10px] font-semibold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                        {pkg.discountBadge}
                      </span>
                    )}
                  </div>

                  <div className="flex items-baseline gap-1.5 my-3">
                    <span className="text-3xl font-extrabold text-zinc-100">{pkg.price}</span>
                    <span className="text-xs text-zinc-400">/ one-time</span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold mb-4 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
                    <Zap className="w-3.5 h-3.5 fill-amber-400" />
                    <span>⚡ +{pkg.credits.toLocaleString()} Credits</span>
                    <span className="text-zinc-500 ml-auto font-mono text-[10px]">{pkg.pricePerCredit}</span>
                  </div>

                  <ul className="space-y-2 text-xs text-zinc-300 mb-6">
                    {pkg.features.map((feat, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  id={`purchase-btn-${pkg.id}`}
                  onClick={() => handlePurchase(pkg)}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    pkg.popular
                      ? "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30"
                      : "bg-zinc-800 hover:bg-zinc-700 text-zinc-200"
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Top Up {pkg.credits} Credits</span>
                </button>
              </div>
            ))}
          </div>

          {/* Trust & Commercial Usage Footer */}
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-zinc-400">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Full commercial ownership included on all tiers. EXIF recipes auto-embedded.</span>
            </div>
            <div className="text-zinc-500 text-[11px]">
              Refund guarantee on any safety moderation refusal.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
