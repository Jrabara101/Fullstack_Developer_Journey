import React, { useState } from "react";
import { 
  X, 
  Copy, 
  Check, 
  GitFork, 
  Download, 
  ShieldCheck, 
  Cpu, 
  Code, 
  Sliders, 
  Sparkles,
  Clock
} from "lucide-react";
import { GeneratedImage } from "../types";

interface RecipeInspectorModalProps {
  image: GeneratedImage | null;
  isOpen: boolean;
  onClose: () => void;
  onForkAndRemix: (img: GeneratedImage) => void;
}

export const RecipeInspectorModal: React.FC<RecipeInspectorModalProps> = ({
  image,
  isOpen,
  onClose,
  onForkAndRemix,
}) => {
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);

  if (!isOpen || !image) return null;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(image.prompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  const handleCopyJson = () => {
    const jsonRecipe = JSON.stringify(image, null, 2);
    navigator.clipboard.writeText(jsonRecipe);
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in-50 duration-200">
      <div className="w-full max-w-3xl max-h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div>
            <div className="flex items-center gap-2">
              <Code className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-zinc-100 font-mono uppercase tracking-wider">
                Recipe & Parameter Inspector
              </h2>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Exact generative parameters, latents & diffusion seeds for reproduceable output.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Image preview & Top meta */}
          <div className="flex flex-col sm:flex-row gap-4 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 items-center">
            <img
              src={image.imageUrl}
              alt={image.title}
              referrerPolicy="no-referrer"
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-lg object-cover border border-zinc-700 shrink-0"
            />
            <div className="flex-1 min-w-0 space-y-1.5 text-xs">
              <h3 className="font-bold text-zinc-100 text-sm">{image.title}</h3>
              <div className="flex flex-wrap gap-2 text-[11px] text-zinc-400">
                <span className="flex items-center gap-1 text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20 font-medium">
                  <Cpu className="w-3 h-3" /> {image.model}
                </span>
                <span className="flex items-center gap-1 text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  <ShieldCheck className="w-3 h-3" /> Commercial License CC0
                </span>
                {image.generationTimeMs && (
                  <span className="flex items-center gap-1 text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded">
                    <Clock className="w-3 h-3" /> {(image.generationTimeMs / 1000).toFixed(1)}s render
                  </span>
                )}
              </div>
              <p className="text-[11px] text-zinc-500">Created {image.createdAt} by {image.author}</p>
            </div>
          </div>

          {/* Prompt Breakdown */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">Prompt</span>
              <button
                onClick={handleCopyPrompt}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
              >
                {copiedPrompt ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedPrompt ? "Copied" : "Copy Prompt"}</span>
              </button>
            </div>
            <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 leading-relaxed font-mono selection:bg-indigo-500/30">
              {image.prompt}
            </div>
          </div>

          {/* Negative Prompt */}
          {image.negativePrompt && (
            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">Negative Prompt</span>
              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-400 font-mono">
                {image.negativePrompt}
              </div>
            </div>
          )}

          {/* Key Parameters Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase font-mono">Seed</span>
              <span className="font-mono font-bold text-zinc-200">{image.seed}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase font-mono">CFG Scale</span>
              <span className="font-mono font-bold text-zinc-200">{image.guidanceScale.toFixed(1)}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase font-mono">Inference Steps</span>
              <span className="font-mono font-bold text-zinc-200">{image.steps}</span>
            </div>
            <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase font-mono">Sampler</span>
              <span className="font-mono font-bold text-zinc-200 truncate">{image.sampler}</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/60 flex items-center justify-between gap-3">
          <button
            onClick={handleCopyJson}
            className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copiedJson ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedJson ? "Copied JSON" : "Copy Recipe JSON"}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onForkAndRemix(image);
                onClose();
              }}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
            >
              <GitFork className="w-3.5 h-3.5" />
              <span>Load Parameters Into Studio</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
