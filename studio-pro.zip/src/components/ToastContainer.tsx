import React from "react";
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from "lucide-react";
import { ToastMessage } from "../types";

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`pointer-events-auto p-3.5 rounded-xl border shadow-2xl flex items-start gap-3 animate-in slide-in-from-bottom-3 fade-in duration-200 backdrop-blur-md ${
            toast.type === "success"
              ? "bg-zinc-950/95 border-emerald-500/40 text-emerald-300"
              : toast.type === "error"
              ? "bg-zinc-950/95 border-rose-500/40 text-rose-300"
              : toast.type === "warning"
              ? "bg-zinc-950/95 border-amber-500/40 text-amber-300"
              : "bg-zinc-950/95 border-indigo-500/40 text-indigo-300"
          }`}
        >
          {toast.type === "success" && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />}
          {toast.type === "error" && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />}
          {toast.type === "warning" && <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />}
          {toast.type === "info" && <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />}

          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-semibold text-zinc-100">{toast.title}</h4>
            <p className="text-[11px] text-zinc-300 mt-0.5 leading-relaxed">{toast.message}</p>
            {toast.refunded && (
              <span className="inline-block mt-1 text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                ⚡ Credits Auto-Refunded
              </span>
            )}
          </div>

          <button
            onClick={() => onDismiss(toast.id)}
            className="text-zinc-500 hover:text-zinc-300 transition-colors p-0.5 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
