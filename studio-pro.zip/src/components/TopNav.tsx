import React, { useState } from "react";
import { Sparkles, Zap, Bell, Check, ShieldCheck, Database, Info } from "lucide-react";

interface TopNavProps {
  credits: number;
  onOpenPricing: () => void;
  onOpenCommunity: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  credits,
  onOpenPricing,
  onOpenCommunity,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const notifications = [
    { id: "1", title: "Render Completed", text: "NEON CITYSCAPE (8K HDR) rendered in 2.4s", time: "Just now", unread: true },
    { id: "2", title: "Prompt Enhanced", text: "Cyberpunk aesthetic expansion applied via Gemini 3.7", time: "5m ago", unread: false },
    { id: "3", title: "Free Credits Granted", text: "Daily compute bonus +15 credits loaded", time: "2h ago", unread: false },
  ];

  return (
    <header className="h-16 border-b border-zinc-800/80 bg-[#0d0e12]/95 backdrop-blur-md px-4 md:px-6 flex items-center justify-between sticky top-0 z-40">
      {/* Brand Logo matching screenshot */}
      <div className="flex items-center gap-6">
        <div 
          id="brand-logo-btn"
          className="flex items-center gap-2.5 cursor-pointer select-none group"
        >
          <div className="w-8 h-8 rounded-lg bg-zinc-800/90 border border-zinc-700/60 flex items-center justify-center text-zinc-200 group-hover:border-indigo-500/60 group-hover:text-indigo-400 transition-colors shadow-inner">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="text-base font-semibold tracking-tight text-zinc-100 flex items-center gap-1.5">
            Studio Pro
          </span>
        </div>

        {/* Center / Navigation Links matching screenshot */}
        <nav className="hidden sm:flex items-center gap-6 text-sm font-medium">
          <button
            id="nav-community-link"
            onClick={onOpenCommunity}
            className="text-zinc-400 hover:text-zinc-100 transition-colors cursor-pointer"
          >
            Community
          </button>
          <button
            id="nav-pricing-link"
            onClick={onOpenPricing}
            className="text-zinc-400 hover:text-zinc-100 transition-colors cursor-pointer"
          >
            Pricing
          </button>
        </nav>
      </div>

      {/* Right Controls matching screenshot */}
      <div className="flex items-center gap-3.5">
        {/* Credits Pill with Gold/Amber Lightning Icon */}
        <button
          id="top-credits-pill"
          onClick={onOpenPricing}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 hover:border-amber-400/50 transition-all text-xs font-semibold tracking-wide cursor-pointer shadow-sm shadow-amber-950/20"
          title="Click to top-up credits & view pricing breakdown"
        >
          <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span>{credits} Credits</span>
        </button>

        {/* Notifications Icon with Unread Indicator */}
        <div className="relative">
          <button
            id="top-bell-btn"
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowUserMenu(false);
            }}
            className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 transition-colors cursor-pointer relative"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-indigo-500 ring-2 ring-[#0d0e12]" />
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl bg-zinc-900 border border-zinc-800 shadow-2xl p-3 z-50 animate-in fade-in-50 slide-in-from-top-2 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-800 px-1">
                <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">Notifications</span>
                <span className="text-[11px] text-indigo-400 hover:underline cursor-pointer">Mark all read</span>
              </div>
              <div className="divide-y divide-zinc-800/60 mt-1">
                {notifications.map((n) => (
                  <div key={n.id} className="py-2.5 px-1 hover:bg-zinc-800/40 rounded-lg transition-colors">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-zinc-200">{n.title}</span>
                      <span className="text-[10px] text-zinc-500">{n.time}</span>
                    </div>
                    <p className="text-[11px] text-zinc-400 mt-0.5">{n.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Avatar with custom drop menu */}
        <div className="relative">
          <button
            id="top-user-avatar-btn"
            onClick={() => {
              setShowUserMenu(!showUserMenu);
              setShowNotifications(false);
            }}
            className="w-8 h-8 rounded-full overflow-hidden border border-zinc-700/80 hover:border-indigo-500/80 transition-all cursor-pointer ring-1 ring-black/40"
            aria-label="User Account Menu"
          >
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
              alt="User Avatar"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </button>

          {/* User Menu Dropdown */}
          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-64 rounded-xl bg-zinc-900 border border-zinc-800 shadow-2xl p-3 z-50 animate-in fade-in-50 slide-in-from-top-2 duration-150">
              <div className="flex items-center gap-3 pb-3 border-b border-zinc-800 px-1">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                  alt="User Avatar"
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover border border-zinc-700"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-zinc-100 truncate">Studio Pro Creator</p>
                  <p className="text-[11px] text-zinc-400 truncate">Pro Tier • ⚡ {credits} credits</p>
                </div>
              </div>

              <div className="py-2 space-y-1 text-xs">
                <div className="flex items-center justify-between px-2 py-1.5 rounded-md text-zinc-300 hover:bg-zinc-800/60 cursor-pointer" onClick={onOpenPricing}>
                  <span className="flex items-center gap-2">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    Manage Subscription
                  </span>
                  <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-500/30">Pro</span>
                </div>
                <div className="flex items-center justify-between px-2 py-1.5 rounded-md text-zinc-300 hover:bg-zinc-800/60 cursor-pointer">
                  <span className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Commercial License
                  </span>
                  <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">
                    <Check className="w-2.5 h-2.5" /> Active
                  </span>
                </div>
                <div className="flex items-center justify-between px-2 py-1.5 rounded-md text-zinc-300 hover:bg-zinc-800/60 cursor-pointer">
                  <span className="flex items-center gap-2">
                    <Database className="w-3.5 h-3.5 text-zinc-400" />
                    Local Storage Cache
                  </span>
                  <span className="text-[10px] text-zinc-400">Persistent</span>
                </div>
              </div>

              <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-[11px] text-zinc-500 px-1">
                <span>Studio Pro v2.4</span>
                <span className="text-zinc-400 hover:text-zinc-200 cursor-pointer flex items-center gap-1">
                  <Info className="w-3 h-3" /> Docs
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
