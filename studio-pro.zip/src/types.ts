export type AspectRatioKey = "1:1" | "4:3" | "3:2" | "16:9" | "9:16" | "3:4";

export interface ModelOption {
  id: string;
  name: string;
  badge: string;
  description: string;
  creditCost: number;
  provider: string;
  maxResolution: string;
  isPro?: boolean;
  commercialAllowed: boolean;
}

export interface StyleOption {
  id: string;
  name: string;
  description: string;
  promptTag: string;
}

export interface GeneratedImage {
  id: string;
  title: string;
  prompt: string;
  negativePrompt: string;
  model: string;
  style: string;
  aspectRatio: AspectRatioKey;
  seed: number;
  steps: number;
  guidanceScale: number;
  sampler: string;
  isPrivate: boolean;
  author: string;
  authorAvatar: string;
  likes: number;
  remixes: number;
  imageUrl: string;
  createdAt: string;
  commercialUse: boolean;
  generationSource?: string;
  generationTimeMs?: number;
}

export type ActiveTab = "Models" | "Styles" | "Layout";

export interface CreditPackage {
  id: string;
  name: string;
  credits: number;
  price: string;
  pricePerCredit: string;
  discountBadge?: string;
  popular?: boolean;
  features: string[];
}

export interface ToastMessage {
  id: string;
  type: "success" | "error" | "info" | "warning";
  title: string;
  message: string;
  refunded?: boolean;
}
