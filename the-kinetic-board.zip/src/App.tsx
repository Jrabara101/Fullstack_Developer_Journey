import React from 'react';
import { useBoardStore } from './store/useBoardStore';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { SubHeader } from './components/SubHeader';
import { KanbanBoard } from './components/KanbanBoard';
import { ListView } from './components/ListView';
import { StatsView } from './components/StatsView';
import { RoadmapView } from './components/RoadmapView';
import { TaskInspector } from './components/TaskInspector';
import { NewTaskModal } from './components/NewTaskModal';
import { MetricsModal } from './components/MetricsModal';

export default function App() {
  const { activeView, isInspectorOpen } = useBoardStore();

  return (
    <div className="min-h-screen bg-[#131315] text-[#e5e1e4] flex font-sans selection:bg-[#06b6d4] selection:text-[#00424f]">
      {/* Left Fixed Navigation Rail */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="pl-20 min-h-screen flex-1 flex flex-col w-full overflow-x-hidden">
        {/* Top Fixed Header */}
        <Header />

        {/* Sub-Header Bar */}
        <main className="relative pt-16 flex-1 w-full bg-[#131315] flex flex-col">
          <SubHeader />

          {/* Active View Routing */}
          <div className="flex-1 flex flex-col overflow-y-auto">
            {activeView === 'board' && <KanbanBoard />}
            {activeView === 'list' && <ListView />}
            {activeView === 'stats' && <StatsView />}
            {activeView === 'map' && <RoadmapView />}
          </div>
        </main>
      </div>

      {/* Slide-out Task Inspector Sheet */}
      <TaskInspector />

      {/* Modal Dialogs */}
      <NewTaskModal />
      <MetricsModal />
    </div>
  );
}

