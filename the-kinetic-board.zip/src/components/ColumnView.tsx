import React from 'react';
import { useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { Column, Task } from '../types';
import { TaskCard } from './TaskCard';
import { useBoardStore } from '../store/useBoardStore';
import { 
  Plus, 
  RefreshCw, 
  ShieldCheck, 
  CheckCircle2, 
  Archive, 
  FolderGit2, 
  Inbox
} from 'lucide-react';

interface ColumnViewProps {
  column: Column;
  tasks: Task[];
  onAddTask: (colId: Column['id']) => void;
}

export const ColumnView: React.FC<ColumnViewProps> = ({ column, tasks, onAddTask }) => {
  const { setNodeRef, isOver } = useDroppable({
    id: column.id,
    data: {
      type: 'column',
      columnId: column.id,
    },
  });

  // Pick suitable icon based on column
  const getColumnIcon = () => {
    switch (column.id) {
      case 'backlog':
        return <FolderGit2 className="w-4 h-4 text-[#869397]" />;
      case 'in_progress':
        return <RefreshCw className="w-4 h-4 text-[#4cd7f6] animate-spin" style={{ animationDuration: '6s' }} />;
      case 'review':
        return <ShieldCheck className="w-4 h-4 text-[#ffb690]" />;
      case 'deployed':
        return <CheckCircle2 className="w-4 h-4 text-[#4cd7f6]" />;
      default:
        return <FolderGit2 className="w-4 h-4 text-[#869397]" />;
    }
  };

  return (
    <div
      ref={setNodeRef}
      className={`w-80 flex-shrink-0 flex flex-col rounded-2xl bg-[#1c1b1d]/70 backdrop-blur-md p-3.5 shadow-lg border transition-colors duration-200 ${
        isOver
          ? 'border-[#4cd7f6] ring-2 ring-[#4cd7f6]/40 bg-[#201f22]/90'
          : column.id === 'in_progress'
          ? 'border-[#4cd7f6]/30 ring-1 ring-[#4cd7f6]/20'
          : 'border-[#3d494c]/30'
      }`}
    >
      {/* Column Header */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#3d494c]/20">
        <div className="flex items-center gap-2">
          {getColumnIcon()}
          <span className="font-semibold text-sm text-[#e5e1e4] tracking-wide">
            {column.title}
          </span>
          <span className={`px-2 py-0.5 rounded-full font-mono text-[11px] font-semibold ${column.badgeBg} ${column.badgeText}`}>
            {tasks.length}
          </span>
        </div>

        {/* Quick Add Button */}
        <button
          onClick={() => onAddTask(column.id)}
          className="w-7 h-7 rounded flex items-center justify-center text-[#869397] hover:text-[#4cd7f6] hover:bg-[#2a2a2c] transition-colors"
          title={`Add node to ${column.title}`}
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Cards Container with SortableContext */}
      <SortableContext items={tasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
        <div className="flex flex-col gap-2.5 min-h-[460px] flex-1">
          {tasks.map((task) => (
            <TaskCard key={task.id} task={task} />
          ))}

          {/* Empty state or column drop zone target */}
          {column.id === 'review' ? (
            <div className="h-24 rounded-lg border-2 border-dashed border-[#ec6a06]/40 bg-[#ec6a06]/5 flex flex-col items-center justify-center text-[#ffb690] font-mono text-[11px] tracking-wider uppercase transition-all">
              <Inbox className="w-5 h-5 mb-1 text-[#ffb690]" />
              <span>Drop for QA Audit</span>
            </div>
          ) : column.id === 'backlog' ? (
            <div className="h-20 rounded-lg border-2 border-dashed border-[#3d494c]/40 bg-[#1c1b1d]/40 flex items-center justify-center text-[#869397] font-mono text-[11px] tracking-wider uppercase opacity-60">
              Drop into Backlog
            </div>
          ) : tasks.length === 0 ? (
            <div className="h-24 rounded-lg border border-dashed border-[#3d494c]/40 flex items-center justify-center text-[#869397] font-mono text-xs">
              {column.dropPlaceholder}
            </div>
          ) : null}
        </div>
      </SortableContext>
    </div>
  );
};
