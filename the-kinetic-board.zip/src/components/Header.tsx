import React, { useEffect, useRef } from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { 
  Search, 
  Plus, 
  Bell, 
  User, 
  X, 
  Wifi, 
  WifiOff, 
  Clock, 
  RotateCcw,
  Sparkles
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    searchQuery,
    setSearchQuery,
    myTasksOnly,
    toggleMyTasks,
    highPriorityOnly,
    toggleHighPriority,
    dueSoonOnly,
    toggleDueSoon,
    setIsNewTaskModalOpen,
    netcode,
    toggleSimulateFailure,
    toggleSimulateLatency,
    rollbackMove
  } = useBoardStore();

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut listener for ⌘K / Ctrl+K and 'N' for new task
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
      if (
        e.key.toLowerCase() === 'n' && 
        !['input', 'textarea', 'select'].includes((e.target as HTMLElement).tagName.toLowerCase())
      ) {
        e.preventDefault();
        setIsNewTaskModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setIsNewTaskModalOpen]);

  return (
    <header className="fixed top-0 left-20 right-0 h-16 bg-[#0e0e10]/90 backdrop-blur-xl z-40 px-4 md:px-6 shadow-[0_1px_8px_rgba(0,0,0,0.4)] flex items-center justify-between border-b border-[#3d494c]/30">
      {/* Brand & Workspace breadcrumbs */}
      <div className="flex items-center gap-3 md:gap-5">
        <div className="flex items-center gap-1.5">
          <span className="font-bold text-[#4cd7f6] tracking-widest text-lg">KINETIC</span>
          <span className="font-mono text-xs text-[#869397] tracking-wider">// OS</span>
        </div>

        <div className="hidden md:flex items-center gap-1.5 text-[#bcc9cd] font-mono text-xs">
          <span className="text-[#869397]">/</span>
          <span className="hover:text-[#4cd7f6] cursor-pointer transition-colors">WORKSPACE</span>
          <span className="text-[#869397]">/</span>
          <span className="text-[#e5e1e4] font-semibold">CORE-ALPHA</span>
        </div>

        <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded bg-[#1c1b1d] border border-[#3d494c]/30">
          <div className="w-2 h-2 rounded-full bg-[#06b6d4] shadow-[0_0_8px_#06b6d4]"></div>
          <span className="font-mono text-xs text-[#4cd7f6] font-semibold tracking-wider uppercase">
            SPRINT 44
          </span>
          <span className="font-mono text-[10px] text-[#869397] font-normal">[DAY 8/14]</span>
        </div>
      </div>

      {/* Global Search with ⌘K */}
      <div className="flex-1 max-w-md mx-3 lg:mx-6">
        <div className="relative flex items-center">
          <Search className="absolute left-3 w-4 h-4 text-[#869397] pointer-events-none" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="⌘K Search entities, tags, commands..."
            className="w-full bg-[#1c1b1d] text-[#e5e1e4] font-sans text-xs md:text-sm pl-9 pr-8 py-1.5 rounded-lg placeholder-[#869397] outline-none border border-[#3d494c]/40 focus:border-[#4cd7f6] focus:bg-[#201f22] focus:ring-1 focus:ring-[#4cd7f6]/40 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 text-[#869397] hover:text-[#e5e1e4]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Quick Filters & Actions */}
      <div className="flex items-center gap-2.5 md:gap-3">
        {/* Netcode Simulation Controls (Interactive Game Engine Indicator) */}
        <div className="hidden xl:flex items-center gap-1.5 px-2 py-1 rounded bg-[#1c1b1d] border border-[#3d494c]/30">
          <button
            onClick={toggleSimulateFailure}
            title={netcode.simulateFailure ? "Simulated Network Reject: ENABLED (Next drop will rubber-band)" : "Simulated Network Reject: OFF"}
            className={`font-mono text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1 transition-colors ${
              netcode.simulateFailure
                ? 'bg-[#93000a] text-[#ffb4ab] border border-[#ffb4ab]/40 animate-pulse'
                : 'text-[#869397] hover:text-[#e5e1e4] hover:bg-[#2a2a2c]'
            }`}
          >
            {netcode.simulateFailure ? <WifiOff className="w-3 h-3" /> : <Wifi className="w-3 h-3" />}
            <span>{netcode.simulateFailure ? 'DROP-FAIL ON' : 'NETCODE: STABLE'}</span>
          </button>

          {netcode.isSyncing && (
            <span className="font-mono text-[10px] text-[#4cd7f6] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4cd7f6] animate-ping" />
              <span>SYNCING</span>
            </span>
          )}
        </div>

        {/* Quick Filter Buttons */}
        <div className="hidden xl:flex items-center gap-1.5">
          <button
            onClick={toggleMyTasks}
            className={`font-mono text-xs px-2 py-1 rounded transition-colors ${
              myTasksOnly
                ? 'bg-[#06b6d4] text-[#003640] font-semibold shadow-[0_0_8px_rgba(6,182,212,0.3)]'
                : 'bg-[#1c1b1d] text-[#bcc9cd] hover:bg-[#2a2a2c] hover:text-[#e5e1e4]'
            }`}
          >
            My Tasks
          </button>
          <button
            onClick={toggleHighPriority}
            className={`font-mono text-xs px-2 py-1 rounded transition-colors ${
              highPriorityOnly
                ? 'bg-[#ec6a06] text-[#341100] font-semibold shadow-[0_0_8px_rgba(236,106,6,0.3)]'
                : 'bg-[#1c1b1d] text-[#ffb690] hover:bg-[#2a2a2c] hover:text-[#e5e1e4]'
            }`}
          >
            High Priority
          </button>
          <button
            onClick={toggleDueSoon}
            className={`font-mono text-xs px-2 py-1 rounded transition-colors ${
              dueSoonOnly
                ? 'bg-[#93000a] text-[#ffdad6] font-semibold shadow-[0_0_8px_rgba(239,68,68,0.3)]'
                : 'bg-[#1c1b1d] text-[#ffb3ad] hover:bg-[#2a2a2c] hover:text-[#e5e1e4]'
            }`}
          >
            Due Soon
          </button>
        </div>

        {/* Engineer Avatars */}
        <div className="flex items-center -space-x-1.5">
          <div className="w-7 h-7 rounded-full bg-[#2a2a2c] text-[#e5e1e4] font-mono text-[10px] flex items-center justify-center ring-2 ring-[#0e0e10] font-semibold" title="Kaelen Thorne (Lead)">
            KT
          </div>
          <div className="w-7 h-7 rounded-full bg-[#ec6a06] text-[#341100] font-mono text-[10px] flex items-center justify-center ring-2 ring-[#0e0e10] font-semibold" title="Aria Xavier (Systems)">
            AX
          </div>
          <div className="w-7 h-7 rounded-full bg-[#06b6d4] text-[#003640] font-mono text-[10px] flex items-center justify-center ring-2 ring-[#0e0e10] font-semibold" title="Riku Nakamura (Shader Dev)">
            RN
          </div>
        </div>

        {/* New Task Button */}
        <button
          onClick={() => setIsNewTaskModalOpen(true)}
          className="flex items-center gap-1 bg-[#06b6d4] text-[#003640] px-3 py-1.5 rounded-lg font-semibold text-xs md:text-sm hover:opacity-95 shadow-[0_0_12px_rgba(6,182,212,0.35)] transition-all cursor-pointer active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">New Task</span>
        </button>

        {/* Notification Bell */}
        <button 
          className="relative p-2 text-[#bcc9cd] hover:bg-[#1c1b1d] hover:text-[#e5e1e4] rounded-lg transition-colors"
          title="Telemetry Alerts: 1 critical memory overrun reported"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#ffb4ab] shadow-[0_0_6px_#ef4444]"></span>
        </button>

        {/* Profile Avatar */}
        <div className="w-8 h-8 rounded-full bg-[#4cd7f6] flex items-center justify-center shadow-md text-[#003640]">
          <User className="w-4 h-4" />
        </div>
      </div>
    </header>
  );
};
