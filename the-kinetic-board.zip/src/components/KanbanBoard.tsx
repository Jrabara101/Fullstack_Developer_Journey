import React, { useState } from 'react';
import {
  DndContext,
  DragEndEvent,
  DragOverEvent,
  DragOverlay,
  DragStartEvent,
  KeyboardSensor,
  PointerSensor,
  closestCorners,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import { sortableKeyboardCoordinates } from '@dnd-kit/sortable';
import { ColumnId, Task } from '../types';
import { useBoardStore } from '../store/useBoardStore';
import { ColumnView } from './ColumnView';
import { TaskCard } from './TaskCard';
import { sound } from '../utils/sound';

export const KanbanBoard: React.FC = () => {
  const {
    columns,
    tasks,
    moveTaskOptimistic,
    searchQuery,
    activeTag,
    myTasksOnly,
    highPriorityOnly,
    dueSoonOnly,
    setIsNewTaskModalOpen,
  } = useBoardStore();

  const [activeTask, setActiveTask] = useState<Task | null>(null);

  // Require small pointer movement before dragging begins to allow clean clicks for opening Inspector
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Filter tasks based on global search, tag, priority, due soon, and "my tasks"
  const filterTask = (task: Task): boolean => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = task.title.toLowerCase().includes(q);
      const matchCode = task.code.toLowerCase().includes(q);
      const matchDesc = (task.subtitle || '').toLowerCase().includes(q);
      const matchTags = task.tags.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchCode && !matchDesc && !matchTags) return false;
    }

    if (activeTag) {
      if (!task.tags.includes(activeTag)) return false;
    }

    if (myTasksOnly) {
      // User is KT (Lead) in demo workspace
      if (!task.engineers.some((e) => e.id === 'KT')) return false;
    }

    if (highPriorityOnly) {
      if (task.priority !== 'P0' && task.priority !== 'P1') return false;
    }

    if (dueSoonOnly) {
      if (!['urgent', 'warning', 'overdue'].includes(task.deadlineType || '')) return false;
    }

    return true;
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const task = tasks[active.id as string];
    if (task) {
      setActiveTask(task);
      sound.playGrab();
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveTask(null);

    if (!over) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    const sourceTask = tasks[activeId];
    if (!sourceTask) return;

    const sourceColId = sourceTask.columnId;
    let destColId: ColumnId = sourceColId;
    let newIndex = 0;

    // Check if dropping directly onto a column container
    if (overId in columns) {
      destColId = overId as ColumnId;
      newIndex = columns[destColId].taskIds.length;
    } else {
      // Dropping over another task
      const targetTask = tasks[overId];
      if (targetTask) {
        destColId = targetTask.columnId;
        const targetColTasks = columns[destColId].taskIds;
        newIndex = targetColTasks.indexOf(overId);
      }
    }

    // Execute Client-Side Predicted Optimistic State Machine mutation
    moveTaskOptimistic(activeId, sourceColId, destColId, newIndex);
  };

  const handleAddTaskToColumn = (columnId: ColumnId) => {
    setIsNewTaskModalOpen(true);
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <div className="relative w-full px-4 md:px-6 pb-8 flex-1 overflow-x-auto select-none">
        <div className="flex items-start gap-4 min-w-max pb-6 pt-3">
          {(['backlog', 'in_progress', 'review', 'deployed'] as ColumnId[]).map((colId) => {
            const column = columns[colId];
            const columnTasks = column.taskIds
              .map((id) => tasks[id])
              .filter(Boolean)
              .filter(filterTask);

            return (
              <ColumnView
                key={column.id}
                column={column}
                tasks={columnTasks}
                onAddTask={handleAddTaskToColumn}
              />
            );
          })}
        </div>
      </div>

      {/* Floating Drag Overlay with 60fps Lift Effect */}
      <DragOverlay dropAnimation={{
        duration: 250,
        easing: 'cubic-bezier(0.18, 0.67, 0.6, 1.22)',
      }}>
        {activeTask ? (
          <div className="rotate-2 scale-105 shadow-[0_20px_30px_-5px_rgba(6,182,212,0.4)] cursor-grabbing">
            <TaskCard task={activeTask} isOverlay />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
};
