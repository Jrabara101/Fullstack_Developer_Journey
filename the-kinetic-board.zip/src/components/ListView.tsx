import React from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { Task } from '../types';
import { Clock, CheckCheck, AlertTriangle, ArrowRight, Zap } from 'lucide-react';

export const ListView: React.FC = () => {
  const { tasks, openInspector, activeTaskId, searchQuery } = useBoardStore();

  const allTasks = Object.values(tasks).filter((t) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      t.title.toLowerCase().includes(q) ||
      t.code.toLowerCase().includes(q) ||
      t.tags.some((tag) => tag.toLowerCase().includes(q))
    );
  });

  const getStatusBadge = (colId: Task['columnId']) => {
    switch (colId) {
      case 'backlog':
        return <span className="px-2 py-0.5 rounded bg-[#353437] text-[#bcc9cd] font-mono text-[10px] uppercase font-semibold">Backlog</span>;
      case 'in_progress':
        return <span className="px-2 py-0.5 rounded bg-[#06b6d4]/20 text-[#4cd7f6] font-mono text-[10px] uppercase font-semibold">In Progress</span>;
      case 'review':
        return <span className="px-2 py-0.5 rounded bg-[#ec6a06]/20 text-[#ffb690] font-mono text-[10px] uppercase font-semibold">Review & QA</span>;
      case 'deployed':
        return <span className="px-2 py-0.5 rounded bg-[#06b6d4]/10 text-[#4cd7f6] font-mono text-[10px] uppercase font-semibold">Deployed</span>;
    }
  };

  const getPriorityBadge = (priority: Task['priority']) => {
    switch (priority) {
      case 'P0':
        return <span className="px-1.5 py-0.5 rounded bg-[#93000a]/25 text-[#ffb4ab] font-mono text-[10px] font-bold">P0 CRITICAL</span>;
      case 'P1':
        return <span className="px-1.5 py-0.5 rounded bg-[#ec6a06]/20 text-[#ffb690] font-mono text-[10px] font-bold">P1 HIGH</span>;
      case 'P2':
        return <span className="px-1.5 py-0.5 rounded bg-[#353437] text-[#bcc9cd] font-mono text-[10px]">P2 ELEVATED</span>;
      case 'P3':
        return <span className="px-1.5 py-0.5 rounded bg-[#353437] text-[#869397] font-mono text-[10px]">P3 STANDARD</span>;
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-[#e5e1e4] tracking-tight uppercase font-mono">
            Task Queue Matrix ({allTasks.length} Entities)
          </h2>
          <p className="text-xs text-[#869397] font-mono">
            Flattened chronological inspection stream with direct node inspector bindings
          </p>
        </div>
      </div>

      <div className="bg-[#1c1b1d] rounded-xl border border-[#3d494c]/40 overflow-hidden shadow-xl">
        <div className="grid grid-cols-12 gap-3 p-3 bg-[#201f22] border-b border-[#3d494c]/40 font-mono text-[10px] text-[#869397] uppercase tracking-wider">
          <div className="col-span-1">CODE</div>
          <div className="col-span-5">TITLE & SPEC</div>
          <div className="col-span-2">STATUS</div>
          <div className="col-span-2">PRIORITY</div>
          <div className="col-span-1">DEADLINE</div>
          <div className="col-span-1 text-right">ACTION</div>
        </div>

        <div className="divide-y divide-[#3d494c]/20">
          {allTasks.map((t) => {
            const isSelected = activeTaskId === t.id;
            return (
              <div
                key={t.id}
                onClick={() => openInspector(t.id)}
                className={`grid grid-cols-12 gap-3 p-3 items-center hover:bg-[#252428] cursor-pointer transition-colors ${
                  isSelected ? 'bg-[#201f22] ring-1 ring-inset ring-[#4cd7f6]/50' : ''
                }`}
              >
                <div className="col-span-1 font-mono text-xs text-[#4cd7f6] font-bold">
                  {t.code}
                </div>
                <div className="col-span-5">
                  <div className="flex items-center gap-1.5">
                    {t.isActiveSticker && <Zap className="w-3 h-3 text-[#06b6d4] fill-current" />}
                    <h4 className={`text-xs text-[#e5e1e4] font-medium line-clamp-1 ${t.columnId === 'deployed' ? 'line-through text-[#869397]' : ''}`}>
                      {t.title}
                    </h4>
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    {t.tags.map((tag) => (
                      <span key={tag} className="font-mono text-[9px] px-1 py-0.2 rounded bg-[#2a2a2c] text-[#869397]">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="col-span-2">
                  {getStatusBadge(t.columnId)}
                </div>
                <div className="col-span-2">
                  {getPriorityBadge(t.priority)}
                </div>
                <div className="col-span-1 font-mono text-[11px] text-[#bcc9cd]">
                  {t.deadline || '—'}
                </div>
                <div className="col-span-1 text-right">
                  <span className="text-[#869397] hover:text-[#4cd7f6] text-xs font-mono inline-flex items-center gap-1">
                    <span>Inspect</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
