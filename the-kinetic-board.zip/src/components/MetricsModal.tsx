import React from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { 
  X, 
  Cpu, 
  Activity, 
  Wifi, 
  WifiOff, 
  RotateCcw, 
  Zap, 
  Gauge, 
  Layers,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { sound } from '../utils/sound';

export const MetricsModal: React.FC = () => {
  const { 
    isMetricsModalOpen, 
    setIsMetricsModalOpen, 
    netcode, 
    toggleSimulateFailure, 
    toggleSimulateLatency,
    rollbackMove,
    tasks,
    columns 
  } = useBoardStore();

  if (!isMetricsModalOpen) return null;

  const totalTasks = Object.keys(tasks).length;
  const deployedCount = columns.deployed?.taskIds.length || 0;
  const inProgressCount = columns.in_progress?.taskIds.length || 0;
  const reviewCount = columns.review?.taskIds.length || 0;
  const backlogCount = columns.backlog?.taskIds.length || 0;

  const p0Count = Object.values(tasks).filter((t) => t.priority === 'P0').length;
  const p1Count = Object.values(tasks).filter((t) => t.priority === 'P1').length;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#1c1b1d] border border-[#3d494c]/60 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 border-b border-[#3d494c]/30 flex items-center justify-between bg-[#201f22]">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#4cd7f6]" />
            <div>
              <h3 className="font-semibold text-[#e5e1e4] text-sm md:text-base uppercase tracking-wider font-mono">
                Kinetic Engine Telemetry & Netcode Diagnostics
              </h3>
              <p className="text-[11px] text-[#869397] font-mono">
                Realtime DOM 2D Spatial Scene & Client-Side Prediction Netcode
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsMetricsModalOpen(false)}
            className="w-7 h-7 rounded flex items-center justify-center text-[#869397] hover:text-[#e5e1e4] hover:bg-[#2a2a2c] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-5 max-h-[80vh] overflow-y-auto font-mono text-xs">
          {/* Hardware 60fps Render Loop Monitor */}
          <div className="p-3.5 rounded-xl bg-[#131315] border border-[#3d494c]/40 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#4cd7f6] font-bold">
                <Gauge className="w-4 h-4" />
                <span>SPATIAL RENDER LOOP (HARDWARE ACCELERATED)</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-[#06b6d4]/20 text-[#4cd7f6] font-semibold text-[10px]">
                60.0 FPS • 16.6ms / frame
              </span>
            </div>
            <p className="text-[11px] text-[#869397] leading-relaxed">
              Pointer coordinates tracked via hardware sensors. Position manipulated directly via{' '}
              <code className="text-[#4cd7f6] bg-[#2a2a2c] px-1 py-0.5 rounded">
                transform: translate3d(x, y, 0)
              </code>{' '}
              bypassing React re-renders during drag updates until the drop event occurs.
            </p>
            <div className="grid grid-cols-3 gap-2 pt-1 text-[11px]">
              <div className="bg-[#1c1b1d] p-2 rounded border border-[#3d494c]/30">
                <span className="text-[#869397] block text-[10px]">GPU ACCELERATION</span>
                <span className="text-[#4cd7f6] font-bold">MATRIX 3D (ACTIVE)</span>
              </div>
              <div className="bg-[#1c1b1d] p-2 rounded border border-[#3d494c]/30">
                <span className="text-[#869397] block text-[10px]">COLLISION MODEL</span>
                <span className="text-[#ffb690] font-bold">CLOSEST CORNERS</span>
              </div>
              <div className="bg-[#1c1b1d] p-2 rounded border border-[#3d494c]/30">
                <span className="text-[#869397] block text-[10px]">ANIMATION SPRING</span>
                <span className="text-[#e5e1e4] font-bold">STIFFNESS: 550</span>
              </div>
            </div>
          </div>

          {/* Client-Side Prediction Netcode Automaton */}
          <div className="p-3.5 rounded-xl bg-[#131315] border border-[#3d494c]/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#ffb690] font-bold">
                <Zap className="w-4 h-4" />
                <span>CLIENT-SIDE PREDICTED NETCODE AUTOMATON</span>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                netcode.simulateFailure
                  ? 'bg-[#93000a] text-[#ffb4ab]'
                  : 'bg-[#06b6d4]/20 text-[#4cd7f6]'
              }`}>
                {netcode.simulateFailure ? 'FAILURE INJECTION ACTIVE' : 'PREDICTION: HEALTHY'}
              </span>
            </div>

            <p className="text-[11px] text-[#869397] leading-relaxed">
              When a card is moved, local UI state mutates in 0ms (optimistic update). Backend API sync executes in the background. If the server rejects the move, the state rolls back, triggering an elastic rubber-band animation back to the origin column.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={toggleSimulateFailure}
                className={`p-2.5 rounded-lg border text-left flex items-start gap-2.5 transition-all ${
                  netcode.simulateFailure
                    ? 'bg-[#93000a]/20 border-[#ffb4ab] text-[#ffb4ab]'
                    : 'bg-[#1c1b1d] border-[#3d494c]/40 text-[#869397] hover:border-[#ffb690]'
                }`}
              >
                {netcode.simulateFailure ? <WifiOff className="w-4 h-4 text-[#ffb4ab]" /> : <Wifi className="w-4 h-4" />}
                <div>
                  <span className="font-bold text-xs block text-[#e5e1e4]">
                    Simulate Server Rejection
                  </span>
                  <span className="text-[10px]">
                    {netcode.simulateFailure ? 'Reject enabled! Move a card to watch it rubber-band.' : 'Click to test network drop rollback'}
                  </span>
                </div>
              </button>

              <button
                onClick={toggleSimulateLatency}
                className={`p-2.5 rounded-lg border text-left flex items-start gap-2.5 transition-all ${
                  netcode.simulateLatency
                    ? 'bg-[#06b6d4]/15 border-[#4cd7f6] text-[#4cd7f6]'
                    : 'bg-[#1c1b1d] border-[#3d494c]/40 text-[#869397]'
                }`}
              >
                <Cpu className="w-4 h-4" />
                <div>
                  <span className="font-bold text-xs block text-[#e5e1e4]">
                    Simulate Latency (420ms)
                  </span>
                  <span className="text-[10px]">
                    {netcode.simulateLatency ? '420ms async simulated lag' : '60ms instantaneous'}
                  </span>
                </div>
              </button>
            </div>

            {/* Test Trigger Button */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-[#869397]">Immediate Rollback Trigger:</span>
              <button
                onClick={() => {
                  sound.playRubberBand();
                  rollbackMove('KT-1042');
                }}
                className="px-3 py-1 rounded bg-[#2a2a2c] hover:bg-[#353437] text-[#ffb690] border border-[#ffb690]/30 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Trigger Rubber-Band Rollback (#KT-1042)</span>
              </button>
            </div>
          </div>

          {/* Spatial Pipeline Distribution */}
          <div className="p-3.5 rounded-xl bg-[#131315] border border-[#3d494c]/40 space-y-2.5">
            <div className="flex items-center justify-between text-[#e5e1e4] font-bold">
              <span>WORKFLOW STRATA DISTRIBUTION</span>
              <span>{totalTasks} ACTIVE ENTITIES</span>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
              <div className="p-2 rounded bg-[#1c1b1d] border border-[#3d494c]/30">
                <span className="text-[#869397] block">BACKLOG</span>
                <span className="text-sm font-bold text-[#e5e1e4]">{backlogCount}</span>
              </div>
              <div className="p-2 rounded bg-[#1c1b1d] border border-[#06b6d4]/30">
                <span className="text-[#4cd7f6] block">IN PROGRESS</span>
                <span className="text-sm font-bold text-[#4cd7f6]">{inProgressCount}</span>
              </div>
              <div className="p-2 rounded bg-[#1c1b1d] border border-[#ec6a06]/30">
                <span className="text-[#ffb690] block">REVIEW & QA</span>
                <span className="text-sm font-bold text-[#ffb690]">{reviewCount}</span>
              </div>
              <div className="p-2 rounded bg-[#1c1b1d] border border-[#3d494c]/30">
                <span className="text-[#4cd7f6] block">DEPLOYED</span>
                <span className="text-sm font-bold text-[#4cd7f6]">{deployedCount}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-[#3d494c]/30 bg-[#201f22] flex justify-end">
          <button
            onClick={() => setIsMetricsModalOpen(false)}
            className="px-4 py-1.5 rounded-lg bg-[#06b6d4] text-[#003640] font-mono text-xs font-bold hover:opacity-95 transition-all"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
};
