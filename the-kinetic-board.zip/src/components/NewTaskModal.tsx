import React, { useState } from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { ColumnId, Priority } from '../types';
import { ENGINEERS } from '../data/initialData';
import { X, Plus, Sparkles, Tag, Calendar, User } from 'lucide-react';
import { sound } from '../utils/sound';

export const NewTaskModal: React.FC = () => {
  const { isNewTaskModalOpen, setIsNewTaskModalOpen, createTask } = useBoardStore();

  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [columnId, setColumnId] = useState<ColumnId>('backlog');
  const [priority, setPriority] = useState<Priority>('P1');
  const [tagInput, setTagInput] = useState('Frontend, Core');
  const [deadline, setDeadline] = useState('Tomorrow');
  const [selectedEngineers, setSelectedEngineers] = useState<string[]>(['KT']);

  if (!isNewTaskModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const tags = tagInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const priorityLabels: Record<Priority, string> = {
      P0: 'P0 - Critical Core',
      P1: 'P1 - High',
      P2: 'P2 - Elevated',
      P3: 'P3 - Standard',
    };

    const assignedEngineers = selectedEngineers
      .map((id) => ENGINEERS[id])
      .filter(Boolean);

    createTask({
      title: title.trim(),
      subtitle: subtitle.trim() || undefined,
      columnId,
      priority,
      priorityLabel: priorityLabels[priority],
      tags: tags.length > 0 ? tags : ['General'],
      deadline: deadline.trim() || null,
      deadlineType: priority === 'P0' ? 'urgent' : 'normal',
      engineers: assignedEngineers.length > 0 ? assignedEngineers : [ENGINEERS.KT],
      missionSpec: `## Mission Parameters\n- [ ] Initialize implementation loop\n- [ ] Validate 60fps interaction profiles`,
    });

    setTitle('');
    setSubtitle('');
    setIsNewTaskModalOpen(false);
  };

  const toggleEngineer = (id: string) => {
    sound.playClick();
    setSelectedEngineers((prev) =>
      prev.includes(id) ? (prev.length > 1 ? prev.filter((e) => e !== id) : prev) : [...prev, id]
    );
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1c1b1d] border border-[#3d494c]/60 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 border-b border-[#3d494c]/30 flex items-center justify-between bg-[#201f22]">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-[#06b6d4] shadow-[0_0_8px_#06b6d4]"></div>
            <h3 className="font-semibold text-[#e5e1e4] text-sm md:text-base uppercase tracking-wider">
              Spawn Kinetic Node
            </h3>
          </div>
          <button
            onClick={() => setIsNewTaskModalOpen(false)}
            className="w-7 h-7 rounded flex items-center justify-center text-[#869397] hover:text-[#e5e1e4] hover:bg-[#2a2a2c] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5">
          {/* Title */}
          <div className="space-y-1">
            <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
              Task Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Integrate dynamic vertex buffer physics shaders"
              className="w-full bg-[#201f22] text-[#e5e1e4] text-sm p-2 rounded-lg border border-[#3d494c]/50 focus:border-[#4cd7f6] outline-none"
              autoFocus
            />
          </div>

          {/* Subtitle */}
          <div className="space-y-1">
            <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
              Subtitle / Objective
            </label>
            <input
              type="text"
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              placeholder="e.g. Reduce CPU garbage collection overhead on drag operations"
              className="w-full bg-[#201f22] text-[#e5e1e4] text-xs p-2 rounded-lg border border-[#3d494c]/50 focus:border-[#4cd7f6] outline-none"
            />
          </div>

          {/* 2-Col Grid */}
          <div className="grid grid-cols-2 gap-3">
            {/* Column Target */}
            <div className="space-y-1">
              <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
                Initial Zone
              </label>
              <select
                value={columnId}
                onChange={(e) => setColumnId(e.target.value as ColumnId)}
                className="w-full bg-[#201f22] text-[#e5e1e4] font-mono text-xs p-2 rounded-lg border border-[#3d494c]/50 focus:border-[#4cd7f6] outline-none"
              >
                <option value="backlog">Backlog</option>
                <option value="in_progress">In Progress</option>
                <option value="review">Review & QA</option>
                <option value="deployed">Deployed</option>
              </select>
            </div>

            {/* Priority */}
            <div className="space-y-1">
              <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full bg-[#201f22] text-[#ffb690] font-mono text-xs p-2 rounded-lg border border-[#3d494c]/50 focus:border-[#ffb690] outline-none font-semibold"
              >
                <option value="P0">P0 - Critical Core</option>
                <option value="P1">P1 - High</option>
                <option value="P2">P2 - Elevated</option>
                <option value="P3">P3 - Standard</option>
              </select>
            </div>
          </div>

          {/* Tags & Deadline */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
                Tags (comma separated)
              </label>
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Kinetic, WebGL, Shader"
                className="w-full bg-[#201f22] text-[#e5e1e4] font-mono text-xs p-2 rounded-lg border border-[#3d494c]/50 focus:border-[#4cd7f6] outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
                Deadline
              </label>
              <input
                type="text"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                placeholder="e.g. Tomorrow, 18h left"
                className="w-full bg-[#201f22] text-[#e5e1e4] font-mono text-xs p-2 rounded-lg border border-[#3d494c]/50 focus:border-[#4cd7f6] outline-none"
              />
            </div>
          </div>

          {/* Engineers */}
          <div className="space-y-1">
            <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
              Assigned Engineers
            </label>
            <div className="flex items-center gap-2 pt-1 flex-wrap">
              {Object.values(ENGINEERS).map((eng) => {
                const isSelected = selectedEngineers.includes(eng.id);
                return (
                  <button
                    type="button"
                    key={eng.id}
                    onClick={() => toggleEngineer(eng.id)}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-mono transition-all ${
                      isSelected
                        ? 'bg-[#06b6d4]/20 border-[#06b6d4] text-[#4cd7f6]'
                        : 'bg-[#201f22] border-[#3d494c]/40 text-[#869397] hover:border-[#869397]'
                    }`}
                  >
                    <span className={`w-4 h-4 rounded-full text-[8px] flex items-center justify-center font-bold ${eng.bgClass} ${eng.textClass}`}>
                      {eng.initials}
                    </span>
                    <span>{eng.name.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-[#3d494c]/30 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsNewTaskModalOpen(false)}
              className="px-3 py-1.5 rounded-lg bg-[#2a2a2c] text-[#e5e1e4] font-mono text-xs hover:bg-[#353437] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-[#06b6d4] text-[#003640] font-mono text-xs font-bold hover:opacity-95 shadow-[0_0_12px_rgba(6,182,212,0.4)] transition-all flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Node</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
