import React from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { GitBranch, CheckCircle2, CircleDot, Clock } from 'lucide-react';

export const RoadmapView: React.FC = () => {
  const milestones = [
    {
      version: 'Sprint 43.8',
      date: 'Completed Sep 07',
      status: 'shipped',
      title: 'Foundation Layer: WebGL Fluid Micro-mesh Infrastructure',
      items: ['Zero memory allocations in 60fps render loops', 'Ping-pong texture ping-pong framebuffers', 'Tactile audio feedback synthesizer'],
    },
    {
      version: 'Sprint 44.2',
      date: 'In Flight (Day 8 of 14)',
      status: 'active',
      title: 'Active Velocity: Game-Netcode Client-Side Prediction',
      items: ['Optimistic Zustand Automaton with rubber-band rollback', 'Spatial 2D collision detector via @dnd-kit', 'Instant Task Inspector with live Markdown editing'],
    },
    {
      version: 'Sprint 45.0',
      date: 'Queued Oct 01',
      status: 'planned',
      title: 'Next Phase: Multi-tenant WebSocket Replication Mesh',
      items: ['Binary Delta sync protocol for remote peer cursor positions', 'Automated canary rollback on 0.05% error rate', 'Customizable HUD theme matrix tokens'],
    },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-4xl font-mono text-xs">
      <div>
        <h2 className="text-lg font-bold text-[#e5e1e4] tracking-tight uppercase font-sans">
          Sprint Strategic Roadmap
        </h2>
        <p className="text-xs text-[#869397]">
          Chronological milestone vectors and architecture progression
        </p>
      </div>

      <div className="relative pl-6 space-y-8 before:content-[''] before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-[#3d494c]/50">
        {milestones.map((m, idx) => (
          <div key={m.version} className="relative group">
            <span
              className={`w-5 h-5 rounded-full absolute -left-6 top-1 flex items-center justify-center ring-4 ring-[#131315] ${
                m.status === 'shipped'
                  ? 'bg-[#06b6d4] text-[#003640]'
                  : m.status === 'active'
                  ? 'bg-[#ec6a06] text-[#341100] animate-pulse'
                  : 'bg-[#353437] text-[#869397]'
              }`}
            >
              {m.status === 'shipped' ? (
                <CheckCircle2 className="w-3 h-3" />
              ) : m.status === 'active' ? (
                <CircleDot className="w-3 h-3" />
              ) : (
                <Clock className="w-3 h-3" />
              )}
            </span>

            <div className="p-4 rounded-xl bg-[#1c1b1d] border border-[#3d494c]/40 space-y-2 shadow-lg">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className={`px-2 py-0.5 rounded font-bold uppercase text-[10px] ${
                  m.status === 'active'
                    ? 'bg-[#ec6a06]/20 text-[#ffb690] border border-[#ec6a06]/30'
                    : m.status === 'shipped'
                    ? 'bg-[#06b6d4]/20 text-[#4cd7f6]'
                    : 'bg-[#2a2a2c] text-[#869397]'
                }`}>
                  {m.version}
                </span>
                <span className="text-[#869397] text-[10px]">{m.date}</span>
              </div>

              <h3 className="text-sm font-bold text-[#e5e1e4] font-sans">
                {m.title}
              </h3>

              <ul className="space-y-1 text-[#bcc9cd] pt-1">
                {m.items.map((item, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="w-1 h-1 rounded-full bg-[#4cd7f6]" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
