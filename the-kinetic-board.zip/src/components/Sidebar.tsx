import React from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { 
  Terminal, 
  LayoutGrid, 
  ListOrdered, 
  Activity, 
  GitBranch, 
  Settings, 
  Volume2, 
  VolumeX,
  Sparkles
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeView, setActiveView, soundEnabled, toggleSound, setIsMetricsModalOpen } = useBoardStore();

  const navItems = [
    { id: 'board' as const, label: 'BOARD', icon: LayoutGrid, title: 'Board Matrix View' },
    { id: 'list' as const, label: 'LIST', icon: ListOrdered, title: 'Task Queue View' },
    { id: 'stats' as const, label: 'STATS', icon: Activity, title: 'Telemetry & Analytics' },
    { id: 'map' as const, label: 'MAP', icon: GitBranch, title: 'Sprint Roadmap' },
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-20 bg-[#0e0e10] z-50 flex flex-col items-center py-3 justify-between shadow-[0_1px_8px_rgba(0,0,0,0.5)] border-r border-[#3d494c]/20">
      {/* Top Terminal Brand */}
      <div className="flex flex-col items-center w-full gap-5">
        <button
          onClick={() => setIsMetricsModalOpen(true)}
          className="w-12 h-12 rounded-lg bg-[#201f22] flex items-center justify-center shadow-inner group hover:bg-[#2a2a2c] hover:border-[#4cd7f6]/40 border border-transparent transition-all"
          title="Kinetic Engine Console (Click for Telemetry)"
        >
          <Terminal className="w-5 h-5 text-[#4cd7f6] group-hover:scale-110 transition-transform" />
        </button>

        {/* Nav Tabs */}
        <nav className="flex flex-col items-center gap-2 w-full px-1">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                title={item.title}
                className={`flex flex-col items-center justify-center w-12 h-12 rounded-lg transition-all group ${
                  isActive
                    ? 'bg-[#2a2a2c] text-[#4cd7f6] shadow-[0_0_12px_rgba(76,215,246,0.25)] border border-[#4cd7f6]/30'
                    : 'text-[#bcc9cd] hover:bg-[#201f22] hover:text-[#e5e1e4]'
                }`}
              >
                <Icon className="w-5 h-5 transition-transform group-hover:scale-105" />
                <span className="font-mono text-[9px] tracking-wider mt-0.5 opacity-90 uppercase">
                  {item.label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Controls */}
      <div className="flex flex-col items-center gap-3 w-full px-1">
        {/* Sound FX Toggle */}
        <button
          onClick={toggleSound}
          title={soundEnabled ? 'Zero-Latency Audio FX: Active' : 'Audio FX: Muted'}
          className={`flex flex-col items-center justify-center w-12 h-11 rounded-lg transition-all ${
            soundEnabled
              ? 'text-[#4cd7f6] hover:bg-[#201f22]'
              : 'text-[#869397] hover:bg-[#201f22] opacity-60'
          }`}
        >
          {soundEnabled ? (
            <Volume2 className="w-4 h-4" />
          ) : (
            <VolumeX className="w-4 h-4" />
          )}
          <span className="font-mono text-[8px] tracking-wider mt-0.5 uppercase">
            {soundEnabled ? 'FX ON' : 'MUTE'}
          </span>
        </button>

        {/* Sys Settings */}
        <button
          onClick={() => setIsMetricsModalOpen(true)}
          className="flex flex-col items-center justify-center w-12 h-12 rounded-lg text-[#bcc9cd] hover:bg-[#201f22] hover:text-[#e5e1e4] transition-all"
          title="System Configuration & Diagnostics"
        >
          <Settings className="w-5 h-5" />
          <span className="font-mono text-[9px] tracking-wider mt-0.5 opacity-80 uppercase">
            SYS
          </span>
        </button>

        {/* Live Engine Pulse Indicator */}
        <div 
          className="w-8 h-8 rounded-full bg-[#2a2a2c] flex items-center justify-center cursor-pointer hover:bg-[#353437] transition-colors"
          title="60fps Hardware Render Loop Active"
          onClick={() => setIsMetricsModalOpen(true)}
        >
          <div className="w-2 h-2 rounded-full bg-[#4cd7f6] animate-pulse shadow-[0_0_8px_#06b6d4]"></div>
        </div>
      </div>
    </aside>
  );
};
