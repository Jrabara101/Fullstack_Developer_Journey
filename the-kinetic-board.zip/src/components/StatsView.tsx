import React from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { Activity, Gauge, TrendingUp, Cpu, Flame, Layers } from 'lucide-react';

export const StatsView: React.FC = () => {
  const { tasks, columns } = useBoardStore();

  const total = Object.keys(tasks).length;
  const deployed = columns.deployed.taskIds.length;
  const inProgress = columns.in_progress.taskIds.length;
  const review = columns.review.taskIds.length;
  const backlog = columns.backlog.taskIds.length;

  const completionRate = Math.round((deployed / total) * 100) || 0;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl font-mono text-xs">
      <div>
        <h2 className="text-lg font-bold text-[#e5e1e4] tracking-tight uppercase font-sans">
          Sprint 44 Telemetry & Velocity Engine
        </h2>
        <p className="text-xs text-[#869397]">
          Real-time execution throughput, micro-mesh performance, and netcode latency metrics
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#1c1b1d] border border-[#3d494c]/40 space-y-1 shadow-lg">
          <span className="text-[10px] text-[#869397] uppercase">Completion Rate</span>
          <div className="text-2xl font-bold text-[#4cd7f6]">{completionRate}%</div>
          <span className="text-[10px] text-[#06b6d4]">14/19 Objectives Reached</span>
        </div>

        <div className="p-4 rounded-xl bg-[#1c1b1d] border border-[#3d494c]/40 space-y-1 shadow-lg">
          <span className="text-[10px] text-[#869397] uppercase">Current Velocity</span>
          <div className="text-2xl font-bold text-[#ffb690]">4.2 pts/day</div>
          <span className="text-[10px] text-[#ffb690]">Active Burn Rate</span>
        </div>

        <div className="p-4 rounded-xl bg-[#1c1b1d] border border-[#3d494c]/40 space-y-1 shadow-lg">
          <span className="text-[10px] text-[#869397] uppercase">Spatial Frame Budget</span>
          <div className="text-2xl font-bold text-[#e5e1e4]">16.6ms</div>
          <span className="text-[10px] text-[#4cd7f6]">60fps Locked</span>
        </div>

        <div className="p-4 rounded-xl bg-[#1c1b1d] border border-[#3d494c]/40 space-y-1 shadow-lg">
          <span className="text-[10px] text-[#869397] uppercase">Netcode Ping</span>
          <div className="text-2xl font-bold text-[#4cd7f6]">38ms</div>
          <span className="text-[10px] text-[#869397]">0ms Client Prediction</span>
        </div>
      </div>

      {/* Visual Workflow Pipeline Breakdown */}
      <div className="p-5 rounded-xl bg-[#1c1b1d] border border-[#3d494c]/40 space-y-3 shadow-xl">
        <div className="flex items-center justify-between text-sm font-bold text-[#e5e1e4]">
          <span className="flex items-center gap-1.5 font-sans">
            <Layers className="w-4 h-4 text-[#4cd7f6]" />
            Pipeline Density Distribution
          </span>
          <span className="text-xs text-[#869397] font-mono">{total} Total Entities</span>
        </div>

        {/* Multi-segment progress bar */}
        <div className="h-4 w-full rounded-full bg-[#131315] flex overflow-hidden p-0.5 border border-[#3d494c]/30">
          <div style={{ width: `${(backlog / total) * 100}%` }} className="bg-[#869397] h-full" title={`Backlog: ${backlog}`} />
          <div style={{ width: `${(inProgress / total) * 100}%` }} className="bg-[#06b6d4] h-full" title={`In Progress: ${inProgress}`} />
          <div style={{ width: `${(review / total) * 100}%` }} className="bg-[#ec6a06] h-full" title={`Review: ${review}`} />
          <div style={{ width: `${(deployed / total) * 100}%` }} className="bg-[#4cd7f6] h-full" title={`Deployed: ${deployed}`} />
        </div>

        <div className="grid grid-cols-4 gap-3 pt-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded bg-[#869397]" />
            <span className="text-[#bcc9cd]">Backlog ({backlog})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded bg-[#06b6d4]" />
            <span className="text-[#4cd7f6]">In Progress ({inProgress})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded bg-[#ec6a06]" />
            <span className="text-[#ffb690]">Review & QA ({review})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded bg-[#4cd7f6]" />
            <span className="text-[#4cd7f6]">Deployed ({deployed})</span>
          </div>
        </div>
      </div>
    </div>
  );
};
