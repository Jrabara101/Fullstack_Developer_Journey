import React, { useState } from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { 
  BarChart2, 
  SlidersHorizontal, 
  Layers, 
  Grid, 
  Sliders, 
  Sparkles, 
  CheckCircle2, 
  TrendingUp, 
  PanelRightOpen,
  PanelRightClose
} from 'lucide-react';

export const SubHeader: React.FC = () => {
  const { 
    isInspectorOpen, 
    toggleInspector, 
    setIsMetricsModalOpen,
    tasks,
    columns,
    activeTag,
    setActiveTag,
    resetFilters
  } = useBoardStore();

  const [activeLayoutMode, setActiveLayoutMode] = useState<'grid' | 'stream'>('grid');
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);

  // Compute completed tasks statistics
  const totalTasks = Object.keys(tasks).length;
  const completedTasks = columns.deployed?.taskIds.length || 0;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const allTags = Array.from(
    new Set(Object.values(tasks).flatMap((t) => t.tags))
  );

  return (
    <section className="relative px-4 md:px-6 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-[#3d494c]/20 bg-[#131315]">
      {/* Title & Velocity */}
      <div className="flex items-center gap-3 md:gap-4">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#06b6d4] shadow-[0_0_10px_#06b6d4]"></span>
          <h2 className="font-semibold text-[#e5e1e4] tracking-tight uppercase text-sm md:text-base">
            Sprint Matrix 44.2
          </h2>
          <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-[#2a2a2c] text-[#4cd7f6] uppercase tracking-widest font-semibold border border-[#4cd7f6]/20">
            Active Velocity
          </span>
        </div>

        {/* Progress bar */}
        <div className="hidden xl:flex items-center gap-2 pl-3 border-l border-[#3d494c]/30">
          <div className="flex items-center gap-1.5 text-[#bcc9cd] font-mono text-xs">
            <TrendingUp className="w-3.5 h-3.5 text-[#4cd7f6]" />
            <span>{completedTasks}/{totalTasks} Completed</span>
          </div>
          <div className="w-28 h-1.5 rounded-full bg-[#2a2a2c] overflow-hidden">
            <div
              className="h-full bg-[#06b6d4] rounded-full shadow-[0_0_8px_#06b6d4] transition-all duration-500"
              style={{ width: `${completionPercentage}%` }}
            ></div>
          </div>
          <span className="font-mono text-[10px] text-[#bcc9cd]">{completionPercentage}%</span>
        </div>
      </div>

      {/* Right controls: View toggles, Metrics, Inspector Toggle */}
      <div className="flex items-center gap-2 flex-wrap">
        {/* Layout segmented button */}
        <div className="flex items-center bg-[#1c1b1d] rounded-lg p-0.5 border border-[#3d494c]/30">
          <button
            onClick={() => setActiveLayoutMode('grid')}
            className={`px-2.5 py-1 rounded font-mono text-xs flex items-center gap-1 transition-colors ${
              activeLayoutMode === 'grid'
                ? 'bg-[#201f22] text-[#4cd7f6] shadow-sm'
                : 'text-[#bcc9cd] hover:text-[#e5e1e4]'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Grid</span>
          </button>
          <button
            onClick={() => setActiveLayoutMode('stream')}
            className={`px-2.5 py-1 rounded font-mono text-xs flex items-center gap-1 transition-colors ${
              activeLayoutMode === 'stream'
                ? 'bg-[#201f22] text-[#4cd7f6] shadow-sm'
                : 'text-[#bcc9cd] hover:text-[#e5e1e4]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Kinetic Stream</span>
          </button>

          {/* Filter Popover Trigger */}
          <div className="relative">
            <button
              onClick={() => setShowFilterDropdown(!showFilterDropdown)}
              className={`px-2.5 py-1 rounded font-mono text-xs flex items-center gap-1 transition-colors ${
                activeTag
                  ? 'bg-[#06b6d4]/20 text-[#4cd7f6] font-semibold'
                  : 'text-[#bcc9cd] hover:text-[#e5e1e4]'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{activeTag ? `Tag: ${activeTag}` : 'Filter'}</span>
            </button>

            {/* Tags Dropdown */}
            {showFilterDropdown && (
              <div className="absolute right-0 top-full mt-1.5 w-56 p-2 rounded-lg bg-[#1c1b1d] border border-[#3d494c]/60 shadow-xl z-50">
                <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-[#3d494c]/30 text-[11px] font-mono text-[#869397]">
                  <span>FILTER BY TAG</span>
                  {activeTag && (
                    <button
                      onClick={() => { setActiveTag(null); setShowFilterDropdown(false); }}
                      className="text-[#4cd7f6] hover:underline"
                    >
                      Clear
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-1 max-h-48 overflow-y-auto">
                  {allTags.map((tag) => (
                    <button
                      key={tag}
                      onClick={() => {
                        setActiveTag(tag);
                        setShowFilterDropdown(false);
                      }}
                      className={`text-left font-mono text-[10px] px-2 py-1 rounded transition-colors ${
                        activeTag === tag
                          ? 'bg-[#06b6d4] text-[#003640] font-bold'
                          : 'bg-[#2a2a2c] text-[#bcc9cd] hover:bg-[#353437] hover:text-[#e5e1e4]'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Metrics Button */}
        <button
          onClick={() => setIsMetricsModalOpen(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#2a2a2c] text-[#e5e1e4] hover:bg-[#353437] border border-[#3d494c]/40 transition-colors font-mono text-xs cursor-pointer"
        >
          <BarChart2 className="w-3.5 h-3.5 text-[#ffb690]" />
          <span>Metrics</span>
        </button>

        {/* Inspect Inspector Button */}
        <button
          onClick={toggleInspector}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-mono text-xs font-semibold transition-all cursor-pointer ${
            isInspectorOpen
              ? 'bg-[#06b6d4] text-[#003640] shadow-[0_0_12px_rgba(6,182,212,0.35)]'
              : 'bg-[#201f22] text-[#e5e1e4] hover:bg-[#2a2a2c] border border-[#3d494c]/40'
          }`}
        >
          {isInspectorOpen ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
          <span>Inspect Inspector</span>
        </button>
      </div>
    </section>
  );
};
