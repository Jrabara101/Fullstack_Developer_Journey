import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { motion } from 'motion/react';
import { Task } from '../types';
import { useBoardStore } from '../store/useBoardStore';
import { 
  GripVertical, 
  Clock, 
  AlertTriangle, 
  CheckCheck, 
  Zap, 
  GitPullRequest,
  CheckCircle2
} from 'lucide-react';
import { Badge } from './ui/badge';
import { Card } from './ui/card';

interface TaskCardProps {
  task: Task;
  isOverlay?: boolean;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task, isOverlay = false }) => {
  const { 
    openInspector, 
    activeTaskId, 
    netcode 
  } = useBoardStore();

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: task.id,
    data: {
      type: 'task',
      task,
    },
    disabled: isOverlay,
  });

  const isSelected = activeTaskId === task.id;
  const isRubberBanding = netcode.rubberBandingTaskId === task.id;
  const isDeployed = task.columnId === 'deployed';

  // Map priority to accent border colors and badge styles
  const getBorderColor = () => {
    if (task.columnId === 'deployed') return 'border-l-[#06b6d4]/60';
    if (task.priority === 'P0' || task.tags.includes('Urgent') || task.tags.includes('Bugfix')) {
      return task.tags.includes('Urgent') ? 'border-l-[#ffb4ab]' : 'border-l-[#06b6d4]';
    }
    if (task.priority === 'P1' || task.tags.includes('Security')) return 'border-l-[#ffb690]';
    if (task.priority === 'P2') return 'border-l-[#ec6a06]';
    return 'border-l-[#869397]';
  };

  // Deadline styling
  const getDeadlineStyle = () => {
    if (isDeployed) {
      return {
        text: 'text-[#869397]',
        icon: CheckCheck,
      };
    }
    if (task.deadlineType === 'overdue') {
      return {
        text: 'text-[#ffb4ab] font-semibold',
        icon: AlertTriangle,
      };
    }
    if (task.deadlineType === 'urgent' || task.deadlineType === 'warning') {
      return {
        text: 'text-[#ffb690] font-semibold',
        icon: Clock,
      };
    }
    return {
      text: 'text-[#869397]',
      icon: Clock,
    };
  };

  const deadlineInfo = getDeadlineStyle();
  const DeadlineIcon = deadlineInfo.icon;

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition: transition || undefined,
    opacity: isDragging ? 0.35 : 1,
  };

  return (
    <motion.div
      layout
      layoutId={task.id}
      transition={{ type: 'spring', stiffness: 550, damping: 35 }}
      ref={setNodeRef}
      style={style}
      className={`relative select-none ${isRubberBanding ? 'animate-rubber-band' : ''}`}
    >
      <Card
        onClick={() => openInspector(task.id)}
        className={`group relative rounded-lg p-3.5 shadow-md border-l-4 transition-all duration-150 cursor-pointer overflow-hidden ${getBorderColor()} ${
          task.isActiveSticker && !isDragging
            ? 'bg-[#2a2a2c] shadow-[0_12px_24px_-4px_rgba(6,182,212,0.25)] scale-[1.01] ring-1 ring-[#06b6d4]/60'
            : isSelected
            ? 'bg-[#201f22] ring-1 ring-[#4cd7f6] shadow-[0_0_14px_rgba(76,215,246,0.2)]'
            : isDeployed
            ? 'bg-[#201f22]/70 opacity-80 hover:opacity-100 hover:bg-[#201f22]'
            : 'bg-[#201f22] hover:bg-[#252428] hover:shadow-xl hover:-translate-y-0.5'
        }`}
      >
        {/* Active Lightning Sticker */}
        {task.isActiveSticker && (
          <div className="absolute -top-1 -right-1 px-2 py-0.5 rounded-full bg-[#06b6d4] text-[#003640] font-mono text-[9px] font-bold shadow-md uppercase tracking-wider flex items-center gap-0.5 z-10">
            <Zap className="w-2.5 h-2.5 fill-current" />
            <span>Active</span>
          </div>
        )}

        {/* Rubber-band rollback alert indicator */}
        {isRubberBanding && (
          <div className="absolute inset-0 bg-[#93000a]/20 border border-[#ffb4ab] rounded-lg pointer-events-none flex items-center justify-center">
            <span className="font-mono text-[11px] font-bold text-[#ffb4ab] bg-[#0e0e10]/90 px-2 py-0.5 rounded shadow">
              ROLLBACK NETCODE
            </span>
          </div>
        )}

        {/* Card Header: Drag grip, Tags, Task Code */}
        <div className="flex items-start gap-1.5 mb-1.5">
          <div
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing p-0.5 -ml-1 text-[#869397] hover:text-[#4cd7f6] transition-colors"
            title="Drag task"
          >
            <GripVertical className="w-4 h-4 opacity-50 group-hover:opacity-100" />
          </div>

          <div className="flex-1 flex flex-wrap gap-1 items-center">
            {task.tags.map((tag) => {
              const isUrgent = tag.toLowerCase().includes('urgent') || tag.toLowerCase().includes('bugfix');
              const isCrit = tag.toLowerCase().includes('critical') || tag.toLowerCase().includes('kinetic');
              return (
                <span
                  key={tag}
                  className={`font-mono text-[9px] px-1.5 py-0.5 rounded uppercase font-semibold tracking-wider ${
                    isUrgent
                      ? 'bg-[#93000a]/25 text-[#ffb4ab] border border-[#ffb4ab]/30'
                      : isCrit
                      ? 'bg-[#06b6d4]/15 text-[#4cd7f6] border border-[#06b6d4]/30'
                      : 'bg-[#353437] text-[#bcc9cd]'
                  }`}
                >
                  {tag}
                </span>
              );
            })}

            {task.priority && (
              <span className="font-mono text-[9px] px-1.5 py-0.5 rounded bg-[#353437] text-[#869397] font-semibold uppercase">
                {task.priority}
              </span>
            )}
          </div>

          <span className="font-mono text-[10px] text-[#869397] group-hover:text-[#4cd7f6] transition-colors">
            {task.code}
          </span>
        </div>

        {/* Card Title */}
        <h3
          className={`font-medium text-xs md:text-sm text-[#e5e1e4] leading-snug mb-1.5 line-clamp-2 ${
            isDeployed ? 'line-through text-[#869397]' : ''
          }`}
        >
          {task.title}
        </h3>

        {/* Subtitle / Description if present */}
        {task.subtitle && !isDeployed && (
          <p className="font-sans text-[11px] text-[#869397] line-clamp-1 mb-2 leading-tight">
            {task.subtitle}
          </p>
        )}

        {/* Subtasks Progress Bar (like KT-1042) */}
        {task.subtasks && !isDeployed && (
          <div className="space-y-1 mb-2 bg-[#1c1b1d] p-1.5 rounded border border-[#3d494c]/20">
            <div className="flex justify-between text-[10px] font-mono">
              <span className="text-[#bcc9cd]">
                Subtasks ({task.subtasks.completed}/{task.subtasks.total})
              </span>
              <span className="text-[#4cd7f6] font-bold">
                {Math.round((task.subtasks.completed / task.subtasks.total) * 100)}%
              </span>
            </div>
            <div className="w-full h-1 bg-[#353437] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#06b6d4] rounded-full transition-all duration-300"
                style={{
                  width: `${Math.round((task.subtasks.completed / task.subtasks.total) * 100)}%`,
                }}
              />
            </div>
          </div>
        )}

        {/* PR badge / Review signoff info */}
        {task.pr && (
          <div className="flex items-center gap-1.5 mb-2 text-[10px] font-mono text-[#bcc9cd]">
            <GitPullRequest className="w-3 h-3 text-[#4cd7f6]" />
            <span>Waiting 1 reviewer signoff</span>
          </div>
        )}

        {/* Card Footer: Engineers & Deadline */}
        <div className="flex items-center justify-between pt-1.5 border-t border-[#3d494c]/20">
          {/* Engineer Avatar circles */}
          <div className="flex items-center -space-x-1.5">
            {task.engineers.map((eng) => (
              <div
                key={eng.id}
                title={`${eng.name} (${eng.role})`}
                className={`w-5 h-5 rounded-full text-[9px] font-mono font-semibold flex items-center justify-center ring-1 ring-[#131315] ${eng.bgClass} ${eng.textClass}`}
              >
                {eng.initials}
              </div>
            ))}
          </div>

          {/* Deadline Countdown Pill */}
          {task.deadline && (
            <div className={`flex items-center gap-1 font-mono text-[10px] ${deadlineInfo.text}`}>
              <DeadlineIcon className="w-3 h-3" />
              <span>{task.deadline}</span>
            </div>
          )}
        </div>
      </Card>
    </motion.div>
  );
};
