import React, { useState, useEffect } from 'react';
import { useBoardStore } from '../store/useBoardStore';
import { ColumnId, Priority, Task } from '../types';
import { sound } from '../utils/sound';
import { ENGINEERS } from '../data/initialData';
import { 
  X, 
  Share2, 
  Maximize2, 
  Minimize2, 
  Calendar, 
  Bold, 
  Italic, 
  Code, 
  Link, 
  CheckSquare, 
  History, 
  Archive, 
  Plus, 
  Check, 
  Eye, 
  Edit3,
  Sparkles
} from 'lucide-react';

export const TaskInspector: React.FC = () => {
  const { 
    isInspectorOpen, 
    closeInspector, 
    activeTaskId, 
    tasks, 
    updateTask, 
    archiveTask 
  } = useBoardStore();

  const task = activeTaskId ? tasks[activeTaskId] : null;

  // Local editable draft state
  const [title, setTitle] = useState('');
  const [columnId, setColumnId] = useState<ColumnId>('in_progress');
  const [priority, setPriority] = useState<Priority>('P0');
  const [deadline, setDeadline] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [missionSpec, setMissionSpec] = useState('');
  const [newTagInput, setNewTagInput] = useState('');
  const [isAddingTag, setIsAddingTag] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [savedFeedback, setSavedFeedback] = useState(false);
  const [showDeadlinePicker, setShowDeadlinePicker] = useState(false);

  // Sync draft state when selected task changes
  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setColumnId(task.columnId);
      setPriority(task.priority);
      setDeadline(task.deadline || 'Tomorrow, 18:00');
      setTags([...task.tags]);
      setMissionSpec(task.missionSpec || '');
      setSavedFeedback(false);
    }
  }, [task]);

  if (!isInspectorOpen || !task) {
    return null;
  }

  const handleSave = () => {
    sound.playClick();
    const priorityLabels: Record<Priority, string> = {
      P0: 'P0 - Critical Core',
      P1: 'P1 - High',
      P2: 'P2 - Elevated',
      P3: 'P3 - Standard',
    };

    updateTask(task.id, {
      title,
      columnId,
      priority,
      priorityLabel: priorityLabels[priority],
      deadline,
      tags,
      missionSpec,
    });

    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 2000);
  };

  const handleAddTag = () => {
    if (newTagInput.trim() && !tags.includes(newTagInput.trim())) {
      setTags([...tags, newTagInput.trim()]);
      setNewTagInput('');
      setIsAddingTag(false);
      sound.playClick();
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
    sound.playClick();
  };

  const handleToggleEngineer = (engId: string) => {
    const engineer = ENGINEERS[engId];
    if (!engineer) return;
    const exists = task.engineers.some((e) => e.id === engId);
    let updatedEngs;
    if (exists) {
      if (task.engineers.length > 1) {
        updatedEngs = task.engineers.filter((e) => e.id !== engId);
      } else {
        return; // Keep at least one
      }
    } else {
      updatedEngs = [...task.engineers, engineer];
    }
    updateTask(task.id, { engineers: updatedEngs });
    sound.playClick();
  };

  const insertMarkdown = (prefix: string, suffix: string = '') => {
    setMissionSpec((prev) => prev + `\n${prefix} Checklist item${suffix}`);
  };

  return (
    <aside
      className={`fixed top-16 right-0 bottom-0 bg-[#0e0e10]/95 backdrop-blur-2xl border-l border-[#3d494c]/40 shadow-[-16px_0_36px_rgba(0,0,0,0.8)] z-50 flex flex-col transition-all duration-300 ${
        isFullScreen ? 'w-full md:w-3/4 max-w-4xl' : 'w-full md:w-[460px]'
      }`}
    >
      {/* Inspector Header */}
      <div className="p-3.5 border-b border-[#3d494c]/30 flex items-center justify-between bg-[#1c1b1d]/60">
        <div className="flex items-center gap-2.5">
          <span className="font-mono text-xs px-2 py-0.5 rounded bg-[#06b6d4]/20 text-[#4cd7f6] font-bold">
            {task.code}
          </span>
          <div className="flex items-center gap-1 text-[#bcc9cd] font-mono text-[10px]">
            <span className="w-2 h-2 rounded-full bg-[#4cd7f6] animate-pulse"></span>
            <span>LIVE RECORD</span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              navigator.clipboard?.writeText(window.location.href);
              sound.playClick();
            }}
            className="w-8 h-8 rounded flex items-center justify-center text-[#869397] hover:text-[#e5e1e4] hover:bg-[#2a2a2c] transition-colors"
            title="Share / Copy Entity URL"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsFullScreen(!isFullScreen)}
            className="w-8 h-8 rounded flex items-center justify-center text-[#869397] hover:text-[#e5e1e4] hover:bg-[#2a2a2c] transition-colors"
            title={isFullScreen ? 'Exit Full Screen' : 'Full Screen Expanded'}
          >
            {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={closeInspector}
            className="w-8 h-8 rounded flex items-center justify-center text-[#869397] hover:text-[#ffb4ab] hover:bg-[#2a2a2c] transition-colors"
            title="Close Panel (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Inspector Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Title Field with Cyber Focus Ring */}
        <div className="space-y-1">
          <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
            Node Title
          </label>
          <textarea
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            rows={2}
            className="w-full bg-[#1c1b1d] text-[#e5e1e4] font-medium text-sm p-2.5 rounded-lg border border-[#3d494c]/40 focus:border-[#4cd7f6] focus:ring-1 focus:ring-[#4cd7f6] outline-none transition-all resize-none"
          />
        </div>

        {/* Quick Metadata Attribute Grid */}
        <div className="grid grid-cols-2 gap-2.5 bg-[#1c1b1d] p-3 rounded-xl border border-[#3d494c]/30">
          {/* Zone Status */}
          <div className="space-y-1">
            <span className="font-mono text-[10px] text-[#869397] uppercase tracking-wider block">
              Zone Status
            </span>
            <select
              value={columnId}
              onChange={(e) => setColumnId(e.target.value as ColumnId)}
              className="w-full bg-[#201f22] text-[#e5e1e4] font-mono text-xs px-2 py-1.5 rounded border border-[#3d494c]/40 focus:border-[#4cd7f6] outline-none cursor-pointer"
            >
              <option value="backlog">Backlog</option>
              <option value="in_progress">In Progress</option>
              <option value="review">Review & QA</option>
              <option value="deployed">Deployed</option>
            </select>
          </div>

          {/* Priority */}
          <div className="space-y-1">
            <span className="font-mono text-[10px] text-[#869397] uppercase tracking-wider block">
              Priority
            </span>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
              className="w-full bg-[#201f22] text-[#ffb690] font-mono text-xs px-2 py-1.5 rounded border border-[#3d494c]/40 focus:border-[#ffb690] outline-none cursor-pointer font-semibold"
            >
              <option value="P3">P3 - Standard</option>
              <option value="P2">P2 - Elevated</option>
              <option value="P1">P1 - High</option>
              <option value="P0">P0 - Critical Core</option>
            </select>
          </div>

          {/* Assignees Area */}
          <div className="space-y-1">
            <span className="font-mono text-[10px] text-[#869397] uppercase tracking-wider block">
              Engineers
            </span>
            <div className="flex items-center gap-1.5 bg-[#201f22] p-1 rounded border border-[#3d494c]/40 flex-wrap">
              {Object.values(ENGINEERS).map((eng) => {
                const isAssigned = task.engineers.some((e) => e.id === eng.id);
                return (
                  <button
                    key={eng.id}
                    onClick={() => handleToggleEngineer(eng.id)}
                    title={`${eng.name} (${eng.role}) - ${isAssigned ? 'Assigned' : 'Click to assign'}`}
                    className={`w-5 h-5 rounded-full text-[9px] font-mono font-semibold flex items-center justify-center transition-all ${
                      isAssigned
                        ? `${eng.bgClass} ${eng.textClass} ring-1 ring-white/40 scale-105`
                        : 'bg-[#2a2a2c] text-[#869397] opacity-40 hover:opacity-80'
                    }`}
                  >
                    {eng.initials}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sprint Deadline Picker */}
          <div className="space-y-1 relative">
            <span className="font-mono text-[10px] text-[#869397] uppercase tracking-wider block">
              Sprint Deadline
            </span>
            <button
              onClick={() => setShowDeadlinePicker(!showDeadlinePicker)}
              className="w-full flex items-center justify-between bg-[#201f22] px-2 py-1.5 rounded border border-[#3d494c]/40 text-[#ffb690] font-mono text-xs hover:border-[#ffb690] transition-colors"
            >
              <div className="flex items-center gap-1 truncate">
                <Calendar className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{deadline}</span>
              </div>
              <span className="w-1.5 h-1.5 rounded-full bg-[#ffb690] animate-ping flex-shrink-0"></span>
            </button>

            {/* Quick Deadline Selector Popover */}
            {showDeadlinePicker && (
              <div className="absolute top-full left-0 right-0 mt-1 p-2 rounded bg-[#1c1b1d] border border-[#3d494c]/60 shadow-xl z-20 space-y-1 font-mono text-[11px]">
                {['18h left', 'Tomorrow, 18:00', '3d left', '5d left', 'Overdue (4h)', 'Production'].map((opt) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setDeadline(opt);
                      setShowDeadlinePicker(false);
                    }}
                    className="w-full text-left px-2 py-1 rounded hover:bg-[#2a2a2c] text-[#e5e1e4] flex items-center justify-between"
                  >
                    <span>{opt}</span>
                    {deadline === opt && <Check className="w-3 h-3 text-[#4cd7f6]" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Active Classification Tags */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
              Active Classification Tags
            </label>
            <button
              onClick={() => setIsAddingTag(!isAddingTag)}
              className="font-mono text-[10px] text-[#4cd7f6] hover:underline cursor-pointer flex items-center gap-0.5"
            >
              <Plus className="w-3 h-3" />
              <span>New Tag</span>
            </button>
          </div>

          {isAddingTag && (
            <div className="flex items-center gap-1 mb-1.5">
              <input
                type="text"
                value={newTagInput}
                onChange={(e) => setNewTagInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
                placeholder="Tag name..."
                className="bg-[#1c1b1d] text-xs px-2 py-1 rounded border border-[#3d494c]/60 text-[#e5e1e4] outline-none flex-1 font-mono"
                autoFocus
              />
              <button
                onClick={handleAddTag}
                className="px-2 py-1 rounded bg-[#06b6d4] text-[#003640] font-mono text-xs font-bold"
              >
                Add
              </button>
            </div>
          )}

          <div className="flex flex-wrap gap-1.5">
            {tags.map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#06b6d4]/10 text-[#4cd7f6] font-mono text-[11px] font-medium border border-[#06b6d4]/20"
              >
                <span>{tag}</span>
                <button
                  onClick={() => handleRemoveTag(tag)}
                  className="hover:text-white transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Rich Mission Specification with Tactical Markdown Toolbar */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider">
              Mission Specification
            </label>
            
            <div className="flex items-center gap-1">
              <div className="flex items-center gap-0.5 bg-[#1c1b1d] px-1.5 py-0.5 rounded border border-[#3d494c]/30 text-[#869397]">
                <button
                  onClick={() => insertMarkdown('**', '**')}
                  className="p-1 hover:text-[#4cd7f6] transition-colors"
                  title="Bold"
                >
                  <Bold className="w-3 h-3" />
                </button>
                <button
                  onClick={() => insertMarkdown('*', '*')}
                  className="p-1 hover:text-[#4cd7f6] transition-colors"
                  title="Italic"
                >
                  <Italic className="w-3 h-3" />
                </button>
                <button
                  onClick={() => insertMarkdown('`', '`')}
                  className="p-1 hover:text-[#4cd7f6] transition-colors"
                  title="Inline Code"
                >
                  <Code className="w-3 h-3" />
                </button>
                <button
                  onClick={() => insertMarkdown('- [ ] ')}
                  className="p-1 hover:text-[#4cd7f6] transition-colors"
                  title="Add Checklist"
                >
                  <CheckSquare className="w-3 h-3" />
                </button>
              </div>

              <button
                onClick={() => setIsPreviewMode(!isPreviewMode)}
                className={`p-1 rounded text-xs font-mono flex items-center gap-1 border border-[#3d494c]/30 ${
                  isPreviewMode ? 'bg-[#06b6d4]/20 text-[#4cd7f6]' : 'text-[#869397] hover:text-[#e5e1e4]'
                }`}
                title="Toggle Markdown Preview"
              >
                {isPreviewMode ? <Edit3 className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-[#3d494c]/40 bg-[#1c1b1d] overflow-hidden">
            {isPreviewMode ? (
              <div className="p-3 font-sans text-xs text-[#e5e1e4] leading-relaxed whitespace-pre-wrap min-h-[120px]">
                {missionSpec}
              </div>
            ) : (
              <textarea
                value={missionSpec}
                onChange={(e) => setMissionSpec(e.target.value)}
                rows={5}
                placeholder="Enter operational notes, acceptance parameters..."
                className="w-full bg-transparent p-2.5 font-sans text-xs text-[#e5e1e4] outline-none resize-none leading-relaxed placeholder-[#869397] font-mono"
              />
            )}
            <div className="bg-[#201f22] px-3 py-1 border-t border-[#3d494c]/20 flex items-center justify-between text-[10px] font-mono text-[#869397]">
              <span>Markdown supported</span>
              <span>Last synchronized 3m ago</span>
            </div>
          </div>
        </div>

        {/* Realtime Audit Timeline / Micro-logs */}
        <div className="space-y-1.5 pt-1">
          <label className="font-mono text-[10px] text-[#869397] uppercase tracking-wider flex items-center gap-1">
            <History className="w-3.5 h-3.5" />
            <span>Telemetry & Audit Log</span>
          </label>

          <div className="relative pl-4 space-y-3 before:content-[''] before:absolute before:left-1 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#3d494c]/30">
            {task.auditLog.map((log) => (
              <div key={log.id} className="relative flex items-start gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full absolute -left-[17px] top-1 ring-4 ring-[#0e0e10] ${
                    log.type === 'commit'
                      ? 'bg-[#06b6d4]'
                      : log.type === 'state'
                      ? 'bg-[#ec6a06]'
                      : 'bg-[#869397]'
                  }`}
                />
                <div>
                  <p className="font-sans text-xs text-[#e5e1e4]">
                    <strong className={`font-semibold ${log.userColor}`}>{log.user}</strong>{' '}
                    {log.action}{' '}
                    {log.commitHash && (
                      <code className="bg-[#2a2a2c] px-1 rounded text-[#4cd7f6] font-mono text-[10px]">
                        {log.commitHash}
                      </code>
                    )}{' '}
                    {log.highlightText && (
                      <span className="text-[#869397]">{log.highlightText}</span>
                    )}
                  </p>
                  <span className="font-mono text-[10px] text-[#869397]">{log.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Inspector Footer Action Bar */}
      <div className="p-3.5 border-t border-[#3d494c]/30 bg-[#1c1b1d] flex items-center justify-between">
        <button
          onClick={() => {
            if (confirm(`Archive ${task.code}?`)) {
              archiveTask(task.id);
            }
          }}
          className="px-2.5 py-1.5 rounded bg-[#353437] text-[#ffb4ab] hover:bg-[#93000a]/30 font-mono text-xs transition-colors flex items-center gap-1 cursor-pointer"
        >
          <Archive className="w-3.5 h-3.5" />
          <span>Archive</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={closeInspector}
            className="px-3 py-1.5 rounded bg-[#2a2a2c] text-[#e5e1e4] hover:bg-[#353437] font-mono text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-1.5 rounded bg-[#06b6d4] text-[#003640] font-mono text-xs font-semibold hover:opacity-95 shadow-[0_0_12px_rgba(6,182,212,0.4)] transition-all cursor-pointer flex items-center gap-1"
          >
            {savedFeedback ? <Check className="w-3.5 h-3.5" /> : null}
            <span>{savedFeedback ? 'Saved!' : 'Save Entity'}</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
