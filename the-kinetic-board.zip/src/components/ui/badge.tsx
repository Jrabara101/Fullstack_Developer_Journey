import * as React from 'react';
import { cn } from '../../lib/utils';

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
  variant?: 'default' | 'secondary' | 'outline' | 'destructive' | 'cyan' | 'orange' | 'amber' | 'muted';
}

export function Badge({
  className,
  variant = 'default',
  ...props
}: BadgeProps) {
  const variantStyles = {
    default: 'bg-[#06b6d4]/15 text-[#4cd7f6] border border-[#06b6d4]/30',
    secondary: 'bg-[#ec6a06]/15 text-[#ffb690] border border-[#ec6a06]/30',
    outline: 'border border-[#3d494c] text-[#bcc9cd] bg-transparent',
    destructive: 'bg-[#93000a]/20 text-[#ffb4ab] border border-[#ffb4ab]/30',
    cyan: 'bg-[#06b6d4]/20 text-[#4cd7f6] border border-[#06b6d4]/40',
    orange: 'bg-[#ec6a06]/20 text-[#ffb690] border border-[#ec6a06]/40',
    amber: 'bg-[#ffb690]/15 text-[#ffb690]',
    muted: 'bg-[#353437] text-[#bcc9cd] border border-[#3d494c]/50',
  };

  return (
    <div
      className={cn(
        'inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-mono font-semibold tracking-wider uppercase transition-colors',
        variantStyles[variant],
        className
      )}
      {...props}
    />
  );
}
