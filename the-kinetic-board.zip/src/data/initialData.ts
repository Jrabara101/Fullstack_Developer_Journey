import { Column, ColumnId, Engineer, Task } from '../types';

export const ENGINEERS: Record<string, Engineer> = {
  KT: { id: 'KT', initials: 'KT', name: 'Kaelen Thorne', role: 'Lead Architect', bgClass: 'bg-[#06b6d4]', textClass: 'text-[#003640]' },
  AX: { id: 'AX', initials: 'AX', name: 'Aria Xavier', role: 'Systems Engineer', bgClass: 'bg-[#ec6a06]', textClass: 'text-[#341100]' },
  RN: { id: 'RN', initials: 'RN', name: 'Riku Nakamura', role: 'UI/UX Shader Dev', bgClass: 'bg-[#4cd7f6]', textClass: 'text-[#001f26]' },
  VX: { id: 'VX', initials: 'VX', name: 'Vesper Vance', role: 'Telemetry Specialist', bgClass: 'bg-[#2a2a2c]', textClass: 'text-[#4cd7f6]' },
  DA: { id: 'DA', initials: 'DA', name: 'Dante Albright', role: 'Backend Core Dev', bgClass: 'bg-[#353437]', textClass: 'text-[#ffb690]' },
  SK: { id: 'SK', initials: 'SK', name: 'Sora Kuroda', role: 'Security Auditor', bgClass: 'bg-[#2a2a2c]', textClass: 'text-[#e5e1e4]' },
  ML: { id: 'ML', initials: 'ML', name: 'Mira Lin', role: 'Performance Tester', bgClass: 'bg-[#93000a]', textClass: 'text-[#ffdad6]' },
};

export const INITIAL_TASKS: Record<string, Task> = {
  'KT-1082': {
    id: 'KT-1082',
    code: '#KT-1082',
    title: 'Sync vector telemetry pipelines for real-time WebSocket state distribution',
    subtitle: 'Implement dynamic delta payloads and throttle bursts across distributed nodes.',
    tags: ['API Engine', 'P2'],
    priority: 'P2',
    priorityLabel: 'P2 - Elevated',
    columnId: 'backlog',
    deadline: '3d left',
    deadlineType: 'normal',
    engineers: [ENGINEERS.VX, ENGINEERS.DA],
    missionSpec: `## Telemetry Sync Protocol
- [x] Integrate binary serializer for positional deltas
- [ ] Implement token bucket algorithm with max burst rate 120 msg/sec
- [ ] Connect fallback WebSocket endpoint for legacy agents`,
    auditLog: [
      { id: '1', user: 'VX', userColor: 'text-[#4cd7f6]', action: 'drafted pipeline specifications', time: '1 day ago', type: 'state' },
      { id: '2', user: 'DA', userColor: 'text-[#ffb690]', action: 'assigned to Backlog queue', time: '2 days ago', type: 'created' },
    ],
    createdAt: '2026-09-12',
    updatedAt: '2026-09-13',
  },
  'KT-1089': {
    id: 'KT-1089',
    code: '#KT-1089',
    title: 'Audit OAuth2 session revival with biometric security tokens',
    subtitle: 'Evaluate multi-factor replay protection on session timeout restoration.',
    tags: ['Core'],
    priority: 'P3',
    priorityLabel: 'P3 - Standard',
    columnId: 'backlog',
    deadline: '5d left',
    deadlineType: 'normal',
    engineers: [ENGINEERS.SK],
    missionSpec: `## Security Acceptance Tests
- [x] Biometric credential pass-through validation
- [ ] Secure enclave key rotation test suite
- [ ] Zero storage of raw tokens in LocalStorage`,
    auditLog: [
      { id: '1', user: 'SK', userColor: 'text-[#e5e1e4]', action: 'initiated threat modeling review', time: '3 days ago', type: 'created' },
    ],
    createdAt: '2026-09-11',
    updatedAt: '2026-09-12',
  },
  'KT-1094': {
    id: 'KT-1094',
    code: '#KT-1094',
    title: 'Update tactical HUD token definitions for high-DPI displays',
    subtitle: 'Normalize subpixel grid alignment and edge glow radiuses for Retina viewports.',
    tags: ['Design System', 'P3'],
    priority: 'P3',
    priorityLabel: 'P3 - Standard',
    columnId: 'backlog',
    deadline: 'Jun 24',
    deadlineType: 'normal',
    engineers: [ENGINEERS.RN],
    missionSpec: `## HUD Scaling Checklist
- [x] Export 2x and 3x vector sprite definitions
- [ ] Verify chromatic aberration shaders in Dark Canvas mode
- [ ] Calibrate hairline stroke widths (1px vs 1.25px)`,
    auditLog: [
      { id: '1', user: 'RN', userColor: 'text-[#4cd7f6]', action: 'created design token draft', time: '4 days ago', type: 'created' },
    ],
    createdAt: '2026-09-10',
    updatedAt: '2026-09-11',
  },
  'KT-1042': {
    id: 'KT-1042',
    code: '#KT-1042',
    title: 'Architect WebGL fluid micro-mesh simulation node for HUD viewport',
    subtitle: 'Implement vertex buffer ping-pong textures for 60fps dynamic physics ripples across reactive dashboards.',
    tags: ['Kinetic Core', 'WebGL Simulation', 'Performance', 'HUD Elements'],
    priority: 'P0',
    priorityLabel: 'P0 - Critical Core',
    columnId: 'in_progress',
    deadline: '18h left',
    deadlineType: 'urgent',
    engineers: [ENGINEERS.KT, ENGINEERS.AX],
    isActiveSticker: true,
    subtasks: { completed: 7, total: 9 },
    missionSpec: `## Acceptance Criteria
- [x] Zero allocations inside the 60fps render loop
- [x] Integrate dual ping-pong Framebuffer Objects
- [ ] Fallback gracefully to WebGL1 when Float32 textures are unavailable on integrated GPUs
- [ ] Implement spring momentum dampening token values`,
    auditLog: [
      { id: '1', user: 'KT (Lead)', userColor: 'text-[#06b6d4]', action: 'pushed commit', commitHash: 'f79a0b2', time: '12 minutes ago', type: 'commit', highlightText: 'to origin/kinetic-mesh' },
      { id: '2', user: 'AX', userColor: 'text-[#ffb690]', action: 'modified state to In Progress from Backlog', time: '2 hours ago', type: 'state' },
      { id: '3', user: 'System', userColor: 'text-[#869397]', action: 'assigned priority level P0 Critical', time: '5 hours ago', type: 'priority' },
    ],
    createdAt: '2026-09-08',
    updatedAt: '2026-09-14',
  },
  'KT-1048': {
    id: 'KT-1048',
    code: '#KT-1048',
    title: 'Refactor Board.tsx flex lanes into virtualized horizontal snap containers',
    subtitle: 'Enable momentum horizontal touch scrolling with magnetic snap points for columns.',
    tags: ['Frontend', 'P1'],
    priority: 'P1',
    priorityLabel: 'P1 - High',
    columnId: 'in_progress',
    deadline: 'Tomorrow',
    deadlineType: 'warning',
    engineers: [ENGINEERS.RN],
    missionSpec: `## Virtualization Parameters
- [x] Smooth CSS scroll-snap integration
- [ ] Keyboard navigation arrow hotkeys
- [ ] Lazy render off-screen cards during drag operations`,
    auditLog: [
      { id: '1', user: 'RN', userColor: 'text-[#4cd7f6]', action: 're-routed component props', time: '3 hours ago', type: 'state' },
    ],
    createdAt: '2026-09-09',
    updatedAt: '2026-09-14',
  },
  'KT-1051': {
    id: 'KT-1051',
    code: '#KT-1051',
    title: 'Memory leak when unmounting canvas contexts during high frequency layout pivots',
    subtitle: 'Garbage collector stalls when WebGL contexts fail to release renderbuffers properly.',
    tags: ['Bugfix', 'Urgent'],
    priority: 'P0',
    priorityLabel: 'P0 - Critical Core',
    columnId: 'in_progress',
    deadline: 'Overdue (4h)',
    deadlineType: 'overdue',
    engineers: [ENGINEERS.ML],
    missionSpec: `## Fix Steps
- [x] Hook into componentWillUnmount / React cleanup ref
- [ ] Call loseContext extension explicitly
- [ ] Verify heap allocation profiler drops back to baseline`,
    auditLog: [
      { id: '1', user: 'ML', userColor: 'text-[#ffb4ab]', action: 'marked as Overdue blocker', time: '4 hours ago', type: 'priority' },
    ],
    createdAt: '2026-09-13',
    updatedAt: '2026-09-14',
  },
  'KT-1060': {
    id: 'KT-1060',
    code: '#KT-1060',
    title: 'Shader bloom pass optimization for low-tier hardware profiles',
    subtitle: 'Downsample bloom buffers to quarter-res and apply Gaussian blur approximations.',
    tags: ['WebGL'],
    priority: 'P2',
    priorityLabel: 'P2 - Elevated',
    columnId: 'in_progress',
    deadline: '2d left',
    deadlineType: 'normal',
    engineers: [ENGINEERS.KT],
    missionSpec: `## Shader Benchmark
- [x] Test on Intel Iris 6100 iGPU
- [ ] Max frametime target: 16.6ms at 1080p`,
    auditLog: [
      { id: '1', user: 'KT', userColor: 'text-[#06b6d4]', action: 'reduced shader iterations', time: '1 day ago', type: 'commit' },
    ],
    createdAt: '2026-09-12',
    updatedAt: '2026-09-13',
  },
  'KT-1031': {
    id: 'KT-1031',
    code: '#KT-1031',
    title: 'End-to-end cryptographic envelope signing for kinetic dispatch events',
    subtitle: 'Ensure event verification payloads cannot be tampered with in transit.',
    tags: ['Security', 'PR #204'],
    priority: 'P1',
    priorityLabel: 'P1 - High',
    columnId: 'review',
    deadline: 'Today',
    deadlineType: 'warning',
    engineers: [ENGINEERS.AX, ENGINEERS.RN],
    pr: 'PR #204',
    missionSpec: `## Review Checklist
- [x] ECDSA key signature verification
- [x] Replay attack nonce expiration
- [ ] Waiting for second reviewer signoff`,
    auditLog: [
      { id: '1', user: 'AX', userColor: 'text-[#ffb690]', action: 'submitted PR #204 for review', time: '4 hours ago', type: 'state' },
    ],
    createdAt: '2026-09-07',
    updatedAt: '2026-09-14',
  },
  'KT-1039': {
    id: 'KT-1039',
    code: '#KT-1039',
    title: 'Synthetic latency injection tests across clustered multi-tenant brokers',
    subtitle: 'Measure client prediction rubber-banding tolerance under 250ms packet jitter.',
    tags: ['Perf'],
    priority: 'P2',
    priorityLabel: 'P2 - Elevated',
    columnId: 'review',
    deadline: 'Tomorrow',
    deadlineType: 'warning',
    engineers: [ENGINEERS.KT],
    missionSpec: `## Test Scenarios
- [x] 50ms smooth ping simulation
- [x] 250ms jitter packet drop simulation
- [ ] Validate optimistic state machine rollback trigger`,
    auditLog: [
      { id: '1', user: 'KT', userColor: 'text-[#06b6d4]', action: 'ran Chaos Monkey stress suite', time: '6 hours ago', type: 'commit' },
    ],
    createdAt: '2026-09-08',
    updatedAt: '2026-09-14',
  },
  'KT-1014': {
    id: 'KT-1014',
    code: '#KT-1014',
    title: 'Zero-latency audio reactive feedback ticks on task state changes',
    subtitle: 'Native Web Audio API synthesizer for tactile mechanical and chord sound effects.',
    tags: ['Prod v4.2.0'],
    priority: 'P3',
    priorityLabel: 'P3 - Standard',
    columnId: 'deployed',
    deadline: 'Production',
    deadlineType: 'done',
    engineers: [ENGINEERS.KT],
    missionSpec: `## Completed Deployment
- [x] AudioContext lazy initialization
- [x] Sound toggle persist in preferences
- [x] Zero external MP3 asset payload`,
    auditLog: [
      { id: '1', user: 'System', userColor: 'text-[#06b6d4]', action: 'promoted to Deployed Prod v4.2.0', time: '2 days ago', type: 'state' },
    ],
    createdAt: '2026-09-01',
    updatedAt: '2026-09-12',
  },
  'KT-1020': {
    id: 'KT-1020',
    code: '#KT-1020',
    title: 'Automated canary deployments via Kubernetes ingress orchestrator',
    subtitle: 'Progressive traffic routing with automatic rollback if error rate exceeds 0.05%.',
    tags: ['Infra'],
    priority: 'P2',
    priorityLabel: 'P2 - Elevated',
    columnId: 'deployed',
    deadline: 'Production',
    deadlineType: 'done',
    engineers: [ENGINEERS.DA],
    missionSpec: `## Production Verification
- [x] ServiceMesh traffic split 10% -> 50% -> 100%
- [x] Health checks verified on cluster eu-west-1`,
    auditLog: [
      { id: '1', user: 'DA', userColor: 'text-[#ffb690]', action: 'verified canary stability', time: '3 days ago', type: 'state' },
    ],
    createdAt: '2026-09-03',
    updatedAt: '2026-09-11',
  },
  'KT-1025': {
    id: 'KT-1025',
    code: '#KT-1025',
    title: 'Integrate Prometheus metrics scraper with Grafana HUD views',
    subtitle: 'Expose Node.js process telemetry, event loop lag, and memory heap gauges.',
    tags: ['Telemetry'],
    priority: 'P2',
    priorityLabel: 'P2 - Elevated',
    columnId: 'deployed',
    deadline: 'Production',
    deadlineType: 'done',
    engineers: [ENGINEERS.VX],
    missionSpec: `## Monitoring
- [x] Scrape interval 5s
- [x] Alert webhook configured for high memory threshold`,
    auditLog: [
      { id: '1', user: 'VX', userColor: 'text-[#4cd7f6]', action: 'dashboards live in Grafana', time: '4 days ago', type: 'state' },
    ],
    createdAt: '2026-09-04',
    updatedAt: '2026-09-10',
  },
};

export const INITIAL_COLUMNS: Record<ColumnId, Column> = {
  backlog: {
    id: 'backlog',
    title: 'Backlog',
    icon: 'inventory_2',
    taskIds: ['KT-1082', 'KT-1089', 'KT-1094'],
    accentColor: '#869397',
    borderColor: 'border-[#3d494c]/30',
    badgeBg: 'bg-[#353437]',
    badgeText: 'text-[#bcc9cd]',
    dropPlaceholder: 'Drop into Backlog',
  },
  in_progress: {
    id: 'in_progress',
    title: 'In Progress',
    icon: 'sync',
    taskIds: ['KT-1042', 'KT-1048', 'KT-1051', 'KT-1060'],
    accentColor: '#4cd7f6',
    borderColor: 'border-[#06b6d4]/30 ring-1 ring-[#06b6d4]/20',
    badgeBg: 'bg-[#06b6d4]/20',
    badgeText: 'text-[#4cd7f6]',
    dropPlaceholder: 'Drop into In Progress',
  },
  review: {
    id: 'review',
    title: 'Review & QA',
    icon: 'verified_user',
    taskIds: ['KT-1031', 'KT-1039'],
    accentColor: '#ffb690',
    borderColor: 'border-[#ec6a06]/30',
    badgeBg: 'bg-[#ec6a06]/20',
    badgeText: 'text-[#ffb690]',
    dropPlaceholder: 'Drop for QA Audit',
  },
  deployed: {
    id: 'deployed',
    title: 'Deployed',
    icon: 'check_circle',
    taskIds: ['KT-1014', 'KT-1020', 'KT-1025'],
    accentColor: '#4cd7f6',
    borderColor: 'border-[#3d494c]/30',
    badgeBg: 'bg-[#353437]',
    badgeText: 'text-[#bcc9cd]',
    dropPlaceholder: 'Drop into Deployed',
  },
};
