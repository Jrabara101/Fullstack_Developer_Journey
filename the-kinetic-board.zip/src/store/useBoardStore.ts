import { create } from 'zustand';
import { INITIAL_COLUMNS, INITIAL_TASKS } from '../data/initialData';
import { Column, ColumnId, NetcodeState, Task } from '../types';
import { sound } from '../utils/sound';

interface BoardStateSnapshot {
  columns: Record<ColumnId, Column>;
  tasks: Record<string, Task>;
}

export interface BoardState {
  columns: Record<ColumnId, Column>;
  tasks: Record<string, Task>;
  previousState: BoardStateSnapshot | null;
  
  // UI & Workspace State
  activeTaskId: string | null;
  isInspectorOpen: boolean;
  activeView: 'board' | 'list' | 'stats' | 'map';
  soundEnabled: boolean;
  isNewTaskModalOpen: boolean;
  isMetricsModalOpen: boolean;

  // Filter State
  searchQuery: string;
  activeTag: string | null;
  myTasksOnly: boolean;
  highPriorityOnly: boolean;
  dueSoonOnly: boolean;

  // Game Netcode State
  netcode: NetcodeState;

  // Actions
  setActiveTaskId: (id: string | null) => void;
  toggleInspector: () => void;
  openInspector: (taskId: string) => void;
  closeInspector: () => void;
  setActiveView: (view: 'board' | 'list' | 'stats' | 'map') => void;
  toggleSound: () => void;
  setIsNewTaskModalOpen: (open: boolean) => void;
  setIsMetricsModalOpen: (open: boolean) => void;

  // Filter Actions
  setSearchQuery: (query: string) => void;
  setActiveTag: (tag: string | null) => void;
  toggleMyTasks: () => void;
  toggleHighPriority: () => void;
  toggleDueSoon: () => void;
  resetFilters: () => void;

  // Netcode Actions
  toggleSimulateFailure: () => void;
  toggleSimulateLatency: () => void;

  // Game Engine Optimistic State Machine
  moveTaskOptimistic: (taskId: string, sourceColId: ColumnId, destColId: ColumnId, newIndex: number) => void;
  confirmMove: () => void;
  rollbackMove: (taskId?: string) => void;
  
  // Entity CRUD
  updateTask: (taskId: string, partial: Partial<Task>) => void;
  createTask: (newTask: Omit<Task, 'id' | 'code' | 'createdAt' | 'updatedAt' | 'auditLog'>) => void;
  archiveTask: (taskId: string) => void;
}

export const useBoardStore = create<BoardState>((set, get) => ({
  columns: INITIAL_COLUMNS,
  tasks: INITIAL_TASKS,
  previousState: null,

  activeTaskId: 'KT-1042',
  isInspectorOpen: true,
  activeView: 'board',
  soundEnabled: true,
  isNewTaskModalOpen: false,
  isMetricsModalOpen: false,

  searchQuery: '',
  activeTag: null,
  myTasksOnly: false,
  highPriorityOnly: false,
  dueSoonOnly: false,

  netcode: {
    isSyncing: false,
    latencyMs: 38,
    simulateFailure: false,
    simulateLatency: true,
    rubberBandingTaskId: null,
    lastSyncResult: 'idle',
  },

  setActiveTaskId: (id) => set({ activeTaskId: id }),
  toggleInspector: () => set((state) => ({ isInspectorOpen: !state.isInspectorOpen })),
  openInspector: (taskId) => {
    sound.playClick();
    set({ activeTaskId: taskId, isInspectorOpen: true });
  },
  closeInspector: () => {
    sound.playClick();
    set({ isInspectorOpen: false });
  },
  setActiveView: (view) => {
    sound.playClick();
    set({ activeView: view });
  },
  toggleSound: () => {
    const next = !get().soundEnabled;
    sound.enabled = next;
    set({ soundEnabled: next });
    if (next) sound.playClick();
  },
  setIsNewTaskModalOpen: (open) => set({ isNewTaskModalOpen: open }),
  setIsMetricsModalOpen: (open) => set({ isMetricsModalOpen: open }),

  setSearchQuery: (query) => set({ searchQuery: query }),
  setActiveTag: (tag) => set((state) => ({ activeTag: state.activeTag === tag ? null : tag })),
  toggleMyTasks: () => {
    sound.playClick();
    set((state) => ({ myTasksOnly: !state.myTasksOnly }));
  },
  toggleHighPriority: () => {
    sound.playClick();
    set((state) => ({ highPriorityOnly: !state.highPriorityOnly }));
  },
  toggleDueSoon: () => {
    sound.playClick();
    set((state) => ({ dueSoonOnly: !state.dueSoonOnly }));
  },
  resetFilters: () => set({ searchQuery: '', activeTag: null, myTasksOnly: false, highPriorityOnly: false, dueSoonOnly: false }),

  toggleSimulateFailure: () => {
    sound.playClick();
    set((state) => ({
      netcode: { ...state.netcode, simulateFailure: !state.netcode.simulateFailure }
    }));
  },
  toggleSimulateLatency: () => {
    sound.playClick();
    set((state) => ({
      netcode: { ...state.netcode, simulateLatency: !state.netcode.simulateLatency }
    }));
  },

  moveTaskOptimistic: (taskId, sourceColId, destColId, newIndex) => {
    const state = get();
    const sourceCol = state.columns[sourceColId];
    const destCol = state.columns[destColId];
    const task = state.tasks[taskId];

    if (!sourceCol || !destCol || !task) return;

    // 1. Snapshot world state for client prediction rollback
    const snapshot: BoardStateSnapshot = {
      columns: JSON.parse(JSON.stringify(state.columns)),
      tasks: JSON.parse(JSON.stringify(state.tasks)),
    };

    // 2. Calculate new spatial arrays
    const newSourceTaskIds = Array.from(sourceCol.taskIds).filter((id) => id !== taskId);
    const newDestTaskIds = sourceColId === destColId ? newSourceTaskIds : Array.from(destCol.taskIds).filter((id) => id !== taskId);
    
    // Bounds check index
    const clampedIndex = Math.max(0, Math.min(newIndex, newDestTaskIds.length));
    newDestTaskIds.splice(clampedIndex, 0, taskId);

    // 3. Mutate immediately for 0-latency UI (optimistic update)
    const updatedColumns = {
      ...state.columns,
      [sourceColId]: { ...sourceCol, taskIds: newSourceTaskIds },
      [destColId]: { ...destCol, taskIds: newDestTaskIds },
    };

    const updatedTasks = {
      ...state.tasks,
      [taskId]: {
        ...task,
        columnId: destColId,
        updatedAt: new Date().toISOString().split('T')[0],
      },
    };

    sound.playDrop();

    if (destColId === 'deployed' && sourceColId !== 'deployed') {
      sound.playSuccess();
    }

    set({
      previousState: snapshot,
      columns: updatedColumns,
      tasks: updatedTasks,
      netcode: {
        ...state.netcode,
        isSyncing: true,
        rubberBandingTaskId: null,
        lastSyncResult: 'idle',
      },
    });

    // 4. Client-Side Prediction Network Reconciliation Simulation
    const simulateLatency = state.netcode.simulateLatency;
    const latencyDelay = simulateLatency ? 420 : 60;
    const shouldFail = state.netcode.simulateFailure;

    setTimeout(() => {
      const currentState = get();
      if (shouldFail) {
        // Trigger server rejection rollback (Rubber-band back to origin)
        currentState.rollbackMove(taskId);
      } else {
        // Success -> commit state
        currentState.confirmMove();
      }
    }, latencyDelay);
  },

  confirmMove: () => {
    set((state) => ({
      previousState: null,
      netcode: {
        ...state.netcode,
        isSyncing: false,
        lastSyncResult: 'success',
        rubberBandingTaskId: null,
      },
    }));
  },

  rollbackMove: (taskId) => {
    sound.playRubberBand();
    set((state) => {
      if (!state.previousState) {
        return {
          netcode: { ...state.netcode, isSyncing: false, lastSyncResult: 'rollback' }
        };
      }
      return {
        columns: state.previousState.columns,
        tasks: state.previousState.tasks,
        previousState: null,
        netcode: {
          ...state.netcode,
          isSyncing: false,
          lastSyncResult: 'rollback',
          rubberBandingTaskId: taskId || null,
        },
      };
    });

    // Clear rubber-band highlight after animation
    setTimeout(() => {
      set((state) => ({
        netcode: { ...state.netcode, rubberBandingTaskId: null }
      }));
    }, 1200);
  },

  updateTask: (taskId, partial) => {
    set((state) => {
      const currentTask = state.tasks[taskId];
      if (!currentTask) return state;

      const newAuditLog = [...currentTask.auditLog];
      
      // If status changed, also update column taskIds
      let newColumns = state.columns;
      if (partial.columnId && partial.columnId !== currentTask.columnId) {
        const oldCol = state.columns[currentTask.columnId];
        const newCol = state.columns[partial.columnId];
        if (oldCol && newCol) {
          newColumns = {
            ...state.columns,
            [currentTask.columnId]: {
              ...oldCol,
              taskIds: oldCol.taskIds.filter((id) => id !== taskId),
            },
            [partial.columnId]: {
              ...newCol,
              taskIds: [...newCol.taskIds, taskId],
            },
          };
          newAuditLog.unshift({
            id: String(Date.now()),
            user: 'AX',
            userColor: 'text-[#ffb690]',
            action: `modified state to ${newCol.title} from ${oldCol.title}`,
            time: 'Just now',
            type: 'state',
          });
        }
      }

      if (partial.priority && partial.priority !== currentTask.priority) {
        newAuditLog.unshift({
          id: String(Date.now() + 1),
          user: 'System',
          userColor: 'text-[#869397]',
          action: `assigned priority level ${partial.priorityLabel || partial.priority}`,
          time: 'Just now',
          type: 'priority',
        });
      }

      const updatedTask: Task = {
        ...currentTask,
        ...partial,
        auditLog: newAuditLog,
        updatedAt: new Date().toISOString().split('T')[0],
      };

      return {
        columns: newColumns,
        tasks: {
          ...state.tasks,
          [taskId]: updatedTask,
        },
      };
    });
  },

  createTask: (newTaskData) => {
    const idNum = Math.floor(1000 + Math.random() * 900);
    const id = `KT-${idNum}`;
    const code = `#KT-${idNum}`;

    const newTask: Task = {
      ...newTaskData,
      id,
      code,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      auditLog: [
        {
          id: '1',
          user: 'KT (Lead)',
          userColor: 'text-[#06b6d4]',
          action: 'spawned node in workspace',
          time: 'Just now',
          type: 'created',
        },
      ],
    };

    sound.playDrop();

    set((state) => {
      const targetCol = state.columns[newTaskData.columnId] || state.columns.backlog;
      return {
        tasks: {
          ...state.tasks,
          [id]: newTask,
        },
        columns: {
          ...state.columns,
          [targetCol.id]: {
            ...targetCol,
            taskIds: [id, ...targetCol.taskIds],
          },
        },
        activeTaskId: id,
        isInspectorOpen: true,
        isNewTaskModalOpen: false,
      };
    });
  },

  archiveTask: (taskId) => {
    sound.playClick();
    set((state) => {
      const task = state.tasks[taskId];
      if (!task) return state;

      const col = state.columns[task.columnId];
      const newColumns = {
        ...state.columns,
        [task.columnId]: {
          ...col,
          taskIds: col.taskIds.filter((id) => id !== taskId),
        },
      };

      const newTasks = { ...state.tasks };
      delete newTasks[taskId];

      return {
        columns: newColumns,
        tasks: newTasks,
        activeTaskId: state.activeTaskId === taskId ? null : state.activeTaskId,
        isInspectorOpen: state.activeTaskId === taskId ? false : state.isInspectorOpen,
      };
    });
  },
}));
