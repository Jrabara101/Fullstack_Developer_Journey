export type Priority = 'P0' | 'P1' | 'P2' | 'P3';
export type ColumnId = 'backlog' | 'in_progress' | 'review' | 'deployed';

export interface Engineer {
  id: string;
  initials: string;
  name: string;
  role: string;
  bgClass: string;
  textClass: string;
}

export interface Subtasks {
  completed: number;
  total: number;
}

export interface AuditEntry {
  id: string;
  user: string;
  userColor: string;
  action: string;
  time: string;
  type: 'commit' | 'state' | 'priority' | 'created';
  commitHash?: string;
  highlightText?: string;
}

export interface Task {
  id: string;
  code: string;
  title: string;
  subtitle?: string;
  description?: string;
  tags: string[];
  priority: Priority;
  priorityLabel: string;
  columnId: ColumnId;
  deadline: string | null;
  deadlineType?: 'urgent' | 'warning' | 'normal' | 'done' | 'overdue';
  engineers: Engineer[];
  subtasks?: Subtasks;
  missionSpec: string;
  pr?: string;
  isActiveSticker?: boolean;
  auditLog: AuditEntry[];
  createdAt: string;
  updatedAt: string;
}

export interface Column {
  id: ColumnId;
  title: string;
  icon: string;
  taskIds: string[];
  accentColor: string;
  borderColor: string;
  badgeBg: string;
  badgeText: string;
  dropPlaceholder: string;
}

export interface BoardFilter {
  searchQuery: string;
  activeTag: string | null;
  myTasksOnly: boolean;
  highPriorityOnly: boolean;
  dueSoonOnly: boolean;
}

export interface NetcodeState {
  isSyncing: boolean;
  latencyMs: number;
  simulateFailure: boolean;
  simulateLatency: boolean;
  rubberBandingTaskId: string | null;
  lastSyncResult: 'idle' | 'success' | 'rollback';
}
