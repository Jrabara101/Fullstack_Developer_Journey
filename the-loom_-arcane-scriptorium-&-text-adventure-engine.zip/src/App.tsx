import React, { useEffect } from 'react';
import {
  Bug,
  FolderKanban,
  Pause,
  PenTool,
  Play,
  RotateCcw,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useAdventureStore } from './store/useAdventureStore';
import { ObservatoryScene3D } from './components/three/ObservatoryScene3D';
import { PlayTerminal } from './components/play/PlayTerminal';
import { RightTelemetryHud } from './components/play/RightTelemetryHud';
import { CreatorStudio } from './components/creator/CreatorStudio';
import { CartridgeManagerModal } from './components/modals/CartridgeManagerModal';
import { LiveDebuggerDrawer } from './components/modals/LiveDebuggerDrawer';
import { Button } from './components/ui/primitives';

export default function App() {
  const {
    mode,
    shellState,
    cartridge,
    currentRoomId,
    visitedRoomIds,
    inventoryIds,
    flags,
    turnCount,
    historyStack,
    victoryState,
    isDebuggerOpen,
    isCartridgeModalOpen,
    isMuted,
    setShellState,
    setMode,
    toggleMode,
    toggleMute,
    setDebuggerOpen,
    setCartridgeModalOpen,
    undoLastTurn,
    restartAdventure,
  } = useAdventureStore();

  // Global keyboard bindings:
  // - Enter / Space on Title screen starts adventure
  // - Space (outside input/textarea) toggles Play Mode <-> Creator Studio
  // - Ctrl+Z / Cmd+Z (outside input/textarea) rewinds last turn
  // - Escape toggles Pause modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isEditingText =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable);

      if (shellState === 'title') {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          (document.activeElement as HTMLElement | null)?.blur?.();
          setShellState('playing');
        }
        return;
      }

      if (e.key === 'Escape' && !isCartridgeModalOpen) {
        e.preventDefault();
        if (shellState === 'playing') {
          setShellState('paused');
        } else if (shellState === 'paused') {
          setShellState('playing');
        }
        return;
      }

      if (isEditingText) return;

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        undoLastTurn();
        return;
      }

      if (e.key === ' ' && shellState === 'playing') {
        e.preventDefault();
        toggleMode();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [shellState, isCartridgeModalOpen, setShellState, undoLastTurn, toggleMode]);

  const handleStartPlay = (targetMode: 'PLAY' | 'CREATE' = 'PLAY') => {
    (document.activeElement as HTMLElement | null)?.blur?.();
    setMode(targetMode);
    setShellState('playing');
  };

  return (
    <div className="w-screen h-screen overflow-hidden bg-[#080A0F] text-[#E2E8F0] flex flex-col select-none">
      {/* TITLE SCREEN STAGE: Full-Viewport 3D Clockwork Observatory Tour + Asymmetric Negative Space Lockup */}
      {shellState === 'title' && (
        <main className="relative w-full h-full overflow-hidden">
          <div className="absolute inset-0">
            <ObservatoryScene3D
              cartridge={cartridge}
              currentRoomId={currentRoomId}
              visitedRoomIds={visitedRoomIds}
              flags={flags}
              variant="title"
            />
          </div>

          {/* Measured Left Scrim for >= 4.5:1 Contrast over 3D Scene (Zero backdrop-filter) */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                'linear-gradient(90deg, rgba(8,10,15,0.92) 0%, rgba(8,10,15,0.72) 38%, rgba(8,10,15,0.05) 75%)',
            }}
          />

          <div className="relative z-10 h-full max-w-[1380px] mx-auto px-8 md:px-14 flex flex-col justify-between py-10 pointer-events-none">
            {/* Top Minimal Cartridge Emblem */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 text-xs font-mono-code text-[#94A3B8]">
                <span className="text-[#F59E0B]">ARCANE SCRIPTORIUM ENGINE</span>
                <span>·</span>
                <span>CARTRIDGE: {cartridge.title.toUpperCase()}</span>
              </div>
            </div>

            {/* Center Asymmetric Hero Lockup over Calm Negative Space */}
            <div className="max-w-[540px] space-y-6 my-auto pointer-events-auto">
              {/* Bespoke Inline SVG Horological Astrolabe & Title Lockup */}
              <svg
                viewBox="0 0 500 120"
                className="w-full max-w-[460px] h-auto"
                role="img"
                aria-label="The Loom — Clockwork Observatory"
              >
                <g fill="none" stroke="#F59E0B" strokeWidth="1.5" opacity="0.9">
                  <circle cx="48" cy="58" r="38" strokeDasharray="4 3" />
                  <circle cx="48" cy="58" r="26" />
                  <circle cx="48" cy="58" r="6" fill="#F59E0B" />
                  <path d="M48 12 L48 104 M2 58 L94 58" strokeOpacity="0.45" />
                  <polygon
                    points="48,26 54,50 48,45 42,50"
                    fill="#38BDF8"
                    stroke="none"
                  />
                </g>
                <text
                  x="106"
                  y="38"
                  fill="#F59E0B"
                  fontFamily="JetBrains Mono, monospace"
                  fontSize="11"
                  letterSpacing="3"
                >
                  INTERACTIVE FICTION STUDIO
                </text>
                <text
                  x="104"
                  y="78"
                  fill="#F8FAFC"
                  fontFamily="Newsreader, Georgia, serif"
                  fontSize="44"
                  fontWeight="600"
                >
                  The Loom
                </text>
                <text
                  x="106"
                  y="104"
                  fill="#38BDF8"
                  fontFamily="Newsreader, Georgia, serif"
                  fontStyle="italic"
                  fontSize="20"
                >
                  The Clockwork Observatory Chronicle
                </text>
              </svg>

              <p className="font-prose text-lg text-[#E2E8F0] leading-relaxed">
                {cartridge.synopsis}
              </p>

              {/* Primary CTA & Secondary Creator Action (<= 3 actions total) */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  data-start="true"
                  onClick={() => handleStartPlay('PLAY')}
                  className="px-6 py-3 rounded-lg bg-[#F59E0B] hover:bg-[#FBBF24] text-[#080A0F] font-semibold text-sm flex items-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Enter the Observatory</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleStartPlay('CREATE')}
                  className="px-5 py-3 rounded-lg bg-[#141A29] hover:bg-[#1C2539] text-[#E2E8F0] border border-[#232D42] font-medium text-sm flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <PenTool className="w-4 h-4 text-[#38BDF8]" />
                  <span>Open Creator Studio</span>
                </button>
              </div>
            </div>

            {/* Bottom Single Flat Control-Hint Line */}
            <div className="text-xs font-mono-code text-[#94A3B8]">
              Enter / Space Start Adventure · Click Highlighted Nouns or Type Commands · Space Toggle Creator Studio · Ctrl+Z Rewind Turn · Esc Pause
            </div>
          </div>
        </main>
      )}

      {/* ACTIVE WORKSPACE (PLAY RUNTIME + CREATOR STUDIO) */}
      {shellState !== 'title' && (
        <>
          {/* Global Top Studio Bar (48px Height) */}
          <header
            className={`h-12 px-4 bg-[#0D111A] border-b flex items-center justify-between gap-4 shrink-0 transition-colors ${
              mode === 'PLAY' ? 'border-[#10B981]/40' : 'border-[#38BDF8]/40'
            }`}
          >
            {/* Left: Cartridge Title & Cartridge Foundry Trigger */}
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setShellState('title')}
                className="text-sm font-semibold text-[#F8FAFC] hover:text-[#F59E0B] transition-colors truncate cursor-pointer"
                title="Return to Title Screen"
              >
                {cartridge.title}
              </button>
              <span className="text-xs text-[#64748B] hidden sm:inline">·</span>
              <span className="text-xs text-[#94A3B8] hidden sm:inline truncate">
                by {cartridge.author}
              </span>
              <button
                type="button"
                onClick={() => setCartridgeModalOpen(true)}
                className="px-2.5 py-1 text-xs font-medium rounded bg-[#141A29] hover:bg-[#1C2539] text-[#38BDF8] border border-[#232D42] flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
              >
                <FolderKanban className="w-3.5 h-3.5" />
                <span>Cartridges &amp; Seed</span>
              </button>
            </div>

            {/* Center: Tactile Mode Switcher Capsule (Write-to-Play Flight Check) */}
            <div className="flex items-center p-0.5 rounded-lg bg-[#141A29] border border-[#232D42] shrink-0">
              <button
                type="button"
                onClick={() => setMode('CREATE')}
                className={`px-3 py-1 text-xs font-medium rounded-md flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'CREATE'
                    ? 'bg-[#38BDF8] text-[#080A0F] font-semibold'
                    : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                }`}
              >
                <PenTool className="w-3 h-3" />
                <span>Creator Studio</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('PLAY')}
                className={`px-3 py-1 text-xs font-medium rounded-md flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'PLAY'
                    ? 'bg-[#10B981] text-[#080A0F] font-semibold'
                    : 'text-[#94A3B8] hover:text-[#F8FAFC]'
                }`}
              >
                <Play className="w-3 h-3" />
                <span>Play Adventure</span>
              </button>
            </div>

            {/* Right: Turn Rewind, Live State Debugger & Utility Controls */}
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs font-mono-code text-[#94A3B8] hidden md:inline mr-1">
                TURN {String(turnCount).padStart(3, '0')}
              </span>

              <button
                type="button"
                disabled={historyStack.length === 0}
                onClick={undoLastTurn}
                className="px-2.5 py-1 text-xs font-medium rounded bg-[#141A29] hover:bg-[#1C2539] disabled:opacity-40 text-[#FDE68A] border border-[#232D42] flex items-center gap-1 cursor-pointer whitespace-nowrap"
                title="Rewind 1 Turn (Ctrl+Z)"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Undo Turn</span>
              </button>

              <button
                type="button"
                onClick={() => setDebuggerOpen(!isDebuggerOpen)}
                className={`px-2.5 py-1 text-xs font-medium rounded border flex items-center gap-1 cursor-pointer whitespace-nowrap ${
                  isDebuggerOpen
                    ? 'bg-[#A855F7] text-[#080A0F] border-purple-400 font-semibold'
                    : 'bg-[#141A29] hover:bg-[#1C2539] text-[#C4B5FD] border-[#232D42]'
                }`}
              >
                <Bug className="w-3.5 h-3.5" />
                <span>Live Debugger</span>
              </button>

              <button
                type="button"
                aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
                onClick={(e) => {
                  e.currentTarget.blur();
                  toggleMute();
                }}
                className="p-1.5 rounded bg-[#141A29] hover:bg-[#1C2539] text-[#94A3B8] hover:text-[#F8FAFC] border border-[#232D42] cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>

              <button
                type="button"
                aria-label="Pause adventure"
                onClick={(e) => {
                  e.currentTarget.blur();
                  setShellState('paused');
                }}
                className="p-1.5 rounded bg-[#141A29] hover:bg-[#1C2539] text-[#94A3B8] hover:text-[#F8FAFC] border border-[#232D42] cursor-pointer"
              >
                <Pause className="w-3.5 h-3.5" />
              </button>
            </div>
          </header>

          {/* Main Synchronized Dual-Mode Viewport */}
          <main className="flex-1 flex overflow-hidden relative">
            {mode === 'PLAY' ? (
              <>
                <PlayTerminal />
                <RightTelemetryHud />
              </>
            ) : (
              <CreatorStudio />
            )}

            <LiveDebuggerDrawer />
          </main>
        </>
      )}

      {/* PAUSE MODAL (`document.body.dataset.state === 'paused'`) */}
      {shellState === 'paused' && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Adventure Paused"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
        >
          <div className="w-full max-w-md bg-[#141A29] border border-[#232D42] rounded-xl p-6 space-y-5 shadow-2xl">
            <div className="space-y-1">
              <span className="text-xs font-mono-code text-[#F59E0B] uppercase">
                CHRONOMETER SUSPENDED
              </span>
              <h2 className="text-xl font-semibold text-[#F8FAFC] font-prose">
                Expedition Paused
              </h2>
            </div>

            <div className="grid grid-cols-3 gap-2.5 font-mono-code">
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42]">
                <div className="text-[10px] text-[#64748B]">TURNS</div>
                <div className="text-lg font-semibold text-[#F8FAFC]">{turnCount}</div>
              </div>
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42]">
                <div className="text-[10px] text-[#64748B]">CHAMBERS</div>
                <div className="text-lg font-semibold text-[#38BDF8]">
                  {visitedRoomIds.length}/{Object.keys(cartridge.rooms).length}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42]">
                <div className="text-[10px] text-[#64748B]">RELICS</div>
                <div className="text-lg font-semibold text-[#10B981]">
                  {inventoryIds.length}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Button
                variant="primary"
                size="lg"
                onClick={() => setShellState('playing')}
              >
                Resume Adventure
              </Button>
              <Button
                variant="secondary"
                size="md"
                onClick={() => restartAdventure()}
              >
                Restart Cartridge
              </Button>
              <Button
                variant="outline"
                size="md"
                onClick={() => setShellState('title')}
              >
                Return to Title Screen
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* VICTORY / CHRONICLE COMPLETION MODAL (`document.body.dataset.state === 'gameover'`) */}
      {shellState === 'gameover' && victoryState && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Chronicle Fulfilled"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4"
        >
          <div className="w-full max-w-lg bg-[#141A29] border border-[#F59E0B]/60 rounded-xl p-6 space-y-5 shadow-2xl">
            <div className="space-y-1">
              <span className="text-xs font-mono-code text-[#F59E0B] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>CHRONICLE FULFILLED · {cartridge.title.toUpperCase()}</span>
              </span>
              <h2 className="text-2xl font-semibold text-[#F8FAFC] font-prose">
                {victoryState.title}
              </h2>
            </div>

            <p className="font-prose text-base text-[#E2E8F0] leading-relaxed bg-[#0D111A] p-4 rounded-lg border border-[#232D42]">
              {victoryState.epilogue.replace(/\[\/?(glow|shake|whisper)\]/g, '')}
            </p>

            <div className="grid grid-cols-3 gap-2.5 font-mono-code">
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42]">
                <div className="text-[10px] text-[#64748B]">TURNS TAKEN</div>
                <div className="text-lg font-semibold text-[#F59E0B]">
                  {victoryState.turnsTaken}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42]">
                <div className="text-[10px] text-[#64748B]">CHAMBERS MAPPED</div>
                <div className="text-lg font-semibold text-[#38BDF8]">
                  {victoryState.roomsDiscovered}/{Object.keys(cartridge.rooms).length}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42]">
                <div className="text-[10px] text-[#64748B]">RELICS HELD</div>
                <div className="text-lg font-semibold text-[#10B981]">
                  {victoryState.relicsCollected}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                data-start="true"
                onClick={() => restartAdventure()}
                className="flex-1 py-2.5 px-4 rounded-lg bg-[#F59E0B] hover:bg-[#FBBF24] text-[#080A0F] font-semibold text-xs cursor-pointer"
              >
                Play Again from Turn 1
              </button>
              <Button
                variant="secondary"
                size="md"
                onClick={() => {
                  setShellState('playing');
                  undoLastTurn();
                }}
              >
                Rewind Before Ending
              </Button>
            </div>
          </div>
        </div>
      )}

      <CartridgeManagerModal />
    </div>
  );
}
