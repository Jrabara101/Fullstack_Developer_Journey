import React, { useRef, useState } from 'react';
import {
  Compass,
  Flag,
  Layers,
  Link2,
  Lock,
  Package,
  Play,
  Plus,
  Search,
  Sparkles,
  Trash2,
  Unlock,
  ZoomIn,
  ZoomOut,
  Maximize2,
} from 'lucide-react';
import { useAdventureStore } from '../../store/useAdventureStore';
import { BiomeMood, Direction, WorldEntity } from '../../types/adventure';
import { Button } from '../ui/primitives';

const DIRECTIONS: Direction[] = ['north', 'south', 'east', 'west', 'up', 'down'];
const BIOMES: BiomeMood[] = ['sanctuary', 'arcane', 'twilight', 'crypt', 'peril'];

const BIOME_BADGE_COLORS: Record<BiomeMood, string> = {
  sanctuary: 'bg-amber-500',
  arcane: 'bg-sky-400',
  twilight: 'bg-purple-500',
  crypt: 'bg-emerald-500',
  peril: 'bg-red-500',
};

export const CreatorStudio: React.FC = () => {
  const {
    cartridge,
    selectedCreatorRoomId,
    selectedCreatorEntityId,
    flags,
    selectCreatorRoom,
    selectCreatorEntity,
    setMode,
    updateRoomNode,
    updateRoomPosition,
    addRoomNode,
    deleteRoomNode,
    upsertRoomExit,
    removeRoomExit,
    addRoomChoice,
    updateRoomChoice,
    removeRoomChoice,
    upsertWorldEntity,
    deleteWorldEntity,
    toggleRoomEntity,
    createFlag,
    toggleFlag,
  } = useAdventureStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [inspectorSection, setInspectorSection] = useState<'prose' | 'exits' | 'entities' | 'choices'>('prose');
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 20, y: 20 });

  // Node dragging state
  const [draggingRoomId, setDraggingRoomId] = useState<string | null>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });
  const isPanningRef = useRef(false);
  const panStartRef = useRef({ x: 0, y: 0 });

  // New Exit quick-form state
  const [newExitDir, setNewExitDir] = useState<Direction>('north');
  const [newExitTarget, setNewExitTarget] = useState<string>('');
  const [newExitLocked, setNewExitLocked] = useState(false);
  const [newExitFlag, setNewExitFlag] = useState('');

  // New Flag input
  const [newFlagName, setNewFlagName] = useState('');

  // New Entity quick-create state
  const [newEntityName, setNewEntityName] = useState('');
  const [newEntityDesc, setNewEntityDesc] = useState('');

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const roomsList = Object.values(cartridge.rooms);
  const entitiesList = Object.values(cartridge.entities);
  const selectedRoom = cartridge.rooms[selectedCreatorRoomId] || roomsList[0];
  const selectedEntity = selectedCreatorEntityId
    ? cartridge.entities[selectedCreatorEntityId]
    : null;

  const filteredRooms = roomsList.filter((r) =>
    r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredEntities = entitiesList.filter((e) =>
    e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget || (e.target as HTMLElement).tagName === 'svg') {
      isPanningRef.current = true;
      panStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (draggingRoomId) {
      const nextX = (e.clientX - pan.x) / zoom - dragOffsetRef.current.x;
      const nextY = (e.clientY - pan.y) / zoom - dragOffsetRef.current.y;
      updateRoomPosition(draggingRoomId, Math.max(20, nextX), Math.max(20, nextY));
    } else if (isPanningRef.current) {
      setPan({
        x: e.clientX - panStartRef.current.x,
        y: e.clientY - panStartRef.current.y,
      });
    }
  };

  const handleCanvasMouseUp = () => {
    setDraggingRoomId(null);
    isPanningRef.current = false;
  };

  const insertMarkupSnippet = (snippet: string) => {
    if (!selectedRoom) return;
    const el = textareaRef.current;
    const currentText = selectedRoom.descriptionMarkup;
    if (!el) {
      updateRoomNode(selectedRoom.id, {
        descriptionMarkup: `${currentText} ${snippet}`,
      });
      return;
    }
    const start = el.selectionStart ?? currentText.length;
    const end = el.selectionEnd ?? currentText.length;
    const nextText =
      currentText.slice(0, start) + snippet + currentText.slice(end);
    updateRoomNode(selectedRoom.id, { descriptionMarkup: nextText });
  };

  const handleCreateNewEntity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEntityName.trim()) return;
    const id = newEntityName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_');
    const entity: WorldEntity = {
      id,
      name: newEntityName.trim(),
      aliases: [newEntityName.trim().toLowerCase()],
      description:
        newEntityDesc.trim() ||
        'An intricate horological artifact forged in the Scriptorium.',
      isTakeable: true,
      isUsable: true,
      onInspectText: 'Fine geometric runes spiral across its surface.',
      onUseText: `[glow]You activate the ${newEntityName.trim()}.[/glow]`,
    };
    upsertWorldEntity(entity, selectedRoom?.id);
    setNewEntityName('');
    setNewEntityDesc('');
  };

  return (
    <div className="flex-1 h-full flex overflow-hidden bg-[#080A0F]">
      {/* Left Outliner & Entity Drawer (280px) */}
      <aside className="w-[280px] h-full bg-[#141A29] border-r border-[#232D42] flex flex-col shrink-0">
        <div className="p-3 border-b border-[#232D42] bg-[#0D111A]">
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 text-[#64748B] absolute left-2.5" />
            <label htmlFor="outliner-search" className="sr-only">
              Search rooms and entities
            </label>
            <input
              id="outliner-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter rooms, relics, flags..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-[#141A29] border border-[#232D42] rounded-md text-[#F8FAFC] placeholder-[#64748B] focus:outline-none focus:border-[#38BDF8]"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-5">
          {/* Rooms Section */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-[#94A3B8] flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-[#F59E0B]" />
                <span>Chambers ({roomsList.length})</span>
              </span>
              <button
                type="button"
                onClick={() => addRoomNode()}
                className="px-2 py-0.5 text-[11px] font-medium rounded bg-[#1C2539] hover:bg-[#F59E0B] hover:text-[#080A0F] text-[#FDE68A] border border-[#232D42] flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>New Room</span>
              </button>
            </div>
            <div className="space-y-1">
              {filteredRooms.map((room) => {
                const isSelected = room.id === selectedRoom?.id;
                return (
                  <button
                    key={room.id}
                    type="button"
                    onClick={() => {
                      selectCreatorRoom(room.id);
                      selectCreatorEntity(null);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-md text-xs flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#1C2539] text-[#F8FAFC] border border-[#F59E0B]/50'
                        : 'text-[#94A3B8] hover:bg-[#1C2539]/60 hover:text-[#E2E8F0] border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`w-2 h-2 rounded-sm shrink-0 ${BIOME_BADGE_COLORS[room.biomeMood]}`}
                      />
                      <span className="truncate font-medium">{room.title}</span>
                    </div>
                    <span className="text-[10px] font-mono-code text-[#64748B] shrink-0">
                      {room.exits.length}ex
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* World Relics / Entities Section */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-[#94A3B8] flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>World Relics ({entitiesList.length})</span>
              </span>
              <button
                type="button"
                onClick={() => setInspectorSection('entities')}
                className="px-2 py-0.5 text-[11px] font-medium rounded bg-[#1C2539] hover:bg-[#38BDF8] hover:text-[#080A0F] text-[#38BDF8] border border-[#232D42] flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Relic</span>
              </button>
            </div>
            <div className="space-y-1">
              {filteredEntities.map((ent) => {
                const isSelected = selectedCreatorEntityId === ent.id;
                return (
                  <button
                    key={ent.id}
                    type="button"
                    onClick={() => {
                      selectCreatorEntity(ent.id);
                      setInspectorSection('entities');
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-md text-xs flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#1C2539] text-[#38BDF8] border border-[#38BDF8]/50'
                        : 'text-[#94A3B8] hover:bg-[#1C2539]/60 hover:text-[#E2E8F0] border border-transparent'
                    }`}
                  >
                    <span className="truncate">{ent.name}</span>
                    <span className="text-[10px] font-mono-code text-[#64748B] shrink-0">
                      {ent.isTakeable ? 'Item' : 'Fixture'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Story Flags Section */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-[#94A3B8] flex items-center gap-1.5">
                <Flag className="w-3.5 h-3.5 text-[#A855F7]" />
                <span>Story Flags ({Object.keys(flags).length})</span>
              </span>
            </div>
            <div className="flex gap-1.5 mb-2">
              <label htmlFor="new-story-flag-input" className="sr-only">
                New flag key
              </label>
              <input
                id="new-story-flag-input"
                type="text"
                value={newFlagName}
                onChange={(e) => setNewFlagName(e.target.value)}
                placeholder="new_flag_key..."
                className="flex-1 px-2 py-1 text-xs font-mono-code bg-[#0D111A] border border-[#232D42] rounded text-[#F8FAFC] placeholder-[#64748B]"
              />
              <button
                type="button"
                onClick={() => {
                  if (newFlagName.trim()) {
                    createFlag(newFlagName);
                    setNewFlagName('');
                  }
                }}
                className="px-2 py-1 text-xs font-medium rounded bg-[#1C2539] hover:bg-[#A855F7] hover:text-[#080A0F] text-[#C4B5FD] border border-[#232D42] cursor-pointer"
              >
                Add
              </button>
            </div>
            <div className="space-y-1">
              {Object.entries(flags).map(([key, val]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => toggleFlag(key)}
                  className="w-full px-2.5 py-1.5 rounded bg-[#0D111A] hover:bg-[#1C2539] border border-[#232D42] flex items-center justify-between text-xs font-mono-code cursor-pointer"
                >
                  <span className="text-[#E2E8F0] truncate">{key}</span>
                  <span className={val ? 'text-[#10B981]' : 'text-[#64748B]'}>
                    {val ? 'ON' : 'OFF'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </aside>

      {/* Center 2D World-Weave Pan-and-Zoom Node Canvas (1fr) */}
      <div
        className="flex-1 h-full relative overflow-hidden bg-blueprint-grid select-none"
        onMouseDown={handleCanvasMouseDown}
        onMouseMove={handleCanvasMouseMove}
        onMouseUp={handleCanvasMouseUp}
        onMouseLeave={handleCanvasMouseUp}
      >
        {/* Canvas Floating Header Info & Zoom Controls */}
        <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between pointer-events-none">
          <div className="px-3 py-1.5 rounded-lg bg-[#141A29] border border-[#232D42] text-xs flex items-center gap-2 pointer-events-auto">
            <Layers className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span className="font-semibold text-[#F8FAFC]">World-Weave Node Graph</span>
            <span className="text-[#64748B]">·</span>
            <span className="text-[#94A3B8]">Drag nodes to arrange · Select node to inspect</span>
          </div>

          <div className="flex items-center gap-1 bg-[#141A29] border border-[#232D42] rounded-lg p-1 pointer-events-auto">
            <button
              type="button"
              aria-label="Zoom out canvas"
              onClick={() => setZoom((z) => Math.max(0.55, +(z - 0.15).toFixed(2)))}
              className="p-1.5 text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1C2539] rounded cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 text-xs font-mono-code text-[#E2E8F0]">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              aria-label="Zoom in canvas"
              onClick={() => setZoom((z) => Math.min(1.6, +(z + 0.15).toFixed(2)))}
              className="p-1.5 text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1C2539] rounded cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              aria-label="Reset canvas pan and zoom"
              onClick={() => {
                setZoom(1);
                setPan({ x: 20, y: 20 });
              }}
              className="p-1.5 text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1C2539] rounded cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Transformed Canvas Plane */}
        <div
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: '0 0',
          }}
          className="w-[1400px] h-[950px] relative"
        >
          {/* SVG Cubic-Bezier Exit Conduits */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
            <defs>
              <marker
                id="arrow-unlocked"
                markerWidth="8"
                markerHeight="8"
                refX="6"
                refY="4"
                orient="auto"
              >
                <path d="M0,1 L7,4 L0,7 Z" fill="#38BDF8" />
              </marker>
              <marker
                id="arrow-locked"
                markerWidth="8"
                markerHeight="8"
                refX="6"
                refY="4"
                orient="auto"
              >
                <path d="M0,1 L7,4 L0,7 Z" fill="#EF4444" />
              </marker>
            </defs>

            {roomsList.map((room) => {
              const x1 = room.editorPosition.x + 115;
              const y1 = room.editorPosition.y + 62;

              return room.exits.map((exit) => {
                const target = cartridge.rooms[exit.targetRoomId];
                if (!target) return null;
                const x2 = target.editorPosition.x + 115;
                const y2 = target.editorPosition.y + 62;
                const dx = x2 - x1;
                const dy = y2 - y1;
                const cx1 = x1 + dx * 0.45;
                const cy1 = y1 + dy * 0.1;
                const cx2 = x1 + dx * 0.55;
                const cy2 = y2 - dy * 0.1;
                const pathD = `M ${x1} ${y1} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${x2} ${y2}`;

                return (
                  <g key={`${room.id}_${exit.direction}_${target.id}`}>
                    <path
                      d={pathD}
                      fill="none"
                      stroke={exit.isLocked ? '#EF4444' : '#38BDF8'}
                      strokeWidth={room.id === selectedRoom?.id ? 2.5 : 1.75}
                      strokeDasharray={exit.isLocked ? '6 4' : undefined}
                      markerEnd={exit.isLocked ? 'url(#arrow-locked)' : 'url(#arrow-unlocked)'}
                      opacity={0.78}
                    />
                    <rect
                      x={(x1 + x2) / 2 - 22}
                      y={(y1 + y2) / 2 - 9}
                      width={44}
                      height={18}
                      rx={4}
                      fill="#0D111A"
                      stroke={exit.isLocked ? '#EF4444' : '#232D42'}
                    />
                    <text
                      x={(x1 + x2) / 2}
                      y={(y1 + y2) / 2 + 3}
                      textAnchor="middle"
                      fill={exit.isLocked ? '#FCA5A5' : '#38BDF8'}
                      fontSize="9.5"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      {exit.direction.toUpperCase()}
                    </text>
                  </g>
                );
              });
            })}
          </svg>

          {/* Draggable Room Cards */}
          {roomsList.map((room) => {
            const isSelected = room.id === selectedRoom?.id;
            const isStart = room.id === cartridge.startingRoomId;

            return (
              <div
                key={room.id}
                style={{
                  left: `${room.editorPosition.x}px`,
                  top: `${room.editorPosition.y}px`,
                }}
                onMouseDown={(e) => {
                  e.stopPropagation();
                  selectCreatorRoom(room.id);
                  setDraggingRoomId(room.id);
                  dragOffsetRef.current = {
                    x: (e.clientX - pan.x) / zoom - room.editorPosition.x,
                    y: (e.clientY - pan.y) / zoom - room.editorPosition.y,
                  };
                }}
                className={`absolute w-[230px] rounded-xl bg-[#141A29] border transition-shadow cursor-grab active:cursor-grabbing ${
                  isSelected
                    ? 'border-[#F59E0B] shadow-xl ring-1 ring-[#F59E0B]/40'
                    : 'border-[#232D42] hover:border-[#38BDF8]/60 shadow-md'
                }`}
              >
                {/* Top Biome Color Bar */}
                <div className={`h-1.5 rounded-t-xl ${BIOME_BADGE_COLORS[room.biomeMood]}`} />

                <div className="p-3 space-y-2">
                  <div className="flex items-start justify-between gap-1.5">
                    <h3 className="text-xs font-semibold text-[#F8FAFC] leading-snug">
                      {room.title}
                    </h3>
                    {isStart && (
                      <span className="text-[9px] font-mono-code uppercase text-[#F59E0B] shrink-0">
                        START
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] text-[#94A3B8] line-clamp-2 font-prose">
                    {room.descriptionMarkup
                      .replace(/\|id:[^\]]+/g, '')
                      .replace(/\[\[|\]\]|\{if[^}]*\}|\{else\}|\{\/if\}|\[\/?(shake|glow|whisper)\]/g, '')}
                  </p>

                  {/* Node Metadata & Instant Playtest Button */}
                  <div className="pt-1.5 border-t border-[#232D42] flex items-center justify-between text-[10px] font-mono-code text-[#64748B]">
                    <span>
                      [X:{Math.round(room.editorPosition.x / 20)}, Y:
                      {Math.round(room.editorPosition.y / 20)}] · {room.entityIds.length} relics
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        selectCreatorRoom(room.id);
                        setMode('PLAY');
                      }}
                      className="px-1.5 py-0.5 rounded bg-[#1C2539] hover:bg-[#10B981] hover:text-[#080A0F] text-[#10B981] flex items-center gap-1 transition-colors cursor-pointer"
                      title="Playtest directly from this chamber"
                    >
                      <Play className="w-2.5 h-2.5" />
                      <span>Play</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Passage & Logic Inspector (390px) */}
      <aside className="w-[390px] h-full bg-[#141A29] border-l border-[#232D42] flex flex-col shrink-0 overflow-hidden">
        {selectedRoom ? (
          <>
            {/* Inspector Header */}
            <div className="p-3.5 bg-[#0D111A] border-b border-[#232D42] flex items-center justify-between gap-2">
              <div className="min-w-0">
                <span className="text-[10px] font-mono-code text-[#F59E0B] uppercase">
                  CHAMBER INSPECTOR · ID: {selectedRoom.id}
                </span>
                <h2 className="text-sm font-semibold text-[#F8FAFC] truncate">
                  {selectedRoom.title}
                </h2>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button
                  variant="emerald"
                  size="sm"
                  onClick={() => setMode('PLAY')}
                >
                  <Play className="w-3 h-3" />
                  <span>Play Here</span>
                </Button>
                {selectedRoom.id !== cartridge.startingRoomId && (
                  <button
                    type="button"
                    aria-label="Delete chamber"
                    onClick={() => deleteRoomNode(selectedRoom.id)}
                    className="p-1.5 text-[#64748B] hover:text-[#EF4444] rounded cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Inspector Section Tabs */}
            <div className="grid grid-cols-4 p-1.5 bg-[#0D111A] border-b border-[#232D42] gap-1 shrink-0">
              {(['prose', 'exits', 'entities', 'choices'] as const).map((sec) => (
                <button
                  key={sec}
                  type="button"
                  onClick={() => setInspectorSection(sec)}
                  className={`py-1.5 text-xs font-medium rounded capitalize transition-colors cursor-pointer ${
                    inspectorSection === sec
                      ? 'bg-[#1C2539] text-[#F8FAFC]'
                      : 'text-[#64748B] hover:text-[#E2E8F0]'
                  }`}
                >
                  {sec}
                </button>
              ))}
            </div>

            {/* Inspector Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {inspectorSection === 'prose' && (
                <>
                  <div className="space-y-1.5">
                    <label
                      htmlFor="inspector-room-title"
                      className="block text-xs font-medium text-[#94A3B8]"
                    >
                      Chamber Title
                    </label>
                    <input
                      id="inspector-room-title"
                      type="text"
                      value={selectedRoom.title}
                      onChange={(e) =>
                        updateRoomNode(selectedRoom.id, { title: e.target.value })
                      }
                      className="w-full px-3 py-1.5 text-xs bg-[#0D111A] border border-[#232D42] rounded-md text-[#F8FAFC] focus:outline-none focus:border-[#F59E0B]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-medium text-[#94A3B8]">
                      Atmospheric Biome Mood
                    </label>
                    <div className="grid grid-cols-5 gap-1">
                      {BIOMES.map((b) => (
                        <button
                          key={b}
                          type="button"
                          onClick={() => updateRoomNode(selectedRoom.id, { biomeMood: b })}
                          className={`py-1.5 px-2 text-[11px] font-medium rounded border capitalize cursor-pointer ${
                            selectedRoom.biomeMood === b
                              ? 'bg-[#1C2539] text-[#F59E0B] border-[#F59E0B]/60'
                              : 'bg-[#0D111A] text-[#94A3B8] border-[#232D42]'
                          }`}
                        >
                          {b}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Syntax Helper Toolbar */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label
                        htmlFor="inspector-prose-markup"
                        className="text-xs font-medium text-[#94A3B8]"
                      >
                        Interactive Prose &amp; Conditional Markup
                      </label>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      <button
                        type="button"
                        onClick={() =>
                          insertMarkupSnippet(
                            '[[Relic Name|id:lantern_01|actions:inspect,take,use]]'
                          )
                        }
                        className="px-2 py-1 text-[11px] font-mono-code rounded bg-[#0D111A] hover:bg-[#1C2539] text-[#38BDF8] border border-[#232D42] cursor-pointer"
                      >
                        + [[Entity]]
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          insertMarkupSnippet(
                            '{if flag:lantern_lit}Illuminated prose...{else}Shadowed prose...{/if}'
                          )
                        }
                        className="px-2 py-1 text-[11px] font-mono-code rounded bg-[#0D111A] hover:bg-[#1C2539] text-[#A855F7] border border-[#232D42] cursor-pointer"
                      >
                        + &#123;if flag&#125;
                      </button>
                      <button
                        type="button"
                        onClick={() => insertMarkupSnippet('[glow]Golden pulse[/glow]')}
                        className="px-2 py-1 text-[11px] font-mono-code rounded bg-[#0D111A] hover:bg-[#1C2539] text-[#F59E0B] border border-[#232D42] cursor-pointer"
                      >
                        + [glow]
                      </button>
                      <button
                        type="button"
                        onClick={() => insertMarkupSnippet('[shake]Earthquake tremor[/shake]')}
                        className="px-2 py-1 text-[11px] font-mono-code rounded bg-[#0D111A] hover:bg-[#1C2539] text-[#EF4444] border border-[#232D42] cursor-pointer"
                      >
                        + [shake]
                      </button>
                      <button
                        type="button"
                        onClick={() => insertMarkupSnippet('[whisper]Faint echo...[/whisper]')}
                        className="px-2 py-1 text-[11px] font-mono-code rounded bg-[#0D111A] hover:bg-[#1C2539] text-[#C4B5FD] border border-[#232D42] cursor-pointer"
                      >
                        + [whisper]
                      </button>
                    </div>
                    <textarea
                      id="inspector-prose-markup"
                      ref={textareaRef}
                      rows={10}
                      value={selectedRoom.descriptionMarkup}
                      onChange={(e) =>
                        updateRoomNode(selectedRoom.id, {
                          descriptionMarkup: e.target.value,
                        })
                      }
                      className="w-full p-3 text-xs font-mono-code leading-relaxed bg-[#0D111A] border border-[#232D42] rounded-lg text-[#E2E8F0] focus:outline-none focus:border-[#38BDF8]"
                    />
                  </div>
                </>
              )}

              {inspectorSection === 'exits' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-xs font-semibold text-[#F8FAFC]">
                      Connected Compass Conduits
                    </h3>
                    {selectedRoom.exits.length === 0 ? (
                      <p className="text-xs text-[#64748B]">No exits wired yet.</p>
                    ) : (
                      selectedRoom.exits.map((ex) => (
                        <div
                          key={ex.direction}
                          className="p-2.5 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 text-xs font-mono-code uppercase rounded bg-[#141A29] text-[#38BDF8] border border-[#232D42]">
                                {ex.direction}
                              </span>
                              <span className="text-xs text-[#E2E8F0]">
                                → {cartridge.rooms[ex.targetRoomId]?.title || ex.targetRoomId}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() =>
                                  upsertRoomExit(selectedRoom.id, {
                                    ...ex,
                                    isLocked: !ex.isLocked,
                                  })
                                }
                                className={`p-1 rounded border cursor-pointer ${
                                  ex.isLocked
                                    ? 'text-[#EF4444] border-[#EF4444]/40 bg-[#EF4444]/10'
                                    : 'text-[#10B981] border-[#10B981]/40 bg-[#10B981]/10'
                                }`}
                                title="Toggle Exit Lock"
                              >
                                {ex.isLocked ? (
                                  <Lock className="w-3.5 h-3.5" />
                                ) : (
                                  <Unlock className="w-3.5 h-3.5" />
                                )}
                              </button>
                              <button
                                type="button"
                                aria-label={`Remove ${ex.direction} exit`}
                                onClick={() => removeRoomExit(selectedRoom.id, ex.direction)}
                                className="p-1 text-[#64748B] hover:text-[#EF4444] cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                          {ex.isLocked && (
                            <p className="text-[11px] text-[#FCA5A5] font-mono-code">
                              Required Flag:{' '}
                              {ex.unlockCondition?.requiredFlags?.join(', ') || 'Manual Unlock'}
                            </p>
                          )}
                        </div>
                      ))
                    )}
                  </div>

                  {/* Wire New Compass Conduit */}
                  <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2.5">
                    <h4 className="text-xs font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                      <Link2 className="w-3.5 h-3.5 text-[#38BDF8]" />
                      <span>Wire Compass Exit Conduit</span>
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label
                          htmlFor="new-exit-direction"
                          className="block text-[11px] text-[#94A3B8] mb-1"
                        >
                          Direction
                        </label>
                        <select
                          id="new-exit-direction"
                          value={newExitDir}
                          onChange={(e) => setNewExitDir(e.target.value as Direction)}
                          className="w-full px-2 py-1.5 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
                        >
                          {DIRECTIONS.map((d) => (
                            <option key={d} value={d}>
                              {d.toUpperCase()}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label
                          htmlFor="new-exit-target"
                          className="block text-[11px] text-[#94A3B8] mb-1"
                        >
                          Target Chamber
                        </label>
                        <select
                          id="new-exit-target"
                          value={newExitTarget || roomsList[0]?.id}
                          onChange={(e) => setNewExitTarget(e.target.value)}
                          className="w-full px-2 py-1.5 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
                        >
                          {roomsList
                            .filter((r) => r.id !== selectedRoom.id)
                            .map((r) => (
                              <option key={r.id} value={r.id}>
                                {r.title}
                              </option>
                            ))}
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <label className="inline-flex items-center gap-2 text-xs text-[#94A3B8] cursor-pointer">
                        <input
                          type="checkbox"
                          checked={newExitLocked}
                          onChange={(e) => setNewExitLocked(e.target.checked)}
                          className="rounded border-[#232D42]"
                        />
                        <span>Lock Conduit by Flag</span>
                      </label>
                    </div>

                    {newExitLocked && (
                      <input
                        type="text"
                        value={newExitFlag}
                        onChange={(e) => setNewExitFlag(e.target.value)}
                        placeholder="Required flag (e.g., grate_unlocked)"
                        className="w-full px-2.5 py-1.5 text-xs font-mono-code bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
                      />
                    )}

                    <Button
                      variant="primary"
                      size="sm"
                      className="w-full"
                      onClick={() => {
                        const fallbackTarget = roomsList.find(
                          (r) => r.id !== selectedRoom.id
                        )?.id;
                        const targetId = newExitTarget || fallbackTarget;
                        if (!targetId) return;
                        upsertRoomExit(selectedRoom.id, {
                          direction: newExitDir,
                          targetRoomId: targetId,
                          isLocked: newExitLocked,
                          unlockCondition:
                            newExitLocked && newExitFlag.trim()
                              ? { requiredFlags: [newExitFlag.trim()] }
                              : undefined,
                        });
                      }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Connect Exit Conduit</span>
                    </Button>
                  </div>
                </div>
              )}

              {inspectorSection === 'entities' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-xs font-semibold text-[#F8FAFC]">
                      Relics Present in {selectedRoom.title}
                    </h3>
                    <div className="space-y-1.5">
                      {entitiesList.map((ent) => {
                        const present = selectedRoom.entityIds.includes(ent.id);
                        return (
                          <div
                            key={ent.id}
                            className="p-2 rounded-lg bg-[#0D111A] border border-[#232D42] flex items-center justify-between gap-2"
                          >
                            <label className="flex items-center gap-2 text-xs text-[#E2E8F0] cursor-pointer min-w-0">
                              <input
                                type="checkbox"
                                checked={present}
                                onChange={() => toggleRoomEntity(selectedRoom.id, ent.id)}
                              />
                              <span className="truncate font-medium">{ent.name}</span>
                            </label>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="text-[10px] font-mono-code text-[#64748B]">
                                {ent.id}
                              </span>
                              <button
                                type="button"
                                aria-label={`Delete relic ${ent.name}`}
                                onClick={() => deleteWorldEntity(ent.id)}
                                className="p-1 text-[#64748B] hover:text-[#EF4444] cursor-pointer"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Selected Entity Detail Editor */}
                  {selectedEntity && (
                    <div className="p-3 rounded-lg bg-[#0D111A] border border-[#38BDF8]/40 space-y-2">
                      <h4 className="text-xs font-semibold text-[#38BDF8]">
                        Editing Relic: {selectedEntity.name}
                      </h4>
                      <input
                        type="text"
                        value={selectedEntity.name}
                        onChange={(e) =>
                          upsertWorldEntity({ ...selectedEntity, name: e.target.value })
                        }
                        className="w-full px-2.5 py-1 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
                      />
                      <textarea
                        rows={3}
                        value={selectedEntity.description}
                        onChange={(e) =>
                          upsertWorldEntity({
                            ...selectedEntity,
                            description: e.target.value,
                          })
                        }
                        className="w-full p-2 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#E2E8F0]"
                      />
                    </div>
                  )}

                  {/* Create New Relic Form */}
                  <form
                    onSubmit={handleCreateNewEntity}
                    className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2.5"
                  >
                    <h4 className="text-xs font-semibold text-[#F8FAFC]">
                      Forge New Relic / NPC
                    </h4>
                    <input
                      type="text"
                      value={newEntityName}
                      onChange={(e) => setNewEntityName(e.target.value)}
                      placeholder="Relic name (e.g., Obsidian Astrolabe)"
                      className="w-full px-2.5 py-1.5 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
                    />
                    <textarea
                      rows={2}
                      value={newEntityDesc}
                      onChange={(e) => setNewEntityDesc(e.target.value)}
                      placeholder="Lore description when inspected..."
                      className="w-full p-2 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#E2E8F0]"
                    />
                    <Button type="submit" variant="primary" size="sm" className="w-full">
                      <Plus className="w-3.5 h-3.5" />
                      <span>Create &amp; Place in Chamber</span>
                    </Button>
                  </form>
                </div>
              )}

              {inspectorSection === 'choices' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-semibold text-[#F8FAFC]">
                      Interactive Choice Pills ({selectedRoom.choices.length})
                    </h3>
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => addRoomChoice(selectedRoom.id)}
                    >
                      <Plus className="w-3 h-3" />
                      <span>Add Choice</span>
                    </Button>
                  </div>

                  {selectedRoom.choices.map((ch) => (
                    <div
                      key={ch.id}
                      className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-mono-code text-[#F59E0B] flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          CHOICE PILL
                        </span>
                        <button
                          type="button"
                          aria-label={`Remove choice ${ch.label}`}
                          onClick={() => removeRoomChoice(selectedRoom.id, ch.id)}
                          className="text-[#64748B] hover:text-[#EF4444] cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <input
                        type="text"
                        value={ch.label}
                        onChange={(e) =>
                          updateRoomChoice(selectedRoom.id, ch.id, {
                            label: e.target.value,
                          })
                        }
                        className="w-full px-2.5 py-1 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
                        placeholder="Choice button label"
                      />
                      <textarea
                        rows={2}
                        value={ch.responseMarkup || ''}
                        onChange={(e) =>
                          updateRoomChoice(selectedRoom.id, ch.id, {
                            responseMarkup: e.target.value,
                          })
                        }
                        className="w-full p-2 text-xs font-mono-code bg-[#141A29] border border-[#232D42] rounded text-[#E2E8F0]"
                        placeholder="Response prose markup..."
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        ) : null}
      </aside>
    </div>
  );
};
