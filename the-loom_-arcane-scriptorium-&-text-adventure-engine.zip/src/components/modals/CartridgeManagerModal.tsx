import React, { useState } from 'react';
import {
  Check,
  Copy,
  Download,
  FileCode2,
  FileJson,
  FolderOpen,
  Share2,
  Upload,
} from 'lucide-react';
import { useAdventureStore } from '../../store/useAdventureStore';
import { DEMO_CARTRIDGES } from '../../data/demoCartridges';
import { decodeCartridgeSeed, encodeCartridgeSeed } from '../../engine/parser';
import { Button, Dialog } from '../ui/primitives';
import { StoryCartridge } from '../../types/adventure';

export const CartridgeManagerModal: React.FC = () => {
  const {
    cartridge,
    isCartridgeModalOpen,
    setCartridgeModalOpen,
    loadCartridge,
    updateCartridgeMeta,
  } = useAdventureStore();

  const [seedInput, setSeedInput] = useState('');
  const [jsonInput, setJsonInput] = useState('');
  const [copiedSeed, setCopiedSeed] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  const handleCopySeed = () => {
    const encoded = encodeCartridgeSeed(cartridge);
    navigator.clipboard?.writeText(encoded).catch(() => {});
    setCopiedSeed(true);
    setTimeout(() => setCopiedSeed(false), 2000);
  };

  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(cartridge, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${cartridge.id || 'story_cartridge'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadStandaloneHtml = () => {
    const htmlContent = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>${cartridge.title} — Standalone Story Cartridge</title>
<style>
  body { background:#080A0F; color:#E2E8F0; font-family:Georgia,serif; max-width:720px; margin:40px auto; padding:20px; line-height:1.75; }
  h1 { color:#F59E0B; font-family:sans-serif; }
  .room { background:#141A29; border:1px solid #232D42; padding:20px; border-radius:10px; margin-bottom:20px; }
</style>
</head>
<body>
  <h1>${cartridge.title}</h1>
  <p><em>By ${cartridge.author} · v${cartridge.version}</em></p>
  <p>${cartridge.synopsis}</p>
  <hr style="border-color:#232D42;margin:24px 0;"/>
  ${Object.values(cartridge.rooms)
    .map(
      (r) => `<div class="room"><h2>${r.title}</h2><p>${r.descriptionMarkup}</p></div>`
    )
    .join('\n')}
</body>
</html>`;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${cartridge.id || 'adventure'}_playable.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleLoadFromSeed = () => {
    setImportError(null);
    const decoded = decodeCartridgeSeed(seedInput);
    if (!decoded) {
      setImportError('Invalid or corrupted Story Seed string.');
      return;
    }
    loadCartridge(decoded, true);
    setSeedInput('');
  };

  const handleLoadFromJson = () => {
    setImportError(null);
    try {
      const parsed = JSON.parse(jsonInput) as StoryCartridge;
      if (!parsed || !parsed.rooms || !parsed.startingRoomId) {
        setImportError('JSON must contain `startingRoomId` and `rooms` map.');
        return;
      }
      loadCartridge(parsed, true);
      setJsonInput('');
    } catch {
      setImportError('Failed to parse JSON cartridge.');
    }
  };

  return (
    <Dialog
      open={isCartridgeModalOpen}
      onOpenChange={setCartridgeModalOpen}
      title="Story Cartridge & Seed Foundry"
      description="Load pre-built interactive fiction worlds, edit cartridge metadata, or export your creation as a portable JSON cartridge, HTML chronicle, or URL seed."
      maxWidthClass="max-w-3xl"
    >
      <div className="space-y-6">
        {/* Active Cartridge Metadata Editor */}
        <div className="p-4 rounded-xl bg-[#0D111A] border border-[#232D42] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono-code text-[#F59E0B] uppercase">
              ACTIVE CARTRIDGE MANIFEST
            </span>
            <span className="text-xs font-mono-code text-[#64748B]">
              {Object.keys(cartridge.rooms).length} Chambers ·{' '}
              {Object.keys(cartridge.entities).length} Relics
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="cartridge-title-input"
                className="block text-xs text-[#94A3B8] mb-1"
              >
                Adventure Title
              </label>
              <input
                id="cartridge-title-input"
                type="text"
                value={cartridge.title}
                onChange={(e) => updateCartridgeMeta({ title: e.target.value })}
                className="w-full px-3 py-1.5 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
              />
            </div>
            <div>
              <label
                htmlFor="cartridge-author-input"
                className="block text-xs text-[#94A3B8] mb-1"
              >
                Author / Archivist
              </label>
              <input
                id="cartridge-author-input"
                type="text"
                value={cartridge.author}
                onChange={(e) => updateCartridgeMeta({ author: e.target.value })}
                className="w-full px-3 py-1.5 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-2">
            <Button variant="primary" size="sm" onClick={handleDownloadJson}>
              <FileJson className="w-3.5 h-3.5" />
              <span>Export JSON Cartridge</span>
            </Button>
            <Button variant="secondary" size="sm" onClick={handleDownloadStandaloneHtml}>
              <FileCode2 className="w-3.5 h-3.5" />
              <span>Export Playable HTML</span>
            </Button>
            <Button variant="secondary" size="sm" onClick={handleCopySeed}>
              {copiedSeed ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#10B981]" />
                  <span>Seed Copied to Clipboard</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Copy Compressed Story Seed</span>
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Pre-Built Demo Cartridges */}
        <div className="space-y-2.5">
          <h3 className="text-xs font-semibold text-[#F8FAFC] uppercase tracking-wider font-mono-code flex items-center gap-1.5">
            <FolderOpen className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>Curated Story Cartridges</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {DEMO_CARTRIDGES.map((demo) => {
              const isCurrent = demo.id === cartridge.id;
              return (
                <div
                  key={demo.id}
                  className={`p-3.5 rounded-xl bg-[#0D111A] border flex flex-col justify-between gap-3 ${
                    isCurrent ? 'border-[#F59E0B]' : 'border-[#232D42]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-sm font-semibold text-[#F8FAFC]">{demo.title}</h4>
                      <span className="text-[10px] font-mono-code text-[#64748B]">
                        v{demo.version}
                      </span>
                    </div>
                    <p className="text-xs text-[#94A3B8] mt-1 line-clamp-3">{demo.synopsis}</p>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-[#232D42]">
                    <span className="text-[11px] font-mono-code text-[#64748B]">
                      {Object.keys(demo.rooms).length} Rooms · {Object.keys(demo.entities).length}{' '}
                      Relics
                    </span>
                    <Button
                      variant={isCurrent ? 'emerald' : 'secondary'}
                      size="sm"
                      onClick={() => loadCartridge(demo, true)}
                    >
                      <Download className="w-3 h-3" />
                      <span>{isCurrent ? 'Reload World' : 'Load Cartridge'}</span>
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Import Seed or JSON */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-3.5 rounded-xl bg-[#0D111A] border border-[#232D42] space-y-2">
            <label
              htmlFor="import-seed-input"
              className="block text-xs font-semibold text-[#F8FAFC]"
            >
              Load from Shareable Story Seed
            </label>
            <input
              id="import-seed-input"
              type="text"
              value={seedInput}
              onChange={(e) => setSeedInput(e.target.value)}
              placeholder="Paste Base64 Story Seed..."
              className="w-full px-2.5 py-1.5 text-xs font-mono-code bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
            />
            <Button
              variant="secondary"
              size="sm"
              className="w-full"
              disabled={!seedInput.trim()}
              onClick={handleLoadFromSeed}
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Decode &amp; Launch Seed</span>
            </Button>
          </div>

          <div className="p-3.5 rounded-xl bg-[#0D111A] border border-[#232D42] space-y-2">
            <label
              htmlFor="import-json-input"
              className="block text-xs font-semibold text-[#F8FAFC]"
            >
              Import Raw JSON Cartridge
            </label>
            <input
              id="import-json-input"
              type="text"
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              placeholder='Paste {"id": "...", "rooms": {...}}...'
              className="w-full px-2.5 py-1.5 text-xs font-mono-code bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC]"
            />
            <Button
              variant="secondary"
              size="sm"
              className="w-full"
              disabled={!jsonInput.trim()}
              onClick={handleLoadFromJson}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Import JSON Cartridge</span>
            </Button>
          </div>
        </div>

        {importError && (
          <p className="text-xs text-[#EF4444] font-mono-code">{importError}</p>
        )}
      </div>
    </Dialog>
  );
};
