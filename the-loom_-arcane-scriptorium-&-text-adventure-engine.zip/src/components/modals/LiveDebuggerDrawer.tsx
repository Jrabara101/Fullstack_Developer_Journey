import React from 'react';
import { Bug, Compass, Flag, Package, Sliders, Terminal, X } from 'lucide-react';
import { useAdventureStore } from '../../store/useAdventureStore';

export const LiveDebuggerDrawer: React.FC = () => {
  const {
    cartridge,
    currentRoomId,
    inventoryIds,
    flags,
    variables,
    parserLogs,
    isDebuggerOpen,
    setDebuggerOpen,
    toggleFlag,
    setVariable,
    teleportToRoom,
    toggleInventoryItem,
  } = useAdventureStore();

  if (!isDebuggerOpen) return null;

  const rooms = Object.values(cartridge.rooms);
  const entities = Object.values(cartridge.entities);

  return (
    <div
      role="region"
      aria-label="Live State Debugger Drawer"
      className="fixed bottom-4 right-4 z-40 w-[440px] max-h-[75vh] bg-[#141A29] border border-[#A855F7]/60 rounded-xl shadow-2xl flex flex-col overflow-hidden"
    >
      {/* Header */}
      <div className="px-4 py-2.5 bg-[#0D111A] border-b border-[#232D42] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bug className="w-4 h-4 text-[#A855F7]" />
          <span className="text-xs font-mono-code font-semibold text-[#F8FAFC]">
            LIVE STATE INSPECTOR &amp; TELEPORT
          </span>
        </div>
        <button
          type="button"
          aria-label="Close Live State Debugger"
          onClick={() => setDebuggerOpen(false)}
          className="p-1 text-[#64748B] hover:text-[#F8FAFC] rounded cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 overflow-y-auto space-y-4 text-xs">
        {/* Instant Chamber Teleport */}
        <div>
          <h4 className="font-mono-code text-[11px] text-[#94A3B8] uppercase mb-1.5 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span>Teleport to Chamber</span>
          </h4>
          <div className="grid grid-cols-2 gap-1.5">
            {rooms.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => teleportToRoom(r.id)}
                className={`px-2.5 py-1.5 rounded text-left truncate border transition-colors cursor-pointer ${
                  r.id === currentRoomId
                    ? 'bg-[#F59E0B] text-[#080A0F] font-semibold border-amber-400'
                    : 'bg-[#0D111A] hover:bg-[#1C2539] text-[#E2E8F0] border-[#232D42]'
                }`}
              >
                {r.title}
              </button>
            ))}
          </div>
        </div>

        {/* Toggle Boolean Flags */}
        <div>
          <h4 className="font-mono-code text-[11px] text-[#94A3B8] uppercase mb-1.5 flex items-center gap-1.5">
            <Flag className="w-3.5 h-3.5 text-[#A855F7]" />
            <span>Story Flags (Click to Toggle)</span>
          </h4>
          <div className="grid grid-cols-2 gap-1.5">
            {Object.entries(flags).map(([k, v]) => (
              <button
                key={k}
                type="button"
                onClick={() => toggleFlag(k)}
                className="px-2.5 py-1.5 rounded bg-[#0D111A] hover:bg-[#1C2539] border border-[#232D42] flex items-center justify-between font-mono-code cursor-pointer"
              >
                <span className="truncate text-[#E2E8F0]">{k}</span>
                <span className={v ? 'text-[#10B981]' : 'text-[#64748B]'}>
                  {v ? 'TRUE' : 'FALSE'}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* World Variables */}
        <div>
          <h4 className="font-mono-code text-[11px] text-[#94A3B8] uppercase mb-1.5 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>Numeric Variables</span>
          </h4>
          <div className="space-y-1.5">
            {Object.entries(variables).map(([k, val]) => (
              <div
                key={k}
                className="px-2.5 py-1.5 rounded bg-[#0D111A] border border-[#232D42] flex items-center justify-between font-mono-code"
              >
                <span className="text-[#E2E8F0]">{k}</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setVariable(k, val - 5)}
                    className="px-2 py-0.5 rounded bg-[#141A29] hover:bg-[#1C2539] text-[#94A3B8] cursor-pointer"
                  >
                    -5
                  </button>
                  <span className="w-8 text-center text-[#38BDF8]">{val}</span>
                  <button
                    type="button"
                    onClick={() => setVariable(k, val + 5)}
                    className="px-2 py-0.5 rounded bg-[#141A29] hover:bg-[#1C2539] text-[#94A3B8] cursor-pointer"
                  >
                    +5
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Grant / Revoke Relics */}
        <div>
          <h4 className="font-mono-code text-[11px] text-[#94A3B8] uppercase mb-1.5 flex items-center gap-1.5">
            <Package className="w-3.5 h-3.5 text-[#10B981]" />
            <span>Satchel Spawner</span>
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {entities.map((ent) => {
              const owned = inventoryIds.includes(ent.id);
              return (
                <button
                  key={ent.id}
                  type="button"
                  onClick={() => toggleInventoryItem(ent.id)}
                  className={`px-2 py-1 rounded text-[11px] border cursor-pointer ${
                    owned
                      ? 'bg-[#10B981]/20 text-[#10B981] border-[#10B981]/50'
                      : 'bg-[#0D111A] text-[#94A3B8] border-[#232D42]'
                  }`}
                >
                  {owned ? '✓ ' : '+ '}
                  {ent.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Lexer & Parser Token Logs */}
        <div>
          <h4 className="font-mono-code text-[11px] text-[#94A3B8] uppercase mb-1.5 flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-[#10B981]" />
            <span>Natural Language Lexer Trace</span>
          </h4>
          {parserLogs.length === 0 ? (
            <p className="text-[11px] text-[#64748B] font-mono-code">
              No commands parsed yet.
            </p>
          ) : (
            <div className="space-y-1 max-h-32 overflow-y-auto font-mono-code text-[11px]">
              {parserLogs.slice(0, 6).map((log) => (
                <div
                  key={log.id}
                  className="p-1.5 rounded bg-[#0D111A] border border-[#232D42] flex items-center justify-between gap-2"
                >
                  <span className="text-[#E2E8F0] truncate">
                    &gt; {log.rawInput} → <strong className="text-[#38BDF8]">{log.intent}</strong>
                  </span>
                  <span
                    className={
                      log.outcome === 'valid' || log.outcome === 'victory'
                        ? 'text-[#10B981]'
                        : 'text-[#EF4444]'
                    }
                  >
                    {log.outcome.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
