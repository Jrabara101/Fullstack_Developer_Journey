import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Compass,
  CornerDownLeft,
  Eye,
  Hand,
  Lock,
  Sparkles,
  Terminal,
  Unlock,
  Wand2,
} from 'lucide-react';
import { useAdventureStore } from '../../store/useAdventureStore';
import {
  evaluateCondition,
  getAutocompleteSuggestions,
  parseInlineMarkup,
} from '../../engine/parser';
import { BiomeMood, Direction, MarkupSegment } from '../../types/adventure';
import { Popover } from '../ui/primitives';
import { soundEngine } from '../../utils/sound';

const BIOME_STYLES: Record<
  BiomeMood,
  { label: string; border: string; text: string; glow: string }
> = {
  sanctuary: {
    label: 'Sanctuary Spire',
    border: 'border-amber-500/40',
    text: 'text-amber-300',
    glow: 'from-amber-500/10 via-transparent to-transparent',
  },
  arcane: {
    label: 'Arcane Scriptorium',
    border: 'border-sky-500/40',
    text: 'text-sky-300',
    glow: 'from-sky-500/10 via-transparent to-transparent',
  },
  twilight: {
    label: 'Twilight Viaduct',
    border: 'border-purple-500/40',
    text: 'text-purple-300',
    glow: 'from-purple-500/10 via-transparent to-transparent',
  },
  crypt: {
    label: 'Subterranean Cistern',
    border: 'border-emerald-500/40',
    text: 'text-emerald-300',
    glow: 'from-emerald-500/10 via-transparent to-transparent',
  },
  peril: {
    label: 'Mechanical Peril',
    border: 'border-red-500/40',
    text: 'text-red-300',
    glow: 'from-red-500/10 via-transparent to-transparent',
  },
};

export const PlayTerminal: React.FC = () => {
  const {
    cartridge,
    currentRoomId,
    inventoryIds,
    flags,
    variables,
    narrativeLog,
    lastCommandStatus,
    submitCommand,
    executeChoice,
  } = useAdventureStore();

  const [inputVal, setInputVal] = useState('');
  const [shudderActive, setShudderActive] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const currentRoom = cartridge.rooms[currentRoomId];

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [narrativeLog.length]);

  useEffect(() => {
    if (lastCommandStatus === 'invalid' || lastCommandStatus === 'locked') {
      setShudderActive(true);
      const timer = setTimeout(() => setShudderActive(false), 260);
      return () => clearTimeout(timer);
    }
  }, [lastCommandStatus, narrativeLog.length]);

  const suggestions = useMemo(() => {
    if (!currentRoom) return [];
    return getAutocompleteSuggestions(inputVal, currentRoom, cartridge, inventoryIds);
  }, [inputVal, currentRoom, cartridge, inventoryIds]);

  const visibleChoices = useMemo(() => {
    if (!currentRoom) return [];
    return currentRoom.choices.filter(
      (c) => evaluateCondition(c.condition, flags, inventoryIds, variables).met
    );
  }, [currentRoom, flags, inventoryIds, variables]);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    submitCommand(inputVal.trim());
    setInputVal('');
  };

  const handleEntityAction = (action: string, entityId: string, label: string, close: () => void) => {
    soundEngine.playParchmentTap();
    const ent = cartridge.entities[entityId];
    const targetName = ent ? ent.name : label;
    submitCommand(`${action} ${targetName}`);
    close();
  };

  const renderMarkupSegment = (seg: MarkupSegment, idx: number) => {
    const kineticClass =
      seg.effect === 'shake'
        ? 'kinetic-shake'
        : seg.effect === 'glow'
        ? 'kinetic-glow'
        : seg.effect === 'whisper'
        ? 'kinetic-whisper'
        : '';

    if (seg.type === 'text') {
      return (
        <span key={idx} className={kineticClass}>
          {seg.content}
        </span>
      );
    }

    const entityObj = cartridge.entities[seg.entityId];
    const alreadyInInventory = inventoryIds.includes(seg.entityId);

    return (
      <Popover
        key={`${seg.entityId}_${idx}`}
        trigger={
          <button
            type="button"
            onClick={() => soundEngine.playParchmentTap()}
            className={`inline-flex items-center gap-1 px-1 mx-0.5 font-prose font-medium text-[#38BDF8] border-b border-dashed border-[#38BDF8]/70 hover:bg-[#38BDF8]/15 hover:text-sky-200 rounded-sm transition-colors cursor-pointer ${kineticClass}`}
          >
            <span>{seg.label}</span>
          </button>
        }
      >
        {(close) => (
          <div className="flex flex-col gap-1 text-left font-studio">
            <div className="px-2 py-1 border-b border-[#232D42] flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-[#F8FAFC] truncate">
                {entityObj?.name || seg.label}
              </span>
              <span className="text-[10px] font-mono-code text-[#64748B]">
                {alreadyInInventory ? 'In Satchel' : 'In Chamber'}
              </span>
            </div>
            <div className="flex items-center gap-1 pt-0.5">
              <button
                type="button"
                onClick={() => handleEntityAction('inspect', seg.entityId, seg.label, close)}
                className="flex-1 flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded bg-[#141A29] hover:bg-[#38BDF8]/20 text-[#38BDF8] border border-[#232D42] transition-colors cursor-pointer whitespace-nowrap"
              >
                <Eye className="w-3 h-3" />
                Inspect
              </button>
              {(!entityObj || entityObj.isTakeable) && !alreadyInInventory && (
                <button
                  type="button"
                  onClick={() => handleEntityAction('take', seg.entityId, seg.label, close)}
                  className="flex-1 flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded bg-[#141A29] hover:bg-[#10B981]/20 text-[#10B981] border border-[#232D42] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Hand className="w-3 h-3" />
                  Take
                </button>
              )}
              {(!entityObj || entityObj.isUsable) && (
                <button
                  type="button"
                  onClick={() => handleEntityAction('use', seg.entityId, seg.label, close)}
                  className="flex-1 flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded bg-[#141A29] hover:bg-[#F59E0B]/20 text-[#F59E0B] border border-[#232D42] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Wand2 className="w-3 h-3" />
                  Use
                </button>
              )}
            </div>
          </div>
        )}
      </Popover>
    );
  };

  const renderCompassPill = (exit: { direction: Direction; isLocked?: boolean; conduitLabel?: string }) => {
    const condMet =
      !exit.isLocked ||
      evaluateCondition(
        currentRoom?.exits.find((e) => e.direction === exit.direction)?.unlockCondition,
        flags,
        inventoryIds,
        variables
      ).met;

    return (
      <button
        key={exit.direction}
        type="button"
        onClick={() => submitCommand(`go ${exit.direction}`)}
        className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono-code rounded-md border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
          condMet
            ? 'bg-[#141A29] hover:bg-[#1C2539] text-[#10B981] border-[#10B981]/40'
            : 'bg-[#141A29] hover:bg-[#1C2539] text-[#EF4444] border-[#EF4444]/40'
        }`}
      >
        {condMet ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
        <span className="uppercase font-semibold">{exit.direction}</span>
        {exit.conduitLabel && (
          <span className="text-[#94A3B8] font-studio text-[11px]">· {exit.conduitLabel}</span>
        )}
      </button>
    );
  };

  const activeBiome = BIOME_STYLES[currentRoom?.biomeMood || 'sanctuary'];

  return (
    <div className="flex-1 h-full flex flex-col bg-[#0D111A] border-r border-[#232D42] overflow-hidden">
      {/* Sticky Room Context Banner */}
      <div
        className={`px-6 py-3 border-b border-[#232D42] bg-gradient-to-r ${activeBiome.glow} flex items-center justify-between gap-4 shrink-0`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <Compass className="w-4 h-4 text-[#F59E0B] shrink-0" />
          <h1 className="text-base font-semibold text-[#F8FAFC] truncate">
            {currentRoom?.title || 'Uncharted Chamber'}
          </h1>
          <span className="text-xs text-[#64748B] shrink-0">·</span>
          <span className={`text-xs font-medium ${activeBiome.text} shrink-0`}>
            {activeBiome.label}
          </span>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono-code text-[#64748B] shrink-0">
          <span>
            AETHER: <strong className="text-[#E2E8F0]">{variables.aether_pressure ?? 0}</strong>
          </span>
          <span>·</span>
          <span>
            HARMONY: <strong className="text-[#E2E8F0]">{variables.resonance_harmony ?? 0}</strong>
          </span>
        </div>
      </div>

      {/* Scrollable Center Narrative Feed (Max-width 780px Centered) */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        <div className="max-w-[760px] mx-auto space-y-5">
          {narrativeLog.map((entry, entryIdx) => {
            if (entry.type === 'COMMAND_ECHO') {
              return (
                <div
                  key={entry.id}
                  className="flex items-center gap-2 pt-2 text-xs font-mono-code text-[#10B981]"
                >
                  <span className="text-[#64748B]">TURN {String(entry.turn).padStart(3, '0')} &gt;</span>
                  <span className="px-2 py-0.5 rounded bg-[#141A29] border border-[#232D42] text-[#10B981]">
                    {entry.contentMarkup}
                  </span>
                </div>
              );
            }

            const segments = parseInlineMarkup(
              entry.contentMarkup,
              flags,
              variables,
              inventoryIds
            );
            const paragraphs: MarkupSegment[][] = [[]];
            segments.forEach((seg) => {
              if (seg.type === 'text' && seg.content.includes('\n\n')) {
                const splitParts = seg.content.split('\n\n');
                splitParts.forEach((part, pIdx) => {
                  if (pIdx > 0) paragraphs.push([]);
                  if (part) {
                    paragraphs[paragraphs.length - 1].push({
                      ...seg,
                      content: part,
                    });
                  }
                });
              } else {
                paragraphs[paragraphs.length - 1].push(seg);
              }
            });

            return (
              <article
                key={entry.id}
                className={`rounded-lg p-5 border transition-colors ${
                  entry.type === 'DISCOVERY'
                    ? 'bg-[#141A29] border-[#F59E0B]/40'
                    : entry.type === 'SYSTEM'
                    ? 'bg-[#141A29]/70 border-[#232D42] text-sm'
                    : 'bg-[#141A29]/45 border-[#232D42]'
                }`}
              >
                {entry.roomTitle && (
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#232D42]">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono-code text-[#F59E0B]">
                        CHAMBER
                      </span>
                      <span className="text-xs text-[#64748B]">·</span>
                      <h2 className="text-sm font-semibold text-[#F8FAFC]">
                        {entry.roomTitle}
                      </h2>
                    </div>
                    <span className="text-[11px] font-mono-code text-[#64748B]">
                      TURN {String(entry.turn).padStart(3, '0')}
                    </span>
                  </div>
                )}

                <div className="font-prose text-[18px] leading-[1.75] text-[#E2E8F0] space-y-4">
                  {paragraphs.map((para, pIdx) => (
                    <p
                      key={pIdx}
                      className={
                        entryIdx === narrativeLog.length - 1 &&
                        pIdx === 0 &&
                        entry.type === 'PROSE'
                          ? 'first-letter:text-3xl first-letter:font-semibold first-letter:text-[#F59E0B] first-letter:mr-1'
                          : ''
                      }
                    >
                      {para.map((seg, sIdx) => renderMarkupSegment(seg, sIdx))}
                    </p>
                  ))}
                </div>
              </article>
            );
          })}
          <div ref={logEndRef} />
        </div>
      </div>

      {/* Bottom Hybrid Command Dock */}
      <div className="px-6 py-4 bg-[#141A29] border-t border-[#232D42] shrink-0">
        <div className="max-w-[760px] mx-auto space-y-3">
          {/* Row 1: Story Branch Choices & Compass Exits */}
          <div className="flex flex-wrap items-center gap-2">
            {currentRoom?.exits.map((exit) => renderCompassPill(exit))}

            {visibleChoices.map((choice) => (
              <button
                key={choice.id}
                type="button"
                onClick={() => executeChoice(choice)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-[#1C2539] hover:bg-[#F59E0B]/20 text-[#FDE68A] border border-[#F59E0B]/40 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Sparkles className="w-3 h-3 text-[#F59E0B]" />
                <span>{choice.label}</span>
              </button>
            ))}
          </div>

          {/* Row 2: Natural Language Command Input Bar */}
          <form
            onSubmit={handleFormSubmit}
            className={`relative flex items-center bg-[#0D111A] border rounded-lg px-3.5 py-2 transition-colors ${
              shudderActive
                ? 'animate-shudder border-[#EF4444]'
                : lastCommandStatus === 'valid'
                ? 'border-[#10B981]/60 focus-within:border-[#38BDF8]'
                : 'border-[#232D42] focus-within:border-[#38BDF8]'
            }`}
          >
            <Terminal className="w-4 h-4 text-[#10B981] mr-2.5 shrink-0" />
            <span className="font-mono-code text-sm text-[#10B981] mr-2 select-none">&gt;</span>
            <label htmlFor="parser-command-input" className="sr-only">
              Type a natural-language command
            </label>
            <input
              id="parser-command-input"
              ref={inputRef}
              type="text"
              value={inputVal}
              onChange={(e) => {
                setInputVal(e.target.value);
                soundEngine.playTypewriterChirp();
              }}
              placeholder="Type a command (e.g., take brass lantern, unlock north with rusted key, go east)..."
              className="flex-1 bg-transparent font-mono-code text-sm text-[#F8FAFC] placeholder-[#64748B] focus:outline-none"
              autoComplete="off"
            />
            <button
              type="submit"
              className="ml-2 px-3 py-1 text-xs font-mono-code font-medium bg-[#1C2539] hover:bg-[#10B981] hover:text-[#080A0F] text-[#E2E8F0] rounded border border-[#232D42] transition-colors flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
            >
              <span>Execute</span>
              <CornerDownLeft className="w-3 h-3" />
            </button>
          </form>

          {/* Row 3: Live Smart Parser Autocomplete Suggestions */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
            <span className="text-[11px] font-mono-code text-[#64748B] shrink-0 mr-1">
              SUGGESTIONS:
            </span>
            {suggestions.map((sug) => (
              <button
                key={sug}
                type="button"
                onClick={() => {
                  submitCommand(sug);
                  setInputVal('');
                }}
                className="px-2 py-0.5 text-[11px] font-mono-code text-[#94A3B8] hover:text-[#38BDF8] bg-[#0D111A] hover:bg-[#1C2539] border border-[#232D42] rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                {sug}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
