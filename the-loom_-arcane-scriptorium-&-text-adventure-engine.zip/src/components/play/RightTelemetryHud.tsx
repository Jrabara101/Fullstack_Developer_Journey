import React, { useState } from 'react';
import {
  Backpack,
  BookOpen,
  Box,
  CheckCircle2,
  CircleDot,
  Clock,
  Eye,
  GitBranch,
  History,
  Lock,
  Map as MapIcon,
  Plus,
  RotateCcw,
  Trash2,
  Wand2,
  Wrench,
} from 'lucide-react';
import { useAdventureStore } from '../../store/useAdventureStore';
import { ObservatoryScene3D } from '../three/ObservatoryScene3D';
import { evaluateCondition } from '../../engine/parser';

export const RightTelemetryHud: React.FC = () => {
  const {
    cartridge,
    currentRoomId,
    visitedRoomIds,
    inventoryIds,
    flags,
    variables,
    turnCount,
    historyStack,
    savedBranches,
    rightHudView,
    setRightHudView,
    submitCommand,
    fastTravelToRoom,
    combineInventoryItems,
    undoLastTurn,
    saveBranchCheckpoint,
    loadBranchCheckpoint,
    deleteBranchCheckpoint,
  } = useAdventureStore();

  const [activeTab, setActiveTab] = useState<'inventory' | 'journal' | 'timeturner'>('inventory');
  const [combineFirstId, setCombineFirstId] = useState<string | null>(null);
  const [branchLabelInput, setBranchLabelInput] = useState('');

  const roomsList = Object.values(cartridge.rooms);

  // Compute normalized 2D SVG coordinates for the Auto-Cartographer Blueprint Map
  const minX = Math.min(...roomsList.map((r) => r.editorPosition.x), 0);
  const maxX = Math.max(...roomsList.map((r) => r.editorPosition.x), 800);
  const minY = Math.min(...roomsList.map((r) => r.editorPosition.y), 0);
  const maxY = Math.max(...roomsList.map((r) => r.editorPosition.y), 600);

  const mapCoord = (x: number, y: number) => {
    const spanX = Math.max(maxX - minX, 200);
    const spanY = Math.max(maxY - minY, 200);
    const nx = 48 + ((x - minX) / spanX) * 230;
    const ny = 36 + ((y - minY) / spanY) * 165;
    return { x: nx, y: ny };
  };

  const handleCombineClick = (entityId: string) => {
    if (!combineFirstId) {
      setCombineFirstId(entityId);
    } else if (combineFirstId === entityId) {
      setCombineFirstId(null);
    } else {
      combineInventoryItems(combineFirstId, entityId);
      setCombineFirstId(null);
    }
  };

  return (
    <aside className="w-[360px] h-full bg-[#141A29] flex flex-col shrink-0 overflow-hidden select-none">
      {/* Top Half: Dynamic Auto-Cartographer Map & 3D Spatial Chamber Viewport */}
      <div className="h-[265px] border-b border-[#232D42] flex flex-col shrink-0">
        <div className="px-3.5 py-2 bg-[#0D111A] border-b border-[#232D42] flex items-center justify-between">
          <span className="text-xs font-semibold text-[#F8FAFC] flex items-center gap-1.5">
            {rightHudView === 'scene3d' ? (
              <>
                <Box className="w-3.5 h-3.5 text-[#F59E0B]" />
                <span>3D Spatial Observatory</span>
              </>
            ) : (
              <>
                <MapIcon className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Auto-Cartographer Blueprint</span>
              </>
            )}
          </span>

          {/* Segmented View Switcher */}
          <div className="flex items-center gap-1 bg-[#141A29] p-0.5 rounded-md border border-[#232D42]">
            <button
              type="button"
              onClick={() => setRightHudView('scene3d')}
              className={`px-2 py-0.5 text-[11px] font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
                rightHudView === 'scene3d'
                  ? 'bg-[#1C2539] text-[#F59E0B]'
                  : 'text-[#64748B] hover:text-[#E2E8F0]'
              }`}
            >
              3D Diorama
            </button>
            <button
              type="button"
              onClick={() => setRightHudView('map2d')}
              className={`px-2 py-0.5 text-[11px] font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
                rightHudView === 'map2d'
                  ? 'bg-[#1C2539] text-[#38BDF8]'
                  : 'text-[#64748B] hover:text-[#E2E8F0]'
              }`}
            >
              2D Radar
            </button>
          </div>
        </div>

        <div className="flex-1 relative bg-[#080A0F] overflow-hidden">
          {rightHudView === 'scene3d' ? (
            <ObservatoryScene3D
              cartridge={cartridge}
              currentRoomId={currentRoomId}
              visitedRoomIds={visitedRoomIds}
              flags={flags}
              variant="hud"
              onSelectRoom={fastTravelToRoom}
            />
          ) : (
            <div className="w-full h-full relative bg-blueprint-grid flex items-center justify-center">
              <svg
                viewBox="0 0 330 235"
                className="w-full h-full"
                aria-label="Procedural Fog-of-War Auto-Map"
              >
                {/* Exit conduits */}
                {roomsList.map((room) => {
                  const isSourceVisited = visitedRoomIds.includes(room.id);
                  if (!isSourceVisited) return null;
                  const p1 = mapCoord(room.editorPosition.x, room.editorPosition.y);

                  return room.exits.map((exit) => {
                    const target = cartridge.rooms[exit.targetRoomId];
                    if (!target) return null;
                    const p2 = mapCoord(target.editorPosition.x, target.editorPosition.y);
                    const isTargetVisited = visitedRoomIds.includes(target.id);
                    const isUnlocked =
                      !exit.isLocked ||
                      evaluateCondition(exit.unlockCondition, flags, inventoryIds, variables).met;

                    return (
                      <g key={`${room.id}_${exit.direction}`}>
                        <line
                          x1={p1.x}
                          y1={p1.y}
                          x2={p2.x}
                          y2={p2.y}
                          stroke={!isUnlocked ? '#EF4444' : isTargetVisited ? '#38BDF8' : '#64748B'}
                          strokeWidth={isTargetVisited ? 2 : 1.5}
                          strokeDasharray={isTargetVisited ? undefined : '4 3'}
                          opacity={0.75}
                        />
                        {!isUnlocked && (
                          <circle
                            cx={(p1.x + p2.x) / 2}
                            cy={(p1.y + p2.y) / 2}
                            r={4}
                            fill="#EF4444"
                          />
                        )}
                      </g>
                    );
                  });
                })}

                {/* Room nodes */}
                {roomsList.map((room) => {
                  const isVisited = visitedRoomIds.includes(room.id);
                  const isCurrent = room.id === currentRoomId;
                  // Check if adjacent to any visited room
                  const isAdjacentMystery =
                    !isVisited &&
                    roomsList.some(
                      (r) =>
                        visitedRoomIds.includes(r.id) &&
                        r.exits.some((e) => e.targetRoomId === room.id)
                    );

                  if (!isVisited && !isAdjacentMystery) return null;
                  const pos = mapCoord(room.editorPosition.x, room.editorPosition.y);

                  return (
                    <g
                      key={room.id}
                      onClick={() => {
                        if (isVisited && !isCurrent) fastTravelToRoom(room.id);
                      }}
                      className={isVisited && !isCurrent ? 'cursor-pointer' : ''}
                    >
                      <rect
                        x={pos.x - 18}
                        y={pos.y - 12}
                        width={36}
                        height={24}
                        rx={4}
                        fill={isCurrent ? '#F59E0B' : isVisited ? '#141A29' : '#0D111A'}
                        stroke={isCurrent ? '#FEF3C7' : isVisited ? '#38BDF8' : '#64748B'}
                        strokeWidth={isCurrent ? 2 : 1.5}
                        strokeDasharray={isVisited ? undefined : '3 2'}
                      />
                      <text
                        x={pos.x}
                        y={pos.y + 22}
                        textAnchor="middle"
                        fill={isCurrent ? '#FDE68A' : isVisited ? '#E2E8F0' : '#64748B'}
                        fontSize="8.5"
                        fontFamily="Plus Jakarta Sans, sans-serif"
                        fontWeight={isCurrent ? '600' : '400'}
                      >
                        {isVisited ? room.title.replace(/^The\s+/i, '').slice(0, 16) : 'Unexplored'}
                      </text>
                      {isVisited && room.entityIds.length > 0 && (
                        <circle
                          cx={pos.x + 12}
                          cy={pos.y - 7}
                          r={3}
                          fill={isCurrent ? '#080A0F' : '#38BDF8'}
                        />
                      )}
                    </g>
                  );
                })}
              </svg>
              <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[10px] font-mono-code text-[#64748B]">
                <span>DISCOVERED: {visitedRoomIds.length}/{roomsList.length}</span>
                <span>CLICK EXPLORED NODE TO FAST-TRAVEL</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Half: Tabbed Satchel, Journal & Time-Turner */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div
          role="tablist"
          aria-label="Satchel and Codex Tabs"
          className="grid grid-cols-3 p-1.5 bg-[#0D111A] border-b border-[#232D42] gap-1 shrink-0"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'inventory'}
            onClick={() => setActiveTab('inventory')}
            className={`py-1.5 px-2 text-xs font-medium rounded flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'inventory'
                ? 'bg-[#1C2539] text-[#F8FAFC]'
                : 'text-[#64748B] hover:text-[#E2E8F0]'
            }`}
          >
            <Backpack className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span>Satchel ({inventoryIds.length})</span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'journal'}
            onClick={() => setActiveTab('journal')}
            className={`py-1.5 px-2 text-xs font-medium rounded flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'journal'
                ? 'bg-[#1C2539] text-[#F8FAFC]'
                : 'text-[#64748B] hover:text-[#E2E8F0]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>Codex</span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'timeturner'}
            onClick={() => setActiveTab('timeturner')}
            className={`py-1.5 px-2 text-xs font-medium rounded flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'timeturner'
                ? 'bg-[#1C2539] text-[#F8FAFC]'
                : 'text-[#64748B] hover:text-[#E2E8F0]'
            }`}
          >
            <History className="w-3.5 h-3.5 text-[#A855F7]" />
            <span>Time-Turner</span>
          </button>
        </div>

        {/* Tab Content Panel */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
          {activeTab === 'inventory' && (
            <>
              {combineFirstId && (
                <div className="p-2.5 rounded-lg bg-[#1C2539] border border-[#F59E0B]/50 flex items-center justify-between text-xs">
                  <span className="text-[#FDE68A]">
                    Pairing <strong>{cartridge.entities[combineFirstId]?.name}</strong> — select second relic
                  </span>
                  <button
                    type="button"
                    onClick={() => setCombineFirstId(null)}
                    className="text-[#94A3B8] hover:text-[#F8FAFC] underline ml-2 cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              )}

              {inventoryIds.length === 0 ? (
                <div className="py-10 text-center space-y-2 border border-dashed border-[#232D42] rounded-lg p-4">
                  <Backpack className="w-6 h-6 text-[#64748B] mx-auto" />
                  <p className="text-xs text-[#94A3B8]">Your satchel is empty.</p>
                  <p className="text-[11px] text-[#64748B]">
                    Click cyan nouns in the prose or type <code className="font-mono-code">take [item]</code> to collect relics.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {inventoryIds.map((itemId) => {
                    const ent = cartridge.entities[itemId];
                    if (!ent) return null;
                    const isSelectedForCombine = combineFirstId === itemId;

                    return (
                      <div
                        key={itemId}
                        className={`p-3 rounded-lg bg-[#0D111A] border transition-colors ${
                          isSelectedForCombine ? 'border-[#F59E0B]' : 'border-[#232D42]'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="text-xs font-semibold text-[#F8FAFC]">{ent.name}</h3>
                          {ent.combineWithEntityId && (
                            <span className="text-[10px] font-mono-code text-[#F59E0B]">
                              Combinable
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-2">
                          {ent.description}
                        </p>
                        <div className="flex items-center gap-1.5 mt-2.5">
                          <button
                            type="button"
                            onClick={() => submitCommand(`inspect ${ent.name}`)}
                            className="px-2 py-1 text-[11px] font-medium rounded bg-[#141A29] hover:bg-[#1C2539] text-[#38BDF8] border border-[#232D42] flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3 h-3" />
                            Inspect
                          </button>
                          {ent.isUsable && (
                            <button
                              type="button"
                              onClick={() => submitCommand(`use ${ent.name}`)}
                              className="px-2 py-1 text-[11px] font-medium rounded bg-[#141A29] hover:bg-[#1C2539] text-[#10B981] border border-[#232D42] flex items-center gap-1 cursor-pointer"
                            >
                              <Wand2 className="w-3 h-3" />
                              Use
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleCombineClick(ent.id)}
                            className={`px-2 py-1 text-[11px] font-medium rounded border flex items-center gap-1 cursor-pointer ${
                              isSelectedForCombine
                                ? 'bg-[#F59E0B] text-[#080A0F] border-amber-400'
                                : 'bg-[#141A29] hover:bg-[#1C2539] text-[#FDE68A] border-[#232D42]'
                            }`}
                          >
                            <Wrench className="w-3 h-3" />
                            {combineFirstId && combineFirstId !== ent.id
                              ? 'Combine With'
                              : 'Combine'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {activeTab === 'journal' && (
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2">
                <h3 className="text-xs font-semibold text-[#F8FAFC] uppercase tracking-wider font-mono-code">
                  Expedition Directives
                </h3>
                <ul className="space-y-2 text-xs">
                  <li className="flex items-start gap-2">
                    {flags.lantern_lit ? (
                      <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
                    ) : (
                      <CircleDot className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                    )}
                    <span className={flags.lantern_lit ? 'text-[#64748B] line-through' : 'text-[#E2E8F0]'}>
                      Kindle the Ancient Brass Lantern to pierce the observatory gloom.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    {flags.grate_unlocked ? (
                      <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
                    ) : (
                      <CircleDot className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                    )}
                    <span className={flags.grate_unlocked ? 'text-[#64748B] line-through' : 'text-[#E2E8F0]'}>
                      Recover the Rusted Chronometer Key from the Scriptorium and unlock the Northern Grate.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    {flags.core_installed ? (
                      <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
                    ) : (
                      <CircleDot className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                    )}
                    <span className={flags.core_installed ? 'text-[#64748B] line-through' : 'text-[#E2E8F0]'}>
                      Combine the Fractured Mainspring and Calibrated Escapement Gear, then seat the Core inside the Great Vault.
                    </span>
                  </li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2">
                <h3 className="text-xs font-semibold text-[#F8FAFC] uppercase tracking-wider font-mono-code">
                  Active World Flags
                </h3>
                <div className="space-y-1.5">
                  {Object.entries(flags).map(([key, val]) => (
                    <div
                      key={key}
                      className="flex items-center justify-between text-xs font-mono-code py-1 border-b border-[#232D42]/60 last:border-0"
                    >
                      <span className="text-[#94A3B8]">{key}</span>
                      <span className={val ? 'text-[#10B981]' : 'text-[#64748B]'}>
                        {val ? 'TRUE' : 'FALSE'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'timeturner' && (
            <div className="space-y-3">
              {/* Single-Turn Rewind Card */}
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#F8FAFC] flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#F59E0B]" />
                    <span>Turn Timeline (Turn {turnCount})</span>
                  </span>
                  <span className="text-[11px] font-mono-code text-[#64748B]">
                    {historyStack.length} snapshots
                  </span>
                </div>
                <button
                  type="button"
                  disabled={historyStack.length === 0}
                  onClick={undoLastTurn}
                  className="w-full py-1.5 px-3 text-xs font-medium rounded bg-[#1C2539] hover:bg-[#25314B] disabled:opacity-40 text-[#FDE68A] border border-[#F59E0B]/40 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Rewind Previous Turn (Ctrl+Z)</span>
                </button>
              </div>

              {/* Fork Save Branch */}
              <div className="p-3 rounded-lg bg-[#0D111A] border border-[#232D42] space-y-2">
                <label
                  htmlFor="branch-checkpoint-name"
                  className="block text-xs font-semibold text-[#F8FAFC]"
                >
                  Fork Parallel Save Branch
                </label>
                <div className="flex gap-1.5">
                  <input
                    id="branch-checkpoint-name"
                    type="text"
                    value={branchLabelInput}
                    onChange={(e) => setBranchLabelInput(e.target.value)}
                    placeholder="e.g., Before Vault Ascent..."
                    className="flex-1 px-2.5 py-1.5 text-xs bg-[#141A29] border border-[#232D42] rounded text-[#F8FAFC] placeholder-[#64748B] focus:outline-none focus:border-[#A855F7]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      saveBranchCheckpoint(branchLabelInput);
                      setBranchLabelInput('');
                    }}
                    className="px-2.5 py-1.5 text-xs font-medium rounded bg-[#A855F7] text-[#080A0F] hover:bg-purple-400 flex items-center gap-1 cursor-pointer shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Fork</span>
                  </button>
                </div>
              </div>

              {/* Saved Timeline Branches */}
              <div className="space-y-2">
                {savedBranches.map((b) => (
                  <div
                    key={b.id}
                    className="p-2.5 rounded-lg bg-[#0D111A] border border-[#232D42] flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <GitBranch className="w-3 h-3 text-[#A855F7] shrink-0" />
                        <p className="text-xs font-medium text-[#F8FAFC] truncate">{b.label}</p>
                      </div>
                      <p className="text-[10px] font-mono-code text-[#64748B] mt-0.5">
                        Turn {b.turn} · {b.timestamp}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => loadBranchCheckpoint(b.id)}
                        className="px-2 py-1 text-[11px] font-medium rounded bg-[#141A29] hover:bg-[#A855F7]/20 text-[#C4B5FD] border border-[#232D42] cursor-pointer"
                      >
                        Restore
                      </button>
                      {b.id !== 'branch_origin' && (
                        <button
                          type="button"
                          aria-label={`Delete branch ${b.label}`}
                          onClick={() => deleteBranchCheckpoint(b.id)}
                          className="p-1 text-[#64748B] hover:text-[#EF4444] rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
