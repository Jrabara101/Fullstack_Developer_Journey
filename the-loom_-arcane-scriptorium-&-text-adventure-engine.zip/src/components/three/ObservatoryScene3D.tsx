import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Eye, Compass, RotateCcw, Sparkles } from 'lucide-react';
import { BiomeMood, StoryCartridge } from '../../types/adventure';

interface ObservatoryScene3DProps {
  cartridge: StoryCartridge;
  currentRoomId: string;
  visitedRoomIds: string[];
  flags: Record<string, boolean>;
  variant: 'title' | 'hud';
  onSelectRoom?: (roomId: string) => void;
}

// Pre-allocated scratch math helpers (Zero GC in animation loop)
const _targetPos = new THREE.Vector3();
const _targetLook = new THREE.Vector3();
const _dummyObj = new THREE.Object3D();

const ROOM_3D_COORDS: Record<string, [number, number, number]> = {
  rotunda: [0, 0, 0],
  scriptorium: [4.8, 0, 0.4],
  pendulum_bridge: [-4.8, 0, 0.4],
  subterranean_cistern: [4.8, -2.8, 2.2],
  gear_vault: [0, 0.4, -4.6],
  zenith_dome: [0, 3.8, -4.6],
};

const BIOME_HEX: Record<BiomeMood, number> = {
  sanctuary: 0xf59e0b,
  arcane: 0x38bdf8,
  twilight: 0xa855f7,
  crypt: 0x10b981,
  peril: 0xef4444,
};

function createEngravedBrassTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#162038';
    ctx.fillRect(0, 0, 512, 512);

    ctx.strokeStyle = '#3b4f78';
    ctx.lineWidth = 3;
    for (let r = 40; r <= 240; r += 40) {
      ctx.beginPath();
      ctx.arc(256, 256, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.globalAlpha = 0.65;
    for (let i = 0; i < 12; i++) {
      const angle = (i * Math.PI) / 6;
      ctx.beginPath();
      ctx.moveTo(256 + Math.cos(angle) * 40, 256 + Math.sin(angle) * 40);
      ctx.lineTo(256 + Math.cos(angle) * 240, 256 + Math.sin(angle) * 240);
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

/**
 * Builds a multi-part procedural clockwork chamber node (5-9 distinct parts per room)
 */
function buildProceduralChamberGroup(
  roomId: string,
  biome: BiomeMood,
  dialTexture: THREE.CanvasTexture
): {
  group: THREE.Group;
  animatedParts: THREE.Object3D[];
  emissiveMat: THREE.MeshStandardMaterial;
} {
  const group = new THREE.Group();
  const animatedParts: THREE.Object3D[] = [];
  const accentHex = BIOME_HEX[biome] || 0xf59e0b;

  // Calibrated PBR materials with varied roughness (>= 0.25 delta) & metalness
  const slateBaseMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.72,
    metalness: 0.2,
    map: dialTexture,
  });

  const brushedBrassMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    emissive: 0x78350f,
    emissiveIntensity: 0.35,
    roughness: 0.24,
    metalness: 0.82,
  });

  const darkIronMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.55,
    metalness: 0.65,
  });

  const crystalMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    emissive: accentHex,
    emissiveIntensity: 0.3,
    roughness: 0.18,
    metalness: 0.15,
    transparent: true,
    opacity: 0.75,
  });

  const emissiveMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    emissive: accentHex,
    emissiveIntensity: 1.8,
    roughness: 0.2,
    metalness: 0.3,
  });

  // 1. Soft radial contact shadow plane at y = 0.015
  const shadowGeo = new THREE.CircleGeometry(2.2, 24);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x04060b,
    transparent: true,
    opacity: 0.45,
    depthWrite: false,
  });
  const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
  contactShadow.position.y = 0.015;
  group.add(contactShadow);

  // 2. Primary Silhouette: Octagonal stepped plinth (bottom-center pivot)
  const plinthGeo = new THREE.CylinderGeometry(1.75, 1.95, 0.4, 8);
  plinthGeo.translate(0, 0.2, 0);
  const plinth = new THREE.Mesh(plinthGeo, slateBaseMat);
  plinth.receiveShadow = true;
  group.add(plinth);

  // 3. Secondary Read: Bevelled brass compass rim
  const rimGeo = new THREE.TorusGeometry(1.72, 0.08, 12, 32);
  rimGeo.rotateX(Math.PI / 2);
  const rim = new THREE.Mesh(rimGeo, brushedBrassMat);
  rim.position.y = 0.41;
  group.add(rim);

  // 4. Four corner architectural buttress pillars
  const pillarGeo = new THREE.CylinderGeometry(0.09, 0.12, 1.75, 8);
  pillarGeo.translate(0, 0.875, 0);
  for (let i = 0; i < 4; i++) {
    const angle = (i * Math.PI) / 2 + Math.PI / 4;
    const pillar = new THREE.Mesh(pillarGeo, darkIronMat);
    pillar.position.set(Math.cos(angle) * 1.42, 0.38, Math.sin(angle) * 1.42);
    group.add(pillar);
  }

  // 5. Room-specific Hero Centerpiece (Parts 5-9)
  if (roomId === 'rotunda' || roomId === 'zenith_dome') {
    const pedGeo = new THREE.LatheGeometry(
      [
        new THREE.Vector2(0.42, 0),
        new THREE.Vector2(0.26, 0.35),
        new THREE.Vector2(0.18, 0.75),
        new THREE.Vector2(0.32, 0.95),
      ],
      16
    );
    const pedestal = new THREE.Mesh(pedGeo, darkIronMat);
    pedestal.position.y = 0.38;
    group.add(pedestal);

    const ringOuter = new THREE.Mesh(
      new THREE.TorusGeometry(0.95, 0.055, 12, 36),
      brushedBrassMat
    );
    ringOuter.position.y = 1.55;
    group.add(ringOuter);
    animatedParts.push(ringOuter);

    const ringInner = new THREE.Mesh(
      new THREE.TorusGeometry(0.68, 0.045, 12, 32),
      brushedBrassMat
    );
    ringInner.position.y = 1.55;
    ringInner.rotation.x = Math.PI / 3;
    group.add(ringInner);
    animatedParts.push(ringInner);

    const coreCrystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.34, 0),
      emissiveMat
    );
    coreCrystal.position.y = 1.55;
    group.add(coreCrystal);
    animatedParts.push(coreCrystal);

    const archGeo = new THREE.TorusGeometry(1.42, 0.045, 8, 24, Math.PI);
    const arch1 = new THREE.Mesh(archGeo, crystalMat);
    arch1.position.y = 2.05;
    group.add(arch1);
    const arch2 = new THREE.Mesh(archGeo, crystalMat);
    arch2.position.y = 2.05;
    arch2.rotation.y = Math.PI / 2;
    group.add(arch2);
  } else if (roomId === 'gear_vault') {
    const gearA = new THREE.Mesh(
      new THREE.TorusGeometry(0.82, 0.11, 8, 16),
      brushedBrassMat
    );
    gearA.position.set(-0.35, 1.38, 0);
    group.add(gearA);
    animatedParts.push(gearA);

    const gearB = new THREE.Mesh(
      new THREE.TorusGeometry(0.62, 0.1, 8, 12),
      darkIronMat
    );
    gearB.position.set(0.48, 1.38, 0.2);
    gearB.rotation.y = Math.PI / 2;
    group.add(gearB);
    animatedParts.push(gearB);

    const dynamoCore = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.28, 1.0, 12),
      emissiveMat
    );
    dynamoCore.position.set(0, 1.0, 0);
    group.add(dynamoCore);
  } else if (roomId === 'pendulum_bridge') {
    const gantry = new THREE.Mesh(
      new THREE.BoxGeometry(1.9, 0.14, 0.28),
      darkIronMat
    );
    gantry.position.y = 2.15;
    group.add(gantry);

    const pendulumPivot = new THREE.Group();
    pendulumPivot.position.set(0, 2.1, 0);
    const rod = new THREE.Mesh(
      new THREE.CylinderGeometry(0.03, 0.03, 1.3, 8),
      brushedBrassMat
    );
    rod.position.y = -0.65;
    const bob = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 0.5, 16),
      emissiveMat
    );
    bob.rotation.x = Math.PI;
    bob.position.y = -1.3;
    pendulumPivot.add(rod, bob);
    group.add(pendulumPivot);
    animatedParts.push(pendulumPivot);
  } else {
    const basin = new THREE.Mesh(
      new THREE.CylinderGeometry(1.0, 0.85, 0.28, 16),
      crystalMat
    );
    basin.position.y = 0.52;
    group.add(basin);

    const spireShard = new THREE.Mesh(
      new THREE.ConeGeometry(0.36, 1.2, 6),
      emissiveMat
    );
    spireShard.position.y = 1.35;
    group.add(spireShard);
    animatedParts.push(spireShard);
  }

  return { group, animatedParts, emissiveMat };
}

export const ObservatoryScene3D: React.FC<ObservatoryScene3DProps> = ({
  cartridge,
  currentRoomId,
  visitedRoomIds,
  flags,
  variant,
  onSelectRoom,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [cameraPreset, setCameraPreset] = useState<'focus' | 'overview' | 'zenith'>('focus');
  const [hudCollapsed, setHudCollapsed] = useState(false);

  const stateRef = useRef({
    currentRoomId,
    visitedRoomIds,
    flags,
    variant,
    cameraPreset,
    onSelectRoom,
  });

  useEffect(() => {
    stateRef.current = {
      currentRoomId,
      visitedRoomIds,
      flags,
      variant,
      cameraPreset,
      onSelectRoom,
    };
  }, [currentRoomId, visitedRoomIds, flags, variant, cameraPreset, onSelectRoom]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = Math.max(container.clientWidth, 320);
    const height = Math.max(container.clientHeight, 230);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b101d);
    scene.fog = new THREE.FogExp2(0x0b101d, 0.016);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 120);
    if (stateRef.current.variant === 'title') {
      camera.position.set(1.8, 3.4, 5.2);
    } else {
      camera.position.set(2.8, 2.7, 3.6);
    }

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x1e293b, 1.6);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfde68a, 3.2);
    keyLight.position.set(8, 15, 10);
    keyLight.castShadow = !isSoftwareGl;
    if (!isSoftwareGl) {
      keyLight.shadow.mapSize.set(1024, 1024);
      const d = 12;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.8);
    rimLight.position.set(-10, 8, -8);
    scene.add(rimLight);

    const lanternPointLight = new THREE.PointLight(0xf59e0b, 5.0, 18, 1.5);
    lanternPointLight.position.set(0, 2.5, 0);
    scene.add(lanternPointLight);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 + 0.15;
    controls.minDistance = 2.8;
    controls.maxDistance = 24;
    if (stateRef.current.variant === 'title') {
      controls.target.set(-1.6, 1.0, 0);
    } else {
      controls.target.set(0, 1.1, 0);
    }
    controls.update();

    let userInteracting = false;
    controls.addEventListener('start', () => {
      userInteracting = true;
    });

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const dialTex = createEngravedBrassTexture(maxAniso);

    // Subtle global celestial astrolabe ring beneath the spire
    const grandAstrolabeRing = new THREE.Mesh(
      new THREE.TorusGeometry(6.8, 0.06, 12, 64),
      new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.35 })
    );
    grandAstrolabeRing.rotation.x = Math.PI / 2;
    grandAstrolabeRing.position.y = -0.2;
    scene.add(grandAstrolabeRing);

    const outerGoldRing = new THREE.Mesh(
      new THREE.TorusGeometry(8.4, 0.05, 12, 64),
      new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.4 })
    );
    outerGoldRing.rotation.x = Math.PI / 2;
    outerGoldRing.position.y = -0.2;
    scene.add(outerGoldRing);

    const roomEntries = Object.values(cartridge.rooms);
    const chamberMap = new Map<
      string,
      {
        group: THREE.Group;
        animatedParts: THREE.Object3D[];
        emissiveMat: THREE.MeshStandardMaterial;
        pos: THREE.Vector3;
      }
    >();

    roomEntries.forEach((room, idx) => {
      const coords = ROOM_3D_COORDS[room.id] || [
        ((idx % 3) - 1) * 4.8,
        Math.floor(idx / 3) * 3.0,
        0,
      ];
      const built = buildProceduralChamberGroup(room.id, room.biomeMood, dialTex);
      built.group.position.set(coords[0], coords[1], coords[2]);
      scene.add(built.group);
      chamberMap.set(room.id, {
        ...built,
        pos: new THREE.Vector3(coords[0], coords[1], coords[2]),
      });
    });

    // Connect rooms with glowing brass TubeGeometry conduits
    const conduitMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.25,
      metalness: 0.8,
      emissive: 0xf59e0b,
      emissiveIntensity: 0.65,
    });

    roomEntries.forEach((room) => {
      const fromData = chamberMap.get(room.id);
      if (!fromData) return;
      room.exits.forEach((exit) => {
        const toData = chamberMap.get(exit.targetRoomId);
        if (!toData) return;
        const mid = new THREE.Vector3()
          .addVectors(fromData.pos, toData.pos)
          .multiplyScalar(0.5);
        mid.y += 0.4;
        const curve = new THREE.QuadraticBezierCurve3(
          new THREE.Vector3(fromData.pos.x, fromData.pos.y + 0.4, fromData.pos.z),
          mid,
          new THREE.Vector3(toData.pos.x, toData.pos.y + 0.4, toData.pos.z)
        );
        const tubeGeo = new THREE.TubeGeometry(curve, 16, 0.055, 8, false);
        const tubeMesh = new THREE.Mesh(tubeGeo, conduitMat);
        scene.add(tubeMesh);
      });
    });

    // InstancedMesh Celestial Starfield (> 20 instances)
    const starCount = 140;
    const starGeo = new THREE.OctahedronGeometry(0.08, 0);
    const starMat = new THREE.MeshBasicMaterial({ color: 0xfef3c7 });
    const starInstanced = new THREE.InstancedMesh(starGeo, starMat, starCount);
    const colorPalette = [
      new THREE.Color(0xfde68a),
      new THREE.Color(0x38bdf8),
      new THREE.Color(0xc4b5fd),
    ];

    for (let i = 0; i < starCount; i++) {
      const radius = 11 + (i % 6) * 2.0;
      const theta = (i * 2.39996) % (Math.PI * 2);
      const phi = Math.acos(1 - (2 * (i + 0.5)) / starCount);
      _dummyObj.position.set(
        radius * Math.sin(phi) * Math.cos(theta),
        Math.abs(radius * Math.cos(phi)) - 2,
        radius * Math.sin(phi) * Math.sin(theta)
      );
      const s = 0.8 + (i % 5) * 0.25;
      _dummyObj.scale.set(s, s, s);
      _dummyObj.updateMatrix();
      starInstanced.setMatrixAt(i, _dummyObj.matrix);
      starInstanced.setColorAt(i, colorPalette[i % colorPalette.length]);
    }
    starInstanced.instanceMatrix.needsUpdate = true;
    if (starInstanced.instanceColor) starInstanced.instanceColor.needsUpdate = true;
    starInstanced.computeBoundingSphere();
    scene.add(starInstanced);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = Math.max(entry.contentRect.width, 200);
        const h = Math.max(entry.contentRect.height, 180);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    });
    resizeObserver.observe(container);

    let lastTime = performance.now();
    let elapsed = 0;
    let frameId = 0;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || !gl.fenceSync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const now = performance.now();
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
      elapsed += dt;
      const cur = stateRef.current;

      chamberMap.forEach((chamber, rId) => {
        const isCurrent = rId === cur.currentRoomId;
        const isVisited = cur.visitedRoomIds.includes(rId) || cur.variant === 'title';

        chamber.group.visible = true;
        chamber.emissiveMat.emissiveIntensity = isCurrent
          ? 2.4 + Math.sin(elapsed * 3.5) * 0.45
          : isVisited
          ? 1.1
          : 0.35;

        chamber.animatedParts.forEach((part, idx) => {
          if (rId === 'pendulum_bridge') {
            part.rotation.z = Math.sin(elapsed * 2.0) * 0.32;
          } else {
            part.rotation.y += dt * (0.5 + idx * 0.25);
            part.rotation.x += dt * 0.2 * (idx % 2 === 0 ? 1 : -1);
          }
        });

        if (isCurrent) {
          lanternPointLight.position.set(
            chamber.pos.x,
            chamber.pos.y + 2.4,
            chamber.pos.z
          );
          lanternPointLight.intensity = cur.flags.lantern_lit ? 6.0 : 3.8;
        }
      });

      if (cur.variant === 'title') {
        // Frame the hero chambers on the right half of the viewport so they shine beside the left title lockup
        const orbitAngle = elapsed * 0.22 + 0.55;
        _targetPos.set(
          Math.sin(orbitAngle) * 8.2,
          3.8 + Math.sin(elapsed * 0.4) * 0.6,
          Math.cos(orbitAngle) * 8.2
        );
        _targetLook.set(-1.6, 1.1, -0.5);
        const alpha = 1 - Math.exp(-4.0 * dt);
        camera.position.lerp(_targetPos, alpha);
        controls.target.lerp(_targetLook, alpha);
      } else if (!userInteracting) {
        const activeChamber = chamberMap.get(cur.currentRoomId) || chamberMap.get('rotunda');
        if (activeChamber) {
          if (cur.cameraPreset === 'overview') {
            _targetPos.set(0, 10.5, 10.5);
            _targetLook.set(0, 0.5, -1.5);
          } else if (cur.cameraPreset === 'zenith') {
            _targetPos.set(3.2, 6.4, -1.2);
            _targetLook.set(0, 3.6, -4.6);
          } else {
            _targetPos.set(
              activeChamber.pos.x + 2.6,
              activeChamber.pos.y + 2.3,
              activeChamber.pos.z + 3.3
            );
            _targetLook.set(
              activeChamber.pos.x,
              activeChamber.pos.y + 1.1,
              activeChamber.pos.z
            );
          }
          const alpha = 1 - Math.exp(-5.0 * dt);
          camera.position.lerp(_targetPos, alpha);
          controls.target.lerp(_targetLook, alpha);
        }
      }

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.dispose();
      dialTex.dispose();
      renderer.dispose();
    };
  }, [cartridge.id]);

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#0B101D]">
      {/* Dedicated empty ref container for Three.js WebGL canvas */}
      <div
        ref={mountRef}
        data-testid="observatory-3d-canvas"
        className="w-full h-full"
      />

      {/* Active Chamber Telemetry Label in HUD mode */}
      {variant === 'hud' && (
        <div className="absolute top-2 left-2.5 z-10 pointer-events-none flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#0D111A]/90 border border-[#232D42] text-[10px] font-mono-code text-[#FDE68A]">
          <span>LOCUS:</span>
          <span className="text-[#F8FAFC] font-semibold">
            {cartridge.rooms[currentRoomId]?.title || currentRoomId}
          </span>
        </div>
      )}

      {/* Compact Collapsible Bottom Dock for HUD mode */}
      {variant === 'hud' && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center pointer-events-none w-[94%]">
          <button
            type="button"
            onClick={() => setHudCollapsed((c) => !c)}
            className="pointer-events-auto px-2 py-0.5 text-[10px] font-mono-code bg-[#141A29] text-[#94A3B8] hover:text-[#F8FAFC] border border-[#232D42] rounded-t-md cursor-pointer"
          >
            {hudCollapsed ? '▴ Camera Dock' : '▾ Hide Controls'}
          </button>
          {!hudCollapsed && (
            <div className="pointer-events-auto flex items-center justify-between gap-1.5 px-2.5 py-1.5 bg-[#141A29] border border-[#232D42] rounded-lg shadow-lg w-full">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setCameraPreset('focus')}
                  className={`px-2 py-1 text-[11px] rounded font-medium flex items-center gap-1 cursor-pointer ${
                    cameraPreset === 'focus'
                      ? 'bg-[#F59E0B] text-[#080A0F]'
                      : 'text-[#94A3B8] hover:text-[#F8FAFC] bg-[#1C2539]'
                  }`}
                >
                  <Eye className="w-3 h-3" />
                  Chamber
                </button>
                <button
                  type="button"
                  onClick={() => setCameraPreset('overview')}
                  className={`px-2 py-1 text-[11px] rounded font-medium flex items-center gap-1 cursor-pointer ${
                    cameraPreset === 'overview'
                      ? 'bg-[#F59E0B] text-[#080A0F]'
                      : 'text-[#94A3B8] hover:text-[#F8FAFC] bg-[#1C2539]'
                  }`}
                >
                  <Compass className="w-3 h-3" />
                  Spire Orbit
                </button>
                <button
                  type="button"
                  onClick={() => setCameraPreset('zenith')}
                  className={`px-2 py-1 text-[11px] rounded font-medium flex items-center gap-1 cursor-pointer ${
                    cameraPreset === 'zenith'
                      ? 'bg-[#F59E0B] text-[#080A0F]'
                      : 'text-[#94A3B8] hover:text-[#F8FAFC] bg-[#1C2539]'
                  }`}
                >
                  <Sparkles className="w-3 h-3" />
                  Zenith
                </button>
              </div>
              <button
                type="button"
                aria-label="Reset camera focus"
                onClick={() => setCameraPreset('focus')}
                className="p-1 text-[#94A3B8] hover:text-[#F8FAFC] bg-[#1C2539] rounded cursor-pointer"
                title="Re-center on Active Chamber"
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
