import React, { useEffect, useRef, useState } from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { X } from 'lucide-react';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'emerald';
  size?: 'sm' | 'md' | 'lg' | 'icon';
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'secondary', size = 'md', ...props }, ref) => {
    const variants: Record<NonNullable<ButtonProps['variant']>, string> = {
      primary:
        'bg-[#F59E0B] text-[#080A0F] font-semibold hover:bg-[#FBBF24] border border-amber-400/40 shadow-sm',
      emerald:
        'bg-[#10B981] text-[#080A0F] font-semibold hover:bg-[#34D399] border border-emerald-400/40 shadow-sm',
      secondary:
        'bg-[#1C2539] text-[#E2E8F0] hover:bg-[#25314B] border border-[#232D42]',
      outline:
        'bg-transparent text-[#E2E8F0] hover:bg-[#1C2539] border border-[#232D42]',
      ghost:
        'bg-transparent text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1C2539]/70',
      danger:
        'bg-[#EF4444]/15 text-[#FCA5A5] hover:bg-[#EF4444]/25 border border-[#EF4444]/40',
    };

    const sizes: Record<NonNullable<ButtonProps['size']>, string> = {
      sm: 'px-2.5 py-1 text-xs rounded-md',
      md: 'px-3.5 py-1.5 text-xs font-medium rounded-md',
      lg: 'px-5 py-2.5 text-sm font-semibold rounded-lg',
      icon: 'p-1.5 rounded-md',
    };

    return (
      <button
        ref={ref}
        className={cn(
          'inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/70 disabled:opacity-45 disabled:pointer-events-none cursor-pointer',
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = 'Button';

export const Card: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  className,
  children,
  ...props
}) => (
  <div
    className={cn(
      'bg-[#141A29] border border-[#232D42] rounded-lg text-[#E2E8F0]',
      className
    )}
    {...props}
  >
    {children}
  </div>
);

export interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  children: React.ReactNode;
  maxWidthClass?: string;
}

export const Dialog: React.FC<DialogProps> = ({
  open,
  onOpenChange,
  title,
  description,
  children,
  maxWidthClass = 'max-w-2xl',
}) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={(e) => {
        if (e.target === e.currentTarget) onOpenChange(false);
      }}
    >
      <div
        className={cn(
          'w-full bg-[#141A29] border border-[#232D42] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]',
          maxWidthClass
        )}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#232D42] bg-[#0D111A]">
          <div>
            <h2 className="text-base font-semibold text-[#F8FAFC]">{title}</h2>
            {description && (
              <p className="text-xs text-[#64748B] mt-0.5">{description}</p>
            )}
          </div>
          <button
            type="button"
            aria-label="Close modal"
            onClick={() => onOpenChange(false)}
            className="p-1.5 rounded-md text-[#64748B] hover:text-[#F8FAFC] hover:bg-[#1C2539] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-5 overflow-y-auto flex-1">{children}</div>
      </div>
    </div>
  );
};

export interface PopoverProps {
  trigger: React.ReactNode;
  children: (close: () => void) => React.ReactNode;
  align?: 'start' | 'center' | 'end';
}

export const Popover: React.FC<PopoverProps> = ({
  trigger,
  children,
  align = 'center',
}) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [open]);

  const alignClasses = {
    start: 'left-0',
    center: 'left-1/2 -translate-x-1/2',
    end: 'right-0',
  };

  return (
    <span ref={containerRef} className="relative inline-block">
      <span
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="inline"
      >
        {trigger}
      </span>
      {open && (
        <span
          role="menu"
          className={cn(
            'absolute bottom-full mb-2 z-40 min-w-[200px] bg-[#1C2539] border border-[#38BDF8]/40 rounded-lg shadow-xl p-1.5 block animate-in fade-in zoom-in-95 duration-150',
            alignClasses[align]
          )}
        >
          {children(() => setOpen(false))}
        </span>
      )}
    </span>
  );
};
