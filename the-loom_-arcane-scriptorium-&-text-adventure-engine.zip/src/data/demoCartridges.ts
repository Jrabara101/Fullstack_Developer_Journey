import { StoryCartridge } from '../types/adventure';

export const CLOCKWORK_OBSERVATORY_CARTRIDGE: StoryCartridge = {
  id: 'clockwork_observatory',
  title: 'The Clockwork Observatory',
  author: 'Archivist Vaelen',
  version: '1.4.0',
  synopsis:
    'High atop the Obsidian Spire, the Great Celestial Orrery has seized mid-eclipse. Traverse six interconnected chambers, re-ignite the phosphor lanterns, repair the fractured horological core, and decide whether to restore the dawn or anchor the spire in perpetual starlight.',
  startingRoomId: 'rotunda',
  initialFlags: {
    lantern_lit: false,
    grate_unlocked: false,
    chart_studied: false,
    core_assembled: false,
    core_installed: false,
    pendulum_stabilized: false,
    oracle_consulted: false,
  },
  initialVariables: {
    aether_pressure: 40,
    resonance_harmony: 1,
    chronos_drift: 3,
  },
  entities: {
    lantern_01: {
      id: 'lantern_01',
      name: 'Ancient Brass Lantern',
      aliases: ['lantern', 'brass lantern', 'ancient lantern', 'lamp'],
      description:
        'A heavy octagonal lantern forged from tarnished bell-brass. Its crystal panes are soot-streaked, and its wick thirsts for astral spark.',
      isTakeable: true,
      isUsable: true,
      combineWithEntityId: 'tinderbox_01',
      combinationText:
        'You strike the flint against the astral tinderbox. [glow]A warm amber flame catches inside the Ancient Brass Lantern, banishing the ink-black shadows![/glow]',
      onInspectText:
        'Etched along the brass collar is an inscription: "Carry the amber sun where the Foucault shadow swings." Its reservoir still holds phosphor oil, waiting to be ignited.',
      onUseText:
        'You raise the [glow]Ancient Brass Lantern[/glow]. Its golden beam cuts through the observatory gloom, revealing hairline engravings in the masonry.',
      setFlagsOnUse: ['lantern_lit'],
      setFlagsOnTake: [],
    },
    tinderbox_01: {
      id: 'tinderbox_01',
      name: 'Astral Flint Tinderbox',
      aliases: ['tinderbox', 'flint', 'astral tinderbox', 'sparker'],
      description:
        'A pocket-sized silver striking box filled with star-salt charcloth and a bevelled quartz striker.',
      isTakeable: true,
      isUsable: true,
      combineWithEntityId: 'lantern_01',
      combinationText:
        'Sparks shower into the lantern wick. [glow]The Ancient Brass Lantern blazes to life with steady amber radiance![/glow]',
      onInspectText:
        'Striking the wheel produces pale violet sparks capable of kindling phosphor wicks even in damp subterranean drafts.',
      onUseText:
        'You strike the quartz wheel. A cascade of amber sparks dances across your knuckles—combine it with the [[Ancient Brass Lantern|id:lantern_01|actions:inspect,use]] to sustain the flame.',
      setFlagsOnUse: ['lantern_lit'],
    },
    chronometer_note: {
      id: 'chronometer_note',
      name: 'Astronomer Ledger',
      aliases: ['ledger', 'note', 'journal', 'book', 'astronomer ledger'],
      description:
        'A calfskin ledger bound in brass corners, left open upon the central astrolabe plinth.',
      isTakeable: true,
      isUsable: false,
      onInspectText:
        'The final entry reads: "The northern iron grate is barred against the tremors. I left the [[Rusted Chronometer Key|id:rusted_key|actions:inspect,take]] on my desk in the East Scriptorium. Without uniting the Fractured Mainspring and the Calibrated Escapement Gear inside the Great Vault, the Zenith Dome will remain sealed."',
    },
    rusted_key: {
      id: 'rusted_key',
      name: 'Rusted Chronometer Key',
      aliases: ['key', 'rusted key', 'chronometer key', 'iron key'],
      description:
        'A heavy double-bitted key shaped like an hourglass tooth, coated in red oxide.',
      isTakeable: true,
      isUsable: true,
      unlocksExitDirection: 'north',
      onInspectText:
        'Its bow is stamped with the sigil of the Northern Gear Vault grate.',
      onUseText:
        'You fit the Rusted Chronometer Key into the northern iron grate. With a resonant [shake]CLANG of counterweights[/shake], the rusted tumblers retract!',
      setFlagsOnUse: ['grate_unlocked'],
    },
    star_chart: {
      id: 'star_chart',
      name: 'Vellum Star Chart',
      aliases: ['chart', 'star chart', 'vellum chart', 'map', 'scroll'],
      description:
        'An illuminated celestial map pricked with silver pinholes marking the meridian of the Obsidian Spire.',
      isTakeable: true,
      isUsable: true,
      onInspectText:
        'Pinholes trace the constellation of the Horologium. Margin notes indicate the Zenith Orrery requires Aether Pressure >= 60 and a Synchronized Horological Core.',
      onUseText:
        'You align the Vellum Star Chart against the scriptorium astrolabe. [glow]The celestial coordinates sear themselves into your memory (+1 Resonance Harmony).[/glow]',
      setFlagsOnUse: ['chart_studied'],
      modifyVariablesOnUse: { resonance_harmony: 1 },
    },
    ink_automaton: {
      id: 'ink_automaton',
      name: 'Brass Scribe Automaton',
      aliases: ['automaton', 'scribe', 'brass scribe', 'construct', 'clockwork scribe'],
      description:
        'A hunched clockwork figure seated at the scriptorium lectern, its quill poised over infinite parchment.',
      isTakeable: false,
      isUsable: true,
      onInspectText:
        'Tiny escapement ticks echo inside its ribcage. [whisper]"Find the gear in the cistern below... bind it to the spring from the western span..."[/whisper]',
      onUseText:
        'You wind the dorsal key on the Brass Scribe Automaton. Its porcelain head tilts: [whisper]"The Cistern beneath us holds the Calibrated Escapement Gear. Take the spiral stairs down."[/whisper]',
      setFlagsOnUse: ['oracle_consulted'],
    },
    broken_mainspring: {
      id: 'broken_mainspring',
      name: 'Fractured Mainspring',
      aliases: ['mainspring', 'spring', 'fractured mainspring', 'broken spring', 'coil'],
      description:
        'A coiled ribbon of tempered blue meteoric steel, unspooled from the pendulum housing.',
      isTakeable: true,
      isUsable: true,
      combineWithEntityId: 'escapement_gear',
      combinedResultEntityId: 'synchronized_core',
      combinationText:
        'You seat the Fractured Mainspring into the teeth of the Calibrated Escapement Gear. [glow]With a crisp horological click, they lock together into a humming Synchronized Horological Core![/glow]',
      onInspectText:
        'The temper is still strong, but it needs to be mated with the [[Calibrated Escapement Gear|id:escapement_gear|actions:inspect,take]] to form a working horological core.',
      onUseText:
        'The Fractured Mainspring vibrates softly in your palm. Combine it with the Calibrated Escapement Gear in your satchel.',
    },
    wind_lever: {
      id: 'wind_lever',
      name: 'Barometric Windlass',
      aliases: ['windlass', 'lever', 'barometric windlass', 'wheel', 'valve'],
      description:
        'A cast-iron flywheel coupled to the pneumatic pressure conduits along the bridge parapet.',
      isTakeable: false,
      isUsable: true,
      onInspectText:
        'A brass gauge beside the wheel reads current Aether Pressure. Cranking the wheel stabilizes the Foucault pendulum and boosts pressure.',
      onUseText:
        '[shake]Grinding gears shudder underfoot[/shake] as you haul the Barometric Windlass! Aether Pressure surges through the brass arteries (+25 Aether Pressure) and the Foucault pendulum settles into a steady arc.',
      setFlagsOnUse: ['pendulum_stabilized'],
      modifyVariablesOnUse: { aether_pressure: 25 },
    },
    escapement_gear: {
      id: 'escapement_gear',
      name: 'Calibrated Escapement Gear',
      aliases: ['gear', 'escapement gear', 'cog', 'calibrated gear', 'wheel'],
      description:
        'A precision-milled phosphor-bronze cogwheel with twenty-four bevelled teeth resting on a dry plinth.',
      isTakeable: true,
      isUsable: true,
      combineWithEntityId: 'broken_mainspring',
      combinedResultEntityId: 'synchronized_core',
      combinationText:
        'You mesh the Calibrated Escapement Gear with the Fractured Mainspring. [glow]They fuse into the Synchronized Horological Core, ticking with steady golden pulse![/glow]',
      onInspectText:
        'Every tooth is engraved with a lunar hour. It is designed to interlock directly with the [[Fractured Mainspring|id:broken_mainspring|actions:inspect,take]].',
      onUseText:
        'You spin the Calibrated Escapement Gear on your finger; it rings like a tuning fork. Combine it with the Fractured Mainspring.',
    },
    whispering_bust: {
      id: 'whispering_bust',
      name: 'Oracular Marble Bust',
      aliases: ['bust', 'marble bust', 'statue', 'oracle', 'head'],
      description:
        'A hollow Carrara marble bust of the First Horologist, half-submerged in the mercury mirror pool.',
      isTakeable: false,
      isUsable: true,
      onInspectText:
        'Liquid silver ripples around its collarbone. Acoustic tubes behind its eyes carry whispers from the Zenith Dome.',
      onUseText:
        '[whisper]"When the Core is seated in the Northern Vault, ascend the spiral iris to the Zenith... There, choose between the Dawn of Mortals or the Eternal Astral Choir."[/whisper]',
      setFlagsOnUse: ['oracle_consulted'],
    },
    synchronized_core: {
      id: 'synchronized_core',
      name: 'Synchronized Horological Core',
      aliases: ['core', 'horological core', 'synchronized core', 'assembled core'],
      description:
        'The unified assembly of meteoric mainspring and phosphor-bronze escapement, beating like a mechanical heart.',
      isTakeable: true,
      isUsable: true,
      unlocksExitDirection: 'up',
      onInspectText:
        'Golden sparks arc cleanly across its balance wheel. Install (`use`) this inside the Great Escapement Vault to unseal the Zenith Dome.',
      onUseText:
        'You seat the [glow]Synchronized Horological Core[/glow] into the Prime Astral Cradle! Colossal drive-shafts roar to life, and the overhead brass iris to the Zenith Dome spirals open!',
      setFlagsOnUse: ['core_installed'],
    },
    astral_dynamo: {
      id: 'astral_dynamo',
      name: 'Prime Astral Cradle',
      aliases: ['cradle', 'dynamo', 'astral cradle', 'socket', 'pedestal'],
      description:
        'A towering gimbal housing of interlocking brass rings awaiting the observatory heart.',
      isTakeable: false,
      isUsable: true,
      onInspectText:
        'At the center of the Prime Astral Cradle sits an empty recessed bay shaped for the Synchronized Horological Core.',
      onUseText:
        'You engage the primary clutch on the Prime Astral Cradle. If the Synchronized Horological Core is in your satchel, use the core or choose "Install Synchronized Core" to awaken the spire.',
    },
    zenith_astrolabe: {
      id: 'zenith_astrolabe',
      name: 'Sovereign Orrery Switch',
      aliases: ['orrery', 'switch', 'astrolabe', 'sovereign orrery', 'celestial mechanism'],
      description:
        'The master celestial regulator crowning the Zenith Dome, where planetary spheres of spun glass orbit a captive star.',
      isTakeable: false,
      isUsable: true,
      triggersVictoryOnUse: true,
      victoryTitle: 'The Dawn of Perpetual Starlight',
      victoryEpilogue:
        'As you engage the Sovereign Orrery Switch, the great shutters of the Zenith Dome part before the cosmos. Golden light cascades down every brass conduit of the Spire, restoring time and tide to the waking world.',
      onInspectText:
        'Three concentric rings of brushed gold and sapphire glass await your final command. Using this mechanism will complete your expedition.',
      onUseText:
        '[glow]You throw the Sovereign Orrery Switch! A harmonic chord reverberates through the entire Clockwork Observatory as the celestial spheres lock into true alignment![/glow]',
    },
  },
  rooms: {
    rotunda: {
      id: 'rotunda',
      title: 'The Grand Astrolabe Rotunda',
      biomeMood: 'sanctuary',
      editorPosition: { x: 265, y: 270 },
      descriptionMarkup:
        'Beneath a vaulted ribcage of darkened iron and stained starlight glass, the central rotunda hums with dormant tension. Above your head, [shake]great counterweights shudder against seized gear-trains[/shake]. On a porphyry pedestal rests an [[Ancient Brass Lantern|id:lantern_01|actions:inspect,take,use]], beside an [[Astral Flint Tinderbox|id:tinderbox_01|actions:inspect,take,use]] and a weathered [[Astronomer Ledger|id:chronometer_note|actions:inspect,take]].\n\n{if flag:lantern_lit}[glow]Your lit brass lantern bathes the rotunda floor in warm amber, illuminating the brass compass rose inlaid into the stone.[/glow]{else}[whisper]Cold draughts curl from the western span—lighting the lantern would pierce the gathering gloom.[/whisper]{/if}\n\n{if flag:grate_unlocked}To the north, the heavy iron grate stands unlocked, revealing the Great Escapement Vault.{else}To the north, a massive iron portcullis blocks the passage to the Vault.{/if}',
      entityIds: ['lantern_01', 'tinderbox_01', 'chronometer_note'],
      exits: [
        {
          direction: 'north',
          targetRoomId: 'gear_vault',
          isLocked: true,
          conduitLabel: 'Iron Portcullis',
          lockDescription:
            'The northern iron portcullis is padlocked with a chronometer tumbler. You need the Rusted Chronometer Key (or unlock the grate).',
          unlockCondition: {
            requiredFlags: ['grate_unlocked'],
          },
        },
        {
          direction: 'east',
          targetRoomId: 'scriptorium',
          isLocked: false,
          conduitLabel: 'Archway of Quills',
        },
        {
          direction: 'west',
          targetRoomId: 'pendulum_bridge',
          isLocked: false,
          conduitLabel: 'Wind-Swept Span',
        },
      ],
      choices: [
        {
          id: 'choice_ignite_lantern',
          label: 'Kindle the Ancient Brass Lantern',
          condition: {
            forbiddenFlags: ['lantern_lit'],
          },
          setFlags: ['lantern_lit'],
          responseMarkup:
            'You strike a shower of violet sparks from the flint tinderbox into the oil reservoir. [glow]The Ancient Brass Lantern ignites with a steady golden halo![/glow]',
        },
        {
          id: 'choice_unlock_north',
          label: 'Unlock Northern Grate with Chronometer Key',
          condition: {
            requiredItems: ['rusted_key'],
            forbiddenFlags: ['grate_unlocked'],
          },
          setFlags: ['grate_unlocked'],
          responseMarkup:
            'You turn the [[Rusted Chronometer Key|id:rusted_key|actions:inspect]] inside the northern lock. [shake]Heavy iron bolts retract with a thunderous echo[/shake], opening the way North!',
        },
      ],
    },
    scriptorium: {
      id: 'scriptorium',
      title: 'The Phosphor Scriptorium',
      biomeMood: 'arcane',
      editorPosition: { x: 515, y: 270 },
      descriptionMarkup:
        'Tiered mahogany galleries rise toward a ceiling painted with silver nebulae. Thousands of vellum scrolls rustle in an unseen electrostatic breeze. Seated at the high lectern is a [[Brass Scribe Automaton|id:ink_automaton|actions:inspect,use]], its clockwork fingers twitching over an illuminated [[Vellum Star Chart|id:star_chart|actions:inspect,take,use]]. Glinting inside an open inkwell tray lies a [[Rusted Chronometer Key|id:rusted_key|actions:inspect,take,use]].\n\n{if flag:oracle_consulted}[whisper]The Brass Scribe hums softly: "Descend the spiral stair to the Mercury Cistern..."[/whisper]{/if}',
      entityIds: ['rusted_key', 'star_chart', 'ink_automaton'],
      exits: [
        {
          direction: 'west',
          targetRoomId: 'rotunda',
          isLocked: false,
          conduitLabel: 'Rotunda Arch',
        },
        {
          direction: 'down',
          targetRoomId: 'subterranean_cistern',
          isLocked: false,
          conduitLabel: 'Spiral Iron Stair',
        },
      ],
      choices: [
        {
          id: 'choice_consult_scribe',
          label: 'Wind the Brass Scribe Automaton',
          condition: {
            forbiddenFlags: ['oracle_consulted'],
          },
          setFlags: ['oracle_consulted'],
          responseMarkup:
            'Gears whirr inside the automaton’s chest. [whisper]"Two halves make the heart: the Fractured Mainspring on the Western Span, and the Escapement Gear in the Cistern below."[/whisper]',
        },
      ],
    },
    pendulum_bridge: {
      id: 'pendulum_bridge',
      title: 'The Foucault Pendulum Span',
      biomeMood: 'twilight',
      editorPosition: { x: 15, y: 270 },
      descriptionMarkup:
        'A narrow stone viaduct arches across a dizzying chasm where clouds swirl hundreds of feet below. Suspended from the spire’s spine, a colossal brass Foucault pendulum cuts through the mist. Tangled in the housing rests a [[Fractured Mainspring|id:broken_mainspring|actions:inspect,take,use]], while a heavy [[Barometric Windlass|id:wind_lever|actions:inspect,use]] juts from the parapet.\n\n{if flag:pendulum_stabilized}[glow]The pendulum swings in a serene, harmonic arc, feeding pressurized aether into the upper vault.[/glow]{else}[shake]Violent crosswinds buffet the bridge, threatening to snap the suspension cables![/shake]{/if}',
      entityIds: ['broken_mainspring', 'wind_lever'],
      exits: [
        {
          direction: 'east',
          targetRoomId: 'rotunda',
          isLocked: false,
          conduitLabel: 'East Viaduct',
        },
        {
          direction: 'north',
          targetRoomId: 'gear_vault',
          isLocked: true,
          conduitLabel: 'Maintenance Catwalk',
          lockDescription:
            'The catwalk gate is held shut by pneumatic back-pressure until the Foucault pendulum is stabilized (`use windlass`).',
          unlockCondition: {
            requiredFlags: ['pendulum_stabilized'],
          },
        },
      ],
      choices: [
        {
          id: 'choice_crank_windlass',
          label: 'Haul the Barometric Windlass',
          condition: {
            forbiddenFlags: ['pendulum_stabilized'],
          },
          setFlags: ['pendulum_stabilized'],
          modifyVariables: { aether_pressure: 25 },
          responseMarkup:
            '[shake]You throw your weight against the Barometric Windlass![/shake] Pressurized steam vents from the valves, stabilizing the pendulum and unsealing the northern catwalk to the Gear Vault.',
        },
      ],
    },
    subterranean_cistern: {
      id: 'subterranean_cistern',
      title: 'The Mercury Echo Cistern',
      biomeMood: 'crypt',
      editorPosition: { x: 515, y: 470 },
      descriptionMarkup:
        'At the root of the spire, fluted basalt columns rise from a still basin of liquid mercury that mirrors the vaulting like a silver sky. Half-submerged at the basin’s rim rests an [[Oracular Marble Bust|id:whispering_bust|actions:inspect,use]]. Upon a dry obsidian altar gleams a [[Calibrated Escapement Gear|id:escapement_gear|actions:inspect,take,use]].\n\n{if flag:lantern_lit}[glow]Your lantern’s reflection multiplies infinitely across the mercury pool, revealing submerged geometric runes.[/glow]{else}[whisper]In the dimness, the mercury pool murmurs with forgotten timelines.[/whisper]{/if}',
      entityIds: ['escapement_gear', 'whispering_bust'],
      exits: [
        {
          direction: 'up',
          targetRoomId: 'scriptorium',
          isLocked: false,
          conduitLabel: 'Ascend Spiral Stair',
        },
      ],
      choices: [
        {
          id: 'choice_listen_bust',
          label: 'Listen to the Oracular Marble Bust',
          setFlags: ['oracle_consulted'],
          responseMarkup:
            '[whisper]"Combine the Mainspring and the Escapement Gear within your Satchel to forge the Synchronized Horological Core..."[/whisper]',
        },
      ],
    },
    gear_vault: {
      id: 'gear_vault',
      title: 'The Great Escapement Vault',
      biomeMood: 'peril',
      editorPosition: { x: 265, y: 70 },
      descriptionMarkup:
        'You stand inside the titanic mechanical heart of the observatory. Thirty-foot crown wheels and bevelled pinions tower around a central platform housing the [[Prime Astral Cradle|id:astral_dynamo|actions:inspect,use]]. Directly overhead, a spiraled brass iris leads UP to the Zenith Orrery Dome.\n\n{if flag:core_installed}[glow]The Synchronized Horological Core blazes inside the Prime Astral Cradle! The great gears revolve with thunderous majesty, and the upper iris to the Zenith Dome stands wide open![/glow]{else}[shake]Without a Synchronized Horological Core seated in the Prime Astral Cradle, the massive drive-train groans under lethal strain.[/shake]{/if}',
      entityIds: ['astral_dynamo'],
      exits: [
        {
          direction: 'south',
          targetRoomId: 'rotunda',
          isLocked: false,
          conduitLabel: 'Iron Portcullis',
        },
        {
          direction: 'west',
          targetRoomId: 'pendulum_bridge',
          isLocked: false,
          conduitLabel: 'Maintenance Catwalk',
        },
        {
          direction: 'up',
          targetRoomId: 'zenith_dome',
          isLocked: true,
          conduitLabel: 'Zenith Brass Iris',
          lockDescription:
            'The overhead Zenith Brass Iris is mechanically interlocked. You must forge and install the Synchronized Horological Core (`core_installed`) to open the ascent.',
          unlockCondition: {
            requiredFlags: ['core_installed'],
          },
        },
      ],
      choices: [
        {
          id: 'choice_install_core',
          label: 'Install Synchronized Horological Core into the Cradle',
          condition: {
            requiredItems: ['synchronized_core'],
            forbiddenFlags: ['core_installed'],
          },
          setFlags: ['core_installed', 'grate_unlocked'],
          responseMarkup:
            'You lock the [[Synchronized Horological Core|id:synchronized_core|actions:inspect]] into the Prime Astral Cradle! [glow]A blinding column of golden light shoots upward as the Zenith Brass Iris Dilates open (`go up`)![/glow]',
        },
        {
          id: 'choice_emergency_synthesis',
          label: 'Forge & Seat Core from Mainspring + Escapement Gear',
          condition: {
            requiredItems: ['broken_mainspring', 'escapement_gear'],
            forbiddenFlags: ['core_installed'],
          },
          setFlags: ['core_assembled', 'core_installed', 'grate_unlocked'],
          giveItemIds: ['synchronized_core'],
          responseMarkup:
            'Working directly at the Prime Astral Cradle, you mesh the [[Fractured Mainspring|id:broken_mainspring|actions:inspect]] and [[Calibrated Escapement Gear|id:escapement_gear|actions:inspect]] together and slam the resulting Synchronized Core home! [glow]The overhead Zenith Iris spirals open (`go up`)![/glow]',
        },
      ],
    },
    zenith_dome: {
      id: 'zenith_dome',
      title: 'The Zenith Orrery Dome',
      biomeMood: 'sanctuary',
      editorPosition: { x: 515, y: 70 },
      descriptionMarkup:
        'You emerge beneath the crystalline hemisphere of the Zenith Dome. All around you, concentric armillary rings of brushed gold and sapphire glass revolve in solemn silence against a canopy of wheeling constellations. At the apex stands the [[Sovereign Orrery Switch|id:zenith_astrolabe|actions:inspect,use]], pulsing with captured starlight.\n\n[glow]The fate of the Obsidian Spire rests upon your final calibration.[/glow]',
      entityIds: ['zenith_astrolabe'],
      exits: [
        {
          direction: 'down',
          targetRoomId: 'gear_vault',
          isLocked: false,
          conduitLabel: 'Descend Brass Iris',
        },
      ],
      choices: [
        {
          id: 'choice_ending_dawn',
          label: 'Engage Orrery: Restore the Mortal Dawn',
          triggersVictory: true,
          victoryTitle: 'Ending I — The Dawn of Perpetual Starlight',
          responseMarkup:
            '[glow]You release the eclipse brake on the Sovereign Orrery. The crystalline dome parts, and warm golden daybreak floods the valley below as the Spire chimes the first hour of a renewed age![/glow]',
        },
        {
          id: 'choice_ending_eternal',
          label: 'Anchor the Spire in Astral Eternity',
          triggersVictory: true,
          victoryTitle: 'Ending II — Sovereign of the Astral Choir',
          responseMarkup:
            '[whisper]You lock the meridian rings into the Horologium constellation. The Spire detaches from mortal time, ascending into a luminous sea of eternal starlight where you reign as Arch-Cartographer.[/whisper]',
        },
      ],
    },
  },
};

export const SUNKEN_ARCHIVE_CARTRIDGE: StoryCartridge = {
  id: 'sunken_archive',
  title: 'Whispers of the Sunken Archive',
  author: 'Curator Lyra',
  version: '1.1.0',
  synopsis:
    'Beneath the tidal locks of Old Venetian Murano, a flooded library of glass codices holds the memory of a vanished republic. Navigate the drowned vaults and sound the Resonance Bell.',
  startingRoomId: 'tidal_vestibule',
  initialFlags: {
    sluice_drained: false,
    codex_translated: false,
  },
  initialVariables: {
    tide_level: 3,
    echo_clarity: 2,
  },
  entities: {
    glass_tuning_fork: {
      id: 'glass_tuning_fork',
      name: 'Murano Tuning Fork',
      aliases: ['fork', 'tuning fork', 'glass fork'],
      description: 'A spun-cobalt glass resonator that hums at the frequency of crystal locks.',
      isTakeable: true,
      isUsable: true,
      onInspectText: 'Tapping it produces a pure C-sharp chime that shatters calcified salt.',
      onUseText: '[glow]The Murano Tuning Fork sings through the flooded colonnade, draining the eastern sluice gate![/glow]',
      setFlagsOnUse: ['sluice_drained'],
      unlocksExitDirection: 'east',
    },
    cobalt_codex: {
      id: 'cobalt_codex',
      name: 'Cobalt Glass Codex',
      aliases: ['codex', 'glass codex', 'book', 'tablet'],
      description: 'Wafer-thin plates of translucent blue glass etched with hydro-glyphs.',
      isTakeable: true,
      isUsable: true,
      onInspectText: 'Refracting light through the plates reveals the hymn of the Sunken Bell.',
      onUseText: 'You read the refracted glyphs aloud. [whisper]The drowned archive remembers your voice.[/whisper]',
      setFlagsOnUse: ['codex_translated'],
    },
    abyssal_bell: {
      id: 'abyssal_bell',
      name: 'The Campanile of Tides',
      aliases: ['bell', 'campanile', 'tide bell'],
      description: 'A green-patinated bronze bell suspended above the subterranean lagoon.',
      isTakeable: false,
      isUsable: true,
      triggersVictoryOnUse: true,
      victoryTitle: 'The Rising of the Glass Republic',
      victoryEpilogue: 'At the tolling of the Campanile, the waters part around the Sunken Archive, raising its crystalline domes back into the Venetian sun.',
      onInspectText: 'Strike the bell once the Cobalt Codex has been translated.',
      onUseText: '[glow]The Campanile of Tides tolls across the lagoon, awakening the ancient sea-walls![/glow]',
    },
  },
  rooms: {
    tidal_vestibule: {
      id: 'tidal_vestibule',
      title: 'The Tidal Vestibule',
      biomeMood: 'twilight',
      editorPosition: { x: 260, y: 240 },
      descriptionMarkup:
        'Ankle-deep lagoon water laps against mosaic peacocks. On a marble balustrade gleams a [[Murano Tuning Fork|id:glass_tuning_fork|actions:inspect,take,use]].\n\n{if flag:sluice_drained}[glow]The eastern sluice gate stands open to the Index Hall.[/glow]{else}To the east, a calcified crystal sluice gate bars entry.{/if}',
      entityIds: ['glass_tuning_fork'],
      exits: [
        {
          direction: 'east',
          targetRoomId: 'index_hall',
          isLocked: true,
          conduitLabel: 'Crystal Sluice Gate',
          lockDescription: 'Calcified salt seals the crystal gate. Sound the Murano Tuning Fork to shatter the seal.',
          unlockCondition: { requiredFlags: ['sluice_drained'] },
        },
      ],
      choices: [
        {
          id: 'drain_sluice_choice',
          label: 'Sound the Murano Tuning Fork at the Sluice Gate',
          condition: { requiredItems: ['glass_tuning_fork'], forbiddenFlags: ['sluice_drained'] },
          setFlags: ['sluice_drained'],
          responseMarkup: '[glow]The resonant chime shatters the salt crust! The eastern gate swings open.[/glow]',
        },
      ],
    },
    index_hall: {
      id: 'index_hall',
      title: 'The Hall of Refracted Indices',
      biomeMood: 'arcane',
      editorPosition: { x: 620, y: 240 },
      descriptionMarkup:
        'Submerged chandeliers cast rippling caustics across shelves of glass books. Resting on a brass cradle is the [[Cobalt Glass Codex|id:cobalt_codex|actions:inspect,take,use]] beside the great [[Campanile of Tides|id:abyssal_bell|actions:inspect,use]].',
      entityIds: ['cobalt_codex', 'abyssal_bell'],
      exits: [
        {
          direction: 'west',
          targetRoomId: 'tidal_vestibule',
          isLocked: false,
          conduitLabel: 'Crystal Sluice Gate',
        },
      ],
      choices: [
        {
          id: 'toll_bell_choice',
          label: 'Toll the Campanile of Tides',
          triggersVictory: true,
          victoryTitle: 'The Rising of the Glass Republic',
          responseMarkup: '[glow]The bronze bell rings out, and the sunken library rises from the depths![/glow]',
        },
      ],
    },
  },
};

export const DEMO_CARTRIDGES: StoryCartridge[] = [
  CLOCKWORK_OBSERVATORY_CARTRIDGE,
  SUNKEN_ARCHIVE_CARTRIDGE,
];
