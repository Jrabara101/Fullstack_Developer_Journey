import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseNaturalCommand,
  parseInlineMarkup,
  evaluateCondition,
  executeEngineStep,
  restoreEngineSnapshot,
  encodeCartridgeSeed,
  decodeCartridgeSeed,
} from './parser';
import { CLOCKWORK_OBSERVATORY_CARTRIDGE } from '../data/demoCartridges';
import { EngineRuntimeState } from '../types/adventure';

function createInitialTestState(): EngineRuntimeState {
  const cartridge = JSON.parse(JSON.stringify(CLOCKWORK_OBSERVATORY_CARTRIDGE));
  return {
    mode: 'PLAY',
    shellState: 'playing',
    cartridge,
    currentRoomId: cartridge.startingRoomId,
    visitedRoomIds: [cartridge.startingRoomId],
    inventoryIds: [],
    flags: { ...cartridge.initialFlags },
    variables: { ...cartridge.initialVariables },
    turnCount: 1,
    narrativeLog: [
      {
        id: 'init_1',
        turn: 1,
        type: 'PROSE',
        roomTitle: cartridge.rooms[cartridge.startingRoomId].title,
        roomBiome: cartridge.rooms[cartridge.startingRoomId].biomeMood,
        contentMarkup: cartridge.rooms[cartridge.startingRoomId].descriptionMarkup,
      },
    ],
    historyStack: [],
    savedBranches: [],
    parserLogs: [],
    victoryState: null,
  };
}

test('Natural Language Lexer tokenizes verbs, prepositions, and fuzzy entities', () => {
  const rotunda = CLOCKWORK_OBSERVATORY_CARTRIDGE.rooms.rotunda;
  const parsed = parseNaturalCommand(
    'examine the ancient brass lantern',
    rotunda,
    CLOCKWORK_OBSERVATORY_CARTRIDGE,
    []
  );
  assert.equal(parsed.canonicalVerb, 'ACTION_INSPECT');
  assert.equal(parsed.matchedEntity?.id, 'lantern_01');

  const parsedUnlock = parseNaturalCommand(
    'unlock north grate with rusted key',
    rotunda,
    CLOCKWORK_OBSERVATORY_CARTRIDGE,
    ['rusted_key']
  );
  assert.equal(parsedUnlock.canonicalVerb, 'ACTION_UNLOCK');
  assert.equal(parsedUnlock.direction, 'north');
  assert.equal(parsedUnlock.preposition, 'with');
  assert.equal(parsedUnlock.matchedSecondaryEntity?.id, 'rusted_key');
});

test('Inline Markup Parser resolves {if flag:...}, kinetic tags, and [[Entity]] badges', () => {
  const sample =
    '{if flag:lantern_lit}[glow]Warm light shines on [[Brass Lantern|id:lantern_01|actions:inspect,take]].[/glow]{else}[whisper]Darkness reigns.[/whisper]{/if}';

  const unlitSegments = parseInlineMarkup(sample, { lantern_lit: false });
  assert.equal(unlitSegments.length, 1);
  assert.equal(unlitSegments[0].type, 'text');
  assert.equal(unlitSegments[0].effect, 'whisper');

  const litSegments = parseInlineMarkup(sample, { lantern_lit: true });
  const entitySeg = litSegments.find((s) => s.type === 'entity');
  assert.ok(entitySeg && entitySeg.type === 'entity');
  assert.equal(entitySeg.entityId, 'lantern_01');
  assert.equal(entitySeg.effect, 'glow');
  assert.deepEqual(entitySeg.actions, ['inspect', 'take']);
});

test('Engine state reducer handles taking items, combining relics, unlocking doors, and Undo rewind', () => {
  let state = createInitialTestState();

  // 1. Try going north while locked
  const lockedTry = executeEngineStep(state, 'go north');
  assert.equal(lockedTry.status, 'locked');
  assert.equal(lockedTry.nextState.currentRoomId, 'rotunda');

  // 2. Take lantern in rotunda
  const takeLantern = executeEngineStep(state, 'take ancient brass lantern');
  assert.equal(takeLantern.status, 'valid');
  state = takeLantern.nextState;
  assert.ok(state.inventoryIds.includes('lantern_01'));
  assert.equal(state.turnCount, 2);

  // 3. Move east to scriptorium and take rusted key
  state = executeEngineStep(state, 'go east').nextState;
  assert.equal(state.currentRoomId, 'scriptorium');
  state = executeEngineStep(state, 'take rusted key').nextState;
  assert.ok(state.inventoryIds.includes('rusted_key'));

  // 4. Return west to rotunda and unlock north with key
  state = executeEngineStep(state, 'go west').nextState;
  assert.equal(state.currentRoomId, 'rotunda');
  const unlockStep = executeEngineStep(state, 'unlock north with rusted key');
  assert.equal(unlockStep.status, 'valid');
  state = unlockStep.nextState;
  assert.equal(state.flags.grate_unlocked, true);

  // 5. Move north into gear_vault
  const moveNorth = executeEngineStep(state, 'go north');
  assert.equal(moveNorth.status, 'valid');
  assert.equal(moveNorth.nextState.currentRoomId, 'gear_vault');

  // 6. Test non-destructive single-turn rewind
  const lastSnapshot = moveNorth.nextState.historyStack[moveNorth.nextState.historyStack.length - 1];
  const rewoundState = restoreEngineSnapshot(moveNorth.nextState, lastSnapshot);
  assert.equal(rewoundState.currentRoomId, 'rotunda');
});

test('ConditionRule evaluator checks requiredFlags, forbiddenFlags, requiredItems, and minVariables', () => {
  const rule = {
    requiredFlags: ['lantern_lit'],
    forbiddenFlags: ['trapped'],
    requiredItems: ['rusted_key'],
    minVariables: { aether_pressure: 50 },
  };

  assert.equal(
    evaluateCondition(rule, { lantern_lit: true }, ['rusted_key'], { aether_pressure: 65 }).met,
    true
  );
  assert.equal(
    evaluateCondition(rule, { lantern_lit: true }, ['rusted_key'], { aether_pressure: 30 }).met,
    false
  );
});

test('Cartridge seed encoder and decoder round-trip losslessly', () => {
  const seed = encodeCartridgeSeed(CLOCKWORK_OBSERVATORY_CARTRIDGE);
  const decoded = decodeCartridgeSeed(seed);
  assert.ok(decoded);
  assert.equal(decoded.id, CLOCKWORK_OBSERVATORY_CARTRIDGE.id);
  assert.equal(Object.keys(decoded.rooms).length, 6);
});
