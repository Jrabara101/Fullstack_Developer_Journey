import {
  CanonicalVerb,
  ConditionRule,
  Direction,
  EngineRuntimeState,
  EngineSnapshot,
  MarkupSegment,
  ParsedCommand,
  RoomNode,
  StoryCartridge,
  WorldEntity,
} from '../types/adventure';

const DIRECTION_ALIASES: Record<string, Direction> = {
  north: 'north',
  n: 'north',
  south: 'south',
  s: 'south',
  east: 'east',
  e: 'east',
  west: 'west',
  w: 'west',
  up: 'up',
  u: 'up',
  ascend: 'up',
  climb: 'up',
  down: 'down',
  d: 'down',
  descend: 'down',
};

const VERB_SYNONYMS: Record<string, CanonicalVerb> = {
  go: 'ACTION_MOVE',
  walk: 'ACTION_MOVE',
  move: 'ACTION_MOVE',
  travel: 'ACTION_MOVE',
  enter: 'ACTION_MOVE',
  head: 'ACTION_MOVE',
  north: 'ACTION_MOVE',
  n: 'ACTION_MOVE',
  south: 'ACTION_MOVE',
  s: 'ACTION_MOVE',
  east: 'ACTION_MOVE',
  e: 'ACTION_MOVE',
  west: 'ACTION_MOVE',
  w: 'ACTION_MOVE',
  up: 'ACTION_MOVE',
  u: 'ACTION_MOVE',
  down: 'ACTION_MOVE',
  d: 'ACTION_MOVE',
  ascend: 'ACTION_MOVE',
  descend: 'ACTION_MOVE',

  inspect: 'ACTION_INSPECT',
  examine: 'ACTION_INSPECT',
  look: 'ACTION_INSPECT',
  x: 'ACTION_INSPECT',
  read: 'ACTION_INSPECT',
  study: 'ACTION_INSPECT',
  check: 'ACTION_INSPECT',
  observe: 'ACTION_INSPECT',
  search: 'ACTION_INSPECT',

  take: 'ACTION_TAKE',
  get: 'ACTION_TAKE',
  grab: 'ACTION_TAKE',
  pick: 'ACTION_TAKE',
  collect: 'ACTION_TAKE',
  acquire: 'ACTION_TAKE',
  carry: 'ACTION_TAKE',

  drop: 'ACTION_DROP',
  leave: 'ACTION_DROP',
  discard: 'ACTION_DROP',

  use: 'ACTION_USE',
  ignite: 'ACTION_USE',
  light: 'ACTION_USE',
  kindle: 'ACTION_USE',
  activate: 'ACTION_USE',
  pull: 'ACTION_USE',
  push: 'ACTION_USE',
  turn: 'ACTION_USE',
  crank: 'ACTION_USE',
  haul: 'ACTION_USE',
  wind: 'ACTION_USE',
  install: 'ACTION_USE',
  insert: 'ACTION_USE',
  ring: 'ACTION_USE',
  sound: 'ACTION_USE',
  strike: 'ACTION_USE',

  combine: 'ACTION_COMBINE',
  merge: 'ACTION_COMBINE',
  craft: 'ACTION_COMBINE',
  join: 'ACTION_COMBINE',
  connect: 'ACTION_COMBINE',
  pair: 'ACTION_COMBINE',
  assemble: 'ACTION_COMBINE',

  unlock: 'ACTION_UNLOCK',
  open: 'ACTION_UNLOCK',
  unseal: 'ACTION_UNLOCK',

  talk: 'ACTION_TALK',
  speak: 'ACTION_TALK',
  ask: 'ACTION_TALK',
  consult: 'ACTION_TALK',
  listen: 'ACTION_TALK',

  inventory: 'ACTION_INVENTORY',
  inv: 'ACTION_INVENTORY',
  i: 'ACTION_INVENTORY',
  satchel: 'ACTION_INVENTORY',

  help: 'ACTION_HELP',
  hint: 'ACTION_HELP',
  commands: 'ACTION_HELP',

  wait: 'ACTION_WAIT',
  z: 'ACTION_WAIT',
};

const STOP_WORDS = new Set(['the', 'a', 'an', 'at', 'to', 'in', 'into', 'on', 'onto', 'up', 'around']);
const PREPOSITIONS = new Set(['with', 'using', 'on', 'into', 'to', 'and']);

/**
 * Fuzzy matches a noun phrase against available entities in the room or player inventory.
 */
export function findMatchingEntity(
  phrase: string | undefined,
  room: RoomNode,
  cartridge: StoryCartridge,
  inventoryIds: string[]
): WorldEntity | undefined {
  if (!phrase) return undefined;
  const normalized = phrase.trim().toLowerCase();
  if (!normalized) return undefined;

  const accessibleIds = Array.from(new Set([...room.entityIds, ...inventoryIds]));
  const accessibleEntities = accessibleIds
    .map((id) => cartridge.entities[id])
    .filter((e): e is WorldEntity => Boolean(e));

  // 1. Exact ID, name, or alias match
  for (const entity of accessibleEntities) {
    if (
      entity.id.toLowerCase() === normalized ||
      entity.name.toLowerCase() === normalized ||
      entity.aliases.some((a) => a.toLowerCase() === normalized)
    ) {
      return entity;
    }
  }

  // 2. Substring or token overlap match
  for (const entity of accessibleEntities) {
    const haystacks = [entity.name.toLowerCase(), ...entity.aliases.map((a) => a.toLowerCase())];
    if (haystacks.some((h) => h.includes(normalized) || normalized.includes(h))) {
      return entity;
    }
  }

  return undefined;
}

/**
 * Natural Language Lexer: Tokenizes player text input into
 * { verb, canonicalVerb, directObject, preposition, indirectObject, direction, matchedEntity, matchedSecondaryEntity }
 */
export function parseNaturalCommand(
  input: string,
  currentRoom: RoomNode,
  cartridge: StoryCartridge,
  inventoryIds: string[]
): ParsedCommand {
  const raw = input.trim();
  const cleaned = raw
    .toLowerCase()
    .replace(/[^\w\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleaned) {
    return { raw, verb: '', canonicalVerb: 'ACTION_UNKNOWN' };
  }

  const rawTokens = cleaned.split(' ');

  // Handle single-word or multi-word look around
  if (cleaned === 'look' || cleaned === 'look around' || cleaned === 'l') {
    return {
      raw,
      verb: 'look',
      canonicalVerb: 'ACTION_LOOK',
    };
  }

  // Handle "pick up X" or "look at X"
  let verbToken = rawTokens[0];
  let restTokens = rawTokens.slice(1);

  if (verbToken === 'pick' && restTokens[0] === 'up') {
    restTokens = restTokens.slice(1);
  } else if (
    (verbToken === 'look' || verbToken === 'talk' || verbToken === 'speak' || verbToken === 'listen') &&
    (restTokens[0] === 'at' || restTokens[0] === 'to' || restTokens[0] === 'in')
  ) {
    restTokens = restTokens.slice(1);
  }

  const canonicalVerb: CanonicalVerb = VERB_SYNONYMS[verbToken] ?? 'ACTION_UNKNOWN';

  // Check if the command is a bare direction ("north", "n", "up") or "go north"
  if (DIRECTION_ALIASES[verbToken] && restTokens.length === 0) {
    return {
      raw,
      verb: verbToken,
      canonicalVerb: 'ACTION_MOVE',
      direction: DIRECTION_ALIASES[verbToken],
    };
  }

  if (canonicalVerb === 'ACTION_MOVE' && restTokens.length > 0) {
    const dirCandidate = restTokens.find((t) => DIRECTION_ALIASES[t]);
    if (dirCandidate) {
      return {
        raw,
        verb: verbToken,
        canonicalVerb: 'ACTION_MOVE',
        directObject: dirCandidate,
        direction: DIRECTION_ALIASES[dirCandidate],
      };
    }
  }

  // Split remaining tokens around prepositions ('with', 'using', 'and', 'on', 'into', 'to')
  let prepIndex = -1;
  let preposition: string | undefined;
  for (let i = 0; i < restTokens.length; i++) {
    if (PREPOSITIONS.has(restTokens[i])) {
      prepIndex = i;
      preposition = restTokens[i];
      break;
    }
  }

  const filterArticles = (tokens: string[]) =>
    tokens.filter((t) => !STOP_WORDS.has(t) || DIRECTION_ALIASES[t]).join(' ').trim();

  let directObject: string | undefined;
  let indirectObject: string | undefined;

  if (prepIndex !== -1) {
    directObject = filterArticles(restTokens.slice(0, prepIndex));
    indirectObject = filterArticles(restTokens.slice(prepIndex + 1));
  } else {
    directObject = filterArticles(restTokens);
  }

  // Also check if directObject specifies a direction (e.g. "unlock north grate")
  let direction: Direction | undefined;
  for (const token of restTokens) {
    if (DIRECTION_ALIASES[token]) {
      direction = DIRECTION_ALIASES[token];
      break;
    }
  }

  const matchedEntity = findMatchingEntity(directObject, currentRoom, cartridge, inventoryIds);
  const matchedSecondaryEntity = findMatchingEntity(indirectObject, currentRoom, cartridge, inventoryIds);

  return {
    raw,
    verb: verbToken,
    canonicalVerb,
    directObject: directObject || undefined,
    preposition,
    indirectObject: indirectObject || undefined,
    direction,
    matchedEntity,
    matchedSecondaryEntity,
  };
}

/**
 * Evaluates a ConditionRule against current runtime flags, inventory, and variables.
 */
export function evaluateCondition(
  condition: ConditionRule | undefined,
  flags: Record<string, boolean>,
  inventoryIds: string[],
  variables: Record<string, number>
): { met: boolean; reason?: string } {
  if (!condition) return { met: true };

  if (condition.requiredFlags) {
    for (const flag of condition.requiredFlags) {
      if (!flags[flag]) {
        return { met: false, reason: `Requires flag "${flag}"` };
      }
    }
  }

  if (condition.forbiddenFlags) {
    for (const flag of condition.forbiddenFlags) {
      if (flags[flag]) {
        return { met: false, reason: `Blocked by flag "${flag}"` };
      }
    }
  }

  if (condition.requiredItems) {
    for (const itemId of condition.requiredItems) {
      if (!inventoryIds.includes(itemId)) {
        return { met: false, reason: `Requires item "${itemId}"` };
      }
    }
  }

  if (condition.minVariables) {
    for (const [varName, minVal] of Object.entries(condition.minVariables)) {
      const currentVal = variables[varName] ?? 0;
      if (currentVal < minVal) {
        return { met: false, reason: `Requires ${varName} >= ${minVal} (currently ${currentVal})` };
      }
    }
  }

  return { met: true };
}

/**
 * Inline Interactive Markup Parser:
 * Evaluates conditional prose `{if flag:lantern_lit}...{else}...{/if}` and `{if item:rusted_key}...{/if}`,
 * kinetic text tags `[shake]...[/shake]`, `[glow]...[/glow]`, `[whisper]...[/whisper]`,
 * and inline interactive entity badges `[[Ancient Lantern|id:lantern_01|actions:inspect,take,use]]`.
 */
export function parseInlineMarkup(
  markup: string,
  flags: Record<string, boolean>,
  variables: Record<string, number> = {},
  inventoryIds: string[] = []
): MarkupSegment[] {
  if (!markup) return [];

  // Step 1: Resolve {if ...}...{else}...{/if} blocks
  const resolvedConditionals = markup.replace(
    /\{if\s+([^}]+)\}([\s\S]*?)\{\/if\}/g,
    (_match, condExpr: string, innerContent: string) => {
      const parts = innerContent.split('{else}');
      const trueBranch = parts[0] ?? '';
      const falseBranch = parts[1] ?? '';

      const trimmedCond = condExpr.trim();
      let isTrue = false;

      if (trimmedCond.startsWith('flag:')) {
        const flagName = trimmedCond.slice(5).trim();
        isTrue = Boolean(flags[flagName]);
      } else if (trimmedCond.startsWith('!flag:')) {
        const flagName = trimmedCond.slice(6).trim();
        isTrue = !flags[flagName];
      } else if (trimmedCond.startsWith('item:')) {
        const itemId = trimmedCond.slice(5).trim();
        isTrue = inventoryIds.includes(itemId);
      } else if (trimmedCond.includes('>=')) {
        const [varPart, valPart] = trimmedCond.split('>=').map((s) => s.trim());
        const cleanVar = varPart.replace(/^var:/, '');
        isTrue = (variables[cleanVar] ?? 0) >= Number(valPart);
      } else {
        isTrue = Boolean(flags[trimmedCond]);
      }

      return isTrue ? trueBranch : falseBranch;
    }
  );

  // Step 2: Parse kinetic effect wrappers [shake]...[/shake], [glow]...[/glow], [whisper]...[/whisper]
  // and inline entities [[Label|id:...|actions:...]]
  const segments: MarkupSegment[] = [];

  const parseEntitiesWithinChunk = (chunk: string, effect?: 'shake' | 'glow' | 'whisper') => {
    const entityRegex = /\[\[([^\]]+)\]\]/g;
    let lastIdx = 0;
    let match: RegExpExecArray | null;

    while ((match = entityRegex.exec(chunk)) !== null) {
      if (match.index > lastIdx) {
        segments.push({
          type: 'text',
          content: chunk.slice(lastIdx, match.index),
          effect,
        });
      }

      const rawSpec = match[1];
      const specParts = rawSpec.split('|').map((s) => s.trim());
      const label = specParts[0];
      let entityId = label.toLowerCase().replace(/\s+/g, '_');
      let actions = ['inspect', 'take', 'use'];

      for (const part of specParts.slice(1)) {
        if (part.startsWith('id:')) {
          entityId = part.slice(3).trim();
        } else if (part.startsWith('actions:')) {
          actions = part
            .slice(8)
            .split(',')
            .map((a) => a.trim())
            .filter(Boolean);
        }
      }

      segments.push({
        type: 'entity',
        label,
        entityId,
        actions,
        effect,
      });

      lastIdx = entityRegex.lastIndex;
    }

    if (lastIdx < chunk.length) {
      segments.push({
        type: 'text',
        content: chunk.slice(lastIdx),
        effect,
      });
    }
  };

  const kineticRegex = /\[(shake|glow|whisper)\]([\s\S]*?)\[\/\1\]/g;
  let lastKineticIdx = 0;
  let kineticMatch: RegExpExecArray | null;

  while ((kineticMatch = kineticRegex.exec(resolvedConditionals)) !== null) {
    if (kineticMatch.index > lastKineticIdx) {
      parseEntitiesWithinChunk(resolvedConditionals.slice(lastKineticIdx, kineticMatch.index), undefined);
    }
    const effectType = kineticMatch[1] as 'shake' | 'glow' | 'whisper';
    parseEntitiesWithinChunk(kineticMatch[2], effectType);
    lastKineticIdx = kineticRegex.lastIndex;
  }

  if (lastKineticIdx < resolvedConditionals.length) {
    parseEntitiesWithinChunk(resolvedConditionals.slice(lastKineticIdx), undefined);
  }

  return segments;
}

/**
 * Generates contextual real-time autocomplete command suggestions based on current room & inventory.
 */
export function getAutocompleteSuggestions(
  partialInput: string,
  currentRoom: RoomNode,
  cartridge: StoryCartridge,
  inventoryIds: string[]
): string[] {
  const query = partialInput.trim().toLowerCase();
  const candidates: string[] = [];

  // Room exits
  for (const exit of currentRoom.exits) {
    candidates.push(`go ${exit.direction}`);
    if (exit.isLocked) {
      candidates.push(`unlock ${exit.direction} door`);
    }
  }

  // Room entities
  for (const entityId of currentRoom.entityIds) {
    const ent = cartridge.entities[entityId];
    if (!ent) continue;
    const shortName = ent.aliases[0] || ent.name.toLowerCase();
    candidates.push(`inspect ${shortName}`);
    if (ent.isTakeable) {
      candidates.push(`take ${shortName}`);
    }
    if (ent.isUsable) {
      candidates.push(`use ${shortName}`);
    }
  }

  // Inventory entities
  for (const itemId of inventoryIds) {
    const ent = cartridge.entities[itemId];
    if (!ent) continue;
    const shortName = ent.aliases[0] || ent.name.toLowerCase();
    candidates.push(`inspect ${shortName}`);
    if (ent.isUsable) {
      candidates.push(`use ${shortName}`);
    }
    if (ent.combineWithEntityId && inventoryIds.includes(ent.combineWithEntityId)) {
      const partner = cartridge.entities[ent.combineWithEntityId];
      if (partner) {
        const partnerName = partner.aliases[0] || partner.name.toLowerCase();
        candidates.push(`combine ${shortName} with ${partnerName}`);
      }
    }
  }

  candidates.push('look around', 'inventory', 'help');

  const unique = Array.from(new Set(candidates));
  if (!query) return unique.slice(0, 6);

  return unique
    .filter((cmd) => cmd.toLowerCase().includes(query) && cmd.toLowerCase() !== query)
    .slice(0, 6);
}

/**
 * Serializes current play state into a compact snapshot for Undo/Rewind & Save Forking.
 */
export function createEngineSnapshot(state: EngineRuntimeState): string {
  const roomEntities: Record<string, string[]> = {};
  const roomExitLocks: Record<string, Record<string, boolean>> = {};

  for (const [roomId, room] of Object.entries(state.cartridge.rooms)) {
    roomEntities[roomId] = [...room.entityIds];
    roomExitLocks[roomId] = {};
    for (const exit of room.exits) {
      roomExitLocks[roomId][exit.direction] = Boolean(exit.isLocked);
    }
  }

  const snapshot: EngineSnapshot = {
    currentRoomId: state.currentRoomId,
    visitedRoomIds: [...state.visitedRoomIds],
    inventoryIds: [...state.inventoryIds],
    flags: { ...state.flags },
    variables: { ...state.variables },
    turnCount: state.turnCount,
    narrativeLog: state.narrativeLog.map((entry) => ({ ...entry })),
    roomEntities,
    roomExitLocks,
  };

  return JSON.stringify(snapshot);
}

/**
 * Restores an EngineSnapshot back into an EngineRuntimeState non-destructively.
 */
export function restoreEngineSnapshot(
  state: EngineRuntimeState,
  snapshotJson: string
): EngineRuntimeState {
  const snapshot = JSON.parse(snapshotJson) as EngineSnapshot;
  const updatedRooms: Record<string, RoomNode> = {};

  for (const [roomId, room] of Object.entries(state.cartridge.rooms)) {
    updatedRooms[roomId] = {
      ...room,
      entityIds: snapshot.roomEntities[roomId] ?? [...room.entityIds],
      exits: room.exits.map((exit) => ({
        ...exit,
        isLocked:
          snapshot.roomExitLocks[roomId]?.[exit.direction] !== undefined
            ? snapshot.roomExitLocks[roomId][exit.direction]
            : exit.isLocked,
      })),
    };
  }

  return {
    ...state,
    cartridge: {
      ...state.cartridge,
      rooms: updatedRooms,
    },
    currentRoomId: snapshot.currentRoomId,
    visitedRoomIds: snapshot.visitedRoomIds,
    inventoryIds: snapshot.inventoryIds,
    flags: snapshot.flags,
    variables: snapshot.variables,
    turnCount: snapshot.turnCount,
    narrativeLog: snapshot.narrativeLog,
    victoryState: null,
    shellState: state.shellState === 'gameover' ? 'playing' : state.shellState,
  };
}

/**
 * Executes a single player command against the EngineRuntimeState and returns the updated state.
 */
export function executeEngineStep(
  state: EngineRuntimeState,
  rawCommand: string
): {
  nextState: EngineRuntimeState;
  status: 'valid' | 'invalid' | 'locked' | 'victory';
} {
  const currentRoom = state.cartridge.rooms[state.currentRoomId];
  if (!currentRoom) {
    return { nextState: state, status: 'invalid' };
  }

  const parsed = parseNaturalCommand(rawCommand, currentRoom, state.cartridge, state.inventoryIds);
  const snapshotBefore = createEngineSnapshot(state);
  const nextTurn = state.turnCount + 1;

  // Deep clone mutable parts
  const nextFlags = { ...state.flags };
  const nextVariables = { ...state.variables };
  let nextInventory = [...state.inventoryIds];
  let nextRoomId = state.currentRoomId;
  const nextVisited = [...state.visitedRoomIds];
  const nextRooms: Record<string, RoomNode> = {};
  for (const [rId, rNode] of Object.entries(state.cartridge.rooms)) {
    nextRooms[rId] = {
      ...rNode,
      entityIds: [...rNode.entityIds],
      exits: rNode.exits.map((e) => ({ ...e })),
    };
  }

  const echoEntry = {
    id: `log_${Date.now()}_echo_${nextTurn}`,
    turn: nextTurn,
    type: 'COMMAND_ECHO' as const,
    contentMarkup: rawCommand,
  };

  const appendLog = (
    type: 'PROSE' | 'SYSTEM' | 'DISCOVERY',
    contentMarkup: string,
    roomTitle?: string,
    roomBiome?: RoomNode['biomeMood']
  ) => [
    ...state.narrativeLog,
    echoEntry,
    {
      id: `log_${Date.now()}_res_${nextTurn}`,
      turn: nextTurn,
      type,
      roomTitle,
      roomBiome,
      contentMarkup,
    },
  ];

  let status: 'valid' | 'invalid' | 'locked' | 'victory' = 'valid';
  let nextLog = state.narrativeLog;
  let victoryState = state.victoryState;

  const activeRoom = nextRooms[state.currentRoomId];

  switch (parsed.canonicalVerb) {
    case 'ACTION_LOOK': {
      nextLog = appendLog(
        'PROSE',
        activeRoom.descriptionMarkup,
        activeRoom.title,
        activeRoom.biomeMood
      );
      break;
    }

    case 'ACTION_INVENTORY': {
      if (nextInventory.length === 0) {
        nextLog = appendLog('SYSTEM', 'Your satchel is currently empty.');
      } else {
        const names = nextInventory
          .map((id) => {
            const e = state.cartridge.entities[id];
            return e ? `[[${e.name}|id:${e.id}|actions:inspect,use]]` : id;
          })
          .join(', ');
        nextLog = appendLog('SYSTEM', `You are carrying: ${names}.`);
      }
      break;
    }

    case 'ACTION_HELP': {
      nextLog = appendLog(
        'SYSTEM',
        'Available commands: `go [north/south/east/west/up/down]`, `inspect [object]`, `take [item]`, `use [item]`, `combine [item A] with [item B]`, `unlock [direction] with [key]`, or click any highlighted cyan noun directly in the prose.'
      );
      break;
    }

    case 'ACTION_WAIT': {
      nextVariables.chronos_drift = (nextVariables.chronos_drift ?? 0) + 1;
      nextLog = appendLog(
        'PROSE',
        '[whisper]Time ticks forward inside the spire. Distant escapement gears advance by one tooth.[/whisper]'
      );
      break;
    }

    case 'ACTION_MOVE': {
      const dir = parsed.direction;
      if (!dir) {
        status = 'invalid';
        nextLog = appendLog(
          'SYSTEM',
          'Specify a compass direction (`north`, `south`, `east`, `west`, `up`, `down`).'
        );
        break;
      }

      const exit = activeRoom.exits.find((e) => e.direction === dir);
      if (!exit) {
        status = 'invalid';
        nextLog = appendLog('SYSTEM', `There is no passage leading ${dir.toUpperCase()} from here.`);
        break;
      }

      // Check if exit can be auto-unlocked by condition
      if (exit.isLocked) {
        const condResult = evaluateCondition(
          exit.unlockCondition,
          nextFlags,
          nextInventory,
          nextVariables
        );
        if (condResult.met) {
          exit.isLocked = false;
        } else {
          status = 'locked';
          nextLog = appendLog(
            'SYSTEM',
            `[shake]Locked Passage (${dir.toUpperCase()}):[/shake] ${
              exit.lockDescription || 'The way is sealed.'
            }`
          );
          break;
        }
      }

      const targetRoom = nextRooms[exit.targetRoomId];
      if (!targetRoom) {
        status = 'invalid';
        nextLog = appendLog('SYSTEM', 'That passage leads into an unmapped void.');
        break;
      }

      nextRoomId = targetRoom.id;
      if (!nextVisited.includes(targetRoom.id)) {
        nextVisited.push(targetRoom.id);
      }
      if (targetRoom.onEnterSetFlags) {
        for (const f of targetRoom.onEnterSetFlags) {
          nextFlags[f] = true;
        }
      }

      nextLog = appendLog(
        'PROSE',
        targetRoom.descriptionMarkup,
        targetRoom.title,
        targetRoom.biomeMood
      );
      break;
    }

    case 'ACTION_INSPECT': {
      if (!parsed.directObject) {
        nextLog = appendLog(
          'PROSE',
          activeRoom.descriptionMarkup,
          activeRoom.title,
          activeRoom.biomeMood
        );
        break;
      }
      const ent = parsed.matchedEntity;
      if (!ent) {
        status = 'invalid';
        nextLog = appendLog(
          'SYSTEM',
          `You do not see "${parsed.directObject}" here or in your satchel.`
        );
        break;
      }
      const text = ent.onInspectText ? `${ent.description}\n\n${ent.onInspectText}` : ent.description;
      nextLog = appendLog('PROSE', text);
      break;
    }

    case 'ACTION_TAKE': {
      const ent = parsed.matchedEntity;
      if (!ent) {
        status = 'invalid';
        nextLog = appendLog(
          'SYSTEM',
          `You cannot find "${parsed.directObject || 'that'}" to pick up.`
        );
        break;
      }
      if (nextInventory.includes(ent.id)) {
        nextLog = appendLog('SYSTEM', `You already have the ${ent.name} in your satchel.`);
        break;
      }
      if (!activeRoom.entityIds.includes(ent.id)) {
        status = 'invalid';
        nextLog = appendLog('SYSTEM', `The ${ent.name} is not in this chamber.`);
        break;
      }
      if (!ent.isTakeable) {
        status = 'invalid';
        nextLog = appendLog(
          'SYSTEM',
          `The ${ent.name} is anchored fast and cannot be carried.`
        );
        break;
      }

      activeRoom.entityIds = activeRoom.entityIds.filter((id) => id !== ent.id);
      nextInventory.push(ent.id);
      if (ent.setFlagsOnTake) {
        for (const f of ent.setFlagsOnTake) {
          nextFlags[f] = true;
        }
      }

      nextLog = appendLog(
        'DISCOVERY',
        `Added [[${ent.name}|id:${ent.id}|actions:inspect,use]] to your satchel. ${ent.description}`
      );
      break;
    }

    case 'ACTION_DROP': {
      const ent = parsed.matchedEntity;
      if (!ent || !nextInventory.includes(ent.id)) {
        status = 'invalid';
        nextLog = appendLog('SYSTEM', 'You are not carrying that item.');
        break;
      }
      nextInventory = nextInventory.filter((id) => id !== ent.id);
      activeRoom.entityIds.push(ent.id);
      nextLog = appendLog('SYSTEM', `You set down the ${ent.name} in ${activeRoom.title}.`);
      break;
    }

    case 'ACTION_COMBINE': {
      const entA = parsed.matchedEntity;
      const entB = parsed.matchedSecondaryEntity;
      if (!entA || !entB) {
        status = 'invalid';
        nextLog = appendLog(
          'SYSTEM',
          'Specify two relics to combine (e.g., `combine fractured mainspring with calibrated escapement gear`).'
        );
        break;
      }
      const validPair =
        entA.combineWithEntityId === entB.id || entB.combineWithEntityId === entA.id;
      if (!validPair) {
        status = 'invalid';
        nextLog = appendLog(
          'SYSTEM',
          `The ${entA.name} and ${entB.name} cannot be combined together.`
        );
        break;
      }

      if (entA.setFlagsOnUse) entA.setFlagsOnUse.forEach((f) => (nextFlags[f] = true));
      if (entB.setFlagsOnUse) entB.setFlagsOnUse.forEach((f) => (nextFlags[f] = true));

      const resultId = entA.combinedResultEntityId || entB.combinedResultEntityId;
      if (resultId && state.cartridge.entities[resultId]) {
        nextInventory = nextInventory.filter((id) => id !== entA.id && id !== entB.id);
        activeRoom.entityIds = activeRoom.entityIds.filter(
          (id) => id !== entA.id && id !== entB.id
        );
        if (!nextInventory.includes(resultId)) {
          nextInventory.push(resultId);
        }
        nextFlags.core_assembled = true;
      }

      const comboMsg =
        entA.combinationText ||
        entB.combinationText ||
        `You combine the ${entA.name} with the ${entB.name}!`;
      nextLog = appendLog('DISCOVERY', comboMsg);
      break;
    }

    case 'ACTION_UNLOCK': {
      // Unlock exit direction or use key entity
      const keyEntity =
        parsed.matchedSecondaryEntity ||
        parsed.matchedEntity ||
        nextInventory
          .map((id) => state.cartridge.entities[id])
          .find((e) => e?.unlocksExitDirection);

      const targetExit = activeRoom.exits.find(
        (e) =>
          (parsed.direction && e.direction === parsed.direction) ||
          (keyEntity?.unlocksExitDirection && e.direction === keyEntity.unlocksExitDirection) ||
          e.isLocked
      );

      if (!targetExit) {
        status = 'invalid';
        nextLog = appendLog('SYSTEM', 'There is no locked passage here to unseal.');
        break;
      }

      if (
        keyEntity &&
        (keyEntity.unlocksExitDirection === targetExit.direction ||
          keyEntity.setFlagsOnUse?.some((f) =>
            targetExit.unlockCondition?.requiredFlags?.includes(f)
          ))
      ) {
        targetExit.isLocked = false;
        if (keyEntity.setFlagsOnUse) {
          keyEntity.setFlagsOnUse.forEach((f) => (nextFlags[f] = true));
        }
        nextLog = appendLog(
          'DISCOVERY',
          keyEntity.onUseText ||
            `[glow]You unlock the ${targetExit.direction.toUpperCase()} passage using the ${keyEntity.name}![/glow]`
        );
      } else {
        const cond = evaluateCondition(
          targetExit.unlockCondition,
          nextFlags,
          nextInventory,
          nextVariables
        );
        if (cond.met) {
          targetExit.isLocked = false;
          nextLog = appendLog(
            'DISCOVERY',
            `[glow]The ${targetExit.direction.toUpperCase()} passage unseals![/glow]`
          );
        } else {
          status = 'locked';
          nextLog = appendLog(
            'SYSTEM',
            `[shake]Cannot unlock ${targetExit.direction.toUpperCase()}:[/shake] ${
              targetExit.lockDescription || 'You lack the required key or alignment.'
            }`
          );
        }
      }
      break;
    }

    case 'ACTION_TALK':
    case 'ACTION_USE': {
      // If user typed "use A with B", delegate to combine if they are combinable
      if (
        parsed.matchedEntity &&
        parsed.matchedSecondaryEntity &&
        (parsed.matchedEntity.combineWithEntityId === parsed.matchedSecondaryEntity.id ||
          parsed.matchedSecondaryEntity.combineWithEntityId === parsed.matchedEntity.id)
      ) {
        return executeEngineStep(
          state,
          `combine ${parsed.matchedEntity.name} with ${parsed.matchedSecondaryEntity.name}`
        );
      }

      const ent = parsed.matchedEntity;
      if (!ent) {
        status = 'invalid';
        nextLog = appendLog(
          'SYSTEM',
          `Specify what you wish to interact with (e.g., \`use brass lantern\` or click a highlighted entity).`
        );
        break;
      }

      if (ent.setFlagsOnUse) {
        for (const f of ent.setFlagsOnUse) {
          nextFlags[f] = true;
        }
      }
      if (ent.modifyVariablesOnUse) {
        for (const [k, delta] of Object.entries(ent.modifyVariablesOnUse)) {
          nextVariables[k] = (nextVariables[k] ?? 0) + delta;
        }
      }

      if (ent.unlocksExitDirection) {
        const exitToUnlock = activeRoom.exits.find(
          (e) => e.direction === ent.unlocksExitDirection
        );
        if (exitToUnlock) {
          exitToUnlock.isLocked = false;
        }
      }

      // Also unlock any exits in current room whose unlockCondition is now satisfied
      for (const ex of activeRoom.exits) {
        if (ex.isLocked && ex.unlockCondition) {
          const check = evaluateCondition(
            ex.unlockCondition,
            nextFlags,
            nextInventory,
            nextVariables
          );
          if (check.met) {
            ex.isLocked = false;
          }
        }
      }

      const useResponse =
        ent.onUseText || `You activate the ${ent.name}.`;

      if (ent.triggersVictoryOnUse) {
        status = 'victory';
        victoryState = {
          title: ent.victoryTitle || 'Expedition Complete',
          epilogue: ent.victoryEpilogue || useResponse,
          turnsTaken: nextTurn,
          roomsDiscovered: nextVisited.length,
          relicsCollected: nextInventory.length,
        };
        nextLog = appendLog('DISCOVERY', `${useResponse}\n\n[glow]${victoryState.epilogue}[/glow]`);
      } else {
        nextLog = appendLog('PROSE', useResponse);
      }
      break;
    }

    default: {
      status = 'invalid';
      nextLog = appendLog(
        'SYSTEM',
        `Unrecognized command "${rawCommand}". Try verbs like \`inspect\`, \`take\`, \`use\`, \`combine\`, \`unlock\`, or \`go [north/south/east/west/up/down]\`.`
      );
      break;
    }
  }

  const debugEntry = {
    id: `dbg_${Date.now()}_${nextTurn}`,
    turn: nextTurn,
    rawInput: rawCommand,
    intent: parsed.canonicalVerb,
    verb: parsed.verb,
    directObject: parsed.directObject,
    preposition: parsed.preposition,
    indirectObject: parsed.indirectObject,
    matchedEntityId: parsed.matchedEntity?.id,
    matchedSecondaryEntityId: parsed.matchedSecondaryEntity?.id,
    outcome: status,
  };

  const nextState: EngineRuntimeState = {
    ...state,
    cartridge: {
      ...state.cartridge,
      rooms: nextRooms,
    },
    currentRoomId: nextRoomId,
    visitedRoomIds: nextVisited,
    inventoryIds: nextInventory,
    flags: nextFlags,
    variables: nextVariables,
    turnCount: status === 'invalid' ? state.turnCount : nextTurn,
    narrativeLog: nextLog,
    historyStack:
      status === 'invalid'
        ? state.historyStack
        : [...state.historyStack.slice(-29), snapshotBefore],
    parserLogs: [debugEntry, ...state.parserLogs.slice(0, 39)],
    victoryState,
    shellState: status === 'victory' ? 'gameover' : state.shellState,
  };

  return { nextState, status };
}

/**
 * Encodes a StoryCartridge into a shareable Base64 URL-safe seed string.
 */
export function encodeCartridgeSeed(cartridge: StoryCartridge): string {
  const json = JSON.stringify(cartridge);
  const bytes = new TextEncoder().encode(json);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Decodes a Base64 seed string back into a validated StoryCartridge.
 */
export function decodeCartridgeSeed(seed: string): StoryCartridge | null {
  try {
    const clean = seed.trim().replace(/^#?seed=/, '');
    const binary = atob(clean);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const json = new TextDecoder().decode(bytes);
    const parsed = JSON.parse(json) as StoryCartridge;
    if (parsed && parsed.id && parsed.title && parsed.startingRoomId && parsed.rooms) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}
