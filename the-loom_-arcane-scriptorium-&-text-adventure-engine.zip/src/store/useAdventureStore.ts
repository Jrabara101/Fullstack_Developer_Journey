import { create } from 'zustand';
import {
  Direction,
  EngineRuntimeState,
  RoomChoice,
  RoomExit,
  RoomNode,
  SavedBranch,
  StoryCartridge,
  WorldEntity,
} from '../types/adventure';
import { CLOCKWORK_OBSERVATORY_CARTRIDGE } from '../data/demoCartridges';
import {
  createEngineSnapshot,
  evaluateCondition,
  executeEngineStep,
  restoreEngineSnapshot,
} from '../engine/parser';
import { soundEngine } from '../utils/sound';

const DB_NAME = 'TheLoomScriptoriumDB';
const STORE_NAME = 'EngineStateStore';
const STATE_KEY = 'active_workspace_v1';

// Lightweight IndexedDB persistence helper
function saveToIndexedDB(payload: Partial<EngineRuntimeState>) {
  if (typeof window === 'undefined' || !window.indexedDB) return;
  try {
    const req = window.indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(JSON.stringify(payload), STATE_KEY);
    };
  } catch {
    // Ignore storage quota or sandbox errors
  }
}

function cloneCartridge(cartridge: StoryCartridge): StoryCartridge {
  return JSON.parse(JSON.stringify(cartridge)) as StoryCartridge;
}

function getInitialShellState(): 'title' | 'playing' {
  if (typeof window !== 'undefined') {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      return 'playing';
    }
  }
  return 'title';
}

interface AdventureStore extends EngineRuntimeState {
  selectedCreatorRoomId: string;
  selectedCreatorEntityId: string | null;
  isDebuggerOpen: boolean;
  isCartridgeModalOpen: boolean;
  isMuted: boolean;
  lastCommandStatus: 'idle' | 'valid' | 'invalid' | 'locked' | 'victory';
  rightHudView: 'map2d' | 'scene3d';

  // Shell & Mode Actions
  setShellState: (shellState: 'title' | 'playing' | 'paused' | 'gameover') => void;
  setMode: (mode: 'PLAY' | 'CREATE') => void;
  toggleMode: () => void;
  setRightHudView: (view: 'map2d' | 'scene3d') => void;
  toggleMute: () => void;
  setDebuggerOpen: (open: boolean) => void;
  setCartridgeModalOpen: (open: boolean) => void;

  // Play Runtime Actions
  submitCommand: (rawCommand: string) => 'valid' | 'invalid' | 'locked' | 'victory';
  executeChoice: (choice: RoomChoice) => void;
  fastTravelToRoom: (roomId: string) => void;
  combineInventoryItems: (itemAId: string, itemBId: string) => void;
  undoLastTurn: () => void;
  saveBranchCheckpoint: (label?: string) => void;
  loadBranchCheckpoint: (branchId: string) => void;
  deleteBranchCheckpoint: (branchId: string) => void;
  restartAdventure: () => void;
  loadCartridge: (cartridge: StoryCartridge, startImmediately?: boolean) => void;

  // Creator Studio & Live Debugger Actions
  selectCreatorRoom: (roomId: string) => void;
  selectCreatorEntity: (entityId: string | null) => void;
  updateCartridgeMeta: (patch: Partial<Pick<StoryCartridge, 'title' | 'author' | 'synopsis'>>) => void;
  updateRoomNode: (roomId: string, patch: Partial<RoomNode>) => void;
  updateRoomPosition: (roomId: string, x: number, y: number) => void;
  addRoomNode: () => string;
  deleteRoomNode: (roomId: string) => void;
  upsertRoomExit: (roomId: string, exit: RoomExit) => void;
  removeRoomExit: (roomId: string, direction: Direction) => void;
  addRoomChoice: (roomId: string) => void;
  updateRoomChoice: (roomId: string, choiceId: string, patch: Partial<RoomChoice>) => void;
  removeRoomChoice: (roomId: string, choiceId: string) => void;
  upsertWorldEntity: (entity: WorldEntity, assignToRoomId?: string) => void;
  deleteWorldEntity: (entityId: string) => void;
  toggleRoomEntity: (roomId: string, entityId: string) => void;

  // Live God-Mode Debugger Actions
  toggleFlag: (flagKey: string) => void;
  createFlag: (flagKey: string, initialValue?: boolean) => void;
  setVariable: (varKey: string, value: number) => void;
  teleportToRoom: (roomId: string) => void;
  toggleInventoryItem: (entityId: string) => void;
}

const initialCartridge = cloneCartridge(CLOCKWORK_OBSERVATORY_CARTRIDGE);
const startRoom = initialCartridge.rooms[initialCartridge.startingRoomId];
const initialShell = getInitialShellState();

if (typeof document !== 'undefined') {
  document.body.dataset.state = initialShell;
}

export const useAdventureStore = create<AdventureStore>((set, get) => ({
  mode: 'PLAY',
  shellState: initialShell,
  cartridge: initialCartridge,
  currentRoomId: initialCartridge.startingRoomId,
  visitedRoomIds: [initialCartridge.startingRoomId],
  inventoryIds: [],
  flags: { ...initialCartridge.initialFlags },
  variables: { ...initialCartridge.initialVariables },
  turnCount: 1,
  narrativeLog: [
    {
      id: 'entry_initial_1',
      turn: 1,
      type: 'PROSE',
      roomTitle: startRoom.title,
      roomBiome: startRoom.biomeMood,
      contentMarkup: startRoom.descriptionMarkup,
    },
  ],
  historyStack: [],
  savedBranches: [
    {
      id: 'branch_origin',
      label: 'Spire Arrival (Turn 1)',
      timestamp: 'Initial Anchor',
      turn: 1,
      roomTitle: startRoom.title,
      snapshotJson: '',
    },
  ],
  parserLogs: [],
  victoryState: null,

  selectedCreatorRoomId: initialCartridge.startingRoomId,
  selectedCreatorEntityId: null,
  isDebuggerOpen: false,
  isCartridgeModalOpen: false,
  isMuted: false,
  lastCommandStatus: 'idle',
  rightHudView: 'scene3d',

  setShellState: (shellState) => {
    if (typeof document !== 'undefined') {
      document.body.dataset.state = shellState;
    }
    set({ shellState });
  },

  setMode: (mode) => {
    soundEngine.playParchmentTap();
    const state = get();
    // When switching from CREATE to PLAY, sync currentRoomId to the room being edited in the studio!
    if (mode === 'PLAY' && state.selectedCreatorRoomId && state.cartridge.rooms[state.selectedCreatorRoomId]) {
      const targetRoom = state.cartridge.rooms[state.selectedCreatorRoomId];
      const visited = state.visitedRoomIds.includes(targetRoom.id)
        ? state.visitedRoomIds
        : [...state.visitedRoomIds, targetRoom.id];
      set({
        mode: 'PLAY',
        currentRoomId: targetRoom.id,
        visitedRoomIds: visited,
      });
    } else {
      set({
        mode,
        selectedCreatorRoomId: state.currentRoomId,
      });
    }
  },

  toggleMode: () => {
    const current = get().mode;
    get().setMode(current === 'PLAY' ? 'CREATE' : 'PLAY');
  },

  setRightHudView: (view) => {
    soundEngine.playParchmentTap();
    set({ rightHudView: view });
  },

  toggleMute: () => {
    const nextMuted = !get().isMuted;
    soundEngine.isMuted = nextMuted;
    set({ isMuted: nextMuted });
  },

  setDebuggerOpen: (open) => set({ isDebuggerOpen: open }),
  setCartridgeModalOpen: (open) => set({ isCartridgeModalOpen: open }),

  submitCommand: (rawCommand) => {
    const state = get();
    const { nextState, status } = executeEngineStep(state, rawCommand);

    if (status === 'valid' || status === 'victory') {
      soundEngine.playDiscoveryChime();
    } else {
      soundEngine.playLockShudder();
    }

    if (nextState.shellState !== state.shellState && typeof document !== 'undefined') {
      document.body.dataset.state = nextState.shellState;
    }

    set({
      ...nextState,
      selectedCreatorRoomId: nextState.currentRoomId,
      lastCommandStatus: status,
    });

    saveToIndexedDB(nextState);
    return status;
  },

  executeChoice: (choice) => {
    const state = get();
    const cond = evaluateCondition(choice.condition, state.flags, state.inventoryIds, state.variables);
    if (!cond.met) {
      soundEngine.playLockShudder();
      return;
    }

    const snapshotBefore = createEngineSnapshot(state);
    const nextTurn = state.turnCount + 1;
    const nextFlags = { ...state.flags };
    const nextVariables = { ...state.variables };
    const nextInventory = [...state.inventoryIds];
    let nextRoomId = state.currentRoomId;
    const nextVisited = [...state.visitedRoomIds];
    const nextRooms = cloneCartridge(state.cartridge).rooms;

    if (choice.setFlags) {
      choice.setFlags.forEach((f) => {
        nextFlags[f] = true;
      });
    }
    if (choice.modifyVariables) {
      for (const [k, delta] of Object.entries(choice.modifyVariables)) {
        nextVariables[k] = (nextVariables[k] ?? 0) + delta;
      }
    }
    if (choice.giveItemIds) {
      choice.giveItemIds.forEach((id) => {
        if (!nextInventory.includes(id)) {
          nextInventory.push(id);
        }
      });
    }

    // Unlock any exits in the active room whose conditions are now satisfied
    const activeRoom = nextRooms[state.currentRoomId];
    if (activeRoom) {
      for (const ex of activeRoom.exits) {
        if (ex.isLocked && ex.unlockCondition) {
          if (evaluateCondition(ex.unlockCondition, nextFlags, nextInventory, nextVariables).met) {
            ex.isLocked = false;
          }
        }
      }
    }

    if (choice.targetRoomId && nextRooms[choice.targetRoomId]) {
      nextRoomId = choice.targetRoomId;
      if (!nextVisited.includes(nextRoomId)) {
        nextVisited.push(nextRoomId);
      }
    }

    const echoEntry = {
      id: `log_${Date.now()}_choice_${nextTurn}`,
      turn: nextTurn,
      type: 'COMMAND_ECHO' as const,
      contentMarkup: choice.label,
    };

    const responseEntry = {
      id: `log_${Date.now()}_cresp_${nextTurn}`,
      turn: nextTurn,
      type: (choice.triggersVictory ? 'DISCOVERY' : 'PROSE') as 'DISCOVERY' | 'PROSE',
      roomTitle: choice.targetRoomId ? nextRooms[choice.targetRoomId]?.title : undefined,
      roomBiome: choice.targetRoomId ? nextRooms[choice.targetRoomId]?.biomeMood : undefined,
      contentMarkup:
        choice.responseMarkup ||
        (choice.targetRoomId ? nextRooms[choice.targetRoomId]?.descriptionMarkup : '') ||
        'Done.',
    };

    let victoryState = state.victoryState;
    let nextShell = state.shellState;
    if (choice.triggersVictory) {
      victoryState = {
        title: choice.victoryTitle || 'Chronicle Fulfilled',
        epilogue: choice.responseMarkup || 'Your journey reaches its culmination.',
        turnsTaken: nextTurn,
        roomsDiscovered: nextVisited.length,
        relicsCollected: nextInventory.length,
      };
      nextShell = 'gameover';
      if (typeof document !== 'undefined') {
        document.body.dataset.state = 'gameover';
      }
    }

    soundEngine.playDiscoveryChime();

    const updatedState: Partial<AdventureStore> = {
      cartridge: {
        ...state.cartridge,
        rooms: nextRooms,
      },
      currentRoomId: nextRoomId,
      visitedRoomIds: nextVisited,
      inventoryIds: nextInventory,
      flags: nextFlags,
      variables: nextVariables,
      turnCount: nextTurn,
      narrativeLog: [...state.narrativeLog, echoEntry, responseEntry],
      historyStack: [...state.historyStack.slice(-29), snapshotBefore],
      victoryState,
      shellState: nextShell,
      lastCommandStatus: choice.triggersVictory ? 'victory' : 'valid',
    };

    set(updatedState);
    saveToIndexedDB({ ...state, ...updatedState });
  },

  fastTravelToRoom: (roomId) => {
    const state = get();
    if (!state.visitedRoomIds.includes(roomId) || roomId === state.currentRoomId) return;
    const targetRoom = state.cartridge.rooms[roomId];
    if (!targetRoom) return;

    const snapshotBefore = createEngineSnapshot(state);
    const nextTurn = state.turnCount + 1;
    soundEngine.playParchmentTap();

    set({
      currentRoomId: roomId,
      selectedCreatorRoomId: roomId,
      turnCount: nextTurn,
      narrativeLog: [
        ...state.narrativeLog,
        {
          id: `log_${Date.now()}_ft_echo`,
          turn: nextTurn,
          type: 'COMMAND_ECHO',
          contentMarkup: `fast-travel to ${targetRoom.title}`,
        },
        {
          id: `log_${Date.now()}_ft_prose`,
          turn: nextTurn,
          type: 'PROSE',
          roomTitle: targetRoom.title,
          roomBiome: targetRoom.biomeMood,
          contentMarkup: targetRoom.descriptionMarkup,
        },
      ],
      historyStack: [...state.historyStack.slice(-29), snapshotBefore],
    });
  },

  combineInventoryItems: (itemAId, itemBId) => {
    const state = get();
    const entA = state.cartridge.entities[itemAId];
    const entB = state.cartridge.entities[itemBId];
    if (!entA || !entB) return;
    get().submitCommand(`combine ${entA.name} with ${entB.name}`);
  },

  undoLastTurn: () => {
    const state = get();
    if (state.historyStack.length === 0) return;
    const lastSnapshot = state.historyStack[state.historyStack.length - 1];
    const restored = restoreEngineSnapshot(state, lastSnapshot);
    soundEngine.playTimeRewind();

    if (typeof document !== 'undefined') {
      document.body.dataset.state = restored.shellState;
    }

    set({
      ...restored,
      historyStack: state.historyStack.slice(0, -1),
      selectedCreatorRoomId: restored.currentRoomId,
    });
  },

  saveBranchCheckpoint: (label) => {
    const state = get();
    const currentRoom = state.cartridge.rooms[state.currentRoomId];
    const snapshotJson = createEngineSnapshot(state);
    const newBranch: SavedBranch = {
      id: `branch_${Date.now()}`,
      label: label?.trim() || `${currentRoom?.title || 'Chamber'} (Turn ${state.turnCount})`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      turn: state.turnCount,
      roomTitle: currentRoom?.title || state.currentRoomId,
      snapshotJson,
    };
    soundEngine.playDiscoveryChime();
    set({
      savedBranches: [newBranch, ...state.savedBranches],
    });
  },

  loadBranchCheckpoint: (branchId) => {
    const state = get();
    const branch = state.savedBranches.find((b) => b.id === branchId);
    if (!branch) return;

    if (!branch.snapshotJson) {
      // Initial anchor branch resets the cartridge cleanly
      get().restartAdventure();
      return;
    }

    const snapshotBefore = createEngineSnapshot(state);
    const restored = restoreEngineSnapshot(state, branch.snapshotJson);
    soundEngine.playTimeRewind();

    if (typeof document !== 'undefined') {
      document.body.dataset.state = 'playing';
    }

    set({
      ...restored,
      shellState: 'playing',
      historyStack: [...state.historyStack.slice(-29), snapshotBefore],
    });
  },

  deleteBranchCheckpoint: (branchId) => {
    set((state) => ({
      savedBranches: state.savedBranches.filter((b) => b.id !== branchId),
    }));
  },

  restartAdventure: () => {
    const state = get();
    // Reload original demo if matching ID, otherwise reset current cartridge
    const freshCartridge =
      state.cartridge.id === CLOCKWORK_OBSERVATORY_CARTRIDGE.id
        ? cloneCartridge(CLOCKWORK_OBSERVATORY_CARTRIDGE)
        : cloneCartridge(state.cartridge);
    const startNode = freshCartridge.rooms[freshCartridge.startingRoomId];

    soundEngine.playTimeRewind();
    if (typeof document !== 'undefined') {
      document.body.dataset.state = 'playing';
    }

    set({
      shellState: 'playing',
      cartridge: freshCartridge,
      currentRoomId: freshCartridge.startingRoomId,
      selectedCreatorRoomId: freshCartridge.startingRoomId,
      visitedRoomIds: [freshCartridge.startingRoomId],
      inventoryIds: [],
      flags: { ...freshCartridge.initialFlags },
      variables: { ...freshCartridge.initialVariables },
      turnCount: 1,
      narrativeLog: [
        {
          id: `entry_restart_${Date.now()}`,
          turn: 1,
          type: 'PROSE',
          roomTitle: startNode.title,
          roomBiome: startNode.biomeMood,
          contentMarkup: startNode.descriptionMarkup,
        },
      ],
      historyStack: [],
      victoryState: null,
      lastCommandStatus: 'idle',
    });
  },

  loadCartridge: (cartridge, startImmediately = true) => {
    const fresh = cloneCartridge(cartridge);
    const startNode = fresh.rooms[fresh.startingRoomId] || Object.values(fresh.rooms)[0];
    const startId = startNode.id;

    soundEngine.playDiscoveryChime();
    const nextShell = startImmediately ? 'playing' : get().shellState;
    if (typeof document !== 'undefined') {
      document.body.dataset.state = nextShell;
    }

    set({
      shellState: nextShell,
      cartridge: fresh,
      currentRoomId: startId,
      selectedCreatorRoomId: startId,
      visitedRoomIds: [startId],
      inventoryIds: [],
      flags: { ...fresh.initialFlags },
      variables: { ...fresh.initialVariables },
      turnCount: 1,
      narrativeLog: [
        {
          id: `entry_load_${Date.now()}`,
          turn: 1,
          type: 'PROSE',
          roomTitle: startNode.title,
          roomBiome: startNode.biomeMood,
          contentMarkup: startNode.descriptionMarkup,
        },
      ],
      historyStack: [],
      savedBranches: [
        {
          id: `branch_origin_${Date.now()}`,
          label: `${startNode.title} (Turn 1)`,
          timestamp: 'Initial Anchor',
          turn: 1,
          roomTitle: startNode.title,
          snapshotJson: '',
        },
      ],
      victoryState: null,
      isCartridgeModalOpen: false,
    });
  },

  // Creator Studio & Live Debugger Actions
  selectCreatorRoom: (roomId) => set({ selectedCreatorRoomId: roomId }),
  selectCreatorEntity: (entityId) => set({ selectedCreatorEntityId: entityId }),

  updateCartridgeMeta: (patch) =>
    set((state) => ({
      cartridge: {
        ...state.cartridge,
        ...patch,
      },
    })),

  updateRoomNode: (roomId, patch) =>
    set((state) => {
      const existing = state.cartridge.rooms[roomId];
      if (!existing) return state;
      const updatedRoom = { ...existing, ...patch };
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: updatedRoom,
          },
        },
      };
    }),

  updateRoomPosition: (roomId, x, y) =>
    set((state) => {
      const existing = state.cartridge.rooms[roomId];
      if (!existing) return state;
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: {
              ...existing,
              editorPosition: { x: Math.round(x), y: Math.round(y) },
            },
          },
        },
      };
    }),

  addRoomNode: () => {
    const state = get();
    const id = `chamber_${Object.keys(state.cartridge.rooms).length + 1}_${Date.now().toString().slice(-3)}`;
    const newRoom: RoomNode = {
      id,
      title: 'New Uncharted Chamber',
      biomeMood: 'arcane',
      descriptionMarkup:
        'Stepping into this newly woven chamber, [glow]amber motes drift across the stonework[/glow].',
      exits: [],
      entityIds: [],
      choices: [],
      editorPosition: {
        x: 360 + (Object.keys(state.cartridge.rooms).length % 3) * 140,
        y: 220 + (Object.keys(state.cartridge.rooms).length % 2) * 160,
      },
    };
    set({
      cartridge: {
        ...state.cartridge,
        rooms: {
          ...state.cartridge.rooms,
          [id]: newRoom,
        },
      },
      selectedCreatorRoomId: id,
    });
    return id;
  },

  deleteRoomNode: (roomId) =>
    set((state) => {
      const roomKeys = Object.keys(state.cartridge.rooms);
      if (roomKeys.length <= 1 || roomId === state.cartridge.startingRoomId) return state;
      const nextRooms = { ...state.cartridge.rooms };
      delete nextRooms[roomId];
      // Clean up exits pointing to deleted room
      for (const r of Object.values(nextRooms)) {
        r.exits = r.exits.filter((e) => e.targetRoomId !== roomId);
      }
      const fallbackId = state.cartridge.startingRoomId;
      return {
        cartridge: {
          ...state.cartridge,
          rooms: nextRooms,
        },
        selectedCreatorRoomId:
          state.selectedCreatorRoomId === roomId ? fallbackId : state.selectedCreatorRoomId,
        currentRoomId: state.currentRoomId === roomId ? fallbackId : state.currentRoomId,
      };
    }),

  upsertRoomExit: (roomId, exit) =>
    set((state) => {
      const room = state.cartridge.rooms[roomId];
      if (!room) return state;
      const filtered = room.exits.filter((e) => e.direction !== exit.direction);
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: {
              ...room,
              exits: [...filtered, exit],
            },
          },
        },
      };
    }),

  removeRoomExit: (roomId, direction) =>
    set((state) => {
      const room = state.cartridge.rooms[roomId];
      if (!room) return state;
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: {
              ...room,
              exits: room.exits.filter((e) => e.direction !== direction),
            },
          },
        },
      };
    }),

  addRoomChoice: (roomId) =>
    set((state) => {
      const room = state.cartridge.rooms[roomId];
      if (!room) return state;
      const newChoice: RoomChoice = {
        id: `choice_${Date.now().toString().slice(-4)}`,
        label: 'Inspect the Arcane Inscription',
        responseMarkup: '[glow]The runes shimmer softly in answer to your touch.[/glow]',
      };
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: {
              ...room,
              choices: [...room.choices, newChoice],
            },
          },
        },
      };
    }),

  updateRoomChoice: (roomId, choiceId, patch) =>
    set((state) => {
      const room = state.cartridge.rooms[roomId];
      if (!room) return state;
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: {
              ...room,
              choices: room.choices.map((c) => (c.id === choiceId ? { ...c, ...patch } : c)),
            },
          },
        },
      };
    }),

  removeRoomChoice: (roomId, choiceId) =>
    set((state) => {
      const room = state.cartridge.rooms[roomId];
      if (!room) return state;
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: {
              ...room,
              choices: room.choices.filter((c) => c.id !== choiceId),
            },
          },
        },
      };
    }),

  upsertWorldEntity: (entity, assignToRoomId) =>
    set((state) => {
      const nextRooms = { ...state.cartridge.rooms };
      if (assignToRoomId && nextRooms[assignToRoomId]) {
        const r = nextRooms[assignToRoomId];
        if (!r.entityIds.includes(entity.id)) {
          nextRooms[assignToRoomId] = {
            ...r,
            entityIds: [...r.entityIds, entity.id],
          };
        }
      }
      return {
        cartridge: {
          ...state.cartridge,
          entities: {
            ...state.cartridge.entities,
            [entity.id]: entity,
          },
          rooms: nextRooms,
        },
        selectedCreatorEntityId: entity.id,
      };
    }),

  deleteWorldEntity: (entityId) =>
    set((state) => {
      const nextEntities = { ...state.cartridge.entities };
      delete nextEntities[entityId];
      const nextRooms: Record<string, RoomNode> = {};
      for (const [rId, r] of Object.entries(state.cartridge.rooms)) {
        nextRooms[rId] = {
          ...r,
          entityIds: r.entityIds.filter((id) => id !== entityId),
        };
      }
      return {
        cartridge: {
          ...state.cartridge,
          entities: nextEntities,
          rooms: nextRooms,
        },
        inventoryIds: state.inventoryIds.filter((id) => id !== entityId),
        selectedCreatorEntityId:
          state.selectedCreatorEntityId === entityId ? null : state.selectedCreatorEntityId,
      };
    }),

  toggleRoomEntity: (roomId, entityId) =>
    set((state) => {
      const room = state.cartridge.rooms[roomId];
      if (!room) return state;
      const exists = room.entityIds.includes(entityId);
      const nextEntityIds = exists
        ? room.entityIds.filter((id) => id !== entityId)
        : [...room.entityIds, entityId];
      return {
        cartridge: {
          ...state.cartridge,
          rooms: {
            ...state.cartridge.rooms,
            [roomId]: {
              ...room,
              entityIds: nextEntityIds,
            },
          },
        },
      };
    }),

  toggleFlag: (flagKey) =>
    set((state) => ({
      flags: {
        ...state.flags,
        [flagKey]: !state.flags[flagKey],
      },
    })),

  createFlag: (flagKey, initialValue = false) =>
    set((state) => {
      const clean = flagKey.trim().toLowerCase().replace(/\s+/g, '_');
      if (!clean) return state;
      return {
        flags: {
          ...state.flags,
          [clean]: initialValue,
        },
        cartridge: {
          ...state.cartridge,
          initialFlags: {
            ...state.cartridge.initialFlags,
            [clean]: initialValue,
          },
        },
      };
    }),

  setVariable: (varKey, value) =>
    set((state) => ({
      variables: {
        ...state.variables,
        [varKey]: value,
      },
    })),

  teleportToRoom: (roomId) =>
    set((state) => {
      const target = state.cartridge.rooms[roomId];
      if (!target) return state;
      const visited = state.visitedRoomIds.includes(roomId)
        ? state.visitedRoomIds
        : [...state.visitedRoomIds, roomId];
      return {
        currentRoomId: roomId,
        selectedCreatorRoomId: roomId,
        visitedRoomIds: visited,
        narrativeLog: [
          ...state.narrativeLog,
          {
            id: `log_tp_${Date.now()}`,
            turn: state.turnCount,
            type: 'PROSE',
            roomTitle: target.title,
            roomBiome: target.biomeMood,
            contentMarkup: target.descriptionMarkup,
          },
        ],
      };
    }),

  toggleInventoryItem: (entityId) =>
    set((state) => {
      const hasItem = state.inventoryIds.includes(entityId);
      return {
        inventoryIds: hasItem
          ? state.inventoryIds.filter((id) => id !== entityId)
          : [...state.inventoryIds, entityId],
      };
    }),
}));
