export type Direction = 'north' | 'south' | 'east' | 'west' | 'up' | 'down';

export type BiomeMood = 'sanctuary' | 'crypt' | 'arcane' | 'peril' | 'twilight';

export interface ConditionRule {
  requiredFlags?: string[];
  forbiddenFlags?: string[];
  requiredItems?: string[];
  minVariables?: Record<string, number>;
}

export interface WorldEntity {
  id: string;
  name: string;
  aliases: string[];
  description: string;
  isTakeable: boolean;
  isUsable: boolean;
  combineWithEntityId?: string;
  combinedResultEntityId?: string;
  combinationText?: string;
  onInspectText?: string;
  onUseText?: string;
  setFlagsOnUse?: string[];
  setFlagsOnTake?: string[];
  modifyVariablesOnUse?: Record<string, number>;
  unlocksExitDirection?: Direction;
  triggersVictoryOnUse?: boolean;
  victoryTitle?: string;
  victoryEpilogue?: string;
}

export interface RoomExit {
  direction: Direction;
  targetRoomId: string;
  isLocked?: boolean;
  lockDescription?: string;
  unlockCondition?: ConditionRule;
  conduitLabel?: string;
}

export interface RoomChoice {
  id: string;
  label: string;
  targetRoomId?: string;
  responseMarkup?: string;
  condition?: ConditionRule;
  setFlags?: string[];
  giveItemIds?: string[];
  modifyVariables?: Record<string, number>;
  triggersVictory?: boolean;
  victoryTitle?: string;
}

export interface RoomNode {
  id: string;
  title: string;
  biomeMood: BiomeMood;
  descriptionMarkup: string; // Supports [[Entity|id:...|actions:...]] and {if flag:...}...{/if} and [shake]/[glow]/[whisper]
  exits: RoomExit[];
  entityIds: string[];
  choices: RoomChoice[];
  onEnterSetFlags?: string[];
  tickScriptMarkup?: string;
  editorPosition: { x: number; y: number }; // 2D coordinates for Creator Canvas
}

export interface StoryCartridge {
  id: string;
  title: string;
  author: string;
  version: string;
  synopsis: string;
  startingRoomId: string;
  rooms: Record<string, RoomNode>;
  entities: Record<string, WorldEntity>;
  initialFlags: Record<string, boolean>;
  initialVariables: Record<string, number>;
}

export interface NarrativeLogEntry {
  id: string;
  turn: number;
  type: 'PROSE' | 'COMMAND_ECHO' | 'SYSTEM' | 'DISCOVERY';
  roomTitle?: string;
  roomBiome?: BiomeMood;
  contentMarkup: string;
}

export interface SavedBranch {
  id: string;
  label: string;
  timestamp: string;
  turn: number;
  roomTitle: string;
  snapshotJson: string;
}

export interface ParserDebugEntry {
  id: string;
  turn: number;
  rawInput: string;
  intent: string;
  verb: string;
  directObject?: string;
  preposition?: string;
  indirectObject?: string;
  matchedEntityId?: string;
  matchedSecondaryEntityId?: string;
  outcome: 'valid' | 'invalid' | 'locked' | 'victory';
}

export interface EngineSnapshot {
  currentRoomId: string;
  visitedRoomIds: string[];
  inventoryIds: string[];
  flags: Record<string, boolean>;
  variables: Record<string, number>;
  turnCount: number;
  narrativeLog: NarrativeLogEntry[];
  // Deep copy of room entities and exit lock states at that turn
  roomEntities: Record<string, string[]>;
  roomExitLocks: Record<string, Record<string, boolean>>;
}

export interface EngineRuntimeState {
  mode: 'PLAY' | 'CREATE';
  shellState: 'title' | 'playing' | 'paused' | 'gameover';
  cartridge: StoryCartridge;
  currentRoomId: string;
  visitedRoomIds: string[];
  inventoryIds: string[];
  flags: Record<string, boolean>;
  variables: Record<string, number>;
  turnCount: number;
  narrativeLog: NarrativeLogEntry[];
  historyStack: string[]; // Serialized EngineSnapshot JSON strings for Undo/Rewind
  savedBranches: SavedBranch[];
  parserLogs: ParserDebugEntry[];
  victoryState?: {
    title: string;
    epilogue: string;
    turnsTaken: number;
    roomsDiscovered: number;
    relicsCollected: number;
  } | null;
}

export type CanonicalVerb =
  | 'ACTION_MOVE'
  | 'ACTION_INSPECT'
  | 'ACTION_TAKE'
  | 'ACTION_DROP'
  | 'ACTION_USE'
  | 'ACTION_COMBINE'
  | 'ACTION_UNLOCK'
  | 'ACTION_TALK'
  | 'ACTION_INVENTORY'
  | 'ACTION_LOOK'
  | 'ACTION_HELP'
  | 'ACTION_WAIT'
  | 'ACTION_UNKNOWN';

export interface ParsedCommand {
  raw: string;
  verb: string;
  canonicalVerb: CanonicalVerb;
  directObject?: string;
  preposition?: string;
  indirectObject?: string;
  direction?: Direction;
  matchedEntity?: WorldEntity;
  matchedSecondaryEntity?: WorldEntity;
}

export type MarkupSegment =
  | { type: 'text'; content: string; effect?: 'shake' | 'glow' | 'whisper' }
  | {
      type: 'entity';
      label: string;
      entityId: string;
      actions: string[];
      effect?: 'shake' | 'glow' | 'whisper';
    };
