# Stitch.md: Shared Puzzle Room UI Design System & Specification

## 1. Design Theme & Aesthetic
- **Concept:** Cyber-Mystic Terminal / Collaborative Control Room (Blending sleek, futuristic sci-fi surfaces with tactile industrial switches, glowing conduits, and clear team color coding).
- **Surface Textures:** Dark metallic panels frosted with crisp borders, high-contrast neon status lines, and distinct color indicators for player separation (Cyan for Player 1, Amber for Player 2).

## 2. Color Palette Tokens
- `--bg-canvas`: `#0D1117` (Deep space terminal background)
- `--surface-panel`: `#161B22` (Elevated cards and window containers)
- `--player-one`: `#58A6FF` (Cyan accent for Player 1 actions and elements)
- `--player-two`: `#D29922` (Warm amber accent for Player 2 actions and elements)
- `--success-glow`: `#238636` (Vibrant green for door unlocks and puzzle completions)
- `--text-main`: `#C9D1D9` (Crisp light gray for clear readability)
- `--text-muted`: `#8B949E` (Subdued slate for secondary UI markers)

## 3. Typography
- **Primary Font:** 'Outfit' for clean HUD readouts, menus, and button labels.
- **Monospace Font:** 'JetBrains Mono' for room codes, countdown timers, and coordinate readouts.

## 4. Component Layout Guidelines
- **Desktop View:** Dual side-by-side or synchronized 3D viewports with a perimeter status cluster and collapsible bottom collaboration HUD, persistent chat/ping tray, bioscience protein vault, and AI specimen scanner.
- **Mobile View:** Adaptive tabbed layout allowing users to toggle between their viewport and their partner's live feed, ensuring touch targets remain minimum 44x44px.
- **Interactive States:**
  - Hover: Elevated depth transform with partner-colored border highlights.
  - Active/Triggered: Solid inner state highlight matching the active player's theme color.
