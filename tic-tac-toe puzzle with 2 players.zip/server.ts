import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocket, WebSocketServer } from 'ws';
import { GoogleGenAI, Type } from '@google/genai';
import { applyClientAction, createInitialRoomState } from './src/game/engine';
import { ClientActionPayload, SharedRoomState } from './src/game/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const app = express();
app.use(express.json({ limit: '12mb' }));

// Server-side authoritative room store
const rooms = new Map<string, SharedRoomState>();
const roomClients = new Map<string, Set<WebSocket>>();

function getOrCreateRoom(roomId: string): SharedRoomState {
  const cleanId = (roomId || 'SYNC-42').trim().toUpperCase();
  if (!rooms.has(cleanId)) {
    rooms.set(cleanId, createInitialRoomState(cleanId, 0));
  }
  return rooms.get(cleanId)!;
}

function broadcastRoomState(roomId: string) {
  const cleanId = roomId.toUpperCase();
  const state = rooms.get(cleanId);
  const clients = roomClients.get(cleanId);
  if (!state || !clients) return;

  const payload = JSON.stringify({
    type: 'ROOM_STATE_SYNC',
    state,
  });

  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  }
}

// REST endpoint for room snapshot
app.get('/api/rooms/:roomId', (req, res) => {
  const state = getOrCreateRoom(req.params.roomId);
  res.json({ state });
});

// Server-side Gemini API image analysis endpoint using gemini-4-argon
app.post('/api/analyze-image', async (req, res) => {
  try {
    const { imageBase64, mimeType, prompt, targetProtein } = req.body as {
      imageBase64?: string;
      mimeType?: string;
      prompt?: string;
      targetProtein?: string;
    };

    if (!imageBase64) {
      res.status(400).json({ error: 'Please provide an image to analyze.' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(403).json({
        error:
          'Gemini API key not configured. Please check your API key in the Settings > Secrets panel.',
      });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
    const userPrompt =
      prompt?.trim() ||
      `Analyze this uploaded image in the context of our cooperative bio-containment puzzle room (target protein ${
        targetProtein || 'TP53 / P04637'
      }). Identify structural patterns, biological or geometric features, and provide a tactical chamber unlock cipher.`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-argon',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType || 'image/png',
              data: cleanBase64,
            },
          },
          {
            text: userPrompt,
          },
        ],
      },
      config: {
        systemInstruction:
          'You are the Synapse Chamber Bio-Optical Scanner. Analyze uploaded specimen images, protein diagrams, or puzzle glyphs concisely. Return structured JSON with specimenClassification, structuralObservations, recommendedAccession (one of P04637, P00533, P68871, or P38398), confidenceScore (0-100), and tacticalHint.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            specimenClassification: {
              type: Type.STRING,
              description: 'Concise title of what is shown in the uploaded image.',
            },
            structuralObservations: {
              type: Type.STRING,
              description: 'Detailed visual and scientific analysis of the image.',
            },
            recommendedAccession: {
              type: Type.STRING,
              description: 'Recommended UniProt accession for the chamber lock (e.g. P04637, P00533, P68871).',
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: 'Scanner confidence score from 0 to 100.',
            },
            tacticalHint: {
              type: Type.STRING,
              description: 'Actionable hint for Player 1 (Cyan) and Player 2 (Amber) in the puzzle room.',
            },
          },
          required: [
            'specimenClassification',
            'structuralObservations',
            'recommendedAccession',
            'confidenceScore',
            'tacticalHint',
          ],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    res.json({
      model: 'gemini-4-argon',
      analysis: parsed,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    const isAuthOrQuota =
      /403|400|429|PERMISSION_DENIED|API_KEY_INVALID|RESOURCE_EXHAUSTED/i.test(message);

    res.status(isAuthOrQuota ? 403 : 500).json({
      error: isAuthOrQuota
        ? `Gemini API error (${message.slice(0, 140)}). Please check or upgrade your billing-enabled API key in the Settings > Secrets panel.`
        : `Image analysis failed: ${message.slice(0, 180)}`,
    });
  }
});

async function startServer() {
  const httpServer = createServer(app);

  // Attach WebSocket server to same HTTP server on port 3000
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    let currentRoomId = 'SYNC-42';

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(String(raw)) as {
          roomId?: string;
          action?: ClientActionPayload;
        };
        const targetRoomId = (msg.roomId || currentRoomId || 'SYNC-42').trim().toUpperCase();
        currentRoomId = targetRoomId;

        if (!roomClients.has(targetRoomId)) {
          roomClients.set(targetRoomId, new Set());
        }
        roomClients.get(targetRoomId)!.add(ws);

        let room = getOrCreateRoom(targetRoomId);
        if (msg.action) {
          room = applyClientAction(room, msg.action);
          rooms.set(targetRoomId, room);
        }

        broadcastRoomState(targetRoomId);
      } catch (e) {
        console.error('WebSocket message error:', e);
      }
    });

    ws.on('close', () => {
      for (const [, clients] of roomClients) {
        clients.delete(ws);
      }
    });
  });

  // Authoritative server-side 1Hz timer tick for active rooms
  setInterval(() => {
    for (const [roomId, room] of rooms.entries()) {
      if (room.status === 'PLAYING') {
        const updated = applyClientAction(room, { type: 'TICK_TIMER', deltaSec: 1 });
        rooms.set(roomId, updated);
        broadcastRoomState(roomId);
      }
    }
  }, 1000);

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Synapse Chambers server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
