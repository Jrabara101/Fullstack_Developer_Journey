/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Chamber3DViewport } from './components/Chamber3DViewport';
import { CommunicationHud } from './components/CommunicationHud';
import { GameWorkspace } from './components/GameWorkspace';
import { LobbyView } from './components/LobbyView';
import { VictoryModal } from './components/VictoryModal';
import { RoomProvider } from './context/RoomProvider';

export default function App() {
  return (
    <RoomProvider>
      <main className="relative w-screen h-screen overflow-hidden bg-[#0D1117] select-none">
        <Chamber3DViewport />
        <LobbyView />
        <GameWorkspace />
        <CommunicationHud />
        <VictoryModal />
      </main>
    </RoomProvider>
  );
}
