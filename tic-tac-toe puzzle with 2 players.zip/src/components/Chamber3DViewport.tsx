import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { useRoom } from '../context/RoomProvider';
import { SharedRoomState } from '../game/types';

// Pre-allocated math helpers at module scope to prevent GC in render loop
const _vec3 = new THREE.Vector3();
const _targetCamPos = new THREE.Vector3();
const _targetLookAt = new THREE.Vector3();
const _currentLookAt = new THREE.Vector3(5.5, 0, 3.5);
const _dummyMatrix = new THREE.Matrix4();
const _color = new THREE.Color();

function createProceduralGridTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#141B24';
  ctx.fillRect(0, 0, 256, 256);

  ctx.strokeStyle = '#253142';
  ctx.lineWidth = 6;
  ctx.strokeRect(4, 4, 248, 248);

  ctx.strokeStyle = '#1C2636';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(128, 0);
  ctx.lineTo(128, 256);
  ctx.moveTo(0, 128);
  ctx.lineTo(256, 128);
  ctx.stroke();

  // Corner tech rivets
  ctx.fillStyle = '#33445C';
  const corners = [
    [20, 20],
    [236, 20],
    [20, 236],
    [236, 236],
  ];
  for (const [cx, cy] of corners) {
    ctx.beginPath();
    ctx.arc(cx, cy, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

/**
 * Builds a 7-part composite 3D operative model pivoted at bottom-center (y = 0)
 * with varied roughness/metalness and a soft radial contact shadow disc.
 */
function buildCompositeOperativeMesh(primaryHex: number, accentHex: number): THREE.Group {
  const group = new THREE.Group();

  // 1. Soft radial contact shadow disc at y = 0.015
  const shadowGeo = new THREE.CircleGeometry(0.42, 24);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.45,
    depthWrite: false,
  });
  const shadowDisc = new THREE.Mesh(shadowGeo, shadowMat);
  shadowDisc.position.y = 0.015;
  group.add(shadowDisc);

  // 2. Hover base stabilizer ring (metallic trim, roughness 0.25, metalness 0.85)
  const baseGeo = new THREE.TorusGeometry(0.28, 0.05, 12, 24);
  baseGeo.rotateX(Math.PI / 2);
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x222933,
    roughness: 0.25,
    metalness: 0.85,
  });
  const baseMesh = new THREE.Mesh(baseGeo, baseMat);
  baseMesh.position.y = 0.12;
  group.add(baseMesh);

  // 3. Lower armored chassis (matte hull, roughness 0.65, metalness 0.35)
  const torsoGeo = new THREE.CylinderGeometry(0.22, 0.28, 0.52, 16);
  const torsoMat = new THREE.MeshStandardMaterial({
    color: primaryHex,
    roughness: 0.65,
    metalness: 0.35,
  });
  const torsoMesh = new THREE.Mesh(torsoGeo, torsoMat);
  torsoMesh.position.y = 0.42;
  torsoMesh.castShadow = true;
  group.add(torsoMesh);

  // 4. Shoulder pauldrons (secondary silhouette, roughness 0.3, metalness 0.8)
  const pauldronGeo = new THREE.BoxGeometry(0.58, 0.14, 0.28);
  const pauldronMat = new THREE.MeshStandardMaterial({
    color: 0x2d3748,
    roughness: 0.3,
    metalness: 0.8,
  });
  const pauldronMesh = new THREE.Mesh(pauldronGeo, pauldronMat);
  pauldronMesh.position.y = 0.64;
  pauldronMesh.castShadow = true;
  group.add(pauldronMesh);

  // 5. Articulated helmet dome (glossy finish, roughness 0.18, metalness 0.5)
  const headGeo = new THREE.SphereGeometry(0.19, 20, 16);
  const headMat = new THREE.MeshStandardMaterial({
    color: primaryHex,
    roughness: 0.18,
    metalness: 0.5,
  });
  const headMesh = new THREE.Mesh(headGeo, headMat);
  headMesh.position.y = 0.84;
  headMesh.castShadow = true;
  group.add(headMesh);

  // 6. Emissive cyber visor (accent detail facing +Z forward)
  const visorGeo = new THREE.BoxGeometry(0.26, 0.08, 0.14);
  const visorMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    emissive: accentHex,
    emissiveIntensity: 1.6,
    roughness: 0.1,
    metalness: 0.2,
  });
  const visorMesh = new THREE.Mesh(visorGeo, visorMat);
  visorMesh.position.set(0, 0.85, 0.14);
  group.add(visorMesh);

  // 7. Dorsal neural beacon pack
  const packGeo = new THREE.CylinderGeometry(0.08, 0.1, 0.34, 12);
  const packMesh = new THREE.Mesh(packGeo, visorMat);
  packMesh.position.set(0, 0.54, -0.2);
  group.add(packMesh);

  return group;
}

/**
 * Builds the 6-part central AlphaFold Bio-Containment Core at the partition wall.
 */
function buildBioContainmentCore(isSoftwareGl: boolean): THREE.Group {
  const coreGroup = new THREE.Group();

  // 1. Base pedestal
  const pedGeo = new THREE.CylinderGeometry(0.75, 0.9, 0.28, 24);
  const pedMat = new THREE.MeshStandardMaterial({
    color: 0x1c2430,
    roughness: 0.35,
    metalness: 0.85,
  });
  const ped = new THREE.Mesh(pedGeo, pedMat);
  ped.position.y = 0.14;
  coreGroup.add(ped);

  // 2. Top containment crown
  const crown = new THREE.Mesh(pedGeo, pedMat);
  crown.position.y = 2.05;
  coreGroup.add(crown);

  // 3 & 4. Double helical protein backbone ribbons colored by AlphaFold pLDDT scale
  const helixGroup = new THREE.Group();
  helixGroup.name = 'helixRibbon';
  const plddtColors = [0x0053d6, 0x65cbf3, 0xffdb13, 0xff7d45];
  const sphereGeo = new THREE.SphereGeometry(0.09, 12, 12);

  for (let i = 0; i < 20; i++) {
    const t = i / 19;
    const angle = t * Math.PI * 4;
    const y = 0.4 + t * 1.4;
    const colHex = plddtColors[i % plddtColors.length];
    const nodeMat = new THREE.MeshStandardMaterial({
      color: colHex,
      emissive: colHex,
      emissiveIntensity: 0.55,
      roughness: 0.25,
      metalness: 0.4,
    });

    const strandA = new THREE.Mesh(sphereGeo, nodeMat);
    strandA.position.set(Math.cos(angle) * 0.35, y, Math.sin(angle) * 0.35);
    helixGroup.add(strandA);

    const strandB = new THREE.Mesh(sphereGeo, nodeMat);
    strandB.position.set(Math.cos(angle + Math.PI) * 0.35, y, Math.sin(angle + Math.PI) * 0.35);
    helixGroup.add(strandB);
  }
  coreGroup.add(helixGroup);

  // 5. Outer optical containment vessel (depthWrite: false per Three.js skill)
  const glassGeo = new THREE.CylinderGeometry(0.62, 0.62, 1.65, 24);
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x88ccff,
    transparent: true,
    opacity: isSoftwareGl ? 0.24 : 0.32,
    roughness: 0.1,
    metalness: 0.1,
    depthWrite: false,
  });
  const glassVessel = new THREE.Mesh(glassGeo, glassMat);
  glassVessel.position.y = 1.1;
  glassVessel.renderOrder = 2;
  coreGroup.add(glassVessel);

  return coreGroup;
}

export const Chamber3DViewport: React.FC = () => {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const {
    roomState,
    activeSlot,
    setActiveSlot,
    viewportMode,
    pingToolActive,
    setPingToolActive,
    dispatchAction,
  } = useRoom();

  // Keep latest mutable refs so WebGL canvas never tears down on React state changes
  const stateRef = useRef<SharedRoomState>(roomState);
  stateRef.current = roomState;

  const activeSlotRef = useRef<'A' | 'B'>(activeSlot);
  activeSlotRef.current = activeSlot;

  const viewportModeRef = useRef(viewportMode);
  viewportModeRef.current = viewportMode;

  const pingToolRef = useRef(pingToolActive);
  pingToolRef.current = pingToolActive;

  const dispatchRef = useRef(dispatchAction);
  dispatchRef.current = dispatchAction;

  const setActiveSlotRef = useRef(setActiveSlot);
  setActiveSlotRef.current = setActiveSlot;

  const setPingToolRef = useRef(setPingToolActive);
  setPingToolRef.current = setPingToolActive;

  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    // 1. Software-WebGL detection from GPU renderer string
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0d1117);
    scene.fog = new THREE.FogExp2(0x0d1117, 0.022);

    // Mandatory studio environment reflection
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      46,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.1,
      120
    );
    camera.position.set(5.5, 11.5, 12.5);
    camera.lookAt(5.5, 0, 3.5);

    // 3-Point Warm/Cool Studio Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x6495ed, 0x161b22, 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff0dd, 1.9);
    keyLight.position.set(9, 15, 10);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 35;
    keyLight.shadow.camera.left = -9;
    keyLight.shadow.camera.right = 9;
    keyLight.shadow.camera.top = 9;
    keyLight.shadow.camera.bottom = -9;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    // Chamber A Cyan accent light & Chamber B Amber accent light
    const cyanPoint = new THREE.PointLight(0x58a6ff, 2.2, 11);
    cyanPoint.position.set(2.5, 3.2, 3.5);
    scene.add(cyanPoint);

    const amberPoint = new THREE.PointLight(0xd29922, 2.2, 11);
    amberPoint.position.set(8.5, 3.2, 3.5);
    scene.add(amberPoint);

    // Sub-floor plasma abyss plane
    const abyssGeo = new THREE.PlaneGeometry(40, 40);
    abyssGeo.rotateX(-Math.PI / 2);
    const abyssMat = new THREE.MeshStandardMaterial({
      color: 0x070a0f,
      roughness: 0.9,
      metalness: 0.1,
    });
    const abyssMesh = new THREE.Mesh(abyssGeo, abyssMat);
    abyssMesh.position.set(5.5, -0.55, 3.5);
    scene.add(abyssMesh);

    const gridTex = createProceduralGridTexture(renderer.capabilities.getMaxAnisotropy());

    // InstancedMesh for floor tiles (up to 96 tiles)
    const tileGeo = new THREE.BoxGeometry(0.96, 0.24, 0.96);
    const tileMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: gridTex,
      roughness: 0.55,
      metalness: 0.35,
    });
    const floorInstanced = new THREE.InstancedMesh(tileGeo, tileMat, 96);
    floorInstanced.receiveShadow = true;
    scene.add(floorInstanced);

    // InstancedMesh for perimeter & partition wall blocks (up to 96 blocks)
    const wallGeo = new THREE.BoxGeometry(0.96, 0.85, 0.96);
    const wallMat = new THREE.MeshStandardMaterial({
      color: 0x1e2633,
      roughness: 0.4,
      metalness: 0.7,
    });
    const wallInstanced = new THREE.InstancedMesh(wallGeo, wallMat, 96);
    wallInstanced.castShadow = !isSoftwareGl;
    wallInstanced.receiveShadow = true;
    scene.add(wallInstanced);

    // Raycast proxy plane for click-to-move / click-to-ping
    const raycastPlaneGeo = new THREE.PlaneGeometry(12, 8);
    raycastPlaneGeo.rotateX(-Math.PI / 2);
    const raycastPlaneMat = new THREE.MeshBasicMaterial({ visible: false });
    const raycastPlane = new THREE.Mesh(raycastPlaneGeo, raycastPlaneMat);
    raycastPlane.position.set(5.5, 0.05, 3.5);
    scene.add(raycastPlane);

    // Dynamic level entities container
    const dynamicLevelGroup = new THREE.Group();
    scene.add(dynamicLevelGroup);

    // Central Bio-Containment Core at partition center (5.5, 0, 3.5)
    const bioCore = buildBioContainmentCore(isSoftwareGl);
    bioCore.position.set(5.5, 0, 3.5);
    scene.add(bioCore);

    // Operatives A (Cyan) and B (Amber)
    const playerAMesh = buildCompositeOperativeMesh(0x58a6ff, 0x99d5ff);
    const playerBMesh = buildCompositeOperativeMesh(0xd29922, 0xffdf80);
    scene.add(playerAMesh);
    scene.add(playerBMesh);

    // Track dynamic meshes by ID
    const switchMeshes = new Map<string, THREE.Group>();
    const doorMeshes = new Map<string, THREE.Group>();
    const hazardMeshes = new Map<string, THREE.Group>();
    const pingMeshes = new Map<string, THREE.Group>();

    let builtLevelIndex = -1;

    function rebuildLevelGeometry(state: SharedRoomState) {
      const puzzle = state.puzzleState;
      builtLevelIndex = puzzle.levelIndex;

      // Clear previous dynamic level meshes
      while (dynamicLevelGroup.children.length > 0) {
        dynamicLevelGroup.remove(dynamicLevelGroup.children[0]);
      }
      switchMeshes.clear();
      doorMeshes.clear();
      hazardMeshes.clear();

      let floorCount = 0;
      let wallCount = 0;

      for (let y = 0; y < puzzle.height; y++) {
        for (let x = 0; x < puzzle.width; x++) {
          const cell = puzzle.grid[y][x];
          if (cell.type !== 'chasm' && cell.type !== 'bridge') {
            _dummyMatrix.makeTranslation(x, -0.12, y);
            floorInstanced.setMatrixAt(floorCount, _dummyMatrix);
            if (cell.chamber === 'A') {
              _color.setHex(0xcbe4ff);
            } else if (cell.chamber === 'B') {
              _color.setHex(0xffe4b5);
            } else {
              _color.setHex(0x94a3b8);
            }
            floorInstanced.setColorAt(floorCount, _color);
            floorCount++;
          }

          if (cell.type === 'wall') {
            // Skip central bio-core spot at (5,3) & (6,3) so core is showcased
            if ((x === 5 || x === 6) && (y === 3 || y === 4)) continue;
            _dummyMatrix.makeTranslation(x, 0.42, y);
            wallInstanced.setMatrixAt(wallCount, _dummyMatrix);
            wallCount++;
          }

          if (cell.type === 'exit') {
            const exitGroup = new THREE.Group();
            exitGroup.position.set(x, 0.02, y);
            const ringGeo = new THREE.RingGeometry(0.26, 0.42, 24);
            ringGeo.rotateX(-Math.PI / 2);
            const ringMat = new THREE.MeshStandardMaterial({
              color: cell.owner === 'A' ? 0x58a6ff : 0xd29922,
              emissive: cell.owner === 'A' ? 0x58a6ff : 0xd29922,
              emissiveIntensity: 1.4,
              side: THREE.DoubleSide,
              polygonOffset: true,
              polygonOffsetFactor: -1,
            });
            exitGroup.add(new THREE.Mesh(ringGeo, ringMat));
            dynamicLevelGroup.add(exitGroup);
          }
        }
      }

      floorInstanced.count = floorCount;
      floorInstanced.instanceMatrix.needsUpdate = true;
      if (floorInstanced.instanceColor) floorInstanced.instanceColor.needsUpdate = true;
      floorInstanced.computeBoundingSphere();

      wallInstanced.count = wallCount;
      wallInstanced.instanceMatrix.needsUpdate = true;
      wallInstanced.computeBoundingSphere();

      // Build Switch Groups (4 parts: base plate, collar, glowing plunger, conduit line)
      for (const sw of puzzle.switches) {
        const swGroup = new THREE.Group();
        swGroup.position.set(sw.x, 0.02, sw.y);

        const plateGeo = new THREE.CylinderGeometry(0.38, 0.44, 0.08, 20);
        const plateMat = new THREE.MeshStandardMaterial({
          color: 0x222b38,
          roughness: 0.4,
          metalness: 0.8,
        });
        const plate = new THREE.Mesh(plateGeo, plateMat);
        plate.position.y = 0.04;
        swGroup.add(plate);

        const plungerGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.18, 20);
        const plungerMat = new THREE.MeshStandardMaterial({
          color: sw.chamber === 'A' ? 0x58a6ff : 0xd29922,
          emissive: sw.chamber === 'A' ? 0x58a6ff : 0xd29922,
          emissiveIntensity: 0.8,
          roughness: 0.2,
          metalness: 0.4,
        });
        const plunger = new THREE.Mesh(plungerGeo, plungerMat);
        plunger.name = 'plunger';
        plunger.position.y = 0.14;
        swGroup.add(plunger);

        dynamicLevelGroup.add(swGroup);
        switchMeshes.set(sw.id, swGroup);
      }

      // Build Door & Hardlight Bridge Groups
      for (const door of puzzle.doors) {
        const dGroup = new THREE.Group();
        dGroup.position.set(door.x, 0, door.y);

        if (door.kind === 'bridge') {
          const bridgeGeo = new THREE.BoxGeometry(0.92, 0.14, 0.92);
          const bridgeMat = new THREE.MeshStandardMaterial({
            color: 0x2ea043,
            emissive: 0x238636,
            emissiveIntensity: 1.35,
            transparent: true,
            opacity: 0.92,
            roughness: 0.18,
            metalness: 0.3,
          });
          const bridgeMesh = new THREE.Mesh(bridgeGeo, bridgeMat);
          bridgeMesh.name = 'panel';
          bridgeMesh.position.y = -0.06;
          dGroup.add(bridgeMesh);
        } else {
          // Framed gate jambs on both sides + sliding energy barrier
          const jambGeo = new THREE.BoxGeometry(0.14, 0.95, 0.22);
          const jambMat = new THREE.MeshStandardMaterial({
            color: 0x334155,
            roughness: 0.35,
            metalness: 0.8,
          });
          const leftJamb = new THREE.Mesh(jambGeo, jambMat);
          leftJamb.position.set(-0.4, 0.48, 0);
          const rightJamb = new THREE.Mesh(jambGeo, jambMat);
          rightJamb.position.set(0.4, 0.48, 0);
          dGroup.add(leftJamb, rightJamb);

          const barrierGeo = new THREE.BoxGeometry(0.76, 0.8, 0.1);
          const barrierMat = new THREE.MeshStandardMaterial({
            color: door.chamber === 'A' ? 0x58a6ff : 0xd29922,
            emissive: door.chamber === 'A' ? 0x58a6ff : 0xd29922,
            emissiveIntensity: 0.9,
            transparent: true,
            opacity: 0.78,
          });
          const barrier = new THREE.Mesh(barrierGeo, barrierMat);
          barrier.name = 'panel';
          barrier.position.y = 0.42;
          dGroup.add(barrier);
        }

        dynamicLevelGroup.add(dGroup);
        doorMeshes.set(door.id, dGroup);
      }

      // Build Hazard Drones (4-part composite drone + windup telegraph ring)
      for (const haz of puzzle.hazards) {
        const hGroup = new THREE.Group();
        hGroup.position.set(haz.x, 0, haz.y);

        const ringGeo = new THREE.RingGeometry(0.32, 0.45, 24);
        ringGeo.rotateX(-Math.PI / 2);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0xf85149,
          transparent: true,
          opacity: 0.35,
          side: THREE.DoubleSide,
          depthWrite: false,
        });
        const telegraphRing = new THREE.Mesh(ringGeo, ringMat);
        telegraphRing.name = 'telegraph';
        telegraphRing.position.y = 0.025;
        hGroup.add(telegraphRing);

        const bodyGeo = new THREE.OctahedronGeometry(0.24, 1);
        const bodyMat = new THREE.MeshStandardMaterial({
          color: 0xef4444,
          emissive: 0x991b1b,
          emissiveIntensity: 0.8,
          roughness: 0.25,
          metalness: 0.7,
        });
        const body = new THREE.Mesh(bodyGeo, bodyMat);
        body.name = 'droneBody';
        body.position.y = 0.55;
        hGroup.add(body);

        dynamicLevelGroup.add(hGroup);
        hazardMeshes.set(haz.id, hGroup);
      }
    }

    rebuildLevelGeometry(stateRef.current);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Raycasting for tile clicks
    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();

    const handlePointerDown = (e: MouseEvent) => {
      const currentState = stateRef.current;
      if (currentState.status !== 'PLAYING') return;

      const rect = renderer.domElement.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return;

      pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(pointerNdc, camera);
      const hits = raycaster.intersectObject(raycastPlane, false);
      if (hits.length > 0) {
        const pt = hits[0].point;
        const gridX = Math.round(pt.x);
        const gridY = Math.round(pt.z);
        if (gridX >= 0 && gridX < 12 && gridY >= 0 && gridY < 8) {
          const clickedSlot: 'A' | 'B' = gridX < 6 ? 'A' : 'B';

          if (pingToolRef.current) {
            dispatchRef.current({
              type: 'SEND_PING',
              slot: activeSlotRef.current,
              x: gridX,
              y: gridY,
              kind: 'stand_here',
              label: `Coord (${gridX}, ${gridY})`,
            });
            setPingToolRef.current(false);
            return;
          }

          const targetSlot = currentState.splitControlMode ? clickedSlot : activeSlotRef.current;
          setActiveSlotRef.current(targetSlot);
          dispatchRef.current({
            type: 'TELEPORT_CLICK',
            slot: targetSlot,
            targetX: gridX,
            targetY: gridY,
          });
        }
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Software-WebGL safe frame pacing (`afterDraw`)
    let frameId = 0;
    let isDisposed = false;
    let lastTimeMs = performance.now();
    const startTimeMs = lastTimeMs;

    function afterDraw(cb: () => void) {
      if (isDisposed) return;
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        if (isDisposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (isDisposed) return;
      const nowMs = performance.now();
      const rawDt = (nowMs - lastTimeMs) / 1000;
      lastTimeMs = nowMs;
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
      const elapsed = (nowMs - startTimeMs) / 1000;
      const state = stateRef.current;

      if (state.puzzleState.levelIndex !== builtLevelIndex) {
        rebuildLevelGeometry(state);
      }

      const dampFactor = 1 - Math.exp(-8 * dt);

      // Update Operatives A and B positions & orientations smoothly
      const pA = state.players.find((p) => p.slot === 'A');
      const pB = state.players.find((p) => p.slot === 'B');

      if (pA) {
        _vec3.set(pA.x, 0, pA.y);
        playerAMesh.position.lerp(_vec3, dampFactor);
        const targetYawA =
          pA.facing === 'E' ? Math.PI / 2 : pA.facing === 'W' ? -Math.PI / 2 : pA.facing === 'N' ? Math.PI : 0;
        playerAMesh.rotation.y = THREE.MathUtils.lerp(playerAMesh.rotation.y, targetYawA, dampFactor);
      }

      if (pB) {
        _vec3.set(pB.x, 0, pB.y);
        playerBMesh.position.lerp(_vec3, dampFactor);
        const targetYawB =
          pB.facing === 'E' ? Math.PI / 2 : pB.facing === 'W' ? -Math.PI / 2 : pB.facing === 'N' ? Math.PI : 0;
        playerBMesh.rotation.y = THREE.MathUtils.lerp(playerBMesh.rotation.y, targetYawB, dampFactor);
      }

      // Rotate AlphaFold Bio-Core helix
      const helix = bioCore.getObjectByName('helixRibbon');
      if (helix) {
        helix.rotation.y = elapsed * (state.puzzleState.bioLockVerified ? 1.8 : 0.65);
      }

      // Update switches
      for (const sw of state.puzzleState.switches) {
        const swGroup = switchMeshes.get(sw.id);
        if (!swGroup) continue;
        const plunger = swGroup.getObjectByName('plunger') as THREE.Mesh | undefined;
        if (plunger) {
          const targetY = sw.state ? 0.07 : 0.16;
          plunger.position.y = THREE.MathUtils.lerp(plunger.position.y, targetY, dampFactor);
          const mat = plunger.material as THREE.MeshStandardMaterial;
          mat.color.setHex(sw.state ? 0x238636 : sw.chamber === 'A' ? 0x58a6ff : 0xd29922);
          mat.emissive.setHex(sw.state ? 0x2ea043 : sw.chamber === 'A' ? 0x58a6ff : 0xd29922);
          mat.emissiveIntensity = sw.state ? 1.8 : 0.7;
        }
      }

      // Update doors and bridges
      for (const door of state.puzzleState.doors) {
        const dGroup = doorMeshes.get(door.id);
        if (!dGroup) continue;
        const panel = dGroup.getObjectByName('panel') as THREE.Mesh | undefined;
        if (!panel) continue;

        if (door.kind === 'bridge') {
          const targetY = door.isOpen ? -0.02 : -0.48;
          panel.position.y = THREE.MathUtils.lerp(panel.position.y, targetY, dampFactor);
          const mat = panel.material as THREE.MeshStandardMaterial;
          mat.opacity = door.isOpen ? 0.95 : 0.18;
        } else {
          const targetY = door.isOpen ? -0.45 : 0.42;
          panel.position.y = THREE.MathUtils.lerp(panel.position.y, targetY, dampFactor);
        }
      }

      // Update hazards & windup telegraphs
      for (const haz of state.puzzleState.hazards) {
        const hGroup = hazardMeshes.get(haz.id);
        if (!hGroup) continue;
        _vec3.set(haz.x, 0, haz.y);
        hGroup.position.lerp(_vec3, dampFactor);
        const body = hGroup.getObjectByName('droneBody') as THREE.Mesh | undefined;
        const ring = hGroup.getObjectByName('telegraph') as THREE.Mesh | undefined;
        if (body) {
          body.rotation.y = elapsed * 2.4;
          body.position.y = 0.52 + Math.sin(elapsed * 4) * 0.06;
        }
        if (ring) {
          const scale = 0.7 + haz.windupTimer * 0.65;
          ring.scale.set(scale, scale, 1);
          (ring.material as THREE.MeshBasicMaterial).opacity = haz.activePulse ? 0.85 : 0.28;
        }
      }

      // Sync 3D Ping Beacons
      const activePingIds = new Set(state.pings.map((p) => p.id));
      for (const [id, mesh] of pingMeshes.entries()) {
        if (!activePingIds.has(id)) {
          dynamicLevelGroup.remove(mesh);
          pingMeshes.delete(id);
        }
      }
      for (const ping of state.pings) {
        let pGroup = pingMeshes.get(ping.id);
        if (!pGroup) {
          pGroup = new THREE.Group();
          const beamGeo = new THREE.CylinderGeometry(0.06, 0.22, 1.8, 16);
          const beamMat = new THREE.MeshBasicMaterial({
            color: ping.slot === 'A' ? 0x58a6ff : 0xd29922,
            transparent: true,
            opacity: 0.65,
            depthWrite: false,
          });
          const beam = new THREE.Mesh(beamGeo, beamMat);
          beam.position.y = 0.9;
          pGroup.add(beam);
          pGroup.position.set(ping.x, 0, ping.y);
          dynamicLevelGroup.add(pGroup);
          pingMeshes.set(ping.id, pGroup);
        }
      }

      // Camera choreography: Orbital tour on Title/Lobby, damped tactical framing during Playing
      if (state.status === 'LOBBY' || state.status === 'CONNECTING') {
        const orbitAngle = elapsed * 0.22;
        _targetCamPos.set(
          5.5 + Math.sin(orbitAngle) * 8.5,
          9.2,
          3.5 + Math.cos(orbitAngle) * 8.5
        );
        _targetLookAt.set(5.5, 0.4, 3.5);
      } else {
        const vMode = viewportModeRef.current;
        if (vMode === 'CHAMBER_A' && pA) {
          _targetCamPos.set(2.5, 8.2, 8.8);
          _targetLookAt.set(2.5, 0.2, 3.5);
        } else if (vMode === 'CHAMBER_B' && pB) {
          _targetCamPos.set(8.5, 8.2, 8.8);
          _targetLookAt.set(8.5, 0.2, 3.5);
        } else {
          _targetCamPos.set(5.5, 10.6, 11.2);
          _targetLookAt.set(5.5, 0.2, 3.6);
        }
      }

      camera.position.lerp(_targetCamPos, dampFactor);
      _currentLookAt.lerp(_targetLookAt, dampFactor);
      camera.lookAt(_currentLookAt);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      isDisposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={canvasMountRef}
      data-testid="chamber-3d-canvas"
      className="fixed inset-0 w-screen h-screen overflow-hidden z-0"
    />
  );
};
