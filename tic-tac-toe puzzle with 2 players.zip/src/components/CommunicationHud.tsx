import React, { useEffect, useState } from 'react';
import { useRoom } from '../context/RoomProvider';
import {
  BioStructureRecord,
  fetchBioStructureProfile,
  QUICK_PROTEIN_TARGETS,
} from '../services/bioscienceService';

interface GeminiScanResult {
  specimenClassification: string;
  structuralObservations: string;
  recommendedAccession: string;
  confidenceScore: number;
  tacticalHint: string;
}

export const CommunicationHud: React.FC = () => {
  const { roomState, activeSlot, dispatchAction } = useRoom();
  const [collapsed, setCollapsed] = useState(true);
  const [activeTab, setActiveTab] = useState<'comms' | 'biovault' | 'scanner'>('comms');
  const [chatInput, setChatInput] = useState('');

  // Bioscience AlphaFold + UniProt inspector state
  const [selectedAccession, setSelectedAccession] = useState(
    roomState.puzzleState.proteinTarget.uniprotAccession || 'P04637'
  );
  const [bioProfile, setBioProfile] = useState<BioStructureRecord | null>(null);
  const [loadingBio, setLoadingBio] = useState(false);

  // Gemini 4 Argon image analysis state
  const [previewDataUrl, setPreviewDataUrl] = useState<string | null>(null);
  const [scanPrompt, setScanPrompt] = useState('');
  const [scanLoading, setScanLoading] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<GeminiScanResult | null>(null);

  useEffect(() => {
    setSelectedAccession(roomState.puzzleState.proteinTarget.uniprotAccession);
  }, [roomState.puzzleState.proteinTarget.uniprotAccession]);

  useEffect(() => {
    let active = true;
    setLoadingBio(true);
    fetchBioStructureProfile(selectedAccession)
      .then((res) => {
        if (active) setBioProfile(res);
      })
      .finally(() => {
        if (active) setLoadingBio(false);
      });
    return () => {
      active = false;
    };
  }, [selectedAccession]);

  // Keyboard shortcut [H] to collapse/expand bottom dock
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
        return;
      }
      if (e.key === 'h' || e.key === 'H') {
        setCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  if (roomState.status === 'LOBBY' || roomState.status === 'CONNECTING') {
    return null;
  }

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    dispatchAction({ type: 'SEND_CHAT', slot: activeSlot, text: chatInput });
    setChatInput('');
  };

  const handleQuickEmote = (text: string) => {
    dispatchAction({ type: 'SEND_CHAT', slot: activeSlot, text, isEmote: true });
  };

  const handleQuickPing = (label: string, kind: 'inspect' | 'stand_here' | 'activate' | 'danger') => {
    const player = roomState.players.find((p) => p.slot === activeSlot) || roomState.players[0];
    dispatchAction({
      type: 'SEND_PING',
      slot: activeSlot,
      x: player.x,
      y: player.y,
      kind,
      label,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPreviewDataUrl(reader.result);
        setScanError(null);
      }
    };
    reader.readAsDataURL(file);
  };

  // Generates a deterministic synthetic bio-glyph specimen canvas so users can test image analysis in 1 click
  const generateSampleBioSpecimenImage = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 200;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#0D1117';
    ctx.fillRect(0, 0, 320, 200);
    ctx.strokeStyle = '#58A6FF';
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let x = 20; x < 300; x += 10) {
      const y = 100 + Math.sin(x * 0.06) * 42;
      if (x === 20) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    ctx.fillStyle = '#D29922';
    ctx.font = 'bold 16px monospace';
    ctx.fillText(`SPECIMEN: ${roomState.puzzleState.proteinTarget.gene} (${selectedAccession})`, 24, 38);
    ctx.fillStyle = '#C9D1D9';
    ctx.font = '12px monospace';
    ctx.fillText('ALPHAFOLD pLDDT > 90 CORE HELIX', 24, 178);

    const dataUrl = canvas.toDataURL('image/png');
    setPreviewDataUrl(dataUrl);
    setScanError(null);
  };

  const handleAnalyzeImage = async () => {
    if (!previewDataUrl) {
      setScanError('Please upload an image or click "Load Chamber Specimen" first.');
      return;
    }
    setScanLoading(true);
    setScanError(null);
    try {
      const response = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: previewDataUrl,
          mimeType: 'image/png',
          prompt: scanPrompt,
          targetProtein: `${roomState.puzzleState.proteinTarget.gene} (${selectedAccession})`,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setScanError(data.error || 'Gemini image analysis failed.');
      } else if (data.analysis) {
        setScanResult(data.analysis);
      }
    } catch (err: unknown) {
      setScanError(err instanceof Error ? err.message : 'Network error calling /api/analyze-image');
    } finally {
      setScanLoading(false);
    }
  };

  const latestMessage = roomState.messages[roomState.messages.length - 1];

  return (
    <div
      className="fixed bottom-3 left-1/2 -translate-x-1/2 z-20 w-[min(740px,92vw)] pointer-events-auto"
      data-testid="communication-hud"
    >
      {/* Top Bar of Collapsible Bottom Dock */}
      <div className="flex items-center justify-between gap-2 bg-[#161B22] border border-[#30363D] rounded-xl px-3.5 py-2 shadow-2xl">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveTab('comms');
              setCollapsed(false);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              !collapsed && activeTab === 'comms'
                ? 'bg-[#58A6FF] text-[#0D1117]'
                : 'text-[#C9D1D9] hover:bg-[#0D1117]'
            }`}
          >
            Comms & Pings
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('biovault');
              setCollapsed(false);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              !collapsed && activeTab === 'biovault'
                ? 'bg-[#238636] text-white'
                : 'text-[#C9D1D9] hover:bg-[#0D1117]'
            }`}
          >
            AlphaFold Bio-Vault ({roomState.puzzleState.proteinTarget.gene})
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('scanner');
              setCollapsed(false);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              !collapsed && activeTab === 'scanner'
                ? 'bg-[#D29922] text-[#0D1117]'
                : 'text-[#C9D1D9] hover:bg-[#0D1117]'
            }`}
          >
            Gemini Specimen Scanner
          </button>
        </div>

        {/* Live 1-line feed preview when collapsed */}
        {collapsed && latestMessage && (
          <div className="hidden md:block text-xs text-[#8B949E] truncate max-w-[340px]">
            <span className="font-mono text-[#C9D1D9]">{latestMessage.senderName}:</span>{' '}
            {latestMessage.text}
          </div>
        )}

        <button
          type="button"
          onClick={() => setCollapsed((prev) => !prev)}
          className="px-3 py-1.5 text-xs font-mono font-semibold rounded-lg bg-[#0D1117] border border-[#30363D] text-[#C9D1D9] hover:border-[#58A6FF] whitespace-nowrap shrink-0"
        >
          {collapsed ? '▴ Expand Dock [H]' : '▾ Hide Controls [H]'}
        </button>
      </div>

      {/* Expanded Drawer Content */}
      {!collapsed && (
        <div className="mt-2 bg-[#161B22] border border-[#30363D] rounded-xl p-4 shadow-2xl max-h-[42vh] overflow-y-auto">
          {activeTab === 'comms' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* Quick Pings & Emotes */}
              <div className="md:col-span-5 flex flex-col gap-2.5">
                <div className="text-xs font-semibold text-[#C9D1D9]">
                  Tactical Pings & Quick Signals (Operative {activeSlot})
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickPing('Stand on Relay!', 'stand_here')}
                    className="px-2.5 py-2 text-xs font-medium rounded-lg bg-[#0D1117] border border-[#30363D] hover:border-[#58A6FF] text-[#C9D1D9] text-left"
                  >
                    Ping: Stand Here
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickPing('Toggle Switch Now!', 'activate')}
                    className="px-2.5 py-2 text-xs font-medium rounded-lg bg-[#0D1117] border border-[#30363D] hover:border-[#D29922] text-[#C9D1D9] text-left"
                  >
                    Ping: Toggle Switch
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickEmote('Bridge is open! Cross now!')}
                    className="px-2.5 py-2 text-xs font-medium rounded-lg bg-[#0D1117] border border-[#30363D] hover:border-[#238636] text-[#C9D1D9] text-left"
                  >
                    Signal: Bridge Open
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickEmote('Heading to Exit Pad!')}
                    className="px-2.5 py-2 text-xs font-medium rounded-lg bg-[#0D1117] border border-[#30363D] hover:border-[#58A6FF] text-[#C9D1D9] text-left"
                  >
                    Signal: At Exit Pad
                  </button>
                </div>
              </div>

              {/* Real-Time Synchronized Chat Log */}
              <div className="md:col-span-7 flex flex-col gap-2">
                <div className="h-24 overflow-y-auto rounded-lg bg-[#0D1117] border border-[#30363D] p-2.5 space-y-1.5 text-xs">
                  {roomState.messages.map((m) => (
                    <div key={m.id} className="leading-relaxed">
                      <span
                        className={`font-mono font-semibold ${
                          m.senderSlot === 'A'
                            ? 'text-[#58A6FF]'
                            : m.senderSlot === 'B'
                            ? 'text-[#D29922]'
                            : 'text-[#238636]'
                        }`}
                      >
                        [{m.senderName}]:
                      </span>{' '}
                      <span className="text-[#C9D1D9]">{m.text}</span>
                    </div>
                  ))}
                </div>
                <form onSubmit={handleSendChat} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={`Transmit message as Operative ${activeSlot}...`}
                    className="flex-1 px-3 py-1.5 rounded-lg bg-[#0D1117] border border-[#30363D] text-xs text-[#C9D1D9] focus:outline-none focus:border-[#58A6FF]"
                    aria-label="Chat message input"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 rounded-lg bg-[#58A6FF] text-[#0D1117] text-xs font-semibold hover:bg-[#79b8ff] transition-colors whitespace-nowrap shrink-0"
                  >
                    Transmit
                  </button>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'biovault' && (
            <div className="space-y-3">
              {/* Quick-Try Example Protein Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#30363D]">
                <div className="flex flex-wrap items-center gap-1.5">
                  {QUICK_PROTEIN_TARGETS.map((item) => (
                    <button
                      key={item.accession}
                      type="button"
                      onClick={() => setSelectedAccession(item.accession)}
                      className={`px-2.5 py-1 text-xs font-mono rounded-md transition-colors ${
                        selectedAccession === item.accession
                          ? 'bg-[#58A6FF] text-[#0D1117] font-bold'
                          : 'bg-[#0D1117] text-[#C9D1D9] border border-[#30363D] hover:border-[#58A6FF]'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>

                {bioProfile && (
                  <button
                    type="button"
                    data-testid="verify-bio-lock-btn"
                    onClick={() =>
                      dispatchAction({
                        type: 'VERIFY_BIO_LOCK',
                        uniprotAccession: bioProfile.uniprotAccession,
                        meanPlddt: bioProfile.meanPlddt,
                      })
                    }
                    className="px-3.5 py-1.5 rounded-lg bg-[#238636] hover:bg-[#2ea043] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
                  >
                    Verify {bioProfile.gene} & Unlock All Bridges
                  </button>
                )}
              </div>

              {loadingBio && (
                <div className="text-xs font-mono text-[#8B949E] py-4">
                  Querying AlphaFold DB & UniProtKB for {selectedAccession}...
                </div>
              )}

              {bioProfile && !loadingBio && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
                  <div className="md:col-span-6 space-y-1.5 bg-[#0D1117] border border-[#30363D] rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-sm text-[#58A6FF]">
                        {bioProfile.gene} · {bioProfile.uniprotAccession}
                      </span>
                      <span className="text-[#8B949E] font-mono">
                        {bioProfile.sequenceLength} aa · PDB {bioProfile.pdbId} ({bioProfile.resolutionAngstrom} Å)
                      </span>
                    </div>
                    <div className="text-[#C9D1D9] font-medium">{bioProfile.proteinName}</div>
                    <div className="text-[#8B949E]">
                      Provenance: [Predicted by model: AlphaFold v6] · [Experimentally determined: {bioProfile.experimentalMethod}]
                    </div>
                    <div className="flex items-center gap-3 pt-1">
                      <a
                        href={bioProfile.alphafoldUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#58A6FF] hover:underline font-mono"
                      >
                        AlphaFold DB ↗
                      </a>
                      <span>·</span>
                      <a
                        href={bioProfile.uniprotUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#58A6FF] hover:underline font-mono"
                      >
                        UniProtKB ↗
                      </a>
                      <span>·</span>
                      <a
                        href={bioProfile.rcsbUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#58A6FF] hover:underline font-mono"
                      >
                        RCSB PDB ↗
                      </a>
                    </div>
                  </div>

                  {/* Canonical 4-Band AlphaFold pLDDT Confidence Scale & Domains */}
                  <div className="md:col-span-6 space-y-2 bg-[#0D1117] border border-[#30363D] rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-[#C9D1D9]">
                        AlphaFold pLDDT Confidence Distribution
                      </span>
                      <span className="font-mono font-bold text-[#C9D1D9] tabular-nums">
                        Mean: {bioProfile.meanPlddt.toFixed(1)}
                      </span>
                    </div>
                    <div className="w-full h-3 rounded overflow-hidden flex">
                      <div
                        style={{ width: `${bioProfile.plddtBands.veryHigh}%`, backgroundColor: '#0053D6' }}
                        title={`Very High (>90): ${bioProfile.plddtBands.veryHigh}%`}
                      />
                      <div
                        style={{ width: `${bioProfile.plddtBands.confident}%`, backgroundColor: '#65CBF3' }}
                        title={`Confident (70-90): ${bioProfile.plddtBands.confident}%`}
                      />
                      <div
                        style={{ width: `${bioProfile.plddtBands.low}%`, backgroundColor: '#FFDB13' }}
                        title={`Low (50-70): ${bioProfile.plddtBands.low}%`}
                      />
                      <div
                        style={{ width: `${bioProfile.plddtBands.veryLow}%`, backgroundColor: '#FF7D45' }}
                        title={`Very Low (<50): ${bioProfile.plddtBands.veryLow}%`}
                      />
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono text-[#8B949E]">
                      <span>&gt;90 Very High: {bioProfile.plddtBands.veryHigh}%</span>
                      <span>·</span>
                      <span>70-90 Confident: {bioProfile.plddtBands.confident}%</span>
                      <span>·</span>
                      <span>50-70 Low: {bioProfile.plddtBands.low}%</span>
                    </div>
                    <div className="pt-1 space-y-1">
                      {bioProfile.domains.slice(0, 2).map((d, i) => (
                        <div key={i} className="flex items-center justify-between text-[11px] font-mono">
                          <span className="text-[#C9D1D9] truncate">{d.name}</span>
                          <span className="text-[#8B949E] tabular-nums">
                            aa {d.start}–{d.end}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'scanner' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
              <div className="md:col-span-5 space-y-2.5">
                <div className="font-semibold text-[#C9D1D9]">
                  Upload Bio-Specimen or Puzzle Glyph Image (Gemini 4 Argon)
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <label className="px-3 py-1.5 rounded-lg bg-[#0D1117] border border-[#30363D] hover:border-[#58A6FF] text-[#C9D1D9] cursor-pointer font-medium">
                    Upload Image File
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={generateSampleBioSpecimenImage}
                    className="px-3 py-1.5 rounded-lg bg-[#0D1117] border border-[#30363D] hover:border-[#D29922] text-[#D29922] font-medium"
                  >
                    Load Chamber Specimen
                  </button>
                </div>

                <input
                  type="text"
                  value={scanPrompt}
                  onChange={(e) => setScanPrompt(e.target.value)}
                  placeholder="Optional prompt: e.g. Identify protein fold & chamber cipher..."
                  className="w-full px-3 py-1.5 rounded-lg bg-[#0D1117] border border-[#30363D] text-xs text-[#C9D1D9] focus:outline-none focus:border-[#58A6FF]"
                  aria-label="Image analysis prompt"
                />

                <button
                  type="button"
                  onClick={handleAnalyzeImage}
                  disabled={scanLoading}
                  className="w-full py-2 rounded-lg bg-[#D29922] hover:bg-[#e3a82b] text-[#0D1117] font-semibold transition-colors disabled:opacity-50"
                >
                  {scanLoading ? 'Analyzing with gemini-4-argon...' : 'Analyze Specimen with Gemini'}
                </button>
              </div>

              <div className="md:col-span-7 bg-[#0D1117] border border-[#30363D] rounded-lg p-3 flex flex-col justify-between min-h-[120px]">
                {previewDataUrl && (
                  <div className="flex items-start gap-3 mb-2">
                    <img
                      src={previewDataUrl}
                      alt="Uploaded bio-specimen preview"
                      referrerPolicy="no-referrer"
                      className="w-24 h-16 object-cover rounded border border-[#30363D] shrink-0"
                    />
                    <div className="space-y-1 flex-1">
                      {scanError && <div className="text-[#F85149] font-medium">{scanError}</div>}
                      {scanResult && (
                        <>
                          <div className="font-mono font-bold text-[#58A6FF]">
                            {scanResult.specimenClassification} · Confidence {Math.round(scanResult.confidenceScore)}%
                          </div>
                          <p className="text-[#C9D1D9] leading-snug">{scanResult.structuralObservations}</p>
                          <p className="text-[#238636] font-mono">{scanResult.tacticalHint}</p>
                        </>
                      )}
                      {!scanError && !scanResult && !scanLoading && (
                        <div className="text-[#8B949E]">
                          Specimen loaded. Click &ldquo;Analyze Specimen with Gemini&rdquo; to run server-side{' '}
                          <code className="font-mono">gemini-4-argon</code> analysis.
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {!previewDataUrl && (
                  <div className="text-[#8B949E] my-auto">
                    Upload any photo or click &ldquo;Load Chamber Specimen&rdquo; to inspect structural features with{' '}
                    <code className="font-mono text-[#C9D1D9]">models/gemini-4-argon</code>.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
