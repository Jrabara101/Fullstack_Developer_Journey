import React from 'react';
import { useRoom } from '../context/RoomProvider';
import { LEVEL_BLUEPRINTS } from '../game/levels';

export const GameWorkspace: React.FC = () => {
  const {
    roomState,
    activeSlot,
    setActiveSlot,
    viewportMode,
    setViewportMode,
    pingToolActive,
    setPingToolActive,
    muted,
    toggleMute,
    dispatchAction,
  } = useRoom();

  if (roomState.status === 'LOBBY' || roomState.status === 'CONNECTING') {
    return null;
  }

  const { puzzleState, players } = roomState;
  const pA = players.find((p) => p.slot === 'A')!;
  const pB = players.find((p) => p.slot === 'B')!;

  const openDoorsCount = puzzleState.doors.filter((d) => d.isOpen).length;
  const totalDoorsCount = puzzleState.doors.length;

  return (
    <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-between p-3 md:p-5">
      {/* Top Perimeter Status Cluster (World-Matched Cyber-Mystic Palette, Zero Backdrop Blur) */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        {/* Top-Left Cluster: Room Code, Chamber Objective & Timer */}
        <div className="pointer-events-auto flex items-center gap-4 bg-[#161B22]/95 border border-[#30363D] rounded-xl px-4 py-2.5 shadow-lg">
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-[#8B949E]">
              ROOM CODE
            </div>
            <div className="text-base font-mono font-bold text-[#58A6FF] tabular-nums">
              {roomState.roomId}
            </div>
          </div>

          <div className="h-7 w-px bg-[#30363D]" />

          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-[#8B949E]">
              ELAPSED
            </div>
            <div
              data-testid="hud-timer"
              className="text-xl font-mono font-bold text-[#C9D1D9] tabular-nums"
            >
              {Math.round(roomState.timer)}s
            </div>
          </div>

          <div className="h-7 w-px bg-[#30363D]" />

          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-[#8B949E]">
              BRIDGES
            </div>
            <div
              data-testid="hud-bridges"
              className="text-xl font-mono font-bold text-[#238636] tabular-nums"
            >
              {openDoorsCount}/{totalDoorsCount}
            </div>
          </div>

          <div className="h-7 w-px bg-[#30363D] hidden sm:block" />

          <div className="hidden sm:block max-w-[260px]">
            <div className="text-xs font-semibold text-[#C9D1D9] truncate">
              {puzzleState.levelTitle}
            </div>
            <div className="text-[11px] text-[#8B949E] truncate">
              Target Lock: {puzzleState.proteinTarget.gene} ({puzzleState.proteinTarget.uniprotAccession})
            </div>
          </div>
        </div>

        {/* Top-Center Viewport Mode Switcher (Adaptive Desktop Dual / Mobile Single Chamber Feed) */}
        <div className="pointer-events-auto flex items-center gap-1 bg-[#161B22]/95 border border-[#30363D] rounded-xl p-1 shadow-lg">
          <button
            type="button"
            onClick={() => setViewportMode('CHAMBER_A')}
            className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              viewportMode === 'CHAMBER_A'
                ? 'bg-[#58A6FF] text-[#0D1117]'
                : 'text-[#C9D1D9] hover:text-[#58A6FF]'
            }`}
          >
            Chamber A (Cyan)
          </button>
          <button
            type="button"
            onClick={() => setViewportMode('DUAL')}
            className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              viewportMode === 'DUAL'
                ? 'bg-[#238636] text-white'
                : 'text-[#C9D1D9] hover:text-white'
            }`}
          >
            Dual Sync View
          </button>
          <button
            type="button"
            onClick={() => setViewportMode('CHAMBER_B')}
            className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              viewportMode === 'CHAMBER_B'
                ? 'bg-[#D29922] text-[#0D1117]'
                : 'text-[#C9D1D9] hover:text-[#D29922]'
            }`}
          >
            Chamber B (Amber)
          </button>
        </div>

        {/* Top-Right Utility Controls: Chamber Select, Ping, Mute [M], Pause [P], Reset [R] */}
        <div className="pointer-events-auto flex items-center gap-2 bg-[#161B22]/95 border border-[#30363D] rounded-xl p-1.5 shadow-lg">
          <select
            aria-label="Switch Chamber Level"
            value={puzzleState.levelIndex}
            onChange={(e) => {
              e.currentTarget.blur();
              dispatchAction({ type: 'START_GAME', levelIndex: Number(e.target.value) });
            }}
            className="px-2.5 py-1.5 rounded-lg bg-[#0D1117] border border-[#30363D] text-xs font-mono text-[#C9D1D9] focus:outline-none"
          >
            {LEVEL_BLUEPRINTS.map((bp) => (
              <option key={bp.levelIndex} value={bp.levelIndex}>
                Chamber 0{bp.levelIndex + 1}
              </option>
            ))}
          </select>

          <button
            type="button"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              setPingToolActive(!pingToolActive);
            }}
            aria-label="Toggle 3D Ping Marker Tool"
            className={`px-2.5 py-1.5 min-h-[36px] rounded-lg border text-xs font-mono font-semibold transition-colors whitespace-nowrap shrink-0 ${
              pingToolActive
                ? 'bg-[#58A6FF] border-[#58A6FF] text-[#0D1117]'
                : 'bg-[#0D1117] border-[#30363D] text-[#C9D1D9] hover:border-[#58A6FF]'
            }`}
          >
            Ping Map
          </button>

          {/* Mute [M] */}
          <button
            type="button"
            tabIndex={-1}
            aria-label={muted ? 'Unmute Audio [M]' : 'Mute Audio [M]'}
            onClick={(e) => {
              e.currentTarget.blur();
              toggleMute();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-[#0D1117] border border-[#30363D] text-[#C9D1D9] hover:border-[#58A6FF]"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2">
              <path d="M11 5L6 9H2v6h4l5 4V5z" />
              {muted ? (
                <path d="M23 9l-6 6M17 9l6 6" stroke="#F85149" />
              ) : (
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14" />
              )}
            </svg>
          </button>

          {/* Reset [R] */}
          <button
            type="button"
            tabIndex={-1}
            aria-label="Reset Chamber [R]"
            onClick={(e) => {
              e.currentTarget.blur();
              dispatchAction({ type: 'RESET_ROOM' });
            }}
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-[#0D1117] border border-[#30363D] text-[#C9D1D9] hover:border-[#D29922]"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2">
              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
              <path d="M3 3v5h5" />
            </svg>
          </button>

          {/* Pause [P] */}
          <button
            type="button"
            tabIndex={-1}
            aria-label="Pause Game [P]"
            onClick={(e) => {
              e.currentTarget.blur();
              dispatchAction({ type: 'PAUSE_GAME' });
            }}
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-[#0D1117] border border-[#30363D] text-[#C9D1D9] hover:border-[#58A6FF]"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
              <rect x="6" y="4" width="4" height="16" rx="1" />
              <rect x="14" y="4" width="4" height="16" rx="1" />
            </svg>
          </button>
        </div>
      </div>

      {/* Compact Corner Tactical Pad for Player 1 (Cyan) & Player 2 (Amber) */}
      <div className="flex items-end justify-between gap-4 mb-16 pointer-events-none">
        {/* PlayerViewportA Controls (Left Corner Cluster) */}
        <div
          data-testid="player-viewport-a"
          className={`pointer-events-auto bg-[#161B22]/95 border rounded-xl p-2.5 shadow-lg transition-colors ${
            activeSlot === 'A' ? 'border-[#58A6FF]' : 'border-[#30363D]'
          }`}
        >
          <div className="flex items-center justify-between gap-3 mb-1.5">
            <button
              type="button"
              onClick={() => setActiveSlot('A')}
              className="text-xs font-mono font-bold text-[#58A6FF] hover:underline"
            >
              P1 CYAN ({pA.x},{pA.y}) {pA.onExit ? '· ON EXIT' : ''}
            </button>
            <button
              type="button"
              aria-label="P1 Toggle Switch"
              onClick={() => dispatchAction({ type: 'INTERACT', slot: 'A' })}
              className="px-2 py-1 text-[11px] font-mono font-semibold rounded bg-[#58A6FF]/20 border border-[#58A6FF] text-[#58A6FF] hover:bg-[#58A6FF] hover:text-[#0D1117] transition-colors"
            >
              Switch [E]
            </button>
          </div>
          <div className="grid grid-cols-3 gap-1 w-[138px]">
            <div />
            <button
              type="button"
              aria-label="Move P1 North"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'A', dx: 0, dy: -1 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#58A6FF] text-xs font-mono text-[#C9D1D9]"
            >
              W
            </button>
            <div />
            <button
              type="button"
              aria-label="Move P1 West"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'A', dx: -1, dy: 0 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#58A6FF] text-xs font-mono text-[#C9D1D9]"
            >
              A
            </button>
            <button
              type="button"
              aria-label="Move P1 South"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'A', dx: 0, dy: 1 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#58A6FF] text-xs font-mono text-[#C9D1D9]"
            >
              S
            </button>
            <button
              type="button"
              aria-label="Move P1 East"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'A', dx: 1, dy: 0 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#58A6FF] text-xs font-mono text-[#C9D1D9]"
            >
              D
            </button>
          </div>
        </div>

        {/* PlayerViewportB Controls (Right Corner Cluster) */}
        <div
          data-testid="player-viewport-b"
          className={`pointer-events-auto bg-[#161B22]/95 border rounded-xl p-2.5 shadow-lg transition-colors ${
            activeSlot === 'B' ? 'border-[#D29922]' : 'border-[#30363D]'
          }`}
        >
          <div className="flex items-center justify-between gap-3 mb-1.5">
            <button
              type="button"
              onClick={() => setActiveSlot('B')}
              className="text-xs font-mono font-bold text-[#D29922] hover:underline"
            >
              P2 AMBER ({pB.x},{pB.y}) {pB.onExit ? '· ON EXIT' : ''}
            </button>
            <button
              type="button"
              aria-label="P2 Toggle Switch"
              onClick={() => dispatchAction({ type: 'INTERACT', slot: 'B' })}
              className="px-2 py-1 text-[11px] font-mono font-semibold rounded bg-[#D29922]/20 border border-[#D29922] text-[#D29922] hover:bg-[#D29922] hover:text-[#0D1117] transition-colors"
            >
              Switch [Space]
            </button>
          </div>
          <div className="grid grid-cols-3 gap-1 w-[138px]">
            <div />
            <button
              type="button"
              aria-label="Move P2 North"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'B', dx: 0, dy: -1 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#D29922] text-xs font-mono text-[#C9D1D9]"
            >
              ↑
            </button>
            <div />
            <button
              type="button"
              aria-label="Move P2 West"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'B', dx: -1, dy: 0 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#D29922] text-xs font-mono text-[#C9D1D9]"
            >
              ←
            </button>
            <button
              type="button"
              aria-label="Move P2 South"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'B', dx: 0, dy: 1 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#D29922] text-xs font-mono text-[#C9D1D9]"
            >
              ↓
            </button>
            <button
              type="button"
              aria-label="Move P2 East"
              onClick={() => dispatchAction({ type: 'MOVE_PLAYER', slot: 'B', dx: 1, dy: 0 })}
              className="h-9 rounded bg-[#0D1117] border border-[#30363D] hover:border-[#D29922] text-xs font-mono text-[#C9D1D9]"
            >
              →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
