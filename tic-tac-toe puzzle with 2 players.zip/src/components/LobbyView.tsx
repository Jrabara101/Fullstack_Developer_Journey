import React, { useState } from 'react';
import { useRoom } from '../context/RoomProvider';
import { LEVEL_BLUEPRINTS } from '../game/levels';

export const LobbyView: React.FC = () => {
  const {
    roomState,
    activeSlot,
    setActiveSlot,
    connectionStatus,
    dispatchAction,
    joinRoomByCode,
    generateNewRoomCode,
  } = useRoom();

  const [codeInput, setCodeInput] = useState(roomState.roomId);
  const [selectedLevel, setSelectedLevel] = useState(roomState.puzzleState.levelIndex);

  if (roomState.status !== 'LOBBY' && roomState.status !== 'CONNECTING') {
    return null;
  }

  const handleStart = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.currentTarget.blur();
    dispatchAction({ type: 'START_GAME', levelIndex: selectedLevel });
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!codeInput.trim()) return;
    joinRoomByCode(codeInput.trim(), activeSlot);
  };

  const handleGenerateCode = () => {
    const nextCode = generateNewRoomCode();
    setCodeInput(nextCode);
  };

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-6 md:p-10">
      {/* Asymmetric Left/Top Stage over 35%+ calm negative space */}
      <div className="w-full max-w-xl pointer-events-auto bg-[#0D1117]/92 border border-[#30363D] rounded-xl p-6 shadow-2xl">
        {/* Bespoke Inline SVG Title Emblem */}
        <div className="mb-5">
          <svg
            viewBox="0 0 520 84"
            className="w-full max-w-[440px] h-auto"
            role="img"
            aria-label="Synapse Chambers Co-Op Bio-Containment Escape"
          >
            {/* Outer tech frame */}
            <path
              d="M4 18 L20 4 H168 L182 14 H514 V66 L498 80 H4 Z"
              fill="#161B22"
              stroke="#30363D"
              strokeWidth="2"
            />
            {/* Dual Cyan & Amber conduit emblem */}
            <g transform="translate(18, 16)">
              <polygon
                points="24,2 44,14 44,38 24,50 4,38 4,14"
                fill="#0D1117"
                stroke="#58A6FF"
                strokeWidth="2.5"
              />
              <polygon
                points="38,2 58,14 58,38 38,50 18,38 18,14"
                fill="none"
                stroke="#D29922"
                strokeWidth="2.5"
              />
              <circle cx="31" cy="26" r="5" fill="#238636" />
            </g>
            {/* Custom display lockup lettering */}
            <text
              x="92"
              y="43"
              fill="#C9D1D9"
              fontFamily="Outfit, sans-serif"
              fontWeight="700"
              fontSize="28"
              letterSpacing="2"
            >
              SYNAPSE CHAMBERS
            </text>
            <text
              x="94"
              y="64"
              fill="#8B949E"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="600"
              fontSize="11.5"
              letterSpacing="1.4"
            >
              CO-OP BIO-CONTAINMENT PUZZLE ROOM
            </text>
          </svg>
        </div>

        {/* Room Code & Quick-Join Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
          <form onSubmit={handleJoinSubmit} className="flex flex-col gap-1.5">
            <label htmlFor="room-code-input" className="text-xs font-medium text-[#8B949E]">
              Room Synchronization Code
            </label>
            <div className="flex items-center gap-2">
              <input
                id="room-code-input"
                type="text"
                value={codeInput}
                onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
                maxLength={12}
                className="w-full px-3 py-2 rounded-lg bg-[#0D1117] border border-[#30363D] text-sm font-mono font-semibold text-[#C9D1D9] focus:outline-none focus:border-[#58A6FF]"
                aria-label="Room Code"
              />
              <button
                type="submit"
                className="px-3 py-2 text-xs font-semibold rounded-lg bg-[#161B22] border border-[#30363D] text-[#C9D1D9] hover:border-[#58A6FF] transition-colors whitespace-nowrap shrink-0"
              >
                Join Room
              </button>
            </div>
          </form>

          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-[#8B949E]">
              Peer Session & Control Mode
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleGenerateCode}
                className="px-3 py-2 text-xs font-semibold rounded-lg bg-[#161B22] border border-[#30363D] text-[#C9D1D9] hover:border-[#D29922] transition-colors whitespace-nowrap shrink-0"
              >
                New Room Code
              </button>
              <button
                type="button"
                onClick={() =>
                  dispatchAction({
                    type: 'SET_SPLIT_CONTROL',
                    enabled: !roomState.splitControlMode,
                  })
                }
                className={`flex-1 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                  roomState.splitControlMode
                    ? 'bg-[#58A6FF]/15 border-[#58A6FF] text-[#58A6FF]'
                    : 'bg-[#161B22] border-[#30363D] text-[#8B949E]'
                }`}
              >
                {roomState.splitControlMode ? 'Split-Control: ON' : 'Single Slot Mode'}
              </button>
            </div>
          </div>
        </div>

        {/* Dual Operative Slot Selection */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          {roomState.players.map((p) => {
            const isCyan = p.slot === 'A';
            const isSelected = activeSlot === p.slot;
            return (
              <button
                key={p.slot}
                type="button"
                onClick={() => setActiveSlot(p.slot)}
                className={`text-left p-3.5 rounded-lg border transition-transform ${
                  isSelected
                    ? isCyan
                      ? 'bg-[#161B22] border-[#58A6FF] -translate-y-0.5'
                      : 'bg-[#161B22] border-[#D29922] -translate-y-0.5'
                    : 'bg-[#0D1117]/80 border-[#30363D] hover:border-[#8B949E]'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span
                    className={`text-xs font-mono font-bold ${
                      isCyan ? 'text-[#58A6FF]' : 'text-[#D29922]'
                    }`}
                  >
                    CHAMBER {p.slot} · {isCyan ? 'CYAN' : 'AMBER'}
                  </span>
                  <span className="text-[11px] font-mono text-[#8B949E]">
                    {p.isReady ? 'READY' : 'STANDBY'}
                  </span>
                </div>
                <div className="text-sm font-semibold text-[#C9D1D9] truncate">{p.name}</div>
                <div className="text-xs text-[#8B949E] mt-1">
                  {isCyan ? 'Controls: WASD / Click Left' : 'Controls: Arrows / Click Right'}
                </div>
              </button>
            );
          })}
        </div>

        {/* Chamber Selection & Primary Start CTA */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-[#30363D]">
          <div className="flex items-center gap-2">
            <label htmlFor="chamber-select" className="text-xs text-[#8B949E] whitespace-nowrap">
              Select Chamber:
            </label>
            <select
              id="chamber-select"
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(Number(e.target.value))}
              className="px-2.5 py-2 rounded-lg bg-[#161B22] border border-[#30363D] text-xs font-medium text-[#C9D1D9] focus:outline-none focus:border-[#58A6FF]"
            >
              {LEVEL_BLUEPRINTS.map((bp) => (
                <option key={bp.levelIndex} value={bp.levelIndex}>
                  {bp.title} ({bp.proteinTarget.gene})
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            data-start="true"
            onClick={handleStart}
            className="px-6 py-2.5 rounded-lg bg-[#238636] hover:bg-[#2ea043] text-white font-semibold text-sm tracking-wide transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Enter Synchronized Chamber
          </button>
        </div>

        <div className="mt-3 flex items-center justify-between text-xs text-[#8B949E]">
          <span>
            Active Room: <strong className="font-mono text-[#C9D1D9]">{roomState.roomId}</strong>
          </span>
          <span>·</span>
          <span>
            Sync Link: {connectionStatus === 'connected' ? 'WebSocket Live' : 'Local Co-Op Sim'}
          </span>
        </div>
      </div>

      {/* Single flat borderless control-hint line in the bottom safe margin */}
      <div className="w-full text-center pointer-events-none">
        <p className="inline-block text-xs font-mono text-[#C9D1D9] bg-[#0D1117]/85 px-4 py-1.5 rounded">
          WASD Move Operative Cyan · Arrows Move Operative Amber · Space/E Toggle Switch · Click Any Tile to Step · Esc Pause
        </p>
      </div>
    </div>
  );
};
