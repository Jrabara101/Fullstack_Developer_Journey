import React from 'react';
import { useRoom } from '../context/RoomProvider';

export const VictoryModal: React.FC = () => {
  const { roomState, dispatchAction } = useRoom();

  if (roomState.status !== 'VICTORY' && roomState.status !== 'PAUSED') {
    return null;
  }

  const isVictory = roomState.status === 'VICTORY';

  return (
    <div className="fixed inset-0 z-30 bg-[#0D1117]/80 flex items-center justify-center p-4">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-status-title"
        className="w-full max-w-md bg-[#161B22] border border-[#30363D] rounded-xl p-6 shadow-2xl"
      >
        <div className="text-xs font-mono uppercase tracking-wider text-[#238636] mb-1">
          {isVictory ? 'CHAMBER SYNCHRONIZATION COMPLETE' : 'NEURAL LINK PAUSED'}
        </div>
        <h2 id="modal-status-title" className="text-2xl font-bold text-[#C9D1D9] mb-2">
          {isVictory ? roomState.puzzleState.levelTitle : 'Simulation Paused'}
        </h2>
        <p className="text-sm text-[#8B949E] mb-5">
          {isVictory
            ? 'Both operatives reached their bio-containment exit pads in synchronized lockstep.'
            : 'Chamber timer and patrol drones are suspended.'}
        </p>

        {/* 3 Tabular-Nums Mastery Metrics Tiles */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3">
            <div className="text-[11px] font-mono text-[#8B949E]">CLEAR TIME</div>
            <div className="text-xl font-mono font-bold text-[#C9D1D9] tabular-nums">
              {Math.round(roomState.timer)}s
            </div>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3">
            <div className="text-[11px] font-mono text-[#8B949E]">TOTAL MOVES</div>
            <div className="text-xl font-mono font-bold text-[#58A6FF] tabular-nums">
              {roomState.puzzleState.movesCount}
            </div>
          </div>
          <div className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3">
            <div className="text-[11px] font-mono text-[#8B949E]">SYNC SCORE</div>
            <div className="text-xl font-mono font-bold text-[#238636] tabular-nums">
              {isVictory ? roomState.lastScore : roomState.puzzleState.syncIntegrity}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => dispatchAction({ type: 'RESET_ROOM' })}
            className="px-4 py-2 rounded-lg bg-[#0D1117] border border-[#30363D] hover:border-[#8B949E] text-xs font-semibold text-[#C9D1D9]"
          >
            Restart Chamber
          </button>

          {isVictory ? (
            <button
              type="button"
              data-start="true"
              onClick={() => dispatchAction({ type: 'NEXT_LEVEL' })}
              className="px-5 py-2 rounded-lg bg-[#238636] hover:bg-[#2ea043] text-xs font-semibold text-white"
            >
              Next Chamber
            </button>
          ) : (
            <button
              type="button"
              data-start="true"
              onClick={() => dispatchAction({ type: 'RESUME_GAME' })}
              className="px-5 py-2 rounded-lg bg-[#58A6FF] hover:bg-[#79b8ff] text-xs font-semibold text-[#0D1117]"
            >
              Resume Chamber
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
