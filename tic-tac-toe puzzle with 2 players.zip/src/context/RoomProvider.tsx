import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { applyClientAction, createInitialRoomState } from '../game/engine';
import { soundEngine } from '../game/audio';
import { ClientActionPayload, SharedRoomState } from '../game/types';

interface RoomContextValue {
  roomState: SharedRoomState;
  activeSlot: 'A' | 'B';
  setActiveSlot: (slot: 'A' | 'B') => void;
  viewportMode: 'DUAL' | 'CHAMBER_A' | 'CHAMBER_B';
  setViewportMode: (mode: 'DUAL' | 'CHAMBER_A' | 'CHAMBER_B') => void;
  pingToolActive: boolean;
  setPingToolActive: (active: boolean) => void;
  connectionStatus: 'connected' | 'local_sync' | 'reconnecting';
  muted: boolean;
  toggleMute: () => void;
  dispatchAction: (action: ClientActionPayload) => void;
  joinRoomByCode: (code: string, preferredSlot?: 'A' | 'B') => void;
  generateNewRoomCode: () => string;
}

const RoomContext = createContext<RoomContextValue | null>(null);

export const RoomProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [roomState, setRoomState] = useState<SharedRoomState>(() => {
    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get('room') || 'SYNC-42';
    const autostart = params.get('autostart') === '1';
    let initial = createInitialRoomState(roomParam, 0);
    if (autostart) {
      initial = applyClientAction(initial, { type: 'START_GAME', levelIndex: 0 });
    }
    return initial;
  });

  const [activeSlot, setActiveSlot] = useState<'A' | 'B'>('A');
  const [viewportMode, setViewportMode] = useState<'DUAL' | 'CHAMBER_A' | 'CHAMBER_B'>('DUAL');
  const [pingToolActive, setPingToolActive] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'local_sync' | 'reconnecting'>('local_sync');
  const [muted, setMuted] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const roomIdRef = useRef(roomState.roomId);
  roomIdRef.current = roomState.roomId;

  // Mirror FSM to document.body.dataset.state as required by game shell guidelines
  useEffect(() => {
    if (roomState.status === 'PLAYING') {
      document.body.dataset.state = 'playing';
    } else if (roomState.status === 'PAUSED') {
      document.body.dataset.state = 'paused';
    } else if (roomState.status === 'VICTORY') {
      document.body.dataset.state = 'gameover';
    } else {
      document.body.dataset.state = 'title';
    }
  }, [roomState.status]);

  // Connect to authoritative WebSocket server on port 3000
  useEffect(() => {
    let reconnectTimer: number | undefined;
    let isUnmounted = false;

    function connectWs() {
      if (isUnmounted) return;
      try {
        const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${proto}//${window.location.host}/ws`;
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (isUnmounted) return;
          setConnectionStatus('connected');
          const params = new URLSearchParams(window.location.search);
          const autostart = params.get('autostart') === '1';
          ws.send(
            JSON.stringify({
              roomId: roomIdRef.current,
              action: autostart
                ? { type: 'START_GAME', levelIndex: 0 }
                : { type: 'JOIN_ROOM', roomId: roomIdRef.current, playerId: 'client-host', preferredSlot: 'A' },
            })
          );
        };

        ws.onmessage = (event) => {
          if (isUnmounted) return;
          try {
            const data = JSON.parse(event.data);
            if (data.type === 'ROOM_STATE_SYNC' && data.state) {
              setRoomState((prev) => {
                // Keep autostart playing state if local started first
                if (prev.status === 'PLAYING' && data.state.status === 'LOBBY' && prev.version > data.state.version) {
                  return prev;
                }
                return data.state;
              });
            }
          } catch {
            // Ignore malformed packets
          }
        };

        ws.onclose = () => {
          if (isUnmounted) return;
          setConnectionStatus('local_sync');
          reconnectTimer = window.setTimeout(connectWs, 3500);
        };

        ws.onerror = () => {
          ws.close();
        };
      } catch {
        setConnectionStatus('local_sync');
      }
    }

    connectWs();

    return () => {
      isUnmounted = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, []);

  // Local fallback 1Hz timer tick when operating in local_sync mode
  useEffect(() => {
    if (connectionStatus === 'connected') return;
    const interval = window.setInterval(() => {
      setRoomState((prev) => {
        if (prev.status !== 'PLAYING') return prev;
        return applyClientAction(prev, { type: 'TICK_TIMER', deltaSec: 1 });
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [connectionStatus]);

  const dispatchAction = useCallback((action: ClientActionPayload) => {
    // Play procedural Web Audio feedback based on action
    if (action.type === 'MOVE_PLAYER' || action.type === 'TELEPORT_CLICK') {
      soundEngine.playStep(action.slot);
    } else if (action.type === 'INTERACT' || action.type === 'VERIFY_BIO_LOCK') {
      soundEngine.playSwitch(true);
    } else if (action.type === 'SEND_PING') {
      soundEngine.playPing();
    }

    // Optimistic local state update
    setRoomState((prev) => {
      const next = applyClientAction(prev, action);
      if (prev.status !== 'VICTORY' && next.status === 'VICTORY') {
        soundEngine.playVictory();
      }
      return next;
    });

    // Send to authoritative WebSocket server if connected
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          roomId: roomIdRef.current,
          action,
        })
      );
    }
  }, []);

  const joinRoomByCode = useCallback(
    (code: string, preferredSlot: 'A' | 'B' = 'A') => {
      const clean = (code || 'SYNC-42').trim().toUpperCase();
      roomIdRef.current = clean;
      setActiveSlot(preferredSlot);
      setRoomState(createInitialRoomState(clean, 0));
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            roomId: clean,
            action: {
              type: 'JOIN_ROOM',
              roomId: clean,
              playerId: `player-${preferredSlot.toLowerCase()}`,
              preferredSlot,
            },
          })
        );
      }
    },
    []
  );

  const generateNewRoomCode = useCallback(() => {
    const prefixes = ['SYNC', 'HELIX', 'CYBER', 'QUARK', 'CODON'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const num = Math.floor(10 + Math.random() * 89);
    const newCode = `${prefix}-${num}`;
    joinRoomByCode(newCode, 'A');
    return newCode;
  }, [joinRoomByCode]);

  const toggleMute = useCallback(() => {
    const nextMuted = soundEngine.toggleMute();
    setMuted(nextMuted);
  }, []);

  // Global keyboard controls (WASD for Player A, Arrows for Player B, Space/E Interact, Esc/P Pause)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
        return;
      }

      if (roomState.status === 'LOBBY') {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          (document.activeElement as HTMLElement | null)?.blur?.();
          dispatchAction({ type: 'START_GAME', levelIndex: roomState.puzzleState.levelIndex });
        }
        return;
      }

      if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        if (roomState.status === 'PLAYING') {
          dispatchAction({ type: 'PAUSE_GAME' });
        } else if (roomState.status === 'PAUSED') {
          dispatchAction({ type: 'RESUME_GAME' });
        }
        return;
      }

      if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        toggleMute();
        return;
      }

      if (e.key === 'r' || e.key === 'R') {
        if (roomState.status === 'PLAYING' || roomState.status === 'PAUSED') {
          e.preventDefault();
          dispatchAction({ type: 'RESET_ROOM' });
        }
        return;
      }

      if (e.key === 'Tab') {
        e.preventDefault();
        setActiveSlot((prev) => (prev === 'A' ? 'B' : 'A'));
        return;
      }

      if (roomState.status !== 'PLAYING') return;

      // WASD controls Player A (or activeSlot when not in splitControlMode)
      const wasdSlot = roomState.splitControlMode ? 'A' : activeSlot;
      if (e.key === 'w' || e.key === 'W') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: wasdSlot, dx: 0, dy: -1 });
      } else if (e.key === 's' || e.key === 'S') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: wasdSlot, dx: 0, dy: 1 });
      } else if (e.key === 'a' || e.key === 'A') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: wasdSlot, dx: -1, dy: 0 });
      } else if (e.key === 'd' || e.key === 'D') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: wasdSlot, dx: 1, dy: 0 });
      }

      // Arrow keys control Player B in splitControlMode, or activeSlot otherwise
      const arrowSlot = roomState.splitControlMode ? 'B' : activeSlot;
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: arrowSlot, dx: 0, dy: -1 });
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: arrowSlot, dx: 0, dy: 1 });
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: arrowSlot, dx: -1, dy: 0 });
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        dispatchAction({ type: 'MOVE_PLAYER', slot: arrowSlot, dx: 1, dy: 0 });
      }

      if (e.key === ' ' || e.key === 'e' || e.key === 'E') {
        e.preventDefault();
        dispatchAction({ type: 'INTERACT', slot: activeSlot });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [roomState.status, roomState.splitControlMode, roomState.puzzleState.levelIndex, activeSlot, dispatchAction, toggleMute]);

  return (
    <RoomContext.Provider
      value={{
        roomState,
        activeSlot,
        setActiveSlot,
        viewportMode,
        setViewportMode,
        pingToolActive,
        setPingToolActive,
        connectionStatus,
        muted,
        toggleMute,
        dispatchAction,
        joinRoomByCode,
        generateNewRoomCode,
      }}
    >
      {children}
    </RoomContext.Provider>
  );
};

export function useRoom() {
  const ctx = useContext(RoomContext);
  if (!ctx) throw new Error('useRoom must be used within a RoomProvider');
  return ctx;
}
