import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyClientAction,
  calculateChamberScore,
  createInitialRoomState,
  isCellWalkable,
} from './engine';

test('initial room state boots in LOBBY with 2 cooperative operatives and closed bridges', () => {
  const room = createInitialRoomState('TEST-01', 0);
  assert.equal(room.roomId, 'TEST-01');
  assert.equal(room.status, 'LOBBY');
  assert.equal(room.players.length, 2);
  assert.equal(room.puzzleState.doors.every((d) => !d.isOpen), true);
  // Closed bridge at (3, 4) should not be walkable initially
  assert.equal(isCellWalkable(room.puzzleState, 3, 4), false);
});

test('cooperative switch in Chamber A unlocks bridge and gate in Chamber B', () => {
  let room = createInitialRoomState('TEST-02', 0);
  room = applyClientAction(room, { type: 'START_GAME', levelIndex: 0 });
  assert.equal(room.status, 'PLAYING');

  // Player A starts at (1, 2). Relay S1 is at (3, 2).
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 1, dy: 0 }); // (2, 2)
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 1, dy: 0 }); // (3, 2) -> steps on sw-alpha

  const swAlpha = room.puzzleState.switches.find((s) => s.id === 'sw-alpha');
  assert.equal(swAlpha?.state, true);

  const bridgeBeta = room.puzzleState.doors.find((d) => d.id === 'bridge-beta');
  const doorBeta = room.puzzleState.doors.find((d) => d.id === 'door-beta');
  assert.equal(bridgeBeta?.isOpen, true);
  assert.equal(doorBeta?.isOpen, true);
  assert.equal(isCellWalkable(room.puzzleState, 9, 4), true);
});

test('full cooperative walkthrough reaches VICTORY when both players stand on exit pads', () => {
  let room = createInitialRoomState('TEST-03', 0);
  room = applyClientAction(room, { type: 'START_GAME', levelIndex: 0 });

  // Player A (1,2) -> (3,2) to activate sw-alpha (opens B bridge at 9,4 & door at 9,3)
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 1, dy: 0 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 1, dy: 0 });

  // Player B (7,5) -> (8,5) to activate sw-beta (opens A bridge at 3,4 & door at 3,5)
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'B', dx: 1, dy: 0 });

  // Move Player A from (3,2) -> (3,3) -> (3,4) -> (3,5) -> (3,6) -> (4,6) [Exit A]
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 0, dy: 1 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 0, dy: 1 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 0, dy: 1 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 0, dy: 1 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'A', dx: 1, dy: 0 });
  assert.equal(room.players[0].onExit, true);
  assert.equal(room.status, 'PLAYING'); // Still playing until Player B also reaches Exit B

  // Move Player B from (8,5) -> (9,5) -> (9,4) -> (9,3) -> (9,2) -> (10,2) [Exit B]
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'B', dx: 1, dy: 0 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'B', dx: 0, dy: -1 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'B', dx: 0, dy: -1 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'B', dx: 0, dy: -1 });
  room = applyClientAction(room, { type: 'MOVE_PLAYER', slot: 'B', dx: 1, dy: 0 });

  assert.equal(room.players[1].onExit, true);
  assert.equal(room.status, 'VICTORY');
  assert.equal(room.lastScore > 1000, true);
});

test('AlphaFold bio-lock verification opens all chamber bridges and gates', () => {
  let room = createInitialRoomState('TEST-04', 0);
  room = applyClientAction(room, { type: 'START_GAME', levelIndex: 0 });
  room = applyClientAction(room, {
    type: 'VERIFY_BIO_LOCK',
    uniprotAccession: 'P04637',
    meanPlddt: 86.4,
  });

  assert.equal(room.puzzleState.bioLockVerified, true);
  assert.equal(room.puzzleState.doors.every((d) => d.isOpen), true);
  assert.equal(calculateChamberScore(25, 10, 100) > 1500, true);
});
