import { buildPuzzleStateFromBlueprint, LEVEL_BLUEPRINTS } from './levels';
import {
  ClientActionPayload,
  PingMarker,
  PlayerActor,
  PuzzleState,
  SharedRoomState,
} from './types';

export function createInitialPlayers(levelIndex = 0): PlayerActor[] {
  const safeIndex = ((levelIndex % LEVEL_BLUEPRINTS.length) + LEVEL_BLUEPRINTS.length) % LEVEL_BLUEPRINTS.length;
  const bp = LEVEL_BLUEPRINTS[safeIndex];
  return [
    {
      id: 'player-a',
      role: 'host',
      slot: 'A',
      name: 'Operative Cyan (P1)',
      color: '#58A6FF',
      isReady: true,
      x: bp.spawnA.x,
      y: bp.spawnA.y,
      facing: bp.spawnA.facing,
      hp: 3,
      maxHp: 3,
      moves: 0,
      onExit: false,
      lastActionAt: Date.now(),
    },
    {
      id: 'player-b',
      role: 'guest',
      slot: 'B',
      name: 'Operative Amber (P2)',
      color: '#D29922',
      isReady: true,
      x: bp.spawnB.x,
      y: bp.spawnB.y,
      facing: bp.spawnB.facing,
      hp: 3,
      maxHp: 3,
      moves: 0,
      onExit: false,
      lastActionAt: Date.now(),
    },
  ];
}

export function createInitialRoomState(roomId = 'SYNC-42', levelIndex = 0): SharedRoomState {
  return {
    roomId: roomId.toUpperCase(),
    status: 'LOBBY',
    splitControlMode: true,
    players: createInitialPlayers(levelIndex),
    puzzleState: buildPuzzleStateFromBlueprint(levelIndex),
    pings: [],
    messages: [
      {
        id: 'sys-init',
        senderSlot: 'SYSTEM',
        senderName: 'CHAMBER CORE',
        text: 'Dual-chamber neural link online. Toggle switches or verify AlphaFold protein lock to open partner bridges.',
        timestamp: Date.now(),
      },
    ],
    timer: 0,
    startedAt: null,
    completedAt: null,
    bestScore: 0,
    lastScore: 0,
    version: 1,
  };
}

export function isCellWalkable(puzzle: PuzzleState, x: number, y: number): boolean {
  if (y < 0 || y >= puzzle.height || x < 0 || x >= puzzle.width) {
    return false;
  }
  const cell = puzzle.grid[y][x];
  if (!cell) return false;

  if (cell.type === 'wall' || cell.type === 'chasm') {
    return false;
  }

  if (cell.type === 'bridge' || cell.type === 'door') {
    const door = puzzle.doors.find((d) => d.id === cell.entityId || (d.x === x && d.y === y));
    if (door && !door.isOpen) {
      return false;
    }
  }

  return true;
}

export function recomputeDoorsAndVictory(state: SharedRoomState): SharedRoomState {
  const puzzle = state.puzzleState;
  const switchMap = new Map<string, boolean>();
  for (const sw of puzzle.switches) {
    switchMap.set(sw.id, sw.state);
  }

  for (const door of puzzle.doors) {
    if (puzzle.bioLockVerified) {
      door.isOpen = true;
    } else {
      door.isOpen = door.requiredSwitchIds.every((reqId) => switchMap.get(reqId) === true);
    }
  }

  const bp = LEVEL_BLUEPRINTS[puzzle.levelIndex] || LEVEL_BLUEPRINTS[0];
  for (const p of state.players) {
    const targetExit = p.slot === 'A' ? bp.exitA : bp.exitB;
    p.onExit = p.x === targetExit.x && p.y === targetExit.y;
  }

  const allOnExit = state.players.length >= 2 && state.players.every((p) => p.onExit);
  if (allOnExit && state.status === 'PLAYING') {
    state.status = 'VICTORY';
    state.completedAt = Date.now();
    const score = calculateChamberScore(state.timer, puzzle.movesCount, puzzle.syncIntegrity);
    state.lastScore = score;
    state.bestScore = Math.max(state.bestScore, score);
    state.messages = [
      ...state.messages.slice(-19),
      {
        id: `victory-${Date.now()}`,
        senderSlot: 'SYSTEM',
        senderName: 'CHAMBER CORE',
        text: `${puzzle.levelTitle} cleared in ${Math.round(state.timer)}s with ${puzzle.movesCount} moves! Score: ${score}`,
        timestamp: Date.now(),
      },
    ];
  }

  return state;
}

export function calculateChamberScore(timerSec: number, moves: number, syncIntegrity: number): number {
  const timeBonus = Math.max(0, 600 - Math.floor(timerSec) * 4);
  const moveBonus = Math.max(0, 400 - moves * 5);
  const integrityFactor = Math.max(10, Math.min(100, syncIntegrity)) / 100;
  return Math.round((1000 + timeBonus + moveBonus) * integrityFactor);
}

export function applyClientAction(current: SharedRoomState, action: ClientActionPayload): SharedRoomState {
  const next: SharedRoomState = structuredClone(current);
  next.version += 1;

  switch (action.type) {
    case 'JOIN_ROOM': {
      const targetSlot = action.preferredSlot || 'A';
      const player = next.players.find((p) => p.slot === targetSlot);
      if (player) {
        player.id = action.playerId;
        if (action.name) player.name = action.name;
        player.isReady = true;
      }
      return next;
    }

    case 'TOGGLE_READY': {
      const player = next.players.find((p) => p.id === action.playerId) || next.players[0];
      if (player) {
        player.isReady = !player.isReady;
      }
      return next;
    }

    case 'SET_SPLIT_CONTROL': {
      next.splitControlMode = action.enabled;
      return next;
    }

    case 'START_GAME': {
      const lvl = typeof action.levelIndex === 'number' ? action.levelIndex : next.puzzleState.levelIndex;
      next.puzzleState = buildPuzzleStateFromBlueprint(lvl);
      next.players = createInitialPlayers(lvl);
      next.status = 'PLAYING';
      next.timer = 0;
      next.startedAt = Date.now();
      next.completedAt = null;
      return recomputeDoorsAndVictory(next);
    }

    case 'PAUSE_GAME': {
      if (next.status === 'PLAYING') {
        next.status = 'PAUSED';
      }
      return next;
    }

    case 'RESUME_GAME': {
      if (next.status === 'PAUSED') {
        next.status = 'PLAYING';
      }
      return next;
    }

    case 'RESET_ROOM': {
      const lvl = typeof action.levelIndex === 'number' ? action.levelIndex : next.puzzleState.levelIndex;
      next.puzzleState = buildPuzzleStateFromBlueprint(lvl);
      next.players = createInitialPlayers(lvl);
      next.status = 'PLAYING';
      next.timer = 0;
      next.startedAt = Date.now();
      next.completedAt = null;
      next.pings = [];
      return recomputeDoorsAndVictory(next);
    }

    case 'NEXT_LEVEL': {
      const nextLvl = (next.puzzleState.levelIndex + 1) % LEVEL_BLUEPRINTS.length;
      next.puzzleState = buildPuzzleStateFromBlueprint(nextLvl);
      next.players = createInitialPlayers(nextLvl);
      next.status = 'PLAYING';
      next.timer = 0;
      next.startedAt = Date.now();
      next.completedAt = null;
      next.pings = [];
      return recomputeDoorsAndVictory(next);
    }

    case 'MOVE_PLAYER': {
      if (next.status !== 'PLAYING') return next;
      const player = next.players.find((p) => p.slot === action.slot);
      if (!player) return next;

      const dx = Math.sign(action.dx);
      const dy = Math.sign(action.dy);
      if (dx === 0 && dy === 0) return next;

      if (dx > 0) player.facing = 'E';
      else if (dx < 0) player.facing = 'W';
      else if (dy > 0) player.facing = 'S';
      else if (dy < 0) player.facing = 'N';

      const targetX = player.x + dx;
      const targetY = player.y + dy;

      if (!isCellWalkable(next.puzzleState, targetX, targetY)) {
        return next;
      }

      player.x = targetX;
      player.y = targetY;
      player.moves += 1;
      player.lastActionAt = Date.now();
      next.puzzleState.movesCount += 1;

      // Stepping directly onto a switch automatically toggles it for smooth feel
      const steppedSwitch = next.puzzleState.switches.find(
        (sw) => sw.x === targetX && sw.y === targetY
      );
      if (steppedSwitch) {
        steppedSwitch.state = !steppedSwitch.state;
        next.messages = [
          ...next.messages.slice(-19),
          {
            id: `sw-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            senderSlot: player.slot,
            senderName: player.name,
            text: `${steppedSwitch.state ? 'Activated' : 'Deactivated'} ${steppedSwitch.label}`,
            timestamp: Date.now(),
          },
        ];
      }

      return recomputeDoorsAndVictory(next);
    }

    case 'TELEPORT_CLICK': {
      if (next.status !== 'PLAYING') return next;
      const player = next.players.find((p) => p.slot === action.slot);
      if (!player) return next;

      // Move 1 step toward clicked tile or directly if adjacent/reachable in chamber
      const dx = Math.sign(action.targetX - player.x);
      const dy = Math.sign(action.targetY - player.y);
      if (dx !== 0 && isCellWalkable(next.puzzleState, player.x + dx, player.y)) {
        return applyClientAction(current, { type: 'MOVE_PLAYER', slot: action.slot, dx, dy: 0 });
      }
      if (dy !== 0 && isCellWalkable(next.puzzleState, player.x, player.y + dy)) {
        return applyClientAction(current, { type: 'MOVE_PLAYER', slot: action.slot, dx: 0, dy });
      }
      return next;
    }

    case 'INTERACT': {
      if (next.status !== 'PLAYING') return next;
      const player = next.players.find((p) => p.slot === action.slot);
      if (!player) return next;

      // Toggle switch on current tile or Manhattan distance <= 1 in same chamber
      const nearbySwitch = next.puzzleState.switches.find(
        (sw) =>
          sw.chamber === player.slot &&
          Math.abs(sw.x - player.x) + Math.abs(sw.y - player.y) <= 1
      );
      if (nearbySwitch) {
        nearbySwitch.state = !nearbySwitch.state;
        player.lastActionAt = Date.now();
        next.messages = [
          ...next.messages.slice(-19),
          {
            id: `int-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            senderSlot: player.slot,
            senderName: player.name,
            text: `${nearbySwitch.state ? 'Engaged' : 'Disengaged'} ${nearbySwitch.label}`,
            timestamp: Date.now(),
          },
        ];
      }
      return recomputeDoorsAndVictory(next);
    }

    case 'VERIFY_BIO_LOCK': {
      next.puzzleState.bioLockVerified = true;
      for (const sw of next.puzzleState.switches) {
        if (!sw.uniprotAccession || sw.uniprotAccession === action.uniprotAccession) {
          sw.state = true;
        }
      }
      next.messages = [
        ...next.messages.slice(-19),
        {
          id: `bio-${Date.now()}`,
          senderSlot: 'SYSTEM',
          senderName: 'ALPHAFOLD BIO-LOCK',
          text: `Protein structure ${action.uniprotAccession} verified (mean pLDDT ${action.meanPlddt.toFixed(1)}). All chamber bridges unlocked!`,
          timestamp: Date.now(),
        },
      ];
      return recomputeDoorsAndVictory(next);
    }

    case 'SEND_PING': {
      const marker: PingMarker = {
        id: `ping-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        playerId: `player-${action.slot.toLowerCase()}`,
        slot: action.slot,
        x: action.x,
        y: action.y,
        kind: action.kind,
        label: action.label,
        createdAt: Date.now(),
      };
      next.pings = [...next.pings.slice(-5), marker];
      return next;
    }

    case 'SEND_CHAT': {
      const sender = next.players.find((p) => p.slot === action.slot);
      next.messages = [
        ...next.messages.slice(-19),
        {
          id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          senderSlot: action.slot,
          senderName: sender ? sender.name : `Operative ${action.slot}`,
          text: action.text.trim().slice(0, 160),
          isEmote: action.isEmote,
          timestamp: Date.now(),
        },
      ];
      return next;
    }

    case 'TICK_TIMER': {
      if (next.status !== 'PLAYING') return next;
      const dt = Math.max(0, Math.min(action.deltaSec, 1));
      next.timer = Number((next.timer + dt).toFixed(2));
      // Expire pings older than 8 seconds
      const cutoff = Date.now() - 8000;
      next.pings = next.pings.filter((p) => p.createdAt >= cutoff);

      // Advance hazard drone patrol & windup telegraphs
      const switchMap = new Map(next.puzzleState.switches.map((s) => [s.id, s.state]));
      for (const h of next.puzzleState.hazards) {
        if (h.disabledBySwitchId && switchMap.get(h.disabledBySwitchId)) {
          h.activePulse = false;
          h.windupTimer = 0;
          continue;
        }
        h.phase += dt * 1.25;
        const t = (Math.sin(h.phase) + 1) * 0.5;
        h.x = Math.round(h.startX + (h.endX - h.startX) * t);
        h.y = Math.round(h.startY + (h.endY - h.startY) * t);
        h.windupTimer = (h.phase % 2.4) / 2.4;
        h.activePulse = h.windupTimer > 0.78;

        if (h.activePulse) {
          for (const p of next.players) {
            if (p.slot === h.chamber && p.x === h.x && p.y === h.y) {
              next.puzzleState.syncIntegrity = Math.max(20, next.puzzleState.syncIntegrity - 5);
            }
          }
        }
      }
      return next;
    }

    default:
      return next;
  }
}
