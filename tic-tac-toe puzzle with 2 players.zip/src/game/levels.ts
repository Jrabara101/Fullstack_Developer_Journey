import { Cell, DoorEntity, HazardDrone, PuzzleState, SwitchEntity } from './types';

export interface LevelBlueprint {
  levelIndex: number;
  title: string;
  subtitle: string;
  proteinTarget: {
    gene: string;
    uniprotAccession: string;
    pdbId: string;
    clueText: string;
  };
  width: number;
  height: number;
  spawnA: { x: number; y: number; facing: 'N' | 'S' | 'E' | 'W' };
  spawnB: { x: number; y: number; facing: 'N' | 'S' | 'E' | 'W' };
  exitA: { x: number; y: number };
  exitB: { x: number; y: number };
  walls: Array<{ x: number; y: number }>;
  chasms: Array<{ x: number; y: number }>;
  bioTerminals: Array<{ x: number; y: number; chamber: 'A' | 'B' }>;
  switches: SwitchEntity[];
  doors: DoorEntity[];
  hazards: HazardDrone[];
}

export const LEVEL_BLUEPRINTS: LevelBlueprint[] = [
  {
    levelIndex: 0,
    title: 'Chamber 01 · Dual Conduit Awakening',
    subtitle: 'Synchronize cross-chamber relays so both operatives cross the plasma chasm.',
    proteinTarget: {
      gene: 'TP53',
      uniprotAccession: 'P04637',
      pdbId: '1TUP',
      clueText: 'Guardian of the Genome: Verify p53 DNA-binding core stability (P04637) or trigger both conduit relays.'
    },
    width: 12,
    height: 8,
    spawnA: { x: 1, y: 2, facing: 'E' },
    spawnB: { x: 7, y: 5, facing: 'E' },
    exitA: { x: 4, y: 6 },
    exitB: { x: 10, y: 2 },
    // Center divider at x=5..6 separates Chamber A (x: 0..5) and Chamber B (x: 6..11)
    walls: [
      // Perimeter walls
      ...Array.from({ length: 12 }, (_, x) => ({ x, y: 0 })),
      ...Array.from({ length: 12 }, (_, x) => ({ x, y: 7 })),
      ...Array.from({ length: 8 }, (_, y) => ({ x: 0, y })),
      ...Array.from({ length: 8 }, (_, y) => ({ x: 11, y })),
      // Central glass-conduit partition at x=5 and x=6 with energy windows
      { x: 5, y: 1 }, { x: 5, y: 2 }, { x: 5, y: 3 }, { x: 5, y: 4 }, { x: 5, y: 5 }, { x: 5, y: 6 },
      { x: 6, y: 1 }, { x: 6, y: 2 }, { x: 6, y: 5 }, { x: 6, y: 6 },
    ],
    chasms: [
      // Chasm across lower Chamber A (y=4, x=1..4) except bridge at (3,4)
      { x: 1, y: 4 }, { x: 2, y: 4 }, { x: 4, y: 4 },
      // Chasm across upper Chamber B (y=4, x=7..10) except bridge at (9,4)
      { x: 7, y: 4 }, { x: 8, y: 4 }, { x: 10, y: 4 },
    ],
    bioTerminals: [
      { x: 2, y: 1, chamber: 'A' },
      { x: 9, y: 6, chamber: 'B' },
    ],
    switches: [
      {
        id: 'sw-alpha',
        label: 'Relay S1 (Unlocks B Bridge)',
        x: 3,
        y: 2,
        chamber: 'A',
        kind: 'toggle',
        state: false,
        targetIds: ['bridge-beta', 'door-beta'],
        uniprotAccession: 'P04637',
      },
      {
        id: 'sw-beta',
        label: 'Relay S2 (Unlocks A Bridge)',
        x: 8,
        y: 5,
        chamber: 'B',
        kind: 'toggle',
        state: false,
        targetIds: ['bridge-alpha', 'door-alpha'],
        uniprotAccession: 'P04637',
      },
    ],
    doors: [
      {
        id: 'bridge-alpha',
        label: 'Hardlight Bridge A1',
        x: 3,
        y: 4,
        chamber: 'A',
        kind: 'bridge',
        isOpen: false,
        requiredSwitchIds: ['sw-beta'],
      },
      {
        id: 'door-alpha',
        label: 'Containment Gate A2',
        x: 3,
        y: 5,
        chamber: 'A',
        kind: 'door',
        isOpen: false,
        requiredSwitchIds: ['sw-beta'],
      },
      {
        id: 'bridge-beta',
        label: 'Hardlight Bridge B1',
        x: 9,
        y: 4,
        chamber: 'B',
        kind: 'bridge',
        isOpen: false,
        requiredSwitchIds: ['sw-alpha'],
      },
      {
        id: 'door-beta',
        label: 'Containment Gate B2',
        x: 9,
        y: 3,
        chamber: 'B',
        kind: 'door',
        isOpen: false,
        requiredSwitchIds: ['sw-alpha'],
      },
    ],
    hazards: [
      {
        id: 'haz-1',
        chamber: 'A',
        archetype: 'patrol_sweeper',
        x: 1,
        y: 5,
        startX: 1,
        startY: 5,
        endX: 2,
        endY: 6,
        phase: 0,
        windupTimer: 0,
        activePulse: false,
        disabledBySwitchId: 'sw-alpha',
      },
      {
        id: 'haz-2',
        chamber: 'B',
        archetype: 'orbital_sentinel',
        x: 8,
        y: 2,
        startX: 7,
        startY: 2,
        endX: 8,
        endY: 3,
        phase: 1.5,
        windupTimer: 0,
        activePulse: false,
        disabledBySwitchId: 'sw-beta',
      },
    ],
  },
  {
    levelIndex: 1,
    title: 'Chamber 02 · Allosteric Cascade',
    subtitle: 'Chain three cross-linked bio-switches to lower the multi-lock laser array.',
    proteinTarget: {
      gene: 'EGFR',
      uniprotAccession: 'P00533',
      pdbId: '1M17',
      clueText: 'Receptor Tyrosine Kinase Dimerization: Synchronize all three allosteric nodes (P00533).'
    },
    width: 12,
    height: 8,
    spawnA: { x: 1, y: 1, facing: 'S' },
    spawnB: { x: 10, y: 6, facing: 'N' },
    exitA: { x: 4, y: 6 },
    exitB: { x: 7, y: 1 },
    walls: [
      ...Array.from({ length: 12 }, (_, x) => ({ x, y: 0 })),
      ...Array.from({ length: 12 }, (_, x) => ({ x, y: 7 })),
      ...Array.from({ length: 8 }, (_, y) => ({ x: 0, y })),
      ...Array.from({ length: 8 }, (_, y) => ({ x: 11, y })),
      { x: 5, y: 1 }, { x: 5, y: 2 }, { x: 5, y: 3 }, { x: 5, y: 4 }, { x: 5, y: 5 }, { x: 5, y: 6 },
      { x: 6, y: 1 }, { x: 6, y: 2 }, { x: 6, y: 3 }, { x: 6, y: 4 }, { x: 6, y: 5 }, { x: 6, y: 6 },
    ],
    chasms: [
      { x: 1, y: 3 }, { x: 3, y: 3 }, { x: 4, y: 3 },
      { x: 7, y: 4 }, { x: 8, y: 4 }, { x: 10, y: 4 },
    ],
    bioTerminals: [
      { x: 4, y: 1, chamber: 'A' },
      { x: 7, y: 6, chamber: 'B' },
    ],
    switches: [
      {
        id: 'sw-c2-a1',
        label: 'Kinase Node A1',
        x: 2,
        y: 2,
        chamber: 'A',
        kind: 'toggle',
        state: false,
        targetIds: ['bridge-c2-b1'],
        uniprotAccession: 'P00533',
      },
      {
        id: 'sw-c2-b1',
        label: 'Dimer Node B1',
        x: 9,
        y: 5,
        chamber: 'B',
        kind: 'toggle',
        state: false,
        targetIds: ['bridge-c2-a1'],
        uniprotAccession: 'P00533',
      },
      {
        id: 'sw-c2-a2',
        label: 'Catalytic Lock A2',
        x: 2,
        y: 5,
        chamber: 'A',
        kind: 'toggle',
        state: false,
        targetIds: ['gate-c2-b2', 'gate-c2-a2'],
        uniprotAccession: 'P00533',
      },
    ],
    doors: [
      {
        id: 'bridge-c2-a1',
        label: 'Photon Bridge A',
        x: 2,
        y: 3,
        chamber: 'A',
        kind: 'bridge',
        isOpen: false,
        requiredSwitchIds: ['sw-c2-b1'],
      },
      {
        id: 'bridge-c2-b1',
        label: 'Photon Bridge B',
        x: 9,
        y: 4,
        chamber: 'B',
        kind: 'bridge',
        isOpen: false,
        requiredSwitchIds: ['sw-c2-a1'],
      },
      {
        id: 'gate-c2-a2',
        label: 'Laser Gate A',
        x: 3,
        y: 6,
        chamber: 'A',
        kind: 'laser_gate',
        isOpen: false,
        requiredSwitchIds: ['sw-c2-a2', 'sw-c2-b1'],
      },
      {
        id: 'gate-c2-b2',
        label: 'Laser Gate B',
        x: 8,
        y: 2,
        chamber: 'B',
        kind: 'laser_gate',
        isOpen: false,
        requiredSwitchIds: ['sw-c2-a1', 'sw-c2-a2'],
      },
    ],
    hazards: [
      {
        id: 'haz-c2-1',
        chamber: 'A',
        archetype: 'phase_emitter',
        x: 3,
        y: 4,
        startX: 1,
        startY: 4,
        endX: 4,
        endY: 4,
        phase: 0.5,
        windupTimer: 0,
        activePulse: false,
        disabledBySwitchId: 'sw-c2-a2',
      },
      {
        id: 'haz-c2-2',
        chamber: 'B',
        archetype: 'patrol_sweeper',
        x: 9,
        y: 2,
        startX: 7,
        startY: 2,
        endX: 10,
        endY: 2,
        phase: 2.1,
        windupTimer: 0,
        activePulse: false,
        disabledBySwitchId: 'sw-c2-b1',
      },
    ],
  },
  {
    levelIndex: 2,
    title: 'Chamber 03 · Hemoglobin Tetramer Vault',
    subtitle: 'Coordinate oxygen-binding cooperative states across four linked locks.',
    proteinTarget: {
      gene: 'HBB',
      uniprotAccession: 'P68871',
      pdbId: '4HHB',
      clueText: 'Bohr Effect & Cooperative Binding: Activate Heme Subunits Alpha & Beta (P68871) in unison.'
    },
    width: 12,
    height: 8,
    spawnA: { x: 1, y: 6, facing: 'N' },
    spawnB: { x: 10, y: 6, facing: 'N' },
    exitA: { x: 2, y: 1 },
    exitB: { x: 9, y: 1 },
    walls: [
      ...Array.from({ length: 12 }, (_, x) => ({ x, y: 0 })),
      ...Array.from({ length: 12 }, (_, x) => ({ x, y: 7 })),
      ...Array.from({ length: 8 }, (_, y) => ({ x: 0, y })),
      ...Array.from({ length: 8 }, (_, y) => ({ x: 11, y })),
      { x: 5, y: 1 }, { x: 5, y: 2 }, { x: 5, y: 4 }, { x: 5, y: 5 }, { x: 5, y: 6 },
      { x: 6, y: 1 }, { x: 6, y: 2 }, { x: 6, y: 4 }, { x: 6, y: 5 }, { x: 6, y: 6 },
    ],
    chasms: [
      { x: 1, y: 3 }, { x: 2, y: 3 }, { x: 4, y: 3 },
      { x: 7, y: 3 }, { x: 9, y: 3 }, { x: 10, y: 3 },
    ],
    bioTerminals: [
      { x: 4, y: 6, chamber: 'A' },
      { x: 7, y: 6, chamber: 'B' },
    ],
    switches: [
      {
        id: 'sw-c3-a1',
        label: 'Heme Alpha-1',
        x: 2,
        y: 5,
        chamber: 'A',
        kind: 'toggle',
        state: false,
        targetIds: ['bridge-c3-b'],
        uniprotAccession: 'P68871',
      },
      {
        id: 'sw-c3-b1',
        label: 'Heme Beta-1',
        x: 9,
        y: 5,
        chamber: 'B',
        kind: 'toggle',
        state: false,
        targetIds: ['bridge-c3-a'],
        uniprotAccession: 'P68871',
      },
      {
        id: 'sw-c3-a2',
        label: 'Heme Alpha-2',
        x: 4,
        y: 2,
        chamber: 'A',
        kind: 'toggle',
        state: false,
        targetIds: ['door-c3-b'],
        uniprotAccession: 'P68871',
      },
      {
        id: 'sw-c3-b2',
        label: 'Heme Beta-2',
        x: 7,
        y: 2,
        chamber: 'B',
        kind: 'toggle',
        state: false,
        targetIds: ['door-c3-a'],
        uniprotAccession: 'P68871',
      },
    ],
    doors: [
      {
        id: 'bridge-c3-a',
        label: 'Subunit Bridge A',
        x: 3,
        y: 3,
        chamber: 'A',
        kind: 'bridge',
        isOpen: false,
        requiredSwitchIds: ['sw-c3-b1'],
      },
      {
        id: 'bridge-c3-b',
        label: 'Subunit Bridge B',
        x: 8,
        y: 3,
        chamber: 'B',
        kind: 'bridge',
        isOpen: false,
        requiredSwitchIds: ['sw-c3-a1'],
      },
      {
        id: 'door-c3-a',
        label: 'Vault Lock A',
        x: 3,
        y: 1,
        chamber: 'A',
        kind: 'door',
        isOpen: false,
        requiredSwitchIds: ['sw-c3-b2'],
      },
      {
        id: 'door-c3-b',
        label: 'Vault Lock B',
        x: 8,
        y: 1,
        chamber: 'B',
        kind: 'door',
        isOpen: false,
        requiredSwitchIds: ['sw-c3-a2'],
      },
    ],
    hazards: [
      {
        id: 'haz-c3-1',
        chamber: 'A',
        archetype: 'orbital_sentinel',
        x: 2,
        y: 2,
        startX: 1,
        startY: 2,
        endX: 3,
        endY: 2,
        phase: 0,
        windupTimer: 0,
        activePulse: false,
        disabledBySwitchId: 'sw-c3-a2',
      },
      {
        id: 'haz-c3-2',
        chamber: 'B',
        archetype: 'phase_emitter',
        x: 9,
        y: 2,
        startX: 8,
        startY: 2,
        endX: 10,
        endY: 2,
        phase: 1.2,
        windupTimer: 0,
        activePulse: false,
        disabledBySwitchId: 'sw-c3-b2',
      },
    ],
  },
];

export function buildPuzzleStateFromBlueprint(levelIndex = 0): PuzzleState {
  const safeIndex = ((levelIndex % LEVEL_BLUEPRINTS.length) + LEVEL_BLUEPRINTS.length) % LEVEL_BLUEPRINTS.length;
  const bp = LEVEL_BLUEPRINTS[safeIndex];
  const grid: Cell[][] = [];

  for (let y = 0; y < bp.height; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < bp.width; x++) {
      const chamber: 'A' | 'B' | 'SHARED' = x < 5 ? 'A' : x > 6 ? 'B' : 'SHARED';
      row.push({
        x,
        y,
        chamber,
        type: 'floor',
      });
    }
    grid.push(row);
  }

  for (const w of bp.walls) {
    if (grid[w.y]?.[w.x]) {
      grid[w.y][w.x].type = 'wall';
    }
  }

  for (const c of bp.chasms) {
    if (grid[c.y]?.[c.x]) {
      grid[c.y][c.x].type = 'chasm';
    }
  }

  for (const bt of bp.bioTerminals) {
    if (grid[bt.y]?.[bt.x]) {
      grid[bt.y][bt.x].type = 'bio_terminal';
      grid[bt.y][bt.x].owner = bt.chamber;
      grid[bt.y][bt.x].label = 'Bio-Lock Terminal';
    }
  }

  for (const sw of bp.switches) {
    if (grid[sw.y]?.[sw.x]) {
      grid[sw.y][sw.x].type = 'switch';
      grid[sw.y][sw.x].entityId = sw.id;
      grid[sw.y][sw.x].owner = sw.chamber;
      grid[sw.y][sw.x].label = sw.label;
    }
  }

  for (const d of bp.doors) {
    if (grid[d.y]?.[d.x]) {
      grid[d.y][d.x].type = d.kind === 'bridge' ? 'bridge' : 'door';
      grid[d.y][d.x].entityId = d.id;
      grid[d.y][d.x].owner = d.chamber;
      grid[d.y][d.x].label = d.label;
    }
  }

  if (grid[bp.exitA.y]?.[bp.exitA.x]) {
    grid[bp.exitA.y][bp.exitA.x].type = 'exit';
    grid[bp.exitA.y][bp.exitA.x].owner = 'A';
    grid[bp.exitA.y][bp.exitA.x].label = 'Exit Pad A';
  }

  if (grid[bp.exitB.y]?.[bp.exitB.x]) {
    grid[bp.exitB.y][bp.exitB.x].type = 'exit';
    grid[bp.exitB.y][bp.exitB.x].owner = 'B';
    grid[bp.exitB.y][bp.exitB.x].label = 'Exit Pad B';
  }

  return {
    levelIndex: safeIndex,
    levelTitle: bp.title,
    levelSubtitle: bp.subtitle,
    proteinTarget: { ...bp.proteinTarget },
    width: bp.width,
    height: bp.height,
    grid,
    switches: bp.switches.map((s) => ({ ...s, targetIds: [...s.targetIds] })),
    doors: bp.doors.map((d) => ({ ...d, requiredSwitchIds: [...d.requiredSwitchIds] })),
    hazards: bp.hazards.map((h) => ({ ...h })),
    syncIntegrity: 100,
    movesCount: 0,
    bioLockVerified: false,
  };
}
