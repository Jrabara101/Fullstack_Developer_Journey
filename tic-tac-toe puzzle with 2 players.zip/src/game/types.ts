export type RoomLifecycleStatus = 'LOBBY' | 'CONNECTING' | 'PLAYING' | 'PAUSED' | 'VICTORY' | 'RESETTING';

export type PlayerRole = 'host' | 'guest';

export type CellType =
  | 'floor'
  | 'wall'
  | 'chasm'
  | 'bridge'
  | 'switch'
  | 'pressure_plate'
  | 'door'
  | 'exit'
  | 'bio_terminal'
  | 'hazard';

export interface Cell {
  x: number;
  y: number;
  chamber: 'A' | 'B' | 'SHARED';
  type: CellType;
  entityId?: string;
  owner?: 'A' | 'B' | 'BOTH';
  label?: string;
}

export interface SwitchEntity {
  id: string;
  label: string;
  x: number;
  y: number;
  chamber: 'A' | 'B';
  kind: 'toggle' | 'hold' | 'bio_lock';
  state: boolean;
  targetIds: string[];
  requiredPlddtBand?: 'very_high' | 'confident' | 'low';
  uniprotAccession?: string;
}

export interface DoorEntity {
  id: string;
  label: string;
  x: number;
  y: number;
  chamber: 'A' | 'B';
  kind: 'door' | 'bridge' | 'laser_gate';
  isOpen: boolean;
  requiredSwitchIds: string[];
}

export interface HazardDrone {
  id: string;
  chamber: 'A' | 'B';
  archetype: 'patrol_sweeper' | 'orbital_sentinel' | 'phase_emitter';
  x: number;
  y: number;
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  phase: number;
  windupTimer: number;
  activePulse: boolean;
  disabledBySwitchId?: string;
}

export interface PlayerActor {
  id: string;
  role: PlayerRole;
  slot: 'A' | 'B';
  name: string;
  color: string;
  isReady: boolean;
  x: number;
  y: number;
  facing: 'N' | 'S' | 'E' | 'W';
  hp: number;
  maxHp: number;
  moves: number;
  onExit: boolean;
  lastActionAt: number;
}

export interface PingMarker {
  id: string;
  playerId: string;
  slot: 'A' | 'B';
  x: number;
  y: number;
  kind: 'inspect' | 'stand_here' | 'activate' | 'danger';
  label: string;
  createdAt: number;
}

export interface ChatMessage {
  id: string;
  senderSlot: 'A' | 'B' | 'SYSTEM';
  senderName: string;
  text: string;
  isEmote?: boolean;
  timestamp: number;
}

export interface PuzzleState {
  levelIndex: number;
  levelTitle: string;
  levelSubtitle: string;
  proteinTarget: {
    gene: string;
    uniprotAccession: string;
    pdbId: string;
    clueText: string;
  };
  width: number;
  height: number;
  grid: Cell[][];
  switches: SwitchEntity[];
  doors: DoorEntity[];
  hazards: HazardDrone[];
  syncIntegrity: number;
  movesCount: number;
  bioLockVerified: boolean;
}

export interface SharedRoomState {
  roomId: string;
  status: RoomLifecycleStatus;
  splitControlMode: boolean;
  players: PlayerActor[];
  puzzleState: PuzzleState;
  pings: PingMarker[];
  messages: ChatMessage[];
  timer: number;
  startedAt: number | null;
  completedAt: number | null;
  bestScore: number;
  lastScore: number;
  version: number;
}

export type ClientActionPayload =
  | { type: 'JOIN_ROOM'; roomId: string; playerId: string; preferredSlot?: 'A' | 'B'; name?: string }
  | { type: 'TOGGLE_READY'; playerId: string }
  | { type: 'SET_SPLIT_CONTROL'; enabled: boolean }
  | { type: 'START_GAME'; levelIndex?: number }
  | { type: 'PAUSE_GAME' }
  | { type: 'RESUME_GAME' }
  | { type: 'RESET_ROOM'; levelIndex?: number }
  | { type: 'NEXT_LEVEL' }
  | { type: 'MOVE_PLAYER'; slot: 'A' | 'B'; dx: number; dy: number }
  | { type: 'TELEPORT_CLICK'; slot: 'A' | 'B'; targetX: number; targetY: number }
  | { type: 'INTERACT'; slot: 'A' | 'B' }
  | { type: 'VERIFY_BIO_LOCK'; uniprotAccession: string; meanPlddt: number }
  | { type: 'SEND_PING'; slot: 'A' | 'B'; x: number; y: number; kind: PingMarker['kind']; label: string }
  | { type: 'SEND_CHAT'; slot: 'A' | 'B'; text: string; isEmote?: boolean }
  | { type: 'TICK_TIMER'; deltaSec: number };
