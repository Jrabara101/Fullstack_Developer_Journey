package com.example.audio

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.model.Player

class SoundEffectsManager {

    private var toneGenerator: ToneGenerator? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (e: Exception) {
            Log.w("SoundEffectsManager", "Could not initialize ToneGenerator: ${e.message}")
        }
    }

    fun playMarkSound(player: Player) {
        try {
            when (player) {
                Player.X -> {
                    // Crisp higher tone for X
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
                }
                Player.O -> {
                    // Distinct chime tone for O
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 90)
                }
            }
        } catch (e: Exception) {
            Log.w("SoundEffectsManager", "Tone playback failed: ${e.message}")
        }
    }

    fun playWinFanfare() {
        try {
            // Harmonic arpeggio fanfare for victory
            toneGenerator?.startTone(ToneGenerator.TONE_DTMF_3, 100)
            mainHandler.postDelayed({
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_DTMF_6, 120)
                } catch (_: Exception) {}
            }, 110)
            mainHandler.postDelayed({
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_DTMF_9, 250)
                } catch (_: Exception) {}
            }, 240)
        } catch (e: Exception) {
            Log.w("SoundEffectsManager", "Win tone failed: ${e.message}")
        }
    }

    fun playDrawSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 180)
        } catch (e: Exception) {
            Log.w("SoundEffectsManager", "Draw tone failed: ${e.message}")
        }
    }

    fun playClickSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 40)
        } catch (e: Exception) {
            Log.w("SoundEffectsManager", "Click tone failed: ${e.message}")
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (_: Exception) {}
    }
}
