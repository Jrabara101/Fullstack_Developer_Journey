package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.GameScores
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ScoreRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _scores = MutableStateFlow(loadScores())
    val scores: StateFlow<GameScores> = _scores.asStateFlow()

    private fun loadScores(): GameScores {
        val xWins = prefs.getInt(KEY_X_WINS, 0)
        val oWins = prefs.getInt(KEY_O_WINS, 0)
        val draws = prefs.getInt(KEY_DRAWS, 0)
        return GameScores(xWins = xWins, oWins = oWins, draws = draws)
    }

    fun saveScores(scores: GameScores) {
        prefs.edit()
            .putInt(KEY_X_WINS, scores.xWins)
            .putInt(KEY_O_WINS, scores.oWins)
            .putInt(KEY_DRAWS, scores.draws)
            .apply()
        _scores.value = scores
    }

    fun resetScores() {
        val zeroScores = GameScores(0, 0, 0)
        saveScores(zeroScores)
    }

    companion object {
        private const val PREFS_NAME = "tictactoe_scores_prefs"
        private const val KEY_X_WINS = "key_x_wins"
        private const val KEY_O_WINS = "key_o_wins"
        private const val KEY_DRAWS = "key_draws"
    }
}
