package com.example.engine

import com.example.model.GameState
import com.example.model.GameScores
import com.example.model.Player
import com.example.model.TicTacToeState
import com.example.model.WinningLine
import com.example.model.WinningLineType

object TicTacToeEngine {

    val WINNING_COMBINATIONS = listOf(
        WinningLine(listOf(0, 1, 2), WinningLineType.ROW_0),
        WinningLine(listOf(3, 4, 5), WinningLineType.ROW_1),
        WinningLine(listOf(6, 7, 8), WinningLineType.ROW_2),
        WinningLine(listOf(0, 3, 6), WinningLineType.COL_0),
        WinningLine(listOf(1, 4, 7), WinningLineType.COL_1),
        WinningLine(listOf(2, 5, 8), WinningLineType.COL_2),
        WinningLine(listOf(0, 4, 8), WinningLineType.MAIN_DIAGONAL),
        WinningLine(listOf(2, 4, 6), WinningLineType.ANTI_DIAGONAL)
    )

    fun checkWin(board: List<Player?>): WinningLine? {
        for (combo in WINNING_COMBINATIONS) {
            val (a, b, c) = combo.indices
            val pA = board[a]
            if (pA != null && pA == board[b] && pA == board[c]) {
                return combo
            }
        }
        return null
    }

    fun isBoardFull(board: List<Player?>): Boolean {
        return board.none { it == null }
    }

    fun makeMove(state: TicTacToeState, index: Int): TicTacToeState {
        // Guard against invalid moves or already finished games
        if (index !in 0..8 || state.board[index] != null || state.isGameOver) {
            return state
        }

        val newBoard = state.board.toMutableList().apply {
            this[index] = state.currentTurn
        }

        val winningLine = checkWin(newBoard)

        return when {
            winningLine != null -> {
                val winner = state.currentTurn
                val newScores = when (winner) {
                    Player.X -> state.scores.copy(xWins = state.scores.xWins + 1)
                    Player.O -> state.scores.copy(oWins = state.scores.oWins + 1)
                }
                state.copy(
                    board = newBoard,
                    gameState = GameState.WIN,
                    winner = winner,
                    winningLine = winningLine,
                    scores = newScores,
                    isGameOver = true
                )
            }
            isBoardFull(newBoard) -> {
                val newScores = state.scores.copy(draws = state.scores.draws + 1)
                state.copy(
                    board = newBoard,
                    gameState = GameState.DRAW,
                    winner = null,
                    winningLine = null,
                    scores = newScores,
                    isGameOver = true
                )
            }
            else -> {
                state.copy(
                    board = newBoard,
                    currentTurn = state.currentTurn.next(),
                    gameState = GameState.IN_PROGRESS,
                    winner = null,
                    winningLine = null,
                    isGameOver = false
                )
            }
        }
    }

    fun resetRound(state: TicTacToeState, startingPlayer: Player = Player.X): TicTacToeState {
        return state.copy(
            board = List(9) { null },
            currentTurn = startingPlayer,
            gameState = GameState.IDLE,
            winner = null,
            winningLine = null,
            isGameOver = false
        )
    }

    fun resetScores(state: TicTacToeState): TicTacToeState {
        return state.copy(
            scores = GameScores(0, 0, 0)
        )
    }
}
