package com.example.model

data class GameScores(
    val xWins: Int = 0,
    val oWins: Int = 0,
    val draws: Int = 0
) {
    val totalGames: Int
        get() = xWins + oWins + draws
}
