package com.example.model

enum class GameState {
    IDLE,
    IN_PROGRESS,
    WIN,
    DRAW
}

data class TicTacToeState(
    val board: List<Player?> = List(9) { null },
    val currentTurn: Player = Player.X,
    val gameState: GameState = GameState.IDLE,
    val winner: Player? = null,
    val winningLine: WinningLine? = null,
    val scores: GameScores = GameScores(),
    val isGameOver: Boolean = false
)
