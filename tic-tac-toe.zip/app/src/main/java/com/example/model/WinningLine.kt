package com.example.model

enum class WinningLineType {
    ROW_0,
    ROW_1,
    ROW_2,
    COL_0,
    COL_1,
    COL_2,
    MAIN_DIAGONAL,
    ANTI_DIAGONAL
}

data class WinningLine(
    val indices: List<Int>,
    val type: WinningLineType
)
