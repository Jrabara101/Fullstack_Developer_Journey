package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.outlined.Grid3x3
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.TicTacToeState
import com.example.ui.components.GameControls
import com.example.ui.components.ResetConfirmDialog
import com.example.ui.components.Scoreboard
import com.example.ui.components.StatusBanner
import com.example.ui.components.TicTacToeBoard
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryLight
import com.example.ui.theme.GeoTextPrimary
import com.example.ui.theme.GeoTextSecondary

@Composable
fun TicTacToeScreen(
    viewModel: TicTacToeViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val showResetDialog by viewModel.showResetDialog.collectAsStateWithLifecycle()

    TicTacToeContent(
        state = uiState,
        showResetDialog = showResetDialog,
        onCellClick = viewModel::onCellClicked,
        onNewRound = viewModel::onNewRoundClicked,
        onResetScores = viewModel::onResetScoresClicked,
        onConfirmReset = viewModel::onConfirmResetScores,
        onDismissReset = viewModel::onDismissResetDialog,
        modifier = modifier
    )
}

@Composable
fun TicTacToeContent(
    state: TicTacToeState,
    showResetDialog: Boolean,
    onCellClick: (Int) -> Unit,
    onNewRound: () -> Unit,
    onResetScores: () -> Unit,
    onConfirmReset: () -> Unit,
    onDismissReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("tictactoe_screen"),
        containerColor = GeoBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 380.dp)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Bar
                    GeometricHeader(onQuickReset = onNewRound)

                    // Scoreboard (Player X, Draws, Player O)
                    Scoreboard(
                        scores = state.scores,
                        currentTurn = state.currentTurn,
                        isGameOver = state.isGameOver
                    )

                    // 3x3 Tic-Tac-Toe Board
                    TicTacToeBoard(
                        board = state.board,
                        winningLine = state.winningLine,
                        isGameOver = state.isGameOver,
                        onCellClick = onCellClick
                    )

                    // Dynamic Status Banner Pill
                    StatusBanner(state = state)

                    // Footer Game Controls (New Round, Reset Match)
                    GameControls(
                        onNewRound = onNewRound,
                        onResetScores = onResetScores
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }

    if (showResetDialog) {
        ResetConfirmDialog(
            onConfirm = onConfirmReset,
            onDismiss = onDismissReset
        )
    }
}

@Composable
private fun GeometricHeader(
    onQuickReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Purple circle icon container with grid symbol
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(GeoPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Grid3x3,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Text(
                text = stringResource(R.string.app_name),
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = GeoTextPrimary,
                letterSpacing = (-0.2).sp
            )
        }

        // Quick Replay / Reset button
        IconButton(
            onClick = onQuickReset,
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .testTag("header_reset_button")
        ) {
            Icon(
                imageVector = Icons.Default.Replay,
                contentDescription = stringResource(R.string.new_round),
                tint = GeoTextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

