package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundEffectsManager
import com.example.data.ScoreRepository
import com.example.engine.TicTacToeEngine
import com.example.model.GameState
import com.example.model.Player
import com.example.model.TicTacToeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TicTacToeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ScoreRepository(application.applicationContext)
    val soundEffects = SoundEffectsManager()

    private val _uiState = MutableStateFlow(
        TicTacToeState(scores = repository.scores.value)
    )
    val uiState: StateFlow<TicTacToeState> = _uiState.asStateFlow()

    private val _showResetDialog = MutableStateFlow(false)
    val showResetDialog: StateFlow<Boolean> = _showResetDialog.asStateFlow()

    init {
        viewModelScope.launch {
            repository.scores.collect { latestScores ->
                _uiState.update { it.copy(scores = latestScores) }
            }
        }
    }

    fun onCellClicked(index: Int) {
        val currentState = _uiState.value
        if (currentState.isGameOver || currentState.board[index] != null) {
            return
        }

        val turnPlayer = currentState.currentTurn
        val nextState = TicTacToeEngine.makeMove(currentState, index)

        _uiState.value = nextState

        // Trigger Audio Feedback based on outcome
        when (nextState.gameState) {
            GameState.WIN -> {
                soundEffects.playMarkSound(turnPlayer)
                soundEffects.playWinFanfare()
                repository.saveScores(nextState.scores)
            }
            GameState.DRAW -> {
                soundEffects.playMarkSound(turnPlayer)
                soundEffects.playDrawSound()
                repository.saveScores(nextState.scores)
            }
            GameState.IN_PROGRESS -> {
                soundEffects.playMarkSound(turnPlayer)
            }
            GameState.IDLE -> {
                soundEffects.playMarkSound(turnPlayer)
            }
        }
    }

    fun onNewRoundClicked() {
        soundEffects.playClickSound()
        _uiState.update { current ->
            // Alternate starting player or start with X
            val nextStartingPlayer = if (current.winner != null) current.winner else Player.X
            TicTacToeEngine.resetRound(current, startingPlayer = nextStartingPlayer)
        }
    }

    fun onResetScoresClicked() {
        soundEffects.playClickSound()
        _showResetDialog.value = true
    }

    fun onConfirmResetScores() {
        soundEffects.playClickSound()
        _showResetDialog.value = false
        repository.resetScores()
        _uiState.update { current ->
            TicTacToeEngine.resetScores(current)
        }
    }

    fun onDismissResetDialog() {
        _showResetDialog.value = false
    }

    override fun onCleared() {
        super.onCleared()
        soundEffects.release()
    }
}
