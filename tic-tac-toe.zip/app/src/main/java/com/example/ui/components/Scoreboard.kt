package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GameScores
import com.example.model.Player
import com.example.ui.theme.GeoNeutralBorder
import com.example.ui.theme.GeoNeutralContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryBorder
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoPrimaryLight
import com.example.ui.theme.GeoTextSecondary

@Composable
fun Scoreboard(
    scores: GameScores,
    currentTurn: Player,
    isGameOver: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .testTag("scoreboard"),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Player X Card
        val isXActive = !isGameOver && currentTurn == Player.X
        ScoreCard(
            modifier = Modifier
                .weight(1f)
                .testTag("score_x"),
            label = stringResource(R.string.player_x),
            score = scores.xWins,
            isActive = isXActive
        )

        // Draws Card
        ScoreCard(
            modifier = Modifier
                .weight(1f)
                .testTag("score_draws"),
            label = stringResource(R.string.draws),
            score = scores.draws,
            isActive = false
        )

        // Player O Card
        val isOActive = !isGameOver && currentTurn == Player.O
        ScoreCard(
            modifier = Modifier
                .weight(1f)
                .testTag("score_o"),
            label = stringResource(R.string.player_o),
            score = scores.oWins,
            isActive = isOActive
        )
    }
}

@Composable
private fun ScoreCard(
    label: String,
    score: Int,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = if (isActive) GeoPrimaryBorder else GeoNeutralBorder,
        animationSpec = tween(durationMillis = 200),
        label = "borderColor"
    )

    val backgroundColor by animateColorAsState(
        targetValue = if (isActive) GeoPrimaryLight else GeoNeutralContainer,
        animationSpec = tween(durationMillis = 200),
        label = "bgColor"
    )

    val textColor = if (isActive) GeoPrimaryDark else GeoTextSecondary
    val labelAlpha = if (isActive) 0.75f else 0.6f

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .border(
                width = 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(vertical = 12.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = label.uppercase(),
                color = textColor.copy(alpha = labelAlpha),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = String.format("%02d", score),
                color = textColor,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp
            )
        }
    }
}

