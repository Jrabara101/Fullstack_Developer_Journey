package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GameState
import com.example.model.Player
import com.example.model.TicTacToeState
import com.example.ui.theme.GeoNeutralBorder
import com.example.ui.theme.GeoNeutralContainer
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryBorder
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoPrimaryLight
import com.example.ui.theme.GeoTextSecondary

@Composable
fun StatusBanner(
    state: TicTacToeState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("status_banner"),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = state,
            transitionSpec = {
                (fadeIn(animationSpec = tween(180)) + scaleIn(initialScale = 0.94f)) togetherWith
                        (fadeOut(animationSpec = tween(140)) + scaleOut(targetScale = 1.04f))
            },
            label = "statusBannerContent"
        ) { targetState ->
            when (targetState.gameState) {
                GameState.WIN -> {
                    val winner = targetState.winner ?: Player.X
                    val winnerText = if (winner == Player.X) {
                        stringResource(R.string.winner_x)
                    } else {
                        stringResource(R.string.winner_o)
                    }

                    Box(
                        modifier = Modifier
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(GeoPrimaryLight)
                            .border(1.dp, GeoPrimaryBorder, CircleShape)
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(text = "👑", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = winnerText,
                                color = GeoPrimaryDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                GameState.DRAW -> {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(GeoNeutralContainer)
                            .border(1.dp, GeoNeutralBorder, CircleShape)
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(text = "🤝", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.game_draw),
                                color = GeoTextSecondary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                GameState.IDLE, GameState.IN_PROGRESS -> {
                    val isXTurn = targetState.currentTurn == Player.X
                    val dotColor = if (isXTurn) GeoPrimary else GeoTextSecondary
                    val turnText = if (isXTurn) {
                        stringResource(R.string.turn_x)
                    } else {
                        stringResource(R.string.turn_o)
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(GeoNeutralContainer)
                            .border(1.dp, GeoNeutralBorder, CircleShape)
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(dotColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = turnText,
                                color = GeoTextSecondary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

