package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.Player
import com.example.model.WinningLine
import com.example.ui.theme.GeoBoardBackground
import com.example.ui.theme.GeoPrimaryBorder

@Composable
fun TicTacToeBoard(
    board: List<Player?>,
    winningLine: WinningLine?,
    isGameOver: Boolean,
    onCellClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val winningIndices = winningLine?.indices ?: emptyList()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .testTag("game_board")
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x1F000000)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(GeoBoardBackground)
            .border(1.dp, GeoPrimaryBorder, RoundedCornerShape(24.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // 3x3 Grid of cells with 12.dp spacing
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            for (row in 0..2) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    for (col in 0..2) {
                        val index = row * 3 + col
                        val player = board[index]
                        val isWinning = index in winningIndices

                        TicTacToeCell(
                            index = index,
                            player = player,
                            isWinningCell = isWinning,
                            isGameOver = isGameOver,
                            onClick = { onCellClick(index) },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                        )
                    }
                }
            }
        }

        // Winning Strike line Canvas overlay
        WinningStrikeLine(
            winningLine = winningLine,
            modifier = Modifier.fillMaxSize()
        )
    }
}

