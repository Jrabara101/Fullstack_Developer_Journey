package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.model.Player
import com.example.ui.theme.GeoCellActive
import com.example.ui.theme.GeoCellBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoPrimaryLight
import com.example.ui.theme.PlayerODark
import com.example.ui.theme.PlayerOColor
import com.example.ui.theme.PlayerXColor

@Composable
fun TicTacToeCell(
    index: Int,
    player: Player?,
    isWinningCell: Boolean,
    isGameOver: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cellDescription = when (player) {
        Player.X -> "Cell ${index + 1}: Player X"
        Player.O -> "Cell ${index + 1}: Player O"
        null -> "Cell ${index + 1}: Empty"
    }

    val animatedBgColor by animateColorAsState(
        targetValue = when {
            isWinningCell -> GeoCellActive
            else -> GeoCellBackground
        },
        animationSpec = tween(220),
        label = "cellBgColor"
    )

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .testTag("cell_$index")
            .semantics {
                this.contentDescription = cellDescription
                this.role = Role.Button
            }
            .shadow(
                elevation = if (isWinningCell) 3.dp else 1.5.dp,
                shape = RoundedCornerShape(14.dp),
                spotColor = Color(0x1A000000)
            )
            .clip(RoundedCornerShape(14.dp))
            .background(animatedBgColor)
            .clickable(
                enabled = player == null && !isGameOver,
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = GeoPrimaryLight),
                onClick = onClick
            )
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        if (player != null) {
            AnimatedMark(
                player = player,
                isWinning = isWinningCell
            )
        }
    }
}

@Composable
private fun AnimatedMark(
    player: Player,
    isWinning: Boolean
) {
    // Animation for stroke drawing progress
    val drawProgress = remember { Animatable(0f) }
    // Animation for scale pop-in
    val scale = remember { Animatable(0.5f) }

    LaunchedEffect(player) {
        drawProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing)
        )
    }

    LaunchedEffect(player) {
        scale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        )
    }

    val markColor = when {
        isWinning -> GeoPrimaryDark
        player == Player.X -> PlayerXColor
        else -> PlayerOColor
    }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .scale(scale.value)
    ) {
        val strokeWidth = size.minDimension * 0.13f
        val stroke = Stroke(
            width = strokeWidth,
            cap = StrokeCap.Round
        )

        when (player) {
            Player.X -> {
                drawAnimatedX(
                    progress = drawProgress.value,
                    color = markColor,
                    stroke = stroke
                )
            }
            Player.O -> {
                drawAnimatedO(
                    progress = drawProgress.value,
                    color = markColor,
                    stroke = stroke
                )
            }
        }
    }
}

private fun DrawScope.drawAnimatedX(
    progress: Float,
    color: Color,
    stroke: Stroke
) {
    val padding = size.minDimension * 0.12f
    val startX = padding
    val startY = padding
    val endX = size.width - padding
    val endY = size.height - padding

    // Diagonal 1: Top-Left to Bottom-Right (0.0 to 0.5 progress)
    val diag1Progress = (progress / 0.5f).coerceIn(0f, 1f)
    if (diag1Progress > 0f) {
        val currentEndX = startX + (endX - startX) * diag1Progress
        val currentEndY = startY + (endY - startY) * diag1Progress
        drawLine(
            color = color,
            start = Offset(startX, startY),
            end = Offset(currentEndX, currentEndY),
            strokeWidth = stroke.width,
            cap = stroke.cap
        )
    }

    // Diagonal 2: Top-Right to Bottom-Left (0.5 to 1.0 progress)
    val diag2Progress = ((progress - 0.5f) / 0.5f).coerceIn(0f, 1f)
    if (diag2Progress > 0f) {
        val currentStartX2 = endX
        val currentStartY2 = startY
        val currentEndX2 = endX - (endX - startX) * diag2Progress
        val currentEndY2 = startY + (endY - startY) * diag2Progress
        drawLine(
            color = color,
            start = Offset(currentStartX2, currentStartY2),
            end = Offset(currentEndX2, currentEndY2),
            strokeWidth = stroke.width,
            cap = stroke.cap
        )
    }
}

private fun DrawScope.drawAnimatedO(
    progress: Float,
    color: Color,
    stroke: Stroke
) {
    val padding = size.minDimension * 0.12f
    val radius = (size.minDimension - (padding * 2) - stroke.width) / 2f
    val center = Offset(size.width / 2f, size.height / 2f)

    // Draw partial arc based on progress (0 to 360 degrees)
    val sweepAngle = 360f * progress
    drawArc(
        color = color,
        startAngle = -90f,
        sweepAngle = sweepAngle,
        useCenter = false,
        topLeft = Offset(center.x - radius, center.y - radius),
        size = Size(radius * 2, radius * 2),
        style = stroke
    )
}

