package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.example.model.WinningLine
import com.example.model.WinningLineType
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryBorder
import com.example.ui.theme.GeoPrimaryDark

@Composable
fun WinningStrikeLine(
    winningLine: WinningLine?,
    modifier: Modifier = Modifier
) {
    if (winningLine == null) return

    val strikeProgress = remember { Animatable(0f) }

    LaunchedEffect(winningLine) {
        strikeProgress.snapTo(0f)
        strikeProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing)
        )
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val margin = size.minDimension * 0.08f

        val (start, end) = when (winningLine.type) {
            WinningLineType.ROW_0 -> {
                val y = h * (1f / 6f)
                Offset(margin, y) to Offset(w - margin, y)
            }
            WinningLineType.ROW_1 -> {
                val y = h * 0.5f
                Offset(margin, y) to Offset(w - margin, y)
            }
            WinningLineType.ROW_2 -> {
                val y = h * (5f / 6f)
                Offset(margin, y) to Offset(w - margin, y)
            }
            WinningLineType.COL_0 -> {
                val x = w * (1f / 6f)
                Offset(x, margin) to Offset(x, h - margin)
            }
            WinningLineType.COL_1 -> {
                val x = w * 0.5f
                Offset(x, margin) to Offset(x, h - margin)
            }
            WinningLineType.COL_2 -> {
                val x = w * (5f / 6f)
                Offset(x, margin) to Offset(x, h - margin)
            }
            WinningLineType.MAIN_DIAGONAL -> {
                Offset(margin, margin) to Offset(w - margin, h - margin)
            }
            WinningLineType.ANTI_DIAGONAL -> {
                Offset(w - margin, margin) to Offset(margin, h - margin)
            }
        }

        val currentEnd = Offset(
            x = start.x + (end.x - start.x) * strikeProgress.value,
            y = start.y + (end.y - start.y) * strikeProgress.value
        )

        // Subtle outer strike backing
        drawLine(
            color = GeoPrimaryBorder,
            start = start,
            end = currentEnd,
            strokeWidth = 10.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Inner solid strike
        drawLine(
            color = GeoPrimaryDark,
            start = start,
            end = currentEnd,
            strokeWidth = 5.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

