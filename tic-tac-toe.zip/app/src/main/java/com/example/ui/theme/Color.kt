package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Palette
val GeoBackground = Color(0xFFFEF7FF)
val GeoTextPrimary = Color(0xFF1D1B20)
val GeoTextSecondary = Color(0xFF49454F)
val GeoTextMuted = Color(0xFF79747E)

// Purple / Brand Accents
val GeoPrimary = Color(0xFF6750A4)
val GeoPrimaryDark = Color(0xFF21005D)
val GeoPrimaryLight = Color(0xFFEADDFF)
val GeoPrimaryBorder = Color(0xFFD0BCFF)
val GeoPrimaryActiveBg = Color(0xFF4F378B)

// Neutral Containers & Cards
val GeoNeutralContainer = Color(0xFFF3EDF7)
val GeoNeutralBorder = Color(0xFFCAC4D0)
val GeoOutline = Color(0xFF79747E)

// Board & Cells
val GeoBoardBackground = Color(0xFFE8DEF8)
val GeoCellBackground = Color(0xFFFFFFFF)
val GeoCellActive = Color(0xFFD0BCFF)

// Players & Marks
val PlayerXColor = Color(0xFF6750A4)
val PlayerXDark = Color(0xFF21005D)
val PlayerOColor = Color(0xFF49454F)
val PlayerODark = Color(0xFF1D1B20)

// Win & Draw
val WinAccent = Color(0xFF6750A4)
val WinGold = Color(0xFF9A6B00)
val DrawAccent = Color(0xFF49454F)

