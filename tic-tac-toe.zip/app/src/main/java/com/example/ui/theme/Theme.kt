package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val GeometricBalanceColorScheme = lightColorScheme(
    primary = GeoPrimary,
    onPrimary = GeoBackground,
    primaryContainer = GeoPrimaryLight,
    onPrimaryContainer = GeoPrimaryDark,
    secondary = GeoTextSecondary,
    onSecondary = GeoBackground,
    secondaryContainer = GeoNeutralContainer,
    onSecondaryContainer = GeoTextSecondary,
    tertiary = WinGold,
    background = GeoBackground,
    onBackground = GeoTextPrimary,
    surface = GeoBackground,
    onSurface = GeoTextPrimary,
    surfaceVariant = GeoNeutralContainer,
    onSurfaceVariant = GeoTextSecondary,
    outline = GeoOutline,
    outlineVariant = GeoNeutralBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = GeometricBalanceColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = true
                controller.isAppearanceLightNavigationBars = true
            }
        }
    }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}


