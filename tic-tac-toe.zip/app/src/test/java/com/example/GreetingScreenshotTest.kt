package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.model.GameScores
import com.example.model.GameState
import com.example.model.Player
import com.example.model.TicTacToeState
import com.example.ui.TicTacToeContent
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    val sampleState = TicTacToeState(
      board = listOf(
        Player.X, Player.O, null,
        null, Player.X, null,
        null, null, Player.O
      ),
      currentTurn = Player.X,
      gameState = GameState.IN_PROGRESS,
      scores = GameScores(xWins = 2, oWins = 1, draws = 0)
    )

    composeTestRule.setContent {
      MyApplicationTheme {
        TicTacToeContent(
          state = sampleState,
          showResetDialog = false,
          onCellClick = {},
          onNewRound = {},
          onResetScores = {},
          onConfirmReset = {},
          onDismissReset = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}

