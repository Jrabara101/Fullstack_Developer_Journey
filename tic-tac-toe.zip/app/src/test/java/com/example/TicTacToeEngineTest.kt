package com.example

import com.example.engine.TicTacToeEngine
import com.example.model.GameState
import com.example.model.GameScores
import com.example.model.Player
import com.example.model.TicTacToeState
import com.example.model.WinningLineType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TicTacToeEngineTest {

    @Test
    fun `initial state is idle and board is empty`() {
        val state = TicTacToeState()
        assertEquals(GameState.IDLE, state.gameState)
        assertEquals(Player.X, state.currentTurn)
        assertEquals(9, state.board.size)
        assertTrue(state.board.all { it == null })
        assertNull(state.winner)
        assertNull(state.winningLine)
        assertFalse(state.isGameOver)
    }

    @Test
    fun `making valid moves alternates turn`() {
        var state = TicTacToeState()
        state = TicTacToeEngine.makeMove(state, 0)
        assertEquals(Player.X, state.board[0])
        assertEquals(Player.O, state.currentTurn)
        assertEquals(GameState.IN_PROGRESS, state.gameState)

        state = TicTacToeEngine.makeMove(state, 4)
        assertEquals(Player.O, state.board[4])
        assertEquals(Player.X, state.currentTurn)
        assertEquals(GameState.IN_PROGRESS, state.gameState)
    }

    @Test
    fun `making move on already occupied cell does nothing`() {
        var state = TicTacToeState()
        state = TicTacToeEngine.makeMove(state, 0)
        val stateAfterDuplicateMove = TicTacToeEngine.makeMove(state, 0)
        assertEquals(state, stateAfterDuplicateMove)
    }

    @Test
    fun `player X winning horizontally detects win and increments score`() {
        var state = TicTacToeState()
        // X: 0, O: 3, X: 1, O: 4, X: 2 (Row 0 win)
        state = TicTacToeEngine.makeMove(state, 0) // X
        state = TicTacToeEngine.makeMove(state, 3) // O
        state = TicTacToeEngine.makeMove(state, 1) // X
        state = TicTacToeEngine.makeMove(state, 4) // O
        state = TicTacToeEngine.makeMove(state, 2) // X

        assertEquals(GameState.WIN, state.gameState)
        assertEquals(Player.X, state.winner)
        assertNotNull(state.winningLine)
        assertEquals(WinningLineType.ROW_0, state.winningLine?.type)
        assertEquals(listOf(0, 1, 2), state.winningLine?.indices)
        assertEquals(1, state.scores.xWins)
        assertEquals(0, state.scores.oWins)
        assertEquals(0, state.scores.draws)
        assertTrue(state.isGameOver)
    }

    @Test
    fun `player O winning diagonally detects win`() {
        var state = TicTacToeState()
        // X: 1, O: 0, X: 2, O: 4, X: 5, O: 8 (Main diagonal win for O)
        state = TicTacToeEngine.makeMove(state, 1) // X
        state = TicTacToeEngine.makeMove(state, 0) // O
        state = TicTacToeEngine.makeMove(state, 2) // X
        state = TicTacToeEngine.makeMove(state, 4) // O
        state = TicTacToeEngine.makeMove(state, 5) // X
        state = TicTacToeEngine.makeMove(state, 8) // O

        assertEquals(GameState.WIN, state.gameState)
        assertEquals(Player.O, state.winner)
        assertNotNull(state.winningLine)
        assertEquals(WinningLineType.MAIN_DIAGONAL, state.winningLine?.type)
        assertEquals(1, state.scores.oWins)
        assertTrue(state.isGameOver)
    }

    @Test
    fun `draw game detection when board is full with no winner`() {
        var state = TicTacToeState()
        // X O X
        // X X O
        // O X O
        // Moves:
        // 0: X, 1: O, 2: X
        // 4: O, 3: X, 5: O
        // 7: X, 6: O, 8: X
        // Board: [X, O, X, X, O, O, O, X, X] -> let's make a known tie:
        // 0(X), 1(O), 2(X)
        // 3(X), 4(O), 5(O)
        // 7(X), 6(O), 8(X)
        state = TicTacToeEngine.makeMove(state, 0) // X
        state = TicTacToeEngine.makeMove(state, 1) // O
        state = TicTacToeEngine.makeMove(state, 2) // X
        state = TicTacToeEngine.makeMove(state, 4) // O
        state = TicTacToeEngine.makeMove(state, 3) // X
        state = TicTacToeEngine.makeMove(state, 5) // O
        state = TicTacToeEngine.makeMove(state, 7) // X
        state = TicTacToeEngine.makeMove(state, 6) // O
        state = TicTacToeEngine.makeMove(state, 8) // X

        assertEquals(GameState.DRAW, state.gameState)
        assertNull(state.winner)
        assertNull(state.winningLine)
        assertEquals(1, state.scores.draws)
        assertTrue(state.isGameOver)
    }

    @Test
    fun `reset round clears board and keeps scores`() {
        var state = TicTacToeState(scores = GameScores(xWins = 3, oWins = 2, draws = 1))
        state = TicTacToeEngine.makeMove(state, 0)
        val resetState = TicTacToeEngine.resetRound(state)

        assertEquals(GameState.IDLE, resetState.gameState)
        assertTrue(resetState.board.all { it == null })
        assertEquals(3, resetState.scores.xWins)
        assertEquals(2, resetState.scores.oWins)
        assertEquals(1, resetState.scores.draws)
    }

    @Test
    fun `reset scores zeroes out scores`() {
        val state = TicTacToeState(scores = GameScores(xWins = 5, oWins = 4, draws = 2))
        val resetState = TicTacToeEngine.resetScores(state)
        assertEquals(0, resetState.scores.xWins)
        assertEquals(0, resetState.scores.oWins)
        assertEquals(0, resetState.scores.draws)
    }
}
