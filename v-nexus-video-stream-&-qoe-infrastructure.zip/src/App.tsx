import React, { useState, useEffect } from 'react';
import { ActiveTab, VideoItem, QoEMetrics } from './types/video';
import { INITIAL_VIDEOS } from './data/mockData';
import { Header } from './components/Header';
import { VideoPlayer } from './components/VideoPlayer/VideoPlayer';
import { UploadManager } from './components/UploadPipeline/UploadManager';
import { CostTriadCalculator } from './components/EconomicsCalculator/CostTriadCalculator';
import { SecurityCenter } from './components/SecurityDRM/SecurityCenter';
import { QoEDashboard } from './components/Observability/QoEDashboard';
import { Footer } from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('player');
  const [allVideos, setAllVideos] = useState<VideoItem[]>(INITIAL_VIDEOS);
  const [currentVideo, setCurrentVideo] = useState<VideoItem>(INITIAL_VIDEOS[0]);
  
  // Network Profile Simulation
  const [networkCondition, setNetworkCondition] = useState<
    'optimal' | 'wifi' | 'cellular_4g' | 'congested_3g' | 'jitter'
  >('optimal');

  // Real-time Egress Cost Counter
  const [hourlyEgressCost, setHourlyEgressCost] = useState<number>(1422.84);

  // Real-time QoE Metrics State
  const [qoeMetrics, setQoEMetrics] = useState<QoEMetrics>({
    ttffMs: 342,
    rebufferRate: 0.28,
    bufferLengthSec: 6.8,
    vpfRate: 0.04,
    avgWatchTimeSec: 525, // 8:45
    completionRate: {
      q1: 86,
      q2: 72,
      q3: 61,
      q4: 52,
    },
    currentBitrateKbps: 12500,
    droppedFrames: 3,
    cdnLatencyMs: 18,
    cdnCacheHitRatio: 96.4,
    networkThroughputMbps: 98.4,
  });

  // Egress tick simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setHourlyEgressCost((prev) => prev + (Math.random() * 0.4 - 0.18));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handlePublishNewVideo = (newVideo: VideoItem) => {
    setAllVideos((prev) => [newVideo, ...prev]);
    setCurrentVideo(newVideo);
    setActiveTab('player');
  };

  return (
    <div className="w-screen h-screen bg-[#0A0A0B] text-gray-200 flex flex-col font-sans overflow-hidden select-none">
      {/* Header with Navigation & Live Simulation Controls */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        networkCondition={networkCondition}
        setNetworkCondition={setNetworkCondition}
        hourlyEgressCost={hourlyEgressCost}
      />

      {/* Main View Area based on Active Tab */}
      <main className="flex-1 flex overflow-hidden relative">
        {activeTab === 'player' && (
          <VideoPlayer
            currentVideo={currentVideo}
            onSelectVideo={setCurrentVideo}
            allVideos={allVideos}
            networkCondition={networkCondition}
            qoeMetrics={qoeMetrics}
            onUpdateQoE={setQoEMetrics}
          />
        )}

        {activeTab === 'pipeline' && (
          <UploadManager onPublishVideo={handlePublishNewVideo} />
        )}

        {activeTab === 'economics' && (
          <CostTriadCalculator />
        )}

        {activeTab === 'security' && (
          <SecurityCenter />
        )}

        {activeTab === 'observability' && (
          <QoEDashboard qoeMetrics={qoeMetrics} />
        )}
      </main>

      {/* Bottom Node Status & Alerts Bar */}
      <Footer />
    </div>
  );
}
