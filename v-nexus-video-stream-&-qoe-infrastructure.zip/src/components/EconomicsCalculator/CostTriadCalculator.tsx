import React, { useState, useMemo } from 'react';
import { VideoCodec } from '../../types/video';
import { 
  DollarSign, 
  Cpu, 
  Wifi, 
  HardDrive, 
  TrendingUp, 
  PieChart as PieIcon, 
  BarChart3, 
  Layers, 
  Info,
  Sparkles,
  Zap
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';

export const CostTriadCalculator: React.FC = () => {
  // Simulator Parameters
  const [viewers, setViewers] = useState<number>(250000); // 250k MAU
  const [hoursPerUser, setHoursPerUser] = useState<number>(14); // 14 hours / mo
  const [selectedCodec, setSelectedCodec] = useState<VideoCodec>('AV1');
  const [cdnRatePerGB, setCdnRatePerGB] = useState<number>(0.012); // $0.012 per GB
  const [cacheHitRatePct, setCacheHitRatePct] = useState<number>(94); // 94% cache hit
  const [catalogHours, setCatalogHours] = useState<number>(1200); // 1,200 video hours
  const [newVideoHoursPerMonth, setNewVideoHoursPerMonth] = useState<number>(150); // 150 hrs added
  const [coldStorageRatio, setColdStorageRatio] = useState<number>(85); // 85% in cold archive

  // Monetization model
  const [monetizationModel, setMonetizationModel] = useState<'avod' | 'svod' | 'hybrid'>('hybrid');
  const [adRpm, setAdRpm] = useState<number>(5.50); // $5.50 per 1000 views
  const [subPrice, setSubPrice] = useState<number>(9.99); // $9.99 / mo
  const [payingSubPct, setPayingSubPct] = useState<number>(4.2); // 4.2% conversion

  // Calculations
  const calculations = useMemo(() => {
    // Codec bitrate multipliers relative to H.264
    // H.264 baseline: 1.0 (e.g. avg 4.5 Mbps across ladder)
    // HEVC: 0.60 (40% bandwidth reduction, 1.8x encode compute)
    // AV1: 0.45 (55% bandwidth reduction, 3.2x encode compute)
    let bitrateMultiplier = 1.0;
    let encodeComputeCostMultiplier = 1.0;

    if (selectedCodec === 'HEVC (H.265)') {
      bitrateMultiplier = 0.60;
      encodeComputeCostMultiplier = 1.8;
    } else if (selectedCodec === 'AV1') {
      bitrateMultiplier = 0.45;
      encodeComputeCostMultiplier = 3.0;
    }

    const avgBitrateMbps = 4.2 * bitrateMultiplier;
    const totalStreamingHours = viewers * hoursPerUser;
    
    // GB streamed = (streaming hours * 3600 sec * avgBitrateMbps) / 8000
    const totalEgressGB = (totalStreamingHours * 3600 * avgBitrateMbps) / 8000;
    
    // Egress cost with CDN volume discount and caching efficiency
    const effectiveEgressCost = totalEgressGB * cdnRatePerGB;

    // Transcoding Compute Cost
    // Baseline H.264: ~$0.025 per output minute of multi-rendition ladder
    const baseTranscodeCostPerMin = 0.022;
    const totalNewMinutes = newVideoHoursPerMonth * 60;
    const transcodeCost = totalNewMinutes * (baseTranscodeCostPerMin * encodeComputeCostMultiplier);

    // Storage Cost
    // Raw video master: ~25 GB / hour. HLS package: ~8 GB / hour.
    const rawMasterGB = catalogHours * 25;
    const hlsPackageGB = catalogHours * 8;
    
    const coldMasterGB = rawMasterGB * (coldStorageRatio / 100);
    const hotMasterGB = rawMasterGB * ((100 - coldStorageRatio) / 100);
    
    const hotStorageRate = 0.021; // $0.021 / GB / mo
    const coldStorageRate = 0.0036; // $0.0036 / GB / mo (Glacier/Archive)

    const storageCost = 
      (hlsPackageGB + hotMasterGB) * hotStorageRate + 
      coldMasterGB * coldStorageRate;

    // Total Infrastructure Cost
    const totalInfraCost = effectiveEgressCost + transcodeCost + storageCost;

    // Revenue calculations
    let totalRevenue = 0;
    const totalViewsEst = (totalStreamingHours * 60) / 10; // avg 10 min per video view

    if (monetizationModel === 'avod') {
      totalRevenue = (totalViewsEst / 1000) * adRpm;
    } else if (monetizationModel === 'svod') {
      const payingUsers = viewers * (payingSubPct / 100);
      totalRevenue = payingUsers * subPrice;
    } else {
      // Hybrid
      const payingUsers = viewers * (payingSubPct / 100);
      const freeUsers = viewers - payingUsers;
      const freeViews = ((freeUsers * hoursPerUser) * 60) / 10;
      const adRev = (freeViews / 1000) * adRpm;
      const subRev = payingUsers * subPrice;
      totalRevenue = adRev + subRev;
    }

    const netProfit = totalRevenue - totalInfraCost;
    const profitMarginPct = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
    const costPerStreamHour = totalStreamingHours > 0 ? totalInfraCost / totalStreamingHours : 0;

    // Comparison matrix across codecs
    const codecComparison = [
      {
        name: 'H.264 (Universal)',
        egressCost: Math.round(totalEgressGB * (1.0 / bitrateMultiplier) * cdnRatePerGB),
        computeCost: Math.round(totalNewMinutes * baseTranscodeCostPerMin),
        totalCost: Math.round(
          totalEgressGB * (1.0 / bitrateMultiplier) * cdnRatePerGB +
          totalNewMinutes * baseTranscodeCostPerMin +
          storageCost
        ),
      },
      {
        name: 'HEVC (H.265)',
        egressCost: Math.round(totalEgressGB * (0.6 / bitrateMultiplier) * cdnRatePerGB),
        computeCost: Math.round(totalNewMinutes * baseTranscodeCostPerMin * 1.8),
        totalCost: Math.round(
          totalEgressGB * (0.6 / bitrateMultiplier) * cdnRatePerGB +
          totalNewMinutes * baseTranscodeCostPerMin * 1.8 +
          storageCost
        ),
      },
      {
        name: 'AV1 (Next-Gen)',
        egressCost: Math.round(totalEgressGB * (0.45 / bitrateMultiplier) * cdnRatePerGB),
        computeCost: Math.round(totalNewMinutes * baseTranscodeCostPerMin * 3.0),
        totalCost: Math.round(
          totalEgressGB * (0.45 / bitrateMultiplier) * cdnRatePerGB +
          totalNewMinutes * baseTranscodeCostPerMin * 3.0 +
          storageCost
        ),
      },
    ];

    const costBreakdownPie = [
      { name: 'CDN Egress Bandwidth', value: Math.round(effectiveEgressCost), color: '#F97316' },
      { name: 'Transcode GPU Compute', value: Math.round(transcodeCost), color: '#3B82F6' },
      { name: 'Multi-Tier Storage', value: Math.round(storageCost), color: '#10B981' },
    ];

    return {
      totalStreamingHours,
      totalEgressGB,
      effectiveEgressCost,
      transcodeCost,
      storageCost,
      totalInfraCost,
      totalRevenue,
      netProfit,
      profitMarginPct,
      costPerStreamHour,
      codecComparison,
      costBreakdownPie,
      bandwidthSavingsPct: Math.round((1 - bitrateMultiplier) * 100),
    };
  }, [
    viewers, 
    hoursPerUser, 
    selectedCodec, 
    cdnRatePerGB, 
    cacheHitRatePct, 
    catalogHours, 
    newVideoHoursPerMonth, 
    coldStorageRatio,
    monetizationModel,
    adRpm,
    subPrice,
    payingSubPct,
  ]);

  return (
    <div className="flex-1 flex flex-col xl:flex-row overflow-hidden bg-[#0A0A0B]">
      
      {/* Left Column: Interactive Triad Sliders & Monetization Engine */}
      <section className="flex-1 flex flex-col p-4 sm:p-6 lg:p-8 overflow-y-auto custom-scrollbar space-y-6">
        <div className="w-full max-w-4xl mx-auto space-y-6">
          
          {/* Header Banner */}
          <div className="bg-[#0F0F11] p-5 rounded-xl border border-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-orange-500" />
                <h2 className="text-base font-bold text-white font-mono">
                  INFRASTRUCTURE ECONOMICS & COST TRIAD
                </h2>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Balance encoding compute complexity, CDN egress bandwidth, and cold storage archiving for maximum margin.
              </p>
            </div>

            {/* Codec Selector Pill */}
            <div className="flex items-center gap-1 bg-[#16161A] p-1 rounded-lg border border-white/5">
              {(['AV1', 'HEVC (H.265)', 'H.264 (AVC)'] as VideoCodec[]).map((c) => (
                <button
                  key={c}
                  onClick={() => setSelectedCodec(c)}
                  className={`px-2.5 py-1 rounded text-xs font-mono font-semibold transition-all ${
                    selectedCodec === c
                      ? 'bg-orange-500 text-white shadow-sm'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {c.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Core Financial Summary KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">Monthly Gross Revenue</div>
              <div className="text-xl sm:text-2xl font-mono text-white font-semibold">
                ${Math.round(calculations.totalRevenue).toLocaleString()}
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">
                {monetizationModel.toUpperCase()} Strategy
              </span>
            </div>

            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">Total Infra Cost</div>
              <div className="text-xl sm:text-2xl font-mono text-orange-400 font-semibold">
                ${Math.round(calculations.totalInfraCost).toLocaleString()}
              </div>
              <span className="text-[10px] text-gray-400 font-mono">
                ${calculations.costPerStreamHour.toFixed(4)} / stream hr
              </span>
            </div>

            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">Net Operating Margin</div>
              <div className={`text-xl sm:text-2xl font-mono font-semibold ${
                calculations.netProfit >= 0 ? 'text-emerald-400' : 'text-red-400'
              }`}>
                ${Math.round(calculations.netProfit).toLocaleString()}
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">
                {calculations.profitMarginPct.toFixed(1)}% Margin
              </span>
            </div>

            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">Bandwidth Savings (vs H.264)</div>
              <div className="text-xl sm:text-2xl font-mono text-blue-400 font-semibold">
                {calculations.bandwidthSavingsPct}%
              </div>
              <span className="text-[10px] text-blue-400 font-mono">
                via {selectedCodec} Encoding
              </span>
            </div>
          </div>

          {/* Interactive Cost Triad Sliders */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-6 space-y-6">
            <h3 className="text-xs font-mono font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-orange-500" />
              Scale & Bandwidth Variable Drivers
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Monthly Active Viewers */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Monthly Active Viewers (MAU):</span>
                  <span className="text-white font-bold">{viewers.toLocaleString()}</span>
                </div>
                <input
                  id="slider-viewers"
                  type="range"
                  min="10000"
                  max="2000000"
                  step="25000"
                  value={viewers}
                  onChange={(e) => setViewers(parseInt(e.target.value, 10))}
                  className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
                />
              </div>

              {/* Hours / User / Month */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Avg Stream Hours / User / Month:</span>
                  <span className="text-white font-bold">{hoursPerUser} hrs</span>
                </div>
                <input
                  id="slider-hours"
                  type="range"
                  min="2"
                  max="60"
                  step="1"
                  value={hoursPerUser}
                  onChange={(e) => setHoursPerUser(parseInt(e.target.value, 10))}
                  className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
                />
              </div>

              {/* CDN Egress Rate */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">CDN Egress Rate ($/GB):</span>
                  <span className="text-white font-bold">${cdnRatePerGB.toFixed(3)}/GB</span>
                </div>
                <input
                  id="slider-cdn-rate"
                  type="range"
                  min="0.005"
                  max="0.05"
                  step="0.001"
                  value={cdnRatePerGB}
                  onChange={(e) => setCdnRatePerGB(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
                />
              </div>

              {/* Cold Storage Ratio */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Master Cold Archive Ratio:</span>
                  <span className="text-white font-bold">{coldStorageRatio}% Cold</span>
                </div>
                <input
                  id="slider-cold-storage"
                  type="range"
                  min="20"
                  max="95"
                  step="5"
                  value={coldStorageRatio}
                  onChange={(e) => setColdStorageRatio(parseInt(e.target.value, 10))}
                  className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
                />
              </div>

            </div>
          </div>

          {/* Codec Strategy Economics Comparison Chart */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-6">
            <h3 className="text-xs font-mono font-bold text-gray-300 uppercase tracking-wider mb-4 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-orange-500" />
              Codec Triad Cost Tradeoff (Egress vs Transcode Compute)
            </h3>
            
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={calculations.codecComparison} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                  <XAxis dataKey="name" stroke="#6b7280" textAnchor="middle" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                  <YAxis stroke="#6b7280" tick={{ fontSize: 11, fill: '#9ca3af' }} tickFormatter={(val) => `$${val}`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#16161A', borderColor: '#ffffff20', borderRadius: '8px', fontSize: '12px' }} 
                    formatter={(value: any) => [`$${Number(value).toLocaleString()}`, 'Cost']}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                  <Bar dataKey="egressCost" name="CDN Egress Cost ($)" fill="#F97316" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="computeCost" name="Transcoding GPU Cost ($)" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>
      </section>

      {/* Right Column: Monetization Strategy & Cost Breakdown */}
      <aside className="w-full xl:w-[380px] border-t xl:border-t-0 xl:border-l border-white/5 bg-[#0F0F11] p-5 lg:p-6 overflow-y-auto shrink-0 custom-scrollbar space-y-6">
        
        <div>
          <span className="text-[10px] font-mono text-orange-400 uppercase font-bold tracking-wider">
            Monetization Alignment Engine
          </span>
          <h3 className="text-sm font-bold text-white mt-1">
            Revenue & Margin Modeling
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            AVOD requires hyper-lean encoding & maximum cache hits. SVOD unlocks 4K DRM master budgets.
          </p>
        </div>

        {/* Model Tabs */}
        <div className="grid grid-cols-3 gap-1 bg-[#16161A] p-1 rounded-lg border border-white/5">
          {(['avod', 'svod', 'hybrid'] as const).map((model) => (
            <button
              key={model}
              onClick={() => setMonetizationModel(model)}
              className={`py-1.5 text-xs font-mono font-bold uppercase rounded transition-all ${
                monetizationModel === model
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {model}
            </button>
          ))}
        </div>

        {/* Model-Specific Inputs */}
        <div className="bg-[#16161A] p-4 rounded-lg border border-white/5 space-y-4 text-xs font-mono">
          
          {(monetizationModel === 'avod' || monetizationModel === 'hybrid') && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-gray-400">
                <span>Ad Revenue per 1000 Views (RPM):</span>
                <span className="text-orange-400 font-bold">${adRpm.toFixed(2)}</span>
              </div>
              <input
                id="slider-ad-rpm"
                type="range"
                min="1.00"
                max="18.00"
                step="0.50"
                value={adRpm}
                onChange={(e) => setAdRpm(parseFloat(e.target.value))}
                className="w-full h-1 bg-gray-800 rounded appearance-none cursor-pointer accent-orange-500"
              />
            </div>
          )}

          {(monetizationModel === 'svod' || monetizationModel === 'hybrid') && (
            <>
              <div className="space-y-1.5">
                <div className="flex justify-between text-gray-400">
                  <span>Monthly Subscription Price:</span>
                  <span className="text-orange-400 font-bold">${subPrice.toFixed(2)} / mo</span>
                </div>
                <input
                  id="slider-sub-price"
                  type="range"
                  min="3.99"
                  max="29.99"
                  step="1.00"
                  value={subPrice}
                  onChange={(e) => setSubPrice(parseFloat(e.target.value))}
                  className="w-full h-1 bg-gray-800 rounded appearance-none cursor-pointer accent-orange-500"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-gray-400">
                  <span>Paying Subscriber Conversion:</span>
                  <span className="text-emerald-400 font-bold">{payingSubPct.toFixed(1)}%</span>
                </div>
                <input
                  id="slider-paying-pct"
                  type="range"
                  min="0.5"
                  max="15.0"
                  step="0.1"
                  value={payingSubPct}
                  onChange={(e) => setPayingSubPct(parseFloat(e.target.value))}
                  className="w-full h-1 bg-gray-800 rounded appearance-none cursor-pointer accent-orange-500"
                />
              </div>
            </>
          )}

        </div>

        {/* Cost Breakdown Donut / Pie */}
        <div className="bg-[#16161A] p-4 rounded-lg border border-white/5">
          <div className="text-xs font-mono font-bold text-gray-300 uppercase mb-3 flex items-center gap-1.5">
            <PieIcon className="w-3.5 h-3.5 text-orange-500" />
            Infrastructure Cost Triad Breakdown
          </div>

          <div className="h-44 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={calculations.costBreakdownPie}
                  innerRadius={36}
                  outerRadius={64}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {calculations.costBreakdownPie.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0F0F11', borderColor: '#ffffff20', borderRadius: '8px', fontSize: '11px' }}
                  formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Cost']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-1.5 pt-2 text-[11px] font-mono border-t border-white/5">
            <div className="flex justify-between items-center">
              <span className="flex items-center gap-1.5 text-gray-400">
                <span className="w-2 h-2 rounded-full bg-orange-500"></span> Bandwidth Egress:
              </span>
              <span className="text-white">${Math.round(calculations.effectiveEgressCost).toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="flex items-center gap-1.5 text-gray-400">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span> GPU Transcoding:
              </span>
              <span className="text-white">${Math.round(calculations.transcodeCost).toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="flex items-center gap-1.5 text-gray-400">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span> Tiered Storage:
              </span>
              <span className="text-white">${Math.round(calculations.storageCost).toLocaleString()}</span>
            </div>
          </div>
        </div>

      </aside>

    </div>
  );
};
