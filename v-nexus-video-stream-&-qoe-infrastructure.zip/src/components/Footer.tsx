import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="h-[32px] bg-[#0A0A0B] border-t border-white/5 flex items-center justify-between px-4 sm:px-6 text-[9px] text-gray-500 uppercase font-mono font-bold tracking-[0.2em] shrink-0 select-none z-20">
      <div className="flex gap-4 sm:gap-8 overflow-hidden">
        <span className="truncate">Node: US-EAST-01A</span>
        <span className="truncate hidden sm:inline">Protocol: HLS/CMAF</span>
        <span className="truncate hidden md:inline">Auth: JWT/SECURE-TOKEN</span>
        <span className="truncate text-emerald-400">ABR Engine: ACTIVE</span>
      </div>
      <div className="text-orange-500 animate-pulse font-mono truncate ml-2">
        System Alert: High Load in SE-ASIA (Tokyo PoP Scaling OK)
      </div>
    </footer>
  );
};
