import React from 'react';
import { ActiveTab } from '../types/video';
import { 
  Tv, 
  UploadCloud, 
  DollarSign, 
  ShieldCheck, 
  Activity, 
  Wifi, 
  WifiOff, 
  Cpu, 
  Server,
  Sparkles
} from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  networkCondition: 'optimal' | 'wifi' | 'cellular_4g' | 'congested_3g' | 'jitter';
  setNetworkCondition: (condition: 'optimal' | 'wifi' | 'cellular_4g' | 'congested_3g' | 'jitter') => void;
  hourlyEgressCost: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  networkCondition,
  setNetworkCondition,
  hourlyEgressCost,
}) => {
  return (
    <header className="h-[64px] border-b border-white/5 flex items-center justify-between px-4 sm:px-8 bg-[#0F0F11] shrink-0 select-none z-30">
      {/* Brand & Status */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-orange-500 rounded flex items-center justify-center shadow-lg shadow-orange-500/20">
            <div className="w-3.5 h-3.5 bg-[#0A0A0B] rounded-sm flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse"></div>
            </div>
          </div>
          <div className="flex flex-col">
            <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-1.5 leading-none">
              V-NEXUS <span className="text-orange-500 font-mono text-xs px-1.5 py-0.5 rounded bg-orange-500/10 border border-orange-500/20">CORE v3.8</span>
            </h1>
            <span className="text-[10px] text-gray-500 font-mono tracking-wider">ENTERPRISE STREAMING & QoE</span>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
          <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest">
            Infra: Healthy
          </span>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <nav className="flex items-center gap-1 bg-[#16161A] p-1 rounded-lg border border-white/5 overflow-x-auto max-w-[480px]">
        <button
          id="nav-tab-player"
          onClick={() => setActiveTab('player')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
            activeTab === 'player'
              ? 'bg-orange-500 text-white shadow-sm font-semibold'
              : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
          }`}
        >
          <Tv className="w-3.5 h-3.5" />
          <span>Player & ABR</span>
        </button>

        <button
          id="nav-tab-pipeline"
          onClick={() => setActiveTab('pipeline')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
            activeTab === 'pipeline'
              ? 'bg-orange-500 text-white shadow-sm font-semibold'
              : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
          }`}
        >
          <UploadCloud className="w-3.5 h-3.5" />
          <span>Ingest & Upload</span>
        </button>

        <button
          id="nav-tab-economics"
          onClick={() => setActiveTab('economics')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
            activeTab === 'economics'
              ? 'bg-orange-500 text-white shadow-sm font-semibold'
              : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>Cost Triad</span>
        </button>

        <button
          id="nav-tab-security"
          onClick={() => setActiveTab('security')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
            activeTab === 'security'
              ? 'bg-orange-500 text-white shadow-sm font-semibold'
              : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Security & DRM</span>
        </button>

        <button
          id="nav-tab-observability"
          onClick={() => setActiveTab('observability')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
            activeTab === 'observability'
              ? 'bg-orange-500 text-white shadow-sm font-semibold'
              : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>QoE Telemetry</span>
        </button>
      </nav>

      {/* Right Controls & Status */}
      <div className="flex items-center gap-4">
        {/* Network Profile Simulator */}
        <div className="hidden xl:flex items-center gap-2 bg-[#16161A] px-2.5 py-1.5 rounded-md border border-white/5">
          <span className="text-[10px] text-gray-400 uppercase font-semibold flex items-center gap-1">
            <Wifi className="w-3 h-3 text-orange-400" /> Network:
          </span>
          <select
            id="network-simulator-select"
            value={networkCondition}
            onChange={(e) => setNetworkCondition(e.target.value as any)}
            className="bg-transparent text-xs font-mono text-gray-200 focus:outline-none cursor-pointer"
          >
            <option value="optimal" className="bg-[#16161A] text-white">5G Optimal (100 Mbps)</option>
            <option value="wifi" className="bg-[#16161A] text-white">Broadband WiFi (30 Mbps)</option>
            <option value="cellular_4g" className="bg-[#16161A] text-white">Cellular 4G (8 Mbps)</option>
            <option value="congested_3g" className="bg-[#16161A] text-white">Constrained 3G (1.5 Mbps)</option>
            <option value="jitter" className="bg-[#16161A] text-white">Packet Loss & Jitter</option>
          </select>
        </div>

        {/* Live Egress Metric */}
        <div className="flex flex-col items-end">
          <span className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">
            Current Session Egress
          </span>
          <span className="text-xs sm:text-sm font-mono text-orange-400 font-semibold">
            ${hourlyEgressCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / hr
          </span>
        </div>

        <div className="w-8 h-8 rounded-full border border-white/20 bg-gray-800 flex items-center justify-center text-xs font-bold text-orange-400">
          NX
        </div>
      </div>
    </header>
  );
};
