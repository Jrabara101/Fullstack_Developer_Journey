import React, { useState, useEffect } from 'react';
import { QoEMetrics, CDNEdgeNode } from '../../types/video';
import { INITIAL_CDN_NODES } from '../../data/mockData';
import { 
  Activity, 
  Clock, 
  AlertCircle, 
  CheckCircle, 
  Server, 
  Globe, 
  Layers, 
  Radio, 
  Cpu, 
  Terminal, 
  TrendingUp,
  Sparkles,
  Zap
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

interface QoEDashboardProps {
  qoeMetrics: QoEMetrics;
}

export const QoEDashboard: React.FC<QoEDashboardProps> = ({ qoeMetrics }) => {
  const [cdnNodes, setCdnNodes] = useState<CDNEdgeNode[]>(INITIAL_CDN_NODES);
  
  // Real-time telemetry log events
  const [telemetryLogs, setTelemetryLogs] = useState<{ id: string; time: string; type: 'info' | 'warn' | 'success'; msg: string }[]>([
    { id: '1', time: '12:44:02', type: 'success', msg: '[ABR] Auto ladder stepped up to 2160p (4K AV1 @ 12.5 Mbps) on 100 Mbps connection' },
    { id: '2', time: '12:43:58', type: 'info', msg: '[CDN] Chunk #18 delivered from Tokyo Edge (NRT) cache in 16ms (Cache Hit)' },
    { id: '3', time: '12:43:52', type: 'success', msg: '[DRM] Widevine Modular L1 license handshake verified in 9ms' },
    { id: '4', time: '12:43:40', type: 'info', msg: '[QoE] TTFF registered at 342ms (Optimal < 500ms target)' },
    { id: '5', time: '12:43:20', type: 'success', msg: '[Buffer] Lookahead buffer stabilized at 8.2 seconds' },
  ]);

  // Hourly TTFF & Rebuffer trend data
  const trendData = [
    { time: '-6H', ttff: 480, rebuffer: 0.42, cacheHit: 93.2 },
    { time: '-5H', ttff: 420, rebuffer: 0.38, cacheHit: 94.5 },
    { time: '-4H', ttff: 390, rebuffer: 0.34, cacheHit: 95.1 },
    { time: '-3H', ttff: 360, rebuffer: 0.31, cacheHit: 96.0 },
    { time: '-2H', ttff: 350, rebuffer: 0.29, cacheHit: 96.8 },
    { time: '-1H', ttff: 345, rebuffer: 0.28, cacheHit: 97.1 },
    { time: 'NOW', ttff: qoeMetrics.ttffMs, rebuffer: qoeMetrics.rebufferRate, cacheHit: 97.4 },
  ];

  // Audience Retention Funnel Data
  const retentionData = [
    { stage: 'Start (0%)', retention: 100 },
    { stage: '25% (Q1)', retention: qoeMetrics.completionRate.q1 },
    { stage: '50% (Mid)', retention: qoeMetrics.completionRate.q2 },
    { stage: '75% (Q3)', retention: qoeMetrics.completionRate.q3 },
    { stage: '100% (End)', retention: qoeMetrics.completionRate.q4 },
  ];

  // Live telemetry pulse simulation
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().toTimeString().split(' ')[0];
      const randomEvents = [
        { type: 'info' as const, msg: `[CDN] Tokyo Edge cache hit ratio steady at 96.4% (1.24 Tbps)` },
        { type: 'success' as const, msg: `[Buffer] Lookahead buffer healthy at ${(5 + Math.random() * 4).toFixed(1)}s` },
        { type: 'info' as const, msg: `[ABR] CMAF segment chunk transfer latency 14ms` },
        { type: 'success' as const, msg: `[DRM] Apple FairPlay KSM token renewed successfully` },
      ];
      const event = randomEvents[Math.floor(Math.random() * randomEvents.length)];
      setTelemetryLogs((prev) => [
        { id: Date.now().toString(), time: now, type: event.type, msg: event.msg },
        ...prev.slice(0, 7),
      ]);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex-1 flex flex-col xl:flex-row overflow-hidden bg-[#0A0A0B]">
      
      {/* Left Column: Core QoE KPIs, Latency Sparklines & Retention Funnel */}
      <section className="flex-1 flex flex-col p-4 sm:p-6 lg:p-8 overflow-y-auto custom-scrollbar space-y-6">
        <div className="w-full max-w-4xl mx-auto space-y-6">
          
          {/* Header Banner */}
          <div className="bg-[#0F0F11] p-5 rounded-xl border border-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-orange-500" />
                <h2 className="text-base font-bold text-white font-mono">
                  PLATFORM OBSERVABILITY & REAL-TIME QoE
                </h2>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Sub-second player telemetry, startup latency (TTFF), rebuffer percentages, and global edge cache hit metrics.
              </p>
            </div>

            <div className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider">
                Telemetry Ingest: 2,400 events/sec
              </span>
            </div>
          </div>

          {/* 4 Core QoE Metric Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* TTFF */}
            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-gray-500 uppercase font-mono font-bold">TTFF (Startup Latency)</span>
                <span className="text-[10px] font-mono text-emerald-400">Target &lt;500ms</span>
              </div>
              <div className="text-2xl font-mono text-white font-semibold">
                {qoeMetrics.ttffMs} <span className="text-xs text-gray-500">ms</span>
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min(100, (qoeMetrics.ttffMs / 500) * 100)}%` }} />
              </div>
            </div>

            {/* Rebuffer Rate */}
            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-gray-500 uppercase font-mono font-bold">Rebuffer Rate</span>
                <span className="text-[10px] font-mono text-emerald-400">Target &lt;0.5%</span>
              </div>
              <div className="text-2xl font-mono text-emerald-400 font-semibold">
                {qoeMetrics.rebufferRate}%
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min(100, (qoeMetrics.rebufferRate / 0.5) * 100)}%` }} />
              </div>
            </div>

            {/* VPF Index */}
            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-gray-500 uppercase font-mono font-bold">VPF (Playback Failure)</span>
                <span className="text-[10px] font-mono text-emerald-400">Target &lt;0.1%</span>
              </div>
              <div className="text-2xl font-mono text-white font-semibold">
                {qoeMetrics.vpfRate}%
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: '40%' }} />
              </div>
            </div>

            {/* Buffer Lookahead */}
            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-gray-500 uppercase font-mono font-bold">Buffer Lookahead</span>
                <span className="text-[10px] font-mono text-orange-400">Healthy</span>
              </div>
              <div className="text-2xl font-mono text-orange-400 font-semibold">
                {qoeMetrics.bufferLengthSec} <span className="text-xs text-gray-500">sec</span>
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-orange-500 rounded-full" style={{ width: `${Math.min(100, (qoeMetrics.bufferLengthSec / 10) * 100)}%` }} />
              </div>
            </div>

          </div>

          {/* Real-Time QoE Latency Trend Chart */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xs font-mono font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-orange-500" />
                Time to First Frame (TTFF) & Global Cache Hit Ratio
              </h3>
              <span className="text-[10px] font-mono text-emerald-400">Past 6 Hours</span>
            </div>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="ttffGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#F97316" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#F97316" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                  <XAxis dataKey="time" stroke="#6b7280" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                  <YAxis stroke="#6b7280" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#16161A', borderColor: '#ffffff20', borderRadius: '8px', fontSize: '12px' }} 
                  />
                  <Area type="monotone" dataKey="ttff" name="TTFF (ms)" stroke="#F97316" strokeWidth={2} fillOpacity={1} fill="url(#ttffGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Audience Retention Curve & Video Completion Funnel */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-6">
            <h3 className="text-xs font-mono font-bold text-gray-300 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-orange-500" />
              Audience Retention Funnel (25%, 50%, 75%, 100% Milestones)
            </h3>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={retentionData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                  <XAxis dataKey="stage" stroke="#6b7280" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                  <YAxis stroke="#6b7280" tick={{ fontSize: 11, fill: '#9ca3af' }} tickFormatter={(v) => `${v}%`} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#16161A', borderColor: '#ffffff20', borderRadius: '8px', fontSize: '12px' }}
                    formatter={(val: any) => [`${val}% Retention`, 'Audience']}
                  />
                  <Bar dataKey="retention" fill="#10B981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>
      </section>

      {/* Right Column: Global CDN Edge Node Matrix & Live Event Stream */}
      <aside className="w-full xl:w-[380px] border-t xl:border-t-0 xl:border-l border-white/5 bg-[#0F0F11] p-5 lg:p-6 overflow-y-auto shrink-0 custom-scrollbar space-y-6">
        
        <div>
          <span className="text-[10px] font-mono text-orange-400 uppercase font-bold tracking-wider">
            Global Edge Node Matrix
          </span>
          <h3 className="text-sm font-bold text-white mt-1">
            CDN Edge Ingest & PoP Status
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            Multi-CDN routing across primary cloud edge PoPs with automatic failover.
          </p>
        </div>

        {/* Global Edge Node List */}
        <div className="space-y-2.5">
          {cdnNodes.map((node) => (
            <div key={node.id} className="p-3 bg-[#16161A] border border-white/5 rounded-lg text-xs font-mono">
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${node.status === 'optimal' ? 'bg-emerald-400' : 'bg-orange-400'}`}></span>
                  {node.city}
                </span>
                <span className="text-orange-400 font-bold">{node.trafficTbps} Tbps</span>
              </div>
              <div className="flex justify-between text-[10px] text-gray-400">
                <span>Latency: {node.latencyMs}ms</span>
                <span className="text-emerald-400">Cache Hit: {node.cacheHitRatio}%</span>
              </div>
            </div>
          ))}
        </div>

        {/* Live Telemetry Log Stream */}
        <div className="bg-[#16161A] p-4 rounded-lg border border-white/5 space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono font-bold text-gray-300 uppercase flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-orange-500" />
              Live Telemetry Feed
            </span>
            <span className="text-[9px] font-mono text-emerald-400 animate-pulse">STREAMING</span>
          </div>

          <div className="space-y-2 text-[10px] font-mono max-h-56 overflow-y-auto custom-scrollbar">
            {telemetryLogs.map((log) => (
              <div key={log.id} className="p-2 rounded bg-black/40 border border-white/5 leading-relaxed">
                <div className="flex justify-between text-gray-500 mb-0.5">
                  <span>{log.time}</span>
                  <span className={log.type === 'success' ? 'text-emerald-400' : 'text-blue-400'}>
                    {log.type.toUpperCase()}
                  </span>
                </div>
                <div className="text-gray-300">{log.msg}</div>
              </div>
            ))}
          </div>
        </div>

      </aside>

    </div>
  );
};
