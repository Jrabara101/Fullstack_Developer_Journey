import React, { useState } from 'react';
import { DRMTier } from '../../types/video';
import { 
  ShieldCheck, 
  Key, 
  Lock, 
  Unlock, 
  Globe, 
  EyeOff, 
  AlertTriangle, 
  CheckCircle2, 
  FileCheck, 
  Terminal, 
  Copy, 
  Check, 
  Zap,
  Server
} from 'lucide-react';

export const SecurityCenter: React.FC = () => {
  const [activeTier, setActiveTier] = useState<DRMTier>('high');
  const [tokenExpiryHours, setTokenExpiryHours] = useState<number>(2);
  const [clientIpRestriction, setClientIpRestriction] = useState<string>('192.168.1.104');
  const [allowedOrigins, setAllowedOrigins] = useState<string>('https://app.vnexus.io, https://stream.vnexus.io');
  const [watermarkEnabled, setWatermarkEnabled] = useState<boolean>(true);
  const [watermarkText, setWatermarkText] = useState<string>('USER#9257 - CONFIDENTIAL');
  
  // Generated Token Output
  const [copiedToken, setCopiedToken] = useState<boolean>(false);
  const [simulatedScanRunning, setSimulatedScanRunning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<{
    status: 'clean' | 'flagged';
    timestamp: string;
    audioToxicity: number;
    visualExplicit: number;
    copyrightFingerprint: string;
    verdict: string;
  }>({
    status: 'clean',
    timestamp: new Date().toLocaleTimeString(),
    audioToxicity: 0.02,
    visualExplicit: 0.00,
    copyrightFingerprint: 'No Match (100% Original Audio)',
    verdict: 'Approved for Global Multi-Region CDN Ingestion',
  });

  const generatedToken = `v-tok_sec_${activeTier}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 8)}?exp=${Date.now() + tokenExpiryHours * 3600000}&ip=${clientIpRestriction}&hmac=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`;

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedToken);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const handleRunModerationScan = () => {
    setSimulatedScanRunning(true);
    setTimeout(() => {
      setSimulatedScanRunning(false);
      setScanResult({
        status: 'clean',
        timestamp: new Date().toLocaleTimeString(),
        audioToxicity: 0.01,
        visualExplicit: 0.00,
        copyrightFingerprint: 'Cleared (Acoustic Hash Match 0.0%)',
        verdict: 'Automated AI Content Moderation Passed',
      });
    }, 1200);
  };

  return (
    <div className="flex-1 flex flex-col xl:flex-row overflow-hidden bg-[#0A0A0B]">
      
      {/* Left Column: Security Tier Matrix & Signed Token Forge */}
      <section className="flex-1 flex flex-col p-4 sm:p-6 lg:p-8 overflow-y-auto custom-scrollbar space-y-6">
        <div className="w-full max-w-4xl mx-auto space-y-6">
          
          {/* Header Banner */}
          <div className="bg-[#0F0F11] p-5 rounded-xl border border-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-orange-500" />
                <h2 className="text-base font-bold text-white font-mono">
                  CONTENT SECURITY, TRUST & RIGHTS
                </h2>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Layered authorization models: Public CDN, HMAC-SHA256 Signed URLs, and Multi-DRM (Widevine, FairPlay, PlayReady).
              </p>
            </div>

            {/* DRM Health Pill */}
            <div className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider">
                DRM Key Servers: ONLINE
              </span>
            </div>
          </div>

          {/* 3-Tier Security Architecture Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Low Security */}
            <div
              onClick={() => setActiveTier('low')}
              className={`p-5 rounded-xl border cursor-pointer transition-all ${
                activeTier === 'low'
                  ? 'bg-orange-500/10 border-orange-500/50 shadow-lg'
                  : 'bg-[#0F0F11] border-white/5 hover:border-white/20'
              }`}
            >
              <div className="flex justify-between items-center mb-2">
                <div className="w-8 h-8 rounded-lg bg-[#16161A] border border-white/10 flex items-center justify-center text-gray-300">
                  <Globe className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono uppercase text-gray-400 font-bold">Tier 1</span>
              </div>
              <h3 className="text-sm font-bold text-white mb-1">Low Security</h3>
              <p className="text-[11px] text-gray-400 leading-relaxed mb-3">
                Public CDN distribution without auth tokens. Ideal for social, trailers, and viral marketing.
              </p>
              <div className="text-[10px] font-mono text-gray-400 space-y-1">
                <div>• Zero DRM overhead</div>
                <div>• Max CDN edge cacheability</div>
                <div>• Tokenless playback</div>
              </div>
            </div>

            {/* Medium Security */}
            <div
              onClick={() => setActiveTier('medium')}
              className={`p-5 rounded-xl border cursor-pointer transition-all ${
                activeTier === 'medium'
                  ? 'bg-orange-500/10 border-orange-500/50 shadow-lg'
                  : 'bg-[#0F0F11] border-white/5 hover:border-white/20'
              }`}
            >
              <div className="flex justify-between items-center mb-2">
                <div className="w-8 h-8 rounded-lg bg-[#16161A] border border-white/10 flex items-center justify-center text-orange-400">
                  <Key className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono uppercase text-orange-400 font-bold">Tier 2</span>
              </div>
              <h3 className="text-sm font-bold text-white mb-1">Signed Tokens & URLs</h3>
              <p className="text-[11px] text-gray-400 leading-relaxed mb-3">
                HMAC-SHA256 signed playback tokens, short-lived cookies, IP and CORS domain restrictions.
              </p>
              <div className="text-[10px] font-mono text-orange-400/90 space-y-1">
                <div>• 2-Hour TTL expiration</div>
                <div>• CORS origin locking</div>
                <div>• Client IP validation</div>
              </div>
            </div>

            {/* High Security */}
            <div
              onClick={() => setActiveTier('high')}
              className={`p-5 rounded-xl border cursor-pointer transition-all ${
                activeTier === 'high'
                  ? 'bg-orange-500/10 border-orange-500/50 shadow-lg'
                  : 'bg-[#0F0F11] border-white/5 hover:border-white/20'
              }`}
            >
              <div className="flex justify-between items-center mb-2">
                <div className="w-8 h-8 rounded-lg bg-[#16161A] border border-white/10 flex items-center justify-center text-blue-400">
                  <Lock className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono uppercase text-blue-400 font-bold">Tier 3</span>
              </div>
              <h3 className="text-sm font-bold text-white mb-1">Multi-DRM Enterprise</h3>
              <p className="text-[11px] text-gray-400 leading-relaxed mb-3">
                Full hardware decryption pipeline preventing screen-ripping and unauthorized stream copying.
              </p>
              <div className="text-[10px] font-mono text-blue-400/90 space-y-1">
                <div>• Google Widevine (L1/L3)</div>
                <div>• Apple FairPlay (CMAF)</div>
                <div>• MS PlayReady + HDCP 2.2</div>
              </div>
            </div>

          </div>

          {/* Interactive Playback Token Forge & Validator */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-6 space-y-5">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-mono font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                <Terminal className="w-4 h-4 text-orange-500" />
                Signed Token & CORS Lock Forge
              </h3>
              <span className="text-[10px] font-mono text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                Algorithm: HMAC-SHA256
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
              <div>
                <label className="text-gray-400 block mb-1">Token TTL Expiry:</label>
                <select
                  value={tokenExpiryHours}
                  onChange={(e) => setTokenExpiryHours(parseInt(e.target.value, 10))}
                  className="w-full bg-[#16161A] border border-white/10 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                >
                  <option value={1}>1 Hour (Strict)</option>
                  <option value={2}>2 Hours (Standard)</option>
                  <option value={6}>6 Hours (Binge Session)</option>
                  <option value={24}>24 Hours (Offline Cache)</option>
                </select>
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Client IP Restriction:</label>
                <input
                  type="text"
                  value={clientIpRestriction}
                  onChange={(e) => setClientIpRestriction(e.target.value)}
                  className="w-full bg-[#16161A] border border-white/10 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-gray-400 block mb-1">Forensic Watermarking:</label>
                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="checkbox"
                    checked={watermarkEnabled}
                    onChange={(e) => setWatermarkEnabled(e.target.checked)}
                    className="accent-orange-500"
                  />
                  <span className="text-gray-300">Burn Client ID into Video</span>
                </div>
              </div>
            </div>

            {/* Generated Token Terminal Output */}
            <div className="bg-[#050505] p-4 rounded-lg border border-white/10 font-mono text-xs relative group">
              <div className="flex justify-between items-center text-gray-500 text-[10px] mb-2">
                <span>ACTIVE_SECURE_PLAYBACK_URL:</span>
                <button
                  id="btn-copy-token"
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-orange-400 hover:text-white px-2 py-0.5 rounded bg-white/5 border border-white/10"
                >
                  {copiedToken ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedToken ? 'Copied' : 'Copy Signed URL'}</span>
                </button>
              </div>
              <div className="text-orange-400/90 break-all leading-relaxed select-all">
                https://edge.vnexus.io/manifest.m3u8?{generatedToken}
              </div>
            </div>
          </div>

          {/* Automated AI Moderation Live Inspector */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-mono font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                Automated Ingestion Moderation Engine
              </h3>
              <button
                id="btn-run-moderation-scan"
                onClick={handleRunModerationScan}
                disabled={simulatedScanRunning}
                className="px-3 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-semibold rounded flex items-center gap-1.5 transition-all"
              >
                <Zap className={`w-3.5 h-3.5 ${simulatedScanRunning ? 'animate-spin' : ''}`} />
                {simulatedScanRunning ? 'Scanning Video Frames...' : 'Trigger Deep AI Scan'}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
              <div className="bg-[#16161A] p-3 rounded-lg border border-white/5">
                <div className="text-gray-500 text-[10px] uppercase">Audio Speech Safety</div>
                <div className="text-emerald-400 font-bold text-sm mt-1">
                  {(100 - scanResult.audioToxicity * 100).toFixed(1)}% Safe
                </div>
                <div className="text-[10px] text-gray-500 mt-0.5">Zero hate speech or policy flags</div>
              </div>

              <div className="bg-[#16161A] p-3 rounded-lg border border-white/5">
                <div className="text-gray-500 text-[10px] uppercase">Visual Frame Scanner</div>
                <div className="text-emerald-400 font-bold text-sm mt-1">
                  {(100 - scanResult.visualExplicit * 100).toFixed(1)}% Safe
                </div>
                <div className="text-[10px] text-gray-500 mt-0.5">Zero explicit or violent frames</div>
              </div>

              <div className="bg-[#16161A] p-3 rounded-lg border border-white/5">
                <div className="text-gray-500 text-[10px] uppercase">Audio Copyright ID</div>
                <div className="text-blue-400 font-bold text-sm mt-1">Clean / Original</div>
                <div className="text-[10px] text-gray-500 mt-0.5">{scanResult.copyrightFingerprint}</div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Right Column: DRM Key Infrastructure & Enforcement Logs */}
      <aside className="w-full xl:w-[360px] border-t xl:border-t-0 xl:border-l border-white/5 bg-[#0F0F11] p-5 lg:p-6 overflow-y-auto shrink-0 custom-scrollbar space-y-6">
        
        <div>
          <span className="text-[10px] font-mono text-orange-400 uppercase font-bold tracking-wider">
            Multi-DRM Key Infrastructure
          </span>
          <h3 className="text-sm font-bold text-white mt-1">
            License Server Handshakes
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            Real-time verification across Apple FairPlay KMS, Google Widevine Modular, and PlayReady servers.
          </p>
        </div>

        {/* License Server Status List */}
        <div className="space-y-3">
          <div className="p-3 bg-[#16161A] border border-white/5 rounded-lg text-xs font-mono flex justify-between items-center">
            <div>
              <div className="font-bold text-white">Google Widevine Modular</div>
              <div className="text-[10px] text-gray-500">Security Level: L1 (Hardware Secure)</div>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-semibold">
              9ms Latency
            </span>
          </div>

          <div className="p-3 bg-[#16161A] border border-white/5 rounded-lg text-xs font-mono flex justify-between items-center">
            <div>
              <div className="font-bold text-white">Apple FairPlay (HLS)</div>
              <div className="text-[10px] text-gray-500">Key Server Module (KSM) Active</div>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-semibold">
              12ms Latency
            </span>
          </div>

          <div className="p-3 bg-[#16161A] border border-white/5 rounded-lg text-xs font-mono flex justify-between items-center">
            <div>
              <div className="font-bold text-white">Microsoft PlayReady</div>
              <div className="text-[10px] text-gray-500">HDCP 2.2 Output Protection</div>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-semibold">
              14ms Latency
            </span>
          </div>
        </div>

        {/* Forensic Watermarking Preview */}
        <div className="bg-[#16161A] p-4 rounded-lg border border-white/5 space-y-2">
          <div className="text-xs font-mono font-bold text-gray-300 uppercase">
            Forensic Watermark Burn-in
          </div>
          <div className="w-full h-24 bg-black rounded border border-white/10 relative flex items-center justify-center overflow-hidden">
            <div className="w-full h-full bg-gradient-to-tr from-gray-900 to-black opacity-60"></div>
            <div className="absolute font-mono text-[10px] text-white/30 tracking-widest rotate-[-12deg] pointer-events-none select-none font-bold">
              {watermarkText}
            </div>
          </div>
          <p className="text-[10px] text-gray-500 font-mono leading-relaxed">
            Invisible steganographic metadata embedded into video frames to track unauthorized leaks back to viewer account.
          </p>
        </div>

      </aside>

    </div>
  );
};
