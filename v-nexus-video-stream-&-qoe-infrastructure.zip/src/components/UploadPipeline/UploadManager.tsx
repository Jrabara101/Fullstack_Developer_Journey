import React, { useState, useEffect, useRef } from 'react';
import { 
  UploadJob, 
  UploadChunk, 
  UploadStage, 
  DRMTier, 
  VideoItem 
} from '../../types/video';
import { 
  UploadCloud, 
  Pause, 
  Play, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  FileVideo, 
  Cpu, 
  ShieldCheck, 
  Layers, 
  Clock, 
  Zap, 
  Sparkles, 
  Image as ImageIcon,
  Check,
  Server
} from 'lucide-react';

interface UploadManagerProps {
  onPublishVideo: (newVideo: VideoItem) => void;
}

export const UploadManager: React.FC<UploadManagerProps> = ({ onPublishVideo }) => {
  // Current active upload job state
  const [activeJob, setActiveJob] = useState<UploadJob>({
    id: 'job-9842',
    fileName: 'dev_master_build_4k.mp4',
    fileSizeMB: 1840, // 1.84 GB
    videoTitle: 'Next-Gen Edge Streaming Architecture Deep Dive',
    description: 'High-throughput direct-to-S3 chunked upload demo featuring Tus resumable protocol and automated multi-stage transcoding pipelines.',
    category: 'Engineering Architecture',
    tags: ['Tus Protocol', 'Chunked S3', 'Transcoding', 'DRM'],
    drmTier: 'high',
    totalChunks: 16,
    completedChunks: 16,
    chunks: Array.from({ length: 16 }, (_, i) => ({
      id: i + 1,
      startByte: i * 115 * 1024 * 1024,
      endByte: (i + 1) * 115 * 1024 * 1024,
      totalBytes: 115 * 1024 * 1024,
      progress: 100,
      status: 'completed',
    })),
    uploadProgress: 100,
    stage: 'transcoding_ladder',
    stageProgress: 72,
    stageMessage: 'Processing: 1080p HEVC & 4K AV1 (Step 2 of 4)',
    transcodeSpeedFps: 142.5,
    estimatedRemainingSec: 24,
    moderationResult: {
      audioSafetyScore: 99.8,
      visualSafetyScore: 99.9,
      copyrightClean: true,
      flags: ['Passed automated speech filter', 'Zero explicit visual frames', 'Audio signature verified'],
    },
  });

  // Upload simulation timer
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [simSpeedMultiplier, setSimSpeedMultiplier] = useState<number>(1);
  const [customThumbnailUrl, setCustomThumbnailUrl] = useState<string>('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80');

  // Job History
  const [completedJobs, setCompletedJobs] = useState<UploadJob[]>([
    {
      id: 'job-9839',
      fileName: 'product_demo_final_v4.mp4',
      fileSizeMB: 1240,
      videoTitle: 'Cloud Run Architecture & Distributed Transcoding Master',
      description: 'Production ready HLS package',
      category: 'Engineering Architecture',
      tags: ['Production', 'Master'],
      drmTier: 'high',
      totalChunks: 12,
      completedChunks: 12,
      chunks: [],
      uploadProgress: 100,
      stage: 'completed',
      stageProgress: 100,
      stageMessage: 'Published to Multi-Region CDN',
      transcodeSpeedFps: 160,
      estimatedRemainingSec: 0,
    },
  ]);

  // Handle stage progressions in simulation
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setActiveJob((prev) => {
        if (prev.stage === 'uploading') {
          // Progress chunks
          const unfinishedChunk = prev.chunks.find((c) => c.status !== 'completed');
          if (unfinishedChunk) {
            const nextProgress = Math.min(100, unfinishedChunk.progress + 25 * simSpeedMultiplier);
            const updatedChunks: UploadChunk[] = prev.chunks.map((c) =>
              c.id === unfinishedChunk.id
                ? {
                    ...c,
                    progress: nextProgress,
                    status: nextProgress >= 100 ? 'completed' : 'uploading',
                  }
                : c
            );
            const finishedCount = updatedChunks.filter((c) => c.status === 'completed').length;
            const overallProgress = Math.round((finishedCount / prev.totalChunks) * 100);

            return {
              ...prev,
              chunks: updatedChunks,
              completedChunks: finishedCount,
              uploadProgress: overallProgress,
              stage: finishedCount === prev.totalChunks ? 'transcoding_1080p' : 'uploading',
              stageProgress: finishedCount === prev.totalChunks ? 10 : overallProgress,
              stageMessage:
                finishedCount === prev.totalChunks
                  ? 'Upload Complete (100%). Initializing GPU workers...'
                  : `Uploading chunk ${unfinishedChunk.id} of ${prev.totalChunks} (Direct-to-S3 Resumable)...`,
            };
          }
        }

        if (prev.stage === 'transcoding_1080p' || prev.stage === 'transcoding_ladder') {
          const nextProg = prev.stageProgress + 4 * simSpeedMultiplier;
          if (nextProg >= 100) {
            return {
              ...prev,
              stage: 'extracting_thumbnails',
              stageProgress: 0,
              stageMessage: 'Extracting storyboard sprites & AI frame analysis (Step 3 of 4)...',
              estimatedRemainingSec: 12,
            };
          }
          return {
            ...prev,
            stage: 'transcoding_ladder',
            stageProgress: nextProg,
            stageMessage: `Generating ABR Matrix: 4K AV1, 1080p HEVC, 720p H.264 (${Math.round(nextProg)}% @ ${prev.transcodeSpeedFps} fps)...`,
            estimatedRemainingSec: Math.max(1, Math.round((100 - nextProg) / 3)),
          };
        }

        if (prev.stage === 'extracting_thumbnails') {
          const nextProg = prev.stageProgress + 8 * simSpeedMultiplier;
          if (nextProg >= 100) {
            return {
              ...prev,
              stage: 'ai_moderation',
              stageProgress: 0,
              stageMessage: 'AI Audio & Visual Content Moderation Scan (Step 3b of 4)...',
              estimatedRemainingSec: 6,
            };
          }
          return {
            ...prev,
            stageProgress: nextProg,
            stageMessage: `Extracting hover preview thumbnails (${Math.round(nextProg)}%)...`,
          };
        }

        if (prev.stage === 'ai_moderation') {
          const nextProg = prev.stageProgress + 12 * simSpeedMultiplier;
          if (nextProg >= 100) {
            return {
              ...prev,
              stage: 'packaging_hls',
              stageProgress: 0,
              stageMessage: 'Packaging HLS/CMAF Master Manifest & CDN Edge Pre-warming (Step 4 of 4)...',
              estimatedRemainingSec: 3,
            };
          }
          return {
            ...prev,
            stageProgress: nextProg,
            stageMessage: 'Automated policy scan: Audio toxicity 0%, Visual explicit 0% (Passing 99.8%)...',
          };
        }

        if (prev.stage === 'packaging_hls') {
          const nextProg = prev.stageProgress + 20 * simSpeedMultiplier;
          if (nextProg >= 100) {
            return {
              ...prev,
              stage: 'completed',
              stageProgress: 100,
              stageMessage: 'Processing Complete! Ready to publish or stream.',
              estimatedRemainingSec: 0,
            };
          }
          return {
            ...prev,
            stageProgress: nextProg,
            stageMessage: `Pre-populating edge caches in Tokyo, London, N. Virginia (${Math.round(nextProg)}%)...`,
          };
        }

        return prev;
      });
    }, 800);

    return () => clearInterval(interval);
  }, [isSimulating, simSpeedMultiplier]);

  // Start fresh upload test
  const handleStartNewUpload = () => {
    const total = 12;
    const newJob: UploadJob = {
      id: `job-${Math.floor(1000 + Math.random() * 9000)}`,
      fileName: 'cinematic_8k_nature_stream.mp4',
      fileSizeMB: 2450, // 2.45 GB
      videoTitle: 'Ultra HDR Wide-Gamut Production Reel',
      description: 'Direct-to-S3 multi-part chunked upload with automated Widevine & FairPlay encryption packaging.',
      category: 'Cinematic Masters',
      tags: ['4K', 'HDR10', 'AV1', 'Widevine'],
      drmTier: 'high',
      totalChunks: total,
      completedChunks: 0,
      chunks: Array.from({ length: total }, (_, i) => ({
        id: i + 1,
        startByte: i * 200 * 1024 * 1024,
        endByte: (i + 1) * 200 * 1024 * 1024,
        totalBytes: 200 * 1024 * 1024,
        progress: 0,
        status: 'pending',
      })),
      uploadProgress: 0,
      stage: 'uploading',
      stageProgress: 0,
      stageMessage: 'Uploading chunk 1 of 12 (Direct-to-S3 Resumable)...',
      transcodeSpeedFps: 154,
      estimatedRemainingSec: 45,
      moderationResult: {
        audioSafetyScore: 100,
        visualSafetyScore: 99.9,
        copyrightClean: true,
        flags: ['Automated safety clearance verified'],
      },
    };
    setActiveJob(newJob);
    setIsSimulating(true);
  };

  // Simulate network disruption on chunk
  const handleSimulateChunkFailure = () => {
    setActiveJob((prev) => {
      const currentChunk = prev.chunks.find((c) => c.status === 'uploading' || c.status === 'pending');
      if (!currentChunk) return prev;
      const updated = prev.chunks.map((c) =>
        c.id === currentChunk.id
          ? { ...c, status: 'retrying' as const, progress: 10 }
          : c
      );
      return {
        ...prev,
        chunks: updated,
        stageMessage: `Network dropped on Chunk #${currentChunk.id}. Auto-retrying via Tus protocol without restarting entire file...`,
      };
    });
  };

  // Publish active job to live player
  const handlePublish = () => {
    const newVideo: VideoItem = {
      id: `vid-${Date.now()}`,
      title: activeJob.videoTitle || 'New Transcoded Stream',
      filename: activeJob.fileName,
      duration: 540,
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      posterUrl: customThumbnailUrl,
      description: activeJob.description,
      category: activeJob.category,
      tags: activeJob.tags,
      views: 1,
      drmTier: activeJob.drmTier,
      securityToken: `v-tok_${Math.random().toString(36).substring(7)}`,
      renditions: [
        {
          label: '2160p (4K)',
          resolution: '3840x2160',
          bitrateKbps: 12000,
          codec: 'AV1',
          fps: 60,
          audioBitrateKbps: 320,
          bandwidthRequirementMbps: 16.0,
        },
        {
          label: '1080p',
          resolution: '1920x1080',
          bitrateKbps: 4500,
          codec: 'HEVC (H.265)',
          fps: 60,
          audioBitrateKbps: 192,
          bandwidthRequirementMbps: 5.8,
        },
      ],
      currentRendition: 'Auto',
      thumbnails: [
        { time: 30, label: '00:30 Chapter 1', previewColor: '#1e1b4b' },
        { time: 150, label: '02:30 Processing Node', previewColor: '#0f172a' },
      ],
      captions: [
        {
          lang: 'en',
          label: 'English [Auto-VTT]',
          cues: [{ start: 0, end: 10, text: 'This video was ingested via Tus resumable protocol and transcoded in real-time.' }],
        },
      ],
    };
    onPublishVideo(newVideo);
    setCompletedJobs((prev) => [activeJob, ...prev]);
  };

  return (
    <div className="flex-1 flex flex-col xl:flex-row overflow-hidden bg-[#0A0A0B]">
      
      {/* Left Column: Active Ingestion & Multi-Stage Transcoding Monitor */}
      <section className="flex-1 flex flex-col p-4 sm:p-6 lg:p-8 overflow-y-auto custom-scrollbar">
        <div className="w-full max-w-4xl mx-auto space-y-6">
          
          {/* Header Action Banner */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#0F0F11] p-5 rounded-xl border border-white/5">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
                <h2 className="text-base font-bold text-white font-mono">
                  RESUMABLE INGESTION PIPELINE
                </h2>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Direct-to-S3 multipart upload with background ABR transcoding matrix and automated AI moderation.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="btn-simulate-disruption"
                onClick={handleSimulateChunkFailure}
                className="px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all"
                title="Simulate network disconnect on a chunk to test Tus resilience"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                Simulate Chunk Failure
              </button>

              <button
                id="btn-new-upload-test"
                onClick={handleStartNewUpload}
                className="px-3 py-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600 text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-orange-500/20 transition-all"
              >
                <UploadCloud className="w-3.5 h-3.5" />
                Test New 2.5GB Upload
              </button>
            </div>
          </div>

          {/* Active Upload Card with Multi-Stage Progress */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-6 space-y-6">
            
            {/* File & Stage Top Bar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-4 border-b border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#16161A] border border-white/10 flex items-center justify-center text-orange-400 shrink-0">
                  <FileVideo className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white flex items-center gap-2">
                    {activeJob.fileName}
                    <span className="text-[10px] px-2 py-0.5 rounded bg-gray-800 text-gray-300 font-mono">
                      {(activeJob.fileSizeMB / 1024).toFixed(2)} GB
                    </span>
                  </div>
                  <div className="text-xs text-orange-400 font-mono mt-0.5 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-orange-500" />
                    {activeJob.stageMessage}
                  </div>
                </div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-gray-400">
                  {activeJob.estimatedRemainingSec > 0 ? `ETA: ${activeJob.estimatedRemainingSec}s` : 'Ready'}
                </span>
                <span className={`px-2.5 py-1 rounded text-[11px] font-mono font-bold uppercase ${
                  activeJob.stage === 'completed'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                }`}>
                  {activeJob.stage.replace('_', ' ')}
                </span>
              </div>
            </div>

            {/* Visual Step-by-Step Pipeline Tracker */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              
              {/* Step 1 */}
              <div className={`p-3 rounded-lg border text-xs ${
                activeJob.uploadProgress === 100 
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                  : 'bg-[#16161A] border-orange-500/40 text-orange-400'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono font-bold">1. S3 Chunk Ingest</span>
                  {activeJob.uploadProgress === 100 ? <Check className="w-3.5 h-3.5" /> : <span>{activeJob.uploadProgress}%</span>}
                </div>
                <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 transition-all" style={{ width: `${activeJob.uploadProgress}%` }} />
                </div>
              </div>

              {/* Step 2 */}
              <div className={`p-3 rounded-lg border text-xs ${
                ['extracting_thumbnails', 'ai_moderation', 'packaging_hls', 'completed'].includes(activeJob.stage)
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                  : activeJob.stage === 'transcoding_ladder' || activeJob.stage === 'transcoding_1080p'
                  ? 'bg-[#16161A] border-orange-500/40 text-orange-400'
                  : 'bg-[#16161A] border-white/5 text-gray-500'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono font-bold">2. ABR Transcode</span>
                  <span className="text-[10px]">{activeJob.stage === 'transcoding_ladder' ? `${Math.round(activeJob.stageProgress)}%` : activeJob.stage === 'completed' ? '100%' : 'Pending'}</span>
                </div>
                <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-orange-500 transition-all" 
                    style={{ width: `${['extracting_thumbnails', 'ai_moderation', 'packaging_hls', 'completed'].includes(activeJob.stage) ? 100 : activeJob.stage === 'transcoding_ladder' ? activeJob.stageProgress : 0}%` }} 
                  />
                </div>
              </div>

              {/* Step 3 */}
              <div className={`p-3 rounded-lg border text-xs ${
                ['packaging_hls', 'completed'].includes(activeJob.stage)
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                  : ['extracting_thumbnails', 'ai_moderation'].includes(activeJob.stage)
                  ? 'bg-[#16161A] border-orange-500/40 text-orange-400'
                  : 'bg-[#16161A] border-white/5 text-gray-500'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono font-bold">3. Sprites & Mod</span>
                  <span className="text-[10px]">{['packaging_hls', 'completed'].includes(activeJob.stage) ? 'Pass (99.8%)' : ['extracting_thumbnails', 'ai_moderation'].includes(activeJob.stage) ? 'Scanning' : 'Queued'}</span>
                </div>
                <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-500 transition-all" 
                    style={{ width: `${['packaging_hls', 'completed'].includes(activeJob.stage) ? 100 : ['extracting_thumbnails', 'ai_moderation'].includes(activeJob.stage) ? activeJob.stageProgress : 0}%` }} 
                  />
                </div>
              </div>

              {/* Step 4 */}
              <div className={`p-3 rounded-lg border text-xs ${
                activeJob.stage === 'completed'
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                  : activeJob.stage === 'packaging_hls'
                  ? 'bg-[#16161A] border-orange-500/40 text-orange-400'
                  : 'bg-[#16161A] border-white/5 text-gray-500'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono font-bold">4. CDN Manifest</span>
                  <span className="text-[10px]">{activeJob.stage === 'completed' ? 'Live Ready' : activeJob.stage === 'packaging_hls' ? 'Pre-warming' : 'Queued'}</span>
                </div>
                <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 transition-all" style={{ width: `${activeJob.stage === 'completed' ? 100 : activeJob.stage === 'packaging_hls' ? activeJob.stageProgress : 0}%` }} />
                </div>
              </div>

            </div>

            {/* Tus / S3 Chunk Resiliency Grid Simulator */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-[11px] text-gray-400 font-mono font-bold uppercase tracking-wider">
                  Chunked Multipart Transfer Matrix ({activeJob.completedChunks} / {activeJob.totalChunks} Chunks)
                </span>
                <span className="text-[10px] font-mono text-gray-500">
                  Tus Protocol Chunk Size: ~115 MB / chunk
                </span>
              </div>

              <div className="grid grid-cols-8 sm:grid-cols-16 gap-1.5 p-3 bg-[#16161A] rounded-lg border border-white/5">
                {activeJob.chunks.map((chunk) => (
                  <div
                    key={chunk.id}
                    className={`h-8 rounded flex flex-col items-center justify-center text-[9px] font-mono font-bold border transition-all ${
                      chunk.status === 'completed'
                        ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                        : chunk.status === 'uploading'
                        ? 'bg-orange-500/20 border-orange-500/50 text-orange-400 animate-pulse'
                        : chunk.status === 'retrying'
                        ? 'bg-red-500/20 border-red-500/50 text-red-400 animate-bounce'
                        : 'bg-gray-900 border-white/5 text-gray-600'
                    }`}
                    title={`Chunk #${chunk.id} (${chunk.status.toUpperCase()})`}
                  >
                    #{chunk.id}
                  </div>
                ))}
              </div>
            </div>

            {/* AI Moderation & Automated Audio/Visual Safety Scan Report */}
            {activeJob.moderationResult && (
              <div className="bg-[#16161A] p-4 rounded-lg border border-white/5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-gray-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Automated Ingestion Safety & Rights Verification
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-semibold">
                    Score: 99.8% Passed
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] font-mono pt-1">
                  <div className="bg-black/40 p-2 rounded border border-white/5 flex justify-between">
                    <span className="text-gray-500">Audio Speech Toxicity:</span>
                    <span className="text-emerald-400">0.0% Safe</span>
                  </div>
                  <div className="bg-black/40 p-2 rounded border border-white/5 flex justify-between">
                    <span className="text-gray-500">Visual Explicit Frames:</span>
                    <span className="text-emerald-400">0.0% Clean</span>
                  </div>
                  <div className="bg-black/40 p-2 rounded border border-white/5 flex justify-between">
                    <span className="text-gray-500">Audio Fingerprint:</span>
                    <span className="text-emerald-400">No Match (Clean)</span>
                  </div>
                </div>
              </div>
            )}

            {/* Publish Button */}
            {activeJob.stage === 'completed' && (
              <div className="pt-2 flex justify-end">
                <button
                  id="btn-publish-video"
                  onClick={handlePublish}
                  className="px-6 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-current" />
                  Publish Stream to Live Player & Catalog
                </button>
              </div>
            )}

          </div>

          {/* Upload History / Pipeline Jobs */}
          <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-5">
            <h3 className="text-xs font-mono font-bold text-gray-400 uppercase mb-3 tracking-wider">
              Recent Ingestion Queue & Archives
            </h3>
            <div className="space-y-2">
              {completedJobs.map((job) => (
                <div key={job.id} className="p-3 bg-[#16161A] border border-white/5 rounded-lg flex justify-between items-center text-xs">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-white">{job.videoTitle}</div>
                      <div className="text-[10px] text-gray-500 font-mono">{job.fileName} • {(job.fileSizeMB / 1024).toFixed(2)} GB • DRM {job.drmTier}</div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Active on Global CDN
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </section>

      {/* Right Column: Decoupled Form Metadata (Title, Description, Tags, DRM) */}
      <aside className="w-full xl:w-[380px] border-t xl:border-t-0 xl:border-l border-white/5 bg-[#0F0F11] p-5 lg:p-6 overflow-y-auto shrink-0 custom-scrollbar space-y-5">
        
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono text-orange-400 uppercase font-bold tracking-wider">
              Decoupled Metadata Layer
            </span>
          </div>
          <h3 className="text-sm font-bold text-white">
            Video Details & Publishing Config
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            Fill in metadata and custom poster artwork freely without waiting for the background GPU transcoding pipeline to complete.
          </p>
        </div>

        {/* Title Input */}
        <div>
          <label className="text-[11px] font-mono text-gray-400 font-semibold block mb-1.5">
            Video Title
          </label>
          <input
            id="input-video-title"
            type="text"
            value={activeJob.videoTitle}
            onChange={(e) => setActiveJob({ ...activeJob, videoTitle: e.target.value })}
            placeholder="e.g. Distributed Video Transcoding at Scale"
            className="w-full bg-[#16161A] border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Description Input */}
        <div>
          <label className="text-[11px] font-mono text-gray-400 font-semibold block mb-1.5">
            Description
          </label>
          <textarea
            id="input-video-desc"
            rows={3}
            value={activeJob.description}
            onChange={(e) => setActiveJob({ ...activeJob, description: e.target.value })}
            placeholder="Provide video summary, chapter breakdown, and technical notes..."
            className="w-full bg-[#16161A] border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-orange-500 resize-none"
          />
        </div>

        {/* Category & Tags */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[11px] font-mono text-gray-400 font-semibold block mb-1.5">
              Category
            </label>
            <select
              id="select-video-category"
              value={activeJob.category}
              onChange={(e) => setActiveJob({ ...activeJob, category: e.target.value })}
              className="w-full bg-[#16161A] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="Engineering Architecture">Engineering</option>
              <option value="Cinematic Masters">Cinematics</option>
              <option value="Live & Gaming">Live & Esports</option>
              <option value="Enterprise SaaS">Enterprise B2B</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-mono text-gray-400 font-semibold block mb-1.5">
              DRM Protection Tier
            </label>
            <select
              id="select-video-drm-tier"
              value={activeJob.drmTier}
              onChange={(e) => setActiveJob({ ...activeJob, drmTier: e.target.value as DRMTier })}
              className="w-full bg-[#16161A] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500 cursor-pointer font-mono"
            >
              <option value="low">Low (Public CDN)</option>
              <option value="medium">Medium (Signed Token)</option>
              <option value="high">High (Multi-DRM Widevine)</option>
            </select>
          </div>
        </div>

        {/* Thumbnail Selector */}
        <div>
          <label className="text-[11px] font-mono text-gray-400 font-semibold block mb-1.5">
            Custom Poster Frame / Thumbnail URL
          </label>
          <div className="flex gap-2">
            <input
              id="input-thumbnail-url"
              type="text"
              value={customThumbnailUrl}
              onChange={(e) => setCustomThumbnailUrl(e.target.value)}
              className="flex-1 bg-[#16161A] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500 font-mono"
            />
          </div>
          {customThumbnailUrl && (
            <div className="mt-2 w-full h-24 rounded-lg overflow-hidden border border-white/10 bg-black">
              <img src={customThumbnailUrl} alt="Preview Poster" className="w-full h-full object-cover" />
            </div>
          )}
        </div>

        {/* Transcoding Ladder Selection Matrix */}
        <div className="bg-[#16161A] p-3.5 rounded-lg border border-white/5 space-y-2">
          <div className="text-[11px] font-mono font-bold text-gray-300">
            Target Encoding Ladder Renditions
          </div>
          <div className="space-y-1 text-xs">
            <label className="flex items-center gap-2 text-gray-300">
              <input type="checkbox" defaultChecked disabled className="accent-orange-500" />
              <span>4K UHD AV1 (3840x2160 @ 12.5 Mbps)</span>
            </label>
            <label className="flex items-center gap-2 text-gray-300">
              <input type="checkbox" defaultChecked disabled className="accent-orange-500" />
              <span>1080p Full HD HEVC (1920x1080 @ 4.8 Mbps)</span>
            </label>
            <label className="flex items-center gap-2 text-gray-300">
              <input type="checkbox" defaultChecked disabled className="accent-orange-500" />
              <span>720p HD H.264 (1280x720 @ 2.4 Mbps)</span>
            </label>
            <label className="flex items-center gap-2 text-gray-300">
              <input type="checkbox" defaultChecked disabled className="accent-orange-500" />
              <span>480p / 360p Mobile Fallback (H.264 @ 800 Kbps)</span>
            </label>
          </div>
        </div>

      </aside>

    </div>
  );
};
