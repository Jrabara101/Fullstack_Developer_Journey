import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  VideoItem, 
  VideoQuality, 
  QualityRendition, 
  QoEMetrics 
} from '../../types/video';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  RotateCcw, 
  RotateCw, 
  Settings, 
  Subtitles, 
  PictureInPicture2, 
  Gauge, 
  Info, 
  Check, 
  Sliders, 
  Layers, 
  Radio, 
  Zap, 
  Sparkles,
  AlertTriangle,
  Flame,
  Activity
} from 'lucide-react';

interface VideoPlayerProps {
  currentVideo: VideoItem;
  onSelectVideo: (video: VideoItem) => void;
  allVideos: VideoItem[];
  networkCondition: 'optimal' | 'wifi' | 'cellular_4g' | 'congested_3g' | 'jitter';
  qoeMetrics: QoEMetrics;
  onUpdateQoE: (updater: (prev: QoEMetrics) => QoEMetrics) => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  currentVideo,
  onSelectVideo,
  allVideos,
  networkCondition,
  qoeMetrics,
  onUpdateQoE,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const scrubberRef = useRef<HTMLDivElement | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(currentVideo.duration || 760);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // ABR & Quality
  const [selectedQuality, setSelectedQuality] = useState<VideoQuality>('Auto');
  const [activeAutoRendition, setActiveAutoRendition] = useState<QualityRendition>(currentVideo.renditions[0]);
  const [showSettingsMenu, setShowSettingsMenu] = useState<boolean>(false);
  const [settingsTab, setSettingsTab] = useState<'main' | 'quality' | 'speed' | 'subtitles'>('main');

  // Subtitles
  const [selectedCaptionLang, setSelectedCaptionLang] = useState<string>('en');
  const [captionSize, setCaptionSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [currentCaptionText, setCurrentCaptionText] = useState<string>('');

  // Scrubber Hover Preview
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPositionPct, setHoverPositionPct] = useState<number>(0);

  // Hotkey Ripple Animation
  const [rippleAction, setRippleAction] = useState<{ text: string; direction: 'left' | 'right' | 'center'; key: number } | null>(null);

  // Stats for Nerds / QoE HUD Overlay
  const [showQoEOverlay, setShowQoEOverlay] = useState<boolean>(false);
  const [isBuffering, setIsBuffering] = useState<boolean>(false);

  // ABR Logic triggered by network condition changes
  useEffect(() => {
    let targetRendition = currentVideo.renditions[0]; // 4K default

    if (networkCondition === 'optimal') {
      targetRendition = currentVideo.renditions[0]; // 4K AV1
    } else if (networkCondition === 'wifi') {
      targetRendition = currentVideo.renditions[1]; // 1080p HEVC
    } else if (networkCondition === 'cellular_4g') {
      targetRendition = currentVideo.renditions[2]; // 720p H.264
    } else if (networkCondition === 'congested_3g') {
      targetRendition = currentVideo.renditions[4]; // 360p
    } else if (networkCondition === 'jitter') {
      targetRendition = currentVideo.renditions[3]; // 480p
    }

    setActiveAutoRendition(targetRendition);

    // Update QoE telemetry
    onUpdateQoE((prev) => ({
      ...prev,
      currentBitrateKbps: targetRendition.bitrateKbps,
      networkThroughputMbps: targetRendition.bandwidthRequirementMbps * (networkCondition === 'congested_3g' ? 0.7 : 1.4),
      cdnLatencyMs: networkCondition === 'congested_3g' ? 145 : networkCondition === 'jitter' ? 88 : 18,
      rebufferRate: networkCondition === 'congested_3g' ? 1.84 : networkCondition === 'jitter' ? 0.95 : 0.28,
    }));
  }, [networkCondition, currentVideo, onUpdateQoE]);

  // Handle Video Time Update & Captions
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const curr = videoRef.current.currentTime;
    setCurrentTime(curr);

    // Buffer calculation
    if (videoRef.current.buffered.length > 0) {
      const end = videoRef.current.buffered.end(videoRef.current.buffered.length - 1);
      const lookahead = Math.max(0, end - curr);
      onUpdateQoE((prev) => ({
        ...prev,
        bufferLengthSec: Number(lookahead.toFixed(1)),
      }));
    }

    // Sync active caption
    if (selectedCaptionLang !== 'off') {
      const track = currentVideo.captions.find((c) => c.lang === selectedCaptionLang);
      if (track) {
        const activeCue = track.cues.find((c) => curr >= c.start && curr <= c.end);
        setCurrentCaptionText(activeCue ? activeCue.text : '');
      } else {
        setCurrentCaptionText('');
      }
    } else {
      setCurrentCaptionText('');
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration || currentVideo.duration);
    }
  };

  const togglePlay = useCallback(() => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(() => {
        setIsPlaying(false);
      });
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  }, []);

  const triggerRipple = (text: string, direction: 'left' | 'right' | 'center') => {
    setRippleAction({ text, direction, key: Date.now() });
    setTimeout(() => {
      setRippleAction((curr) => (curr?.text === text ? null : curr));
    }, 700);
  };

  const seekRelative = useCallback((seconds: number) => {
    if (!videoRef.current) return;
    const target = Math.min(Math.max(0, videoRef.current.currentTime + seconds), duration);
    videoRef.current.currentTime = target;
    setCurrentTime(target);

    if (seconds < 0) {
      triggerRipple(`${seconds}s`, 'left');
    } else {
      triggerRipple(`+${seconds}s`, 'right');
    }
  }, [duration]);

  const toggleMute = () => {
    if (!videoRef.current) return;
    const newMuted = !isMuted;
    videoRef.current.muted = newMuted;
    setIsMuted(newMuted);
  };

  const handleVolumeChange = (newVol: number) => {
    if (!videoRef.current) return;
    videoRef.current.volume = newVol;
    setVolume(newVol);
    if (newVol > 0 && isMuted) {
      videoRef.current.muted = false;
      setIsMuted(false);
    }
  };

  const handlePlaybackRateChange = (rate: number) => {
    if (!videoRef.current) return;
    videoRef.current.playbackRate = rate;
    setPlaybackRate(rate);
    setShowSettingsMenu(false);
    triggerRipple(`${rate}x Speed`, 'center');
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const togglePiP = async () => {
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (err) {
      console.warn('PiP error', err);
    }
  };

  // Keyboard Hotkeys implementation (Space, K, J, L, M, F, C, Left/Right, Up/Down)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture when typing in inputs
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      switch (e.key.toLowerCase()) {
        case ' ':
        case 'k':
          e.preventDefault();
          togglePlay();
          break;
        case 'j':
          e.preventDefault();
          seekRelative(-10);
          break;
        case 'l':
          e.preventDefault();
          seekRelative(10);
          break;
        case 'arrowleft':
          e.preventDefault();
          seekRelative(-5);
          break;
        case 'arrowright':
          e.preventDefault();
          seekRelative(5);
          break;
        case 'arrowup':
          e.preventDefault();
          handleVolumeChange(Math.min(1, volume + 0.1));
          break;
        case 'arrowdown':
          e.preventDefault();
          handleVolumeChange(Math.max(0, volume - 0.1));
          break;
        case 'm':
          e.preventDefault();
          toggleMute();
          break;
        case 'f':
          e.preventDefault();
          toggleFullscreen();
          break;
        case 'c':
          e.preventDefault();
          setSelectedCaptionLang((prev) => (prev === 'off' ? 'en' : 'off'));
          break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
          if (videoRef.current) {
            const pct = parseInt(e.key, 10) / 10;
            const t = duration * pct;
            videoRef.current.currentTime = t;
            setCurrentTime(t);
            triggerRipple(`${pct * 100}%`, 'center');
          }
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePlay, seekRelative, volume, isMuted, duration]);

  // Scrubber Hover Handling
  const handleScrubberMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!scrubberRef.current) return;
    const rect = scrubberRef.current.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    setHoverPositionPct(pos * 100);
    setHoverTime(pos * duration);
  };

  const handleScrubberClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!scrubberRef.current || !videoRef.current) return;
    const rect = scrubberRef.current.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const target = pos * duration;
    videoRef.current.currentTime = target;
    setCurrentTime(target);
  };

  // Helper formatting mm:ss
  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Active rendition display
  const activeRendition = selectedQuality === 'Auto' 
    ? activeAutoRendition 
    : currentVideo.renditions.find((r) => r.label === selectedQuality) || currentVideo.renditions[0];

  const currentThumbnailPreview = currentVideo.thumbnails.reduce((prev, curr) => {
    if (hoverTime !== null && curr.time <= hoverTime) return curr;
    return prev;
  }, currentVideo.thumbnails[0]);

  return (
    <div className="flex-1 flex flex-col xl:flex-row overflow-hidden bg-[#0A0A0B]">
      {/* Main Video Viewport & Diagnostics */}
      <section className="flex-1 flex flex-col bg-[#050505] p-4 sm:p-6 lg:p-8 overflow-y-auto custom-scrollbar">
        <div className="w-full max-w-5xl mx-auto flex flex-col items-center">
          
          {/* Main Video Screen Container */}
          <div
            id="v-nexus-player-container"
            ref={containerRef}
            className="w-full aspect-video bg-black rounded-xl border border-white/10 shadow-2xl overflow-hidden relative group select-none flex items-center justify-center"
          >
            {/* HTML5 Video Element */}
            <video
              id="v-nexus-video-element"
              ref={videoRef}
              src={currentVideo.url}
              poster={currentVideo.posterUrl}
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onWaiting={() => setIsBuffering(true)}
              onPlaying={() => {
                setIsBuffering(false);
                setIsPlaying(true);
              }}
              onPause={() => setIsPlaying(false)}
              onClick={togglePlay}
              playsInline
              className="w-full h-full object-contain cursor-pointer"
            />

            {/* Top Bar Header Overlay */}
            <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent flex justify-between items-start opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-20">
              <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 pointer-events-auto">
                <div className="text-[10px] text-gray-400 uppercase font-mono font-bold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                  Preview Master Rendition
                </div>
                <div className="text-xs font-semibold text-white truncate max-w-md">
                  {currentVideo.filename}
                </div>
              </div>

              <div className="flex items-center gap-2 pointer-events-auto">
                {/* ABR Status Pill */}
                <div className="bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-md border border-orange-500/30 text-[10px] text-orange-400 font-mono flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse"></span>
                  {selectedQuality === 'Auto' ? `AUTO ${activeRendition.resolution.split('x')[1]}p (${activeRendition.codec})` : selectedQuality}
                </div>

                {/* DRM Badge */}
                <div className="bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-md border border-blue-500/30 text-[10px] text-blue-400 font-mono uppercase">
                  DRM: {currentVideo.drmTier}
                </div>

                {/* Stats for nerds toggle */}
                <button
                  id="toggle-qoe-overlay-btn"
                  onClick={() => setShowQoEOverlay(!showQoEOverlay)}
                  className={`p-1.5 rounded-md border transition-all ${
                    showQoEOverlay 
                      ? 'bg-orange-500 text-white border-orange-400' 
                      : 'bg-black/60 text-gray-300 border-white/10 hover:text-white hover:bg-white/10'
                  }`}
                  title="Toggle QoE Diagnostics HUD (Stats for Nerds)"
                >
                  <Gauge className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Buffering Spinner */}
            {isBuffering && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 backdrop-blur-xs pointer-events-none z-20">
                <div className="w-12 h-12 border-2 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-xs font-mono text-orange-400 mt-3 tracking-wider uppercase">
                  Rebuffering ABR Segments...
                </span>
              </div>
            )}

            {/* Center Play Button Overlay (when paused) */}
            {!isPlaying && !isBuffering && (
              <div 
                onClick={togglePlay}
                className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer z-10"
              >
                <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-2xl hover:scale-105 hover:bg-orange-500/80 transition-all">
                  <Play className="w-7 h-7 fill-current ml-1" />
                </div>
              </div>
            )}

            {/* Hotkey Visual Ripple Badges */}
            {rippleAction && (
              <div className={`absolute inset-y-0 flex items-center justify-center pointer-events-none z-30 transition-all ${
                rippleAction.direction === 'left' ? 'left-8' : rippleAction.direction === 'right' ? 'right-8' : 'inset-x-0'
              }`}>
                <div className="bg-black/80 border border-orange-500/50 backdrop-blur-md px-4 py-2 rounded-xl text-orange-400 font-mono font-bold text-sm shadow-2xl animate-ping flex items-center gap-2">
                  <Zap className="w-4 h-4 text-orange-500" />
                  {rippleAction.text}
                </div>
              </div>
            )}

            {/* Live Captions Rendering (VTT Display) */}
            {currentCaptionText && selectedCaptionLang !== 'off' && (
              <div className="absolute bottom-16 inset-x-8 text-center pointer-events-none z-20">
                <span className={`inline-block px-3 py-1 rounded bg-black/80 backdrop-blur-xs text-white border border-white/10 shadow-lg font-medium leading-relaxed ${
                  captionSize === 'small' ? 'text-xs' : captionSize === 'large' ? 'text-lg' : 'text-sm'
                }`}>
                  {currentCaptionText}
                </span>
              </div>
            )}

            {/* QoE Stats HUD Overlay (Stats for Nerds) */}
            {showQoEOverlay && (
              <div className="absolute top-14 left-4 w-80 bg-black/90 backdrop-blur-md border border-orange-500/30 rounded-lg p-3 text-[11px] font-mono text-gray-300 z-30 shadow-2xl space-y-1.5">
                <div className="flex justify-between items-center border-b border-white/10 pb-1 mb-2">
                  <span className="text-orange-400 font-bold flex items-center gap-1">
                    <Activity className="w-3 h-3 text-orange-500" /> QoE REAL-TIME ENGINE
                  </span>
                  <button 
                    onClick={() => setShowQoEOverlay(false)}
                    className="text-gray-500 hover:text-white"
                  >
                    ✕
                  </button>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Viewport / Rendition:</span>
                  <span className="text-white">{activeRendition.resolution} @ {activeRendition.fps}fps</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Current Codec:</span>
                  <span className="text-orange-400 font-semibold">{activeRendition.codec}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Bitrate:</span>
                  <span className="text-white">{activeRendition.bitrateKbps} Kbps ({activeRendition.bandwidthRequirementMbps} Mbps req)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Buffer Health:</span>
                  <span className="text-emerald-400 font-bold">{qoeMetrics.bufferLengthSec}s (Lookahead)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">TTFF (Time to 1st Frame):</span>
                  <span className="text-blue-400 font-bold">{qoeMetrics.ttffMs} ms</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Rebuffer Percentage:</span>
                  <span className="text-emerald-400">{qoeMetrics.rebufferRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Dropped Frames:</span>
                  <span className="text-white">{qoeMetrics.droppedFrames} / 0.01%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">CDN Edge / Latency:</span>
                  <span className="text-white">Tokyo (NRT) • {qoeMetrics.cdnLatencyMs}ms</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">DRM Security Token:</span>
                  <span className="text-emerald-400 truncate max-w-[140px]">{currentVideo.securityToken || 'Active-Pass'}</span>
                </div>
              </div>
            )}

            {/* Bottom Controls Bar Overlay */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/70 to-transparent px-4 pb-3 pt-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-20">
              
              {/* Interactive Timeline Scrubber with Hover Preview */}
              <div 
                ref={scrubberRef}
                onClick={handleScrubberClick}
                onMouseMove={handleScrubberMouseMove}
                onMouseLeave={() => setHoverTime(null)}
                className="w-full h-2 group/bar relative cursor-pointer flex items-center mb-3"
              >
                {/* Background Track */}
                <div className="w-full h-1 bg-white/20 group-hover/bar:h-2 rounded-full overflow-hidden transition-all relative">
                  {/* Buffer Progress bar */}
                  <div 
                    className="h-full bg-white/30 rounded-full transition-all"
                    style={{ width: `${Math.min(100, ((currentTime + qoeMetrics.bufferLengthSec) / duration) * 100)}%` }}
                  />
                  {/* Active Playhead Progress */}
                  <div 
                    className="h-full bg-orange-500 rounded-full absolute top-0 left-0"
                    style={{ width: `${(currentTime / duration) * 100}%` }}
                  />
                </div>

                {/* Scrubber Knob */}
                <div 
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-white rounded-full shadow-lg border border-orange-500 transition-transform group-hover/bar:scale-125"
                  style={{ left: `${(currentTime / duration) * 100}%` }}
                />

                {/* Hover Storyboard Preview Sprite Card */}
                {hoverTime !== null && (
                  <div 
                    className="absolute bottom-5 -translate-x-1/2 pointer-events-none transition-all z-30"
                    style={{ left: `${hoverPositionPct}%` }}
                  >
                    <div className="w-36 bg-[#16161A] border border-white/20 rounded-lg shadow-2xl p-1.5 flex flex-col items-center">
                      <div 
                        className="w-full h-20 rounded border border-white/10 flex items-center justify-center text-xs font-mono text-gray-300 mb-1"
                        style={{ backgroundColor: currentThumbnailPreview.previewColor }}
                      >
                        <span className="text-[10px] text-center px-1 font-semibold text-white/90">
                          {currentThumbnailPreview.label}
                        </span>
                      </div>
                      <div className="text-[11px] font-mono font-bold text-orange-400">
                        {formatTime(hoverTime)}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Buttons Bar */}
              <div className="flex items-center justify-between">
                
                {/* Left Controls: Play, Rewind, FastForward, Volume, Timestamp */}
                <div className="flex items-center gap-3">
                  <button
                    id="player-play-pause-btn"
                    onClick={togglePlay}
                    className="text-white/90 hover:text-white p-1 hover:bg-white/10 rounded transition-all"
                    title={isPlaying ? 'Pause (Space / K)' : 'Play (Space / K)'}
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                  </button>

                  <button
                    id="player-rewind-btn"
                    onClick={() => seekRelative(-10)}
                    className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded transition-all"
                    title="Rewind 10s (J)"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>

                  <button
                    id="player-forward-btn"
                    onClick={() => seekRelative(10)}
                    className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded transition-all"
                    title="Fast Forward 10s (L)"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>

                  {/* Volume Control */}
                  <div className="flex items-center gap-1.5 group/vol">
                    <button
                      id="player-mute-btn"
                      onClick={toggleMute}
                      className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded transition-all"
                      title="Mute / Unmute (M)"
                    >
                      {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <input
                      id="player-volume-slider"
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={isMuted ? 0 : volume}
                      onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                      className="w-16 h-1 accent-orange-500 bg-white/20 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Time Readout */}
                  <div className="text-[11px] font-mono text-gray-300 ml-2">
                    <span className="text-white font-semibold">{formatTime(currentTime)}</span>
                    <span className="text-gray-500"> / {formatTime(duration)}</span>
                  </div>
                </div>

                {/* Right Controls: Settings, Captions, PiP, Fullscreen */}
                <div className="flex items-center gap-2 relative">
                  
                  {/* Captions Toggle */}
                  <button
                    id="player-captions-btn"
                    onClick={() => setSelectedCaptionLang((prev) => (prev === 'off' ? 'en' : 'off'))}
                    className={`px-1.5 py-1 rounded text-xs font-mono font-bold border transition-all ${
                      selectedCaptionLang !== 'off'
                        ? 'bg-orange-500 text-white border-orange-400'
                        : 'text-white/70 border-white/20 hover:text-white hover:bg-white/10'
                    }`}
                    title="Toggle Subtitles (C)"
                  >
                    CC
                  </button>

                  {/* Settings Menu Button */}
                  <button
                    id="player-settings-btn"
                    onClick={() => {
                      setShowSettingsMenu(!showSettingsMenu);
                      setSettingsTab('main');
                    }}
                    className={`p-1.5 rounded hover:bg-white/10 transition-all ${
                      showSettingsMenu ? 'text-orange-400' : 'text-white/80 hover:text-white'
                    }`}
                    title="Playback Settings"
                  >
                    <Settings className="w-4 h-4" />
                  </button>

                  {/* Picture-in-Picture */}
                  <button
                    id="player-pip-btn"
                    onClick={togglePiP}
                    className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded transition-all hidden sm:block"
                    title="Picture-in-Picture"
                  >
                    <PictureInPicture2 className="w-4 h-4" />
                  </button>

                  {/* Fullscreen Button */}
                  <button
                    id="player-fullscreen-btn"
                    onClick={toggleFullscreen}
                    className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded transition-all"
                    title="Fullscreen (F)"
                  >
                    {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                  </button>

                  {/* Interactive Floating Settings Flyout */}
                  {showSettingsMenu && (
                    <div className="absolute bottom-10 right-0 w-64 bg-[#16161A] border border-white/10 rounded-lg shadow-2xl p-2 text-xs z-40 text-gray-200">
                      {settingsTab === 'main' && (
                        <div className="space-y-1">
                          <div className="text-[10px] text-gray-500 uppercase font-mono font-bold px-2 py-1 border-b border-white/5">
                            Playback Settings
                          </div>
                          
                          {/* Quality Selector row */}
                          <button
                            onClick={() => setSettingsTab('quality')}
                            className="w-full flex justify-between items-center px-2 py-1.5 hover:bg-white/5 rounded text-left"
                          >
                            <span className="text-gray-300">Quality</span>
                            <span className="font-mono text-orange-400 text-[11px]">
                              {selectedQuality === 'Auto' ? `Auto (${activeRendition.resolution.split('x')[1]}p)` : selectedQuality} ›
                            </span>
                          </button>

                          {/* Speed Selector row */}
                          <button
                            onClick={() => setSettingsTab('speed')}
                            className="w-full flex justify-between items-center px-2 py-1.5 hover:bg-white/5 rounded text-left"
                          >
                            <span className="text-gray-300">Playback Speed</span>
                            <span className="font-mono text-orange-400 text-[11px]">{playbackRate}x ›</span>
                          </button>

                          {/* Subtitles row */}
                          <button
                            onClick={() => setSettingsTab('subtitles')}
                            className="w-full flex justify-between items-center px-2 py-1.5 hover:bg-white/5 rounded text-left"
                          >
                            <span className="text-gray-300">Subtitles / CC</span>
                            <span className="font-mono text-orange-400 text-[11px]">
                              {selectedCaptionLang === 'off' ? 'Off' : selectedCaptionLang.toUpperCase()} ›
                            </span>
                          </button>
                        </div>
                      )}

                      {/* Quality Submenu */}
                      {settingsTab === 'quality' && (
                        <div className="space-y-1">
                          <button
                            onClick={() => setSettingsTab('main')}
                            className="text-[10px] text-gray-400 hover:text-white px-2 py-1 border-b border-white/5 w-full text-left font-mono font-bold"
                          >
                            ‹ Back to Settings
                          </button>
                          
                          <button
                            onClick={() => {
                              setSelectedQuality('Auto');
                              setShowSettingsMenu(false);
                            }}
                            className={`w-full flex justify-between items-center px-2 py-1.5 rounded ${
                              selectedQuality === 'Auto' ? 'bg-orange-500/20 text-orange-400' : 'hover:bg-white/5'
                            }`}
                          >
                            <div className="flex flex-col items-start">
                              <span className="font-semibold">Auto (Adaptive ABR)</span>
                              <span className="text-[10px] text-gray-400 font-mono">Current: {activeRendition.resolution} ({activeRendition.codec})</span>
                            </div>
                            {selectedQuality === 'Auto' && <Check className="w-3.5 h-3.5 text-orange-400" />}
                          </button>

                          {currentVideo.renditions.map((rend) => (
                            <button
                              key={rend.label}
                              onClick={() => {
                                setSelectedQuality(rend.label);
                                setShowSettingsMenu(false);
                              }}
                              className={`w-full flex justify-between items-center px-2 py-1.5 rounded ${
                                selectedQuality === rend.label ? 'bg-orange-500/20 text-orange-400' : 'hover:bg-white/5'
                              }`}
                            >
                              <div className="flex flex-col items-start">
                                <span className="font-semibold">{rend.label}</span>
                                <span className="text-[10px] text-gray-400 font-mono">{rend.codec} • {rend.bitrateKbps} kbps</span>
                              </div>
                              {selectedQuality === rend.label && <Check className="w-3.5 h-3.5 text-orange-400" />}
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Speed Submenu */}
                      {settingsTab === 'speed' && (
                        <div className="space-y-1">
                          <button
                            onClick={() => setSettingsTab('main')}
                            className="text-[10px] text-gray-400 hover:text-white px-2 py-1 border-b border-white/5 w-full text-left font-mono font-bold"
                          >
                            ‹ Back to Settings
                          </button>
                          {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                            <button
                              key={rate}
                              onClick={() => handlePlaybackRateChange(rate)}
                              className={`w-full flex justify-between items-center px-2 py-1.5 rounded ${
                                playbackRate === rate ? 'bg-orange-500/20 text-orange-400 font-bold' : 'hover:bg-white/5'
                              }`}
                            >
                              <span>{rate === 1.0 ? '1.0x (Normal)' : `${rate}x`}</span>
                              {playbackRate === rate && <Check className="w-3.5 h-3.5 text-orange-400" />}
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Subtitles Submenu */}
                      {settingsTab === 'subtitles' && (
                        <div className="space-y-1">
                          <button
                            onClick={() => setSettingsTab('main')}
                            className="text-[10px] text-gray-400 hover:text-white px-2 py-1 border-b border-white/5 w-full text-left font-mono font-bold"
                          >
                            ‹ Back to Settings
                          </button>
                          <button
                            onClick={() => {
                              setSelectedCaptionLang('off');
                              setShowSettingsMenu(false);
                            }}
                            className={`w-full flex justify-between items-center px-2 py-1.5 rounded ${
                              selectedCaptionLang === 'off' ? 'bg-orange-500/20 text-orange-400 font-bold' : 'hover:bg-white/5'
                            }`}
                          >
                            <span>Off</span>
                            {selectedCaptionLang === 'off' && <Check className="w-3.5 h-3.5 text-orange-400" />}
                          </button>

                          {currentVideo.captions.map((cap) => (
                            <button
                              key={cap.lang}
                              onClick={() => {
                                setSelectedCaptionLang(cap.lang);
                                setShowSettingsMenu(false);
                              }}
                              className={`w-full flex justify-between items-center px-2 py-1.5 rounded ${
                                selectedCaptionLang === cap.lang ? 'bg-orange-500/20 text-orange-400 font-bold' : 'hover:bg-white/5'
                              }`}
                            >
                              <span>{cap.label}</span>
                              {selectedCaptionLang === cap.lang && <Check className="w-3.5 h-3.5 text-orange-400" />}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                </div>
              </div>

            </div>
          </div>

          {/* Quick Metrics Bar directly underneath player */}
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 w-full">
            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4 text-center">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">TTFF (Avg)</div>
              <div className="text-xl sm:text-2xl font-mono text-white font-semibold">
                {qoeMetrics.ttffMs}ms
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">Target: &lt;500ms</span>
            </div>

            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4 text-center">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">Rebuffer Rate</div>
              <div className="text-xl sm:text-2xl font-mono text-emerald-400 font-semibold">
                {qoeMetrics.rebufferRate}%
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">Target: &lt;0.5%</span>
            </div>

            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4 text-center">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">VPF Index</div>
              <div className="text-xl sm:text-2xl font-mono text-white font-semibold">
                {qoeMetrics.vpfRate}%
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">Target: &lt;0.1%</span>
            </div>

            <div className="bg-[#0F0F11] border border-white/5 rounded-xl p-4 text-center">
              <div className="text-[10px] text-gray-500 uppercase font-mono font-bold mb-1">Avg View Time</div>
              <div className="text-xl sm:text-2xl font-mono text-orange-400 font-semibold">
                {formatTime(qoeMetrics.avgWatchTimeSec)}
              </div>
              <span className="text-[10px] text-gray-400 font-mono">68% Retention</span>
            </div>
          </div>

          {/* Keyboard Hotkeys Reference Bar */}
          <div className="mt-6 w-full bg-[#0F0F11]/60 border border-white/5 rounded-lg p-3 text-xs text-gray-400 flex flex-wrap items-center justify-between gap-3">
            <span className="text-[10px] font-mono uppercase text-gray-500 font-bold">Standard Hotkeys:</span>
            <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono">
              <span><kbd className="px-1.5 py-0.5 bg-black border border-white/10 rounded text-gray-200">Space</kbd> / <kbd className="px-1.5 py-0.5 bg-black border border-white/10 rounded text-gray-200">K</kbd> Play/Pause</span>
              <span><kbd className="px-1.5 py-0.5 bg-black border border-white/10 rounded text-gray-200">J</kbd> / <kbd className="px-1.5 py-0.5 bg-black border border-white/10 rounded text-gray-200">L</kbd> ±10s Seek</span>
              <span><kbd className="px-1.5 py-0.5 bg-black border border-white/10 rounded text-gray-200">M</kbd> Mute</span>
              <span><kbd className="px-1.5 py-0.5 bg-black border border-white/10 rounded text-gray-200">F</kbd> Fullscreen</span>
              <span><kbd className="px-1.5 py-0.5 bg-black border border-white/10 rounded text-gray-200">C</kbd> Captions</span>
            </div>
          </div>

        </div>
      </section>

      {/* Side Video Catalog & Transcoding Rendition Ladder Selector */}
      <aside className="w-full xl:w-[320px] border-t xl:border-t-0 xl:border-l border-white/5 bg-[#0F0F11] flex flex-col p-5 overflow-y-auto shrink-0 custom-scrollbar">
        
        {/* Active Video Info */}
        <div className="pb-5 border-b border-white/5 mb-5">
          <span className="text-[10px] text-orange-400 font-mono uppercase font-bold tracking-wider">
            Active Stream Manifest
          </span>
          <h3 className="text-sm font-semibold text-white mt-1 leading-snug">
            {currentVideo.title}
          </h3>
          <p className="text-xs text-gray-400 mt-2 line-clamp-2">
            {currentVideo.description}
          </p>
          <div className="flex flex-wrap gap-1.5 mt-3">
            {currentVideo.tags.map((tag) => (
              <span key={tag} className="text-[10px] px-2 py-0.5 bg-white/5 border border-white/10 rounded font-mono text-gray-300">
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Dynamic ABR Ladder Breakdown */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <h4 className="text-[11px] text-gray-500 uppercase font-mono font-bold tracking-wider">
              ABR Ladder Matrix
            </h4>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
              5 Profiles
            </span>
          </div>

          <div className="space-y-2">
            {currentVideo.renditions.map((rend) => {
              const isCurrent = activeRendition.label === rend.label;
              return (
                <div
                  key={rend.label}
                  onClick={() => setSelectedQuality(rend.label)}
                  className={`p-2.5 rounded-lg border text-xs cursor-pointer transition-all ${
                    isCurrent 
                      ? 'bg-orange-500/10 border-orange-500/40 text-white' 
                      : 'bg-[#16161A] border-white/5 text-gray-400 hover:border-white/20'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-gray-200 flex items-center gap-1.5">
                      {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>}
                      {rend.label}
                    </span>
                    <span className="font-mono text-orange-400 text-[11px]">{rend.bitrateKbps} Kbps</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-500 font-mono">
                    <span>{rend.codec} • {rend.fps}fps</span>
                    <span>Req: {rend.bandwidthRequirementMbps} Mbps</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Video Library Quick Switcher */}
        <div>
          <h4 className="text-[11px] text-gray-500 uppercase font-mono font-bold tracking-wider mb-3">
            Library Catalog Switcher
          </h4>
          <div className="space-y-2.5">
            {allVideos.map((vid) => (
              <div
                key={vid.id}
                onClick={() => onSelectVideo(vid)}
                className={`p-2.5 rounded-lg border cursor-pointer transition-all flex gap-3 items-center ${
                  vid.id === currentVideo.id
                    ? 'bg-orange-500/15 border-orange-500/40'
                    : 'bg-[#16161A] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="w-12 h-8 rounded bg-gray-800 overflow-hidden shrink-0 border border-white/10">
                  <img src={vid.posterUrl} alt={vid.title} className="w-full h-full object-cover" />
                </div>
                <div className="overflow-hidden flex-1">
                  <div className="text-xs font-medium text-white truncate">{vid.title}</div>
                  <div className="text-[10px] text-gray-500 font-mono mt-0.5">{formatTime(vid.duration)} • DRM {vid.drmTier}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </aside>
    </div>
  );
};
