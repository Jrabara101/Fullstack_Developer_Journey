export type VideoQuality = 'Auto' | '2160p (4K)' | '1080p' | '720p' | '480p' | '360p';

export type VideoCodec = 'AV1' | 'HEVC (H.265)' | 'H.264 (AVC)';

export type DRMTier = 'low' | 'medium' | 'high';

export interface QualityRendition {
  label: VideoQuality;
  resolution: string;
  bitrateKbps: number;
  codec: VideoCodec;
  fps: number;
  audioBitrateKbps: number;
  bandwidthRequirementMbps: number;
}

export interface VideoItem {
  id: string;
  title: string;
  filename: string;
  duration: number; // in seconds
  url: string;
  posterUrl: string;
  description: string;
  category: string;
  tags: string[];
  views: number;
  drmTier: DRMTier;
  securityToken?: string;
  renditions: QualityRendition[];
  currentRendition: VideoQuality;
  thumbnails: { time: number; label: string; previewColor: string; imgUrl?: string }[];
  captions: {
    lang: string;
    label: string;
    cues: { start: number; end: number; text: string }[];
  }[];
}

export type UploadStage = 
  | 'idle'
  | 'uploading' 
  | 'upload_paused'
  | 'transcoding_1080p'
  | 'transcoding_ladder'
  | 'extracting_thumbnails'
  | 'ai_moderation'
  | 'packaging_hls'
  | 'completed'
  | 'failed';

export interface UploadChunk {
  id: number;
  startByte: number;
  endByte: number;
  totalBytes: number;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'failed' | 'retrying';
}

export interface UploadJob {
  id: string;
  fileName: string;
  fileSizeMB: number;
  videoTitle: string;
  description: string;
  category: string;
  tags: string[];
  drmTier: DRMTier;
  totalChunks: number;
  completedChunks: number;
  chunks: UploadChunk[];
  uploadProgress: number;
  stage: UploadStage;
  stageProgress: number;
  stageMessage: string;
  transcodeSpeedFps: number;
  estimatedRemainingSec: number;
  moderationResult?: {
    audioSafetyScore: number;
    visualSafetyScore: number;
    copyrightClean: boolean;
    flags: string[];
  };
}

export interface QoEMetrics {
  ttffMs: number; // Time to First Frame
  rebufferRate: number; // Percentage stalled
  bufferLengthSec: number; // Current buffered video ahead of playhead
  vpfRate: number; // Video Playback Failure rate %
  avgWatchTimeSec: number;
  completionRate: {
    q1: number; // 25%
    q2: number; // 50%
    q3: number; // 75%
    q4: number; // 100%
  };
  currentBitrateKbps: number;
  droppedFrames: number;
  cdnLatencyMs: number;
  cdnCacheHitRatio: number;
  networkThroughputMbps: number;
}

export interface CDNEdgeNode {
  id: string;
  city: string;
  region: string;
  trafficTbps: number;
  latencyMs: number;
  cacheHitRatio: number;
  status: 'optimal' | 'elevated' | 'congested';
}

export interface EconomicsParams {
  monthlyActiveViewers: number;
  avgHoursPerUserMonthly: number;
  codec: VideoCodec;
  cdnEgressRatePerGB: number;
  transcodingCostPerMin: number;
  hotStorageRatePerGB: number;
  coldStorageRatePerGB: number;
  totalVideoHoursInCatalog: number;
  monetizationModel: 'avod' | 'svod' | 'hybrid';
  adRpm: number;
  subPriceMonthly: number;
  payingSubscribersPct: number;
}

export type ActiveTab = 'player' | 'pipeline' | 'economics' | 'security' | 'observability';
