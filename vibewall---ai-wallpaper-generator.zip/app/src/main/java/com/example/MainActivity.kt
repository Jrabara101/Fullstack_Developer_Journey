package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.WallpaperRepository
import com.example.data.viewmodel.WallpaperViewModel
import com.example.ui.components.FullscreenPreviewDialog
import com.example.ui.components.HistorySection
import com.example.ui.components.VibeBar
import com.example.ui.components.WallpaperGrid
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.PinkAccent
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.VibeWallTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VibeWallTheme {
                val context = LocalContext.current.applicationContext
                val database = remember { AppDatabase.getDatabase(context) }
                val repository = remember { WallpaperRepository(database.wallpaperDao()) }
                val viewModel: WallpaperViewModel = viewModel(
                    factory = WallpaperViewModel.Factory(repository)
                )

                VibeWallApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun VibeWallApp(viewModel: WallpaperViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.dismissSnackbar()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Slate900,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = Slate800,
                contentColor = Color.White,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
            ) {
                NavigationBarItem(
                    selected = uiState.activeTab == 0,
                    onClick = { viewModel.setTab(0) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Studio Tab"
                        )
                    },
                    label = { Text("Studio") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = CyanAccent,
                        indicatorColor = PurplePrimary,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tab_studio")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == 1,
                    onClick = { viewModel.setTab(1) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History Tab"
                        )
                    },
                    label = { Text("History") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = CyanAccent,
                        indicatorColor = PurplePrimary,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tab_history")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == 2,
                    onClick = { viewModel.setTab(2) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Favorites Tab"
                        )
                    },
                    label = { Text("Saved") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = CyanAccent,
                        indicatorColor = PurplePrimary,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tab_saved")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(PurplePrimary, CyanAccent))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "App Logo",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "VibeWall",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp
                        )
                    )
                    Text(
                        text = "AI 9:16 Phone Wallpaper Generator",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = CyanAccent,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }

            // Main Content Body according to activeTab
            when (uiState.activeTab) {
                0 -> {
                    // Studio View (Prompt Bar + 4 Variations Grid)
                    VibeBar(
                        prompt = uiState.vibePrompt,
                        isGenerating = uiState.isGenerating,
                        remixReference = uiState.remixReference,
                        onPromptChanged = { viewModel.onPromptChanged(it) },
                        onGenerateClicked = { viewModel.generateWallpapers() },
                        onSelectPreset = { viewModel.selectPresetVibe(it) },
                        onClearRemix = { viewModel.clearRemixReference() }
                    )

                    WallpaperGrid(
                        wallpapers = uiState.currentBatch,
                        isGenerating = uiState.isGenerating,
                        onWallpaperClick = { viewModel.selectWallpaperForFullscreen(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        modifier = Modifier.weight(1f)
                    )
                }
                1 -> {
                    // History View
                    HistorySection(
                        wallpapers = uiState.historyList,
                        isFavoritesOnly = false,
                        onWallpaperClick = { viewModel.selectWallpaperForFullscreen(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        modifier = Modifier.weight(1f)
                    )
                }
                2 -> {
                    // Saved Favorites View
                    HistorySection(
                        wallpapers = uiState.favoriteList,
                        isFavoritesOnly = true,
                        onWallpaperClick = { viewModel.selectWallpaperForFullscreen(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Fullscreen Wallpaper Preview Modal Dialog
        uiState.selectedWallpaper?.let { wallpaper ->
            FullscreenPreviewDialog(
                wallpaper = wallpaper,
                showLockScreenOverlay = uiState.showLockScreenOverlay,
                onClose = { viewModel.selectWallpaperForFullscreen(null) },
                onDownload = { viewModel.downloadToGallery(context, it) },
                onRemix = { viewModel.startRemix(it) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onToggleLockOverlay = { viewModel.toggleLockScreenOverlay() }
            )
        }
    }
}
