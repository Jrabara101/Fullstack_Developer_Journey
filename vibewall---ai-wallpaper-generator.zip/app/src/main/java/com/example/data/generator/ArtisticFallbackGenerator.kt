package com.example.data.generator

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object ArtisticFallbackGenerator {

    /**
     * Generates a 9:16 aspect ratio wallpaper bitmap based on vibe prompt and variation index.
     */
    fun generateWallpaper(vibePrompt: String, variationIndex: Int): String {
        val width = 720
        val height = 1280 // 9:16 ratio
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val seed = (vibePrompt.hashCode().toLong() shl 4) + variationIndex
        val random = Random(seed)

        val vibe = vibePrompt.lowercase()

        val colors = when {
            vibe.contains("cyber") || vibe.contains("neon") || vibe.contains("tokyo") -> listOf(
                Color.parseColor("#0F172A"), Color.parseColor("#1E1B4B"),
                Color.parseColor("#A855F7"), Color.parseColor("#06B6D4"),
                Color.parseColor("#EC4899")
            )
            vibe.contains("rain") || vibe.contains("lo-fi") || vibe.contains("lofi") || vibe.contains("moody") -> listOf(
                Color.parseColor("#090D16"), Color.parseColor("#1E293B"),
                Color.parseColor("#334155"), Color.parseColor("#38BDF8"),
                Color.parseColor("#818CF8")
            )
            vibe.contains("sunset") || vibe.contains("synth") || vibe.contains("dusk") || vibe.contains("warm") -> listOf(
                Color.parseColor("#180E29"), Color.parseColor("#4C1D95"),
                Color.parseColor("#C026D3"), Color.parseColor("#F43F5E"),
                Color.parseColor("#F59E0B")
            )
            vibe.contains("nature") || vibe.contains("organic") || vibe.contains("forest") || vibe.contains("green") -> listOf(
                Color.parseColor("#022C22"), Color.parseColor("#064E3B"),
                Color.parseColor("#047857"), Color.parseColor("#10B981"),
                Color.parseColor("#6EE7B7")
            )
            vibe.contains("space") || vibe.contains("cosmic") || vibe.contains("star") || vibe.contains("galaxy") -> listOf(
                Color.parseColor("#030712"), Color.parseColor("#111827"),
                Color.parseColor("#312E81"), Color.parseColor("#6366F1"),
                Color.parseColor("#E0E7FF")
            )
            else -> listOf(
                Color.parseColor("#0F0F1A"), Color.parseColor("#1B1B3A"),
                Color.parseColor("#4C1D95"), Color.parseColor("#8B5CF6"),
                Color.parseColor("#06B6D4")
            )
        }

        // Base gradient
        val bgPaint = Paint()
        val bgGradient = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            colors[0], colors[1], Shader.TileMode.CLAMP
        )
        bgPaint.shader = bgGradient
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Radial lighting aura
        val auraX = when (variationIndex % 4) {
            0 -> width * 0.3f
            1 -> width * 0.7f
            2 -> width * 0.5f
            else -> width * 0.2f
        }
        val auraY = when (variationIndex % 4) {
            0 -> height * 0.3f
            1 -> height * 0.4f
            2 -> height * 0.7f
            else -> height * 0.6f
        }
        val auraPaint = Paint().apply { isAntiAlias = true }
        val auraGradient = RadialGradient(
            auraX, auraY, width * 0.8f,
            intArrayOf(colors[2], colors[3], Color.TRANSPARENT),
            floatArrayOf(0.0f, 0.5f, 1.0f),
            Shader.TileMode.CLAMP
        )
        auraPaint.shader = auraGradient
        canvas.drawCircle(auraX, auraY, width * 0.8f, auraPaint)

        // Geometric & Fluid Art elements based on variation index
        val shapePaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        when (variationIndex % 4) {
            0 -> {
                // Wave layers
                for (i in 0 until 4) {
                    val path = Path()
                    val startY = height * (0.4f + i * 0.12f)
                    path.moveTo(0f, startY)
                    var x = 0f
                    while (x <= width) {
                        val y = startY + sin((x / width * Math.PI * 2) + i + random.nextFloat()) * 80f
                        path.lineTo(x, y.toFloat())
                        x += 40f
                    }
                    path.lineTo(width.toFloat(), height.toFloat())
                    path.lineTo(0f, height.toFloat())
                    path.close()

                    shapePaint.color = colors[(i + 2) % colors.size]
                    shapePaint.alpha = 100 - (i * 18)
                    canvas.drawPath(path, shapePaint)
                }
            }
            1 -> {
                // Glowing Orb & Grid / Horizon
                val sunPaint = Paint().apply { isAntiAlias = true }
                val sunRadius = 180f
                val sunX = width / 2f
                val sunY = height * 0.45f

                val sunGradient = RadialGradient(
                    sunX, sunY, sunRadius,
                    intArrayOf(colors[4], colors[3], Color.TRANSPARENT),
                    floatArrayOf(0f, 0.7f, 1f),
                    Shader.TileMode.CLAMP
                )
                sunPaint.shader = sunGradient
                canvas.drawCircle(sunX, sunY, sunRadius, sunPaint)

                // Grid lines
                val gridPaint = Paint().apply {
                    color = colors[3]
                    strokeWidth = 2f
                    alpha = 60
                    isAntiAlias = true
                }
                val horizonY = height * 0.6f
                canvas.drawLine(0f, horizonY, width.toFloat(), horizonY, gridPaint)
                for (step in 1..8) {
                    val y = horizonY + step * step * 8f
                    if (y < height) {
                        canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
                    }
                }
                for (x in 0..width step 60) {
                    canvas.drawLine(x.toFloat(), horizonY, x.toFloat() + (x - width / 2) * 1.5f, height.toFloat(), gridPaint)
                }
            }
            2 -> {
                // Cyberpunk Bokeh / Rain drops
                val bokehPaint = Paint().apply { isAntiAlias = true }
                for (i in 0..35) {
                    val cx = random.nextFloat() * width
                    val cy = random.nextFloat() * height
                    val radius = 15f + random.nextFloat() * 60f
                    bokehPaint.color = colors[random.nextInt(colors.size)]
                    bokehPaint.alpha = 40 + random.nextInt(120)
                    canvas.drawCircle(cx, cy, radius, bokehPaint)
                }

                // Vertical light streaks (Rain effect)
                val streakPaint = Paint().apply {
                    color = colors[3]
                    strokeWidth = 3f
                    alpha = 110
                    isAntiAlias = true
                }
                for (i in 0..40) {
                    val sx = random.nextFloat() * width
                    val sy = random.nextFloat() * height
                    val len = 60f + random.nextFloat() * 140f
                    canvas.drawLine(sx, sy, sx - 15f, sy + len, streakPaint)
                }
            }
            3 -> {
                // Polygon / Crystal aura
                val polyPaint = Paint().apply {
                    isAntiAlias = true
                    style = Paint.Style.FILL
                }
                for (i in 0..6) {
                    val path = Path()
                    val cx = width * (0.2f + random.nextFloat() * 0.6f)
                    val cy = height * (0.3f + random.nextFloat() * 0.4f)
                    val size = 120f + random.nextFloat() * 180f

                    path.moveTo(cx, cy - size)
                    path.lineTo(cx + size * 0.8f, cy)
                    path.lineTo(cx, cy + size)
                    path.lineTo(cx - size * 0.8f, cy)
                    path.close()

                    polyPaint.color = colors[(i + 1) % colors.size]
                    polyPaint.alpha = 70 - i * 8
                    canvas.drawPath(path, polyPaint)
                }
            }
        }

        // Particle stars / dust overlay
        val starPaint = Paint().apply {
            color = Color.WHITE
            isAntiAlias = true
        }
        for (i in 0..80) {
            val sx = random.nextFloat() * width
            val sy = random.nextFloat() * height
            starPaint.alpha = 50 + random.nextInt(180)
            val starSize = 1f + random.nextFloat() * 3.5f
            canvas.drawCircle(sx, sy, starSize, starPaint)
        }

        // Convert to Base64 JPEG string
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
        val byteArray = outputStream.toByteArray()
        bitmap.recycle()

        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
