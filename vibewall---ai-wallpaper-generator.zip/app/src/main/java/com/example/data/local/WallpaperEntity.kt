package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallpapers")
data class WallpaperEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val vibePrompt: String,
    val imageBase64: String, // Base64 encoded JPEG or image URI
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val variationIndex: Int = 0,
    val remixedFromId: Long? = null
)
