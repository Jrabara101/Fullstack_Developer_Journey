package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.generator.ArtisticFallbackGenerator
import com.example.data.local.WallpaperDao
import com.example.data.local.WallpaperEntity
import com.example.data.remote.GeminiApiService
import com.example.data.remote.GeminiContent
import com.example.data.remote.GeminiGenerationConfig
import com.example.data.remote.GeminiImageConfig
import com.example.data.remote.GeminiInlineData
import com.example.data.remote.GeminiPart
import com.example.data.remote.GeminiRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class WallpaperRepository(
    private val wallpaperDao: WallpaperDao,
    private val geminiApiService: GeminiApiService = GeminiApiService.create()
) {

    val allWallpapers: Flow<List<WallpaperEntity>> = wallpaperDao.getAllWallpapers()
    val favoriteWallpapers: Flow<List<WallpaperEntity>> = wallpaperDao.getFavoriteWallpapers()

    /**
     * Generates 4 variations of phone wallpapers in 9:16 aspect ratio.
     * Supports referenceImageBase64 for remixing!
     */
    suspend fun generate4Variations(
        vibePrompt: String,
        referenceImageBase64: String? = null,
        remixedFromId: Long? = null
    ): List<WallpaperEntity> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val hasApiKey = apiKey.isNotBlank() && !apiKey.contains("MY_GEMINI_API_KEY")

        val variationTasks = (0..3).map { index ->
            async {
                generateSingleVariation(
                    vibePrompt = vibePrompt,
                    variationIndex = index,
                    referenceImageBase64 = referenceImageBase64,
                    apiKey = apiKey,
                    hasApiKey = hasApiKey,
                    remixedFromId = remixedFromId
                )
            }
        }

        val generatedEntities = variationTasks.awaitAll()

        // Persist generated wallpapers into Room DB
        try {
            val insertedIds = wallpaperDao.insertWallpapers(generatedEntities)
            generatedEntities.mapIndexed { i, entity ->
                entity.copy(id = insertedIds.getOrElse(i) { 0L })
            }
        } catch (e: Exception) {
            Log.e("WallpaperRepository", "Error saving to Room database: ${e.message}")
            generatedEntities
        }
    }

    private suspend fun generateSingleVariation(
        vibePrompt: String,
        variationIndex: Int,
        referenceImageBase64: String?,
        apiKey: String,
        hasApiKey: Boolean,
        remixedFromId: Long?
    ): WallpaperEntity {
        var base64Result: String? = null

        if (hasApiKey) {
            val variationPromptText = buildPromptText(vibePrompt, variationIndex, referenceImageBase64 != null)
            val partsList = mutableListOf<GeminiPart>()

            partsList.add(GeminiPart(text = variationPromptText))
            if (!referenceImageBase64.isNullOrBlank()) {
                partsList.add(
                    GeminiPart(
                        inlineData = GeminiInlineData(
                            mimeType = "image/jpeg",
                            data = referenceImageBase64
                        )
                    )
                )
            }

            val request = GeminiRequest(
                contents = listOf(GeminiContent(parts = partsList)),
                generationConfig = GeminiGenerationConfig(
                    imageConfig = GeminiImageConfig(aspectRatio = "9:16", imageSize = "1K"),
                    responseModalities = listOf("IMAGE")
                )
            )

            // Try primary model gemini-3.1-flash-image-preview, then fallback model gemini-2.5-flash-image
            val primaryModel = "gemini-3.1-flash-image-preview"
            val fallbackModel = "gemini-2.5-flash-image"

            try {
                val response = geminiApiService.generateImageContent(primaryModel, apiKey, request)
                base64Result = extractBase64FromResponse(response)
            } catch (e: Exception) {
                Log.w("WallpaperRepository", "Primary model failed: ${e.message}, trying fallback model...")
                try {
                    val response = geminiApiService.generateImageContent(fallbackModel, apiKey, request)
                    base64Result = extractBase64FromResponse(response)
                } catch (e2: Exception) {
                    Log.e("WallpaperRepository", "Gemini API generation failed: ${e2.message}")
                }
            }
        }

        // If Gemini API did not produce an image or key was not present, use ArtisticFallbackGenerator
        if (base64Result == null) {
            base64Result = ArtisticFallbackGenerator.generateWallpaper(vibePrompt, variationIndex)
        }

        return WallpaperEntity(
            vibePrompt = vibePrompt,
            imageBase64 = base64Result,
            createdAt = System.currentTimeMillis() + variationIndex,
            isFavorite = false,
            variationIndex = variationIndex,
            remixedFromId = remixedFromId
        )
    }

    private fun extractBase64FromResponse(response: com.example.data.remote.GeminiResponse): String? {
        val candidate = response.candidates?.firstOrNull() ?: return null
        val parts = candidate.content?.parts ?: return null
        for (part in parts) {
            val inlineData = part.inlineData
            if (inlineData != null && inlineData.data.isNotBlank()) {
                return inlineData.data
            }
        }
        return null
    }

    private fun buildPromptText(vibePrompt: String, variationIndex: Int, isRemix: Boolean): String {
        val variationNuance = when (variationIndex) {
            0 -> "focusing on atmospheric composition and depth"
            1 -> "with glowing neon light highlights and cinematic framing"
            2 -> "minimalist elegant perspective with vivid color harmony"
            else -> "surreal detailed texture with artistic ambient lighting"
        }

        return if (isRemix) {
            "Generate a new 9:16 phone wallpaper remixing the style, colors, and mood of the provided reference image. Desired vibe: '$vibePrompt', $variationNuance. High quality wallpaper art."
        } else {
            "A high-definition 9:16 vertical phone wallpaper embodying the vibe: '$vibePrompt'. $variationNuance. Professional digital artwork, zero text, vibrant visuals."
        }
    }

    suspend fun toggleFavorite(wallpaper: WallpaperEntity) {
        withContext(Dispatchers.IO) {
            wallpaperDao.updateWallpaper(wallpaper.copy(isFavorite = !wallpaper.isFavorite))
        }
    }

    suspend fun deleteWallpaper(id: Long) {
        withContext(Dispatchers.IO) {
            wallpaperDao.deleteWallpaperById(id)
        }
    }
}
