package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.WallpaperEntity
import com.example.ui.theme.PinkAccent
import com.example.ui.theme.PurplePrimary

@Composable
fun HistorySection(
    wallpapers: List<WallpaperEntity>,
    isFavoritesOnly: Boolean,
    onWallpaperClick: (WallpaperEntity) -> Unit,
    onToggleFavorite: (WallpaperEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    if (wallpapers.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = if (isFavoritesOnly) Icons.Default.Favorite else Icons.Default.History,
                    contentDescription = null,
                    tint = if (isFavoritesOnly) PinkAccent else PurplePrimary,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isFavoritesOnly) "No Favorite Wallpapers" else "No Generation History",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isFavoritesOnly)
                        "Tap the heart icon on any wallpaper to save it to your favorites gallery."
                    else
                        "Wallpapers you generate will automatically appear here.",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                )
            }
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(16.dp),
            modifier = modifier.fillMaxSize()
        ) {
            items(
                items = wallpapers,
                key = { it.id }
            ) { wallpaper ->
                WallpaperCard(
                    wallpaper = wallpaper,
                    variationIndex = wallpaper.variationIndex + 1,
                    onClick = { onWallpaperClick(wallpaper) },
                    onToggleFavorite = { onToggleFavorite(wallpaper) }
                )
            }
        }
    }
}
