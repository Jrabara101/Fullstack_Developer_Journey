package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)

val PurplePrimary = Color(0xFFA855F7)
val PurpleDark = Color(0xFF7E22CE)
val CyanAccent = Color(0xFF38BDF8)
val PinkAccent = Color(0xFFEC4899)

val DarkSurface = Color(0xFF182232)
val DarkSurfaceVariant = Color(0xFF243044)
val DarkBorder = Color(0xFF3B4F6B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

