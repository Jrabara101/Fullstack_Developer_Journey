package com.example.data.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.WallpaperEntity
import com.example.data.repository.WallpaperRepository
import com.example.ui.utils.ImageSaveUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class WallpaperUiState(
    val vibePrompt: String = "rainy cyberpunk lo-fi",
    val isGenerating: Boolean = false,
    val currentBatch: List<WallpaperEntity> = emptyList(),
    val selectedWallpaper: WallpaperEntity? = null,
    val remixReference: WallpaperEntity? = null,
    val historyList: List<WallpaperEntity> = emptyList(),
    val favoriteList: List<WallpaperEntity> = emptyList(),
    val activeTab: Int = 0, // 0 = Generator, 1 = History, 2 = Favorites
    val showLockScreenOverlay: Boolean = true,
    val snackbarMessage: String? = null
)

class WallpaperViewModel(
    private val repository: WallpaperRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(WallpaperUiState())
    val uiState: StateFlow<WallpaperUiState> = _uiState.asStateFlow()

    init {
        // Collect history
        viewModelScope.launch {
            repository.allWallpapers.collect { list ->
                _uiState.update { state ->
                    val batch = if (state.currentBatch.isEmpty() && list.isNotEmpty()) {
                        list.take(4)
                    } else {
                        state.currentBatch
                    }
                    state.copy(historyList = list, currentBatch = batch)
                }
            }
        }

        // Collect favorites
        viewModelScope.launch {
            repository.favoriteWallpapers.collect { favs ->
                _uiState.update { it.copy(favoriteList = favs) }
            }
        }

        // Generate initial starter batch on first launch
        generateWallpapers("rainy cyberpunk lo-fi")
    }

    fun onPromptChanged(newPrompt: String) {
        _uiState.update { it.copy(vibePrompt = newPrompt) }
    }

    fun selectPresetVibe(vibe: String) {
        _uiState.update { it.copy(vibePrompt = vibe) }
        generateWallpapers(vibe)
    }

    fun setTab(tabIndex: Int) {
        _uiState.update { it.copy(activeTab = tabIndex) }
    }

    fun toggleLockScreenOverlay() {
        _uiState.update { it.copy(showLockScreenOverlay = !it.showLockScreenOverlay) }
    }

    fun selectWallpaperForFullscreen(wallpaper: WallpaperEntity?) {
        _uiState.update { it.copy(selectedWallpaper = wallpaper) }
    }

    fun clearRemixReference() {
        _uiState.update { it.copy(remixReference = null) }
    }

    fun generateWallpapers(
        prompt: String = _uiState.value.vibePrompt,
        remixFrom: WallpaperEntity? = _uiState.value.remixReference
    ) {
        if (prompt.isBlank() || _uiState.value.isGenerating) return

        _uiState.update {
            it.copy(
                isGenerating = true,
                vibePrompt = prompt,
                snackbarMessage = "Generating 4 variations for '$prompt'..."
            )
        }

        viewModelScope.launch {
            val newBatch = repository.generate4Variations(
                vibePrompt = prompt,
                referenceImageBase64 = remixFrom?.imageBase64,
                remixedFromId = remixFrom?.id
            )

            _uiState.update {
                it.copy(
                    isGenerating = false,
                    currentBatch = newBatch,
                    snackbarMessage = "4 new wallpaper variations ready!"
                )
            }
        }
    }

    fun startRemix(wallpaper: WallpaperEntity) {
        val remixPrompt = wallpaper.vibePrompt
        _uiState.update {
            it.copy(
                remixReference = wallpaper,
                vibePrompt = remixPrompt,
                selectedWallpaper = null, // Close fullscreen preview
                activeTab = 0 // Switch to generator view
            )
        }
        generateWallpapers(remixPrompt, remixFrom = wallpaper)
    }

    fun toggleFavorite(wallpaper: WallpaperEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(wallpaper)
            val isNowFav = !wallpaper.isFavorite
            _uiState.update {
                val updatedSelected = if (it.selectedWallpaper?.id == wallpaper.id) {
                    it.selectedWallpaper.copy(isFavorite = isNowFav)
                } else {
                    it.selectedWallpaper
                }
                it.copy(
                    selectedWallpaper = updatedSelected,
                    snackbarMessage = if (isNowFav) "Saved to favorites!" else "Removed from favorites"
                )
            }
        }
    }

    fun downloadToGallery(context: Context, wallpaper: WallpaperEntity) {
        viewModelScope.launch {
            val uri = ImageSaveUtils.saveImageToGallery(context, wallpaper.imageBase64, wallpaper.vibePrompt)
            if (uri != null) {
                _uiState.update { it.copy(snackbarMessage = "Wallpaper saved to Gallery!") }
            } else {
                _uiState.update { it.copy(snackbarMessage = "Could not save image to gallery.") }
            }
        }
    }

    fun deleteWallpaper(wallpaper: WallpaperEntity) {
        viewModelScope.launch {
            repository.deleteWallpaper(wallpaper.id)
            if (_uiState.value.selectedWallpaper?.id == wallpaper.id) {
                _uiState.update { it.copy(selectedWallpaper = null) }
            }
        }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    class Factory(private val repository: WallpaperRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return WallpaperViewModel(repository) as T
        }
    }
}
