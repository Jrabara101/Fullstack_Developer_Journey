package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pet_state")
data class PetState(
    @PrimaryKey val id: Int = 1,
    val name: String = "TAMAGO",
    val hunger: Float = 100f, // 100 = full, 0 = starving
    val energy: Float = 100f, // 100 = fully charged, 0 = exhausted
    val boredom: Float = 0f,   // 0 = content, 100 = extremely bored
    val isSleeping: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis(),
    val creationTime: Long = System.currentTimeMillis(),
    val totalFeeds: Int = 0,
    val totalNaps: Int = 0
)
