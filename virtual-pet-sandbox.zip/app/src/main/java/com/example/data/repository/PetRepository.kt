package com.example.data.repository

import com.example.data.local.PetDao
import com.example.data.model.PetState
import kotlinx.coroutines.flow.Flow

class PetRepository(private val petDao: PetDao) {
    val petStateFlow: Flow<PetState?> = petDao.getPetStateFlow()

    suspend fun getPetState(): PetState? {
        return petDao.getPetState()
    }

    suspend fun savePetState(state: PetState) {
        petDao.insertOrUpdate(state)
    }

    suspend fun resetPetState() {
        petDao.clearAll()
        petDao.insertOrUpdate(PetState())
    }
}
