package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PetState
import com.example.ui.viewmodel.*
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetScreen(
    viewModel: PetViewModel,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.petStats.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableStateOf(0) } // 0: Engine, 1: Matrix, 2: Config
    
    var showRenameDialog by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var renameInput by remember { mutableStateOf("") }

    // Pulsing active sync animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulseSync")
    val syncAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "syncAlpha"
    )

    // Breathing or blinking animation clock
    var animationTicker by remember { mutableStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            animationTicker = System.currentTimeMillis()
            delay(50)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF111318)) // Elegant Dark Base
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // --- TOP SYSTEM HUD ---
            HeaderHUD(
                petName = stats.name,
                syncAlpha = syncAlpha,
                onRenameClick = {
                    renameInput = stats.name
                    showRenameDialog = true
                }
            )

            // --- CENTRAL MAIN SWITCHABLE AREA ---
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                    },
                    label = "tabTransition"
                ) { targetTab ->
                    when (targetTab) {
                        0 -> SimulationEngineTab(
                            viewModel = viewModel,
                            stats = stats,
                            animationTicker = animationTicker
                        )
                        1 -> DiagnosticMatrixTab(
                            stats = stats,
                            foodItemsCount = viewModel.foodItems.size
                        )
                        2 -> ConfigurationTab(
                            onRenameRequest = {
                                renameInput = stats.name
                                showRenameDialog = true
                            },
                            onResetRequest = { showResetDialog = true }
                        )
                    }
                }
            }

            // --- BOTTOM NAVIGATION BAR (M3 Style) ---
            BottomNavBar(
                selectedTab = selectedTab,
                onTabSelected = { selectedTab = it }
            )
        }
    }

    // --- DIALOGS CONTROLS ---
    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = {
                Text(
                    text = "RENAME PET",
                    color = Color(0xFFD0BCFF),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Calibrate companion identification handle:",
                        color = Color(0xFF919094),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    OutlinedTextField(
                        value = renameInput,
                        onValueChange = { renameInput = it },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFD0BCFF),
                            unfocusedBorderColor = Color(0xFF44474E)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rename_text_field")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameInput.isNotBlank()) {
                            viewModel.renamePet(renameInput)
                        }
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF381E72), contentColor = Color(0xFFD0BCFF)),
                    modifier = Modifier.testTag("rename_confirm_button")
                ) {
                    Text("UPDATE")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showRenameDialog = false },
                    modifier = Modifier.testTag("rename_cancel_button")
                ) {
                    Text("CANCEL", color = Color(0xFF919094))
                }
            },
            containerColor = Color(0xFF1A1C1E),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.border(1.dp, Color(0xFF2D3038), RoundedCornerShape(24.dp))
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Text(
                    text = "REBOOT SIMULATION",
                    color = Color(0xFFFFB4AB),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "WARNING: Performing a full system format will instantly reset metabolic levels, wipe current progression variables, and clear lifetime logs. Action is irreversible.",
                    color = Color(0xFF919094),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetPet()
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB4AB), contentColor = Color(0xFF111318)),
                    modifier = Modifier.testTag("reset_confirm_button")
                ) {
                    Text("CONFIRM FORMAT")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showResetDialog = false },
                    modifier = Modifier.testTag("reset_cancel_button")
                ) {
                    Text("ABORT", color = Color(0xFF919094))
                }
            },
            containerColor = Color(0xFF1A1C1E),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.border(1.dp, Color(0xFF2D3038), RoundedCornerShape(24.dp))
        )
    }
}

// --- SUB-COMPONENTS & LAYOUTS ---

@Composable
fun HeaderHUD(
    petName: String,
    syncAlpha: Float,
    onRenameClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 24.dp, top = 16.dp, end = 24.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "SIMULATION CLUSTER",
                    color = Color(0xFFD0BCFF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.5.sp
                )
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Rename",
                    tint = Color(0xFF919094),
                    modifier = Modifier
                        .size(14.dp)
                        .clickable { onRenameClick() }
                        .testTag("rename_trigger_icon")
                )
            }
            Text(
                text = "PET: $petName // CORE",
                color = Color(0xFF919094),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.testTag("pet_name_text")
            )
        }

        // Sync active state pill
        Box(
            modifier = Modifier
                .background(Color(0xFF2A2D35), RoundedCornerShape(100.dp))
                .border(1.dp, Color(0xFF44474E), RoundedCornerShape(100.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFB6EEAF).copy(alpha = syncAlpha))
                )
                Text(
                    text = "SYNC ACTIVE",
                    color = Color(0xFFE2E2E6),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// --- TAB 0: ENGINE CORE (SANDBOX & VITAL HUD) ---
@Composable
fun SimulationEngineTab(
    viewModel: PetViewModel,
    stats: PetState,
    animationTicker: Long
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Metabolic Metrics grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Hunger
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF1A1C1E), RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0xFF2D3038), RoundedCornerShape(20.dp))
                    .padding(12.dp)
            ) {
                MetricProgressRow(
                    label = "HUNGER",
                    value = stats.hunger,
                    barColor = Color(0xFFD0BCFF),
                    testTagPrefix = "hunger"
                )
            }

            // Vitality
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF1A1C1E), RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0xFF2D3038), RoundedCornerShape(20.dp))
                    .padding(12.dp)
            ) {
                MetricProgressRow(
                    label = "VITALITY",
                    value = stats.energy,
                    barColor = Color(0xFFB6EEAF),
                    testTagPrefix = "energy"
                )
            }
        }

        // 2. Main Simulation stage (Phaser / Three.js hybrid mock)
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(Color(0xFF090A0C)) // Curved stage container background
                .border(1.dp, Color(0xFF2D3038), RoundedCornerShape(32.dp))
                .testTag("sandbox_arena")
        ) {
            val width = constraints.maxWidth.toFloat()
            val height = constraints.maxHeight.toFloat()
            val scaleX = width / SIM_WIDTH
            val scaleY = height / SIM_HEIGHT

            // Canvas drawing loops
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Subtle Dot Grid overlay
                val dotSpacing = 24.dp.toPx()
                val dotsX = (size.width / dotSpacing).toInt()
                val dotsY = (size.height / dotSpacing).toInt()
                for (x in 0..dotsX) {
                    for (y in 0..dotsY) {
                        drawCircle(
                            color = Color(0xFF44474E).copy(alpha = 0.15f),
                            radius = 1.5f,
                            center = Offset(x * dotSpacing, y * dotSpacing)
                        )
                    }
                }

                val floorPixelY = SIM_FLOOR_Y * scaleY
                // Draw sleek floor line
                drawLine(
                    color = Color(0xFF2D3038),
                    start = Offset(0f, floorPixelY),
                    end = Offset(width, floorPixelY),
                    strokeWidth = 2f
                )

                // Pet coordinates translation
                val petPx = viewModel.petX * scaleX
                val petPy = viewModel.petY * scaleY
                val petR = PET_RADIUS * scaleX

                // Inner radial soft glow behind the pet
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFD0BCFF).copy(alpha = 0.22f),
                            Color.Transparent
                        ),
                        center = Offset(petPx, petPy),
                        radius = petR * 3f
                    ),
                    center = Offset(petPx, petPy),
                    radius = petR * 3f
                )

                // Floor shadow
                val shadowW = petR * 2.2f
                val shadowH = 16f * scaleY
                drawOval(
                    color = Color(0x77000000),
                    topLeft = Offset(petPx - shadowW / 2, floorPixelY - shadowH / 2),
                    size = Size(shadowW, shadowH)
                )

                // PROCEDURAL PET: Linear gradient fill body!
                val breathingScaleY = if (stats.isSleeping) {
                    0.82f + sin(animationTicker * 0.003f) * 0.05f
                } else {
                    1.0f + sin(animationTicker * 0.006f) * 0.03f
                }
                val breathingScaleX = 1.0f / breathingScaleY

                val finalWidth = petR * 2f * breathingScaleX
                val finalHeight = petR * 2f * breathingScaleY
                val finalLeft = petPx - finalWidth / 2
                val finalTop = petPy - finalHeight / 2 + (petR * (1f - breathingScaleY))

                // Beautiful gradient body
                val petGradient = Brush.linearGradient(
                    colors = listOf(Color(0xFFD0BCFF), Color(0xFF381E72)),
                    start = Offset(finalLeft, finalTop),
                    end = Offset(finalLeft + finalWidth, finalTop + finalHeight)
                )

                drawOval(
                    brush = petGradient,
                    topLeft = Offset(finalLeft, finalTop),
                    size = Size(finalWidth, finalHeight)
                )

                // Tiny top hair strand
                val strand = Path()
                strand.moveTo(petPx, finalTop)
                strand.quadraticBezierTo(
                    petPx + 12f * scaleX, finalTop - 20f * scaleY,
                    petPx + 4f * scaleX, finalTop - 28f * scaleY
                )
                strand.quadraticBezierTo(
                    petPx - 8f * scaleX, finalTop - 16f * scaleY,
                    petPx, finalTop
                )
                drawPath(strand, brush = petGradient)

                // Face traits
                val eyeY = petPy - 12f * scaleY + (petR * (1f - breathingScaleY))
                val leftEyeX = petPx - 24f * scaleX
                val rightEyeX = petPx + 24f * scaleX

                if (stats.isSleeping) {
                    // Closed sleepy eyes curves
                    val leftSleep = Path().apply {
                        moveTo(leftEyeX - 8f * scaleX, eyeY)
                        quadraticBezierTo(leftEyeX, eyeY + 6f * scaleY, leftEyeX + 8f * scaleX, eyeY)
                    }
                    val rightSleep = Path().apply {
                        moveTo(rightEyeX - 8f * scaleX, eyeY)
                        quadraticBezierTo(rightEyeX, eyeY + 6f * scaleY, rightEyeX + 8f * scaleX, eyeY)
                    }
                    drawPath(leftSleep, Color(0xFF111318), style = Stroke(width = 3.5f * scaleX))
                    drawPath(rightSleep, Color(0xFF111318), style = Stroke(width = 3.5f * scaleX))

                    // Draw sleeping Zzz floating text indicators
                    val zCount = 3
                    for (zIdx in 0 until zCount) {
                        val age = (animationTicker / 1000f + zIdx) % zCount
                        val zAlpha = 1.0f - (age / zCount)
                        val zScale = 0.5f + (age / zCount) * 0.8f
                        val zX = petPx + 36f * scaleX + (age * 30f * scaleX)
                        val zY = finalTop - 10f * scaleY - (age * 60f * scaleY)

                        drawContext.canvas.nativeCanvas.drawText(
                            "z",
                            zX,
                            zY,
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.argb((zAlpha * 255).toInt(), 208, 188, 255)
                                textSize = 16f * zScale * scaleX
                                typeface = android.graphics.Typeface.MONOSPACE
                                style = android.graphics.Paint.Style.FILL
                                isFakeBoldText = true
                            }
                        )
                    }
                } else {
                    // Awake tracking pupil look variables
                    val closestFood = viewModel.foodItems.minByOrNull { hypot(viewModel.petX - it.x, viewModel.petY - it.y) }
                    var lookX = 0f
                    var lookY = 0f
                    if (closestFood != null) {
                        val dx = closestFood.x - viewModel.petX
                        val dy = closestFood.y - viewModel.petY
                        val dist = hypot(dx, dy)
                        if (dist > 10f) {
                            lookX = (dx / dist) * 8f * scaleX
                            lookY = (dy / dist) * 5f * scaleY
                        }
                    }

                    // Draw eyes
                    drawCircle(Color.White, radius = 12f * scaleX, center = Offset(leftEyeX, eyeY))
                    drawCircle(Color.White, radius = 12f * scaleX, center = Offset(rightEyeX, eyeY))

                    drawCircle(Color(0xFF111318), radius = 6f * scaleX, center = Offset(leftEyeX + lookX, eyeY + lookY))
                    drawCircle(Color(0xFF111318), radius = 6f * scaleX, center = Offset(rightEyeX + lookX, eyeY + lookY))

                    // Draw mouth
                    val mouthY = petPy + 10f * scaleY + (petR * (1f - breathingScaleY))
                    if (stats.hunger < 30f) {
                        // Sad line
                        drawLine(
                            color = Color(0xFF111318),
                            start = Offset(petPx - 8f * scaleX, mouthY),
                            end = Offset(petPx + 8f * scaleX, mouthY),
                            strokeWidth = 3f * scaleX
                        )
                    } else {
                        // Sweet smile
                        val smile = Path().apply {
                            moveTo(petPx - 10f * scaleX, mouthY - 1f * scaleY)
                            quadraticBezierTo(petPx, mouthY + 7f * scaleY, petPx + 10f * scaleX, mouthY - 1f * scaleY)
                        }
                        drawPath(smile, Color(0xFF111318), style = Stroke(width = 3f * scaleX))
                    }
                }

                // FALLING PHYSICS ITEMS (🍎 / 🍪)
                viewModel.foodItems.forEach { food ->
                    val fx = food.x * scaleX
                    val fy = food.y * scaleY
                    val fr = FOOD_RADIUS * scaleX

                    if (food.type == "apple") {
                        // Crimson Apple representation
                        drawCircle(Color(0xFFFFB4AB), radius = fr, center = Offset(fx, fy)) // Theme pinkish/red item
                        drawCircle(Color.White.copy(alpha = 0.5f), radius = fr * 0.25f, center = Offset(fx - fr * 0.4f, fy - fr * 0.4f))
                        // Stem
                        drawLine(
                            color = Color(0xFF44474E),
                            start = Offset(fx, fy - fr),
                            end = Offset(fx + 4f, fy - fr - 8f),
                            strokeWidth = 2.5f
                        )
                    } else {
                        // Golden cookie
                        drawCircle(Color(0xFFE2E2E6), radius = fr, center = Offset(fx, fy)) // Grey white treats
                        drawCircle(Color(0xFF111318), radius = fr * 0.15f, center = Offset(fx - fr * 0.3f, fy - fr * 0.2f))
                        drawCircle(Color(0xFF111318), radius = fr * 0.15f, center = Offset(fx + fr * 0.3f, fy - fr * 0.3f))
                        drawCircle(Color(0xFF111318), radius = fr * 0.15f, center = Offset(fx, fy + fr * 0.4f))
                    }
                }

                // FLOATING TEXTS: Render with backdrop pills styling inside canvas
                viewModel.floatingTexts.forEach { ft ->
                    val tx = ft.x * scaleX
                    val ty = ft.y * scaleY

                    // Shadow/Outline background text
                    drawContext.canvas.nativeCanvas.drawText(
                        ft.text,
                        tx,
                        ty + 1.5f,
                        android.graphics.Paint().apply {
                            color = android.graphics.Color.BLACK
                            alpha = (ft.alpha * 255).toInt().coerceIn(0, 255)
                            textSize = 14f * scaleX
                            typeface = android.graphics.Typeface.MONOSPACE
                            isFakeBoldText = true
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                    )

                    drawContext.canvas.nativeCanvas.drawText(
                        ft.text,
                        tx,
                        ty,
                        android.graphics.Paint().apply {
                            color = ft.color.toInt()
                            alpha = (ft.alpha * 255).toInt().coerceIn(0, 255)
                            textSize = 14f * scaleX
                            typeface = android.graphics.Typeface.MONOSPACE
                            isFakeBoldText = true
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                    )
                }
            }

            // Top overlay showing central floating status message (Like Phaser Overlay)
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
                    .background(Color(0xFF1A1C1E).copy(alpha = 0.85f), RoundedCornerShape(100.dp))
                    .border(BorderStroke(1.dp, Color(0xFFD0BCFF).copy(alpha = 0.2f)), RoundedCornerShape(100.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "MOOD: ${getMoodText(stats).uppercase()}",
                    color = Color(0xFFD0BCFF),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // 3. Controller Actions (Transactional overlay layer buttons)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Dispense Button
            Button(
                onClick = { viewModel.dispenseTreat() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF381E72), // Purple primary
                    contentColor = Color(0xFFD0BCFF)
                ),
                shape = RoundedCornerShape(100.dp),
                modifier = Modifier
                    .weight(1.2f)
                    .height(54.dp)
                    .testTag("dispense_treat_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("🥩", fontSize = 18.sp)
                    Text(
                        text = "DISPENSE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Restore / Nap Button
            Button(
                onClick = { viewModel.toggleNap() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2A2D35), // Dark sleek
                    contentColor = Color(0xFFE2E2E6)
                ),
                shape = RoundedCornerShape(100.dp),
                border = BorderStroke(1.dp, Color(0xFF44474E)),
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
                    .testTag("toggle_nap_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(if (stats.isSleeping) "☀️" else "💤", fontSize = 16.sp)
                    Text(
                        text = if (stats.isSleeping) "WAKE UP" else "REST",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

// --- TAB 1: DIAGNOSTIC MATRIX LOGS TAB ---
@Composable
fun DiagnosticMatrixTab(
    stats: PetState,
    foodItemsCount: Int
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("diagnostic_matrix_tab"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        item {
            Text(
                text = "SIMULATION MATRIX DIAGNOSTICS",
                color = Color(0xFFD0BCFF),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        // Numeric Logs Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiagnosticStatCard(
                        modifier = Modifier.weight(1f),
                        label = "NUTRITIONAL DEPTH",
                        value = "${stats.hunger.toInt()}/100",
                        description = "Current metabolised carbs",
                        accentColor = Color(0xFFD0BCFF)
                    )
                    DiagnosticStatCard(
                        modifier = Modifier.weight(1f),
                        label = "VITAL ENERGY LEVEL",
                        value = "${stats.energy.toInt()}/100",
                        description = "Mitochondrial recharge rate",
                        accentColor = Color(0xFFB6EEAF)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiagnosticStatCard(
                        modifier = Modifier.weight(1f),
                        label = "MENTAL BOREDOM LEVEL",
                        value = "${stats.boredom.toInt()}/100",
                        description = "Cortisol accumulation percentage",
                        accentColor = Color(0xFFFFB4AB)
                    )
                    DiagnosticStatCard(
                        modifier = Modifier.weight(1f),
                        label = "ACTIVE DROP MATRIX",
                        value = "$foodItemsCount ITEMS",
                        description = "Active canvas objects in sandbox",
                        accentColor = Color(0xFFE2E2E6)
                    )
                }
            }
        }

        // Lifetime records card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF2D3038), RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1C1E))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "LIFETIME TELEMETRY RECORDS",
                        color = Color(0xFF919094),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    TelemetryRow(label = "TOTAL TRANSACTIONAL FEEDS", value = "${stats.totalFeeds} 🍎")
                    TelemetryRow(label = "COMPLETED RECHARGE NAPS", value = "${stats.totalNaps} 💤")
                    
                    val mins = ((System.currentTimeMillis() - stats.creationTime) / 60000L).coerceAtLeast(0)
                    TelemetryRow(label = "ACTIVE LIFETIME DURATION", value = "$mins MINS")
                    
                    TelemetryRow(label = "OFFLINE PROGRESSION TICKER", value = "ACTIVE ⚡")
                }
            }
        }

        // Raw machine bytes look log mock
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF2D3038), RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF090A0C))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "SYS_LOGGER // RAW_STATE_BYTES",
                        color = Color(0xFFD0BCFF),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Text(
                        text = "ID=1;NAME=${stats.name};HUNGER=${stats.hunger};ENERGY=${stats.energy};SLEEP=${stats.isSleeping};TIME=${stats.lastUpdated}\n" +
                               "200 OK // REPOSITORY TRANSACTION COMMITTED SUCCESSFULLY",
                        color = Color(0xFFB6EEAF).copy(alpha = 0.8f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 13.sp
                    )
                }
            }
        }
    }
}

// --- TAB 2: SYSTEM CONFIGURATION CALIBRATION TAB ---
@Composable
fun ConfigurationTab(
    onRenameRequest: () -> Unit,
    onResetRequest: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("configuration_tab")
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SYSTEM CONFIGURATION / CALIBRATION",
            color = Color(0xFFD0BCFF),
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )

        // Configuration action list
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF2D3038), RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1C1E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                ConfigOptionRow(
                    title = "Calibrate Companion ID Name",
                    subtitle = "Modify character identity handle",
                    emoji = "✏️",
                    onClick = onRenameRequest
                )
                Divider(color = Color(0xFF2D3038), modifier = Modifier.padding(vertical = 12.dp))
                ConfigOptionRow(
                    title = "Execute Clean Format Reboot",
                    subtitle = "Wipe memory nodes & reset pet",
                    emoji = "⚠️",
                    onClick = onResetRequest,
                    isDestructive = true
                )
            }
        }

        // Helpful architecture info block
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF2D3038), RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1C1E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "STAFF ARCHITECTURE NOTE",
                    color = Color(0xFFD0BCFF),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "By decoupling the core metabolic ticker from the render loop, simulation speeds remain strictly uniform across variable device configurations. Offline values are computed symmetrically via deterministic system delta logs when resuming connections.",
                    color = Color(0xFF919094),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

// --- UTILITY ROWS & INNER COMPOSABLES ---

@Composable
fun MetricProgressRow(
    label: String,
    value: Float,
    barColor: Color,
    testTagPrefix: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF919094)
            )
            Text(
                text = "${value.toInt()}%",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = barColor,
                modifier = Modifier.testTag("${testTagPrefix}_percentage_text")
            )
        }
        // Micro track bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(Color(0xFF44474E), RoundedCornerShape(100.dp))
                .testTag("${testTagPrefix}_progress_bar")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = (value / 100f).coerceIn(0f, 1f))
                    .background(barColor, RoundedCornerShape(100.dp))
            )
        }
    }
}

@Composable
fun DiagnosticStatCard(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    description: String,
    accentColor: Color
) {
    Card(
        modifier = modifier.border(1.dp, Color(0xFF2D3038), RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1C1E))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = label,
                color = Color(0xFF919094),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                color = accentColor,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 2.dp)
            )
            Text(
                text = description,
                color = Color(0xFF64748B),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 11.sp
            )
        }
    }
}

@Composable
fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color(0xFF919094), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ConfigOptionRow(
    title: String,
    subtitle: String,
    emoji: String,
    onClick: () -> Unit,
    isDestructive: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(
                    if (isDestructive) Color(0xFF451A03) else Color(0xFF2A2D35),
                    RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(text = emoji, fontSize = 16.sp)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = if (isDestructive) Color(0xFFFFB4AB) else Color(0xFFE2E2E6),
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = Color(0xFF919094),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun BottomNavBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1A1C1E))
            .border(1.dp, Color(0xFF2D3038))
            .navigationBarsPadding()
            .padding(top = 12.dp, bottom = 16.dp, start = 24.dp, end = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab 0: Engine
            BottomNavItem(
                label = "Engine",
                emoji = "🏠",
                isSelected = selectedTab == 0,
                onClick = { onTabSelected(0) },
                modifier = Modifier.testTag("tab_engine")
            )

            // Tab 1: Matrix
            BottomNavItem(
                label = "Matrix",
                emoji = "📊",
                isSelected = selectedTab == 1,
                onClick = { onTabSelected(1) },
                modifier = Modifier.testTag("tab_matrix")
            )

            // Tab 2: Config
            BottomNavItem(
                label = "Config",
                emoji = "🛠️",
                isSelected = selectedTab == 2,
                onClick = { onTabSelected(2) },
                modifier = Modifier.testTag("tab_config")
            )
        }
    }
}

@Composable
fun BottomNavItem(
    label: String,
    emoji: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(80.dp)
            .clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(32.dp)
                .background(
                    if (isSelected) Color(0xFFD0BCFF) else Color.Transparent,
                    RoundedCornerShape(100.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emoji,
                fontSize = 16.sp
            )
        }
        Text(
            text = label,
            color = if (isSelected) Color(0xFFE2E2E6) else Color(0xFF919094),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace
        )
    }
}

// Helper methods

fun getMoodText(stats: PetState): String {
    return when {
        stats.isSleeping -> "Sleeping"
        stats.hunger < 30f -> "Starving"
        stats.energy < 30f -> "Exhausted"
        stats.boredom > 70f -> "Bored"
        else -> "Satisfied"
    }
}
