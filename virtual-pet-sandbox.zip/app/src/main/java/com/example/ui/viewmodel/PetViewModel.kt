package com.example.ui.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.PetState
import com.example.data.repository.PetRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.hypot

// Normalized Coordinate System: 1000 x 1000
const val SIM_WIDTH = 1000f
const val SIM_HEIGHT = 1000f
const val SIM_FLOOR_Y = 880f
const val PET_RADIUS = 75f
const val FOOD_RADIUS = 30f

data class FoodItem(
    val id: Long,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val type: String = "apple" // e.g. "apple", "cookie"
)

data class FloatingText(
    val id: Long,
    val text: String,
    var x: Float,
    var y: Float,
    val color: Long, // Hex color
    var alpha: Float = 1.0f,
    var scale: Float = 1.0f
)

class PetViewModel(private val repository: PetRepository) : ViewModel() {

    private val _petStats = MutableStateFlow(PetState())
    val petStats: StateFlow<PetState> = _petStats.asStateFlow()

    // Screen state elements (for live frame rate physics & visual FX)
    var petX by mutableStateOf(SIM_WIDTH / 2f)
        private set
    var petY by mutableStateOf(SIM_FLOOR_Y - PET_RADIUS)
        private set
    var petVx by mutableStateOf(0f)
        private set

    val foodItems = mutableStateListOf<FoodItem>()
    val floatingTexts = mutableStateListOf<FloatingText>()

    private var isInitialized = false
    private var simulationJob: Job? = null
    private var decayJob: Job? = null

    init {
        loadAndInitializePet()
    }

    private fun loadAndInitializePet() {
        viewModelScope.launch(Dispatchers.IO) {
            // Retrieve or initialize the pet state
            var state = repository.getPetState()
            if (state == null) {
                state = PetState()
                repository.savePetState(state)
            } else {
                // Determine offline progression
                val now = System.currentTimeMillis()
                val elapsedMs = now - state.lastUpdated
                if (elapsedMs > 5000) {
                    state = calculateOfflineProgression(state, elapsedMs)
                }
            }

            _petStats.value = state
            petX = SIM_WIDTH / 2f
            petY = SIM_FLOOR_Y - PET_RADIUS
            isInitialized = true

            // Launch headless metabolic and physics simulation loops
            startSimulationLoops()
        }
    }

    private fun calculateOfflineProgression(initial: PetState, elapsedMs: Long): PetState {
        val elapsedSeconds = (elapsedMs / 1000).coerceAtMost(86400) // Cap decay at 24 hours
        
        var hunger = initial.hunger
        var energy = initial.energy
        var boredom = initial.boredom
        var isSleeping = initial.isSleeping
        var totalNaps = initial.totalNaps

        // Offline progression evaluation logic
        if (isSleeping) {
            // Energy recovers, hunger decays slower
            val sleepSeconds = elapsedSeconds.coerceAtMost(((100f - energy) / 2.0f).toLong().coerceAtLeast(0L))
            energy = (energy + (sleepSeconds * 2.0f)).coerceIn(0f, 100f)
            hunger = (hunger - (sleepSeconds * 0.15f)).coerceIn(0f, 100f)
            boredom = (boredom + (sleepSeconds * 0.05f)).coerceIn(0f, 100f)

            if (energy >= 99.9f) {
                isSleeping = false
                // Remaining awake decay
                val awakeSeconds = elapsedSeconds - sleepSeconds
                if (awakeSeconds > 0) {
                    hunger = (hunger - (awakeSeconds * 0.4f)).coerceIn(0f, 100f)
                    energy = (energy - (awakeSeconds * 0.15f)).coerceIn(0f, 100f)
                    boredom = (boredom + (awakeSeconds * 0.2f)).coerceIn(0f, 100f)
                }
            }
        } else {
            // Awake decay
            hunger = (hunger - (elapsedSeconds * 0.4f)).coerceIn(0f, 100f)
            energy = (energy - (elapsedSeconds * 0.15f)).coerceIn(0f, 100f)
            boredom = (boredom + (elapsedSeconds * 0.2f)).coerceIn(0f, 100f)
        }

        return initial.copy(
            hunger = hunger,
            energy = energy,
            boredom = boredom,
            isSleeping = isSleeping,
            totalNaps = totalNaps,
            lastUpdated = System.currentTimeMillis()
        )
    }

    private fun startSimulationLoops() {
        // Core Physics loop (~60 FPS / 16ms delta steps)
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch(Dispatchers.Main) {
            var lastFrameTime = System.currentTimeMillis()
            while (true) {
                val now = System.currentTimeMillis()
                val dt = (now - lastFrameTime) / 1000f
                lastFrameTime = now
                
                stepPhysics(dt)
                delay(16)
            }
        }

        // Centralized deterministic decay timer (1Hz frequency updates)
        decayJob?.cancel()
        decayJob = viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(1000)
                if (isInitialized) {
                    stepMetabolism()
                }
            }
        }
    }

    // --- STEP 1: METABOLISM SIMULATION (1Hz Ticker) ---
    private suspend fun stepMetabolism() {
        val current = _petStats.value
        var hunger = current.hunger
        var energy = current.energy
        var boredom = current.boredom
        var isSleeping = current.isSleeping
        var totalNaps = current.totalNaps

        if (isSleeping) {
            // Recover energy and slowly decay hunger
            energy = (energy + 2.0f).coerceAtMost(100f)
            hunger = (hunger - 0.15f).coerceAtLeast(0f)
            boredom = (boredom + 0.05f).coerceAtMost(100f)
            if (energy >= 100f) {
                isSleeping = false
                viewModelScope.launch(Dispatchers.Main) {
                    spawnFloatingPopup(petX, petY - 80f, "☀️ AWAKE", 0xFF22D3EE)
                }
            }
        } else {
            // Standard metabolic decay
            hunger = (hunger - 0.4f).coerceAtLeast(0f)
            energy = (energy - 0.15f).coerceAtLeast(0f)
            boredom = (boredom + 0.2f).coerceAtMost(100f)
        }

        val updated = current.copy(
            hunger = hunger,
            energy = energy,
            boredom = boredom,
            isSleeping = isSleeping,
            lastUpdated = System.currentTimeMillis()
        )

        _petStats.value = updated
        repository.savePetState(updated)
    }

    // --- STEP 2: DETERMINISTIC 2D CANVAS PHYSICS LOOP ---
    private fun stepPhysics(dt: Float) {
        val currentStats = _petStats.value

        // 1. Food items falling and bouncing
        val gravity = 25f // pixels/sec^2
        val bounce = 0.45f
        val frictionX = 0.98f

        val eatenIndexes = mutableListOf<Int>()

        for (i in foodItems.indices) {
            val food = foodItems[i]
            
            // Apply gravity
            food.vy += gravity * dt * 60f
            food.x += food.vx * dt * 60f
            food.y += food.vy * dt * 60f

            // Floor boundary collision
            val floorLimit = SIM_FLOOR_Y - FOOD_RADIUS
            if (food.y >= floorLimit) {
                food.y = floorLimit
                food.vy = -food.vy * bounce
                food.vx *= frictionX // apply friction on slide
                if (kotlin.math.abs(food.vy) < 1.5f) {
                    food.vy = 0f
                }
            }

            // Wall boundaries
            if (food.x < FOOD_RADIUS) {
                food.x = FOOD_RADIUS
                food.vx = -food.vx * bounce
            } else if (food.x > SIM_WIDTH - FOOD_RADIUS) {
                food.x = SIM_WIDTH - FOOD_RADIUS
                food.vx = -food.vx * bounce
            }

            // Proximity/Eating collision detection
            val dist = hypot(petX - food.x, petY - food.y)
            if (dist < (PET_RADIUS + FOOD_RADIUS) && !currentStats.isSleeping) {
                eatenIndexes.add(i)
            }
        }

        // Process eaten items
        for (idx in eatenIndexes.sortedDescending()) {
            val food = foodItems[idx]
            foodItems.removeAt(idx)

            // Modify metabolic states in response to eating
            val prevHunger = _petStats.value.hunger
            val nextHunger = (prevHunger + 20f).coerceAtMost(100f)
            val updated = _petStats.value.copy(
                hunger = nextHunger,
                totalFeeds = _petStats.value.totalFeeds + 1,
                lastUpdated = System.currentTimeMillis()
            )
            _petStats.value = updated
            
            viewModelScope.launch(Dispatchers.IO) {
                repository.savePetState(updated)
            }

            // UI feedback
            spawnFloatingPopup(petX, petY - 60f, "+20 NUTRITION 🍎", 0xFF22D3EE)
        }

        // 2. Pet Horizontal Movement AI logic
        if (!currentStats.isSleeping && foodItems.isNotEmpty()) {
            // Find closest food
            val closestFood = foodItems.minByOrNull { hypot(petX - it.x, petY - it.y) }
            closestFood?.let { targetFood ->
                val dx = targetFood.x - petX
                if (kotlin.math.abs(dx) > 10f) {
                    val direction = kotlin.math.sign(dx)
                    // Apply smooth acceleration
                    petVx += direction * 1.5f
                }
            }
        } else {
            // Friction/Deceleration when no food
            petVx *= 0.82f
        }

        // Apply speed limit
        val maxSpeed = 12f
        petVx = petVx.coerceIn(-maxSpeed, maxSpeed)
        
        // Move pet
        petX += petVx

        // Stay within boundaries
        val petMinX = PET_RADIUS
        val petMaxX = SIM_WIDTH - PET_RADIUS
        if (petX < petMinX) {
            petX = petMinX
            petVx = 0f
        } else if (petX > petMaxX) {
            petX = petMaxX
            petVx = 0f
        }

        // 3. Floating text updates
        val textIterator = floatingTexts.iterator()
        while (textIterator.hasNext()) {
            val textObj = textIterator.next()
            textObj.y -= 3f // Rise upward
            textObj.alpha -= 0.03f // Fade out
            if (textObj.alpha <= 0f) {
                textIterator.remove()
            }
        }
    }

    // --- ACTIONS HANDLERS ---
    fun dispenseTreat() {
        if (_petStats.value.isSleeping) {
            spawnFloatingPopup(petX, petY - 80f, "SHHH... SLEEPING 💤", 0xFFA855F7)
            return
        }

        val spawnX = (SIM_WIDTH / 2) + (Math.random().toFloat() - 0.5f) * (SIM_WIDTH * 0.6f)
        val vy = 2f
        val vx = (Math.random().toFloat() - 0.5f) * 10f
        val isApple = Math.random() > 0.4
        
        val newItem = FoodItem(
            id = System.nanoTime(),
            x = spawnX,
            y = 50f,
            vx = vx,
            vy = vy,
            type = if (isApple) "apple" else "cookie"
        )
        foodItems.add(newItem)

        spawnFloatingPopup(spawnX, 100f, "🍎 TREAT SPONTANEOUS", 0xFFF43F5E)
    }

    fun toggleNap() {
        val current = _petStats.value
        if (current.isSleeping) {
            // Wake up
            val updated = current.copy(
                isSleeping = false,
                lastUpdated = System.currentTimeMillis()
            )
            _petStats.value = updated
            viewModelScope.launch(Dispatchers.IO) { repository.savePetState(updated) }
            spawnFloatingPopup(petX, petY - 80f, "☀️ AWAKE", 0xFF22D3EE)
        } else {
            // Go to sleep
            if (current.energy >= 95f) {
                spawnFloatingPopup(petX, petY - 80f, "NOT TIRED ⚡", 0xFFFBBF24)
                return
            }
            val updated = current.copy(
                isSleeping = true,
                totalNaps = current.totalNaps + 1,
                lastUpdated = System.currentTimeMillis()
            )
            _petStats.value = updated
            viewModelScope.launch(Dispatchers.IO) { repository.savePetState(updated) }
            spawnFloatingPopup(petX, petY - 80f, "💤 RESTING", 0xFFA855F7)
        }
    }

    fun playWithPet() {
        val current = _petStats.value
        if (current.isSleeping) {
            spawnFloatingPopup(petX, petY - 80f, "SHHH... SLEEPING 💤", 0xFFA855F7)
            return
        }
        if (current.energy < 15f) {
            spawnFloatingPopup(petX, petY - 80f, "TOO TIRED TO PLAY ⚡", 0xFFEF4444)
            return
        }

        val nextBoredom = (current.boredom - 25f).coerceAtLeast(0f)
        val nextEnergy = (current.energy - 10f).coerceAtLeast(0f)
        val updated = current.copy(
            boredom = nextBoredom,
            energy = nextEnergy,
            lastUpdated = System.currentTimeMillis()
        )
        _petStats.value = updated
        viewModelScope.launch(Dispatchers.IO) { repository.savePetState(updated) }

        // Jump physical action
        petVx = (Math.random().toFloat() - 0.5f) * 15f
        spawnFloatingPopup(petX, petY - 80f, "YAY! FUN! 🎉", 0xFF34D399)
    }

    fun renamePet(newName: String) {
        val cleanName = newName.trim().take(15)
        if (cleanName.isNotEmpty()) {
            val updated = _petStats.value.copy(name = cleanName)
            _petStats.value = updated
            viewModelScope.launch(Dispatchers.IO) { repository.savePetState(updated) }
            spawnFloatingPopup(petX, petY - 80f, "NAMED: $cleanName ✨", 0xFFF43F5E)
        }
    }

    fun resetPet() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.resetPetState()
            val freshState = repository.getPetState() ?: PetState()
            _petStats.value = freshState
            
            viewModelScope.launch(Dispatchers.Main) {
                foodItems.clear()
                floatingTexts.clear()
                petX = SIM_WIDTH / 2f
                petVx = 0f
                spawnFloatingPopup(petX, petY - 80f, "SYSTEM RESET // FRESH NEW PET", 0xFFFFE4E6)
            }
        }
    }

    private fun spawnFloatingPopup(x: Float, y: Float, text: String, color: Long) {
        floatingTexts.add(
            FloatingText(
                id = System.nanoTime(),
                text = text,
                x = x,
                y = y,
                color = color
            )
        )
    }

    override fun onCleared() {
        simulationJob?.cancel()
        decayJob?.cancel()
        super.onCleared()
    }
}

class PetViewModelFactory(private val repository: PetRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PetViewModel::class.java)) {
            return PetViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
