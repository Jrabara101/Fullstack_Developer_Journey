import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// Initialize Google GenAI with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Endpoint: Parse natural language voice intent using Gemini AI
app.post("/api/parse-intent", async (req, res) => {
  try {
    const { transcript, currentView, contextData, forcedConfidence } = req.body;

    if (!transcript || typeof transcript !== "string") {
      return res.status(400).json({ error: "Transcript is required" });
    }

    // Call Gemini 3.7 Flash with structured schema output
    const prompt = `You are the Natural Language Voice Intent Processing Engine for an advanced Voice User Interface (VUI) platform.
The user just spoke the following voice transcript:
"${transcript}"

Current Application Context:
- Active Screen / View: "${currentView || "crm"}"
- Context Snapshot: ${JSON.stringify(contextData || {})}

Your task is to analyze this transcript, detect the exact user intent, extract structured parameters, determine a calibrated confidence score between 0.00 and 1.00 (or use acoustic context), classify into confidence tier (high: >=0.85, medium: 0.50-0.84, low: <0.50), provide disambiguation suggestions if medium, and provide rephrase suggestions if low.

Intent Categories:
- NAVIGATE: { targetView: 'crm' | 'dictation' | 'inspection' | 'analytics' | 'compliance' }
- FILTER_LEADS: { status?: 'active' | 'in_review' | 'lead' | 'won' | 'lost' | 'all', industry?: string, minRevenue?: number }
- SEARCH_LEADS: { query: string }
- SORT_LEADS: { field: 'name' | 'company' | 'revenue' | 'date' | 'score', direction: 'asc' | 'desc' }
- EXPORT_REPORT: { reportType: 'q3_leads' | 'full_crm' | 'inspection_summary' | 'notes', format: 'pdf' | 'csv' }
- DICTATE_APPEND: { text: string, isBullet?: boolean, isNewLine?: boolean }
- NOTE_COMMAND: { action: 'clear' | 'summarize' | 'uppercase' | 'copy' | 'save' }
- INSPECT_ACTION: { itemId?: string, status?: 'pass' | 'fail' | 'flag', notes?: string, actionType?: 'next' | 'prev' | 'mark_all_pass' | 'reset' }
- UNDO: {}
- TOGGLE_VUI_MODE: { mode?: 'ptt' | 'continuous', privacyLevel?: 'hipaa' | 'gdpr' | 'standard' }
- HELP: { topic?: string }
- UNKNOWN: { rawText: string }

Respond in pure JSON matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            intent: {
              type: Type.STRING,
              description: "The primary action intent code e.g. FILTER_LEADS, NAVIGATE, EXPORT_REPORT, DICTATE_APPEND, INSPECT_ACTION, UNDO, UNKNOWN",
            },
            actionLabel: {
              type: Type.STRING,
              description: "A short, readable description of the action, e.g. 'Filter leads by Active status'",
            },
            parameters: {
              type: Type.OBJECT,
              description: "Extracted parameters for the intent",
              properties: {
                targetView: { type: Type.STRING },
                status: { type: Type.STRING },
                industry: { type: Type.STRING },
                query: { type: Type.STRING },
                field: { type: Type.STRING },
                direction: { type: Type.STRING },
                reportType: { type: Type.STRING },
                format: { type: Type.STRING },
                text: { type: Type.STRING },
                isBullet: { type: Type.BOOLEAN },
                isNewLine: { type: Type.BOOLEAN },
                action: { type: Type.STRING },
                itemId: { type: Type.STRING },
                actionType: { type: Type.STRING },
                notes: { type: Type.STRING },
                mode: { type: Type.STRING },
                privacyLevel: { type: Type.STRING },
              },
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: "Score from 0.00 to 1.00 indicating certainty of interpretation",
            },
            confidenceTier: {
              type: Type.STRING,
              description: "'high' if >=0.85, 'medium' if 0.50-0.84, 'low' if <0.50",
            },
            disambiguationOptions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  label: { type: Type.STRING },
                  intent: { type: Type.STRING },
                  parametersJson: { type: Type.STRING },
                },
                required: ["label", "intent"],
              },
              description: "2-3 alternative interpretation options for medium confidence",
            },
            rephraseSuggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "2-3 tips on how to clearly rephrase for low confidence",
            },
            explanation: {
              type: Type.STRING,
              description: "Brief rationale of the intent parsing and confidence assessment",
            },
          },
          required: [
            "intent",
            "actionLabel",
            "confidenceScore",
            "confidenceTier",
            "disambiguationOptions",
            "rephraseSuggestions",
            "explanation",
          ],
        },
      },
    });

    const parsedJson = JSON.parse(response.text || "{}");

    // Allow simulated forced confidence if testing specific routing UX
    if (typeof forcedConfidence === "number") {
      parsedJson.confidenceScore = forcedConfidence;
      if (forcedConfidence >= 0.85) parsedJson.confidenceTier = "high";
      else if (forcedConfidence >= 0.5) parsedJson.confidenceTier = "medium";
      else parsedJson.confidenceTier = "low";
    }

    res.json({
      success: true,
      data: parsedJson,
    });
  } catch (error: any) {
    console.error("Error in /api/parse-intent:", error);
    // Provide a resilient fallback if Gemini is momentarily unavailable
    res.status(200).json({
      success: true,
      data: {
        intent: "UNKNOWN",
        actionLabel: "Command received",
        parameters: { text: req.body?.transcript || "" },
        confidenceScore: 0.75,
        confidenceTier: "medium",
        disambiguationOptions: [
          { label: `Search for "${req.body?.transcript}"`, intent: "SEARCH_LEADS", parametersJson: JSON.stringify({ query: req.body?.transcript }) },
          { label: `Append "${req.body?.transcript}" to Notes`, intent: "DICTATE_APPEND", parametersJson: JSON.stringify({ text: req.body?.transcript }) },
        ],
        rephraseSuggestions: [
          'Say "Filter leads by active status"',
          'Say "Go to dictation notepad"',
          'Say "Export Q3 report"',
        ],
        explanation: "Processed with heuristic fallback",
      },
    });
  }
});

// Endpoint: Multimodal Audio Transcription fallback via Gemini 3.7 Flash
app.post("/api/transcribe-audio", async (req, res) => {
  try {
    const { audioBase64, mimeType = "audio/webm" } = req.body;

    if (!audioBase64) {
      return res.status(400).json({ error: "audioBase64 is required" });
    }

    const audioPart = {
      inlineData: {
        data: audioBase64,
        mimeType: mimeType,
      },
    };

    const textPrompt = {
      text: "Transcribe the spoken words in this audio snippet accurately. Return ONLY the exact transcript text with proper capitalization and punctuation. Do not add conversational prefixes or timestamps.",
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: { parts: [audioPart, textPrompt] },
    });

    const transcript = response.text?.trim() || "";

    res.json({
      success: true,
      transcript,
    });
  } catch (error: any) {
    console.error("Error in /api/transcribe-audio:", error);
    res.status(500).json({
      error: "Audio transcription failed",
      message: error.message,
    });
  }
});

// Endpoint: AI Note Summarizer / Formatter
app.post("/api/enhance-note", async (req, res) => {
  try {
    const { text, action } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is required" });
    }

    let prompt = "";
    if (action === "summarize") {
      prompt = `Summarize the following dictation into 3 concise executive bullet points:\n\n${text}`;
    } else if (action === "format") {
      prompt = `Clean up and format this raw voice dictation into clear, professional meeting notes with headers, action items, and bullet points:\n\n${text}`;
    } else if (action === "action_items") {
      prompt = `Extract all action items, assignees, and deadlines from this voice transcript:\n\n${text}`;
    } else {
      prompt = `Proofread and polish this voice note for clarity while keeping original meaning:\n\n${text}`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
    });

    res.json({
      success: true,
      result: response.text?.trim() || text,
    });
  } catch (error: any) {
    console.error("Error in /api/enhance-note:", error);
    res.status(500).json({ error: error.message });
  }
});

// Vite middleware setup for dev vs production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`VUI Platform Server listening on http://localhost:${PORT}`);
  });
}

startServer();
