/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ActiveTab,
  DisambiguationOption,
  InspectionStep,
  IntentParseResult,
  LeadItem,
  PrivacyMode,
  UndoableAction,
  VuiLogEntry,
  VuiMode,
  VuiState,
} from './types';
import { VoiceController } from './services/voiceController';
import { VuiScaffolding } from './components/VuiScaffolding';
import { ConfidenceRouterModal } from './components/ConfidenceRouterModal';
import { PermissionPrimingModal } from './components/PermissionPrimingModal';
import { PrivacyComplianceCenter } from './components/PrivacyComplianceCenter';
import { CrossBrowserMatrix } from './components/CrossBrowserMatrix';
import { CrmLeadsView } from './components/views/CrmLeadsView';
import { VoiceNotepadView } from './components/views/VoiceNotepadView';
import { HandsFreeInspectionView } from './components/views/HandsFreeInspectionView';
import { VuiAnalyticsView } from './components/views/VuiAnalyticsView';
import { VoiceFloatingController } from './components/VoiceFloatingController';
import {
  Mic,
  Users,
  FileText,
  ClipboardCheck,
  Shield,
  Layers,
  BarChart3,
  Sparkles,
  Volume2,
  Lock,
  Compass,
} from 'lucide-react';
import confetti from 'canvas-confetti';

const INITIAL_LEADS: LeadItem[] = [
  {
    id: 'lead-1',
    name: 'Sarah Chen',
    company: 'Nexus Robotics',
    title: 'VP of Hardware Systems',
    email: 's.chen@nexusrobotics.io',
    phone: '+1 (415) 890-1200',
    status: 'active',
    revenue: 185000,
    industry: 'Technology',
    quarter: 'Q3',
    score: 96,
    lastContact: 'Yesterday',
  },
  {
    id: 'lead-2',
    name: 'Marcus Vance',
    company: 'Apex Health Systems',
    title: 'Chief Medical Officer',
    email: 'mvance@apexhealth.org',
    phone: '+1 (617) 555-4321',
    status: 'in_review',
    revenue: 340000,
    industry: 'Healthcare',
    quarter: 'Q3',
    score: 91,
    lastContact: '3 days ago',
  },
  {
    id: 'lead-3',
    name: 'Elena Rostova',
    company: 'Solaria Energy',
    title: 'Director of Procurement',
    email: 'elena@solariaenergy.com',
    phone: '+1 (512) 777-9922',
    status: 'won',
    revenue: 520000,
    industry: 'Manufacturing',
    quarter: 'Q3',
    score: 99,
    lastContact: 'Just now',
  },
  {
    id: 'lead-4',
    name: 'David Kalu',
    company: 'Vanguard FinTech',
    title: 'Head of Infrastructure',
    email: 'dkalu@vanguardft.com',
    phone: '+1 (212) 440-8811',
    status: 'active',
    revenue: 290000,
    industry: 'Finance',
    quarter: 'Q3',
    score: 88,
    lastContact: '4 hours ago',
  },
  {
    id: 'lead-5',
    name: 'Chloe Tremblay',
    company: 'Aura Logistics Group',
    title: 'Supply Chain VP',
    email: 'chloe@auralogistics.ca',
    phone: '+1 (514) 333-8899',
    status: 'lead',
    revenue: 145000,
    industry: 'Manufacturing',
    quarter: 'Q4',
    score: 79,
    lastContact: '1 week ago',
  },
  {
    id: 'lead-6',
    name: 'Julian Hayes',
    company: 'Beacon Retail Labs',
    title: 'General Manager',
    email: 'jhayes@beaconretail.com',
    phone: '+1 (312) 990-2211',
    status: 'lost',
    revenue: 95000,
    industry: 'Retail',
    quarter: 'Q2',
    score: 64,
    lastContact: '2 weeks ago',
  },
];

const INITIAL_INSPECTION_STEPS: InspectionStep[] = [
  {
    id: 'step-1',
    code: 'SAFE-101',
    title: 'Prep Counter & Knife Sanitization Log',
    area: 'Food Prep',
    threshold: '100% surface swab negative for pathogens',
    status: 'pending',
  },
  {
    id: 'step-2',
    code: 'TEMP-204',
    title: 'Walk-In Refrigeration Core Temperature',
    area: 'Refrigeration Temp',
    threshold: 'Must maintain between 34°F and 38°F',
    status: 'pending',
  },
  {
    id: 'step-3',
    code: 'FIRE-302',
    title: 'Hood Suppression & Emergency Pressure Gauge',
    area: 'Fire Safety',
    threshold: 'Needle firmly in green arc (150-175 PSI)',
    status: 'pending',
  },
  {
    id: 'step-4',
    code: 'SANI-408',
    title: 'High-Temp Dishwasher Final Rinse Cycle',
    area: 'Sanitation',
    threshold: 'Minimum 180°F rinse temperature verified',
    status: 'pending',
  },
];

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('crm');

  // VUI State
  const [vuiState, setVuiState] = useState<VuiState>('idle');
  const [vuiMode, setVuiMode] = useState<VuiMode>('ptt');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [audioLevel, setAudioLevel] = useState(0);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [finalTranscript, setFinalTranscript] = useState('');
  const [currentIntentResult, setCurrentIntentResult] = useState<IntentParseResult | null>(null);
  const [activeUndoAction, setActiveUndoAction] = useState<UndoableAction | null>(null);
  const [isPrimingOpen, setIsPrimingOpen] = useState(false);
  const [consecutiveFailures, setConsecutiveFailures] = useState(0);

  // Compliance Configuration
  const [privacyMode, setPrivacyMode] = useState<PrivacyMode>('standard');
  const [zeroRetention, setZeroRetention] = useState(true);
  const [piiScrubbing, setPiiScrubbing] = useState(true);

  // Business Data
  const [leads, setLeads] = useState<LeadItem[]>(INITIAL_LEADS);
  const [crmFilterStatus, setCrmFilterStatus] = useState('all');
  const [crmSearchQuery, setCrmSearchQuery] = useState('');
  const [crmSortBy, setCrmSortBy] = useState('revenue');
  const [crmSortDir, setCrmSortDir] = useState<'asc' | 'desc'>('desc');
  const [crmIndustry, setCrmIndustry] = useState('all');

  // Dictation Notes
  const [noteContent, setNoteContent] = useState(
    'Meeting with Enterprise Engineering leads.\n- Discussed VUI latency targets (<200ms)\n- Approved Push-to-Talk as default privacy guard\n- Reviewed confidence score thresholds (85% high, 50% medium)'
  );

  // Inspection Checklist
  const [inspectionSteps, setInspectionSteps] = useState<InspectionStep[]>(INITIAL_INSPECTION_STEPS);

  // Telemetry Logs
  const [vuiLogs, setVuiLogs] = useState<VuiLogEntry[]>([]);

  // Input refs for multi-modal keyboard fallback
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  // Voice controller reference
  const voiceControllerRef = useRef<VoiceController | null>(null);

  // Initialize VoiceController
  useEffect(() => {
    const controller = new VoiceController({
      onStateChange: (state) => setVuiState(state),
      onInterimTranscript: (text) => setInterimTranscript(text),
      onFinalTranscript: (text, confidence) => {
        setFinalTranscript(text);
        setInterimTranscript('');
      },
      onError: (err) => {
        console.warn("VUI Error:", err);
      },
      onIntentParsed: (result) => {
        handleIntentResult(result);
      },
      onAudioLevel: (lvl) => setAudioLevel(lvl),
    });

    voiceControllerRef.current = controller;

    return () => {
      controller.stopListening();
    };
  }, []);

  // Sync mode changes with controller
  useEffect(() => {
    if (voiceControllerRef.current) {
      voiceControllerRef.current.setMode(vuiMode);
    }
  }, [vuiMode]);

  // Sync sound changes with controller
  useEffect(() => {
    if (voiceControllerRef.current) {
      voiceControllerRef.current.setSoundEnabled(soundEnabled);
    }
  }, [soundEnabled]);

  // Keyboard Spacebar Push-to-Talk Shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is currently typing in an input or textarea
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }
      if (e.code === 'Space' && !e.repeat && vuiMode === 'ptt') {
        e.preventDefault();
        voiceControllerRef.current?.startListening(activeTab, {
          leadsCount: leads.length,
          filterStatus: crmFilterStatus,
          crmSortBy,
        });
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }
      if (e.code === 'Space' && vuiMode === 'ptt') {
        e.preventDefault();
        voiceControllerRef.current?.stopListening();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [vuiMode, activeTab, leads.length, crmFilterStatus, crmSortBy]);

  // Intent Action Execution Engine
  const executeAction = useCallback((intent: string, params: any, rawTranscript: string = '', isDisambiguated: boolean = false) => {
    const prevStatus = crmFilterStatus;
    const prevSearch = crmSearchQuery;
    const prevSort = crmSortBy;
    const prevNote = noteContent;
    const prevSteps = [...inspectionSteps];

    let actionLabel = 'Voice action executed';
    let undoFn: (() => void) | null = null;

    switch (intent) {
      case 'NAVIGATE': {
        if (params.targetView) {
          setActiveTab(params.targetView as ActiveTab);
          actionLabel = `Navigated to ${params.targetView.toUpperCase()} view`;
          undoFn = () => setActiveTab(activeTab);
        }
        break;
      }

      case 'FILTER_LEADS': {
        setActiveTab('crm');
        if (params.status) {
          setCrmFilterStatus(params.status.toLowerCase());
          actionLabel = `Filtered leads by ${params.status.toUpperCase()} status`;
          undoFn = () => setCrmFilterStatus(prevStatus);
        }
        if (params.industry) {
          setCrmIndustry(params.industry);
          actionLabel = `Filtered leads by ${params.industry} industry`;
        }
        break;
      }

      case 'SEARCH_LEADS': {
        setActiveTab('crm');
        if (params.query) {
          setCrmSearchQuery(params.query);
          actionLabel = `Searched leads for “${params.query}”`;
          undoFn = () => setCrmSearchQuery(prevSearch);
        }
        break;
      }

      case 'SORT_LEADS': {
        setActiveTab('crm');
        if (params.field) {
          setCrmSortBy(params.field);
          if (params.direction) setCrmSortDir(params.direction);
          actionLabel = `Sorted leads by ${params.field} (${params.direction || 'desc'})`;
          undoFn = () => setCrmSortBy(prevSort);
        }
        break;
      }

      case 'EXPORT_REPORT': {
        exportReportCsv(params.reportType || 'q3_leads');
        actionLabel = `Exported ${params.reportType || 'Q3'} report as CSV`;
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.8 } });
        break;
      }

      case 'DICTATE_APPEND': {
        setActiveTab('dictation');
        const appendText = params.text || rawTranscript;
        if (params.isBullet) {
          setNoteContent((prev) => `${prev}\n• ${appendText}`);
          actionLabel = `Appended bullet point to notes`;
        } else if (params.isNewLine) {
          setNoteContent((prev) => `${prev}\n${appendText}`);
          actionLabel = `Appended new line to notes`;
        } else {
          setNoteContent((prev) => `${prev} ${appendText}`);
          actionLabel = `Appended text to notes`;
        }
        undoFn = () => setNoteContent(prevNote);
        break;
      }

      case 'NOTE_COMMAND': {
        setActiveTab('dictation');
        if (params.action === 'clear') {
          setNoteContent('');
          actionLabel = `Cleared dictation notepad`;
          undoFn = () => setNoteContent(prevNote);
        } else if (params.action === 'summarize') {
          actionLabel = `Summarizing note with AI...`;
        }
        break;
      }

      case 'INSPECT_ACTION': {
        setActiveTab('inspection');
        if (params.actionType === 'mark_all_pass') {
          setInspectionSteps((prev) =>
            prev.map((s) => ({ ...s, status: 'passed' as const }))
          );
          actionLabel = `Marked all inspection items as passed`;
          undoFn = () => setInspectionSteps(prevSteps);
          confetti({ particleCount: 40, spread: 50, origin: { y: 0.8 } });
        } else if (params.actionType === 'reset') {
          setInspectionSteps(INITIAL_INSPECTION_STEPS);
          actionLabel = `Reset inspection checklist`;
          undoFn = () => setInspectionSteps(prevSteps);
        } else if (params.status) {
          // Update first pending or matching item
          const targetIndex = params.itemId ? parseInt(params.itemId, 10) - 1 : 0;
          setInspectionSteps((prev) => {
            const next = [...prev];
            const idx = Math.min(Math.max(0, targetIndex), next.length - 1);
            next[idx] = {
              ...next[idx],
              status: params.status as any,
              operatorNotes: params.notes || next[idx].operatorNotes,
            };
            return next;
          });
          actionLabel = `Marked inspection item #${targetIndex + 1} as ${params.status.toUpperCase()}`;
          undoFn = () => setInspectionSteps(prevSteps);
        }
        break;
      }

      case 'UNDO': {
        if (activeUndoAction) {
          activeUndoAction.undoFunction();
          setActiveUndoAction(null);
          actionLabel = `Undid previous action: ${activeUndoAction.actionLabel}`;
        }
        break;
      }

      default:
        break;
    }

    // High confidence execution creates 5-second Undo action toast
    if (undoFn) {
      setActiveUndoAction({
        id: `undo-${Date.now()}`,
        actionLabel,
        undoFunction: undoFn,
        timestamp: Date.now(),
        expiresAt: Date.now() + 6000,
      });
    }
  }, [activeTab, crmFilterStatus, crmSearchQuery, crmSortBy, noteContent, inspectionSteps, activeUndoAction]);

  // Handle Intent Result from Gemini
  const handleIntentResult = (result: IntentParseResult) => {
    setCurrentIntentResult(result);

    // Telemetry log entry
    const newLog: VuiLogEntry = {
      id: `log-${Date.now()}`,
      transcript: result.rawTranscript || '',
      detectedIntent: result.intent,
      confidenceScore: result.confidenceScore,
      confidenceTier: result.confidenceTier,
      latencyMs: Math.floor(Math.random() * 80) + 120, // realistic 120-200ms
      executed: result.confidenceTier === 'high',
      engine: 'Gemini 3.7 Flash + WebSpeech',
      timestamp: new Date().toLocaleTimeString(),
    };
    setVuiLogs((prev) => [newLog, ...prev.slice(0, 49)]);

    if (result.confidenceTier === 'high') {
      setConsecutiveFailures(0);
      executeAction(result.intent, result.parameters, result.rawTranscript);
    } else if (result.confidenceTier === 'medium') {
      // Disambiguation dialog opens automatically via currentIntentResult
    } else {
      // Low confidence
      setConsecutiveFailures((prev) => prev + 1);
    }
  };

  // Disambiguation execution
  const handleExecuteDisambiguation = (option: DisambiguationOption) => {
    const params = option.parametersJson ? JSON.parse(option.parametersJson) : {};
    executeAction(option.intent, params, option.label, true);
    setCurrentIntentResult(null);
    setConsecutiveFailures(0);
  };

  // Rephrase selection
  const handleSelectRephrase = (phrase: string) => {
    setCurrentIntentResult(null);
    simulateVoiceCommand(phrase, 0.95);
  };

  // Multi-modal keyboard fallback trigger
  const handleTriggerKeyboardFallback = () => {
    setActiveTab('crm');
    setCurrentIntentResult(null);
    setTimeout(() => {
      searchInputRef.current?.focus();
    }, 100);
  };

  // Simulate command (from chips or testbench)
  const simulateVoiceCommand = (command: string, forcedConfidence?: number) => {
    setFinalTranscript(command);
    voiceControllerRef.current?.processTranscriptWithGemini(
      command,
      forcedConfidence || 0.94,
      activeTab,
      { filterStatus: crmFilterStatus },
      forcedConfidence
    );
  };

  // Export report as CSV
  const exportReportCsv = (type: string = 'q3_leads') => {
    const headers = ['Name', 'Company', 'Title', 'Email', 'Phone', 'Status', 'Revenue', 'Industry', 'Quarter'];
    const rows = leads.map((l) => [
      `"${l.name}"`,
      `"${l.company}"`,
      `"${l.title}"`,
      `"${l.email}"`,
      `"${l.phone}"`,
      `"${l.status}"`,
      l.revenue,
      `"${l.industry}"`,
      `"${l.quarter}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${type}_export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col font-sans antialiased pb-28 relative overflow-x-hidden selection:bg-orange-500/30 selection:text-white">
      {/* Ambient background light orbs for Frosted Glass refraction */}
      <div className="pointer-events-none fixed top-[-20%] left-[-10%] w-[60vw] h-[60vw] bg-orange-900/15 rounded-full blur-[140px] z-0" />
      <div className="pointer-events-none fixed bottom-[-10%] right-[-5%] w-[45vw] h-[45vw] bg-blue-900/15 rounded-full blur-[130px] z-0" />
      <div className="pointer-events-none fixed top-[40%] right-[20%] w-[30vw] h-[30vw] bg-purple-900/10 rounded-full blur-[120px] z-0" />

      {/* Header Bar */}
      <header className="sticky top-0 z-30 bg-black/40 backdrop-blur-2xl border-b border-white/5 px-4 sm:px-8 py-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 relative z-10">
          {/* Logo & Title */}
          <div className="flex items-center gap-3.5">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 text-white shadow-lg shadow-orange-500/20">
              <div className="w-5 h-5 border-2 border-white rounded-full flex items-center justify-center">
                <div className="w-1 h-1 bg-white rounded-full"></div>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-medium tracking-tight text-white">
                  VUI <span className="text-white/40 font-light">ENGINE</span>
                </h1>
                <span className="px-2 py-0.5 text-[9px] font-mono font-bold uppercase bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded-md tracking-wider">
                  Gemini 3.7 Intelligence
                </span>
              </div>
              <p className="text-[11px] text-white/40 font-mono tracking-wide">
                MULTI-MODAL SPEECH & INTENT PIPELINE
              </p>
            </div>
          </div>

          {/* Privacy Badge & Permission Priming Trigger */}
          <div className="flex items-center gap-2.5">
            <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]"></div>
              <span className="text-[10px] font-mono text-white/70 tracking-wider">SYSTEM ACTIVE</span>
            </div>

            <button
              onClick={() => setActiveTab('compliance')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-full border transition-all ${
                privacyMode === 'hipaa'
                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                  : privacyMode === 'gdpr'
                  ? 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                  : 'bg-white/5 text-white/70 border-white/10 hover:bg-white/10'
              }`}
            >
              <Lock className="w-3.5 h-3.5 text-orange-400" />
              <span className="uppercase text-[11px] tracking-wider">{privacyMode} Shield</span>
            </button>

            <button
              onClick={() => setIsPrimingOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium bg-white/5 hover:bg-white/10 text-white/80 rounded-full border border-white/10 transition-colors backdrop-blur-md"
            >
              <Shield className="w-3.5 h-3.5 text-orange-400" />
              <span>Mic Privacy Priming</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-8 py-6 space-y-6 flex-1 relative z-10">
        {/* VUI Scaffolding & Contextual Hints */}
        <VuiScaffolding
          currentView={activeTab}
          vuiState={vuiState}
          interimTranscript={interimTranscript}
          finalTranscript={finalTranscript}
          onSimulateCommand={(cmd) => simulateVoiceCommand(cmd)}
          onNavigateTab={(tab) => setActiveTab(tab)}
        />

        {/* View Navigation Tabs with Frosted Glass styling */}
        <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-3">
          <button
            onClick={() => setActiveTab('crm')}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs uppercase tracking-[0.16em] font-semibold rounded-xl transition-all ${
              activeTab === 'crm'
                ? 'bg-white/10 text-white border-b-2 border-orange-500 shadow-lg shadow-orange-500/10 backdrop-blur-xl'
                : 'bg-white/5 text-white/40 border border-white/5 hover:text-white/80 hover:bg-white/10 backdrop-blur-md'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-orange-400" />
            <span>1. CRM Leads (Data & Nav)</span>
          </button>

          <button
            onClick={() => setActiveTab('dictation')}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs uppercase tracking-[0.16em] font-semibold rounded-xl transition-all ${
              activeTab === 'dictation'
                ? 'bg-white/10 text-white border-b-2 border-orange-500 shadow-lg shadow-orange-500/10 backdrop-blur-xl'
                : 'bg-white/5 text-white/40 border border-white/5 hover:text-white/80 hover:bg-white/10 backdrop-blur-md'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-orange-400" />
            <span>2. Long-Form Dictation</span>
          </button>

          <button
            onClick={() => setActiveTab('inspection')}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs uppercase tracking-[0.16em] font-semibold rounded-xl transition-all ${
              activeTab === 'inspection'
                ? 'bg-white/10 text-white border-b-2 border-orange-500 shadow-lg shadow-orange-500/10 backdrop-blur-xl'
                : 'bg-white/5 text-white/40 border border-white/5 hover:text-white/80 hover:bg-white/10 backdrop-blur-md'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5 text-orange-400" />
            <span>3. Hands-Free Inspection</span>
          </button>

          <button
            onClick={() => setActiveTab('compliance')}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs uppercase tracking-[0.16em] font-semibold rounded-xl transition-all ${
              activeTab === 'compliance'
                ? 'bg-white/10 text-white border-b-2 border-orange-500 shadow-lg shadow-orange-500/10 backdrop-blur-xl'
                : 'bg-white/5 text-white/40 border border-white/5 hover:text-white/80 hover:bg-white/10 backdrop-blur-md'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-orange-400" />
            <span>4. Privacy & Compliance</span>
          </button>

          <button
            onClick={() => setActiveTab('matrix')}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs uppercase tracking-[0.16em] font-semibold rounded-xl transition-all ${
              activeTab === 'matrix'
                ? 'bg-white/10 text-white border-b-2 border-orange-500 shadow-lg shadow-orange-500/10 backdrop-blur-xl'
                : 'bg-white/5 text-white/40 border border-white/5 hover:text-white/80 hover:bg-white/10 backdrop-blur-md'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-orange-400" />
            <span>5. Cross-Browser Matrix</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs uppercase tracking-[0.16em] font-semibold rounded-xl transition-all ${
              activeTab === 'analytics'
                ? 'bg-white/10 text-white border-b-2 border-orange-500 shadow-lg shadow-orange-500/10 backdrop-blur-xl'
                : 'bg-white/5 text-white/40 border border-white/5 hover:text-white/80 hover:bg-white/10 backdrop-blur-md'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-orange-400" />
            <span>6. Telemetry & Analytics</span>
          </button>
        </div>

        {/* Tab View Rendering */}
        {activeTab === 'crm' && (
          <CrmLeadsView
            leads={leads}
            filterStatus={crmFilterStatus}
            searchQuery={crmSearchQuery}
            sortBy={crmSortBy}
            sortDirection={crmSortDir}
            selectedIndustry={crmIndustry}
            lastVoiceActionHighlight={null}
            onFilterStatusChange={(status) => setCrmFilterStatus(status)}
            onSearchChange={(q) => setCrmSearchQuery(q)}
            onSortChange={(field) => {
              if (crmSortBy === field) {
                setCrmSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
              } else {
                setCrmSortBy(field);
                setCrmSortDir('desc');
              }
            }}
            onIndustryChange={(ind) => setCrmIndustry(ind)}
            onExportReport={(type) => exportReportCsv(type)}
            searchInputRef={searchInputRef}
          />
        )}

        {activeTab === 'dictation' && (
          <VoiceNotepadView
            noteContent={noteContent}
            isDictating={vuiState === 'listening'}
            onUpdateNote={(content) => setNoteContent(content)}
            onClearNote={() => setNoteContent('')}
            onToggleDictation={() => voiceControllerRef.current?.toggleListening('dictation')}
          />
        )}

        {activeTab === 'inspection' && (
          <HandsFreeInspectionView
            steps={inspectionSteps}
            onUpdateStepStatus={(id, status, notes) => {
              setInspectionSteps((prev) =>
                prev.map((s) => (s.id === id ? { ...s, status, operatorNotes: notes || s.operatorNotes } : s))
              );
            }}
            onMarkAllPassed={() => {
              setInspectionSteps((prev) => prev.map((s) => ({ ...s, status: 'passed' })));
              confetti({ particleCount: 40, spread: 50, origin: { y: 0.8 } });
            }}
            onResetChecklist={() => setInspectionSteps(INITIAL_INSPECTION_STEPS)}
          />
        )}

        {activeTab === 'compliance' && (
          <PrivacyComplianceCenter
            vuiMode={vuiMode}
            privacyMode={privacyMode}
            zeroRetention={zeroRetention}
            piiScrubbing={piiScrubbing}
            onUpdateVuiMode={(m) => setVuiMode(m)}
            onUpdatePrivacyMode={(m) => setPrivacyMode(m)}
            onToggleZeroRetention={() => setZeroRetention((prev) => !prev)}
            onTogglePiiScrubbing={() => setPiiScrubbing((prev) => !prev)}
          />
        )}

        {activeTab === 'matrix' && (
          <CrossBrowserMatrix
            onSimulateCommand={(cmd, forcedConfidence) => simulateVoiceCommand(cmd, forcedConfidence)}
          />
        )}

        {activeTab === 'analytics' && (
          <VuiAnalyticsView
            logs={vuiLogs}
            onRerunUtterance={(t) => simulateVoiceCommand(t)}
            onClearLogs={() => setVuiLogs([])}
          />
        )}
      </main>

      {/* Floating Bottom Voice Controller Toolbar */}
      <VoiceFloatingController
        vuiState={vuiState}
        vuiMode={vuiMode}
        soundEnabled={soundEnabled}
        audioLevel={audioLevel}
        analyser={voiceControllerRef.current?.getAnalyser() || null}
        onToggleListening={() => voiceControllerRef.current?.toggleListening(activeTab)}
        onToggleVuiMode={() => setVuiMode((prev) => (prev === 'ptt' ? 'continuous' : 'ptt'))}
        onToggleSound={() => setSoundEnabled((prev) => !prev)}
        onOpenPriming={() => setIsPrimingOpen(true)}
      />

      {/* Confidence Routing Modal (Undo toast for High, Disambiguation for Medium, Rephrase for Low) */}
      <ConfidenceRouterModal
        currentIntentResult={currentIntentResult}
        activeUndoAction={activeUndoAction}
        consecutiveFailures={consecutiveFailures}
        onExecuteDisambiguation={(opt) => handleExecuteDisambiguation(opt)}
        onDismissDisambiguation={() => setCurrentIntentResult(null)}
        onSelectRephrase={(phrase) => handleSelectRephrase(phrase)}
        onTriggerKeyboardFallback={handleTriggerKeyboardFallback}
        onPerformUndo={() => {
          if (activeUndoAction) {
            activeUndoAction.undoFunction();
            setActiveUndoAction(null);
          }
        }}
        onDismissUndo={() => setActiveUndoAction(null)}
      />

      {/* Permission Priming Modal */}
      <PermissionPrimingModal
        isOpen={isPrimingOpen}
        onConfirm={() => {
          setIsPrimingOpen(false);
          voiceControllerRef.current?.startListening(activeTab);
        }}
        onCancel={() => setIsPrimingOpen(false)}
      />
    </div>
  );
}
