import React, { useEffect, useRef } from 'react';
import { VuiState } from '../types';

interface AudioWaveformProps {
  vuiState: VuiState;
  audioLevel: number;
  analyser: AnalyserNode | null;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  vuiState,
  audioLevel,
  analyser,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const width = canvas.width;
      const height = canvas.height;
      const centerY = height / 2;

      if (vuiState === 'listening') {
        if (analyser) {
          const bufferLength = analyser.frequencyBinCount;
          const dataArray = new Uint8Array(bufferLength);
          analyser.getByteTimeDomainData(dataArray);

          ctx.lineWidth = 2.5;
          ctx.strokeStyle = '#f97316'; // Vibrant orange
          ctx.beginPath();

          const sliceWidth = (width * 1.0) / bufferLength;
          let x = 0;

          for (let i = 0; i < bufferLength; i++) {
            const v = dataArray[i] / 128.0; // 0 to 2
            const y = (v * height) / 2;

            if (i === 0) {
              ctx.moveTo(x, y);
            } else {
              ctx.lineTo(x, y);
            }

            x += sliceWidth;
          }

          ctx.lineTo(width, centerY);
          ctx.stroke();

          // Glowing secondary wave
          ctx.lineWidth = 1;
          ctx.strokeStyle = 'rgba(251, 146, 60, 0.4)';
          ctx.stroke();
        } else {
          // Synthetic pulsing sine wave if analyser stream isn't attached
          const time = Date.now() * 0.005;
          const amplitude = Math.max(8, audioLevel * 24);

          ctx.lineWidth = 2;
          ctx.strokeStyle = '#f97316';
          ctx.beginPath();

          for (let x = 0; x < width; x++) {
            const y = centerY + Math.sin(x * 0.05 + time) * amplitude * Math.sin(x / width * Math.PI);
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
        }
      } else if (vuiState === 'processing') {
        // Animated processing flow
        const time = Date.now() * 0.008;
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#fb923c'; // Warm amber-orange
        ctx.beginPath();
        for (let x = 0; x < width; x++) {
          const y = centerY + Math.sin(x * 0.08 + time) * 6;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      } else {
        // Flat calm idle line
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.beginPath();
        ctx.moveTo(0, centerY);
        ctx.lineTo(width, centerY);
        ctx.stroke();
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [vuiState, audioLevel, analyser]);

  return (
    <div className="relative flex items-center justify-center h-10 w-44 bg-white/5 backdrop-blur-xl rounded-xl px-2 border border-white/10 overflow-hidden shadow-inner">
      <canvas
        ref={canvasRef}
        width={160}
        height={36}
        className="w-full h-full block"
      />
      {vuiState === 'listening' && (
        <span className="absolute top-1.5 right-2 flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]"></span>
        </span>
      )}
    </div>
  );
};
