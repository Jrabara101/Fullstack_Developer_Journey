import React, { useEffect, useState } from 'react';
import { DisambiguationOption, IntentParseResult, UndoableAction } from '../types';
import { CheckCircle, AlertTriangle, HelpCircle, RotateCcw, X, ArrowRight, Sparkles, Keyboard } from 'lucide-react';

interface ConfidenceRouterModalProps {
  currentIntentResult: IntentParseResult | null;
  activeUndoAction: UndoableAction | null;
  consecutiveFailures: number;
  onExecuteDisambiguation: (option: DisambiguationOption) => void;
  onDismissDisambiguation: () => void;
  onSelectRephrase: (phrase: string) => void;
  onTriggerKeyboardFallback: () => void;
  onPerformUndo: () => void;
  onDismissUndo: () => void;
}

export const ConfidenceRouterModal: React.FC<ConfidenceRouterModalProps> = ({
  currentIntentResult,
  activeUndoAction,
  consecutiveFailures,
  onExecuteDisambiguation,
  onDismissDisambiguation,
  onSelectRephrase,
  onTriggerKeyboardFallback,
  onPerformUndo,
  onDismissUndo,
}) => {
  // Undo countdown progress state
  const [undoProgress, setUndoProgress] = useState(100);

  useEffect(() => {
    if (!activeUndoAction) return;

    const totalDuration = activeUndoAction.expiresAt - activeUndoAction.timestamp;
    const interval = setInterval(() => {
      const remaining = activeUndoAction.expiresAt - Date.now();
      if (remaining <= 0) {
        setUndoProgress(0);
        clearInterval(interval);
        onDismissUndo();
      } else {
        setUndoProgress(Math.max(0, (remaining / totalDuration) * 100));
      }
    }, 50);

    return () => clearInterval(interval);
  }, [activeUndoAction, onDismissUndo]);

  const showMediumDialog =
    currentIntentResult &&
    currentIntentResult.confidenceTier === 'medium' &&
    currentIntentResult.disambiguationOptions &&
    currentIntentResult.disambiguationOptions.length > 0;

  const showLowBanner =
    currentIntentResult &&
    currentIntentResult.confidenceTier === 'low';

  return (
    <>
      {/* 1. High-Confidence Undo Toast Bar */}
      {activeUndoAction && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md bg-[#0f0f11]/90 text-white rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-white/10 backdrop-blur-2xl p-4 animate-in slide-in-from-bottom-5 duration-300">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
                <CheckCircle className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[10px] font-mono uppercase tracking-wider text-orange-400">Action Executed (High Confidence)</p>
                <p className="text-sm font-medium text-white">{activeUndoAction.actionLabel}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={onPerformUndo}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-mono font-bold bg-orange-500 hover:bg-orange-600 text-white rounded-xl transition-all active:scale-95 shadow-[0_0_12px_rgba(249,115,22,0.4)]"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Undo</span>
              </button>
              <button
                onClick={onDismissUndo}
                className="p-1 text-white/40 hover:text-white rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Progress bar countdown indicator */}
          <div className="w-full bg-white/10 h-1 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-orange-500 h-full transition-all duration-75 shadow-[0_0_8px_rgba(249,115,22,0.8)]"
              style={{ width: `${undoProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* 2. Medium-Confidence Disambiguation Dialog (50 - 85%) */}
      {showMediumDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-150">
          <div className="w-full max-w-lg bg-[#0f0f11]/95 text-white rounded-[28px] shadow-[0_25px_60px_rgba(0,0,0,0.9)] border border-white/10 backdrop-blur-2xl overflow-hidden">
            <div className="p-5 border-b border-white/10 bg-amber-500/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white tracking-tight">
                    Disambiguation Required ({Math.round(currentIntentResult!.confidenceScore * 100)}% Confidence)
                  </h4>
                  <p className="text-xs text-white/50 font-mono">
                    Heard: <span className="font-mono text-orange-400">“{currentIntentResult!.rawTranscript}”</span>
                  </p>
                </div>
              </div>

              <button
                onClick={onDismissDisambiguation}
                className="p-2 text-white/40 hover:text-white rounded-xl hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-3.5">
              <p className="text-[10px] font-mono uppercase tracking-widest text-orange-400 font-bold">
                Did you mean one of the following?
              </p>

              <div className="space-y-2">
                {currentIntentResult!.disambiguationOptions.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => onExecuteDisambiguation(opt)}
                    className="w-full flex items-center justify-between p-3.5 rounded-2xl border border-white/10 hover:border-orange-500/50 bg-white/5 hover:bg-orange-500/10 transition-all text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-white/10 text-white text-xs font-mono font-bold border border-white/10">
                        {idx + 1}
                      </span>
                      <span className="text-xs font-medium text-white group-hover:text-orange-300">
                        {opt.label}
                      </span>
                    </div>
                    <ArrowRight className="w-4 h-4 text-white/40 group-hover:text-orange-400 transition-transform group-hover:translate-x-0.5" />
                  </button>
                ))}
              </div>

              <p className="text-xs text-white/40 font-mono italic pt-1">
                {currentIntentResult!.explanation}
              </p>
            </div>

            <div className="px-6 py-3.5 bg-white/5 border-t border-white/10 flex items-center justify-end gap-2">
              <button
                onClick={onDismissDisambiguation}
                className="px-4 py-1.5 text-xs font-semibold text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Low-Confidence Graceful Fallback & Multi-Modal Keyboard Prompt (<50%) */}
      {showLowBanner && (
        <div className="p-4 bg-rose-950/20 backdrop-blur-xl border border-rose-500/30 rounded-2xl space-y-2.5 animate-in fade-in duration-200 shadow-lg">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl border border-rose-500/30">
                <HelpCircle className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-mono font-bold text-rose-300">
                  LOW CONFIDENCE ({Math.round(currentIntentResult!.confidenceScore * 100)}%): WE DIDN'T QUITE CATCH THAT
                </h5>
                <p className="text-xs text-white/60 font-mono">
                  Spoken: <span className="text-rose-400">“{currentIntentResult!.rawTranscript}”</span>
                </p>
              </div>
            </div>

            {consecutiveFailures >= 2 && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-mono font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-lg">
                Multi-Modal Fallback Triggered
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-mono text-white/60">Try rephrasing:</span>
            {currentIntentResult!.rephraseSuggestions?.map((phrase, idx) => (
              <button
                key={idx}
                onClick={() => onSelectRephrase(phrase)}
                className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-mono bg-white/5 hover:bg-white/10 text-white/80 hover:text-white rounded-lg border border-white/10 transition-all"
              >
                <Sparkles className="w-3 h-3 text-orange-400" />
                <span>{phrase}</span>
              </button>
            ))}
          </div>

          {consecutiveFailures >= 2 && (
            <div className="flex items-center justify-between pt-2.5 border-t border-white/10 text-xs">
              <span className="text-white/60 font-mono">
                Voice failed twice consecutively. Would you like to switch to keyboard input?
              </span>
              <button
                onClick={onTriggerKeyboardFallback}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white font-mono font-bold text-xs rounded-xl shadow-[0_0_12px_rgba(249,115,22,0.4)] transition-all"
              >
                <Keyboard className="w-3.5 h-3.5" />
                <span>Focus Keyboard Input</span>
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
};
