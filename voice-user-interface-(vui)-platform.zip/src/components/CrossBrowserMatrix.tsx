import React from 'react';
import { detectBrowserPlatform } from '../services/browserDetector';
import { Chrome, Compass, Flame, Radio, CheckCircle, AlertCircle, Sparkles, Volume2, Play } from 'lucide-react';

interface CrossBrowserMatrixProps {
  onSimulateCommand: (command: string, forcedConfidence?: number) => void;
}

export const CrossBrowserMatrix: React.FC<CrossBrowserMatrixProps> = ({ onSimulateCommand }) => {
  const currentBrowser = detectBrowserPlatform();

  const sampleVoiceAudios = [
    {
      title: 'High-Confidence Utterance (>85%)',
      command: 'Filter leads by active status and sort by revenue',
      confidence: 0.94,
      desc: 'Crystal-clear speech intent that triggers instant execution with 5-second undo toast.',
      tag: 'Auto-Execute',
      color: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300',
    },
    {
      title: 'Medium-Confidence Utterance (50–85%)',
      command: 'Export Q3',
      confidence: 0.68,
      desc: 'Ambiguous phrase triggering Disambiguation modal: ("Export Q3 Leads Report" vs "Export Q3 Financials").',
      tag: 'Disambiguation Dialog',
      color: 'border-amber-500/40 bg-amber-500/10 text-amber-300',
    },
    {
      title: 'Low-Confidence Utterance (<50%)',
      command: 'Um uh something something leads please',
      confidence: 0.32,
      desc: 'Noisy acoustic utterance triggering non-intrusive rephrase guidance & keyboard fallback on repeat.',
      tag: 'Graceful Fallback',
      color: 'border-rose-500/40 bg-rose-500/10 text-rose-300',
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Current Browser Detected Hero */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="text-[11px] font-mono font-bold text-orange-400 uppercase tracking-widest">
              Real-Time Client Detection
            </span>
            <h2 className="text-lg font-bold text-white tracking-tight">
              Active Environment: {currentBrowser.name} ({currentBrowser.engine} Engine)
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {currentBrowser.supportsWebSpeech ? (
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-mono font-bold bg-emerald-500/15 text-emerald-300 rounded-full border border-emerald-500/30">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Web Speech API Ready {currentBrowser.requiresPrefix ? `(${currentBrowser.prefixName})` : '(Standard)'}</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-mono font-bold bg-amber-500/15 text-amber-300 rounded-full border border-amber-500/30">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Gemini Server-Side STT Fallback Active</span>
              </span>
            )}
          </div>
        </div>

        <p className="text-xs text-white/60 font-mono">
          {currentBrowser.recommendation}
        </p>

        {currentBrowser.complianceWarning && (
          <div className="p-4 bg-amber-500/10 rounded-2xl border border-amber-500/30 text-xs text-amber-300 flex items-start gap-2.5 font-mono">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{currentBrowser.complianceWarning}</span>
          </div>
        )}
      </div>

      {/* Browser Engines Capability Matrix Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Chromium Engine Card */}
        <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Chrome className="w-5 h-5 text-orange-400" />
              <h3 className="text-sm font-bold text-white tracking-tight">
                Chromium Engine
              </h3>
            </div>
            <span className="px-2 py-0.5 text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
              Tier 1
            </span>
          </div>

          <p className="text-xs text-white/50 leading-relaxed font-sans">
            Native implementation with real-time interim streaming results. Streams audio packets to Google/Microsoft transcription clusters.
          </p>

          <div className="pt-3 border-t border-white/10 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between text-white/40">
              <span>Standard API:</span>
              <span className="font-semibold text-white">SpeechRecognition</span>
            </div>
            <div className="flex justify-between text-white/40">
              <span>Interim Streaming:</span>
              <span className="font-semibold text-emerald-400">Yes (&lt;100ms)</span>
            </div>
          </div>
        </div>

        {/* Apple Safari WebKit Card */}
        <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Compass className="w-5 h-5 text-orange-400" />
              <h3 className="text-sm font-bold text-white tracking-tight">
                Apple Safari (WebKit)
              </h3>
            </div>
            <span className="px-2 py-0.5 text-[9px] font-mono font-bold bg-blue-500/20 text-blue-300 rounded border border-blue-500/30">
              Prefixed
            </span>
          </div>

          <p className="text-xs text-white/50 leading-relaxed font-sans">
            Supported via <code className="text-xs font-mono bg-white/10 text-orange-300 px-1.5 py-0.5 rounded">webkitSpeechRecognition</code>. Uses Apple Neural Engine on modern hardware with Siri dictation servers.
          </p>

          <div className="pt-3 border-t border-white/10 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between text-white/40">
              <span>Prefixed API:</span>
              <span className="font-semibold text-white">webkitSpeechRecognition</span>
            </div>
            <div className="flex justify-between text-white/40">
              <span>Interim Streaming:</span>
              <span className="font-semibold text-emerald-400">Yes</span>
            </div>
          </div>
        </div>

        {/* Mozilla Firefox Gecko Card */}
        <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Flame className="w-5 h-5 text-orange-400" />
              <h3 className="text-sm font-bold text-white tracking-tight">
                Mozilla Firefox (Gecko)
              </h3>
            </div>
            <span className="px-2 py-0.5 text-[9px] font-mono font-bold bg-amber-500/20 text-amber-300 rounded border border-amber-500/30">
              Fallback
            </span>
          </div>

          <p className="text-xs text-white/50 leading-relaxed font-sans">
            Native SpeechRecognition is disabled by default in Firefox. Platform switches to server-side Gemini Multimodal Audio transcription.
          </p>

          <div className="pt-3 border-t border-white/10 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between text-white/40">
              <span>Fallback Channel:</span>
              <span className="font-semibold text-white">MediaRecorder + Gemini</span>
            </div>
            <div className="flex justify-between text-white/40">
              <span>Latency:</span>
              <span className="font-semibold text-orange-400">~600ms</span>
            </div>
          </div>
        </div>
      </div>

      {/* Confidence Score Routing Simulator / Testbench */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-orange-400 to-orange-600 text-white rounded-xl shadow-md shadow-orange-500/30">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight">
              Confidence Score Routing Testbench (No Mic Required)
            </h3>
            <p className="text-xs text-white/50 font-mono">
              Simulate speech utterances with calibrated confidence ratings to verify routing behavior
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {sampleVoiceAudios.map((sample, idx) => (
            <div
              key={idx}
              className={`p-5 rounded-[24px] backdrop-blur-xl border ${sample.color} space-y-3.5 flex flex-col justify-between`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold tracking-tight">{sample.title}</span>
                  <span className="text-[9px] font-mono font-extrabold uppercase px-2 py-0.5 rounded-full bg-black/40 border border-white/10">
                    {sample.tag}
                  </span>
                </div>
                <p className="text-xs font-mono font-bold text-white">
                  “{sample.command}”
                </p>
                <p className="text-[11px] opacity-80 leading-relaxed font-sans">
                  {sample.desc}
                </p>
              </div>

              <button
                onClick={() => onSimulateCommand(sample.command, sample.confidence)}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-mono font-bold bg-orange-500 hover:bg-orange-600 text-white rounded-xl transition-all active:scale-95 shadow-[0_0_15px_rgba(249,115,22,0.4)]"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Simulate Routing ({Math.round(sample.confidence * 100)}%)</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
