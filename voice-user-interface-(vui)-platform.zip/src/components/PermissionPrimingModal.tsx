import React from 'react';
import { Mic, Shield, CheckCircle2, Lock, X } from 'lucide-react';

interface PermissionPrimingModalProps {
  isOpen: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const PermissionPrimingModal: React.FC<PermissionPrimingModalProps> = ({
  isOpen,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0f0f11]/95 text-white rounded-[28px] shadow-[0_25px_60px_rgba(0,0,0,0.9)] border border-white/10 backdrop-blur-2xl p-6 space-y-5">
        <button
          onClick={onCancel}
          className="absolute top-4 right-4 p-2 text-white/40 hover:text-white rounded-xl hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-orange-400 to-orange-600 text-white rounded-2xl shadow-lg shadow-orange-500/30">
            <Mic className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">
              Enable Voice Interactions
            </h3>
            <p className="text-xs text-white/50 font-mono">
              Permission Priming & Audio Governance
            </p>
          </div>
        </div>

        <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-2.5 text-xs text-white/70">
          <p className="font-semibold text-white font-mono uppercase tracking-wider text-[11px] text-orange-400">
            Why we request microphone access:
          </p>
          <ul className="space-y-2">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
              <span>Hands-free voice control across CRM leads, dictation, and inspection checklists.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
              <span>Push-to-Talk (press & hold or click toggle) ensures audio is only captured when you choose.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
              <span>Zero background passive listening or unauthorized continuous recording.</span>
            </li>
          </ul>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-white/50 font-mono">
          <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>Clicking "Allow Microphone" will invoke your browser's native permission prompt.</span>
        </div>

        <div className="flex items-center justify-end gap-2.5 pt-1">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-xs font-semibold text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-5 py-2.5 text-xs font-mono font-bold bg-orange-500 hover:bg-orange-600 text-white rounded-xl shadow-[0_0_15px_rgba(249,115,22,0.4)] transition-all active:scale-95"
          >
            Allow Microphone Access
          </button>
        </div>
      </div>
    </div>
  );
};
