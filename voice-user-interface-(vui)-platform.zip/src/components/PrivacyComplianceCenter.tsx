import React, { useState } from 'react';
import { PrivacyMode, VuiMode } from '../types';
import { Shield, Lock, EyeOff, Server, HardDrive, CheckCircle2, AlertTriangle, RefreshCw, Cpu, Activity } from 'lucide-react';

interface PrivacyComplianceCenterProps {
  vuiMode: VuiMode;
  privacyMode: PrivacyMode;
  zeroRetention: boolean;
  piiScrubbing: boolean;
  onUpdateVuiMode: (mode: VuiMode) => void;
  onUpdatePrivacyMode: (mode: PrivacyMode) => void;
  onToggleZeroRetention: () => void;
  onTogglePiiScrubbing: () => void;
}

export const PrivacyComplianceCenter: React.FC<PrivacyComplianceCenterProps> = ({
  vuiMode,
  privacyMode,
  zeroRetention,
  piiScrubbing,
  onUpdateVuiMode,
  onUpdatePrivacyMode,
  onToggleZeroRetention,
  onTogglePiiScrubbing,
}) => {
  const [testText, setTestText] = useState('My patient phone number is 415-555-0199 and SSN is 000-12-3456');

  const scrubText = (raw: string) => {
    return raw
      .replace(/\b\d{3}[-.]?\d{2}[-.]?\d{4}\b/g, '[REDACTED SSN]')
      .replace(/\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g, '[REDACTED PHONE]')
      .replace(/\b(?:\d[ -]*?){13,16}\b/g, '[REDACTED CARD]');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Overview Card */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl text-white rounded-[28px] border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.8)] space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-gradient-to-br from-orange-400 to-orange-600 text-white rounded-2xl shadow-lg shadow-orange-500/30">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-white">Privacy, Trust & Regulatory Compliance Center</h2>
              <p className="text-xs text-white/50 font-mono">
                Audio streaming governance, HIPAA/GDPR validation, and explicit user control
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className={`px-3.5 py-1.5 text-xs font-mono font-bold rounded-full flex items-center gap-2 ${
              privacyMode === 'hipaa'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                : privacyMode === 'gdpr'
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-[0_0_12px_rgba(59,130,246,0.3)]'
                : 'bg-white/10 text-white/80 border border-white/10'
            }`}>
              <Lock className="w-3.5 h-3.5 text-orange-400" />
              <span>{privacyMode.toUpperCase()} Shield Active</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-orange-400 uppercase tracking-wider">
              <Activity className="w-4 h-4 text-orange-400" />
              <span>Mic Capture Paradigm</span>
            </div>
            <p className="text-sm font-bold text-white">
              {vuiMode === 'ptt' ? 'Explicit Push-to-Talk (Gold Standard)' : 'Continuous Hotword Loop'}
            </p>
            <p className="text-[11px] text-white/50 font-mono">
              {vuiMode === 'ptt' ? 'Zero passive background audio listening' : 'Active stream for hands-busy environments'}
            </p>
          </div>

          <div className="p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-orange-400 uppercase tracking-wider">
              <Server className="w-4 h-4 text-orange-400" />
              <span>Audio Routing Pipeline</span>
            </div>
            <p className="text-sm font-bold text-white">
              Hybrid WebSpeech + Gemini 3.7
            </p>
            <p className="text-[11px] text-white/50 font-mono">
              Browser WebSpeech API + Server-side Gemini NLU
            </p>
          </div>

          <div className="p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-orange-400 uppercase tracking-wider">
              <EyeOff className="w-4 h-4 text-orange-400" />
              <span>Data Retention Policy</span>
            </div>
            <p className="text-sm font-bold text-white">
              {zeroRetention ? 'Zero-Retention Buffer' : 'Volatile Session Cache'}
            </p>
            <p className="text-[11px] text-white/50 font-mono">
              Audio frames destroyed immediately post-transcription
            </p>
          </div>
        </div>
      </div>

      {/* Control Configuration Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Section 1: Push-to-Talk vs Continuous Mode */}
        <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-orange-500/20 border border-orange-500/30 text-orange-400 rounded-xl">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                1. Voice Capture Mode
              </h3>
              <p className="text-xs text-white/50 font-mono">
                Select between user-initiated Push-to-Talk or continuous dictation
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <label
              onClick={() => onUpdateVuiMode('ptt')}
              className={`flex items-start justify-between p-4 rounded-2xl border cursor-pointer transition-all ${
                vuiMode === 'ptt'
                  ? 'border-orange-500/50 bg-orange-500/10 shadow-[0_0_15px_rgba(249,115,22,0.15)]'
                  : 'border-white/10 bg-white/5 hover:bg-white/10'
              }`}
            >
              <div className="space-y-1 pr-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">
                    Push-to-Talk (Recommended)
                  </span>
                  <span className="px-2 py-0.5 text-[9px] font-mono font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-md">
                    GDPR / HIPAA Preferred
                  </span>
                </div>
                <p className="text-xs text-white/60 font-mono">
                  User clicks to talk or holds Spacebar. Microphone turns off immediately after speech stops. Eliminates accidental background recording.
                </p>
              </div>
              <input
                type="radio"
                name="vuiMode"
                checked={vuiMode === 'ptt'}
                onChange={() => onUpdateVuiMode('ptt')}
                className="mt-1 accent-orange-500"
              />
            </label>

            <label
              onClick={() => onUpdateVuiMode('continuous')}
              className={`flex items-start justify-between p-4 rounded-2xl border cursor-pointer transition-all ${
                vuiMode === 'continuous'
                  ? 'border-orange-500/50 bg-orange-500/10 shadow-[0_0_15px_rgba(249,115,22,0.15)]'
                  : 'border-white/10 bg-white/5 hover:bg-white/10'
              }`}
            >
              <div className="space-y-1 pr-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">
                    Continuous Listening Mode
                  </span>
                  <span className="px-2 py-0.5 text-[9px] font-mono font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-md">
                    Hands-Free Workflows
                  </span>
                </div>
                <p className="text-xs text-white/60 font-mono">
                  Maintains continuous audio recognition loop. Best for kitchen checklists or warehouse field inspections where hands cannot touch hardware.
                </p>
              </div>
              <input
                type="radio"
                name="vuiMode"
                checked={vuiMode === 'continuous'}
                onChange={() => onUpdateVuiMode('continuous')}
                className="mt-1 accent-orange-500"
              />
            </label>
          </div>
        </div>

        {/* Section 2: Regulatory Compliance Profile (HIPAA / GDPR / Standard) */}
        <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-xl">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                2. Regulatory Profile & Governance
              </h3>
              <p className="text-xs text-white/50 font-mono">
                Strict data compliance enforcement
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            {(['standard', 'hipaa', 'gdpr'] as PrivacyMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => onUpdatePrivacyMode(mode)}
                className={`p-3.5 rounded-2xl border text-center transition-all ${
                  privacyMode === mode
                    ? 'border-orange-500 bg-orange-500/20 text-white font-bold shadow-[0_0_15px_rgba(249,115,22,0.25)]'
                    : 'border-white/10 bg-white/5 hover:bg-white/10 text-white/60 font-medium'
                }`}
              >
                <div className="text-xs font-mono uppercase tracking-wider">{mode}</div>
                <div className="text-[10px] text-white/50 font-mono mt-0.5">
                  {mode === 'hipaa' ? 'Health Data' : mode === 'gdpr' ? 'EU Privacy' : 'Standard Web'}
                </div>
              </button>
            ))}
          </div>

          <div className="space-y-3 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-2xl border border-white/10">
              <div className="text-xs">
                <span className="font-bold text-white block">
                  Zero Audio Retention Buffer
                </span>
                <span className="text-white/50 font-mono text-[11px]">
                  Destroy audio PCM buffers from memory immediately post-turn
                </span>
              </div>
              <button
                onClick={onToggleZeroRetention}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                  zeroRetention ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]' : 'bg-white/20'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    zeroRetention ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 bg-white/5 rounded-2xl border border-white/10">
              <div className="text-xs">
                <span className="font-bold text-white block">
                  Client-Side PII / PHI Redaction
                </span>
                <span className="text-white/50 font-mono text-[11px]">
                  Automatically mask credit cards, phone numbers, and SSNs in voice transcripts
                </span>
              </div>
              <button
                onClick={onTogglePiiScrubbing}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                  piiScrubbing ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]' : 'bg-white/20'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    piiScrubbing ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive PII Scrubber Testbench */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 space-y-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <EyeOff className="w-4 h-4 text-orange-400" />
            <h4 className="text-xs font-mono font-bold text-orange-400 uppercase tracking-widest">
              Real-Time Sensitive Data Masking Preview
            </h4>
          </div>
          <span className="text-[11px] font-mono text-white/50">
            {piiScrubbing ? 'Active: Redacting PII/PHI patterns' : 'Inactive: Raw transcript passing'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-white/70">
              Raw Spoken Input (Simulated)
            </label>
            <textarea
              value={testText}
              onChange={(e) => setTestText(e.target.value)}
              rows={2}
              className="w-full p-3 text-xs bg-white/5 border border-white/10 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-mono text-white/70">
              Sanitized Engine Output ({piiScrubbing ? 'Scrubbed' : 'Raw'})
            </label>
            <div className="w-full p-3 text-xs bg-white/5 border border-white/10 rounded-xl text-emerald-400 font-mono min-h-[64px]">
              {piiScrubbing ? scrubText(testText) : testText}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
