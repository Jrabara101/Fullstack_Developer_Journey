import React from 'react';
import { VuiMode, VuiState } from '../types';
import { AudioWaveform } from './AudioWaveform';
import { Mic, MicOff, Volume2, VolumeX, Radio, Sparkles, Layers, Shield } from 'lucide-react';

interface VoiceFloatingControllerProps {
  vuiState: VuiState;
  vuiMode: VuiMode;
  soundEnabled: boolean;
  audioLevel: number;
  analyser: AnalyserNode | null;
  onToggleListening: () => void;
  onToggleVuiMode: () => void;
  onToggleSound: () => void;
  onOpenPriming: () => void;
}

export const VoiceFloatingController: React.FC<VoiceFloatingControllerProps> = ({
  vuiState,
  vuiMode,
  soundEnabled,
  audioLevel,
  analyser,
  onToggleListening,
  onToggleVuiMode,
  onToggleSound,
  onOpenPriming,
}) => {
  const isListening = vuiState === 'listening';
  const isProcessing = vuiState === 'processing';

  const getStateText = () => {
    switch (vuiState) {
      case 'listening':
        return 'Active Listening...';
      case 'processing':
        return 'AI Parsing Intent...';
      case 'success':
        return 'Action Executed';
      case 'error':
        return 'Recognition Unclear';
      case 'priming':
        return 'Permission Priming';
      default:
        return vuiMode === 'ptt' ? 'Push-to-Talk Ready' : 'Continuous Listening Active';
    }
  };

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 w-full max-w-2xl px-4 animate-in slide-in-from-bottom-3 duration-200">
      <div className="bg-[#0f0f11]/80 text-white backdrop-blur-2xl rounded-2xl border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.8)] p-2.5 flex items-center justify-between gap-3">
        {/* Left Side: Mic Button & Waveform */}
        <div className="flex items-center gap-3">
          <div className="relative">
            {isListening && (
              <span className="absolute -inset-1.5 rounded-full bg-orange-500/40 animate-ping" />
            )}
            <button
              onClick={onToggleListening}
              className={`relative flex items-center justify-center w-11 h-11 rounded-xl shadow-lg transition-all active:scale-95 ${
                isListening
                  ? 'bg-gradient-to-br from-rose-500 to-rose-600 text-white ring-4 ring-rose-500/30 animate-pulse shadow-[0_0_20px_rgba(244,63,94,0.6)]'
                  : isProcessing
                  ? 'bg-gradient-to-br from-orange-400 to-orange-600 text-white ring-2 ring-orange-500/40 shadow-[0_0_20px_rgba(249,115,22,0.6)]'
                  : 'bg-gradient-to-br from-orange-400 to-orange-600 hover:from-orange-500 hover:to-orange-700 text-white ring-2 ring-orange-500/30 shadow-[0_0_15px_rgba(249,115,22,0.4)]'
              }`}
              title={vuiMode === 'ptt' ? 'Click to speak or hold Spacebar' : 'Click to toggle continuous listening'}
            >
              <Mic className="w-5 h-5" />
            </button>
          </div>

          <div className="hidden sm:block">
            <AudioWaveform
              vuiState={vuiState}
              audioLevel={audioLevel}
              analyser={analyser}
            />
          </div>

          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${
                isListening
                  ? 'bg-rose-500 animate-ping shadow-[0_0_8px_rgba(244,63,94,0.9)]'
                  : isProcessing
                  ? 'bg-orange-500 animate-pulse shadow-[0_0_8px_rgba(249,115,22,0.9)]'
                  : 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.9)]'
              }`} />
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-white">
                {getStateText()}
              </span>
            </div>
            <p className="text-[11px] font-mono text-white/50">
              {vuiMode === 'ptt' ? 'Hold [Spacebar] or click mic' : 'Continuous loop running'}
            </p>
          </div>
        </div>

        {/* Right Side: Mode Switchers & Sound */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onToggleVuiMode}
            className={`px-3 py-1.5 text-xs font-mono font-bold rounded-xl transition-all border ${
              vuiMode === 'ptt'
                ? 'bg-white/5 text-white/80 border-white/10 hover:bg-white/10'
                : 'bg-orange-500/20 text-orange-300 border-orange-500/40 shadow-[0_0_12px_rgba(249,115,22,0.3)]'
            }`}
            title="Switch Push-to-Talk vs Continuous Mode"
          >
            <span className="uppercase text-[10px] tracking-widest font-bold">
              {vuiMode.toUpperCase()}
            </span>
          </button>

          <button
            onClick={onToggleSound}
            className="p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-xl transition-colors border border-transparent hover:border-white/10"
            title={soundEnabled ? 'Mute audio sound cues' : 'Enable audio sound cues'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-orange-400" /> : <VolumeX className="w-4 h-4 text-white/40" />}
          </button>
        </div>
      </div>
    </div>
  );
};
