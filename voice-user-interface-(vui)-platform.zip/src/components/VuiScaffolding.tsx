import React, { useState } from 'react';
import { ActiveTab, VoiceHint, VuiState } from '../types';
import { Sparkles, BookOpen, X, Play, Copy, Check, MessageSquare, Shield, HelpCircle, Layers, CheckCircle2 } from 'lucide-react';

interface VuiScaffoldingProps {
  currentView: ActiveTab;
  vuiState: VuiState;
  interimTranscript: string;
  finalTranscript: string;
  onSimulateCommand: (command: string) => void;
  onNavigateTab: (tab: ActiveTab) => void;
}

const CHEATSHEET_DATA: VoiceHint[] = [
  // CRM Leads Commands
  { label: 'Filter Active Leads', command: 'Filter leads by active status', viewContext: 'crm', category: 'Filtering & Sort' },
  { label: 'Filter In Review', command: 'Show leads in review', viewContext: 'crm', category: 'Filtering & Sort' },
  { label: 'Search Company', command: 'Search Acme Corp in leads', viewContext: 'crm', category: 'Control & Nav' },
  { label: 'Filter Industry', command: 'Filter by Technology industry', viewContext: 'crm', category: 'Filtering & Sort' },
  { label: 'Sort Revenue High-to-Low', command: 'Sort leads by revenue descending', viewContext: 'crm', category: 'Filtering & Sort' },
  { label: 'Export Q3 Report', command: 'Export Q3 leads report as CSV', viewContext: 'crm', category: 'Control & Nav' },
  { label: 'Reset CRM Filters', command: 'Clear all lead filters', viewContext: 'crm', category: 'Filtering & Sort' },

  // Dictation Notepad Commands
  { label: 'Dictate Note', command: 'Add note: Team aligned on Q4 enterprise launch targets', viewContext: 'dictation', category: 'Data Entry' },
  { label: 'Bullet Point Item', command: 'Bullet point: Deliver MVP by next sprint', viewContext: 'dictation', category: 'Data Entry' },
  { label: 'AI Summarize Note', command: 'Summarize this voice note with AI', viewContext: 'dictation', category: 'Data Entry' },
  { label: 'Clear Notepad', command: 'Clear the notepad', viewContext: 'dictation', category: 'Data Entry' },

  // Hands-free Inspection Commands
  { label: 'Pass First Item', command: 'Pass item one: Kitchen Cleanliness', viewContext: 'inspection', category: 'Inspection' },
  { label: 'Fail Item with Note', command: 'Fail item two refrigeration temperature too high at 48 degrees', viewContext: 'inspection', category: 'Inspection' },
  { label: 'Mark All Passed', command: 'Mark all inspection items as passed', viewContext: 'inspection', category: 'Inspection' },
  { label: 'Reset Checklist', command: 'Reset inspection checklist', viewContext: 'inspection', category: 'Inspection' },

  // Global Navigation & Control Commands
  { label: 'Go to Leads Table', command: 'Go to CRM leads table', viewContext: 'all', category: 'Control & Nav' },
  { label: 'Go to Dictation', command: 'Open voice dictation notepad', viewContext: 'all', category: 'Control & Nav' },
  { label: 'Go to Inspection', command: 'Open hands-free inspection checklist', viewContext: 'all', category: 'Control & Nav' },
  { label: 'Go to Compliance', command: 'Open privacy and compliance dashboard', viewContext: 'all', category: 'Control & Nav' },
  { label: 'Undo Last Action', command: 'Undo last voice action', viewContext: 'all', category: 'General' },
];

export const VuiScaffolding: React.FC<VuiScaffoldingProps> = ({
  currentView,
  vuiState,
  interimTranscript,
  finalTranscript,
  onSimulateCommand,
  onNavigateTab,
}) => {
  const [isCheatsheetOpen, setIsCheatsheetOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Filter contextual hints for current view
  const contextualHints = CHEATSHEET_DATA.filter(
    (h) => h.viewContext === currentView || h.viewContext === 'all'
  ).slice(0, 4);

  // Cheatsheet categories
  const categories = ['All', 'Filtering & Sort', 'Data Entry', 'Control & Nav', 'Inspection', 'General'];

  const filteredCheatsheet = CHEATSHEET_DATA.filter((item) => {
    const matchesCat = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch =
      item.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.command.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const copyToClipboard = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="w-full space-y-3">
      {/* 1. Contextual Command Hints Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-white/5 backdrop-blur-2xl rounded-2xl border border-white/10 shadow-lg">
        <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-orange-400">
          <Sparkles className="w-4 h-4 text-orange-400 animate-pulse" />
          <span>Context Hints:</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 flex-1 max-w-3xl">
          {contextualHints.map((hint, idx) => (
            <button
              key={idx}
              onClick={() => onSimulateCommand(hint.command)}
              title="Click to run voice command"
              className="group inline-flex items-center gap-1.5 px-3 py-1 text-xs font-mono bg-white/5 text-white/80 hover:text-white rounded-full border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/10 transition-all active:scale-95"
            >
              <span className="text-white/60 group-hover:text-orange-300">“{hint.command}”</span>
              <Play className="w-2.5 h-2.5 opacity-40 group-hover:opacity-100 text-orange-400" />
            </button>
          ))}
        </div>

        <button
          onClick={() => setIsCheatsheetOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold text-orange-400 hover:text-orange-300 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 rounded-xl transition-all"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>VUI CHEATSHEET</span>
        </button>
      </div>

      {/* 2. Live Streaming Transcript Feedback Bar (Visible when speaking or processing) */}
      {(vuiState === 'listening' || vuiState === 'processing' || interimTranscript || finalTranscript) && (
        <div className="flex items-center gap-3 p-3.5 bg-orange-500/10 backdrop-blur-2xl border border-orange-500/30 rounded-2xl shadow-[0_0_25px_rgba(249,115,22,0.15)] animate-in fade-in slide-in-from-top-1 duration-200">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 text-white shadow-lg shadow-orange-500/30 shrink-0">
            {vuiState === 'listening' ? (
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
              </span>
            ) : (
              <MessageSquare className="w-4 h-4 animate-pulse" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-xs text-orange-300 font-mono font-bold mb-0.5">
              <span>
                {vuiState === 'listening'
                  ? 'LIVE AUDIO STREAMING...'
                  : vuiState === 'processing'
                  ? 'GEMINI INTENT REASONING...'
                  : 'LAST SPOKEN UTTERANCE:'}
              </span>
              <span className="text-[10px] font-normal text-white/50 tracking-wider">
                {interimTranscript ? 'PARTIAL INTERIM BUFFER' : 'FINAL BUFFER'}
              </span>
            </div>
            <p className="text-sm font-medium text-white truncate">
              {interimTranscript ? (
                <span className="italic text-orange-300 font-mono">
                  “{interimTranscript}”
                </span>
              ) : finalTranscript ? (
                <span className="font-mono text-white/90">
                  “{finalTranscript}”
                </span>
              ) : (
                <span className="text-white/40 italic">Listening for speech...</span>
              )}
            </p>
          </div>
        </div>
      )}

      {/* 3. Progressive Command Cheatsheet Modal Drawer */}
      {isCheatsheetOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-150">
          <div className="relative w-full max-w-2xl max-h-[85vh] bg-[#0f0f11]/95 text-white backdrop-blur-2xl rounded-[28px] shadow-[0_25px_60px_rgba(0,0,0,0.9)] border border-white/10 flex flex-col overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-orange-500/15 border border-orange-500/30 text-orange-400 rounded-xl">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-tight">
                    Progressive VUI Command Catalog
                  </h3>
                  <p className="text-xs text-white/40 font-mono">
                    Multi-modal intent taxonomy & spoken templates
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCheatsheetOpen(false)}
                className="p-2 text-white/40 hover:text-white rounded-xl hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter & Search Bar */}
            <div className="px-6 py-3 bg-white/5 border-b border-white/10 space-y-2.5">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search supported intents (e.g. filter, export, notes, status)..."
                className="w-full px-3.5 py-2 text-xs bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-1 focus:ring-orange-500 text-white placeholder-white/40 font-mono"
              />

              <div className="flex flex-wrap items-center gap-1.5">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 text-xs font-mono rounded-full transition-all ${
                      selectedCategory === cat
                        ? 'bg-orange-500 text-white shadow-[0_0_10px_rgba(249,115,22,0.5)] font-bold'
                        : 'bg-white/5 text-white/60 border border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Command List */}
            <div className="flex-1 overflow-y-auto p-6 space-y-2.5">
              {filteredCheatsheet.map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3.5 rounded-2xl border border-white/10 bg-white/5 hover:border-orange-500/40 hover:bg-white/10 transition-all group"
                >
                  <div className="space-y-1 pr-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">
                        {item.label}
                      </span>
                      <span className="px-2 py-0.5 text-[9px] font-mono uppercase bg-white/10 text-white/60 rounded-md">
                        {item.category}
                      </span>
                    </div>
                    <p className="text-xs font-mono text-orange-400">
                      “{item.command}”
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => copyToClipboard(item.command, index)}
                      title="Copy phrase"
                      className="p-2 text-white/40 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
                    >
                      {copiedIndex === index ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                    <button
                      onClick={() => {
                        onSimulateCommand(item.command);
                        setIsCheatsheetOpen(false);
                      }}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-mono font-bold bg-orange-500/20 text-orange-300 border border-orange-500/40 hover:bg-orange-500 hover:text-white rounded-xl transition-all"
                    >
                      <Play className="w-3 h-3" />
                      <span>Test</span>
                    </button>
                  </div>
                </div>
              ))}

              {filteredCheatsheet.length === 0 && (
                <div className="text-center py-8 text-white/40 text-xs font-mono">
                  No matching voice commands found for “{searchQuery}”.
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3.5 bg-white/5 border-t border-white/10 flex items-center justify-between text-xs font-mono text-white/40">
              <span>Pro-tip: Hold [Spacebar] anytime for Push-to-Talk execution.</span>
              <button
                onClick={() => setIsCheatsheetOpen(false)}
                className="px-4 py-1.5 font-semibold text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
