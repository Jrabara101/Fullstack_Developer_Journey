import React, { useState } from 'react';
import { LeadItem } from '../../types';
import { Search, Filter, ArrowUpDown, Download, Check, Building, Phone, Mail, DollarSign, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CrmLeadsViewProps {
  leads: LeadItem[];
  filterStatus: string;
  searchQuery: string;
  sortBy: string;
  sortDirection: 'asc' | 'desc';
  selectedIndustry: string;
  lastVoiceActionHighlight: string | null;
  onFilterStatusChange: (status: string) => void;
  onSearchChange: (query: string) => void;
  onSortChange: (field: string) => void;
  onIndustryChange: (ind: string) => void;
  onExportReport: (type?: string) => void;
  searchInputRef: React.RefObject<HTMLInputElement | null>;
}

export const CrmLeadsView: React.FC<CrmLeadsViewProps> = ({
  leads,
  filterStatus,
  searchQuery,
  sortBy,
  sortDirection,
  selectedIndustry,
  lastVoiceActionHighlight,
  onFilterStatusChange,
  onSearchChange,
  onSortChange,
  onIndustryChange,
  onExportReport,
  searchInputRef,
}) => {
  const [selectedLeads, setSelectedLeads] = useState<string[]>([]);

  // Filter & sort leads
  const filteredLeads = leads
    .filter((lead) => {
      const matchStatus = filterStatus === 'all' || lead.status === filterStatus;
      const matchIndustry = selectedIndustry === 'all' || lead.industry.toLowerCase() === selectedIndustry.toLowerCase();
      const matchSearch =
        lead.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lead.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lead.title.toLowerCase().includes(searchQuery.toLowerCase());
      return matchStatus && matchIndustry && matchSearch;
    })
    .sort((a, b) => {
      let valA: any = (a as any)[sortBy] || a.name;
      let valB: any = (b as any)[sortBy] || b.name;

      if (typeof valA === 'string') {
        valA = valA.toLowerCase();
        valB = valB.toLowerCase();
      }

      if (sortDirection === 'asc') {
        return valA > valB ? 1 : -1;
      } else {
        return valA < valB ? 1 : -1;
      }
    });

  const totalRevenue = filteredLeads.reduce((sum, lead) => sum + lead.revenue, 0);

  const toggleSelectLead = (id: string) => {
    setSelectedLeads((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const getStatusBadge = (status: LeadItem['status']) => {
    switch (status) {
      case 'active':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-[0_0_8px_rgba(16,185,129,0.3)]';
      case 'in_review':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-[0_0_8px_rgba(245,158,11,0.3)]';
      case 'won':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40 shadow-[0_0_8px_rgba(59,130,246,0.3)]';
      case 'lost':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-[0_0_8px_rgba(244,63,94,0.3)]';
      default:
        return 'bg-white/10 text-white/70 border-white/10';
    }
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      {/* Top Action Metrics & Highlight Notice */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">Total Filtered Pipeline</span>
          <p className="text-2xl font-bold font-mono text-white">
            ${totalRevenue.toLocaleString()}
          </p>
          <p className="text-[11px] text-white/40 font-mono">Across {filteredLeads.length} matching leads</p>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">Active Status Filter</span>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-bold font-mono text-white uppercase">
              {filterStatus}
            </p>
            {filterStatus !== 'all' && (
              <button
                onClick={() => onFilterStatusChange('all')}
                className="text-[10px] text-orange-400 hover:text-orange-300 underline font-mono"
              >
                Reset
              </button>
            )}
          </div>
          <p className="text-[11px] text-white/40 font-mono">Voice command: "Filter leads by {filterStatus}"</p>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">Sort & Order</span>
          <p className="text-2xl font-bold font-mono text-white capitalize">
            {sortBy} ({sortDirection})
          </p>
          <p className="text-[11px] text-white/40 font-mono">Voice command: "Sort by {sortBy} descending"</p>
        </div>
      </div>

      {/* Action Bar */}
      <div className="p-4 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg flex flex-wrap items-center justify-between gap-3">
        {/* Search Input with Ref for Auto-Focus Fallback */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-white/40" />
          <input
            ref={searchInputRef as any}
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search leads, company, or title (Voice: 'Search Acme Corp')..."
            className="w-full pl-10 pr-4 py-2.5 text-xs bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-1 focus:ring-orange-500 text-white placeholder-white/40 font-mono"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3.5 top-3 text-xs text-white/40 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Status Filters */}
        <div className="flex flex-wrap items-center gap-1.5">
          {['all', 'active', 'in_review', 'won', 'lost'].map((status) => (
            <button
              key={status}
              onClick={() => onFilterStatusChange(status)}
              className={`px-3.5 py-2 text-xs font-mono font-bold uppercase rounded-xl border transition-all ${
                filterStatus === status
                  ? 'bg-orange-500 text-white border-orange-500 shadow-[0_0_12px_rgba(249,115,22,0.4)]'
                  : 'bg-white/5 text-white/60 border-white/10 hover:bg-white/10 hover:text-white'
              }`}
            >
              {status === 'all' ? 'All Leads' : status.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Export Q3 Report Button */}
        <button
          onClick={() => onExportReport('q3_leads')}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-mono font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-[0_0_12px_rgba(16,185,129,0.4)] transition-all active:scale-95"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Q3 Report (CSV)</span>
        </button>
      </div>

      {/* Leads Table */}
      <div className="bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-white/80">
            <thead className="bg-white/5 text-[10px] font-mono font-bold text-orange-400 uppercase tracking-widest border-b border-white/10">
              <tr>
                <th className="p-4 w-8">
                  <input
                    type="checkbox"
                    checked={selectedLeads.length === filteredLeads.length && filteredLeads.length > 0}
                    onChange={(e) => {
                      if (e.target.checked) setSelectedLeads(filteredLeads.map((l) => l.id));
                      else setSelectedLeads([]);
                    }}
                    className="rounded accent-orange-500"
                  />
                </th>
                <th className="p-4 cursor-pointer" onClick={() => onSortChange('name')}>
                  <div className="flex items-center gap-1.5">
                    <span>Contact Name</span>
                    <ArrowUpDown className="w-3 h-3 text-white/40" />
                  </div>
                </th>
                <th className="p-4 cursor-pointer" onClick={() => onSortChange('company')}>
                  <div className="flex items-center gap-1.5">
                    <span>Company / Title</span>
                    <ArrowUpDown className="w-3 h-3 text-white/40" />
                  </div>
                </th>
                <th className="p-4 cursor-pointer" onClick={() => onSortChange('status')}>
                  <div className="flex items-center gap-1.5">
                    <span>Status</span>
                    <ArrowUpDown className="w-3 h-3 text-white/40" />
                  </div>
                </th>
                <th className="p-4 cursor-pointer" onClick={() => onSortChange('industry')}>
                  <div className="flex items-center gap-1.5">
                    <span>Industry</span>
                    <ArrowUpDown className="w-3 h-3 text-white/40" />
                  </div>
                </th>
                <th className="p-4 cursor-pointer" onClick={() => onSortChange('revenue')}>
                  <div className="flex items-center gap-1.5">
                    <span>Est. Pipeline</span>
                    <ArrowUpDown className="w-3 h-3 text-white/40" />
                  </div>
                </th>
                <th className="p-4 cursor-pointer" onClick={() => onSortChange('quarter')}>
                  <div className="flex items-center gap-1.5">
                    <span>Quarter</span>
                    <ArrowUpDown className="w-3 h-3 text-white/40" />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono">
              {filteredLeads.map((lead) => {
                const isSelected = selectedLeads.includes(lead.id);
                return (
                  <tr
                    key={lead.id}
                    className={`hover:bg-white/5 transition-colors ${
                      isSelected ? 'bg-orange-500/10' : ''
                    }`}
                  >
                    <td className="p-4">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectLead(lead.id)}
                        className="rounded accent-orange-500"
                      />
                    </td>
                    <td className="p-4 font-sans">
                      <div className="font-bold text-white">{lead.name}</div>
                      <div className="text-[11px] text-white/40 font-mono">{lead.email}</div>
                    </td>
                    <td className="p-4 font-sans">
                      <div className="font-semibold text-white/90">{lead.company}</div>
                      <div className="text-[11px] text-white/40 font-mono">{lead.title}</div>
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 text-[9px] font-mono font-bold rounded-md border uppercase ${getStatusBadge(lead.status)}`}>
                        {lead.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-4 font-sans">
                      <span className="text-white/70 font-medium">{lead.industry}</span>
                    </td>
                    <td className="p-4 font-mono font-bold text-white">
                      ${lead.revenue.toLocaleString()}
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-white/10 text-white/70 rounded">
                        {lead.quarter}
                      </span>
                    </td>
                  </tr>
                );
              })}

              {filteredLeads.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-white/40 font-mono">
                    No leads matching current filters. Say “Clear filters” to reset.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
