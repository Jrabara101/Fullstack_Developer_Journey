import React from 'react';
import { InspectionStep } from '../../types';
import { CheckCircle2, XCircle, AlertCircle, RotateCcw, CheckCheck, Mic, Thermometer, ShieldAlert, Sparkles } from 'lucide-react';

interface HandsFreeInspectionViewProps {
  steps: InspectionStep[];
  onUpdateStepStatus: (id: string, status: InspectionStep['status'], notes?: string) => void;
  onMarkAllPassed: () => void;
  onResetChecklist: () => void;
}

export const HandsFreeInspectionView: React.FC<HandsFreeInspectionViewProps> = ({
  steps,
  onUpdateStepStatus,
  onMarkAllPassed,
  onResetChecklist,
}) => {
  const passedCount = steps.filter((s) => s.status === 'passed').length;
  const failedCount = steps.filter((s) => s.status === 'failed').length;
  const pendingCount = steps.filter((s) => s.status === 'pending').length;
  const completionPercentage = Math.round((passedCount / steps.length) * 100);

  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      {/* Top Banner */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-gradient-to-br from-orange-400 to-orange-600 text-white rounded-2xl shadow-lg shadow-orange-500/30">
            <Thermometer className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">
              Hands-Free Field & Kitchen Inspection Checklist
            </h2>
            <p className="text-xs text-white/50 font-mono">
              Designed for hands-busy environments with continuous voice command recognition
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onMarkAllPassed}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-mono font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-[0_0_15px_rgba(16,185,129,0.4)] transition-all active:scale-95"
          >
            <CheckCheck className="w-4 h-4" />
            <span>Mark All Passed (Voice: "Pass all")</span>
          </button>

          <button
            onClick={onResetChecklist}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-mono font-semibold text-white/70 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Progress & Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">Overall Compliance</span>
          <p className="text-2xl font-bold font-mono text-white">
            {completionPercentage}%
          </p>
          <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden mt-2">
            <div
              className="bg-orange-500 h-full rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(249,115,22,0.8)]"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">Passed Checkpoints</span>
          <p className="text-2xl font-bold font-mono text-emerald-400">
            {passedCount} / {steps.length}
          </p>
          <p className="text-[11px] text-white/40 font-mono">Inspected & Verified</p>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">Failed / Deviations</span>
          <p className="text-2xl font-bold font-mono text-rose-400">
            {failedCount}
          </p>
          <p className="text-[11px] text-white/40 font-mono">Requiring action</p>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">Pending Review</span>
          <p className="text-2xl font-bold font-mono text-amber-400">
            {pendingCount}
          </p>
          <p className="text-[11px] text-white/40 font-mono">Awaiting voice check</p>
        </div>
      </div>

      {/* Step Checklist List */}
      <div className="space-y-3">
        {steps.map((step, idx) => (
          <div
            key={step.id}
            className={`p-5 rounded-[24px] backdrop-blur-xl border transition-all ${
              step.status === 'passed'
                ? 'bg-emerald-500/10 border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.1)]'
                : step.status === 'failed'
                ? 'bg-rose-500/10 border-rose-500/30 shadow-[0_0_15px_rgba(244,63,94,0.1)]'
                : 'bg-white/5 border-white/10 hover:border-white/20'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1 flex-1 min-w-[280px]">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-white/10 text-orange-400 rounded-md border border-white/10">
                    #{idx + 1} {step.code}
                  </span>
                  <span className="text-xs font-mono font-bold text-white/70">{step.area}</span>
                  <span className="text-xs font-mono text-white/40">| Target: {step.threshold}</span>
                </div>
                <h4 className="text-sm font-bold text-white tracking-tight">{step.title}</h4>
                {step.operatorNotes && (
                  <p className="text-xs text-rose-300 font-mono italic bg-rose-950/40 p-2.5 rounded-xl border border-rose-500/30">
                    Voice Note: “{step.operatorNotes}”
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => onUpdateStepStatus(step.id, 'passed')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-mono font-bold rounded-xl transition-all ${
                    step.status === 'passed'
                      ? 'bg-emerald-600 text-white shadow-[0_0_12px_rgba(16,185,129,0.5)]'
                      : 'bg-white/5 hover:bg-emerald-500/20 text-white/70 hover:text-emerald-300 border border-white/10'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Pass</span>
                </button>

                <button
                  onClick={() => onUpdateStepStatus(step.id, 'failed', 'Deviation recorded via inspector')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-mono font-bold rounded-xl transition-all ${
                    step.status === 'failed'
                      ? 'bg-rose-600 text-white shadow-[0_0_12px_rgba(244,63,94,0.5)]'
                      : 'bg-white/5 hover:bg-rose-500/20 text-white/70 hover:text-rose-300 border border-white/10'
                  }`}
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Fail</span>
                </button>

                <button
                  onClick={() => onUpdateStepStatus(step.id, 'pending')}
                  className="p-2 text-white/40 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition-colors"
                  title="Reset step"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
