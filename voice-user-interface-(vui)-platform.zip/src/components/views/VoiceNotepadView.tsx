import React, { useState } from 'react';
import { Mic, FileText, Sparkles, Copy, Trash2, Check, Download, ListOrdered, AlignLeft, RefreshCw } from 'lucide-react';

interface VoiceNotepadViewProps {
  noteContent: string;
  isDictating: boolean;
  onUpdateNote: (content: string) => void;
  onClearNote: () => void;
  onToggleDictation: () => void;
}

export const VoiceNotepadView: React.FC<VoiceNotepadViewProps> = ({
  noteContent,
  isDictating,
  onUpdateNote,
  onClearNote,
  onToggleDictation,
}) => {
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [summaryResult, setSummaryResult] = useState<string | null>(null);

  const handleAiAction = async (action: 'summarize' | 'format' | 'action_items') => {
    if (!noteContent.trim()) return;
    setIsEnhancing(true);
    try {
      const res = await fetch('/api/enhance-note', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: noteContent, action }),
      });
      const data = await res.json();
      if (data.result) {
        if (action === 'format') {
          onUpdateNote(data.result);
        } else {
          setSummaryResult(data.result);
        }
      }
    } catch (err) {
      console.error("AI enhancement error:", err);
    } finally {
      setIsEnhancing(false);
    }
  };

  const copyNote = () => {
    navigator.clipboard.writeText(noteContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const wordCount = noteContent.trim() ? noteContent.trim().split(/\s+/).length : 0;
  const charCount = noteContent.length;

  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      {/* Top Banner with Dictation Controls */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className={`p-3 rounded-2xl transition-colors ${
            isDictating
              ? 'bg-rose-500 text-white animate-pulse shadow-[0_0_15px_rgba(244,63,94,0.6)]'
              : 'bg-gradient-to-br from-orange-400 to-orange-600 text-white shadow-lg shadow-orange-500/30'
          }`}>
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">
              Long-Form Dictation & Smart Notepad
            </h2>
            <p className="text-xs text-white/50 font-mono">
              Speak naturally for continuous transcript stream or trigger formatting commands
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onToggleDictation}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold rounded-xl shadow-lg transition-all active:scale-95 ${
              isDictating
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-[0_0_15px_rgba(225,29,72,0.5)]'
                : 'bg-orange-500 hover:bg-orange-600 text-white shadow-[0_0_15px_rgba(249,115,22,0.4)]'
            }`}
          >
            <Mic className={`w-4 h-4 ${isDictating ? 'animate-bounce' : ''}`} />
            <span>{isDictating ? 'Stop Dictating' : 'Start Continuous Dictation'}</span>
          </button>

          <button
            onClick={() => handleAiAction('format')}
            disabled={isEnhancing || !noteContent}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-mono font-semibold bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-colors disabled:opacity-40"
          >
            <Sparkles className="w-3.5 h-3.5 text-orange-400" />
            <span>Format Notes</span>
          </button>

          <button
            onClick={() => handleAiAction('summarize')}
            disabled={isEnhancing || !noteContent}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-mono font-semibold bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-colors disabled:opacity-40"
          >
            <ListOrdered className="w-3.5 h-3.5 text-orange-400" />
            <span>AI Summarize</span>
          </button>

          <button
            onClick={copyNote}
            disabled={!noteContent}
            className="p-2.5 text-white/60 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition-colors disabled:opacity-40"
            title="Copy Note"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>

          <button
            onClick={onClearNote}
            disabled={!noteContent}
            className="p-2.5 text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 rounded-xl border border-rose-500/20 transition-colors disabled:opacity-40"
            title="Clear Note"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Dictation Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Editor Area */}
        <div className="lg:col-span-2 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg p-6 space-y-3">
          <div className="flex items-center justify-between text-xs text-white/50 border-b border-white/10 pb-3 font-mono">
            <span className="font-semibold text-orange-400 uppercase tracking-wider text-[11px]">Live Voice Document</span>
            <div className="flex items-center gap-3">
              <span>{wordCount} words</span>
              <span>{charCount} characters</span>
            </div>
          </div>

          <textarea
            value={noteContent}
            onChange={(e) => onUpdateNote(e.target.value)}
            placeholder="Click 'Start Continuous Dictation' or use Push-to-Talk to dictate notes hands-free. Supported voice commands: 'Bullet point [text]', 'New line', 'Clear note'..."
            rows={14}
            className="w-full text-sm leading-relaxed bg-transparent border-0 focus:outline-none text-white placeholder-white/30 resize-none font-sans"
          />

          {isDictating && (
            <div className="flex items-center gap-2.5 p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-xs text-rose-300 animate-pulse font-mono">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
              <span>Listening for spoken dictation stream...</span>
            </div>
          )}
        </div>

        {/* AI Insight & Summary Sidebar */}
        <div className="bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg p-6 space-y-4">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-orange-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4 text-orange-400" />
            <span>AI Executive Insights</span>
          </div>

          {isEnhancing ? (
            <div className="py-12 text-center text-xs text-orange-300 space-y-2 font-mono">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto text-orange-400" />
              <p>Gemini AI analyzing and summarizing dictation...</p>
            </div>
          ) : summaryResult ? (
            <div className="p-4 bg-white/5 rounded-2xl border border-white/10 text-xs text-white/90 space-y-2.5">
              <div className="font-mono font-bold text-orange-400 uppercase tracking-wider text-[11px]">Generated Executive Summary:</div>
              <div className="whitespace-pre-line leading-relaxed font-sans">{summaryResult}</div>
              <button
                onClick={() => setSummaryResult(null)}
                className="text-[11px] font-mono text-orange-400 hover:text-orange-300 underline pt-1 block"
              >
                Dismiss Summary
              </button>
            </div>
          ) : (
            <div className="p-4 bg-white/5 rounded-2xl border border-white/10 text-xs text-white/60 space-y-2 font-mono">
              <p className="font-semibold text-white uppercase tracking-wider text-[11px] text-orange-400">Voice Dictation Tips:</p>
              <ul className="space-y-1.5 text-[11px] list-disc list-inside">
                <li>Say <span className="text-orange-300 font-bold">“Bullet point [text]”</span> to insert itemized lists.</li>
                <li>Say <span className="text-orange-300 font-bold">“Summarize this note”</span> for AI action extraction.</li>
                <li>Punctuation is automatically parsed from spoken pauses.</li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
