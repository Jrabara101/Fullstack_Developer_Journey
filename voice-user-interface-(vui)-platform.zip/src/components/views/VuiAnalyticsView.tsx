import React from 'react';
import { VuiLogEntry } from '../../types';
import { Activity, Zap, CheckCircle2, AlertTriangle, XCircle, RotateCcw, BarChart3, Clock } from 'lucide-react';

interface VuiAnalyticsViewProps {
  logs: VuiLogEntry[];
  onRerunUtterance: (transcript: string) => void;
  onClearLogs: () => void;
}

export const VuiAnalyticsView: React.FC<VuiAnalyticsViewProps> = ({
  logs,
  onRerunUtterance,
  onClearLogs,
}) => {
  const total = logs.length;
  const highCount = logs.filter((l) => l.confidenceTier === 'high').length;
  const mediumCount = logs.filter((l) => l.confidenceTier === 'medium').length;
  const lowCount = logs.filter((l) => l.confidenceTier === 'low').length;

  const highPercent = total > 0 ? Math.round((highCount / total) * 100) : 0;
  const mediumPercent = total > 0 ? Math.round((mediumCount / total) * 100) : 0;
  const lowPercent = total > 0 ? Math.round((lowCount / total) * 100) : 0;

  const avgLatency =
    total > 0
      ? Math.round(logs.reduce((sum, l) => sum + (l.latencyMs || 0), 0) / total)
      : 0;

  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      {/* Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">
            <span>Total Voice Queries</span>
            <Activity className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-white">{total}</p>
          <p className="text-[11px] text-white/40 font-mono">Captured in current session</p>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400">
            <span>High-Confidence Auto</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-400">
            {highPercent}% ({highCount})
          </p>
          <p className="text-[11px] text-white/40 font-mono">Executed with Undo toast</p>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-[11px] font-mono font-bold uppercase tracking-wider text-amber-400">
            <span>Disambiguations</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-amber-400">
            {mediumPercent}% ({mediumCount})
          </p>
          <p className="text-[11px] text-white/40 font-mono">Resolved via 50-85% dialog</p>
        </div>

        <div className="p-5 bg-white/5 backdrop-blur-2xl rounded-[24px] border border-white/10 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-[11px] font-mono font-bold uppercase tracking-wider text-orange-400">
            <span>Avg Response Latency</span>
            <Clock className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-white">
            {avgLatency} ms
          </p>
          <p className="text-[11px] text-white/40 font-mono">Gemini 3.7 Flash parsing</p>
        </div>
      </div>

      {/* Confidence Distribution Bar */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 shadow-lg space-y-3.5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold text-orange-400 uppercase tracking-widest">
            VUI Confidence Routing Distribution
          </h3>
          <span className="text-xs font-mono text-white/40">Total samples: {total}</span>
        </div>

        <div className="w-full h-3.5 bg-white/10 rounded-full overflow-hidden flex">
          <div
            className="bg-emerald-500 h-full transition-all duration-300 shadow-[0_0_8px_rgba(16,185,129,0.8)]"
            style={{ width: `${highPercent}%` }}
            title={`High (>85%): ${highCount}`}
          />
          <div
            className="bg-amber-500 h-full transition-all duration-300 shadow-[0_0_8px_rgba(245,158,11,0.8)]"
            style={{ width: `${mediumPercent}%` }}
            title={`Medium (50-85%): ${mediumCount}`}
          />
          <div
            className="bg-rose-500 h-full transition-all duration-300 shadow-[0_0_8px_rgba(244,63,94,0.8)]"
            style={{ width: `${lowPercent}%` }}
            title={`Low (<50%): ${lowCount}`}
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-white/60">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span>High Confidence &gt;85% ({highPercent}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <span>Medium 50–85% ({mediumPercent}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
            <span>Low &lt;50% ({lowPercent}%)</span>
          </div>
        </div>
      </div>

      {/* Utterance Telemetry Log Table */}
      <div className="bg-white/5 backdrop-blur-2xl rounded-[28px] border border-white/10 overflow-hidden shadow-2xl">
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold text-orange-400 uppercase tracking-widest">
            Voice Utterance Audit Stream
          </h3>
          {logs.length > 0 && (
            <button
              onClick={onClearLogs}
              className="text-xs font-mono text-rose-400 hover:text-rose-300 hover:underline font-semibold"
            >
              Clear Telemetry Log
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-white/80">
            <thead className="bg-white/5 text-[10px] font-mono font-bold text-orange-400 uppercase tracking-widest border-b border-white/10">
              <tr>
                <th className="p-4">Spoken Transcript</th>
                <th className="p-4">Detected Intent</th>
                <th className="p-4">Confidence</th>
                <th className="p-4">Tier</th>
                <th className="p-4">Latency</th>
                <th className="p-4">Timestamp</th>
                <th className="p-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-white/5">
                  <td className="p-4 font-mono font-medium text-white">
                    “{log.transcript}”
                  </td>
                  <td className="p-4 font-bold text-orange-300">
                    {log.detectedIntent}
                  </td>
                  <td className="p-4 font-semibold text-white">
                    {Math.round(log.confidenceScore * 100)}%
                  </td>
                  <td className="p-4">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 text-[9px] font-mono font-bold rounded uppercase border ${
                        log.confidenceTier === 'high'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : log.confidenceTier === 'medium'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                      }`}
                    >
                      {log.confidenceTier}
                    </span>
                  </td>
                  <td className="p-4 text-white/40">
                    {log.latencyMs} ms
                  </td>
                  <td className="p-4 text-white/40">
                    {log.timestamp}
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() => onRerunUtterance(log.transcript)}
                      className="text-xs font-mono font-bold text-orange-400 hover:text-orange-300 hover:underline"
                    >
                      Re-run
                    </button>
                  </td>
                </tr>
              ))}

              {logs.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-white/40 font-mono">
                    No voice sessions logged yet. Speak or simulate a command to populate telemetry.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
