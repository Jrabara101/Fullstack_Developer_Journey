export interface BrowserPlatformInfo {
  name: string;
  engine: 'Chromium' | 'WebKit' | 'Gecko' | 'Other';
  supportsWebSpeech: boolean;
  requiresPrefix: boolean;
  prefixName?: string;
  complianceWarning?: string;
  recommendation: string;
  cloudTranscribed: boolean;
}

export function detectBrowserPlatform(): BrowserPlatformInfo {
  const ua = navigator.userAgent;
  let name = 'Unknown Browser';
  let engine: 'Chromium' | 'WebKit' | 'Gecko' | 'Other' = 'Other';
  let supportsWebSpeech = false;
  let requiresPrefix = false;
  let prefixName = '';
  let complianceWarning = undefined;
  let recommendation = '';
  let cloudTranscribed = true;

  // Check speech constructor
  const hasStandard = 'SpeechRecognition' in window;
  const hasWebkit = 'webkitSpeechRecognition' in window;

  if (hasStandard) {
    supportsWebSpeech = true;
    requiresPrefix = false;
  } else if (hasWebkit) {
    supportsWebSpeech = true;
    requiresPrefix = true;
    prefixName = 'webkitSpeechRecognition';
  }

  // Engine classification
  if (ua.indexOf('Edg/') > -1) {
    name = 'Microsoft Edge';
    engine = 'Chromium';
    cloudTranscribed = true;
    complianceWarning = 'Streams audio chunks to Microsoft cloud servers for speech model processing.';
    recommendation = 'Fully supported with native fast cloud recognition. Ensure HIPAA/GDPR zero-retention mode is toggled if handling protected health records.';
  } else if (ua.indexOf('Chrome/') > -1 && ua.indexOf('Edg/') === -1) {
    name = 'Google Chrome';
    engine = 'Chromium';
    cloudTranscribed = true;
    complianceWarning = 'Streams audio fragments to Google cloud transcription endpoints.';
    recommendation = 'Gold-standard Web Speech support. Excellent real-time interim streaming accuracy.';
  } else if (ua.indexOf('Safari/') > -1 && ua.indexOf('Chrome/') === -1) {
    name = 'Apple Safari';
    engine = 'WebKit';
    cloudTranscribed = true;
    complianceWarning = 'Utilizes Apple on-device/Siri cloud speech services via webkit prefix.';
    recommendation = 'Supported via webkitSpeechRecognition prefix. On macOS Sonoma+, utilizes on-device neural engine where available.';
  } else if (ua.indexOf('Firefox/') > -1) {
    name = 'Mozilla Firefox';
    engine = 'Gecko';
    cloudTranscribed = false;
    complianceWarning = 'Web Speech API is disabled by default behind experimental flags (media.webspeech.recognition.enable).';
    recommendation = 'VUI Fallback Active: Utilizes Gemini Multimodal Audio Transcription fallback or interactive audio testbench.';
  } else if (ua.indexOf('OPR/') > -1 || ua.indexOf('Opera/') > -1) {
    name = 'Opera';
    engine = 'Chromium';
    cloudTranscribed = true;
    recommendation = 'Chromium-based. Full Web Speech API support.';
  } else {
    name = 'Modern Web Browser';
    engine = 'Other';
    recommendation = 'Standard Web Speech or server-side Gemini audio transcription fallback active.';
  }

  return {
    name,
    engine,
    supportsWebSpeech,
    requiresPrefix,
    prefixName,
    complianceWarning,
    recommendation,
    cloudTranscribed,
  };
}
