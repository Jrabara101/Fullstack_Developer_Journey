import { IntentParseResult, VuiMode, VuiState } from '../types';
import { playVuiSound } from './audioEffects';

export interface VoiceCallbacks {
  onStateChange: (state: VuiState) => void;
  onInterimTranscript: (text: string) => void;
  onFinalTranscript: (text: string, confidence: number) => void;
  onError: (error: string) => void;
  onIntentParsed: (result: IntentParseResult) => void;
  onAudioLevel?: (level: number) => void; // 0.0 - 1.0 for visualizer
}

export class VoiceController {
  private recognition: any = null;
  private isListening = false;
  private mode: VuiMode = 'ptt';
  private callbacks: VoiceCallbacks;
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micStream: MediaStream | null = null;
  private animationFrameId: number | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private consecutiveFailures = 0;
  private soundEnabled = true;

  constructor(callbacks: VoiceCallbacks) {
    this.callbacks = callbacks;
    this.initRecognition();
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
  }

  public setMode(mode: VuiMode) {
    this.mode = mode;
    if (this.recognition) {
      this.recognition.continuous = mode === 'continuous';
    }
  }

  public getConsecutiveFailures(): number {
    return this.consecutiveFailures;
  }

  public resetConsecutiveFailures() {
    this.consecutiveFailures = 0;
  }

  public initRecognition() {
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition ||
      (window as any).mozSpeechRecognition ||
      (window as any).msSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn("Native SpeechRecognition not supported in this browser engine.");
      return;
    }

    try {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = this.mode === 'continuous';
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 3;

      this.recognition.onstart = () => {
        this.isListening = true;
        this.callbacks.onStateChange('listening');
        playVuiSound('start_listening', this.soundEnabled);
      };

      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';
        let finalConfidence = 0.9;

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const result = event.results[i];
          if (result.isFinal) {
            finalTranscript += result[0].transcript;
            if (result[0].confidence && result[0].confidence > 0) {
              finalConfidence = result[0].confidence;
            }
          } else {
            interimTranscript += result[0].transcript;
          }
        }

        if (interimTranscript) {
          this.callbacks.onInterimTranscript(interimTranscript);
        }

        if (finalTranscript.trim()) {
          this.callbacks.onFinalTranscript(finalTranscript.trim(), finalConfidence);
          this.processTranscriptWithGemini(finalTranscript.trim(), finalConfidence);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn("Speech recognition error:", event.error);
        if (event.error === 'no-speech') {
          // If no speech detected in continuous mode, we silently loop
          if (this.mode === 'ptt') {
            this.callbacks.onStateChange('idle');
          }
        } else if (event.error === 'not-allowed') {
          this.callbacks.onError('Microphone permission was denied. Please allow microphone access in browser settings.');
          this.callbacks.onStateChange('error');
        } else {
          this.callbacks.onError(`Recognition issue: ${event.error}`);
          this.callbacks.onStateChange('idle');
        }
      };

      this.recognition.onend = () => {
        this.isListening = false;
        if (this.mode === 'continuous') {
          // Restart if continuous mode is still enabled
          try {
            this.recognition.start();
          } catch (e) {
            this.callbacks.onStateChange('idle');
          }
        } else {
          this.callbacks.onStateChange('idle');
        }
        playVuiSound('stop_listening', this.soundEnabled);
        this.stopAudioAnalysis();
      };
    } catch (e: any) {
      console.error("Failed to initialize speech recognition:", e);
    }
  }

  public async startListening(currentView: string = 'crm', contextData: any = {}) {
    if (this.isListening) return;

    try {
      await this.startAudioAnalysis();
      if (this.recognition) {
        try {
          this.recognition.start();
        } catch (err: any) {
          console.warn("Recognition already started or restarting:", err);
        }
      } else {
        // Fallback: Start MediaRecorder to capture audio chunk for Gemini AI STT
        this.startMediaRecorder(currentView, contextData);
      }
    } catch (err: any) {
      console.error("Could not start listening:", err);
      this.callbacks.onError(err.message || "Failed to access microphone");
      this.callbacks.onStateChange('error');
    }
  }

  public stopListening() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (err) {
        console.warn("Error stopping recognition:", err);
      }
    }
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.stop();
    }
    this.isListening = false;
    this.stopAudioAnalysis();
  }

  public toggleListening(currentView: string = 'crm', contextData: any = {}) {
    if (this.isListening) {
      this.stopListening();
    } else {
      this.startListening(currentView, contextData);
    }
  }

  private async startAudioAnalysis() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.micStream = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioContextClass();
      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }

      const source = this.audioCtx.createMediaStreamSource(stream);
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 256;
      source.connect(this.analyser);

      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const updateLevel = () => {
        if (!this.analyser) return;
        this.analyser.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const average = sum / bufferLength;
        const normalized = Math.min(1.0, average / 80); // 0.0 to 1.0

        if (this.callbacks.onAudioLevel) {
          this.callbacks.onAudioLevel(normalized);
        }

        this.animationFrameId = requestAnimationFrame(updateLevel);
      };

      updateLevel();
    } catch (err) {
      console.warn("Audio analysis stream not available:", err);
    }
  }

  private stopAudioAnalysis() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      this.audioCtx.close();
      this.audioCtx = null;
    }
    if (this.callbacks.onAudioLevel) {
      this.callbacks.onAudioLevel(0);
    }
  }

  private async startMediaRecorder(currentView: string, contextData: any) {
    try {
      this.callbacks.onStateChange('listening');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.audioChunks = [];
      this.mediaRecorder = new MediaRecorder(stream);

      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          this.audioChunks.push(e.data);
        }
      };

      this.mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        this.callbacks.onStateChange('processing');

        // Convert blob to base64
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Data = (reader.result as string).split(',')[1];
          try {
            const res = await fetch('/api/transcribe-audio', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ audioBase64: base64Data, mimeType: 'audio/webm' }),
            });
            const data = await res.json();
            if (data.transcript) {
              this.callbacks.onFinalTranscript(data.transcript, 0.92);
              this.processTranscriptWithGemini(data.transcript, 0.92, currentView, contextData);
            } else {
              this.callbacks.onError('No speech recognized by server transcription.');
              this.callbacks.onStateChange('idle');
            }
          } catch (err: any) {
            this.callbacks.onError(`Transcription error: ${err.message}`);
            this.callbacks.onStateChange('idle');
          }
        };
      };

      this.mediaRecorder.start();
    } catch (err: any) {
      this.callbacks.onError(`Could not start media recorder: ${err.message}`);
      this.callbacks.onStateChange('idle');
    }
  }

  public async processTranscriptWithGemini(
    transcript: string,
    acousticConfidence: number = 0.9,
    currentView: string = 'crm',
    contextData: any = {},
    forcedConfidence?: number
  ) {
    this.callbacks.onStateChange('processing');
    const startTime = performance.now();

    try {
      const response = await fetch('/api/parse-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript,
          currentView,
          contextData,
          forcedConfidence,
        }),
      });

      const resJson = await response.json();
      const endTime = performance.now();
      const latencyMs = Math.round(endTime - startTime);

      if (resJson.success && resJson.data) {
        const intentResult: IntentParseResult = {
          ...resJson.data,
          rawTranscript: transcript,
          timestamp: Date.now(),
        };

        // Check confidence routing
        if (intentResult.confidenceTier === 'low') {
          this.consecutiveFailures += 1;
          playVuiSound('fallback_error', this.soundEnabled);
          this.callbacks.onStateChange('error');
        } else if (intentResult.confidenceTier === 'medium') {
          playVuiSound('disambiguate', this.soundEnabled);
          this.callbacks.onStateChange('idle');
        } else {
          // High confidence
          this.consecutiveFailures = 0;
          playVuiSound('action_success', this.soundEnabled);
          this.callbacks.onStateChange('success');
        }

        this.callbacks.onIntentParsed(intentResult);
      } else {
        throw new Error(resJson.error || 'Failed to parse intent');
      }
    } catch (err: any) {
      console.error("Intent parsing error:", err);
      this.consecutiveFailures += 1;
      this.callbacks.onError(`Failed to parse voice command: ${err.message}`);
      this.callbacks.onStateChange('idle');
    }
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }
}
