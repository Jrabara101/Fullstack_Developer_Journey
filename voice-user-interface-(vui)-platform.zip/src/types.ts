export type VuiState = 'idle' | 'priming' | 'listening' | 'processing' | 'success' | 'error';

export type ConfidenceTier = 'high' | 'medium' | 'low';

export type VuiMode = 'ptt' | 'continuous';

export type PrivacyMode = 'standard' | 'hipaa' | 'gdpr';

export type ActiveTab = 'crm' | 'dictation' | 'inspection' | 'analytics' | 'compliance' | 'matrix';

export interface DisambiguationOption {
  label: string;
  intent: string;
  parametersJson: string;
}

export interface IntentParseResult {
  intent: string;
  actionLabel: string;
  parameters: {
    targetView?: ActiveTab;
    status?: string;
    industry?: string;
    query?: string;
    field?: string;
    direction?: 'asc' | 'desc';
    reportType?: string;
    format?: string;
    text?: string;
    isBullet?: boolean;
    isNewLine?: boolean;
    action?: string;
    itemId?: string;
    actionType?: string;
    notes?: string;
    mode?: VuiMode;
    privacyLevel?: PrivacyMode;
    [key: string]: any;
  };
  confidenceScore: number;
  confidenceTier: ConfidenceTier;
  disambiguationOptions: DisambiguationOption[];
  rephraseSuggestions: string[];
  explanation: string;
  rawTranscript?: string;
  timestamp?: number;
}

export interface UndoableAction {
  id: string;
  actionLabel: string;
  undoFunction: () => void;
  timestamp: number;
  expiresAt: number;
}

export interface LeadItem {
  id: string;
  name: string;
  company: string;
  title: string;
  email: string;
  phone: string;
  status: 'active' | 'in_review' | 'lead' | 'won' | 'lost';
  revenue: number;
  industry: 'Technology' | 'Healthcare' | 'Finance' | 'Manufacturing' | 'Retail';
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  score: number;
  lastContact: string;
}

export interface InspectionStep {
  id: string;
  code: string;
  title: string;
  area: 'Kitchen Cleanliness' | 'Refrigeration Temp' | 'Fire Safety' | 'Food Prep' | 'Sanitation';
  threshold: string;
  status: 'pending' | 'passed' | 'failed' | 'flagged';
  measuredValue?: string;
  operatorNotes?: string;
  timestamp?: string;
}

export interface VuiLogEntry {
  id: string;
  transcript: string;
  detectedIntent: string;
  confidenceScore: number;
  confidenceTier: ConfidenceTier;
  latencyMs: number;
  executed: boolean;
  engine: string;
  timestamp: string;
  wasDisambiguated?: boolean;
}

export interface VoiceHint {
  label: string;
  command: string;
  viewContext?: ActiveTab | 'all';
  category: 'Control & Nav' | 'Data Entry' | 'Filtering & Sort' | 'Inspection' | 'General';
}
